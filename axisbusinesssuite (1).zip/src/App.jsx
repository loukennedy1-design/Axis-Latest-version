import { useEffect } from 'react'
import { Toaster } from 'sonner'
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ProtectedRoute from '@/components/ProtectedRoute';
import AppLayout from '@/components/layout/AppLayout';
import Dashboard from '@/pages/Dashboard';
import Leads from '@/pages/Leads';
import ImportCSV from '@/pages/ImportCSV';
import CallBot from '@/pages/CallBot';
import CallLogs from '@/pages/CallLogs';
import Appointments from '@/pages/Appointments';
import DNCRegistry from '@/pages/DNCRegistry';
import Compliance from '@/pages/Compliance';
import UserManagement from '@/pages/admin/UserManagement';
import AdminConsole from '@/pages/AdminConsole';
import AdminSettings from '@/pages/admin/Settings';
import CustomPricing from '@/pages/admin/CustomPricing';
import RevenueAdmin from '@/pages/admin/Revenue';
import SuperAdmin from '@/pages/SuperAdmin';
import SubscribersOverview from '@/pages/admin/SubscribersOverview';
import TrialInvites from '@/pages/admin/TrialInvites';
import FollowUpTasks from '@/pages/FollowUpTasks';
import ImportWizard from '@/pages/ImportWizard';
import UniversalImport from '@/pages/UniversalImport';
import NurtureWorkflows from '@/pages/NurtureWorkflows';
import LeadScoring from '@/pages/LeadScoring';
import CoachingHub from '@/pages/CoachingHub';
import LeadRouting from '@/pages/LeadRouting';
import CallCoachingReport from '@/pages/CallCoachingReport';
import CallCalendar from '@/pages/CallCalendar';
import ComplianceExport from '@/pages/ComplianceExport';
import MyTeam from '@/pages/MyTeam';
import LeadGenerator from '@/pages/LeadGenerator';
import FacebookLeads from '@/pages/FacebookLeads';
import SalesTeam from '@/pages/SalesTeam';
import ZoomScheduler from '@/pages/ZoomScheduler';
import Recruitment from '@/pages/Recruitment';
import PricingCheckout from '@/pages/PricingCheckout';
import CheckoutConfirmation from '@/pages/CheckoutConfirmation';

import Email from '@/pages/Email';
import AEChat from '@/pages/AEChat';
import AEOnboarding from '@/pages/AEOnboarding';
import TrialSignup from '@/pages/TrialSignup';
import TermsOfService from '@/pages/TermsOfService';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import SubscriptionManagement from '@/pages/SubscriptionManagement';
import SocialMedia from '@/pages/SocialMedia';
import HumanResources from '@/pages/HumanResources';
import HrAnalytics from '@/pages/HrAnalytics';
import SmsInbox from '@/pages/SmsInbox';
import LandingPage from '@/pages/LandingPage';
import MovementSignup from '@/pages/MovementSignup';
import WhiteLabel from '@/pages/admin/WhiteLabel';
import SubscriptionManager from '@/pages/admin/SubscriptionManager';
import ApiCenter from '@/pages/ApiCenter';
import AgentTasks from '@/pages/AgentTasks';
import UserSettings from '@/pages/UserSettings';
import DemoMode from '@/pages/DemoMode';
import Academy from '@/pages/Academy';
import CorporateCommand from '@/pages/CorporateCommand';
import FinancialOps from '@/pages/FinancialOps';
import FinanceOverview from '@/pages/FinanceOverview';
import FinanceAnalytics from '@/pages/FinanceAnalytics';
import SystemTopology from '@/pages/SystemTopology.jsx';
import VideoMarketing from '@/pages/VideoMarketing';
import OmniChannel from '@/pages/OmniChannel';
import DigitalEmployees from '@/pages/DigitalEmployees';
import AIAgentsCommand from '@/pages/AIAgentsCommand';
import LLMOrchestration from '@/pages/LLMOrchestration';
import GovernanceCore from '@/pages/GovernanceCore';
import AxisAgenticCRM from '@/pages/AxisAgenticCRM';
import AutonomousScheduler from '@/pages/AutonomousScheduler';
import GlobalWorkforce from '@/pages/GlobalWorkforce';
import DocumentIntelligence from '@/pages/DocumentIntelligence';
import ProductionValidation from '@/pages/ProductionValidation';
import EngagementHub from '@/pages/EngagementHub';
import DeploymentStatus from '@/pages/DeploymentStatus';
import IndustryOnboarding from '@/pages/IndustryOnboarding';
import RealtimeDashboards from '@/pages/RealtimeDashboards';
import Settings from '@/pages/Settings';
import RevenueOperations from '@/pages/RevenueOperations';
import WorkflowOrchestration from '@/pages/WorkflowOrchestration';
import ProductionFulfillment from '@/pages/ProductionFulfillment';
import OperationsDashboard from '@/pages/OperationsDashboard';
import InventoryAnalytics from '@/pages/InventoryAnalytics';
import LogisticsAnalytics from '@/pages/LogisticsAnalytics';
import ProductionAnalytics from '@/pages/ProductionAnalytics';
import CrossDepartmentSync from '@/pages/CrossDepartmentSync';
import UniversalOperationalAI from '@/pages/UniversalOperationalAI';
import IntegrationMarketplace from '@/pages/IntegrationMarketplace';
import SystemAuditReport from '@/pages/SystemAuditReport';
import SetupWizard from '@/pages/SetupWizard';
import RemoteAccess from '@/pages/admin/RemoteAccess';
import SecurityVault from '@/pages/admin/SecurityVault';
import QuickIntegrations from '@/pages/QuickIntegrations';
import AIFeatures from '@/pages/AIFeatures';
import QuoteBuilder from '@/pages/QuoteBuilder';
import RepPortal from '@/pages/RepPortal';
import RepLogin from '@/pages/RepLogin';
import RepInvite from '@/pages/RepInvite';
import RepPortalEntry from '@/components/rep/RepPortalEntry';
import RepPortalLayout from '@/components/rep/RepPortalLayout';
import SalesDashboard from '@/pages/SalesDashboard';
import SalesCommandCenter from '@/pages/SalesCommandCenter';
import VoiceIntelligence from '@/pages/VoiceIntelligence';
import OmniCoreBrain from '@/pages/OmniCoreBrain';
import SecurityAgent from '@/pages/SecurityAgent';
import VideoProductionAgent from '@/pages/VideoProductionAgent';
import AxisMeet from '@/pages/AxisMeet';
import MeetRoom from '@/pages/MeetRoom';
import GuestLobby from '@/pages/GuestLobby';
import Careers from '@/pages/Careers';
import PartnerDashboard from '@/pages/PartnerDashboard';
import TwilioVerification from '@/pages/TwilioVerification';
import SystemStressTest from '@/pages/SystemStressTest';
import HrInvite from '@/pages/HrInvite';
import LiveDemo from '@/pages/LiveDemo';
import WebmailRedirect from '@/components/email/WebmailRedirect';
import Inventory from '@/pages/Inventory';
import Logistics from '@/pages/Logistics';
import LandingPageBuilder from '@/pages/LandingPageBuilder';
import Storefront from '@/pages/Storefront';
import CustomerPortal from '@/pages/CustomerPortal';
import PublicLandingPage from '@/pages/PublicLandingPage';
import NativeCalendar from '@/pages/NativeCalendar';
import NativeFileManager from '@/pages/NativeFileManager';
import NativeEmailCampaigns from '@/pages/NativeEmailCampaigns';
import VerifyAccount from '@/pages/VerifyAccount';
import BusinessKnowledgeGraph from '@/pages/BusinessKnowledgeGraph';
import OrganizationalMemory from '@/pages/OrganizationalMemory';
import DigitalBusinessTwin from '@/pages/DigitalBusinessTwin';
import DecisionSimulator from '@/pages/DecisionSimulator';
import AutonomousConsultant from '@/pages/AutonomousConsultant';
import IncidentCommandCenter from '@/pages/IncidentCommandCenter';
import CompanyKnowledgeCenter from '@/pages/CompanyKnowledgeCenter';
import BusinessVersionControl from '@/pages/BusinessVersionControl';
import RevenueIntelligence from '@/pages/RevenueIntelligence';
import CustomerIntelligence from '@/pages/CustomerIntelligence';
import WorkforceIntelligence from '@/pages/WorkforceIntelligence';
import NaturalLanguageAutomation from '@/pages/NaturalLanguageAutomation';
import ExecutiveCommandCenter from '@/pages/ExecutiveCommandCenter';
import BusinessHealthScorePage from '@/pages/BusinessHealthScore';
import ContinuousEvolution from '@/pages/ContinuousEvolution';
import OmniCoreOptimization from '@/pages/OmniCoreOptimization';
import GlobalErrorHandler from '@/components/system/GlobalErrorHandler';
import CSDashboard from '@/pages/CSDashboard';




import { base44 } from '@/api/base44Client';

const DefaultUnauthenticated = () => {
  useEffect(() => {
    base44.auth.redirectToLogin(window.location.pathname + window.location.search);
  }, []);
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-background">
      <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin"></div>
    </div>
  );
};


function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <GlobalErrorHandler />
          <Routes>
            {/* Public routes - no auth required */}
            {/* AXIS Meet — public guest lobby (no auth) */}
            <Route path="/meet/:meetingId" element={<GuestLobby />} />
            <Route path="/hr-invite" element={<HrInvite />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/live-demo" element={<LiveDemo />} />
            <Route path="/bc5f04c462c1a72bfc63806a491d1e83.html" element={<TwilioVerification />} />
            <Route path="/" element={<LandingPage />} />
            <Route path="/verify-account" element={<VerifyAccount />} />
            <Route path="/trial-signup" element={<TrialSignup />} />
            <Route path="/pricing" element={<PricingCheckout />} />
            <Route path="/checkout-confirmation" element={<CheckoutConfirmation />} />
            <Route path="/movement" element={<MovementSignup />} />
            <Route path="/rep-login" element={<RepLogin />} />
            <Route path="/rep-invite" element={<RepInvite />} />

            {/* Rep Portal — dedicated auth gate with branded login wall */}
            <Route path="/rep-portal" element={<RepPortalEntry />}>
              <Route element={<RepPortalLayout />}>
                <Route index element={<RepPortal />} />
              </Route>
            </Route>
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            {/* Public storefront & landing pages */}
            <Route path="/portal/:token" element={<CustomerPortal />} />
            <Route path="/:slug/:pageName" element={<PublicLandingPage />} />
            <Route path="/:slug" element={<Storefront />} />
            {/* Authenticated app routes - protected by login requirement */}
            <Route element={<ProtectedRoute unauthenticatedElement={<DefaultUnauthenticated />} />}>
              <Route element={<AppLayout />}>
                <Route path="/app" element={<Dashboard />} />
                <Route path="/leads" element={<Leads />} />
                <Route path="/import" element={<ImportCSV />} />
                <Route path="/import-wizard" element={<ImportWizard />} />
                <Route path="/universal-import" element={<UniversalImport />} />
                <Route path="/call-bot" element={<CallBot />} />
                <Route path="/call-logs" element={<CallLogs />} />
                <Route path="/appointments" element={<Appointments />} />
                <Route path="/dnc" element={<DNCRegistry />} />
                <Route path="/compliance" element={<Compliance />} />
                <Route path="/tasks" element={<FollowUpTasks />} />
                <Route path="/nurture" element={<NurtureWorkflows />} />
                <Route path="/lead-scoring" element={<LeadScoring />} />
                <Route path="/coaching" element={<CoachingHub />} />
                <Route path="/lead-routing" element={<LeadRouting />} />
                <Route path="/coaching-report" element={<CallCoachingReport />} />
                <Route path="/sales-command" element={<SalesCommandCenter />} />
                <Route path="/call-calendar" element={<CallCalendar />} />
                <Route path="/compliance-export" element={<ComplianceExport />} />
                <Route path="/my-team" element={<MyTeam />} />
                <Route path="/lead-generator" element={<LeadGenerator />} />
                <Route path="/facebook-leads" element={<FacebookLeads />} />
                <Route path="/sales-team" element={<SalesTeam />} />
                <Route path="/recruitment" element={<Recruitment />} />
                <Route path="/admin" element={<SuperAdmin />} />
                <Route path="/admin/subscribers" element={<SubscribersOverview />} />
                <Route path="/admin/trials" element={<TrialInvites />} />
                <Route path="/admin/users" element={<UserManagement />} />
                <Route path="/admin/console" element={<AdminConsole />} />
                <Route path="/admin/settings" element={<AdminSettings />} />
                <Route path="/admin/custom-pricing" element={<CustomPricing />} />
                <Route path="/admin/revenue" element={<RevenueAdmin />} />
                <Route path="/admin/white-label" element={<WhiteLabel />} />
                <Route path="/admin/subscription-manager" element={<SubscriptionManager />} />
                <Route path="/learning" element={<Navigate to="/academy" replace />} />
            <Route path="/LearningHub" element={<Navigate to="/academy" replace />} />
                <Route path="/ae-onboarding" element={<AEOnboarding />} />
                <Route path="/email" element={<Email />} />
            <Route path="/webmail" element={<WebmailRedirect />} />
            <Route path="/webmail/" element={<WebmailRedirect />} />
                <Route path="/ae-chat" element={<AEChat />} />
                <Route path="/subscription" element={<SubscriptionManagement />} />
                <Route path="/social-media" element={<SocialMedia />} />
                <Route path="/hr" element={<HumanResources />} />
                <Route path="/hr-analytics" element={<HrAnalytics />} />
                <Route path="/sms" element={<SmsInbox />} />
                <Route path="/api-center" element={<ApiCenter />} />
                <Route path="/agent-tasks" element={<AgentTasks />} />
                <Route path="/my-settings" element={<UserSettings />} />
                <Route path="/demo" element={<DemoMode />} />
                <Route path="/academy" element={<Academy />} />
                <Route path="/corporate" element={<CorporateCommand />} />
                <Route path="/financial-ops" element={<FinancialOps />} />
                <Route path="/finance-overview" element={<FinanceOverview />} />
                <Route path="/finance-analytics" element={<FinanceAnalytics />} />
                <Route path="/system-topology" element={<SystemTopology />} />
                <Route path="/video-marketing" element={<VideoMarketing />} />
                <Route path="/omnichannel" element={<OmniChannel />} />
                <Route path="/digital-employees" element={<DigitalEmployees />} />
                <Route path="/ai-agents" element={<AIAgentsCommand />} />
                <Route path="/llm-engine" element={<LLMOrchestration />} />
                <Route path="/governance" element={<GovernanceCore />} />
                <Route path="/agentic-crm" element={<AxisAgenticCRM />} />
                <Route path="/autonomous-scheduler" element={<AutonomousScheduler />} />
                <Route path="/global-workforce" element={<GlobalWorkforce />} />
                <Route path="/document-intelligence" element={<DocumentIntelligence />} />
                <Route path="/production-validation" element={<ProductionValidation />} />
                <Route path="/engagement-hub" element={<EngagementHub />} />
                <Route path="/deployment-status" element={<DeploymentStatus />} />
                <Route path="/industry-onboarding" element={<IndustryOnboarding />} />
                <Route path="/dashboards" element={<RealtimeDashboards />} />
                <Route path="/settings" element={<Settings />} />
                <Route path="/revenue-ops" element={<RevenueOperations />} />
                <Route path="/workflow-orchestration" element={<WorkflowOrchestration />} />
                <Route path="/production-fulfillment" element={<ProductionFulfillment />} />
                <Route path="/operations-dashboard" element={<OperationsDashboard />} />
                <Route path="/inventory-analytics" element={<InventoryAnalytics />} />
                <Route path="/logistics-analytics" element={<LogisticsAnalytics />} />
                <Route path="/production-analytics" element={<ProductionAnalytics />} />
                <Route path="/cross-department-sync" element={<CrossDepartmentSync />} />
                <Route path="/operational-ai" element={<UniversalOperationalAI />} />
                <Route path="/integrations" element={<IntegrationMarketplace />} />
                <Route path="/system-audit" element={<SystemAuditReport />} />
                <Route path="/setup-wizard" element={<SetupWizard />} />
                <Route path="/admin/remote-access" element={<RemoteAccess />} />
                <Route path="/admin/security-vault" element={<SecurityVault />} />
                <Route path="/quick-integrations" element={<QuickIntegrations />} />
                <Route path="/ai-features" element={<AIFeatures />} />
                <Route path="/quote-builder" element={<QuoteBuilder />} />
                <Route path="/sales-dashboard" element={<SalesDashboard />} />
                <Route path="/voice-intelligence" element={<VoiceIntelligence />} />
                <Route path="/omnicore-brain" element={<OmniCoreBrain />} />
                <Route path="/security-agent" element={<SecurityAgent />} />
                <Route path="/video-production-agent" element={<VideoProductionAgent />} />
                <Route path="/axis-meet" element={<AxisMeet />} />
                <Route path="/zoom-scheduler" element={<Navigate to="/axis-meet" replace />} />
                <Route path="/meet/room/:meetingId" element={<MeetRoom />} />
                <Route path="/partner-dashboard" element={<PartnerDashboard />} />
                <Route path="/stress-test" element={<SystemStressTest />} />
                <Route path="/inventory" element={<Inventory />} />
                <Route path="/logistics" element={<Logistics />} />
                <Route path="/page-builder" element={<LandingPageBuilder />} />
                <Route path="/calendar" element={<NativeCalendar />} />
                <Route path="/files" element={<NativeFileManager />} />
                <Route path="/email-campaigns" element={<NativeEmailCampaigns />} />
                <Route path="/nexus/knowledge-graph" element={<BusinessKnowledgeGraph />} />
                <Route path="/nexus/memory" element={<OrganizationalMemory />} />
                <Route path="/nexus/twin" element={<DigitalBusinessTwin />} />
                <Route path="/nexus/simulator" element={<DecisionSimulator />} />
                <Route path="/nexus/consultant" element={<AutonomousConsultant />} />
                <Route path="/nexus/incidents" element={<IncidentCommandCenter />} />
                <Route path="/nexus/knowledge" element={<CompanyKnowledgeCenter />} />
                <Route path="/nexus/versions" element={<BusinessVersionControl />} />
                <Route path="/nexus/revenue" element={<RevenueIntelligence />} />
                <Route path="/nexus/customers" element={<CustomerIntelligence />} />
                <Route path="/nexus/workforce" element={<WorkforceIntelligence />} />
                <Route path="/nexus/automation" element={<NaturalLanguageAutomation />} />
                <Route path="/nexus/executive" element={<ExecutiveCommandCenter />} />
                <Route path="/nexus/health" element={<BusinessHealthScorePage />} />
                <Route path="/nexus/evolution" element={<ContinuousEvolution />} />
                <Route path="/nexus/omnicore" element={<OmniCoreOptimization />} />
                <Route path="/cs-dashboard" element={<CSDashboard />} />
                </Route>
            </Route>
            
            {/* 404 for unmatched routes */}
            <Route path="*" element={<PageNotFound />} />
          </Routes>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App