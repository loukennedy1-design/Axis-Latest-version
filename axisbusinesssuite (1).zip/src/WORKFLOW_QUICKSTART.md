# Workflow Engine - Quick Start Guide

## 🚀 Get Started in 3 Minutes

### Step 1: Close a Deal
1. Navigate to your CRM
2. Move an opportunity to "Closed Won" stage
3. Ensure contract is signed

### Step 2: Trigger Workflow
**Option A - Automatic:**
- Workflow triggers automatically when contract is signed

**Option B - Manual:**
1. Go to `/workflow-orchestration`
2. Click "Trigger Workflow" tab
3. Select your closed opportunity
4. Click "Trigger Workflow" button

### Step 3: Watch the Magic Happen
The system automatically executes 9 steps:

1. ✅ **Generate Invoice** (2 seconds)
2. ✅ **Generate Order** (1 second)
3. ✅ **Create Production Tickets** (3 seconds)
4. ✅ **Create Fulfillment Tasks** (2 seconds)
5. ✅ **Update Accounting** (1 second)
6. ✅ **Update CRM** (1 second)
7. ✅ **Trigger Onboarding** (2 seconds)
8. ✅ **Notify Departments** (3 seconds)
9. ✅ **Update Dashboards** (1 second)

**Total Time: ~15 seconds** ⚡

### Step 4: Monitor Progress
1. **Active Workflows Tab**: See real-time execution
2. **Orders Tab**: Track order lifecycle
3. **Production Tab**: Monitor manufacturing
4. **Fulfillment Tab**: Watch shipping progress

---

## 💡 What Gets Created

### Invoice
- Invoice number: `INV-ACCOUNTNAME-2026-XXX`
- Line items from quote
- Net-30 payment terms
- Sent to customer email

### Order
- Order number: `ORD-ACCOUNTNAME-2026-XXX`
- Links to contract & opportunity
- Expected delivery date (30 days default)
- All status trackers initialized

### Production Tickets
- One ticket per line item
- Ticket numbers: `PROD-ORDERNUMBER-1`, `PROD-ORDERNUMBER-2`, etc.
- Priority: Medium (default)
- Due date: Order expected delivery

### Fulfillment Tasks
- **Picking Task**: `FUL-ORDERNUMBER-PICK`
- **Packing Task**: `FUL-ORDERNUMBER-PACK`
- **Shipping Task**: `FUL-ORDERNUMBER-SHIP`
- Sequential dependencies

### Accounting Entries
- COGS entry (30% of order value)
- Revenue recognition record
- Linked to invoice

### CRM Updates
- Opportunity → Closed Won
- Contract → Active
- Account Agent → Retention stage

### Onboarding
- Welcome email scheduled
- Kickoff call within 3 days
- CSM assigned
- Onboarding status → In Progress

### Department Notifications
- Sales: Deal closed alert
- Production: New order alert
- Fulfillment: Tasks assigned alert
- Customer Success: Onboarding alert
- Finance: Invoice sent alert

---

## 📊 Dashboard Navigation

### KPI Cards (Top)
- **Total Orders**: Count of all orders
- **Revenue**: Total order value
- **Active Workflows**: Currently running
- **Completed**: Successfully finished
- **In Production**: Manufacturing now
- **Pending Fulfillment**: Awaiting shipment

### Tabs

**Active Workflows**
- See all workflow executions
- Real-time progress bars
- Current step display
- Status: Running/Completed/Failed

**Orders**
- Complete order table
- Filter by status
- Track production & fulfillment
- Monitor onboarding progress

**Production**
- All production tickets
- Status by ticket
- Due date tracking
- Priority indicators

**Fulfillment**
- Task list by type
- Tracking numbers
- Carrier info
- Delivery status

**Trigger Workflow**
- Manual execution
- Closed opportunities list
- One-click trigger
- Real-time feedback

---

## 🎯 Common Scenarios

### Scenario 1: New Deal Closed
**Action:**
1. Mark opportunity as "Closed Won"
2. Workflow triggers automatically
3. All 9 steps execute
4. Departments notified
5. Production begins

**Result:** Order created, invoice sent, production started

### Scenario 2: Manual Trigger
**When:** Automatic trigger failed or missed

**Action:**
1. Go to Workflow Dashboard
2. "Trigger Workflow" tab
3. Select opportunity
4. Click trigger button

**Result:** Same as automatic trigger

### Scenario 3: Workflow Failure
**When:** A step fails (e.g., missing data)

**Action:**
1. Check "Active Workflows" tab
2. See failed step and error message
3. Fix underlying issue
4. Re-trigger workflow

**Result:** Workflow retries from failed step

### Scenario 4: Monitor Order
**When:** Customer asks for status

**Action:**
1. Go to "Orders" tab
2. Find order by number or customer
3. Check production status
4. Check fulfillment status
5. Provide update

**Result:** Complete order visibility

---

## ⚠️ Important Notes

### Data Requirements
For workflow to execute successfully, ensure:
- ✅ Opportunity has account name
- ✅ Opportunity has amount
- ✅ Contract exists (for contract-based triggers)
- ✅ Quote exists with line items (optional but recommended)
- ✅ Customer email is valid

### Workflow Timing
- **Execution Time:** ~15 seconds total
- **Step Timeout:** 30 seconds per step
- **Retry Logic:** 3 attempts per step
- **Failure Handling:** Stops at failed step

### Department Notifications
- Notifications sent via Slack (if configured)
- Email backups always sent
- Notification log in workflow record
- Can be re-sent if needed

### Production Tickets
- Default priority: Medium
- Default estimated hours: 8
- Can be customized per product type
- Quality check required before completion

### Fulfillment Tasks
- Sequential execution (Picking → Packing → Shipping)
- Each task must be completed before next
- Tracking numbers added at shipping stage
- Delivery confirmation closes loop

---

## 🔧 Troubleshooting

**Workflow won't trigger?**
- Check opportunity has contract
- Verify contract exists
- Ensure user has permissions
- Check backend function is deployed

**Step fails?**
- Review error message in workflow record
- Check required data exists
- Verify integrations are configured
- Retry after fixing issue

**Notifications not sent?**
- Check Slack integration
- Verify email configuration
- Review notification log
- Re-send manually if needed

**Production tickets missing?**
- Check order has line items
- Verify product names
- Review ticket creation logic
- Re-run step manually

---

## 📞 Need Help?

- **Full Documentation:** See `WORKFLOW_ORCHESTRATION.md`
- **Video Tutorials:** Coming soon
- **Support:** support@axisbusiness.com
- **Status:** `/deployment-status`

---

**Ready to automate your entire sales-to-operations lifecycle? Let's go! 🚀**