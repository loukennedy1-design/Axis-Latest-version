import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Trophy, ChevronDown, ChevronUp, Mic, AlertCircle,
  Lightbulb, CheckCircle2, Users, Building2, FileText,
  Target, UserPlus, Clock, Zap, Star, ArrowRight, BookOpen,
  Flame, Brain, Shield, DollarSign, TrendingUp, MessageSquare
} from 'lucide-react';

// ─── Reusable block components ────────────────────────────────────────────────

function TrainerScript({ children }) {
  return (
    <div className="my-3 border-l-4 border-primary pl-4 py-1 bg-primary/5 rounded-r-lg">
      <p className="text-[10px] font-bold uppercase tracking-widest text-primary mb-1 flex items-center gap-1"><Mic className="w-3 h-3" />Trainer Script</p>
      <p className="text-sm leading-relaxed italic text-foreground">{children}</p>
    </div>
  );
}

function WhoWhatWhy({ who, what, why }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 my-4">
      <div className="rounded-xl border border-blue-500/30 bg-blue-500/5 p-3">
        <p className="text-[10px] font-bold uppercase tracking-widest text-blue-600 mb-2">👤 WHO</p>
        <ul className="space-y-1">{who.map((w, i) => <li key={i} className="text-xs text-foreground flex items-start gap-1.5"><CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0 mt-0.5" />{w}</li>)}</ul>
      </div>
      <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-3">
        <p className="text-[10px] font-bold uppercase tracking-widest text-purple-600 mb-2">⚙️ WHAT</p>
        <ul className="space-y-1">{what.map((w, i) => <li key={i} className="text-xs text-foreground flex items-start gap-1.5"><CheckCircle2 className="w-3 h-3 text-purple-500 shrink-0 mt-0.5" />{w}</li>)}</ul>
      </div>
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
        <p className="text-[10px] font-bold uppercase tracking-widest text-amber-600 mb-2">🎯 WHY</p>
        <ul className="space-y-1">{why.map((w, i) => <li key={i} className="text-xs text-foreground flex items-start gap-1.5"><CheckCircle2 className="w-3 h-3 text-amber-500 shrink-0 mt-0.5" />{w}</li>)}</ul>
      </div>
    </div>
  );
}

function TimeBlock({ time, label, children }) {
  return (
    <div className="flex gap-4 py-4 border-b border-border last:border-0">
      <div className="text-right shrink-0 w-20">
        <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-md">{time}</span>
      </div>
      <div className="flex-1 space-y-2">
        <p className="font-semibold text-sm">{label}</p>
        {children}
      </div>
    </div>
  );
}

function VerbalTest({ question, answer, correction }) {
  const [show, setShow] = useState(false);
  return (
    <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-4 my-3">
      <div className="flex items-start gap-2 mb-3">
        <Brain className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-emerald-600 mb-1">Verbal Test</p>
          <p className="text-sm font-semibold">👉 "{question}"</p>
        </div>
      </div>
      <Button size="sm" variant="outline" onClick={() => setShow(s => !s)} className="text-xs">
        {show ? 'Hide Answer' : 'Reveal Correct Answer'}
      </Button>
      {show && (
        <div className="mt-3 space-y-2">
          <div className="rounded-lg bg-emerald-600 text-white p-3 text-sm">
            <p className="font-bold text-xs mb-1">✔ CORRECT ANSWER:</p>
            <p>"{answer}"</p>
          </div>
          {correction && (
            <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-3 text-xs text-red-700">
              <p className="font-bold mb-1 flex items-center gap-1"><AlertCircle className="w-3 h-3" />If they answer wrong, say:</p>
              <p className="italic">"{correction}"</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Drill({ scenario, response }) {
  return (
    <div className="rounded-xl border border-purple-500/30 bg-purple-500/5 p-4 my-3">
      <p className="text-[10px] font-bold uppercase tracking-widest text-purple-600 mb-2">🧪 Live Drill</p>
      <div className="space-y-2">
        <div className="bg-background border rounded-lg p-2.5">
          <p className="text-[10px] font-bold text-muted-foreground uppercase mb-1">Scenario</p>
          <p className="text-sm">{scenario}</p>
        </div>
        <ArrowRight className="w-4 h-4 text-muted-foreground mx-auto" />
        <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-2.5">
          <p className="text-[10px] font-bold text-emerald-600 uppercase mb-1">Correct Response</p>
          <p className="text-sm italic">"{response}"</p>
        </div>
      </div>
    </div>
  );
}

function CorrectionLine({ trigger, response }) {
  return (
    <div className="rounded-lg border border-red-500/20 bg-red-500/5 p-3 my-2">
      <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-1">⚠️ Correction</p>
      <p className="text-xs text-muted-foreground mb-1">If they say: <span className="italic font-medium text-foreground">"{trigger}"</span></p>
      <p className="text-xs text-red-700 font-medium">Respond: <span className="italic">"{response}"</span></p>
    </div>
  );
}

function Example({ text }) {
  return (
    <div className="rounded-lg bg-slate-900 text-amber-300 p-3 my-2 font-mono text-xs leading-relaxed">
      <p className="text-slate-400 text-[10px] mb-1 font-sans uppercase tracking-widest">Real-World Example</p>
      {text}
    </div>
  );
}

// ─── Day Content ──────────────────────────────────────────────────────────────

const DAYS = [
  { day: 1, title: 'What A Business Really Is', subtitle: 'Structure Before Action', icon: Building2, color: 'bg-blue-500/10 text-blue-700 border-blue-500/30', goal: 'They understand that business = structured system, not income or effort.' },
  { day: 2, title: 'LLC + EIN + Business Identity', subtitle: 'Legal Foundation', icon: Shield, color: 'bg-purple-500/10 text-purple-700 border-purple-500/30', goal: 'They understand legal separation + identity of business.' },
  { day: 3, title: '1099 Contractor System', subtitle: 'AE Structure & Classification', icon: FileText, color: 'bg-amber-500/10 text-amber-700 border-amber-500/30', goal: 'They understand AE structure and legal classification.' },
  { day: 4, title: 'Recruiting System', subtitle: 'Indeed Filter Engine', icon: UserPlus, color: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/30', goal: 'Volume recruiting + mindset filtering.' },
  { day: 5, title: 'Interview System', subtitle: 'Pressure Filtering', icon: Brain, color: 'bg-red-500/10 text-red-700 border-red-500/30', goal: 'Identify performance mindset under pressure.' },
  { day: 6, title: 'Onboarding & Field Training', subtitle: 'From Contract to First Sale', icon: Star, color: 'bg-cyan-500/10 text-cyan-700 border-cyan-500/30', goal: 'Get AEs from signed to producing in 48 hours.' },
  { day: 7, title: 'Territory Management', subtitle: 'Owning Your Zone', icon: Target, color: 'bg-indigo-500/10 text-indigo-700 border-indigo-500/30', goal: 'They understand how to systematically work a geographic market.' },
  { day: 8, title: 'Revenue Tracking & KPIs', subtitle: 'Numbers That Drive Behavior', icon: DollarSign, color: 'bg-green-500/10 text-green-700 border-green-500/30', goal: 'They can track, read, and act on daily performance data.' },
  { day: 9, title: 'Scaling the Territory', subtitle: 'Duplication Without Chaos', icon: TrendingUp, color: 'bg-orange-500/10 text-orange-700 border-orange-500/30', goal: 'They understand how to grow without losing system integrity.' },
  { day: 10, title: 'Territory Owner Certification', subtitle: 'Final Exam & Graduation', icon: Trophy, color: 'bg-yellow-500/10 text-yellow-700 border-yellow-500/30', goal: 'Full verbal and practical certification of all 10 days.' },
];

function Day1Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Anyone building a territory', 'Anyone hiring AEs', 'Future leaders in the system']}
        what={['A business is a system with: Legal structure (LLC), Financial flow (banking), People (AEs), Execution (field activity)']}
        why={['Without structure: money becomes random', 'People become inconsistent', 'Scaling becomes impossible']}
      />
      <TimeBlock time="0–10 min" label="Opening Installation">
        <TrainerScript>
          "Most people think business starts with money. That's why most people fail."
          {"\n\n"}"Business does NOT start with money. It starts with structure."
          {"\n\n"}[Pause.]
          {"\n\n"}"If you don't understand structure, everything you build becomes unstable under pressure."
        </TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="Structure vs. Money">
        <TrainerScript>"Money is not the business. It is the result of the business working correctly. Income is the output. Structure is the input system."</TrainerScript>
        <Example text={`"If you hire 5 AEs into confusion, you don't get growth —\nyou get 5 versions of confusion."`} />
        <Drill scenario="Ask the room: 'What is a business in one sentence?'" response="A structured system that produces predictable outcomes." />
        <VerbalTest question="What is a business in one sentence?" answer="A structured system that produces predictable outcomes." correction="No. Income is a result. Structure is the cause. A business is the system, not the money it makes." />
      </TimeBlock>
      <TimeBlock time="25–40 min" label="Why Structure Comes First">
        <TrainerScript>"Hiring does not fix structure. Hiring multiplies structure. If the structure is broken, every new hire amplifies the breakdown."</TrainerScript>
        <CorrectionLine trigger="hire to grow" response="No — structure grows. Hiring only scales what already exists. If chaos exists, hiring creates more chaos." />
        <div className="rounded-xl border p-3 my-2 space-y-2">
          <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Structure First → Then People</p>
          <div className="flex items-center gap-2 flex-wrap text-sm">
            {['Define the System', 'Build Legal Foundation', 'Set Money Flow', 'THEN Hire AEs'].map((s, i, arr) => (
              <React.Fragment key={s}>
                <span className="px-3 py-1.5 bg-primary/10 text-primary rounded-lg font-medium">{s}</span>
                {i < arr.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground" />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Verbal Test + Recap">
        <VerbalTest question="Why does structure come before people?" answer="Because systems determine behavior, and people amplify systems." correction="People don't create the system — they operate inside it. If there's no system, there's nothing to amplify except confusion." />
        <TrainerScript>"Write this down: Structure is the business. Everything else is what happens inside it."</TrainerScript>
      </TimeBlock>
    </div>
  );
}

function Day2Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Business owner', 'Territory operator', 'Anyone managing contractors']}
        what={['LLC = legal separation between you and your business activity', 'EIN = business identity number for government', 'Bank account = money control system']}
        why={['Without this: you are personally liable for field issues', 'No valid contractor structure', 'Scaling creates personal legal risk']}
      />
      <TimeBlock time="0–10 min" label="Opening">
        <TrainerScript>"Before you hire anyone, you must legally exist as a system. You cannot build a crew on a person. You must build it on an entity."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="LLC Deep Explanation">
        <TrainerScript>"An LLC is a wall. On one side is you personally. On the other side is your business activity. That wall is why you sleep at night."</TrainerScript>
        <Example text={`Without LLC: Customer sues → they sue YOU personally\nWith LLC: Customer sues → they sue the BUSINESS\nYour home, car, personal accounts — protected.`} />
        <div className="grid grid-cols-2 gap-3 my-3">
          {[
            { label: 'Without LLC', items: ['Personal liability for lawsuits', 'No contractor framework', 'No business credit history', 'Tax as individual only'], bad: true },
            { label: 'With LLC', items: ['Business absorbs liability', 'Legal contractor structure', 'Build business credit', 'Multiple tax advantages'], bad: false },
          ].map(col => (
            <div key={col.label} className={`rounded-xl border p-3 ${col.bad ? 'border-red-500/30 bg-red-500/5' : 'border-emerald-500/30 bg-emerald-500/5'}`}>
              <p className={`text-xs font-bold uppercase tracking-widest mb-2 ${col.bad ? 'text-red-600' : 'text-emerald-600'}`}>{col.bad ? '❌' : '✅'} {col.label}</p>
              {col.items.map(i => <p key={i} className="text-xs text-muted-foreground mb-1">{i}</p>)}
            </div>
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="EIN Explanation">
        <TrainerScript>"The EIN is your business's Social Security Number. The government, banks, and contractors all use it to identify your business as a separate entity."</TrainerScript>
        <VerbalTest question="What does an EIN do?" answer="It identifies the business for taxes, banking, and hiring." correction="It's not just for taxes. It's the identity of the business in every legal and financial context." />
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Money Flow Structure">
        <p className="text-sm text-muted-foreground mb-3">Draw this on a whiteboard. Walk through each arrow.</p>
        <div className="flex items-center gap-2 flex-wrap my-3">
          {['Client Pays', 'Business Bank Account', 'Operating Costs', 'AE Commissions', 'Owner Draw'].map((s, i, arr) => (
            <React.Fragment key={s}>
              <span className="px-3 py-2 bg-primary/10 text-primary border border-primary/30 rounded-lg text-sm font-medium">{s}</span>
              {i < arr.length - 1 && <ArrowRight className="w-4 h-4 text-muted-foreground" />}
            </React.Fragment>
          ))}
        </div>
        <CorrectionLine trigger="I can just use my personal account" response="If money is not separated, you lose control of performance, taxes become a nightmare, and you have no legal separation. This is non-negotiable." />
        <VerbalTest question="Why does money go to the business account first?" answer="Because the business operates independently of the owner. The system controls the money, not the person." correction="If you personally touch the money first, you've broken the separation. The LLC only works if you operate through it, not around it." />
      </TimeBlock>
    </div>
  );
}

function Day3Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['AEs — Account Executives', 'Field reps and door-knockers', 'Any contractor in your system']}
        what={['1099 = independent contractor', 'Paid for results, not time', 'No benefits, no hourly rate, no schedule control']}
        why={['Scalable workforce without payroll overhead', 'Performance-based culture by design', 'No hourly dependency — only results matter']}
      />
      <TimeBlock time="0–10 min" label="Opening">
        <TrainerScript>"We don't hire employees. We contract outcomes. There's a massive legal and cultural difference — and you need to understand both."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="Employee vs. Contractor">
        <div className="grid grid-cols-2 gap-3 my-3 text-xs">
          <div className="rounded-xl border border-red-500/30 bg-red-500/5 p-3">
            <p className="font-bold text-red-600 uppercase tracking-widest text-[10px] mb-2">❌ W-2 Employee</p>
            {['Time-based pay', 'You control their hours', 'You control their methods', 'Benefits required', 'Payroll taxes on you', 'Risk = high if they don\'t perform'].map(i => <p key={i} className="text-muted-foreground mb-1">• {i}</p>)}
          </div>
          <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3">
            <p className="font-bold text-emerald-600 uppercase tracking-widest text-[10px] mb-2">✅ 1099 Contractor</p>
            {['Result-based pay', 'They control their own hours', 'They control their methods', 'No benefits owed', 'They pay their own taxes', 'Risk = zero if no production'].map(i => <p key={i} className="text-muted-foreground mb-1">• {i}</p>)}
          </div>
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="The Legal Rule You Must Know">
        <TrainerScript>"You control the OUTCOME — what they produce. You do NOT control the hours, the schedule, or the method. The moment you start controlling those three things, you've created an employee relationship legally."</TrainerScript>
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 my-3">
          <p className="text-xs font-bold text-amber-600 uppercase tracking-widest mb-3">You CAN Control</p>
          <div className="flex gap-2 flex-wrap mb-4">{['The outcome / deliverable', 'Quality standards', 'Geographic territory', 'Commission structure'].map(i => <span key={i} className="px-2 py-1 bg-emerald-500/10 text-emerald-700 border border-emerald-500/30 rounded text-xs">{i}</span>)}</div>
          <p className="text-xs font-bold text-red-500 uppercase tracking-widest mb-3">You CANNOT Control</p>
          <div className="flex gap-2 flex-wrap">{['Their working hours', 'Their daily schedule', 'Exactly how they do it', 'Tools they must use'].map(i => <span key={i} className="px-2 py-1 bg-red-500/10 text-red-700 border border-red-500/30 rounded text-xs">{i}</span>)}</div>
        </div>
        <VerbalTest question="What defines a 1099 contractor?" answer="Someone independent who is paid per result, not time. You control the outcome, not the method or schedule." correction="It's not just about taxes. It's about independence. If you're controlling their time and method, you've created an employee by law regardless of what you call them." />
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Live Drill — Handle the Ask">
        <Drill scenario="An AE says: 'Can I get paid hourly instead of commission?'" response="We only operate on performance-based compensation. Your income is unlimited here, but it's tied to results — not time. That's what makes this different." />
        <Drill scenario="An AE says: 'Can you tell me exactly when to work?'" response="You're an independent contractor — you control your schedule. We hold you accountable to outcomes, not hours. Results are what matters here." />
        <CorrectionLine trigger="Let me just pay them $15/hr to start" response="No. The moment you pay hourly, you've changed the legal and cultural relationship. This system only works on results. Start that way, stay that way." />
      </TimeBlock>
    </div>
  );
}

function Day4Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Territory Owners managing hiring', 'Recruiters posting on Indeed', 'Anyone building a rep pipeline']}
        what={['Recruiting = a filtering system, not a selection process', 'Volume reveals who\'s real', 'Speed controls the pipeline']}
        why={['Most applicants are unqualified — volume reveals the few who are', 'Speed filters out passive candidates', 'Mindset is the only real qualifier']}
      />
      <TimeBlock time="0–10 min" label="Opening Mindset Shift">
        <TrainerScript>"You don't find good people. You eliminate the wrong ones. Your job is not to pick — it's to filter. The faster you filter, the faster you find producers."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="Job Posting Strategy">
        <TrainerScript>"Your job posting is your first filter. If it's too easy, everyone applies. You want it to be slightly challenging so only motivated people respond."</TrainerScript>
        <div className="rounded-xl border bg-slate-900 text-white p-4 my-3 font-mono text-xs leading-relaxed">
          <p className="text-slate-400 mb-2 font-sans text-[10px] uppercase tracking-widest">High-Filter Job Post Framework</p>
          <p className="text-emerald-300">TITLE: Territory Sales Rep — Commission Only | Unlimited Earning Potential</p>
          <p className="text-slate-300 mt-2">We are expanding in [City] and looking for hungry, self-motivated reps ready to build something real. This is NOT for people who need a salary to feel secure.</p>
          <p className="text-amber-300 mt-2">• Commission-only (1099)</p>
          <p className="text-amber-300">• Full training provided</p>
          <p className="text-amber-300">• Top reps earn $5K–$15K/mo</p>
          <p className="text-slate-300 mt-2">If you need a base salary, this isn't for you. If you want control of your income, let's talk.</p>
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="Response System — Speed = Control">
        <TrainerScript>"Speed is not about being desperate. Speed is about controlling who you talk to first. The best candidates are talking to multiple people. You want to be first."</TrainerScript>
        <div className="flex items-center gap-2 flex-wrap my-3">
          {['Lead Applies', 'Respond Within 1 Hour', 'Schedule Same-Day Call', 'Complete Pressure Interview', 'Yes/No Decision Same Day'].map((s, i, arr) => (
            <React.Fragment key={s}>
              <span className="px-2 py-1.5 bg-emerald-500/10 text-emerald-700 border border-emerald-500/30 rounded text-xs font-medium">{s}</span>
              {i < arr.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground" />}
            </React.Fragment>
          ))}
        </div>
        <VerbalTest question="Why do we respond to candidates quickly?" answer="To control the pipeline and filter faster. The best candidates have options — speed puts us first." correction="It's not urgency. It's control. When you respond fast, you set the frame for the entire relationship." />
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Filter Drill — Who Moves Forward?">
        {[
          { type: 'STRONG ✅', profile: 'Responds within 30 min. Message is direct. Asks about income potential. No grammar issues. Tone is confident.', verdict: 'MOVE FORWARD — responsive, confident, income-focused.' },
          { type: 'WEAK ❌', profile: 'Responds 3 days later. Message says "whatever, I guess I can try." Asks if there\'s a guaranteed salary.', verdict: 'ELIMINATE — passive, uncertain, dependency mindset.' },
          { type: 'CONFUSED ⚠️', profile: 'Responds same day but message is all about their past troubles and needing a "fresh start." Emotional, not outcome-focused.', verdict: 'PASS — needs stability, not performance culture.' },
          { type: 'MOTIVATED ✅', profile: 'Responds in 2 hours. Says "I\'ve been looking for something like this. Commission only doesn\'t scare me — I believe in my work ethic."', verdict: 'MOVE FORWARD — owns their outcome, confidence without ego.' },
        ].map(c => (
          <div key={c.type} className="rounded-lg border p-3 mb-2">
            <p className="text-xs font-bold mb-1">{c.type}</p>
            <p className="text-xs text-muted-foreground mb-1">{c.profile}</p>
            <p className="text-xs font-semibold text-primary">Verdict: {c.verdict}</p>
          </div>
        ))}
      </TimeBlock>
    </div>
  );
}

function Day5Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Hiring managers conducting interviews', 'Territory Owners screening candidates', 'Anyone who makes yes/no hiring decisions']}
        what={['Behavioral evaluation under controlled pressure', 'Not a conversation — a performance test', 'The interview reveals who they are under stress']}
        why={['Resumes show history, not character', 'Words are easy to fake in a casual setting', 'Pressure reveals the real person you\'re hiring']}
      />
      <TimeBlock time="0–10 min" label="Opening — Reframe the Interview">
        <TrainerScript>"The interview is not a conversation. It is a pressure test. Your job is not to make them comfortable — it's to see who they are when they're slightly uncomfortable. Sales is uncomfortable. If they can't handle this, they can't handle the field."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="The 5-Step Interview Flow">
        <div className="space-y-2 my-3">
          {[
            { step: '1. Set Expectation', desc: '"This is going to be direct. I ask hard questions. That\'s how we find out if this is a fit."' },
            { step: '2. Explain the Role', desc: 'Commission only. Independent contractor. Territory-based. No salary. No excuses.' },
            { step: '3. Reverse Explanation', desc: '"Tell me what you understand about this role so far." — Forces them to prove they listened.' },
            { step: '4. Pressure Questions', desc: 'See below. These are designed to reveal mindset, not background.' },
            { step: '5. Close the Decision', desc: '"Based on everything you\'ve heard — are you in or out? I need an answer now."' },
          ].map(item => (
            <div key={item.step} className="flex gap-3 p-3 border rounded-lg">
              <span className="font-bold text-primary text-sm shrink-0 w-40">{item.step}</span>
              <p className="text-sm text-muted-foreground italic">{item.desc}</p>
            </div>
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="Pressure Questions — The Real Filter">
        {[
          { q: '"Tell me about a time you failed at something and what you actually did about it."', look: 'Accountability + learning. Red flag: blaming others.' },
          { q: '"If you don\'t make a sale in your first week, what happens to your mindset?"', look: 'Resilience. Red flag: "I\'d be worried" or "I\'d need support."' },
          { q: '"What does success look like to you in 90 days from today — specifically?"', look: 'Specific numbers and actions. Red flag: vague answers.' },
          { q: '"Why should I pick you over the 20 other people I\'m talking to this week?"', look: 'Confidence without arrogance. Red flag: panic or deflection.' },
          { q: '"This is commission only. No salary. No guaranteed income. Are you okay with that?"', look: 'Direct yes with calm energy. Red flag: hedging.' },
        ].map(item => (
          <div key={item.q} className="rounded-lg border p-3 mb-2">
            <p className="text-sm font-semibold italic mb-1">{item.q}</p>
            <p className="text-xs text-emerald-600">✅ Look for: {item.look}</p>
          </div>
        ))}
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Verbal Test + Drill">
        <VerbalTest question="What is the purpose of the pressure interview?" answer="To reveal who they actually are under stress, because sales is a high-pressure environment and the interview simulates it." correction="It's not about being mean. It's about being accurate. You need to know who you're putting in the field before they're in front of a customer." />
        <Drill scenario="Candidate says: 'I just need a chance, I promise I'll work hard.'" response="I believe you want to work hard. But 'hard work' is not a strategy. Tell me exactly what you'll do in your first 5 days." />
        <Drill scenario="Candidate says: 'I've never done door-to-door but I'm a quick learner.'" response="Good. What specifically makes you confident you can learn this fast? Give me a real example from your past." />
        <CorrectionLine trigger="I feel bad pushing them hard" response="You're not being cruel — you're being responsible. The field is harder than this interview. If they can't handle this, they can't handle rejection from strangers. Protect your time and theirs." />
      </TimeBlock>
    </div>
  );
}

function Day6Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['New AEs just contracted', 'Territory Owners onboarding their first hires', 'Training leads responsible for field readiness']}
        what={['Onboarding = the bridge from signed to producing', 'Field training = supervised execution with real feedback', 'First sale = proof of system, not luck']}
        why={['Most AEs fail in week 1 due to no structure in the handoff', 'Clear onboarding eliminates "what do I do?" confusion', 'Fast first sale builds identity as a producer']}
      />
      <TimeBlock time="0–10 min" label="Opening">
        <TrainerScript>"The contract doesn't make them an AE. The first sale makes them an AE. Your job in onboarding is to build a bridge from one to the other as fast as possible — ideally within 48 hours of signing."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="The 48-Hour Onboarding Sequence">
        <div className="space-y-2 my-3">
          {[
            { time: 'Hour 0', label: 'Sign the 1099 agreement. Review compensation structure. No ambiguity.' },
            { time: 'Hour 1–2', label: 'Product deep-dive. They must be able to explain the product in 2 sentences.' },
            { time: 'Hour 3–4', label: 'Script training. Memorize the opening, handle the 3 most common objections.' },
            { time: 'Hour 5–6', label: 'Role play drill — 20 reps minimum. You play the difficult customer.' },
            { time: 'Day 2', label: 'Shadow ride along with a senior rep or trainer. Observe 10 real doors.' },
            { time: 'Day 2 Afternoon', label: 'Supervised solo run — they knock, you observe from a distance.' },
            { time: '48 Hours', label: 'They attempt their first solo door. You debrief after every conversation.' },
          ].map(item => (
            <div key={item.time} className="flex gap-3 p-2.5 border rounded-lg items-start">
              <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded shrink-0">{item.time}</span>
              <p className="text-sm text-muted-foreground">{item.label}</p>
            </div>
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="The 2-Sentence Product Test">
        <TrainerScript>"Before they knock a single door, they must be able to pass this: explain the product in 2 sentences to a stranger. If they can't do it, they're not ready."</TrainerScript>
        <VerbalTest question="Explain the product in 2 sentences right now." answer="[Varies by product — but must include: what it does, who it's for, and why now]" correction="If they talk for 30 seconds and you're still not sure what the product is, they're not ready. Send them back to the materials. This is the standard." />
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Objection Training — The Core 3">
        {[
          { obj: '"I am not interested."', resp: '"Totally fair — most people aren\'t before they see the numbers. Can I take 60 seconds before you decide?"' },
          { obj: '"I already have someone for that."', resp: '"Perfect — that means you already see the value. When\'s your contract up? We can put you in a position to compare."' },
          { obj: '"I don\'t have time right now."', resp: '"Respect that completely. When\'s the best 5 minutes this week? I\'ll be specific."' },
        ].map(item => (
          <div key={item.obj} className="rounded-lg border p-3 mb-2">
            <p className="text-xs text-muted-foreground font-medium mb-1">Customer says: <span className="italic text-foreground">"{item.obj}"</span></p>
            <p className="text-xs text-emerald-700 font-medium">Rep responds: <span className="italic">"{item.resp}"</span></p>
          </div>
        ))}
        <Drill scenario="New AE freezes after 'I'm not interested.'" response="Pause. Smile. Say: 'Totally fair — most people aren't before they see the numbers. Can I take 60 seconds?' Then wait. Silence is your friend." />
      </TimeBlock>
    </div>
  );
}

function Day7Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Territory Owners managing a geographic zone', 'AEs working an assigned area', 'Anyone responsible for market penetration']}
        what={['Territory = a defined geographic system', 'Working a territory = systematic coverage, not random effort', 'Density beats distance every time']}
        why={['Random effort produces random results', 'Systematic coverage builds brand recognition in a zone', 'Dense canvassing creates social proof street by street']}
      />
      <TimeBlock time="0–10 min" label="Opening — Territory Is a System">
        <TrainerScript>"A territory is not just a zip code. It's a system you work in a specific order, at specific times, with specific density. The reps who treat it like a system own it. The ones who wander through it never do."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="Grid Strategy — How to Work a Territory">
        <div className="rounded-xl bg-slate-900 text-white p-4 my-3 font-mono text-xs">
          <p className="text-slate-400 mb-2 font-sans uppercase tracking-widest text-[10px]">Territory Grid Model</p>
          <div className="grid grid-cols-4 gap-1 text-center text-[10px]">
            {['Block A\n✅ Done', 'Block B\n🔄 Active', 'Block C\n⏳ Next', 'Block D\n⏳ Queued',
              'Block E\n✅ Done', 'Block F\n⏳ Queued', 'Block G\n⏳ Queued', 'Block H\n⏳ Queued'].map((b, i) => (
              <div key={i} className={`p-2 rounded border ${b.includes('✅') ? 'border-emerald-500/50 bg-emerald-900/30 text-emerald-300' : b.includes('🔄') ? 'border-blue-500/50 bg-blue-900/30 text-blue-300' : 'border-slate-600 bg-slate-800/50 text-slate-400'}`}>
                <p className="whitespace-pre-line">{b}</p>
              </div>
            ))}
          </div>
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="Time Blocking Your Territory Day">
        <div className="space-y-2">
          {[
            { time: '8:00–9:00am', activity: 'Admin — enter yesterday\'s data, plan today\'s route, set intent for the day' },
            { time: '9:00am–12:00pm', activity: 'Field Block 1 — first 3 hours of knocking (peak morning decision-maker time)' },
            { time: '12:00–1:00pm', activity: 'Lunch + follow-up calls on morning contacts' },
            { time: '1:00–5:00pm', activity: 'Field Block 2 — afternoon push (decision-makers back from lunch)' },
            { time: '5:00–6:00pm', activity: 'Post-field debrief — log outcomes, update CRM, set next-day plan' },
          ].map(item => (
            <div key={item.time} className="flex gap-3 items-center border rounded-lg p-2.5">
              <span className="text-xs font-bold text-primary w-28 shrink-0">{item.time}</span>
              <p className="text-xs text-muted-foreground">{item.activity}</p>
            </div>
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Verbal Test + Territory Ownership Drill">
        <VerbalTest question="What does it mean to 'own' a territory?" answer="To systematically cover every block with density, track every door, and build recognition so that when someone is ready to buy, your name is the one they know." correction="Owning a territory is not about showing up once. It's about being the name people think of in that zone because you've been there repeatedly and consistently." />
        <Drill scenario="AE says: 'I knocked 50 doors today in 6 different neighborhoods.'" response="That's not territory work — that's random activity. Pick one neighborhood. Knock every door. Come back three times. That's how you build density and reputation." />
      </TimeBlock>
    </div>
  );
}

function Day8Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Territory Owners tracking performance', 'AEs who need to understand their own numbers', 'Anyone managing a revenue-generating team']}
        what={['KPIs = Key Performance Indicators', 'The numbers that tell you whether the system is working', 'Leading indicators (activity) vs. lagging indicators (results)']}
        why={['You cannot improve what you don\'t measure', 'Without tracking, effort feels like progress even when it\'s not', 'Numbers remove emotion from performance conversations']}
      />
      <TimeBlock time="0–10 min" label="Opening — Numbers Are Not Optional">
        <TrainerScript>"Every great business runs on numbers. Not feelings. Not vibes. Not 'we've been working hard.' If you don't know your numbers right now, you're flying blind. And blind pilots crash."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="The Core KPI Stack">
        <div className="grid grid-cols-2 gap-3 my-3">
          {[
            { label: 'Doors Knocked / Calls Made', type: 'Leading', desc: 'Raw activity. Controls everything downstream.' },
            { label: 'Contact Rate %', type: 'Leading', desc: 'How many contacts per 10 knocks/calls?' },
            { label: 'Pitch Rate %', type: 'Leading', desc: 'Of contacts made, how many heard the pitch?' },
            { label: 'Conversion Rate %', type: 'Lagging', desc: 'Of pitches given, how many converted?' },
            { label: 'Average Sale Value ($)', type: 'Lagging', desc: 'Revenue per closed deal.' },
            { label: 'Revenue Per Day ($)', type: 'Lagging', desc: 'Total produced divided by working days.' },
          ].map(kpi => (
            <div key={kpi.label} className="rounded-lg border p-3">
              <div className="flex items-center justify-between mb-1">
                <p className="text-xs font-bold">{kpi.label}</p>
                <Badge className={kpi.type === 'Leading' ? 'bg-blue-500/10 text-blue-600 text-[10px]' : 'bg-amber-500/10 text-amber-600 text-[10px]'}>{kpi.type}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">{kpi.desc}</p>
            </div>
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="25–40 min" label="Daily Number Review Ritual">
        <TrainerScript>"Every morning, every AE should be able to answer three questions without hesitation. If they can't, they're not tracking. If they're not tracking, they're not managing their performance."</TrainerScript>
        <VerbalTest question="What were your numbers yesterday — doors, contacts, conversions?" answer="[Specific: '42 doors, 18 contacts, 3 conversions, $1,800 in revenue']" correction="'I worked hard' is not a number. 'I knocked a lot of doors' is not a number. You must be able to say the exact number or you haven't been tracking." />
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Reverse Engineer from Revenue Goal">
        <Example text={`GOAL: $5,000/week\nAverage sale value: $500 → Need 10 sales/week\nConversion rate: 20% → Need 50 pitches/week\nPitch rate: 50% → Need 100 contacts/week\nContact rate: 30% → Need 333 doors/week\n\n÷ 5 days = 67 doors per day\n\nNow you have a DAILY TARGET derived from your INCOME GOAL.`} />
        <Drill scenario="AE says: 'I want to make $10,000 this month.'" response="Great. Let's reverse engineer it. What's your average sale? What's your conversion rate? What's your contact rate per door? Give me those three numbers and I'll tell you exactly how many doors per day it takes." />
      </TimeBlock>
    </div>
  );
}

function Day9Content() {
  return (
    <div>
      <WhoWhatWhy
        who={['Territory Owners ready to grow beyond themselves', 'AEs being promoted to team leads', 'Anyone building a second layer of producers']}
        what={['Scaling = duplicating the system, not the person', 'The system must work without you before you add people to it', 'Duplication requires documentation + training + accountability']}
        why={['Without duplication, you have a job — not a business', 'Scaling a broken system creates bigger chaos', 'Every producer you add should increase output without increasing your direct effort']}
      />
      <TimeBlock time="0–10 min" label="Opening — You Are Not the Business">
        <TrainerScript>"If your territory only works when you're in it, you don't have a territory — you have a job. The goal of everything we've built is to create a system that runs itself. That only happens when the system is documented, trained, and accountable."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–25 min" label="The 3 Conditions for Safe Scaling">
        <div className="space-y-3 my-3">
          {[
            { num: '1', title: 'System Proof', desc: 'You must have at least one AE consistently producing before hiring more. If no one is producing consistently, the system isn\'t ready. More people just reveals the gap faster.' },
            { num: '2', title: 'Documented Process', desc: 'Every part of this Academy must be written down and teachable by someone who is not you. If only you can teach it, it dies when you leave the room.' },
            { num: '3', title: 'Accountability Loop', desc: 'Daily number review. Weekly performance check. Monthly KPI audit. Without these, scale creates chaos.' },
          ].map(item => (
            <div key={item.num} className="flex gap-4 p-3 border rounded-xl">
              <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm shrink-0">{item.num}</div>
              <div>
                <p className="font-semibold text-sm">{item.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
        <CorrectionLine trigger="Let's just hire more people to fix the problem" response="More people do not fix problems. They amplify whatever already exists. Fix the system first. Then hire into it." />
      </TimeBlock>
      <TimeBlock time="25–40 min" label="The Duplication Ladder">
        <div className="flex items-center gap-2 flex-wrap my-3">
          {['You produce', 'You train 1 AE', 'AE produces', 'AE trains next AE', 'You manage, not do', 'Territory scales'].map((s, i, arr) => (
            <React.Fragment key={s}>
              <span className="px-2 py-1.5 bg-primary/10 text-primary border border-primary/30 rounded text-xs font-medium">{s}</span>
              {i < arr.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground" />}
            </React.Fragment>
          ))}
        </div>
        <TrainerScript>"Your job changes at every rung of that ladder. At the bottom, you're a producer. At the top, you're a system operator. Most people never climb because they're too comfortable being the best producer instead of building producers."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="40–60 min" label="Verbal Test + Scenario Drill">
        <VerbalTest question="What must exist before you add your next AE?" answer="At least one AE producing consistently, a documented training system, and a daily accountability loop." correction="Hiring is not the answer to low production. Hiring is how you multiply existing production. If production doesn't exist, you're multiplying zero." />
        <Drill scenario="You have 3 AEs but none are hitting their numbers consistently. A friend asks: 'Should I hire 3 more reps to hit your goal?'" response="No. Adding reps right now would just give me 6 inconsistent producers instead of 3. First I need to fix why the 3 aren't producing. Then I can scale." />
      </TimeBlock>
    </div>
  );
}

function Day10Content() {
  return (
    <div>
      <div className="rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 text-white p-6 my-4 text-center">
        <Trophy className="w-12 h-12 mx-auto mb-3 opacity-90" />
        <h2 className="text-2xl font-black tracking-tight">Territory Owner Certification</h2>
        <p className="text-white/80 mt-1">10-Day Final Exam — All modules must be passed verbally</p>
      </div>
      <TimeBlock time="0–10 min" label="Opening — Certification Mindset">
        <TrainerScript>"Today is not a test of memory. It's a test of ownership. You either own this material or you don't. There's no partial credit in the field. Let's find out where you are."</TrainerScript>
      </TimeBlock>
      <TimeBlock time="10–50 min" label="Full Verbal Certification — All 10 Days">
        <div className="space-y-3">
          {[
            { day: 'Day 1', q: 'What is a business in one sentence?', a: 'A structured system that produces predictable outcomes.' },
            { day: 'Day 2', q: 'Why must money flow through the business account, not yours personally?', a: 'Because the business operates independently of the owner. Separation protects you legally and maintains system control.' },
            { day: 'Day 3', q: 'What are the three things you CANNOT control with a 1099 contractor?', a: 'Their working hours, their daily schedule, and their exact method of doing the work.' },
            { day: 'Day 4', q: 'What is recruiting, really?', a: 'A filtering system. You don\'t find good people — you eliminate the wrong ones fast through volume and speed.' },
            { day: 'Day 5', q: 'What is the interview actually testing?', a: 'Who they are under pressure, because sales is a high-pressure environment and the interview simulates it accurately.' },
            { day: 'Day 6', q: 'What happens in the first 48 hours of onboarding?', a: '1099 signed, product training, script memorization, role play, shadow ride-along, supervised solo, then first doors.' },
            { day: 'Day 7', q: 'What does it mean to own a territory?', a: 'Systematically covering every block with density, tracking every door, and building recognition so your name is known in that zone.' },
            { day: 'Day 8', q: 'What is the difference between a leading and lagging indicator? Give an example of each.', a: 'Leading: doors knocked (activity you control). Lagging: revenue generated (result of that activity). Fix leading indicators to fix lagging ones.' },
            { day: 'Day 9', q: 'What 3 conditions must exist before you scale your team?', a: 'At least one AE producing consistently, a documented and teachable training system, and a daily accountability loop.' },
            { day: 'Day 10', q: 'What is the Territory Owner\'s primary job once the system is built?', a: 'To manage the system — not to be the best producer in it. Your job becomes building producers, not being one.' },
          ].map(item => (
            <VerbalTest key={item.day} question={`[${item.day}] ${item.q}`} answer={item.a} correction="Incomplete. Study that day again tonight. You need to own this answer reflexively — not think your way to it." />
          ))}
        </div>
      </TimeBlock>
      <TimeBlock time="50–60 min" label="Certification & Commissioning">
        <TrainerScript>"If you passed that — you understand the foundation of a real business. But understanding is the beginning, not the end. The certificate means nothing in this room. It means everything in the field when you're under pressure and you make the right call because of what you learned here."</TrainerScript>
        <div className="rounded-xl border-2 border-amber-500/50 bg-amber-500/5 p-6 text-center my-4">
          <Trophy className="w-8 h-8 text-amber-600 mx-auto mb-2" />
          <p className="font-black text-xl text-amber-700">Territory Owner — Certified</p>
          <p className="text-sm text-muted-foreground mt-1">10 Days · 10 Hours · Foundation Complete</p>
          <div className="flex flex-wrap justify-center gap-2 mt-4">
            {['Business Structure', 'LLC + EIN', '1099 System', 'Recruiting Filter', 'Pressure Interview', 'Onboarding 48hrs', 'Territory Grid', 'KPI Tracking', 'Safe Scaling', 'System Operator'].map(badge => (
              <span key={badge} className="px-2 py-1 bg-amber-500/20 text-amber-700 border border-amber-500/30 rounded text-xs font-medium">{badge}</span>
            ))}
          </div>
        </div>
      </TimeBlock>
    </div>
  );
}

const DAY_CONTENT = {
  1: Day1Content, 2: Day2Content, 3: Day3Content, 4: Day4Content, 5: Day5Content,
  6: Day6Content, 7: Day7Content, 8: Day8Content, 9: Day9Content, 10: Day10Content,
};

export default function TerritoryAcademy() {
  const [activeDay, setActiveDay] = useState(1);
  const day = DAYS.find(d => d.day === activeDay);
  const DayContent = DAY_CONTENT[activeDay];

  return (
    <div className="flex gap-6 min-h-[calc(100vh-80px)]">
      <div className="w-56 shrink-0 space-y-1 sticky top-0 self-start pt-1">
        <div className="flex items-center gap-2 mb-4 px-2">
          <Trophy className="w-5 h-5 text-amber-500" />
          <div>
            <h2 className="font-bold text-sm leading-tight">Territory Owner</h2>
            <p className="text-[10px] text-muted-foreground">Certification Academy</p>
          </div>
        </div>
        <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-2 mb-3">
          <p className="text-[10px] text-amber-700 font-bold uppercase tracking-widest">10 Days · 10 Hours</p>
          <p className="text-[10px] text-muted-foreground">1 session per day · 60 min each</p>
        </div>
        {DAYS.map(d => (
          <button key={d.day} onClick={() => setActiveDay(d.day)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left text-xs transition-colors ${activeDay === d.day ? 'bg-amber-500/10 text-amber-700 font-semibold border border-amber-500/30' : 'text-muted-foreground hover:bg-muted hover:text-foreground'}`}>
            <d.icon className="w-3.5 h-3.5 shrink-0" />
            <span><span className="font-bold">Day {d.day}</span><span className="block text-[10px] opacity-70 truncate">{d.title}</span></span>
          </button>
        ))}
      </div>
      <div className="flex-1 min-w-0 space-y-4 pb-10">
        <div className={`rounded-xl border p-5 ${day?.color}`}>
          <div className="flex items-start gap-4">
            {day && <day.icon className="w-8 h-8 shrink-0 mt-0.5" />}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Badge className="bg-black/10 text-inherit text-xs">Day {day?.day} of 10</Badge>
                <Badge className="bg-black/10 text-inherit text-xs">⏱ 60 Minutes</Badge>
              </div>
              <h1 className="text-2xl font-black tracking-tight">{day?.title}</h1>
              <p className="text-sm opacity-70">{day?.subtitle}</p>
            </div>
          </div>
          <div className="mt-3 flex items-start gap-2 bg-black/10 rounded-lg p-3">
            <Target className="w-4 h-4 shrink-0 mt-0.5" />
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-70 mb-0.5">Session Goal</p>
              <p className="text-sm font-medium">{day?.goal}</p>
            </div>
          </div>
        </div>
        <Card><CardContent className="p-6">{DayContent && <DayContent />}</CardContent></Card>
        <div className="flex items-center justify-between pt-2">
          {activeDay > 1 ? (
            <Button variant="outline" onClick={() => setActiveDay(d => d - 1)} className="gap-2">← Day {activeDay - 1}</Button>
          ) : <div />}
          {activeDay < 10 ? (
            <Button onClick={() => setActiveDay(d => d + 1)} className="gap-2 bg-amber-600 hover:bg-amber-700">Day {activeDay + 1}: {DAYS[activeDay].title} →</Button>
          ) : (
            <div className="flex items-center gap-2 text-amber-600 font-bold"><Trophy className="w-5 h-5" /> Academy Complete!</div>
          )}
        </div>
      </div>
    </div>
  );
}