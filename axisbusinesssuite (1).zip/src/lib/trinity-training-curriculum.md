# AXIS Business Suite — Complete Training Curriculum
## From Initial Setup to Selling (Step-by-Step Guide for AXIS AI)

This document is AXIS AI's comprehensive training reference. When a user asks for training, onboarding, or a walkthrough, AXIS AI follows this curriculum step-by-step, adapting depth based on the user's role (admin, rep, new subscriber).

---

## PHASE 1: INITIAL SETUP (Day 1)

### Step 1.1 — Account & First Login
1. User receives an invitation email after trial signup or admin invite
2. Click the invite link and set a password
3. After login, land on the Dashboard (/app)
4. **Admin users** see the full sidebar with all modules
5. **Rep users** are directed to /rep-portal or /rep-login
6. Key concept: Data is isolated by subscriber — each admin owns their own leads, calls, and settings

### Step 1.2 — Company Settings & Configuration
Navigate to Settings (/settings):
1. **Company Name**: Set under General Settings
2. **Timezone**: Set to match the business's operating timezone (default: America/New_York)
3. **Default Timezone** affects when the AI bot is allowed to call (TCPA: 8AM–9PM local)
4. **Caller ID Number**: Set the display number for outbound calls
5. Save settings

### Step 1.3 — AI Call Bot Configuration
Navigate to Call Bot (/call-bot) → Settings tab:
1. **Bot Script**: Write the conversation script (see Phase 3 for script writing)
2. **Bot Voice**: Choose personality (professional, friendly, energetic, calm, assertive, conversational)
3. **Bot Personality Style**: consultative, challenger, solution_seller, relationship_builder, direct_closer
4. **Talking Speed**: slow, normal, fast
5. **Empathy Level**: low, medium, high
6. **Objection Handling Style**: deflect, acknowledge_pivot, challenge, feel_felt_found
7. **Max Call Attempts**: Default 3 per lead
8. **Call Gap Seconds**: Default 5 seconds between calls
9. **Require Consent**: Must be ON for TCPA compliance — bot won't call leads without consent_given = true
10. **Auto DNC**: When ON, automatically adds anyone who says "stop calling" to the Do Not Call list
11. **Display Caller ID**: Should be ON for compliance

### Step 1.4 — Calling Schedule
1. Set weekly calling schedule rules (days and hours)
2. TCPA legally restricts calls to 8AM–9PM in the recipient's local timezone
3. The bot will not call outside these hours

### Step 1.5 — Integration Setup (Smart Connect + API Center)
AXIS connects to 80+ services. Two paths, both reached from Settings → Connections (/settings) → "Connect a Tool":

**A. Smart Connect — per-user OAuth (recommended; isolated per subscriber)**
Each subscriber connects their OWN account with one click — no API keys, no OAuth app setup on their side:
1. **Google family**: Gmail, Google Calendar, Drive, Sheets, Docs, Slides, Meet, Tasks, Forms, Classroom, BigQuery, Analytics, Search Console — "Connect with Google" → authorize → live for that subscriber only
2. **Microsoft Outlook & Slack**: same one-click per-user OAuth flow
3. Status badges in the Connections grid show what's connected; disconnect anytime
4. This is the right choice for any service that holds the subscriber's own data (inbox, calendar, files, CRM)

**B. Shared platform OAuth (platform-level; one consent, shared app-wide)**
For non-Google services used by the platform itself (GitHub for code, Notion for docs, Sentry/PagerDuty for ops, Jira/Linear for backlog), AXIS uses Base44's shared platform OAuth — the platform holds the OAuth app, the account owner consents once. Connect these from the Connections page when a feature needs them. Note: shared mode connects the account owner's data across the whole app, so it is NOT used for per-subscriber CRM/marketing tools.

**C. Manual credentials (API Center, /api-center)**
1. **Twilio** (SMS + real phone calls): Account SID, Auth Token, Phone Number
2. **Converge/Elavon** (subscription billing — admin only)
3. **Custom calling APIs** (Bland, Vapi, SignalWire): API keys in Call Bot settings

### Step 1.6 — Calendly Event Configuration
1. In Settings → Calendly tab, enter the API token and click "Fetch My Info"
2. Set Event Type URI (from Calendly event types)
3. Configure default duration (30 min), buffer minutes (15), days ahead (3)
4. Set timezone preference and morning/afternoon preference
5. Test the connection

### Step 1.7 — The Integration Ecosystem (Quick Reference)
Three connection modes, 80+ services:
- **Per-user OAuth (isolated):** Gmail, Google Calendar, Outlook, Slack, Google Drive, Sheets, Docs, Slides, Meet, Tasks, Forms, Classroom, BigQuery, Analytics, Search Console
- **Shared platform OAuth (platform-level):** GitHub, Notion, Jira, Linear, Sentry, PagerDuty, and 60+ others
- **Manual credentials:** Twilio, Converge, custom calling APIs
Rule of thumb: if it holds the subscriber's own data → per-user OAuth; if it's a platform/dev-ops tool → shared OAuth; if it's telephony/billing → manual credentials. Trinity can guide any user to the right mode.

---

## PHASE 2: LEAD MANAGEMENT (Day 1–2)

### Step 2.1 — Adding Leads
Three methods:
1. **Manual Entry**: Leads page (/leads) → Add Lead button → fill first_name (required), phone (required), email, company, notes
2. **CSV Import**: Import Wizard (/import-wizard or /import) → upload CSV → map columns → confirm consent → import
3. **AI Lead Generator**: Lead Generator (/lead-generator) → specify industry, location, criteria → AI finds prospects from Google Maps, web search, and business databases

### Step 2.2 — Lead Fields Explained
- **first_name** (required): Lead's first name
- **last_name**: Lead's last name
- **phone** (required): Phone number — must be E.164 format for calling (+1XXXXXXXXXX)
- **email**: Email address
- **company**: Company name
- **status**: new, contacted, qualified, appointment_set, not_interested, do_not_call, invalid
- **source**: Where the lead came from
- **consent_given**: MUST be true before the bot can call (TCPA requirement)
- **consent_date**: When consent was recorded
- **timezone**: Lead's timezone for calling window compliance
- **assigned_to**: Email of the rep assigned to this lead
- **call_attempts**: Auto-tracked number of call attempts

### Step 2.3 — Consent & Compliance
**CRITICAL**: Before uploading or calling any lead list:
1. Check the Federal Do Not Call Registry at donotcall.gov
2. Ensure consent_given = true for each lead
3. Record consent_date when consent was captured
4. The bot will refuse to call any lead with consent_given = false (if bot_require_consent is ON)

### Step 2.4 — Lead Statuses & Workflow
Leads flow through these statuses:
- **new** → Just added, not yet called
- **contacted** → Bot has reached the lead
- **qualified** → Lead is interested and meets criteria
- **appointment_set** → An appointment has been booked
- **not_interested** → Lead declined
- **do_not_call** → Lead requested no further contact
- **invalid** → Wrong number or unreachable

### Step 2.5 — DNC Registry
Navigate to DNC Registry (/dnc):
1. Phone numbers on this list will NEVER be called by the bot
2. The bot auto-adds numbers when someone says "stop calling" (if Auto DNC is ON)
3. You can manually add numbers with a reason (customer_request, federal_dnc, state_dnc, internal_policy)
4. Always scrub lead lists against the DNC before importing

---

## PHASE 3: THE AI CALL BOT (Day 2–3)

### Step 3.1 — Understanding Calling Modes
The bot supports 6 modes (configured in Settings → default_call_service):
1. **AI Simulation**: AI simulates a full conversation — best for testing scripts
2. **Phone Link**: Generates a clickable call link for manual dialing
3. **Zoom**: Creates a Zoom meeting instead of a phone call
4. **WhatsApp**: Sends a WhatsApp message
5. **Twilio**: Makes real outbound phone calls via Twilio
6. **Custom API**: Uses a custom calling API endpoint

### Step 3.2 — Writing a High-Converting Script
A winning script has 5 parts:
1. **Opening (first 20 seconds)**: Identify yourself, state the purpose, get permission to continue. Goal: get them to say "tell me more"
2. **Discovery**: Ask qualifying questions to understand needs
3. **Value Proposition**: Connect your solution to their stated needs
4. **Objection Handling**: Address concerns using the configured style (acknowledge_pivot, feel_felt_found, etc.)
5. **Close/Next Step**: Either book an appointment, schedule a callback, or gracefully end

Script tips:
- Keep it conversational, not robotic
- Use the lead's name
- Ask open-ended questions
- Have 3–5 objection responses ready
- Always end with a clear next step

### Step 3.3 — Bot Personality Configuration
In Call Bot → Settings:
- **Voice**: professional (default), friendly, energetic, calm, assertive, conversational
- **Personality Style**: 
  - consultative: asks questions, guides to solution
  - challenger: challenges assumptions, provides new perspective
  - solution_seller: leads with product benefits
  - relationship_builder: focuses on long-term connection
  - direct_closer: gets to the point quickly
- **Empathy Level**: How emotionally responsive the bot is
- **Use Humor**: OFF by default — turn on for casual audiences

### Step 3.4 — Running the Auto-Dialer
1. Navigate to Call Bot (/call-bot)
2. Select leads to call (or let the bot pick from the queue)
3. Click "Start Calling"
4. The bot processes leads in sequence:
   - Checks consent and DNC
   - Checks calling hours
   - Makes the call
   - Records outcome
   - Moves to next lead
5. After all leads are processed, the bot stops and shows a completion summary
6. Each call creates a CallLog entry with transcript, recording, and AI summary

### Step 3.5 — Call Analytics
Navigate to Call Logs (/call-logs):
- Filter by status (completed, no_answer, busy, voicemail, failed, blocked)
- Filter by outcome (appointment_set, callback_requested, not_interested, wrong_number, dnc_requested, voicemail_left)
- View call recordings and transcripts
- Check coaching scores and AI recommendations
- Use analytics to optimize scripts and improve conversion

### Step 3.6 — Call Coaching
1. Each call gets an AI coaching score (0–100)
2. Coaching analyzes: opening quality, objection handling, closing, compliance
3. Coaching flags highlight areas for improvement
4. Coaching recommendations suggest specific script changes
5. Navigate to Coaching Hub (/coaching) for team-wide coaching insights

---

## PHASE 4: APPOINTMENTS & CALENDAR SYNC (Day 3)

### Step 4.1 — How Appointments Get Booked
When the bot is calling and a lead agrees to meet:
1. The bot checks Calendly for available slots
2. The bot books the slot on the lead's behalf
3. An Appointment record is created in the system
4. The lead's status updates to "appointment_set"
5. If Google Calendar is connected, the appointment auto-syncs to the rep's personal calendar

### Step 4.2 — Appointment Management
Navigate to Appointments (/appointments):
- View all scheduled appointments
- Filter by status: scheduled, confirmed, completed, cancelled, no_show
- Reschedule appointments
- Update appointment status
- View lead details (name, phone, email) for each appointment

### Step 4.3 — Google Calendar Sync
1. In the Rep Portal → Appointments tab, click "Connect" next to Google Calendar
2. Authorize via Google OAuth
3. Once connected, every AI-created appointment automatically appears on the rep's Google Calendar
4. Calendly bookings also sync into the portal's Appointment list
5. Disconnect anytime from the same panel

### Step 4.4 — Calendly Booking Sync
1. When a lead books through Calendly, the scheduled automation (every 15 min) pulls it into the portal
2. The appointment appears with calendly_event_id set
3. If the lead's email matches an existing lead, their status updates to appointment_set
4. AI-created appointments (without Calendly) are pushed to Google Calendar to avoid duplicates

---

## PHASE 5: MULTI-CHANNEL COMMUNICATION (Day 3–4)

### Step 5.1 — SMS Communication
Navigate to SMS Inbox (/sms):
1. Two-way SMS conversations with leads
2. Requires Twilio to be configured (API Center)
3. Send individual messages or use in nurture workflows
4. All SMS messages are logged in the SmsMessage entity
5. Compliance: limit to 2–3 messages for unresponsive leads

### Step 5.2 — Email Communication
Navigate to Email (/email):
1. Compose and send emails to leads
2. Use email templates for common scenarios
3. Email threads are tracked in the EmailMessage entity
4. Combine with nurture workflows for automated sequences

### Step 5.3 — Nurture Workflows
Navigate to Nurture Workflows (/nurture):
1. Create automated multi-step sequences
2. Combine calls, SMS, and email into a single workflow
3. Trigger based on lead status changes
4. Example: New lead → Day 1 call → Day 2 SMS → Day 3 email → Day 5 callback
5. Monitor enrollment and completion rates

---

## PHASE 6: SELLING FROM THE SYSTEM (Day 4+)

### Step 6.1 — The Complete Sales Workflow
1. **Lead Acquisition**: Import or generate leads (Phase 2)
2. **AI Outreach**: Bot calls leads, follows script, handles objections (Phase 3)
3. **Appointment Booking**: Bot books meetings via Calendly (Phase 4)
4. **Multi-Channel Follow-Up**: SMS/email nurture sequences (Phase 5)
5. **Deal Closure**: Rep takes the appointment, presents, closes
6. **Revenue Tracking**: Track commissions and revenue (Rep Portal → Referrals tab)

### Step 6.2 — Lead Scoring for Prioritization
Navigate to Lead Scoring (/lead-scoring):
1. AI scores each lead 0–100 based on likelihood to convert
2. Factors: engagement, demographics, firmographics, behavior
3. Prioritize high-score leads for manual follow-up
4. Let the bot handle lower-score leads for volume

### Step 6.3 — Follow-Up Tasks
Navigate to Follow-Up Tasks (/tasks):
1. AI automatically creates follow-up tasks based on call outcomes
2. Task types: call_back, send_email, send_sms, schedule_appointment, review_lead
3. Priority levels: high, medium, low
4. Complete tasks to move leads through the pipeline
5. AI-generated tasks are marked with ai_generated = true

### Step 6.4 — Rep Portal for Sales Reps
Navigate to Rep Portal (/rep-portal):
1. **Command Center**: KPI dashboard with calls, appointments, revenue
2. **Leads**: View assigned leads, filter, search, open lead drawer
3. **Tasks**: Follow-up tasks assigned to this rep
4. **Appointments**: Scheduled meetings with calendar sync
5. **Referrals**: Referral link, commission payouts, referral activity
6. **AI Tools**: Lead qualification, objection handling, script generation, message drafting

### Step 6.5 — Commission & Revenue Tracking
In Rep Portal → Referrals tab:
1. Each rep has a unique referral tracking code
2. Share the referral link: {appUrl}/pricing?ref={tracking_code}
3. When someone signs up via the link, a RepReferral record is created
4. Commission is calculated based on the rep's commission_rate and commission_type
5. Commission payouts are tracked in RepCommission records
6. Monitor gross commission, net commission, and payout status

### Step 6.6 — Sales Team Management
Navigate to Sales Team (/sales-team) or Sales Command Center (/sales-command):
1. View all sales reps and their performance
2. Track calls per day vs target
3. Track appointments per week vs target
4. Track revenue per month vs target
5. Manage rep compensation: base salary, commission rate, bonuses, OTE
6. Assign territories and leads

### Step 6.7 — Closing the Loop
1. **Lead converts to customer** → Update lead status to "qualified" or "appointment_set"
2. **Appointment completed** → Update appointment status to "completed"
3. **Payment processed** → PaymentTransaction created (if using Square billing)
4. **Commission calculated** → RepCommission record created for the referring rep
5. **Revenue tracked** → Visible in admin dashboards and rep portal

---

## PHASE 7: ADVANCED FEATURES (Day 5+)

### Step 7.1 — AI Lead Scoring
1. Navigate to Lead Scoring (/lead-scoring)
2. AI analyzes lead data and assigns scores
3. Use scores to prioritize outreach
4. High-score leads → manual follow-up by best closers
5. Low-score leads → automated bot calling for volume

### Step 7.2 — Call Coaching & Script Evolution
1. Navigate to Coaching Hub (/coaching)
2. Review AI coaching scores for all calls
3. Identify common objections and weak script sections
4. Use Script Evolution to let AI rewrite and improve scripts
5. A/B test script variations

### Step 7.3 — Lead Routing
Navigate to Lead Routing (/lead-routing):
1. Automatically assign leads to reps based on rules
2. Route by territory, industry, round-robin, or skill match
3. Ensure even distribution and fast follow-up

### Step 7.4 — AI Agent Tasks
Navigate to Agent Tasks (/agent-tasks):
1. Create custom AI automations
2. Task types: lead_follow_up, data_cleanup, report_generation, nurture_sequence, dnc_sync, lead_scoring
3. Schedule: once, hourly, daily, weekly
4. Define conditions and actions
5. Monitor run history and results

### Step 7.5 — Social Media AI
Navigate to Social Media (/social-media):
1. AI generates content for Facebook, Instagram, LinkedIn, TikTok, Twitter
2. Schedule posts across platforms
3. Create and manage ad campaigns
4. Track engagement metrics

---

## PHASE 8: ADMINISTRATION & COMPLIANCE (Ongoing)

### Step 8.1 — User Management
Navigate to Admin → Users (/admin/users):
1. Invite new users (admin or user role)
2. Manage trial invitations
3. Enable/disable add-ons per user
4. Control account access

### Step 8.2 — Compliance Monitoring
Navigate to Compliance (/compliance):
1. View all compliance events (consent, DNC, time violations, opt-outs)
2. Export compliance reports (/compliance-export)
3. Audit trail for every consent record, DNC addition, and caller ID check
4. Critical for TCPA defense

### Step 8.3 — Billing & Subscriptions
1. AXIS's Converge (Elavon) merchant account is for charging subscriber SUBSCRIPTION FEES ONLY (monthly/yearly plans, setup fees) — it is NOT a payment processor for subscribers' own storefront sales
2. Subscribers enter their card during checkout via Converge's secure Hosted Payment Page — card data never touches AXIS servers
3. If a subscriber asks about updating the card they pay AXIS with, tell them to contact support@axisbusiness.com — do NOT direct them to any payment settings page
4. The Subscription Billing tab in Settings is admin-only and contains AXIS's own merchant credentials — it is NOT visible to subscribers
5. Trial users are automatically billed after their 7-day free trial ends
6. IMPORTANT DISTINCTION: If a subscriber wants to accept credit cards from THEIR OWN customers (storefront sales, ecommerce), that is completely separate — they would set up their OWN payment processor (Square, Stripe, PayPal, etc.) in their storefront/commerce settings. AXIS's Converge account has nothing to do with subscriber storefront sales.

### Step 8.4 — System Health
1. AXIS AI can run SYSTEM REVIEW for a full health report
2. Daily security audits run automatically
3. Monitor for critical compliance issues
4. Track trial conversions and churn

### Step 8.5 — Trinity CS Team & Customer Service
1. Trinity AI acts as the liaison for all customer service inquiries
2. When a user needs support, Trinity creates a CSTicket automatically from chat
3. The AI triage engine (trinityCSTriage) categorizes, prioritizes, and generates a response
4. Tickets with confidence ≥75% and no escalation flag are auto-resolved by the AI
5. Tickets the AI can't handle are escalated to live agents
6. Live agents monitor and handle tickets via the CS Dashboard (/cs-dashboard)
7. Agent actions: claim, respond, resolve, close
8. Ticket lifecycle: new → ai_triaging → ai_resolved OR escalated → agent_assigned → resolved → closed
9. Sources: Trinity chat, SupportHub, email, manual creation

### Step 8.6 — Trinity Evolution Engine & Dev Studio
1. The Evolution Engine runs on daily and weekly schedules, researching competitor gaps and user pain points
2. Every candidate feature passes a 3-tier value filter: subscriber benefit, platform stickiness, profitability
3. Dev Studio NEVER auto-executes code — it forms a plan and waits for super-admin approval
4. Approved plans are queued as EvolutionBacklog entries for deployment
5. Deployments only occur during low-traffic windows to ensure zero user disruption
6. Trinity cascades all system changes to onboarding, Academy, AI agents, and subscriber notifications
7. Access the Evolution Engine status via Continuous Evolution (/nexus/evolution)

### Step 8.7 — Commerce, Collaboration & Native Tools
1. AXIS Meet (/axis-meet) provides built-in video conferencing — create a room and share the link, no external setup
2. The Storefront (/storefront or /:slug) displays public products synced with InventoryItem records
3. Point of Sale is accessible from the Inventory tab (/inventory) — all retail users can process manual sales
4. The White Label Partner Dashboard (/partner-dashboard) provides branded portals and residual earnings tracking
5. Native Calendar (/calendar) handles scheduling and appointment management — no Google Calendar needed
6. Native File Manager (/files) stores and organizes files — no external cloud storage needed
7. Native Email Campaigns (/email-campaigns) sends bulk marketing emails to subscribers
8. Landing Page Builder (/page-builder) creates custom public pages with drag-and-drop blocks

---

## TRAINING DELIVERY GUIDELINES FOR TRINITY

### How to Train a New User
1. **Assess the user**: Ask their role (admin, rep, new subscriber) and experience level
2. **Start with Phase 1**: Walk through setup before anything else
3. **Use live data**: Reference the user's actual leads, calls, and settings to make it concrete
4. **One step at a time**: Don't overwhelm — complete one step, confirm understanding, move to next
5. **Check for understanding**: Ask questions like "Does that make sense?" or "Want me to explain that part again?"
6. **Adapt to pace**: Some users want to move fast, others need more detail
7. **Offer hands-on practice**: Suggest they try each action themselves while you guide
8. **Reference the Academy**: Point users to /academy for self-paced video modules with quizzes

### Training Paths by Role

**New Subscriber/Admin** → Full Phase 1 through Phase 8
**Sales Rep** → Phase 1.1–1.2, Phase 2.1–2.4, Phase 3.4–3.6, Phase 4, Phase 5, Phase 6.4–6.7
**New Hire** → Phase 1.1, Phase 2, Phase 3, Phase 6.4 (Rep Portal)

### Quick-Reference Commands Users Can Ask AXIS AI
- "Train me on setup" → Start Phase 1
- "How do I add leads?" → Phase 2.1
- "How do I write a call script?" → Phase 3.2
- "How do appointments work?" → Phase 4
- "How do I track my commissions?" → Phase 6.5
- "What's compliance?" → Phase 2.3, Phase 8.2
- "Walk me through the whole system" → Start Phase 1, go through all phases
- "I want to sell using the system" → Phase 6 (Selling from the System)

### Key URLs to Reference
- Dashboard: /app
- Leads: /leads
- Import: /import-wizard
- Call Bot: /call-bot
- Call Logs: /call-logs
- Appointments: /appointments
- DNC Registry: /dnc
- Compliance: /compliance
- Settings: /settings
- API Center: /api-center
- Rep Portal: /rep-portal
- Academy: /academy
- Nurture Workflows: /nurture
- Lead Scoring: /lead-scoring
- Coaching Hub: /coaching
- Follow-Up Tasks: /tasks
- Sales Team: /sales-team
- Sales Command Center: /sales-command
- Admin Console: /admin/console
- User Management: /admin/users
- Compliance Export: /compliance-export
- Agent Tasks: /agent-tasks
- Social Media: /social-media
- Email: /email
- SMS Inbox: /sms
- Lead Generator: /lead-generator
- Lead Routing: /lead-routing
- Subscription: /subscription
- CS Dashboard: /cs-dashboard
- Continuous Evolution: /nexus/evolution
- AXIS Meet: /axis-meet
- Storefront: /storefront (public)
- Inventory & POS: /inventory
- Partner Dashboard: /partner-dashboard
- Native Calendar: /calendar
- File Manager: /files
- Email Campaigns: /email-campaigns
- Landing Page Builder: /page-builder