import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

export function useCurrentUser() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let unsubscribe = null;
    let mounted = true;
    let timeoutId = null;

    // Set a 5-second timeout to prevent infinite loading
    timeoutId = setTimeout(() => {
      if (mounted) {
        console.warn('Auth check timed out in useCurrentUser');
        setLoading(false);
        setUser(null);
      }
    }, 5000);

    const checkAuth = async () => {
      try {
        const u = await base44.auth.me();
        if (mounted) {
          setUser(u);
          if (u?.id) {
            // Subscribe to real-time updates on the User entity for this user
            unsubscribe = base44.entities.User.subscribe((event) => {
              if (event.id === u.id && (event.type === 'update' || event.type === 'create')) {
                setUser(event.data);
              }
            });
          }
        }
      } catch (error) {
        // User is not authenticated - clear user state
        if (mounted) {
          setUser(null);
        }
      } finally {
        if (mounted) {
          setLoading(false);
          if (timeoutId) clearTimeout(timeoutId);
        }
      }
    };

    checkAuth();

    return () => {
      mounted = false;
      if (unsubscribe) unsubscribe();
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, []);

  const refreshUser = async () => {
    const u = await base44.auth.me();
    setUser(u);
    return u;
  };

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const isSuperAdmin = user?.role === 'super_admin';

  const dataOwnerEmail = user?.role === 'user'
    ? (user?.account_owner_email || user?.email)
    : user?.email;

  return { user, loading, isAdmin, isSuperAdmin, dataOwnerEmail, refreshUser };
}