import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from './useCurrentUser';

// Portal roles (distinct from platform admin/user/super_admin).
// Each role defines a landing route, the sidebar module IDs it may use,
// and the route paths it may visit directly. `modules: null` / `paths: 'all'`
// means full app access (minus system admin).
export const PORTAL_ROLES = {
  sales_rep: {
    label: 'Sales Rep',
    landing: '/rep-portal',
    modules: ['rep_portal', 'crm_leads', 'crm_appointments', 'crm_tasks', 'crm_call_logs', 'comm_email', 'comm_sms', 'axis_meet', 'learning_center', 'account_settings'],
    paths: ['/rep-portal', '/leads', '/appointments', '/tasks', '/call-logs', '/email', '/sms', '/axis-meet', '/academy', '/my-settings'],
  },
  hr_staff: {
    label: 'HR Staff',
    landing: '/hr',
    modules: ['dashboard', 'hr_suite', 'recruitment', 'axis_meet', 'comm_email', 'learning_center', 'account_settings'],
    paths: ['/app', '/hr', '/recruitment', '/axis-meet', '/email', '/academy', '/my-settings'],
  },
  finance_staff: {
    label: 'Finance Staff',
    landing: '/finance-overview',
    modules: ['dashboard', 'finance_ops', 'account_settings'],
    paths: ['/app', '/financial-ops', '/finance-overview', '/my-settings'],
  },
  operations_staff: {
    label: 'Operations Staff',
    landing: '/app',
    modules: ['dashboard', 'ai_production_validation', 'quote_builder', 'crm_tasks', 'account_settings'],
    paths: ['/app', '/production-validation', '/quote-builder', '/tasks', '/my-settings'],
  },
  management: {
    label: 'Management',
    landing: '/app',
    modules: null,
    paths: 'all',
  },
};

export const PORTAL_ROLE_OPTIONS = Object.entries(PORTAL_ROLES).map(([key, v]) => ({ key, label: v.label }));

// Resolves the logged-in employee's portal role + allowed modules/paths.
// Account admins / super_admins are not considered employee sub-users.
export function useEmployeeRole() {
  const { user, isAdmin } = useCurrentUser();
  const isSubUser = !!user?.account_owner_email && !isAdmin;

  const { data, isLoading } = useQuery({
    queryKey: ['employee-role', user?.email],
    queryFn: async () => {
      const rows = await base44.entities.Employee.filter({ email: user.email });
      return rows?.[0] || null;
    },
    enabled: isSubUser && !!user?.email,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  const portalRole = data?.portal_role && data.portal_role !== 'none' ? data.portal_role : null;
  const roleConfig = portalRole ? PORTAL_ROLES[portalRole] : null;
  const allowedModules = roleConfig?.modules ?? null; // null = all (management)
  const landing = roleConfig?.landing || '/app';

  const isPathAllowed = (path) => {
    if (!isSubUser || !portalRole) return true;
    if (roleConfig?.paths === 'all') return true;
    return (roleConfig?.paths || []).some((p) => path === p || (p !== '/app' && path.startsWith(p + '/')));
  };

  return { isSubUser, portalRole, roleConfig, allowedModules, landing, isPathAllowed, employee: data, isLoading };
}