import React, { useState, useEffect, useRef } from 'react';

const THRESHOLD = 60;
const MAX_PULL = 100;

/**
 * Touch-based pull-to-refresh hook.
 * Attaches passive touch listeners to the document and activates only when
 * the page is scrolled to the very top (scrollTop === 0).
 *
 * @param {function} onRefresh - async callback invoked when the pull threshold is met
 * @returns { containerRef, pullDistance, isRefreshing }
 */
export function usePullToRefresh({ onRefresh } = {}) {
  const containerRef = useRef(null);
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const startYRef = useRef(0);
  const pullingRef = useRef(false);
  const pullDistRef = useRef(0);
  const refreshingRef = useRef(false);
  const onRefreshRef = useRef(onRefresh);

  useEffect(() => { onRefreshRef.current = onRefresh; }, [onRefresh]);

  useEffect(() => {
    const getScrollTop = () =>
      Math.max(document.documentElement.scrollTop || 0, document.body.scrollTop || 0);

    const handleTouchStart = (e) => {
      if (getScrollTop() === 0 && !refreshingRef.current) {
        startYRef.current = e.touches[0].clientY;
        pullingRef.current = true;
      } else {
        pullingRef.current = false;
      }
    };

    const handleTouchMove = (e) => {
      if (!pullingRef.current || refreshingRef.current) return;
      if (getScrollTop() > 0) {
        pullingRef.current = false;
        setPullDistance(0);
        pullDistRef.current = 0;
        return;
      }
      const diff = e.touches[0].clientY - startYRef.current;
      if (diff > 0) {
        const resisted = Math.min(diff * 0.4, MAX_PULL);
        pullDistRef.current = resisted;
        setPullDistance(resisted);
      }
    };

    const handleTouchEnd = async () => {
      if (!pullingRef.current) return;
      pullingRef.current = false;
      if (pullDistRef.current >= THRESHOLD && !refreshingRef.current) {
        refreshingRef.current = true;
        setIsRefreshing(true);
        try {
          await onRefreshRef.current?.();
        } catch (_) {
          // silent — the page's own error handling applies
        } finally {
          refreshingRef.current = false;
          setIsRefreshing(false);
          setPullDistance(0);
          pullDistRef.current = 0;
        }
      } else {
        setPullDistance(0);
        pullDistRef.current = 0;
      }
    };

    document.addEventListener('touchstart', handleTouchStart, { passive: true });
    document.addEventListener('touchmove', handleTouchMove, { passive: true });
    document.addEventListener('touchend', handleTouchEnd, { passive: true });

    return () => {
      document.removeEventListener('touchstart', handleTouchStart);
      document.removeEventListener('touchmove', handleTouchMove);
      document.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  return { containerRef, pullDistance, isRefreshing };
}