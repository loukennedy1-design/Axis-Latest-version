import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export function useEmailAccounts() {
  const qc = useQueryClient();
  const queryKey = ['user-email-accounts'];

  const { data: accounts = [], isLoading, isError, error } = useQuery({
    queryKey,
    queryFn: async () => {
      const res = await base44.functions.invoke('manageEmailAccounts', { action: 'list' });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data?.accounts || [];
    },
  });

  const invalidate = () => qc.invalidateQueries({ queryKey });

  const saveMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const res = await base44.functions.invoke('manageEmailAccounts', { action: 'save', id, data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: invalidate,
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      const res = await base44.functions.invoke('manageEmailAccounts', { action: 'delete', id });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: invalidate,
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (id) => {
      const res = await base44.functions.invoke('manageEmailAccounts', { action: 'set_default', id });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: invalidate,
  });

  const defaultAccount = accounts.find(a => a.is_default) || accounts[0] || null;

  return {
    accounts,
    defaultAccount,
    isLoading,
    isError,
    error,
    saveAccount: saveMutation.mutateAsync,
    deleteAccount: deleteMutation.mutateAsync,
    setDefault: setDefaultMutation.mutateAsync,
    isSaving: saveMutation.isPending,
  };
}