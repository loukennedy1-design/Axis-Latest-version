import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

// Fetches the system-level email config (super-admin managed).
// Returns { configured, config: { email_address, display_name, reply_to } }
// Regular users only see the sender identity (no server details).
export function useSystemEmail() {
  const { data, isLoading } = useQuery({
    queryKey: ['system-email-config'],
    queryFn: async () => {
      const res = await base44.functions.invoke('systemEmailConfig', { action: 'get' });
      return res.data;
    },
  });

  const config = data?.config || null;
  const configured = !!data?.configured;

  return {
    systemEmail: config,
    systemEmailConfigured: configured,
    systemEmailLoading: isLoading,
  };
}