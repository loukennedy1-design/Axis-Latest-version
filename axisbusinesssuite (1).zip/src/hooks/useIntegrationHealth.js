// Fetches the live status of every integration in one place.
// Shared by the Connections Hub, the Integration Wizard, and the
// sidebar health indicator so they never drift out of sync.
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { INTEGRATIONS } from '@/lib/integrations';

export const integrationHealthKeys = {
  oauth: ['integration-health', 'oauth'],
  twilio: ['integration-health', 'twilio'],
  settings: ['integration-health', 'settings'],
  perUser: ['integration-health', 'per-user'],
};

export function useIntegrationHealth(enabled = true) {
  // OAuth connections (Google Calendar, Gmail, Drive, QuickBooks)
  const oauthQ = useQuery({
    queryKey: integrationHealthKeys.oauth,
    queryFn: async () => {
      const res = await base44.functions.invoke('getOAuthConnections', {});
      return res.data?.connections || [];
    },
    enabled,
    staleTime: 60 * 1000,
  });

  // Per-user OAuth connectors (Gmail, Google Calendar, Outlook, Slack) — each
  // subscriber connects their own account; status lives in the platform's
  // per-user connector store, not the legacy UserOAuthConnection entity.
  const perUserQ = useQuery({
    queryKey: integrationHealthKeys.perUser,
    queryFn: async () => {
      const res = await base44.functions.invoke('perUserConnectorStatus', {});
      return res.data?.connected || {};
    },
    enabled,
    staleTime: 60 * 1000,
  });

  // Twilio config — also tells us whether workspace defaults are in use
  const twilioQ = useQuery({
    queryKey: integrationHealthKeys.twilio,
    queryFn: async () => {
      const res = await base44.functions.invoke('getTwilioConfig', {});
      return res.data?.config || {};
    },
    enabled,
    staleTime: 60 * 1000,
  });

  // Per-user system settings (manual credential fields)
  const settingsQ = useQuery({
    queryKey: integrationHealthKeys.settings,
    queryFn: async () => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
      return res.data?.settings || null;
    },
    enabled,
    staleTime: 60 * 1000,
  });

  const loading = oauthQ.isLoading || twilioQ.isLoading || settingsQ.isLoading || perUserQ.isLoading;
  const oauth = oauthQ.data || [];
  const twilioConfig = twilioQ.data || {};
  const settings = settingsQ.data || null;
  const perUser = perUserQ.data || {};

  const ctx = { oauth, twilioConfig, settings, perUser };

  // Map each integration to a status
  const statuses = INTEGRATIONS.map(i => ({
    id: i.id,
    name: i.name,
    critical: i.critical,
    status: loading ? 'loading' : (i.status?.(ctx) || 'unset'),
  }));

  // Any critical integration broken → show sidebar warning
  const criticalBroken = statuses
    .filter(s => s.critical && (s.status === 'unset' || s.status === 'failed'))
    .map(s => s.id);

  const refetchAll = () => {
    oauthQ.refetch();
    twilioQ.refetch();
    settingsQ.refetch();
    perUserQ.refetch();
  };

  return {
    loading,
    oauth,
    twilioConfig,
    settings,
    perUser,
    statuses,
    criticalBroken,
    refetchAll,
  };
}