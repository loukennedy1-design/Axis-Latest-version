import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from './useCurrentUser';

export const HR_AREAS = [
  'employees', 'timeoff', 'performance', 'jobs',
  'applicants', 'payroll', 'documents', 'onboarding',
];

// Area key → permission field on the UserHrPermissions record
const AREA_TO_FIELD = {
  employees: 'can_view_employees',
  timeoff: 'can_view_timeoff',
  performance: 'can_view_performance',
  jobs: 'can_view_jobs',
  applicants: 'can_view_applicants',
  payroll: 'can_view_payroll',
  documents: 'can_view_documents',
  onboarding: 'can_view_onboarding',
};

const DEFAULTS = {
  can_view_employees: true,
  can_view_timeoff: true,
  can_view_performance: false,
  can_view_jobs: false,
  can_view_applicants: false,
  can_view_payroll: false,
  can_view_documents: true,
  can_view_onboarding: false,
  full_access: false,
};

// Returns the current user's effective HR permissions.
// Account admins (and super_admins) get full access. Sub-users get their
// configured record, or sensible defaults if the admin hasn't set them yet.
export function useHrPermissions() {
  const { isAdmin } = useCurrentUser();
  const { data, isLoading } = useQuery({
    queryKey: ['hr-permissions-mine'],
    queryFn: async () => {
      const res = await base44.functions.invoke('hrAccessControl', { action: 'my_permissions' });
      return res.data;
    },
  });

  const isHrAdmin = !!isAdmin;

  // Admins see everything; sub-users are gated by their permissions.
  const can = (area) => {
    if (isHrAdmin) return true;
    const field = AREA_TO_FIELD[area];
    if (!field) return false;
    const perms = data?.permissions || DEFAULTS;
    if (perms.full_access) return true;
    return !!perms[field];
  };

  return { isHrAdmin, can, permissions: data?.permissions, loading: isLoading };
}