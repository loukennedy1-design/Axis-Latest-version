import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';

/**
 * Resolves the user's active Twilio configuration.
 * Merges per-account SystemSettings with workspace-wide API Center defaults.
 */
export function useTwilioConfig(opts = {}) {
  const { user } = useCurrentUser();
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['twilio-config', user?.email],
    queryFn: async () => {
      const res = await base44.functions.invoke('getTwilioConfig', { config_type: 'frontend' });
      return res?.data?.config || null;
    },
    enabled: !!user?.email && (opts.enabled !== false),
    ...opts,
  });

  return {
    config: data,
    twilioConfigured: data?.configured || false,
    twilioPhoneNumber: data?.from_number || '',
    usingWorkspaceDefaults: data?.using_workspace_defaults || false,
    isLoading,
    error,
    refetch,
  };
}