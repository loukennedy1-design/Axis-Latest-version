import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Receipt, CheckCircle2, XCircle, Loader2, Upload, Pencil, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_COLORS = {
  pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  approved: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
};

const EMPTY = { description: '', amount: '', category: 'other', date: format(new Date(), 'yyyy-MM-dd'), vendor: '', notes: '', receipt_url: '' };

export default function ExpensesPanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(EMPTY);

  const { data: expenses = [] } = useQuery({ queryKey: ['expenses'], queryFn: () => base44.entities.Expense.list('-created_date', 200) });

  const create = useMutation({
    mutationFn: (data) => editId 
      ? base44.entities.Expense.update(editId, { ...data, amount: parseFloat(data.amount) || 0 })
      : base44.entities.Expense.create({ ...data, amount: parseFloat(data.amount) || 0, status: 'pending' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['expenses'] }); setOpen(false); setEditId(null); setForm(EMPTY); toast.success(editId ? 'Expense updated' : 'Expense submitted'); },
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Expense.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['expenses'] }); toast.success('Expense deleted'); },
  });

  const approve = useMutation({
    mutationFn: (id) => base44.functions.invoke('financeOperations', { action: 'approve_expense', expense_id: id }),
    onSuccess: (res) => { if (res.data?.error) { toast.error(res.data.error); return; } qc.invalidateQueries({ queryKey: ['expenses'] }); toast.success(res.data.message || 'Expense approved & posted to ledger'); },
  });

  const reject = useMutation({
    mutationFn: (id) => base44.entities.Expense.update(id, { status: 'rejected' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['expenses'] }),
  });

  const pending = expenses.filter(e => e.status === 'pending');
  const approved = expenses.filter(e => e.status === 'approved');
  const totalApproved = approved.reduce((s, e) => s + (e.amount || 0), 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xl font-bold text-amber-400">{pending.length}</p><p className="text-xs text-muted-foreground">Pending Approval</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xl font-bold text-emerald-400">{approved.length}</p><p className="text-xs text-muted-foreground">Approved</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-xl font-bold">${totalApproved.toLocaleString()}</p><p className="text-xs text-muted-foreground">Total Approved</p></div>
      </div>

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{expenses.length} expenses · {pending.length} awaiting approval</p>
        <Button size="sm" className="gap-2" onClick={() => setOpen(true)}><Plus className="w-4 h-4" />Log Expense</Button>
      </div>

      {expenses.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm"><Receipt className="w-8 h-8 mx-auto mb-3 opacity-40" />No expenses logged yet.</div>
      ) : (
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {expenses.map(exp => (
            <div key={exp.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{exp.description}</p>
                <p className="text-xs text-muted-foreground capitalize">{exp.vendor ? `${exp.vendor} · ` : ''}{exp.category} · {exp.date}</p>
              </div>
              <p className="font-bold text-sm text-red-400">-${(exp.amount || 0).toLocaleString()}</p>
              <Badge className={`text-[10px] ${STATUS_COLORS[exp.status] || ''}`}>{exp.status}</Badge>
              {exp.status === 'pending' && (
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-emerald-400 border-emerald-500/30" disabled={approve.isPending} onClick={() => approve.mutate(exp.id)}><CheckCircle2 className="w-3 h-3" />Approve</Button>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-red-400 border-red-500/30" onClick={() => reject.mutate(exp.id)}><XCircle className="w-3 h-3" />Reject</Button>
                </div>
              )}
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(exp.id); setForm({ description: exp.description, amount: String(exp.amount), category: exp.category, date: exp.date, vendor: exp.vendor, notes: exp.notes, receipt_url: exp.receipt_url }); setOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { if (window.confirm('Delete this expense?')) deleteMut.mutate(exp.id); }}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setEditId(null); setForm(EMPTY); } }}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Receipt className="w-4 h-4" />{editId ? 'Edit Expense' : 'Log Expense'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Description</Label><Input className="mt-1" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="What was purchased?" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Amount ($)</Label><Input className="mt-1" type="number" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} /></div>
              <div><Label>Date</Label><Input className="mt-1" type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Category</Label>
                <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['payroll','software','marketing','office','travel','equipment','contractor','other'].map(c => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Vendor</Label><Input className="mt-1" value={form.vendor} onChange={e => setForm({ ...form, vendor: e.target.value })} /></div>
            </div>
            <div><Label>Notes</Label><Textarea className="mt-1" rows={2} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
            <Button className="w-full" disabled={!form.description || !form.amount || create.isPending} onClick={() => create.mutate(form)}>{create.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}{editId ? 'Update Expense' : 'Submit Expense'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}