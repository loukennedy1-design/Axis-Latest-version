import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Banknote, Building2, CheckCircle2, AlertTriangle, Save, Edit3, Loader2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

export default function ACHSetupWizard() {
  const qc = useQueryClient();
  const [editingOrigin, setEditingOrigin] = useState(false);
  const [empBankOpen, setEmpBankOpen] = useState(null);
  const [saving, setSaving] = useState(false);

  const { data: settings } = useQuery({ queryKey: ['system-settings'], queryFn: () => base44.entities.SystemSettings.filter({}).then(r => r[0]) });
  const { data: employees = [], refetch } = useQuery({ queryKey: ['employees-active'], queryFn: () => base44.entities.Employee.filter({ status: 'active' }) });

  const [origin, setOrigin] = useState({ ach_origin_routing: '', ach_company_name: '', ach_company_id: '' });

  // Sync origin from settings when loaded
  useEffect(() => {
    if (settings) setOrigin({
      ach_origin_routing: settings.ach_origin_routing || '',
      ach_company_name: settings.ach_company_name || settings.company_name || '',
      ach_company_id: settings.ach_company_id || '',
    });
  }, [settings]);

  const updateSettings = useMutation({
    mutationFn: (data) => base44.entities.SystemSettings.update(settings.id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['system-settings'] }); },
  });

  const saveOrigin = async () => {
    setSaving(true);
    try {
      await updateSettings.mutateAsync({ ...origin, ach_setup_complete: true });
      toast.success('ACH origin saved — payroll is ready');
      setEditingOrigin(false);
    } catch (e) { toast.error(e.message); } finally { setSaving(false); }
  };

  const saveEmployeeBank = async (empId, bankData) => {
    setSaving(true);
    try {
      await base44.entities.Employee.update(empId, bankData);
      toast.success('Banking info saved');
      setEmpBankOpen(null);
      refetch();
    } catch (e) { toast.error(e.message); } finally { setSaving(false); }
  };

  const withBanking = employees.filter(e => e.bank_routing && e.bank_account_number);
  const withoutBanking = employees.filter(e => !e.bank_routing || !e.bank_account_number);
  const originReady = settings?.ach_origin_routing && settings?.ach_company_name;

  return (
    <div className="space-y-4">
      {/* ACH Origin Setup */}
      <Card className={`border-2 ${originReady ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
        <CardContent className="p-5">
          <div className="flex items-start justify-between gap-3 mb-4">
            <div className="flex items-start gap-3">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${originReady ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                {originReady ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <Building2 className="w-5 h-5 text-amber-400" />}
              </div>
              <div>
                <h3 className="font-semibold text-sm">Step 1 — Company Banking (NACHA Origin)</h3>
                <p className="text-xs text-muted-foreground mt-0.5">Your business bank routing + company details for NACHA file generation.</p>
              </div>
            </div>
            {originReady && !editingOrigin && <Badge className="bg-emerald-500/10 text-emerald-400 text-[10px]">Configured</Badge>}
          </div>

          {editingOrigin || !originReady ? (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-xs">Bank Routing # (9 digits)</Label>
                  <Input value={origin.ach_origin_routing} onChange={e => setOrigin({ ...origin, ach_origin_routing: e.target.value.replace(/\D/g, '').slice(0, 9) })} placeholder="021000021" className="font-mono" />
                </div>
                <div>
                  <Label className="text-xs">Company Name (NACHA)</Label>
                  <Input value={origin.ach_company_name} onChange={e => setOrigin({ ...origin, ach_company_name: e.target.value.slice(0, 16) })} placeholder="ACME Corp" maxLength={16} />
                </div>
                <div>
                  <Label className="text-xs">Company ID (10 digits)</Label>
                  <Input value={origin.ach_company_id} onChange={e => setOrigin({ ...origin, ach_company_id: e.target.value.replace(/\D/g, '').slice(0, 10) })} placeholder="1234567890" className="font-mono" />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={saveOrigin} disabled={saving || !origin.ach_origin_routing || !origin.ach_company_name} className="gap-2">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}Save & Complete Setup
                </Button>
                {editingOrigin && <Button variant="outline" onClick={() => setEditingOrigin(false)}>Cancel</Button>}
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <div className="flex gap-6 text-sm">
                <div><span className="text-muted-foreground text-xs">Routing:</span> <span className="font-mono">{settings.ach_origin_routing}</span></div>
                <div><span className="text-muted-foreground text-xs">Company:</span> {settings.ach_company_name}</div>
                <div><span className="text-muted-foreground text-xs">ID:</span> <span className="font-mono">{settings.ach_company_id || '—'}</span></div>
              </div>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setEditingOrigin(true)}><Edit3 className="w-3.5 h-3.5" />Edit</Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Employee Banking Status */}
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-blue-500/20 flex items-center justify-center"><Banknote className="w-5 h-5 text-blue-400" /></div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm">Step 2 — Employee Direct Deposit Info</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Add bank routing + account number for each employee to generate valid NACHA files.</p>
            </div>
            <Badge className="bg-blue-500/10 text-blue-400 text-[10px]">{withBanking.length}/{employees.length} Ready</Badge>
          </div>

          {withoutBanking.length > 0 && (
            <div className="mb-3 flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg p-2.5">
              <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
              {withoutBanking.length} employee(s) missing banking info — they'll be skipped in the NACHA file.
            </div>
          )}

          <div className="space-y-1.5 max-h-72 overflow-y-auto">
            {employees.map(emp => {
              const ready = emp.bank_routing && emp.bank_account_number;
              return (
                <div key={emp.id} className="flex items-center gap-3 p-2.5 bg-card border border-border rounded-lg">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${ready ? 'bg-emerald-500/15' : 'bg-muted'}`}>
                    {ready ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <AlertTriangle className="w-4 h-4 text-amber-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{emp.first_name} {emp.last_name}</p>
                    <p className="text-xs text-muted-foreground">{ready ? `••••${(emp.bank_account_number || '').slice(-4)} · ${emp.bank_account_type || 'checking'}` : 'No banking info'}</p>
                  </div>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => setEmpBankOpen(emp)}>
                    {ready ? 'Edit' : 'Add'} <Edit3 className="w-3 h-3" />
                  </Button>
                </div>
              );
            })}
            {employees.length === 0 && <div className="text-center text-muted-foreground text-sm py-6">No active employees found.</div>}
          </div>
        </CardContent>
      </Card>

      {/* Ready state */}
      {originReady && withBanking.length > 0 && (
        <div className="flex items-center gap-2 text-sm text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
          <ShieldCheck className="w-4 h-4" />
          ACH payroll is ready! Go to the Payroll tab to run your first batch.
        </div>
      )}

      <EmployeeBankDialog emp={empBankOpen} open={!!empBankOpen} onClose={() => setEmpBankOpen(null)} onSave={saveEmployeeBank} saving={saving} />
    </div>
  );
}

function EmployeeBankDialog({ emp, open, onClose, onSave, saving }) {
  const [routing, setRouting] = useState('');
  const [account, setAccount] = useState('');
  const [type, setType] = useState('checking');

  useEffect(() => {
    if (emp) { setRouting(emp.bank_routing || ''); setAccount(emp.bank_account_number || ''); setType(emp.bank_account_type || 'checking'); }
  }, [emp]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader><DialogTitle className="flex items-center gap-2"><Banknote className="w-4 h-4 text-primary" />Direct Deposit — {emp?.first_name} {emp?.last_name}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div><Label className="text-xs">Bank Routing # (9 digits)</Label><Input value={routing} onChange={e => setRouting(e.target.value.replace(/\D/g, '').slice(0, 9))} placeholder="021000021" className="font-mono" /></div>
          <div><Label className="text-xs">Account #</Label><Input value={account} onChange={e => setAccount(e.target.value.replace(/\D/g, ''))} placeholder="000123456789" className="font-mono" /></div>
          <div className="flex items-center gap-3">
            <Label className="text-xs">Account Type:</Label>
            <label className="flex items-center gap-1 text-sm cursor-pointer"><input type="radio" checked={type === 'checking'} onChange={() => setType('checking')} /> Checking</label>
            <label className="flex items-center gap-1 text-sm cursor-pointer"><input type="radio" checked={type === 'savings'} onChange={() => setType('savings')} /> Savings</label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave(emp?.id, { bank_routing: routing, bank_account_number: account, bank_account_type: type })} disabled={saving || routing.length < 9 || !account} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}