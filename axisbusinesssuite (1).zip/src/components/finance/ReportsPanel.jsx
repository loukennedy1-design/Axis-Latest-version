import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3, Loader2, Download, TrendingUp, TrendingDown, DollarSign, Scale, FileText } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

function exportCsv(filename, rows) {
  const csv = rows.map(r => r.map(c => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
  toast.success('CSV exported');
}

export default function ReportsPanel() {
  const [periodStart, setPeriodStart] = useState(new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0]);
  const [periodEnd, setPeriodEnd] = useState(new Date().toISOString().split('T')[0]);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('financeOperations', { action: 'generate_reports', period_start: periodStart, period_end: periodEnd });
      if (res.data?.error) throw new Error(res.data.error);
      setReport(res.data);
      toast.success('Reports generated');
    } catch (e) { toast.error(e.message); } finally { setLoading(false); }
  };

  const pl = report?.profit_and_loss;
  const bs = report?.balance_sheet;
  const tx = report?.tax_summary;

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-end gap-3 flex-wrap">
            <div><Label className="text-xs">Period Start</Label><Input type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} className="h-9" /></div>
            <div><Label className="text-xs">Period End</Label><Input type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} className="h-9" /></div>
            <Button onClick={generate} disabled={loading} className="gap-2">{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BarChart3 className="w-4 h-4" />}Generate Reports</Button>
          </div>
        </CardContent>
      </Card>

      {!report ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm"><BarChart3 className="w-8 h-8 mx-auto mb-3 opacity-40" />Select a date range and generate to view your P&L, Balance Sheet, and Tax Summary.</div>
      ) : (
        <>
          {/* P&L */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-400" />Profit & Loss</CardTitle>
              <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => exportCsv(`pl-${periodStart}.csv`, [['Line','Amount'],['Revenue',pl.revenue],['COGS',pl.cost_of_goods_sold],['Gross Profit',pl.gross_profit],['Operating Expenses',pl.operating_expenses],['Payroll',pl.payroll_expense],['Net Income',pl.net_income], ...(Object.entries(pl.expense_breakdown||{}).map(([k,v])=>[`  ${k}`,v]))])}><Download className="w-3 h-3" />CSV</Button>
            </CardHeader>
            <CardContent className="space-y-1.5 text-sm pt-0">
              <Row label="Revenue" value={pl.revenue} color="text-emerald-400" />
              <Row label="Cost of Goods Sold" value={-pl.cost_of_goods_sold} color="text-red-400" />
              <Row label="Gross Profit" value={pl.gross_profit} bold />
              <Row label="Operating Expenses" value={-pl.operating_expenses} color="text-red-400" />
              <Row label="Payroll Expense" value={-pl.payroll_expense} color="text-red-400" />
              <div className="border-t border-border pt-1.5"><Row label="Net Income" value={pl.net_income} bold color={pl.net_income >= 0 ? 'text-emerald-400' : 'text-red-400'} /></div>
              {pl.expense_breakdown && Object.keys(pl.expense_breakdown).length > 0 && (
                <div className="pt-3">
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Expense Breakdown</p>
                  {Object.entries(pl.expense_breakdown).map(([cat, amt]) => (
                    <div key={cat} className="flex justify-between text-xs"><span className="text-muted-foreground capitalize">{cat}</span><span className="text-red-400">-${amt.toLocaleString()}</span></div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Balance Sheet */}
            <Card>
              <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Scale className="w-4 h-4 text-blue-400" />Balance Sheet Snapshot</CardTitle></CardHeader>
              <CardContent className="space-y-1.5 text-sm pt-0">
                <Row label="Total Assets" value={bs.total_assets} color="text-emerald-400" />
                <Row label="Total Liabilities" value={bs.total_liabilities} color="text-red-400" />
                <Row label="Total Equity" value={bs.total_equity} color="text-blue-400" />
                <div className="border-t border-border pt-1.5"><Row label="Liabilities + Equity" value={bs.liabilities_plus_equity} bold /></div>
              </CardContent>
            </Card>

            {/* Tax Summary */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm flex items-center gap-2"><FileText className="w-4 h-4 text-amber-400" />Tax Summary</CardTitle>
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => exportCsv(`tax-${periodStart}.csv`, [['Line','Amount'],['Taxable Revenue',tx.taxable_revenue],['Deductible Expenses',tx.deductible_expenses],['Estimated Taxable Income',tx.estimated_taxable_income],['Estimated Tax Liability',tx.estimated_tax_liability],['Effective Rate',`${(tx.effective_rate*100).toFixed(0)}%`]])}><Download className="w-3 h-3" />CSV</Button>
              </CardHeader>
              <CardContent className="space-y-1.5 text-sm pt-0">
                <Row label="Taxable Revenue" value={tx.taxable_revenue} color="text-emerald-400" />
                <Row label="Deductible Expenses" value={-tx.deductible_expenses} color="text-red-400" />
                <Row label="Estimated Taxable Income" value={tx.estimated_taxable_income} bold />
                <div className="border-t border-border pt-1.5"><Row label={`Estimated Tax Liability (${(tx.effective_rate*100).toFixed(0)}%)`} value={tx.estimated_tax_liability} bold color="text-amber-400" /></div>
              </CardContent>
            </Card>
          </div>

          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-1">
            <DollarSign className="w-3.5 h-3.5" />Cash collected in period: <span className="font-semibold text-emerald-400">${(report.cash_collected || 0).toLocaleString()}</span>
          </div>
        </>
      )}
    </div>
  );
}

function Row({ label, value, bold, color }) {
  return (
    <div className="flex justify-between items-center">
      <span className={bold ? 'font-semibold' : 'text-muted-foreground'}>{label}</span>
      <span className={`${bold ? 'font-bold' : 'font-medium'} ${color || ''}`}>${Math.abs(value || 0).toLocaleString()}{value < 0 ? '' : ''}</span>
    </div>
  );
}