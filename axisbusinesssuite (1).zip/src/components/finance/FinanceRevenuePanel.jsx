import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, TrendingDown, CheckCircle2, XCircle, UserPlus, Activity } from 'lucide-react';
import { format, subDays, startOfDay, isSameDay, isWithinInterval } from 'date-fns';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from 'recharts';

const currency = (n) => `$${(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;

// FinanceRevenuePanel — tracks processed payments, subscription signups, and a
// daily breakdown of successful vs failed transactions for revenue monitoring.
export default function FinanceRevenuePanel() {
  const { data: txns = [], isLoading: txLoading } = useQuery({
    queryKey: ['payment-txns-overview'],
    queryFn: () => base44.entities.PaymentTransaction.list('-created_date', 500),
  });
  const { data: invites = [], isLoading: invLoading } = useQuery({
    queryKey: ['trialInvites-overview'],
    queryFn: () => base44.entities.TrialInvite.list('-created_date', 500),
  });

  const now = new Date();
  const rangeStart = startOfDay(subDays(now, 13));

  const isInRange = (d) => {
    if (!d) return false;
    try { return isWithinInterval(new Date(d), { start: rangeStart, end: now }); } catch { return false; }
  };

  // ── Aggregate totals ────────────────────────────────────────────────
  const totals = useMemo(() => {
    const payments = txns.filter(t => t.transaction_type !== 'refund' && t.transaction_type !== 'fee');
    const completed = payments.filter(t => t.status === 'completed');
    const failed = payments.filter(t => t.status === 'failed');
    const processedAmount = completed.reduce((s, t) => s + (t.amount || 0), 0);
    const failedAmount = failed.reduce((s, t) => s + (t.amount || 0), 0);
    const successRate = (completed.length + failed.length) > 0
      ? (completed.length / (completed.length + failed.length)) * 100
      : 0;
    const signups = invites.length;
    const signupsLast14 = invites.filter(i => isInRange(i.created_date)).length;
    return {
      processedCount: completed.length,
      processedAmount,
      failedCount: failed.length,
      failedAmount,
      successRate,
      signups,
      signupsLast14,
    };
  }, [txns, invites]);

  // ── Daily breakdown (last 14 days) ──────────────────────────────────
  const daily = useMemo(() => {
    const days = Array.from({ length: 14 }, (_, i) => {
      const day = subDays(now, 13 - i);
      return {
        date: day,
        label: format(day, 'MMM d'),
        successful: 0,
        successfulAmount: 0,
        failed: 0,
        failedAmount: 0,
        signups: 0,
      };
    });

    txns.forEach((t) => {
      if (!t.created_date && !t.transaction_date) return;
      const d = new Date(t.created_date || t.transaction_date);
      const day = days.find((x) => isSameDay(x.date, d));
      if (!day) return;
      if (t.status === 'completed' && t.transaction_type !== 'refund' && t.transaction_type !== 'fee') {
        day.successful += 1;
        day.successfulAmount += (t.amount || 0);
      } else if (t.status === 'failed') {
        day.failed += 1;
        day.failedAmount += (t.amount || 0);
      }
    });

    invites.forEach((i) => {
      if (!i.created_date) return;
      const d = new Date(i.created_date);
      const day = days.find((x) => isSameDay(x.date, d));
      if (day) day.signups += 1;
    });

    return days;
  }, [txns, invites]);

  const loading = txLoading || invLoading;

  if (loading) {
    return (
      <Card>
        <CardContent className="py-10 text-center text-sm text-muted-foreground">
          Loading finance overview…
        </CardContent>
      </Card>
    );
  }

  const kpis = [
    {
      label: 'Processed Payments',
      value: currency(totals.processedAmount),
      sub: `${totals.processedCount} transactions`,
      icon: DollarSign,
      color: 'text-emerald-400',
      bg: 'from-emerald-500/10 to-emerald-600/5',
      border: 'border-emerald-500/20',
    },
    {
      label: 'Failed Transactions',
      value: currency(totals.failedAmount),
      sub: `${totals.failedCount} transactions`,
      icon: XCircle,
      color: 'text-red-400',
      bg: 'from-red-500/10 to-red-600/5',
      border: 'border-red-500/20',
    },
    {
      label: 'Subscription Signups',
      value: totals.signups,
      sub: `${totals.signupsLast14} in last 14 days`,
      icon: UserPlus,
      color: 'text-blue-400',
      bg: 'from-blue-500/10 to-blue-600/5',
      border: 'border-blue-500/20',
    },
    {
      label: 'Success Rate',
      value: `${totals.successRate.toFixed(1)}%`,
      sub: `${totals.processedCount + totals.failedCount} total attempts`,
      icon: Activity,
      color: totals.successRate >= 90 ? 'text-emerald-400' : totals.successRate >= 70 ? 'text-amber-400' : 'text-red-400',
      bg: 'from-primary/10 to-primary/5',
      border: 'border-primary/20',
    },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg bg-emerald-500/15 flex items-center justify-center">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
        </div>
        <div>
          <h2 className="text-sm font-semibold">Finance Overview</h2>
          <p className="text-xs text-muted-foreground">Processed payments, signups &amp; daily transaction health — last 14 days</p>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {kpis.map((kpi) => (
          <div key={kpi.label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 ${kpi.bg} ${kpi.border}`}>
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{kpi.label}</p>
                <p className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{kpi.sub}</p>
              </div>
              <kpi.icon className={`w-5 h-5 opacity-30 ${kpi.color}`} />
            </div>
          </div>
        ))}
      </div>

      {/* Daily breakdown chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            Daily Transaction Breakdown — Successful vs Failed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={daily} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
                formatter={(v, name) => [`${v} ${name.includes('Amount') ? '($)' : ''}`, name]}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="successful" name="Successful" fill="#34D399" radius={[3, 3, 0, 0]} />
              <Bar dataKey="failed" name="Failed" fill="#F87171" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Daily breakdown table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Daily Detail
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-xl border border-border overflow-hidden">
            <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-muted/50 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              <div className="col-span-3">Date</div>
              <div className="col-span-2 text-right">Successful</div>
              <div className="col-span-3 text-right">Processed $</div>
              <div className="col-span-2 text-right">Failed</div>
              <div className="col-span-2 text-right">Signups</div>
            </div>
            {[...daily].reverse().map((d) => (
              <div key={d.label} className="grid grid-cols-12 gap-2 px-3 py-2 text-sm border-t border-border items-center">
                <div className="col-span-3 font-medium">{d.label}</div>
                <div className="col-span-2 text-right">
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 text-xs">
                    <CheckCircle2 className="w-3 h-3 mr-1" />{d.successful}
                  </Badge>
                </div>
                <div className="col-span-3 text-right font-semibold text-emerald-400">{currency(d.successfulAmount)}</div>
                <div className="col-span-2 text-right">
                  {d.failed > 0 ? (
                    <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30 text-xs">
                      <XCircle className="w-3 h-3 mr-1" />{d.failed}
                    </Badge>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </div>
                <div className="col-span-2 text-right">
                  {d.signups > 0 ? (
                    <span className="text-blue-400 font-medium">{d.signups}</span>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}