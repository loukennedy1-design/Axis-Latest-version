import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Send, CheckCircle2, Loader2, FileText, Trash2, Pencil } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_COLORS = {
  draft: 'bg-muted text-muted-foreground',
  sent: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  paid: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  overdue: 'bg-red-500/10 text-red-400 border-red-500/20',
  cancelled: 'bg-muted text-muted-foreground',
};

const EMPTY = { client_name: '', client_email: '', due_date: '', line_items: [{ description: '', qty: 1, rate: 0 }], tax_rate: '', notes: '' };

export default function InvoicesPanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState(null);
  const [form, setForm] = useState(EMPTY);

  const { data: invoices = [] } = useQuery({ queryKey: ['invoices'], queryFn: () => base44.entities.Invoice.list('-created_date', 200) });

  const create = useMutation({
    mutationFn: async (data) => {
      const lineItems = data.line_items.map(l => ({ description: l.description, qty: parseFloat(l.qty) || 0, rate: parseFloat(l.rate) || 0, total: (parseFloat(l.qty) || 0) * (parseFloat(l.rate) || 0) }));
      const subtotal = lineItems.reduce((s, l) => s + l.total, 0);
      const taxRate = parseFloat(data.tax_rate) || 0;
      const tax = subtotal * taxRate / 100;
      const total = subtotal + tax;
      if (editId) {
        return base44.entities.Invoice.update(editId, { client_name: data.client_name, client_email: data.client_email, due_date: data.due_date, line_items: JSON.stringify(lineItems), subtotal, tax_rate: taxRate, total, notes: data.notes });
      }
      return base44.entities.Invoice.create({
        invoice_number: `INV-${Date.now().toString().slice(-6)}`,
        client_name: data.client_name,
        client_email: data.client_email,
        due_date: data.due_date,
        line_items: JSON.stringify(lineItems),
        subtotal,
        tax_rate: taxRate,
        total,
        status: 'draft',
        notes: data.notes,
      });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invoices'] }); setOpen(false); setEditId(null); setForm(EMPTY); toast.success(editId ? 'Invoice updated' : 'Invoice created'); },
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Invoice.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['invoices'] }); toast.success('Invoice deleted'); },
  });

  const send = useMutation({
    mutationFn: (invoice_id) => base44.functions.invoke('financeOperations', { action: 'send_invoice', invoice_id }),
    onSuccess: (res) => { if (res.data?.error) { toast.error(res.data.error); return; } qc.invalidateQueries({ queryKey: ['invoices'] }); toast.success(res.data.message || 'Invoice emailed'); },
  });

  const markPaid = useMutation({
    mutationFn: (id) => base44.entities.Invoice.update(id, { status: 'paid', paid_date: format(new Date(), 'yyyy-MM-dd') }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['invoices'] }),
  });

  const updateLine = (i, field, val) => {
    const items = [...form.line_items];
    items[i] = { ...items[i], [field]: val };
    setForm({ ...form, line_items: items });
  };
  const addLine = () => setForm({ ...form, line_items: [...form.line_items, { description: '', qty: 1, rate: 0 }] });
  const removeLine = (i) => setForm({ ...form, line_items: form.line_items.filter((_, idx) => idx !== i) });
  const subtotal = form.line_items.reduce((s, l) => s + (parseFloat(l.qty) || 0) * (parseFloat(l.rate) || 0), 0);
  const tax = subtotal * (parseFloat(form.tax_rate) || 0) / 100;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{invoices.length} invoices</p>
        <Button size="sm" className="gap-2" onClick={() => setOpen(true)}><Plus className="w-4 h-4" />New Invoice</Button>
      </div>

      {invoices.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <FileText className="w-8 h-8 mx-auto mb-3 opacity-40" />No invoices yet.
        </div>
      ) : (
        <div className="space-y-2">
          {invoices.map(inv => (
            <div key={inv.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{inv.client_name} <span className="text-xs text-muted-foreground font-normal">· {inv.invoice_number}</span></p>
                <p className="text-xs text-muted-foreground">Due {inv.due_date || '—'}{inv.client_email ? ` · ${inv.client_email}` : ''}</p>
              </div>
              <p className="font-bold text-sm">${(inv.total || 0).toLocaleString()}</p>
              <Badge className={`text-[10px] ${STATUS_COLORS[inv.status] || ''}`}>{inv.status}</Badge>
              {inv.status === 'draft' && <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={send.isPending} onClick={() => send.mutate(inv.id)}><Send className="w-3 h-3" />Send</Button>}
              {inv.status === 'sent' && <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-emerald-400 border-emerald-500/30" onClick={() => markPaid.mutate(inv.id)}><CheckCircle2 className="w-3 h-3" />Mark Paid</Button>}
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(inv.id); const items = JSON.parse(inv.line_items || '[]'); setForm({ client_name: inv.client_name, client_email: inv.client_email, due_date: inv.due_date, line_items: items.length ? items.map(l => ({ description: l.description, qty: String(l.qty), rate: String(l.rate) })) : [{ description: '', qty: '1', rate: '0' }], tax_rate: String(inv.tax_rate || 0), notes: inv.notes || '' }); setOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { if (window.confirm('Delete this invoice?')) deleteMut.mutate(inv.id); }}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setEditId(null); setForm(EMPTY); } }}>
        <DialogContent className="max-w-lg max-h-[88vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><FileText className="w-4 h-4" />{editId ? 'Edit Invoice' : 'New Invoice'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Client Name</Label><Input className="mt-1" value={form.client_name} onChange={e => setForm({ ...form, client_name: e.target.value })} /></div>
              <div><Label>Client Email</Label><Input className="mt-1" type="email" value={form.client_email} onChange={e => setForm({ ...form, client_email: e.target.value })} /></div>
            </div>
            <div><Label>Due Date</Label><Input className="mt-1" type="date" value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} /></div>
            <div>
              <Label>Line Items</Label>
              <div className="space-y-2 mt-1">
                {form.line_items.map((l, i) => (
                  <div key={i} className="flex gap-2 items-center">
                    <Input className="flex-1" placeholder="Description" value={l.description} onChange={e => updateLine(i, 'description', e.target.value)} />
                    <Input className="w-16" type="number" placeholder="Qty" value={l.qty} onChange={e => updateLine(i, 'qty', e.target.value)} />
                    <Input className="w-24" type="number" placeholder="Rate" value={l.rate} onChange={e => updateLine(i, 'rate', e.target.value)} />
                    <span className="text-xs w-20 text-right">${((parseFloat(l.qty) || 0) * (parseFloat(l.rate) || 0)).toLocaleString()}</span>
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => removeLine(i)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                  </div>
                ))}
                <Button size="sm" variant="outline" className="text-xs" onClick={addLine}><Plus className="w-3 h-3 mr-1" />Add Line</Button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Tax Rate (%)</Label><Input className="mt-1" type="number" value={form.tax_rate} onChange={e => setForm({ ...form, tax_rate: e.target.value })} placeholder="0" /></div>
              <div className="flex flex-col justify-end"><div className="text-xs text-muted-foreground">Subtotal: ${subtotal.toLocaleString()}</div><div className="text-xs text-muted-foreground">Tax: ${tax.toLocaleString()}</div><div className="text-sm font-bold">Total: ${(subtotal + tax).toLocaleString()}</div></div>
            </div>
            <div><Label>Notes</Label><Textarea className="mt-1" rows={2} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
            <Button className="w-full" disabled={!form.client_name || create.isPending} onClick={() => create.mutate(form)}>{create.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}{editId ? 'Update Invoice' : 'Create Invoice'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}