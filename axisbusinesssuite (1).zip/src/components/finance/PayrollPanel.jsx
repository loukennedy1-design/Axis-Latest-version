import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Calculator, Loader2, Play, Download, Banknote, FileDown, CheckCircle2, AlertTriangle, Zap, Settings2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_COLORS = {
  draft: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  approved: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  processed: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  paid: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
};

function defaultPeriod() {
  const now = new Date();
  const start = new Date(now); start.setDate(now.getDate() - now.getDay() - 7);
  const end = new Date(start); end.setDate(start.getDate() + 13);
  const payDate = new Date(end); payDate.setDate(end.getDate() + 3);
  const fmt = d => d.toISOString().split('T')[0];
  return { start: fmt(start), end: fmt(end), payDate: fmt(payDate) };
}

export default function PayrollPanel() {
  const qc = useQueryClient();
  const p = defaultPeriod();
  const [periodStart, setPeriodStart] = useState(p.start);
  const [periodEnd, setPeriodEnd] = useState(p.end);
  const [payDate, setPayDate] = useState(p.payDate);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const { data: records = [] } = useQuery({ queryKey: ['payroll'], queryFn: () => base44.entities.PayrollRecord.list('-pay_date', 200) });
  const { data: settings } = useQuery({ queryKey: ['system-settings'], queryFn: () => base44.entities.SystemSettings.filter({}).then(r => r[0]) });
  const { data: employees = [] } = useQuery({ queryKey: ['employees-active'], queryFn: () => base44.entities.Employee.filter({ status: 'active' }) });

  const achReady = settings?.ach_origin_routing && settings?.ach_company_name;
  const empsWithBanking = employees.filter(e => e.bank_routing && e.bank_account_number);

  const handlePreview = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('calculatePayroll', { action: 'calculate_preview', pay_period_start: periodStart, pay_period_end: periodEnd, pay_date: payDate });
      if (res.data?.error) throw new Error(res.data.error);
      setPreview(res.data);
      setResult(null);
      setPreviewOpen(true);
    } catch (e) { toast.error(e.message); } finally { setLoading(false); }
  };

  const handleRunACH = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('financeOperations', {
        action: 'run_payroll_ach',
        pay_period_start: periodStart,
        pay_period_end: periodEnd,
        pay_date: payDate,
        origin_routing: settings?.ach_origin_routing,
        origin_name: settings?.ach_company_name,
        company_name: settings?.ach_company_name || settings?.company_name,
      });
      if (res.data?.error) throw new Error(res.data.error);
      setResult(res.data);
      qc.invalidateQueries({ queryKey: ['payroll'] });
      toast.success(res.data.message || `Payroll processed — ${res.data.saved_count} employees`);
    } catch (e) { toast.error(e.message); } finally { setLoading(false); }
  };

  const downloadNacha = () => {
    if (!result?.nacha_file) return;
    const blob = new Blob([result.nacha_file], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nacha-payroll-${result.batch_id || 'batch'}.ach`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('NACHA file downloaded — upload to your bank portal');
  };

  const approveAll = useMutation({
    mutationFn: async () => {
      const processed = records.filter(r => r.status === 'processed');
      for (const r of processed) await base44.entities.PayrollRecord.update(r.id, { status: 'approved' });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['payroll'] }); toast.success('All records approved — ACH direct deposit triggered'); },
  });

  const markPaid = useMutation({
    mutationFn: (id) => base44.entities.PayrollRecord.update(id, { status: 'paid' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['payroll'] }),
  });

  const totalPaid = records.filter(r => r.status === 'paid').reduce((s, r) => s + (r.net_pay || 0), 0);
  const totalProcessed = records.filter(r => r.status === 'processed').reduce((s, r) => s + (r.net_pay || 0), 0);
  const totalApproved = records.filter(r => r.status === 'approved').reduce((s, r) => s + (r.net_pay || 0), 0);
  const processedCount = records.filter(r => r.status === 'processed').length;

  return (
    <div className="space-y-4">
      {/* Setup readiness banner */}
      {!achReady && (
        <div className="flex items-center gap-2 text-sm text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-xl p-3">
          <AlertTriangle className="w-4 h-4 flex-shrink-0" />
          ACH setup incomplete — go to the <strong>Banking & ACH</strong> tab to configure your company routing number before running payroll.
        </div>
      )}
      {achReady && empsWithBanking.length < employees.length && (
        <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-xl p-2.5">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
          {employees.length - empsWithBanking.length} of {employees.length} employees are missing direct deposit info — go to <strong>Banking & ACH</strong> to add it.
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card><CardContent className="p-4"><p className="text-xl font-bold text-emerald-400">${totalPaid.toLocaleString()}</p><p className="text-xs text-muted-foreground">Paid (YTD)</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xl font-bold text-blue-400">${totalApproved.toLocaleString()}</p><p className="text-xs text-muted-foreground">Approved (ACH Pending)</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xl font-bold text-amber-400">${totalProcessed.toLocaleString()}</p><p className="text-xs text-muted-foreground">Processed (NACHA Generated)</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xl font-bold text-primary">{records.length}</p><p className="text-xs text-muted-foreground">Total Records</p></CardContent></Card>
      </div>

      {/* ACH Run wizard */}
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="p-5">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center"><Zap className="w-5 h-5 text-emerald-400" /></div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm">Run Payroll + ACH Direct Deposit</h3>
              <p className="text-xs text-muted-foreground mt-0.5">Three simple steps: Preview → Run + Generate NACHA → Approve All to trigger ACH</p>
            </div>
            {achReady && <Badge className="bg-emerald-500/10 text-emerald-400 text-[10px] gap-1"><CheckCircle2 className="w-3 h-3" />ACH Ready</Badge>}
          </div>
          <div className="grid grid-cols-3 gap-3 mb-3">
            <div><Label className="text-xs">Period Start</Label><Input type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} className="h-9 text-sm" /></div>
            <div><Label className="text-xs">Period End</Label><Input type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} className="h-9 text-sm" /></div>
            <div><Label className="text-xs">Pay Date</Label><Input type="date" value={payDate} onChange={e => setPayDate(e.target.value)} className="h-9 text-sm" /></div>
          </div>
          <Button onClick={handlePreview} disabled={loading} className="w-full gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calculator className="w-4 h-4" />}Preview & Calculate Payroll
          </Button>
        </CardContent>
      </Card>

      {/* Batch approve bar */}
      {processedCount > 0 && (
        <div className="flex items-center justify-between gap-3 bg-blue-500/10 border border-blue-500/20 rounded-xl p-3">
          <div className="flex items-center gap-2 text-sm">
            <CheckCircle2 className="w-4 h-4 text-blue-400" />
            <span><strong>{processedCount}</strong> record(s) processed — NACHA file generated. Approve all to trigger ACH direct deposits.</span>
          </div>
          <Button size="sm" className="gap-1.5 bg-blue-600 hover:bg-blue-700" onClick={() => approveAll.mutate()} disabled={approveAll.isPending}>
            {approveAll.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}Approve All & Trigger ACH
          </Button>
        </div>
      )}

      {/* Records */}
      <div className="flex justify-between items-center"><h3 className="font-semibold text-sm">Payroll Records</h3><span className="text-xs text-muted-foreground">{records.length} records</span></div>
      <div className="space-y-2 max-h-96 overflow-y-auto">
        {records.length === 0 ? (
          <div className="rounded-xl border border-dashed border-border p-10 text-center text-muted-foreground text-sm"><Calculator className="w-8 h-8 mx-auto mb-2 opacity-30" />No payroll records yet.</div>
        ) : records.map(r => (
          <div key={r.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{r.employee_name}</p>
              <p className="text-xs text-muted-foreground">{r.pay_period_start && format(new Date(r.pay_period_start), 'MMM d')} – {r.pay_period_end && format(new Date(r.pay_period_end), 'MMM d, yyyy')}</p>
            </div>
            <p className="text-sm font-bold text-emerald-400">${(r.net_pay || 0).toLocaleString()}</p>
            <Badge className={`text-[10px] ${STATUS_COLORS[r.status] || ''}`}>{r.status}</Badge>
            {r.status === 'approved' && <Button size="sm" variant="outline" className="h-7 text-xs text-emerald-400 border-emerald-500/30" onClick={() => markPaid.mutate(r.id)}>Mark Paid</Button>}
          </div>
        ))}
      </div>

      {/* Preview / Run wizard dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Calculator className="w-5 h-5 text-primary" />Payroll Preview — {periodStart} to {periodEnd}</DialogTitle></DialogHeader>
          {preview && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: 'Employees', value: preview.summary?.employee_count, color: 'text-foreground' },
                  { label: 'Total Gross', value: `$${(preview.summary?.total_gross || 0).toLocaleString()}`, color: 'text-amber-400' },
                  { label: 'Total Taxes', value: `$${(preview.summary?.total_taxes || 0).toLocaleString()}`, color: 'text-red-400' },
                  { label: 'Total Net', value: `$${(preview.summary?.total_net || 0).toLocaleString()}`, color: 'text-emerald-400' },
                ].map(s => (
                  <Card key={s.label}><CardContent className="p-3 text-center"><p className={`text-lg font-bold ${s.color}`}>{s.value}</p><p className="text-xs text-muted-foreground">{s.label}</p></CardContent></Card>
                ))}
              </div>
              <div className="max-h-56 overflow-y-auto rounded-lg border border-border">
                {(preview.preview || []).map((r, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 border-b border-border last:border-0 text-sm">
                    <span className="font-medium">{r.employee_name}</span>
                    <span className="text-muted-foreground">Gross ${r.gross_pay.toLocaleString()}</span>
                    <span className="text-red-400">Tax -${((r.federal_tax || 0) + (r.state_tax || 0) + (r.social_security || 0) + (r.medicare || 0)).toLocaleString()}</span>
                    <span className="font-bold text-emerald-400">Net ${r.net_pay.toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {result ? (
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 space-y-3">
                  <p className="flex items-center gap-2 text-emerald-400 font-semibold"><CheckCircle2 className="w-4 h-4" />Payroll Processed</p>
                  <p className="text-sm text-muted-foreground">{result.message}</p>
                  <p className="text-xs text-muted-foreground">Batch ID: <span className="font-mono">{result.batch_id}</span></p>
                  <Button className="w-full gap-2" onClick={downloadNacha}><FileDown className="w-4 h-4" />Download NACHA File (.ach)</Button>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1 gap-2 bg-blue-600 hover:bg-blue-700 text-white" onClick={() => { approveAll.mutate(); setPreviewOpen(false); }}>
                      <CheckCircle2 className="w-4 h-4" />Approve All & Trigger ACH
                    </Button>
                    <Button variant="outline" className="flex-1" onClick={() => { setPreviewOpen(false); setResult(null); setPreview(null); }}>Done</Button>
                  </div>
                </div>
              ) : (
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setPreviewOpen(false)}>Cancel</Button>
                  <Button className="flex-1 gap-2 bg-emerald-600 hover:bg-emerald-700" disabled={loading || !achReady} onClick={handleRunACH}>
                    {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}Run Payroll + Generate NACHA
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}