import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, FileText, Trash2, ArrowRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_COLORS = {
  draft: 'bg-muted text-muted-foreground',
  sent: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  accepted: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
  expired: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
};

const EMPTY = { customer_name: '', customer_email: '', expiry_date: '', line_items: [{ description: '', qty: 1, rate: 0 }], notes: '' };

export default function EstimatesPanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);

  const { data: estimates = [] } = useQuery({ queryKey: ['estimates'], queryFn: () => base44.entities.Estimate.list('-created_date', 200) });

  const create = useMutation({
    mutationFn: async (data) => {
      const lineItems = data.line_items.map(l => ({ description: l.description, qty: parseFloat(l.qty) || 0, rate: parseFloat(l.rate) || 0 }));
      const subtotal = lineItems.reduce((s, l) => s + l.qty * l.rate, 0);
      const total = subtotal;
      return base44.entities.Estimate.create({
        estimate_number: `EST-${Date.now().toString().slice(-6)}`,
        customer_name: data.customer_name,
        customer_email: data.customer_email,
        expiry_date: data.expiry_date,
        line_items: JSON.stringify(lineItems),
        subtotal,
        total_amount: total,
        status: 'draft',
        notes: data.notes,
      });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['estimates'] }); setOpen(false); setForm(EMPTY); toast.success('Estimate created'); },
  });

  const send = useMutation({ mutationFn: (id) => base44.entities.Estimate.update(id, { status: 'sent' }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['estimates'] }); toast.success('Estimate sent'); } });
  const accept = useMutation({ mutationFn: (id) => base44.entities.Estimate.update(id, { status: 'accepted' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['estimates'] }) });

  const convert = useMutation({
    mutationFn: async (est) => {
      const lineItems = (() => { try { return JSON.parse(est.line_items || '[]'); } catch { return []; } })();
      const subtotal = lineItems.reduce((s, l) => s + (l.qty || 0) * (l.rate || 0), 0);
      const inv = await base44.entities.Invoice.create({
        invoice_number: `INV-${Date.now().toString().slice(-6)}`,
        client_name: est.customer_name,
        client_email: est.customer_email,
        due_date: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
        line_items: est.line_items,
        subtotal,
        total: subtotal,
        status: 'draft',
      });
      await base44.entities.Estimate.update(est.id, { status: 'accepted', converted_to_invoice: true });
      return inv;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['estimates'] }); qc.invalidateQueries({ queryKey: ['invoices'] }); toast.success('Converted to invoice'); },
  });

  const updateLine = (i, field, val) => { const items = [...form.line_items]; items[i] = { ...items[i], [field]: val }; setForm({ ...form, line_items: items }); };
  const addLine = () => setForm({ ...form, line_items: [...form.line_items, { description: '', qty: 1, rate: 0 }] });
  const removeLine = (i) => setForm({ ...form, line_items: form.line_items.filter((_, idx) => idx !== i) });
  const subtotal = form.line_items.reduce((s, l) => s + (parseFloat(l.qty) || 0) * (parseFloat(l.rate) || 0), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{estimates.length} estimates</p>
        <Button size="sm" className="gap-2" onClick={() => setOpen(true)}><Plus className="w-4 h-4" />New Estimate</Button>
      </div>

      {estimates.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <FileText className="w-8 h-8 mx-auto mb-3 opacity-40" />No estimates yet.
        </div>
      ) : (
        <div className="space-y-2">
          {estimates.map(est => (
            <div key={est.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{est.customer_name} <span className="text-xs text-muted-foreground font-normal">· {est.estimate_number}</span></p>
                <p className="text-xs text-muted-foreground">Expires {est.expiry_date || '—'}</p>
              </div>
              <p className="font-bold text-sm">${(est.total_amount || 0).toLocaleString()}</p>
              <Badge className={`text-[10px] ${STATUS_COLORS[est.status] || ''}`}>{est.status}</Badge>
              {est.status === 'draft' && <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => send.mutate(est.id)}>Send</Button>}
              {(est.status === 'sent' || est.status === 'draft') && !est.converted_to_invoice && (
                <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-emerald-400 border-emerald-500/30" disabled={convert.isPending} onClick={() => convert.mutate(est)}><ArrowRight className="w-3 h-3" />Invoice</Button>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[88vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><FileText className="w-4 h-4" />New Estimate</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Customer Name</Label><Input className="mt-1" value={form.customer_name} onChange={e => setForm({ ...form, customer_name: e.target.value })} /></div>
              <div><Label>Customer Email</Label><Input className="mt-1" type="email" value={form.customer_email} onChange={e => setForm({ ...form, customer_email: e.target.value })} /></div>
            </div>
            <div><Label>Expiry Date</Label><Input className="mt-1" type="date" value={form.expiry_date} onChange={e => setForm({ ...form, expiry_date: e.target.value })} /></div>
            <div>
              <Label>Line Items</Label>
              <div className="space-y-2 mt-1">
                {form.line_items.map((l, i) => (
                  <div key={i} className="flex gap-2 items-center">
                    <Input className="flex-1" placeholder="Description" value={l.description} onChange={e => updateLine(i, 'description', e.target.value)} />
                    <Input className="w-16" type="number" placeholder="Qty" value={l.qty} onChange={e => updateLine(i, 'qty', e.target.value)} />
                    <Input className="w-24" type="number" placeholder="Rate" value={l.rate} onChange={e => updateLine(i, 'rate', e.target.value)} />
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => removeLine(i)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                  </div>
                ))}
                <Button size="sm" variant="outline" className="text-xs" onClick={addLine}><Plus className="w-3 h-3 mr-1" />Add Line</Button>
              </div>
            </div>
            <div className="text-sm font-bold">Total: ${subtotal.toLocaleString()}</div>
            <div><Label>Notes</Label><Textarea className="mt-1" rows={2} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
            <Button className="w-full" disabled={!form.customer_name || create.isPending} onClick={() => create.mutate(form)}>{create.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}Create Estimate</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}