import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Building2, DollarSign, Users, TrendingUp, Loader2 } from 'lucide-react';
import { useCurrentUser } from '@/hooks/useCurrentUser';

export default function PartnerEarningsDashboard() {
  const { user } = useCurrentUser();

  const { data: wlPartner, isLoading: loadingWL } = useQuery({
    queryKey: ['wl-partner', user?.email],
    queryFn: async () => {
      const wls = await base44.entities.WhiteLabel.filter({ user_email: user?.email });
      return wls[0] || null;
    },
    enabled: !!user?.email
  });

  const { data: residuals = [], isLoading: loadingResiduals } = useQuery({
    queryKey: ['partner-residuals', wlPartner?.id],
    queryFn: async () => {
      if (!wlPartner?.id) return [];
      return await base44.entities.PartnerResidual.filter({ partner_id: wlPartner.id }, '-period');
    },
    enabled: !!wlPartner?.id
  });

  const { data: revenueSplits = [], isLoading: loadingSplits } = useQuery({
    queryKey: ['revenue-splits', wlPartner?.id],
    queryFn: async () => {
      if (!wlPartner?.id) return [];
      return await base44.entities.RevenueSplit.filter({ wl_partner_id: wlPartner.id }, '-split_date', 50);
    },
    enabled: !!wlPartner?.id
  });

  if (loadingWL || loadingResiduals || loadingSplits) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!wlPartner) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="max-w-md w-full border-dashed">
          <CardContent className="py-12 text-center">
            <Building2 className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="font-semibold mb-1">White-Label Partner Account</p>
            <p className="text-sm text-muted-foreground">
              This account is not configured as a White-Label Partner. Contact your administrator.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalPending = residuals.filter(r => r.status === 'pending_review').reduce((sum, r) => sum + (r.residual_amount || 0), 0);
  const totalPaid = residuals.filter(r => r.status === 'paid').reduce((sum, r) => sum + (r.residual_amount || 0), 0);
  const activeSubscribers = residuals.length > 0 ? residuals[0].total_downstream_subscribers : 0;

  const waterfallData = [
    { stage: 'Gross Revenue', amount: revenueSplits.reduce((sum, s) => sum + (s.gross_amount || 0), 0), color: 'hsl(var(--chart-1))' },
    { stage: 'Axis Cut (50%)', amount: revenueSplits.reduce((sum, s) => sum + (s.axis_cut || 0), 0), color: 'hsl(var(--muted-foreground))' },
    { stage: 'Partner Share (30%)', amount: revenueSplits.reduce((sum, s) => sum + (s.partner_cut || 0), 0), color: 'hsl(var(--primary))' },
    { stage: 'Rep Override (20%)', amount: revenueSplits.reduce((sum, s) => sum + (s.rep_cut || 0), 0), color: 'hsl(var(--chart-3))' }
  ];

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-amber-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
            <Building2 className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{wlPartner.app_name || wlPartner.company_name}</h1>
            <p className="text-muted-foreground text-sm capitalize">{wlPartner.wl_tier} Tier • ${wlPartner.monthly_license_fee}/mo</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Subscribers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeSubscribers}</div>
            <p className="text-xs text-muted-foreground">Downstream accounts</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payout</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">${totalPending.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Awaiting approval</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Paid</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">${totalPaid.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime earnings</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">License Fee</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${wlPartner.monthly_license_fee}</div>
            <p className="text-xs text-muted-foreground">Monthly operating cost</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Revenue Waterfall</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waterfallData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" className="text-xs" tickFormatter={(value) => `$${value.toLocaleString()}`} />
                <YAxis dataKey="stage" type="category" className="text-xs" width={120} />
                <Tooltip
                  formatter={(value) => [`$${value.toLocaleString()}`, 'Amount']}
                  contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                />
                <Bar dataKey="amount" barSize={40}>
                  {waterfallData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Residual Payout History</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Period</TableHead>
                <TableHead>Subscribers</TableHead>
                <TableHead>Gross Revenue</TableHead>
                <TableHead>Your Residual (30%)</TableHead>
                <TableHead>License Fee</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>ACH Reference</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {residuals.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-10 text-muted-foreground">
                    No residual records yet — payouts appear after your first subscriber payments
                  </TableCell>
                </TableRow>
              )}
              {residuals.map((residual) => (
                <TableRow key={residual.id}>
                  <TableCell className="font-mono text-sm">{residual.period}</TableCell>
                  <TableCell>{residual.total_downstream_subscribers}</TableCell>
                  <TableCell>${residual.gross_subscriber_revenue?.toFixed(2) || '0.00'}</TableCell>
                  <TableCell className="font-bold text-primary">${residual.residual_amount?.toFixed(2) || '0.00'}</TableCell>
                  <TableCell>${residual.license_fee_paid?.toFixed(2) || '0.00'}</TableCell>
                  <TableCell>
                    <Badge variant={residual.status === 'paid' ? 'default' : residual.status === 'approved' ? 'secondary' : 'outline'}>
                      {residual.status.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {residual.ach_reference || '—'}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}