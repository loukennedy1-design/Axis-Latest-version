import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { format } from 'date-fns';

const STATUS_OPTIONS = ['scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'];

export default function AppointmentFormDialog({ open, onOpenChange, appointment, onSave }) {
  const isEdit = !!appointment?.id;
  const [form, setForm] = useState({});

  useEffect(() => {
    if (open) {
      setForm(appointment || {
        lead_id: '',
        lead_name: '',
        lead_phone: '',
        lead_email: '',
        scheduled_date: new Date().toISOString(),
        duration_minutes: 30,
        status: 'scheduled',
        notes: '',
        assigned_to: '',
      });
    }
  }, [open, appointment]);

  const { data: leads = [] } = useQuery({ queryKey: ['leads-for-appt'], queryFn: () => base44.entities.Lead.list('-created_date', 100), enabled: open });

  const handleLeadSelect = (leadId) => {
    const lead = leads.find(l => l.id === leadId);
    if (lead) {
      setForm(f => ({
        ...f,
        lead_id: lead.id,
        lead_name: `${lead.first_name || ''} ${lead.last_name || ''}`.trim() || lead.company || 'Lead',
        lead_phone: lead.phone || '',
        lead_email: lead.email || '',
      }));
    }
  };

  const handleSubmit = () => {
    if (!form.lead_id) return;
    onSave({
      ...form,
      scheduled_date: form.scheduled_date ? new Date(form.scheduled_date).toISOString() : new Date().toISOString(),
    });
  };

  const dtValue = form.scheduled_date ? format(new Date(form.scheduled_date), "yyyy-MM-dd'T'HH:mm") : '';

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>{isEdit ? 'Edit Appointment' : 'New Appointment'}</DialogTitle></DialogHeader>
        <div className="space-y-4">
          {!isEdit && (
            <div>
              <Label>Select Lead</Label>
              <Select value={form.lead_id || ''} onValueChange={handleLeadSelect}>
                <SelectTrigger><SelectValue placeholder="Choose a lead..." /></SelectTrigger>
                <SelectContent>
                  {leads.map(l => (
                    <SelectItem key={l.id} value={l.id}>
                      {l.first_name} {l.last_name}{l.company ? ` · ${l.company}` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <div>
            <Label>Status</Label>
            <Select value={form.status || 'scheduled'} onValueChange={v => setForm(f => ({ ...f, status: v }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Date & Time</Label>
            <Input type="datetime-local" value={dtValue} onChange={e => setForm(f => ({ ...f, scheduled_date: e.target.value }))} />
          </div>
          <div>
            <Label>Duration (minutes)</Label>
            <Input type="number" value={form.duration_minutes || 30} onChange={e => setForm(f => ({ ...f, duration_minutes: parseInt(e.target.value) || 30 }))} />
          </div>
          <div>
            <Label>Assigned To</Label>
            <Input value={form.assigned_to || ''} onChange={e => setForm(f => ({ ...f, assigned_to: e.target.value }))} placeholder="Email of assigned user" />
          </div>
          <div>
            <Label>Notes</Label>
            <Input value={form.notes || ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Add notes..." />
          </div>
          <Button className="w-full" disabled={!form.lead_id} onClick={handleSubmit}>
            {isEdit ? 'Save Changes' : 'Create Appointment'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}