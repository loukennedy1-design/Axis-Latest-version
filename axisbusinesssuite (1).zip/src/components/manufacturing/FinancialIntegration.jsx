import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid } from 'recharts';
import { DollarSign, TrendingUp, ShoppingCart, Package, AlertTriangle, CheckCircle2 } from 'lucide-react';

const fmt = (n) => n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${(n || 0).toFixed(0)}`;

export default function FinancialIntegration({ tickets, invoices, orders, inventory }) {
  const stats = useMemo(() => {
    const totalRevenue = tickets.reduce((s, t) => s + (t.total_revenue || 0), 0);
    const totalCost = tickets.reduce((s, t) => s + (t.total_cost || 0), 0);
    const grossProfit = totalRevenue - totalCost;
    const margin = totalRevenue > 0 ? ((grossProfit / totalRevenue) * 100).toFixed(1) : 0;

    const invoiceRevenue = invoices.reduce((s, i) => s + (i.total || 0), 0);
    const paidInvoices = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + (i.total || 0), 0);
    const overdueInvoices = invoices.filter(i => i.status === 'overdue').reduce((s, i) => s + (i.total || 0), 0);

    const inventoryValue = inventory.reduce((s, i) => s + ((i.quantity_on_hand || 0) * (i.unit_cost || 0)), 0);
    const lowStockItems = inventory.filter(i => i.quantity_on_hand <= i.reorder_point);

    const orderRevenue = orders.reduce((s, o) => s + (o.total || 0), 0);

    return { totalRevenue, totalCost, grossProfit, margin, invoiceRevenue, paidInvoices, overdueInvoices, inventoryValue, lowStockItems, orderRevenue };
  }, [tickets, invoices, orders, inventory]);

  // Monthly production revenue chart
  const monthlyData = useMemo(() => {
    const map = {};
    tickets.forEach(t => {
      if (!t.created_date) return;
      const d = new Date(t.created_date);
      const key = `${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear()}`;
      if (!map[key]) map[key] = { month: key, revenue: 0, cost: 0, profit: 0, count: 0 };
      map[key].revenue += t.total_revenue || 0;
      map[key].cost += t.total_cost || 0;
      map[key].profit += (t.total_revenue || 0) - (t.total_cost || 0);
      map[key].count++;
    });
    return Object.values(map).slice(-6);
  }, [tickets]);

  // Top products
  const topProducts = useMemo(() => {
    const map = {};
    tickets.forEach(t => {
      if (!t.product_name) return;
      if (!map[t.product_name]) map[t.product_name] = { name: t.product_name, revenue: 0, cost: 0, units: 0 };
      map[t.product_name].revenue += t.total_revenue || 0;
      map[t.product_name].cost += t.total_cost || 0;
      map[t.product_name].units += t.quantity || 1;
    });
    return Object.values(map).sort((a, b) => b.revenue - a.revenue).slice(0, 5);
  }, [tickets]);

  return (
    <div className="space-y-4">
      {/* Financial Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Production Revenue', val: fmt(stats.totalRevenue), sub: `${stats.margin}% margin`, icon: DollarSign, color: 'text-emerald-400' },
          { label: 'Production Cost', val: fmt(stats.totalCost), sub: `Gross profit: ${fmt(stats.grossProfit)}`, icon: Package, color: 'text-primary' },
          { label: 'Invoice Revenue', val: fmt(stats.invoiceRevenue), sub: `${fmt(stats.paidInvoices)} collected`, icon: TrendingUp, color: 'text-blue-400' },
          { label: 'Inventory Value', val: fmt(stats.inventoryValue), sub: `${stats.lowStockItems.length} items low stock`, icon: ShoppingCart, color: stats.lowStockItems.length > 0 ? 'text-amber-400' : 'text-purple-400' },
        ].map(s => (
          <Card key={s.label} className="border-border/60">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className={`text-xl font-bold mt-1 ${s.color}`}>{s.val}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">{s.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Overdue Invoices Alert */}
      {stats.overdueInvoices > 0 && (
        <div className="flex items-center gap-3 p-3 rounded-xl border border-amber-500/30 bg-amber-500/5">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-400">Overdue Invoices</p>
            <p className="text-xs text-muted-foreground">{fmt(stats.overdueInvoices)} in overdue invoices needs attention</p>
          </div>
        </div>
      )}

      {/* Monthly Revenue Chart */}
      {monthlyData.length > 0 && (
        <Card className="border-border/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Monthly Production Revenue vs Cost</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={monthlyData} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="month" tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} />
                <YAxis tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }} tickFormatter={v => `$${v >= 1000 ? (v/1000).toFixed(0)+'k' : v}`} />
                <Tooltip
                  contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '11px' }}
                  formatter={(v) => [`$${v.toLocaleString()}`, '']}
                />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} name="Revenue" />
                <Bar dataKey="cost" fill="hsl(var(--muted))" radius={[4, 4, 0, 0]} name="Cost" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Top Products */}
      {topProducts.length > 0 && (
        <Card className="border-border/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Top Products by Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {topProducts.map((p, i) => {
                const margin = p.revenue > 0 ? (((p.revenue - p.cost) / p.revenue) * 100).toFixed(0) : 0;
                return (
                  <div key={p.name} className="flex items-center gap-3">
                    <span className="text-[10px] text-muted-foreground w-4">{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-xs font-medium truncate">{p.name}</p>
                        <div className="flex items-center gap-2 shrink-0 ml-2">
                          <span className="text-xs text-emerald-400">{fmt(p.revenue)}</span>
                          <Badge className="text-[9px] h-4 px-1 bg-muted text-muted-foreground">{margin}% margin</Badge>
                        </div>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${Math.min(100, (p.revenue / topProducts[0].revenue) * 100)}%` }} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Linked Invoices */}
      <Card className="border-border/60">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Invoice Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {['draft','sent','paid','overdue'].map(status => {
              const inv = invoices.filter(i => i.status === status);
              const total = inv.reduce((s, i) => s + (i.total || 0), 0);
              const colors = { draft: 'text-muted-foreground', sent: 'text-blue-400', paid: 'text-emerald-400', overdue: 'text-red-400' };
              return (
                <div key={status} className="text-center p-3 rounded-xl bg-muted/30">
                  <p className="text-[10px] text-muted-foreground capitalize">{status}</p>
                  <p className={`text-lg font-bold ${colors[status]}`}>{inv.length}</p>
                  <p className="text-[10px] text-muted-foreground">{fmt(total)}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}