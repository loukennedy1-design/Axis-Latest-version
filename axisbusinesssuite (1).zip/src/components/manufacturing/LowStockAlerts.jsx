import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { AlertTriangle, Package, RefreshCw, ShoppingCart, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export default function LowStockAlerts({ owner }) {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [lastScan, setLastScan] = useState(null);

  const runScan = async () => {
    setScanning(true);
    try {
      const res = await base44.functions.invoke('productionAIOrchestrator', {
        action: 'scan_low_stock',
      });
      const data = res.data;
      setAlerts(data.low_stock_items || []);
      setLastScan(new Date());

      if (data.auto_reorders_created?.length > 0) {
        toast.success(`Auto-created ${data.auto_reorders_created.length} purchase order(s) for low-stock items`);
      } else if (data.low_stock_count === 0) {
        toast.success('All inventory levels are healthy');
      }
    } catch (err) {
      toast.error('Failed to scan inventory');
    } finally {
      setScanning(false);
    }
  };

  useEffect(() => {
    runScan();
    // Auto-scan every 10 minutes
    const interval = setInterval(runScan, 10 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const critical = alerts.filter(a => a.status === 'OUT_OF_STOCK');
  const low = alerts.filter(a => a.status === 'LOW_STOCK');

  if (alerts.length === 0 && !scanning) {
    return (
      <div className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs">
        <CheckCircle2 className="w-4 h-4 shrink-0" />
        <span className="font-medium">All inventory levels healthy</span>
        {lastScan && <span className="text-emerald-400/60 ml-auto">Last scan: {lastScan.toLocaleTimeString()}</span>}
        <Button size="icon" variant="ghost" className="h-6 w-6 ml-1 text-emerald-400 hover:text-emerald-300" onClick={runScan}>
          <RefreshCw className="w-3 h-3" />
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <span className="text-sm font-semibold text-foreground">Inventory Alerts</span>
          {critical.length > 0 && (
            <Badge className="text-[9px] h-4 px-1.5 bg-red-500/15 text-red-400 border-red-500/30">
              {critical.length} OUT OF STOCK
            </Badge>
          )}
          {low.length > 0 && (
            <Badge className="text-[9px] h-4 px-1.5 bg-amber-500/15 text-amber-400 border-amber-500/30">
              {low.length} LOW STOCK
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {lastScan && <span className="text-[10px] text-muted-foreground">Scanned {lastScan.toLocaleTimeString()}</span>}
          <Button
            size="sm"
            variant="ghost"
            className="h-7 text-xs gap-1.5"
            onClick={runScan}
            disabled={scanning}
          >
            <RefreshCw className={`w-3 h-3 ${scanning ? 'animate-spin' : ''}`} />
            {scanning ? 'Scanning...' : 'Scan Now'}
          </Button>
        </div>
      </div>

      {/* Alert rows */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-2">
        {alerts.map(item => (
          <AlertCard key={item.id} item={item} />
        ))}
      </div>
    </div>
  );
}

function AlertCard({ item }) {
  const [creatingPO, setCreatingPO] = useState(false);
  const isOut = item.status === 'OUT_OF_STOCK';

  const handleCreatePO = async () => {
    setCreatingPO(true);
    try {
      await base44.functions.invoke('productionAIOrchestrator', {
        action: 'scan_low_stock',
      });
      toast.success(`Purchase order triggered for ${item.name}`);
    } catch {
      toast.error('Failed to create PO');
    } finally {
      setCreatingPO(false);
    }
  };

  return (
    <div className={`rounded-xl border p-3 space-y-2 ${isOut ? 'border-red-500/40 bg-red-500/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            {isOut
              ? <XCircle className="w-3.5 h-3.5 text-red-400 shrink-0" />
              : <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            }
            <p className="text-xs font-semibold truncate">{item.name}</p>
          </div>
          <p className="text-[10px] text-muted-foreground font-mono mt-0.5">{item.sku}</p>
        </div>
        <Badge className={`text-[9px] h-4 px-1.5 shrink-0 ${isOut ? 'bg-red-500/20 text-red-400' : 'bg-amber-500/20 text-amber-400'}`}>
          {isOut ? 'OUT' : 'LOW'}
        </Badge>
      </div>

      <div className="flex items-center gap-3 text-[10px]">
        <span className={`font-bold text-sm ${isOut ? 'text-red-400' : 'text-amber-400'}`}>
          {item.quantity_on_hand}
        </span>
        <span className="text-muted-foreground">/ {item.threshold} threshold</span>
      </div>

      {/* Stock bar */}
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div
          className={`h-full rounded-full transition-all ${isOut ? 'bg-red-500' : 'bg-amber-500'}`}
          style={{ width: `${Math.min(100, item.threshold > 0 ? (item.quantity_on_hand / item.threshold) * 100 : 0)}%` }}
        />
      </div>

      <Button
        size="sm"
        variant="outline"
        className="w-full h-6 text-[10px] gap-1"
        onClick={handleCreatePO}
        disabled={creatingPO}
      >
        <ShoppingCart className="w-3 h-3" />
        {creatingPO ? 'Creating PO...' : 'Auto-Reorder'}
      </Button>
    </div>
  );
}