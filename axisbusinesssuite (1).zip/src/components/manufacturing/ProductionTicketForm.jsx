import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Loader2, Package, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';

export default function ProductionTicketForm({ open, onClose, ticket, onSaved }) {
  const [form, setForm] = useState({
    ticket_number: '', product_name: '', sku: '', account_name: '',
    quantity: 1, unit_cost: 0, unit_price: 0,
    source_type: 'build_to_order',
    supplier_id: '', supplier_name: '',
    priority: 'medium', status: 'backlog',
    due_date: '', assigned_to: '', estimated_hours: 0,
    notes: '', specifications: '',
    raw_materials: '[]',
    payment_status: 'unpaid',
  });
  const [rawMaterials, setRawMaterials] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [inventoryItems, setInventoryItems] = useState([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      base44.entities.Supplier.filter({ is_active: true }).then(setSuppliers).catch(() => {});
      base44.entities.InventoryItem.filter({ status: 'active' }).then(setInventoryItems).catch(() => {});
    }
  }, [open]);

  useEffect(() => {
    if (ticket) {
      setForm({ ...ticket });
      try { setRawMaterials(JSON.parse(ticket.raw_materials || '[]')); } catch { setRawMaterials([]); }
    } else {
      const num = `PT-${Date.now().toString().slice(-6)}`;
      setForm(f => ({ ...f, ticket_number: num }));
      setRawMaterials([]);
    }
  }, [ticket, open]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const addMaterial = () => setRawMaterials(m => [...m, { name: '', sku: '', qty: 1, unit_cost: 0, supplier_id: '' }]);
  const removeMaterial = (i) => setRawMaterials(m => m.filter((_, idx) => idx !== i));
  const updateMaterial = (i, k, v) => setRawMaterials(m => m.map((mat, idx) => idx === i ? { ...mat, [k]: v } : mat));

  const handleSave = async () => {
    if (!form.product_name.trim()) { toast.error('Product name is required'); return; }
    setSaving(true);
    const totalCost = (Number(form.unit_cost) || 0) * (Number(form.quantity) || 1);
    const totalRevenue = (Number(form.unit_price) || 0) * (Number(form.quantity) || 1);
    const payload = {
      ...form,
      total_cost: totalCost,
      total_revenue: totalRevenue,
      quantity: Number(form.quantity) || 1,
      unit_cost: Number(form.unit_cost) || 0,
      unit_price: Number(form.unit_price) || 0,
      estimated_hours: Number(form.estimated_hours) || 0,
      raw_materials: JSON.stringify(rawMaterials),
    };
    if (form.supplier_id) {
      const sup = suppliers.find(s => s.id === form.supplier_id);
      if (sup) payload.supplier_name = sup.supplier_name;
    }
    if (ticket?.id) {
      await base44.entities.ProductionTicket.update(ticket.id, payload);
    } else {
      await base44.entities.ProductionTicket.create({ ...payload, owner: '' });
    }
    setSaving(false);
    toast.success(ticket ? 'Ticket updated' : 'Ticket created');
    onSaved();
    onClose();
  };

  const materialTotal = rawMaterials.reduce((s, m) => s + (Number(m.qty) * Number(m.unit_cost) || 0), 0);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5 text-primary" />
            {ticket ? 'Edit Production Ticket' : 'New Production Ticket'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Ticket # <span className="text-primary">*</span></Label>
              <Input value={form.ticket_number} onChange={e => set('ticket_number', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Customer / Account</Label>
              <Input value={form.account_name} onChange={e => set('account_name', e.target.value)} className="mt-1 text-sm" placeholder="Customer name" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Product Name <span className="text-primary">*</span></Label>
              <Input value={form.product_name} onChange={e => set('product_name', e.target.value)} className="mt-1 text-sm" placeholder="Product name" />
            </div>
            <div>
              <Label className="text-xs">SKU</Label>
              <Input value={form.sku} onChange={e => set('sku', e.target.value)} className="mt-1 text-sm" placeholder="SKU-001" />
            </div>
          </div>

          {/* Source Type */}
          <div>
            <Label className="text-xs">Fulfillment Type</Label>
            <div className="grid grid-cols-3 gap-2 mt-2">
              {[
                { v: 'build_to_order', label: 'Build to Order', desc: 'Manufacture from scratch' },
                { v: 'from_inventory', label: 'From Inventory', desc: 'Pull from stock' },
                { v: 'partial_inventory', label: 'Partial Stock', desc: 'Mix of both' },
              ].map(opt => (
                <button key={opt.v} onClick={() => set('source_type', opt.v)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${form.source_type === opt.v ? 'border-primary bg-primary/10' : 'border-border hover:border-muted-foreground'}`}>
                  <p className="text-xs font-semibold">{opt.label}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{opt.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Quantities & Pricing */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Quantity</Label>
              <Input type="number" min={1} value={form.quantity} onChange={e => set('quantity', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Unit Cost ($)</Label>
              <Input type="number" min={0} step="0.01" value={form.unit_cost} onChange={e => set('unit_cost', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Sale Price ($)</Label>
              <Input type="number" min={0} step="0.01" value={form.unit_price} onChange={e => set('unit_price', e.target.value)} className="mt-1 text-sm" />
            </div>
          </div>

          {/* Financial Preview */}
          <div className="bg-muted/30 rounded-xl p-3 grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-[10px] text-muted-foreground">Total Cost</p>
              <p className="text-sm font-bold">${((form.unit_cost || 0) * (form.quantity || 1)).toFixed(2)}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">Total Revenue</p>
              <p className="text-sm font-bold text-emerald-400">${((form.unit_price || 0) * (form.quantity || 1)).toFixed(2)}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground">Gross Profit</p>
              <p className={`text-sm font-bold ${((form.unit_price - form.unit_cost) * form.quantity) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                ${(((form.unit_price || 0) - (form.unit_cost || 0)) * (form.quantity || 1)).toFixed(2)}
              </p>
            </div>
          </div>

          {/* Supplier */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Primary Supplier</Label>
              <Select value={form.supplier_id} onValueChange={v => set('supplier_id', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {suppliers.map(s => <SelectItem key={s.id} value={s.id}>{s.supplier_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Due Date</Label>
              <Input type="date" value={form.due_date} onChange={e => set('due_date', e.target.value)} className="mt-1 text-sm" />
            </div>
          </div>

          {/* Status & Priority */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={v => set('status', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['backlog','waiting_materials','queued','in_progress','quality_check','completed','on_hold','cancelled'].map(s => (
                    <SelectItem key={s} value={s}>{s.replace(/_/g,' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Priority</Label>
              <Select value={form.priority} onValueChange={v => set('priority', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['low','medium','high','urgent'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Payment Status</Label>
              <Select value={form.payment_status} onValueChange={v => set('payment_status', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['unpaid','deposit_paid','paid','refunded'].map(p => <SelectItem key={p} value={p}>{p.replace(/_/g,' ')}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Raw Materials (build_to_order) */}
          {form.source_type !== 'from_inventory' && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs">Raw Materials / Components</Label>
                <Button size="sm" variant="outline" className="h-6 text-xs px-2 gap-1" onClick={addMaterial}>
                  <Plus className="w-3 h-3" /> Add
                </Button>
              </div>
              <div className="space-y-2">
                {rawMaterials.map((mat, i) => (
                  <div key={i} className="grid grid-cols-5 gap-2 items-center bg-muted/20 p-2 rounded-lg">
                    <Input placeholder="Material name" value={mat.name} onChange={e => updateMaterial(i, 'name', e.target.value)} className="col-span-2 text-xs h-7" />
                    <Input placeholder="Qty" type="number" min={0} value={mat.qty} onChange={e => updateMaterial(i, 'qty', e.target.value)} className="text-xs h-7" />
                    <Input placeholder="Unit cost" type="number" min={0} value={mat.unit_cost} onChange={e => updateMaterial(i, 'unit_cost', e.target.value)} className="text-xs h-7" />
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => removeMaterial(i)}>
                      <Trash2 className="w-3 h-3 text-destructive" />
                    </Button>
                  </div>
                ))}
                {rawMaterials.length > 0 && (
                  <p className="text-xs text-muted-foreground text-right">Materials total: <span className="font-semibold">${materialTotal.toFixed(2)}</span></p>
                )}
              </div>
            </div>
          )}

          {/* Specs & Notes */}
          <div>
            <Label className="text-xs">Specifications / Notes</Label>
            <Textarea value={form.notes} onChange={e => set('notes', e.target.value)} className="mt-1 text-sm resize-none" rows={3} placeholder="Production notes, special requirements, QC criteria..." />
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2 border-t border-border">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={handleSave} disabled={saving} className="gap-2">
            {saving && <Loader2 className="w-3 h-3 animate-spin" />}
            {ticket ? 'Update Ticket' : 'Create Ticket'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}