import React from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import {
  Package, DollarSign, Truck, Clock, CheckCircle2, AlertTriangle,
  Pause, XCircle, Edit, Calendar, User, Hash, Tag, Layers,
  TrendingUp, BarChart2, ShoppingCart, Wrench
} from 'lucide-react';
import { toast } from 'sonner';

const STATUS_CONFIG = {
  backlog:           { label: 'Backlog',           color: 'bg-muted text-muted-foreground', icon: Clock },
  waiting_materials: { label: 'Waiting Materials', color: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: AlertTriangle },
  queued:            { label: 'Queued',            color: 'bg-blue-500/15 text-blue-400 border-blue-500/30', icon: Clock },
  in_progress:       { label: 'In Progress',       color: 'bg-primary/15 text-primary border-primary/30', icon: Package },
  quality_check:     { label: 'QC Check',          color: 'bg-purple-500/15 text-purple-400 border-purple-500/30', icon: CheckCircle2 },
  completed:         { label: 'Completed',         color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  on_hold:           { label: 'On Hold',           color: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: Pause },
  cancelled:         { label: 'Cancelled',         color: 'bg-red-500/15 text-red-400 border-red-500/30', icon: XCircle },
};

const SOURCE_LABEL = {
  build_to_order: { label: 'Build to Order', icon: '🔨', color: 'bg-blue-500/15 text-blue-400' },
  from_inventory: { label: 'From Inventory', icon: '📦', color: 'bg-emerald-500/15 text-emerald-400' },
  partial_inventory: { label: 'Partial Stock', icon: '🔀', color: 'bg-amber-500/15 text-amber-400' },
};

const PRIORITY_COLOR = {
  low: 'bg-slate-500/15 text-slate-400',
  medium: 'bg-blue-500/15 text-blue-400',
  high: 'bg-orange-500/15 text-orange-400',
  urgent: 'bg-red-500/15 text-red-400',
};

const PAY_COLOR = {
  unpaid: 'bg-red-500/15 text-red-400',
  deposit_paid: 'bg-amber-500/15 text-amber-400',
  paid: 'bg-emerald-500/15 text-emerald-400',
  refunded: 'bg-muted text-muted-foreground',
};

function InfoRow({ icon: Icon, label, value, valueClass = '' }) {
  if (!value && value !== 0) return null;
  return (
    <div className="flex items-start gap-2.5 py-2 border-b border-border/40 last:border-0">
      <Icon className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
      <span className="text-xs text-muted-foreground w-28 shrink-0">{label}</span>
      <span className={`text-xs font-medium flex-1 ${valueClass}`}>{value}</span>
    </div>
  );
}

export default function TicketDetailDrawer({ ticket, open, onClose, onEdit, onRefresh }) {
  if (!ticket) return null;

  const cfg = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.backlog;
  const Icon = cfg.icon;
  const src = SOURCE_LABEL[ticket.source_type] || SOURCE_LABEL.build_to_order;
  const margin = ticket.total_revenue > 0
    ? (((ticket.total_revenue - ticket.total_cost) / ticket.total_revenue) * 100).toFixed(1)
    : null;
  const isOverdue = ticket.due_date && new Date(ticket.due_date) < new Date() && ticket.status !== 'completed' && ticket.status !== 'cancelled';

  let rawMaterials = [];
  try { rawMaterials = JSON.parse(ticket.raw_materials || '[]'); } catch {}

  let specs = null;
  try { specs = ticket.specifications ? JSON.parse(ticket.specifications) : null; } catch {}

  const handleStatusChange = async (newStatus) => {
    const updates = { status: newStatus };
    if (newStatus === 'in_progress' && !ticket.started_at) updates.started_at = new Date().toISOString();
    if (newStatus === 'completed') updates.completed_at = new Date().toISOString();
    await base44.entities.ProductionTicket.update(ticket.id, updates);
    toast.success(`Status → ${STATUS_CONFIG[newStatus]?.label}`);
    onRefresh();
  };

  const hoursProgress = ticket.estimated_hours > 0
    ? Math.min(100, ((ticket.actual_hours || 0) / ticket.estimated_hours) * 100)
    : null;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
        <SheetHeader className="pb-4">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <span className="text-base">{src.icon}</span>
                <SheetTitle className="text-base leading-snug">{ticket.product_name}</SheetTitle>
                {isOverdue && <Badge className="text-[9px] bg-red-500/15 text-red-400 border-red-500/30">OVERDUE</Badge>}
              </div>
              <p className="text-xs text-muted-foreground">{ticket.ticket_number}{ticket.account_name ? ` · ${ticket.account_name}` : ''}</p>
            </div>
            <Button size="sm" variant="outline" className="gap-1.5 shrink-0" onClick={() => { onClose(); onEdit(ticket); }}>
              <Edit className="w-3.5 h-3.5" /> Edit
            </Button>
          </div>

          {/* Status + Priority row */}
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge className={`gap-1 ${cfg.color}`}><Icon className="w-3 h-3" />{cfg.label}</Badge>
            <Badge className={`capitalize ${PRIORITY_COLOR[ticket.priority] || ''}`}>▲ {ticket.priority}</Badge>
            <Badge className={src.color}>{src.icon} {src.label}</Badge>
            {ticket.payment_status && <Badge className={PAY_COLOR[ticket.payment_status] || 'bg-muted text-muted-foreground'}>{ticket.payment_status.replace(/_/g, ' ')}</Badge>}
          </div>

          {/* Quick status change */}
          <div className="mt-3">
            <p className="text-[10px] text-muted-foreground mb-1">Update Status</p>
            <Select value={ticket.status} onValueChange={handleStatusChange}>
              <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(STATUS_CONFIG).map(([v, c]) => (
                  <SelectItem key={v} value={v}>{c.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </SheetHeader>

        <div className="space-y-5 pb-6">
          {/* Financial Summary */}
          <div className="grid grid-cols-3 gap-2 p-3 rounded-xl bg-muted/30 border border-border/50">
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground">Revenue</p>
              <p className="text-sm font-bold text-emerald-400">${(ticket.total_revenue || 0).toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">${ticket.unit_price || 0} × {ticket.quantity}</p>
            </div>
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground">Cost</p>
              <p className="text-sm font-bold text-primary">${(ticket.total_cost || 0).toLocaleString()}</p>
              <p className="text-[9px] text-muted-foreground">${ticket.unit_cost || 0} × {ticket.quantity}</p>
            </div>
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground">Profit</p>
              <p className={`text-sm font-bold ${(ticket.total_revenue - ticket.total_cost) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                ${((ticket.total_revenue || 0) - (ticket.total_cost || 0)).toLocaleString()}
              </p>
              {margin && <p className="text-[9px] text-muted-foreground">{margin}% margin</p>}
            </div>
          </div>

          {/* Hours Progress */}
          {hoursProgress !== null && (
            <div>
              <div className="flex justify-between text-[10px] text-muted-foreground mb-1.5">
                <span>Hours: {ticket.actual_hours || 0} / {ticket.estimated_hours} est.</span>
                <span className={hoursProgress > 100 ? 'text-red-400' : 'text-emerald-400'}>{hoursProgress.toFixed(0)}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${hoursProgress > 100 ? 'bg-red-500' : hoursProgress > 80 ? 'bg-amber-500' : 'bg-primary'}`}
                  style={{ width: `${Math.min(100, hoursProgress)}%` }}
                />
              </div>
            </div>
          )}

          {/* Product Details */}
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Product Details</p>
            <div className="rounded-xl border border-border/50 overflow-hidden bg-card/50 px-3">
              <InfoRow icon={Hash} label="SKU" value={ticket.sku} />
              <InfoRow icon={Layers} label="Quantity" value={`${ticket.quantity} units`} />
              <InfoRow icon={Tag} label="Unit Cost" value={`$${ticket.unit_cost || 0}`} />
              <InfoRow icon={DollarSign} label="Sale Price" value={`$${ticket.unit_price || 0}`} valueClass="text-emerald-400" />
              <InfoRow icon={User} label="Customer" value={ticket.account_name} />
              <InfoRow icon={User} label="Assigned To" value={ticket.assigned_to} />
              <InfoRow icon={Calendar} label="Due Date" value={ticket.due_date ? new Date(ticket.due_date).toLocaleDateString() : null} valueClass={isOverdue ? 'text-red-400' : ''} />
              <InfoRow icon={Calendar} label="Started" value={ticket.started_at ? new Date(ticket.started_at).toLocaleString() : null} />
              <InfoRow icon={Calendar} label="Completed" value={ticket.completed_at ? new Date(ticket.completed_at).toLocaleString() : null} valueClass="text-emerald-400" />
              <InfoRow icon={Truck} label="Supplier" value={ticket.supplier_name} />
              <InfoRow icon={Calendar} label="Supplier ETA" value={ticket.supplier_eta ? new Date(ticket.supplier_eta).toLocaleDateString() : null} />
            </div>
          </div>

          {/* Supplier Order Status */}
          {ticket.supplier_name && (
            <div className="flex items-center gap-3 p-3 rounded-xl border border-border/50 bg-muted/20">
              <Truck className="w-4 h-4 text-muted-foreground shrink-0" />
              <div className="flex-1">
                <p className="text-xs font-semibold">{ticket.supplier_name}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  Order sent: {ticket.supplier_order_sent ? '✅' : '❌'} &nbsp;|&nbsp;
                  Confirmed: {ticket.supplier_order_confirmed ? '✅' : '❌'}
                  {ticket.supplier_eta && ` | ETA: ${new Date(ticket.supplier_eta).toLocaleDateString()}`}
                </p>
              </div>
            </div>
          )}

          {/* Raw Materials */}
          {rawMaterials.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">
                Raw Materials / Components ({rawMaterials.length})
              </p>
              <div className="rounded-xl border border-border/50 overflow-hidden">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="bg-muted/30 border-b border-border">
                      <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground">Material</th>
                      <th className="px-3 py-2 text-right text-[10px] font-semibold text-muted-foreground">Qty</th>
                      <th className="px-3 py-2 text-right text-[10px] font-semibold text-muted-foreground">Unit Cost</th>
                      <th className="px-3 py-2 text-right text-[10px] font-semibold text-muted-foreground">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/50">
                    {rawMaterials.map((m, i) => (
                      <tr key={i} className="hover:bg-muted/20">
                        <td className="px-3 py-2 font-medium">{m.name || '—'}{m.sku && <span className="text-muted-foreground ml-1 font-normal">({m.sku})</span>}</td>
                        <td className="px-3 py-2 text-right text-muted-foreground">{m.qty}</td>
                        <td className="px-3 py-2 text-right text-muted-foreground">${m.unit_cost || 0}</td>
                        <td className="px-3 py-2 text-right font-semibold">${((m.qty || 0) * (m.unit_cost || 0)).toFixed(2)}</td>
                      </tr>
                    ))}
                    <tr className="bg-muted/20 font-semibold">
                      <td colSpan={3} className="px-3 py-2 text-right text-muted-foreground">Materials Total</td>
                      <td className="px-3 py-2 text-right text-primary">
                        ${rawMaterials.reduce((s, m) => s + ((m.qty || 0) * (m.unit_cost || 0)), 0).toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Specs */}
          {specs && Object.keys(specs).length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-2">Specifications</p>
              <div className="rounded-xl border border-border/50 bg-card/50 px-3 py-1">
                {Object.entries(specs).map(([k, v]) => (
                  <div key={k} className="flex items-center justify-between py-1.5 border-b border-border/30 last:border-0 text-xs">
                    <span className="text-muted-foreground capitalize">{k.replace(/_/g, ' ')}</span>
                    <span className="font-medium">{String(v)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* QC */}
          {(ticket.status === 'quality_check' || ticket.status === 'completed') && (
            <div className={`p-3 rounded-xl border ${ticket.quality_check_passed ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
              <div className="flex items-center gap-2">
                <CheckCircle2 className={`w-4 h-4 ${ticket.quality_check_passed ? 'text-emerald-400' : 'text-amber-400'}`} />
                <p className="text-xs font-semibold">{ticket.quality_check_passed ? 'QC Passed' : 'QC Pending / Failed'}</p>
              </div>
              {ticket.quality_check_notes && <p className="text-xs text-muted-foreground mt-1">{ticket.quality_check_notes}</p>}
            </div>
          )}

          {/* Notes */}
          {ticket.notes && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground mb-1">Notes</p>
              <p className="text-xs text-muted-foreground bg-muted/20 rounded-xl p-3 leading-relaxed">{ticket.notes}</p>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}