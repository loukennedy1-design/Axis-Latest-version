import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Plug, Globe, Phone, Mail, Star, Loader2, CheckCircle2, AlertTriangle, Link2 } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_STYLE = {
  connected: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  not_connected: 'bg-muted text-muted-foreground',
  error: 'bg-red-500/15 text-red-400 border-red-500/30',
};

const INTEGRATION_ICONS = {
  api: <Link2 className="w-3 h-3" />,
  email: <Mail className="w-3 h-3" />,
  edi: <Globe className="w-3 h-3" />,
  portal: <Plug className="w-3 h-3" />,
  none: null,
};

function SupplierForm({ supplier, onSave, onClose }) {
  const [form, setForm] = useState(supplier || {
    supplier_name: '', supplier_code: '', contact_name: '', email: '', phone: '',
    website: '', api_endpoint: '', api_key: '', integration_type: 'none',
    payment_terms: 'Net 30', currency: 'USD', lead_time_days: 0, minimum_order: 0,
    is_preferred: false, is_active: true, notes: '',
  });
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.supplier_name.trim()) { toast.error('Supplier name required'); return; }
    setSaving(true);
    const payload = { ...form, lead_time_days: Number(form.lead_time_days) || 0, minimum_order: Number(form.minimum_order) || 0 };
    if (payload.integration_type !== 'none' && payload.api_endpoint) {
      payload.integration_status = 'connected';
    }
    if (supplier?.id) {
      await base44.entities.Supplier.update(supplier.id, payload);
    } else {
      await base44.entities.Supplier.create(payload);
    }
    setSaving(false);
    toast.success(supplier ? 'Supplier updated' : 'Supplier added');
    onSave();
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plug className="w-5 h-5 text-primary" />
            {supplier ? 'Edit Supplier' : 'Add Supplier'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Supplier Name *</Label>
              <Input value={form.supplier_name} onChange={e => set('supplier_name', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Supplier Code</Label>
              <Input value={form.supplier_code} onChange={e => set('supplier_code', e.target.value)} className="mt-1 text-sm" placeholder="SUP-001" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Contact Name</Label>
              <Input value={form.contact_name} onChange={e => set('contact_name', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Email</Label>
              <Input type="email" value={form.email} onChange={e => set('email', e.target.value)} className="mt-1 text-sm" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Phone</Label>
              <Input value={form.phone} onChange={e => set('phone', e.target.value)} className="mt-1 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Website</Label>
              <Input value={form.website} onChange={e => set('website', e.target.value)} className="mt-1 text-sm" placeholder="https://" />
            </div>
          </div>

          {/* Integration */}
          <div className="p-3 rounded-xl border border-border bg-muted/20">
            <p className="text-xs font-semibold mb-3 text-muted-foreground uppercase tracking-wide">Direct Integration</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Integration Type</Label>
                <Select value={form.integration_type} onValueChange={v => set('integration_type', v)}>
                  <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None (manual)</SelectItem>
                    <SelectItem value="email">Email orders</SelectItem>
                    <SelectItem value="api">API integration</SelectItem>
                    <SelectItem value="edi">EDI</SelectItem>
                    <SelectItem value="portal">Supplier portal</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Lead Time (days)</Label>
                <Input type="number" min={0} value={form.lead_time_days} onChange={e => set('lead_time_days', e.target.value)} className="mt-1 text-sm" />
              </div>
            </div>
            {(form.integration_type === 'api' || form.integration_type === 'edi') && (
              <div className="mt-3 space-y-2">
                <div>
                  <Label className="text-xs">API Endpoint / EDI URL</Label>
                  <Input value={form.api_endpoint} onChange={e => set('api_endpoint', e.target.value)} className="mt-1 text-sm" placeholder="https://api.supplier.com/orders" />
                </div>
                <div>
                  <Label className="text-xs">API Key</Label>
                  <Input type="password" value={form.api_key} onChange={e => set('api_key', e.target.value)} className="mt-1 text-sm" placeholder="••••••••" />
                </div>
              </div>
            )}
            {form.integration_type === 'portal' && (
              <div className="mt-3">
                <Label className="text-xs">Portal URL</Label>
                <Input value={form.api_endpoint} onChange={e => set('api_endpoint', e.target.value)} className="mt-1 text-sm" placeholder="https://supplier-portal.com" />
              </div>
            )}
          </div>

          {/* Terms */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label className="text-xs">Payment Terms</Label>
              <Select value={form.payment_terms} onValueChange={v => set('payment_terms', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['Net 15','Net 30','Net 45','Net 60','Due on receipt','Prepaid'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Currency</Label>
              <Select value={form.currency} onValueChange={v => set('currency', v)}>
                <SelectTrigger className="mt-1 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['USD','EUR','GBP','CAD','AUD'].map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Min. Order ($)</Label>
              <Input type="number" min={0} value={form.minimum_order} onChange={e => set('minimum_order', e.target.value)} className="mt-1 text-sm" />
            </div>
          </div>

          <div>
            <Label className="text-xs">Notes</Label>
            <Textarea value={form.notes} onChange={e => set('notes', e.target.value)} className="mt-1 text-sm resize-none" rows={2} />
          </div>
        </div>
        <div className="flex justify-end gap-2 pt-2 border-t border-border">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={handleSave} disabled={saving} className="gap-2">
            {saving && <Loader2 className="w-3 h-3 animate-spin" />} Save Supplier
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function SupplierManager({ suppliers, onRefresh }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Suppliers ({suppliers.length})</h3>
        <Button size="sm" variant="outline" className="gap-1.5 text-xs h-7" onClick={() => { setEditing(null); setShowForm(true); }}>
          <Plus className="w-3 h-3" /> Add Supplier
        </Button>
      </div>

      {suppliers.length === 0 ? (
        <Card className="border-dashed border-border">
          <CardContent className="py-8 text-center">
            <Plug className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No suppliers yet. Add your first supplier to connect your supply chain.</p>
            <Button size="sm" className="mt-3 gap-1.5" onClick={() => { setEditing(null); setShowForm(true); }}>
              <Plus className="w-3 h-3" /> Add Supplier
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {suppliers.map(sup => (
            <Card key={sup.id} className="border-border/60 hover:border-primary/30 transition-colors cursor-pointer" onClick={() => { setEditing(sup); setShowForm(true); }}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold truncate">{sup.supplier_name}</p>
                      {sup.is_preferred && <Badge className="text-[9px] h-4 px-1.5 bg-amber-500/15 text-amber-400 border-amber-500/30">⭐ Preferred</Badge>}
                    </div>
                    {sup.contact_name && <p className="text-xs text-muted-foreground mt-0.5">{sup.contact_name}</p>}
                  </div>
                  <Badge className={`text-[9px] shrink-0 ${STATUS_STYLE[sup.integration_status || 'not_connected']}`}>
                    {sup.integration_status === 'connected' ? <CheckCircle2 className="w-2.5 h-2.5 mr-1" /> : null}
                    {(sup.integration_status || 'not connected').replace(/_/g, ' ')}
                  </Badge>
                </div>
                <div className="flex flex-wrap gap-2 mt-3 text-[10px] text-muted-foreground">
                  {sup.email && <span className="flex items-center gap-1"><Mail className="w-2.5 h-2.5" />{sup.email}</span>}
                  {sup.phone && <span className="flex items-center gap-1"><Phone className="w-2.5 h-2.5" />{sup.phone}</span>}
                  {sup.lead_time_days > 0 && <span>Lead time: {sup.lead_time_days}d</span>}
                  {sup.payment_terms && <span>{sup.payment_terms}</span>}
                  {sup.integration_type && sup.integration_type !== 'none' && (
                    <span className="flex items-center gap-1 text-primary/70">
                      {INTEGRATION_ICONS[sup.integration_type]}
                      {sup.integration_type.toUpperCase()}
                    </span>
                  )}
                </div>
                {sup.total_spend > 0 && (
                  <p className="text-xs text-emerald-400 mt-2">Total spend: ${sup.total_spend.toLocaleString()}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {showForm && (
        <SupplierForm
          supplier={editing}
          onSave={onRefresh}
          onClose={() => { setShowForm(false); setEditing(null); }}
        />
      )}
    </div>
  );
}