import React, { useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Plus, Trash2, FileText, CheckCircle2, Clock, XCircle, Send,
  ArrowRight, Package, ChevronDown, ChevronUp, Edit2,
  Layers, Tag, Printer, RefreshCw, TrendingUp
} from 'lucide-react';
import { toast } from 'sonner';

// ── Constants ─────────────────────────────────────────────────────────────────

const STATUS_CONFIG = {
  draft:    { label: 'Draft',    color: 'bg-muted text-muted-foreground', icon: Clock },
  sent:     { label: 'Sent',     color: 'bg-blue-500/15 text-blue-400 border-blue-500/30', icon: Send },
  accepted: { label: 'Accepted', color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-red-500/15 text-red-400 border-red-500/30', icon: XCircle },
  expired:  { label: 'Expired',  color: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: Clock },
};

const ITEM_TYPES = [
  { value: 'finished_product', label: 'Finished Product / Service' },
  { value: 'raw_material',     label: 'Raw Material / Component' },
  { value: 'labor',            label: 'Labor / Time' },
  { value: 'overhead',         label: 'Overhead / Fee' },
  { value: 'shipping',         label: 'Shipping / Delivery' },
  { value: 'discount',         label: 'Discount' },
  { value: 'custom',           label: 'Custom Line' },
];

const UNITS = ['each', 'unit', 'hr', 'day', 'kg', 'lb', 'ft', 'm', 'sqft', 'sqm', 'liter', 'gallon', 'box', 'pallet', 'lot', '%'];

function emptyLine() {
  return {
    type: 'finished_product', description: '', sku: '',
    quantity: 1, unit: 'each',
    unit_cost: 0, unit_price: 0,
    labor_hours: 0, labor_rate: 0,
    overhead_pct: 0,
    notes: '', raw_materials: []
  };
}

function emptyMaterial() {
  return { name: '', sku: '', quantity: 1, unit: 'each', unit_cost: 0 };
}

// ── Cost Calculation Helpers ──────────────────────────────────────────────────

/** Roll up all cost sources for a single line item */
function calcLineCosts(line) {
  const qty        = Number(line.quantity)     || 0;
  const unitPrice  = Number(line.unit_price)   || 0;

  // Materials cost
  const matCostPer = (line.raw_materials || []).reduce(
    (s, m) => s + ((Number(m.quantity) || 0) * (Number(m.unit_cost) || 0)), 0
  );

  // Labor cost per unit
  const laborCostPer = (Number(line.labor_hours) || 0) * (Number(line.labor_rate) || 0);

  // Use explicit unit_cost if user set it AND no raw materials — else derive
  const hasMaterials = (line.raw_materials || []).length > 0;
  const derivedUnitCost = hasMaterials
    ? matCostPer + laborCostPer
    : (Number(line.unit_cost) || 0) + laborCostPer;

  // Overhead %
  const overheadPct = Number(line.overhead_pct) || 0;
  const overhead = derivedUnitCost * (overheadPct / 100);
  const unitCostFinal = derivedUnitCost + overhead;

  const totalCost    = unitCostFinal * qty;
  const totalRevenue = unitPrice * qty * (line.type === 'discount' ? -1 : 1);
  const profit       = totalRevenue - totalCost;
  const margin       = totalRevenue > 0 ? (profit / totalRevenue) * 100 : null;

  return { matCostPer, laborCostPer, overhead, unitCostFinal, totalCost, totalRevenue, profit, margin };
}

// ── Line Item Row ─────────────────────────────────────────────────────────────

function LineItemRow({ item, idx, onChange, onRemove, expanded, onToggle }) {
  const costs = calcLineCosts(item);
  const isDiscount = item.type === 'discount';

  const addMaterial = () => onChange(idx, 'raw_materials', [...(item.raw_materials || []), emptyMaterial()]);
  const updateMaterial = (mi, k, v) => {
    const mats = [...(item.raw_materials || [])];
    mats[mi] = { ...mats[mi], [k]: v };
    onChange(idx, 'raw_materials', mats);
  };
  const removeMaterial = (mi) => onChange(idx, 'raw_materials', (item.raw_materials || []).filter((_, i) => i !== mi));

  const hasMaterials = (item.raw_materials || []).length > 0;

  return (
    <div className={`rounded-xl border transition-all ${expanded ? 'border-primary/40 bg-primary/5' : 'border-border/60 bg-card/50'}`}>
      {/* ── Main Row ── */}
      <div className="p-3 space-y-2">
        {/* Row 1: Type + Description + actions */}
        <div className="flex items-center gap-2">
          <select
            value={item.type}
            onChange={e => onChange(idx, 'type', e.target.value)}
            className="w-44 shrink-0 rounded-md border border-input bg-transparent px-2 py-1.5 text-xs outline-none focus:ring-1 ring-ring"
          >
            {ITEM_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
          <input
            value={item.description}
            onChange={e => onChange(idx, 'description', e.target.value)}
            placeholder="Description / product name..."
            className="flex-1 min-w-0 rounded-md border border-input bg-transparent px-2 py-1.5 text-sm outline-none focus:ring-1 ring-ring"
          />
          <button onClick={onToggle}
            className="p-1.5 rounded-lg hover:bg-muted/40 text-muted-foreground hover:text-foreground transition-colors shrink-0"
            title="Edit details / raw materials">
            {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
          <button onClick={() => onRemove(idx)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors shrink-0">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Row 2: SKU + Qty + Unit + Cost + Price + Total */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* SKU */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide shrink-0">SKU</span>
            <input value={item.sku} onChange={e => onChange(idx, 'sku', e.target.value)} placeholder="SKU"
              className="w-24 rounded-md border border-input bg-transparent px-2 py-1 text-xs font-mono outline-none focus:ring-1 ring-ring" />
          </div>

          <div className="w-px h-4 bg-border/50 hidden sm:block" />

          {/* Qty */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide shrink-0">Qty</span>
            <input type="number" min={0} value={item.quantity} onChange={e => onChange(idx, 'quantity', e.target.value)}
              className="w-16 rounded-md border border-input bg-transparent px-2 py-1 text-xs text-center outline-none focus:ring-1 ring-ring" />
          </div>

          {/* Unit */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide shrink-0">Unit</span>
            <select value={item.unit} onChange={e => onChange(idx, 'unit', e.target.value)}
              className="w-20 rounded-md border border-input bg-transparent px-2 py-1 text-xs outline-none focus:ring-1 ring-ring">
              {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </div>

          <div className="w-px h-4 bg-border/50 hidden sm:block" />

          {/* Unit Cost */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide shrink-0">Cost</span>
            {hasMaterials ? (
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold text-primary">${costs.unitCostFinal.toFixed(2)}</span>
                <span className="text-[9px] text-muted-foreground">(auto)</span>
              </div>
            ) : (
              <div className="relative">
                <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">$</span>
                <input type="number" min={0} step="0.01" value={item.unit_cost} onChange={e => onChange(idx, 'unit_cost', e.target.value)}
                  className="w-24 pl-5 rounded-md border border-input bg-transparent pr-2 py-1 text-xs outline-none focus:ring-1 ring-ring" />
              </div>
            )}
          </div>

          {/* Unit Price */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide shrink-0">Price</span>
            <div className="relative">
              <span className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">$</span>
              <input type="number" min={0} step="0.01" value={item.unit_price} onChange={e => onChange(idx, 'unit_price', e.target.value)}
                className={`w-24 pl-5 rounded-md border border-input bg-transparent pr-2 py-1 text-xs outline-none focus:ring-1 ring-ring ${isDiscount ? 'text-red-400' : ''}`} />
            </div>
          </div>

          {/* Line Total */}
          <div className="ml-auto flex items-center gap-2">
            <span className={`text-sm font-bold ${isDiscount ? 'text-red-400' : costs.totalRevenue > 0 ? 'text-emerald-400' : 'text-muted-foreground'}`}>
              {isDiscount ? '-' : ''}${Math.abs(costs.totalRevenue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            {costs.margin !== null && !isDiscount && (
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${costs.margin >= 30 ? 'bg-emerald-500/10 text-emerald-400' : costs.margin >= 10 ? 'bg-amber-500/10 text-amber-400' : 'bg-red-500/10 text-red-400'}`}>
                {costs.margin.toFixed(1)}%
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ── Expanded Detail Panel ── */}
      {expanded && (
        <div className="px-3 pb-3 space-y-4 border-t border-border/40 pt-3">
          {/* Notes */}
          <input
            value={item.notes}
            onChange={e => onChange(idx, 'notes', e.target.value)}
            placeholder="Line notes / specs / requirements..."
            className="w-full rounded-md border border-input bg-transparent px-3 py-1.5 text-xs outline-none focus:ring-1 ring-ring"
          />

          {/* Labor + Overhead fields */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide">Labor Hrs</label>
              <input type="number" min={0} step="0.5" value={item.labor_hours}
                onChange={e => onChange(idx, 'labor_hours', e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-transparent px-2 py-1.5 text-xs outline-none focus:ring-1 ring-ring" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide">Labor Rate ($/hr)</label>
              <input type="number" min={0} step="0.01" value={item.labor_rate}
                onChange={e => onChange(idx, 'labor_rate', e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-transparent px-2 py-1.5 text-xs outline-none focus:ring-1 ring-ring" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide">Overhead %</label>
              <input type="number" min={0} max={100} step="1" value={item.overhead_pct}
                onChange={e => onChange(idx, 'overhead_pct', e.target.value)}
                className="mt-1 w-full rounded-md border border-input bg-transparent px-2 py-1.5 text-xs outline-none focus:ring-1 ring-ring" />
            </div>
            <div className="rounded-lg bg-muted/20 border border-border/50 p-2 text-xs space-y-1">
              <p className="text-[10px] text-muted-foreground font-semibold uppercase tracking-wide mb-1">Cost Breakdown</p>
              <div className="flex justify-between"><span className="text-muted-foreground">Materials</span><span>${costs.matCostPer.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Labor</span><span>${costs.laborCostPer.toFixed(2)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Overhead</span><span>${costs.overhead.toFixed(2)}</span></div>
              <div className="flex justify-between border-t border-border/50 pt-1 font-bold"><span>Unit Cost</span><span className="text-primary">${costs.unitCostFinal.toFixed(2)}</span></div>
            </div>
          </div>

          {/* Raw Materials / Sub-components */}
          {(item.type === 'finished_product' || item.type === 'raw_material' || item.type === 'custom') && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                  <Layers className="w-3 h-3" /> Raw Materials / Sub-components
                  {(item.raw_materials || []).length > 0 && (
                    <span className="ml-1 text-primary font-bold">
                      ({(item.raw_materials || []).length} items · ${costs.matCostPer.toFixed(2)} each)
                    </span>
                  )}
                </p>
                <Button size="sm" variant="outline" className="h-6 text-[10px] px-2 gap-1" onClick={addMaterial}>
                  <Plus className="w-3 h-3" /> Add Material
                </Button>
              </div>
              {(item.raw_materials || []).length > 0 && (
                <div className="rounded-xl border border-border/50 overflow-hidden">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="bg-muted/30 border-b border-border/50">
                        {['Material / Component', 'SKU', 'Qty', 'Unit', 'Unit Cost', 'Line Total', ''].map(h => (
                          <th key={h} className="px-2 py-1.5 text-left text-[10px] text-muted-foreground font-semibold">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border/30">
                      {(item.raw_materials || []).map((mat, mi) => {
                        const matLineTotal = (Number(mat.quantity) || 0) * (Number(mat.unit_cost) || 0);
                        return (
                          <tr key={mi} className="hover:bg-muted/10">
                            <td className="px-2 py-1.5">
                              <input value={mat.name} onChange={e => updateMaterial(mi, 'name', e.target.value)}
                                placeholder="Material name" className="w-full bg-transparent outline-none text-xs" />
                            </td>
                            <td className="px-2 py-1.5">
                              <input value={mat.sku} onChange={e => updateMaterial(mi, 'sku', e.target.value)}
                                placeholder="SKU" className="w-20 bg-transparent outline-none text-xs font-mono text-muted-foreground" />
                            </td>
                            <td className="px-2 py-1.5">
                              <input type="number" min={0} step="0.001" value={mat.quantity}
                                onChange={e => updateMaterial(mi, 'quantity', e.target.value)}
                                className="w-16 text-center bg-transparent outline-none text-xs" />
                            </td>
                            <td className="px-2 py-1.5">
                              <select value={mat.unit || 'each'} onChange={e => updateMaterial(mi, 'unit', e.target.value)}
                                className="w-14 bg-transparent text-xs outline-none text-muted-foreground">
                                {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                              </select>
                            </td>
                            <td className="px-2 py-1.5">
                              <input type="number" min={0} step="0.001" value={mat.unit_cost}
                                onChange={e => updateMaterial(mi, 'unit_cost', e.target.value)}
                                className="w-20 text-right bg-transparent outline-none text-xs" />
                            </td>
                            <td className="px-2 py-1.5 text-right font-medium text-primary">
                              ${matLineTotal.toFixed(2)}
                            </td>
                            <td className="px-2 py-1.5 text-center">
                              <button onClick={() => removeMaterial(mi)} className="text-muted-foreground hover:text-red-400 transition-colors">
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                    <tfoot>
                      <tr className="bg-muted/20 border-t border-border/50">
                        <td colSpan={5} className="px-2 py-1.5 text-right text-[10px] text-muted-foreground font-semibold">
                          Materials Total (per unit)
                        </td>
                        <td className="px-2 py-1.5 text-right text-xs font-bold text-primary">
                          ${costs.matCostPer.toFixed(2)}
                        </td>
                        <td></td>
                      </tr>
                      <tr className="bg-muted/20">
                        <td colSpan={5} className="px-2 py-1.5 text-right text-[10px] text-muted-foreground font-semibold">
                          Materials Total (× {Number(item.quantity) || 0} units)
                        </td>
                        <td className="px-2 py-1.5 text-right text-xs font-bold text-emerald-400">
                          ${(costs.matCostPer * (Number(item.quantity) || 0)).toFixed(2)}
                        </td>
                        <td></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Quote Totals Calculator ───────────────────────────────────────────────────

function calcQuoteTotals(lines, taxRate, discountAmount) {
  let subtotal = 0, totalCost = 0;

  const lineDetails = lines.map(line => {
    const costs = calcLineCosts(line);
    if (line.type === 'discount') {
      subtotal -= costs.totalRevenue;
    } else {
      subtotal += costs.totalRevenue;
    }
    totalCost += costs.totalCost;
    return costs;
  });

  const taxAmount = subtotal * ((Number(taxRate) || 0) / 100);
  const disc = Number(discountAmount) || 0;
  const total = subtotal + taxAmount - disc;
  const profit = total - totalCost;
  const margin = total > 0 ? (profit / total) * 100 : 0;

  return { subtotal, taxAmount, disc, total, totalCost, profit, margin, lineDetails };
}

// ── Print Preview Modal ───────────────────────────────────────────────────────

function PrintPreview({ quote, onClose }) {
  let lines = [];
  try { lines = JSON.parse(quote.line_items || '[]'); } catch {}
  lines = lines.map(l => ({ ...l, raw_materials: l.raw_materials || [] }));
  const totals = calcQuoteTotals(lines, quote.tax_rate || 0, quote.discount_amount || 0);

  const handlePrint = () => window.print();

  return (
    <div className="fixed inset-0 z-[60] flex items-start justify-center bg-black/80 overflow-y-auto py-6 px-2">
      <div className="w-full max-w-3xl">
        {/* Controls (hidden on print) */}
        <div className="flex justify-between items-center mb-3 print:hidden">
          <p className="text-sm text-muted-foreground">Quote Preview</p>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" className="gap-1.5" onClick={handlePrint}>
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </Button>
            <Button size="sm" variant="outline" onClick={onClose}>Close</Button>
          </div>
        </div>

        {/* ── The Printable Document ── */}
        <div id="quote-print" className="bg-white text-gray-900 rounded-2xl shadow-2xl p-8 print:rounded-none print:shadow-none print:p-6">
          {/* Header */}
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">QUOTE</h1>
              <p className="text-gray-500 mt-1">#{quote.estimate_number}</p>
              {quote.project_title && <p className="text-lg font-semibold text-gray-700 mt-1">{quote.project_title}</p>}
            </div>
            <div className="text-right text-sm text-gray-600 space-y-1">
              <p><span className="font-semibold">Date:</span> {quote.estimate_date ? new Date(quote.estimate_date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '—'}</p>
              {quote.expiry_date && <p><span className="font-semibold">Valid Until:</span> {new Date(quote.expiry_date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>}
              {quote.delivery_lead_time && <p><span className="font-semibold">Lead Time:</span> {quote.delivery_lead_time}</p>}
            </div>
          </div>

          {/* Bill To */}
          <div className="mb-8 p-4 bg-gray-50 rounded-xl">
            <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Bill To</p>
            <p className="font-bold text-lg text-gray-900">{quote.customer_name}</p>
            {quote.customer_email && <p className="text-gray-600 text-sm">{quote.customer_email}</p>}
            {quote.customer_phone && <p className="text-gray-600 text-sm">{quote.customer_phone}</p>}
          </div>

          {/* Line Items Table */}
          <table className="w-full mb-6 text-sm">
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="text-left py-2 text-xs uppercase tracking-wide text-gray-500 font-semibold w-8">#</th>
                <th className="text-left py-2 text-xs uppercase tracking-wide text-gray-500 font-semibold">Description</th>
                <th className="text-center py-2 text-xs uppercase tracking-wide text-gray-500 font-semibold w-20">Qty</th>
                <th className="text-right py-2 text-xs uppercase tracking-wide text-gray-500 font-semibold w-24">Unit Price</th>
                <th className="text-right py-2 text-xs uppercase tracking-wide text-gray-500 font-semibold w-28">Total</th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line, i) => {
                const costs = calcLineCosts(line);
                const isDiscount = line.type === 'discount';
                const typeLabel = ITEM_TYPES.find(t => t.value === line.type)?.label || line.type;
                return (
                  <tr key={i} className="border-b border-gray-100">
                    <td className="py-3 text-gray-400 text-xs">{i + 1}</td>
                    <td className="py-3">
                      <p className="font-semibold text-gray-900">{line.description || '—'}</p>
                      {line.sku && <p className="text-xs text-gray-400 font-mono">SKU: {line.sku}</p>}
                      <p className="text-xs text-gray-400">{typeLabel}</p>
                      {/* Sub-materials on quote */}
                      {(line.raw_materials || []).length > 0 && (
                        <ul className="mt-1 space-y-0.5">
                          {line.raw_materials.map((m, mi) => (
                            <li key={mi} className="text-xs text-gray-500 pl-3 border-l-2 border-gray-200">
                              {m.name} {m.sku ? `(${m.sku})` : ''} — {m.quantity} {m.unit}
                            </li>
                          ))}
                        </ul>
                      )}
                      {(Number(line.labor_hours) > 0) && (
                        <p className="text-xs text-gray-400 mt-0.5">
                          Labor: {line.labor_hours} hrs @ ${line.labor_rate}/hr
                        </p>
                      )}
                      {line.notes && <p className="text-xs text-gray-400 italic mt-0.5">{line.notes}</p>}
                    </td>
                    <td className="py-3 text-center text-gray-700">{line.quantity} {line.unit}</td>
                    <td className="py-3 text-right text-gray-700">
                      {isDiscount ? '—' : `$${(Number(line.unit_price) || 0).toFixed(2)}`}
                    </td>
                    <td className={`py-3 text-right font-semibold ${isDiscount ? 'text-red-600' : 'text-gray-900'}`}>
                      {isDiscount ? `-$${Math.abs(costs.totalRevenue).toFixed(2)}` : `$${costs.totalRevenue.toFixed(2)}`}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {/* Totals */}
          <div className="flex justify-end mb-8">
            <div className="w-72 space-y-2 text-sm">
              <div className="flex justify-between text-gray-700">
                <span>Subtotal</span>
                <span>${totals.subtotal.toFixed(2)}</span>
              </div>
              {totals.taxAmount > 0 && (
                <div className="flex justify-between text-gray-700">
                  <span>Tax ({quote.tax_rate || 0}%)</span>
                  <span>${totals.taxAmount.toFixed(2)}</span>
                </div>
              )}
              {totals.disc > 0 && (
                <div className="flex justify-between text-red-600">
                  <span>Discount</span>
                  <span>-${totals.disc.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg border-t-2 border-gray-300 pt-2 text-gray-900">
                <span>TOTAL</span>
                <span>${totals.total.toFixed(2)} {quote.currency || 'USD'}</span>
              </div>
            </div>
          </div>

          {/* Terms & Notes */}
          {(quote.terms || quote.notes) && (
            <div className="grid grid-cols-2 gap-6 border-t border-gray-200 pt-6 text-sm">
              {quote.terms && (
                <div>
                  <p className="font-semibold text-gray-700 mb-1">Payment Terms</p>
                  <p className="text-gray-500">{quote.terms}</p>
                </div>
              )}
              {quote.notes && (
                <div>
                  <p className="font-semibold text-gray-700 mb-1">Notes / Scope</p>
                  <p className="text-gray-500">{quote.notes}</p>
                </div>
              )}
            </div>
          )}

          {/* Footer */}
          <div className="mt-8 pt-4 border-t border-gray-100 text-center text-xs text-gray-400">
            Thank you for your business. This quote is valid
            {quote.expiry_date ? ` until ${new Date(quote.expiry_date).toLocaleDateString()}` : ' for 30 days from the date of issue'}.
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Quote Builder / Editor Modal ──────────────────────────────────────────────

function QuoteEditor({ quote, onClose, onSaved }) {
  const isNew = !quote?.id;

  const [form, setForm] = useState(() => {
    if (quote) {
      let lines = [];
      try { lines = JSON.parse(quote.line_items || '[]'); } catch {}
      lines = lines.map(l => ({
        ...emptyLine(),
        ...l,
        raw_materials: l.raw_materials || [],
        labor_hours: l.labor_hours || 0,
        labor_rate: l.labor_rate || 0,
        overhead_pct: l.overhead_pct || 0,
      }));
      return { ...quote, _lines: lines.length > 0 ? lines : [emptyLine()] };
    }
    return {
      estimate_number: `Q-${Date.now().toString().slice(-6)}`,
      customer_name: '', customer_email: '', customer_phone: '',
      estimate_date: new Date().toISOString().split('T')[0],
      expiry_date: '',
      status: 'draft',
      currency: 'USD',
      tax_rate: 0,
      discount_amount: 0,
      notes: '',
      terms: '',
      project_title: '',
      delivery_lead_time: '',
      _lines: [emptyLine()],
    };
  });

  const [expandedLines, setExpandedLines] = useState({});
  const [saving, setSaving] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  const setF = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const updateLine = useCallback((idx, k, v) => {
    setForm(f => {
      const lines = [...f._lines];
      lines[idx] = { ...lines[idx], [k]: v };
      return { ...f, _lines: lines };
    });
  }, []);

  const addLine = () => setForm(f => ({ ...f, _lines: [...f._lines, emptyLine()] }));
  const removeLine = (idx) => setForm(f => ({ ...f, _lines: f._lines.filter((_, i) => i !== idx) }));
  const toggleLine = (idx) => setExpandedLines(e => ({ ...e, [idx]: !e[idx] }));

  const totals = calcQuoteTotals(form._lines, form.tax_rate, form.discount_amount);

  const handleSave = async (overrideStatus) => {
    if (!form.customer_name.trim()) { toast.error('Customer name required'); return; }
    setSaving(true);
    const status = overrideStatus || form.status;
    const payload = {
      estimate_number: form.estimate_number,
      customer_name: form.customer_name,
      customer_email: form.customer_email || '',
      customer_phone: form.customer_phone || '',
      estimate_date: form.estimate_date,
      expiry_date: form.expiry_date || null,
      status,
      notes: form.notes || '',
      terms: form.terms || '',
      project_title: form.project_title || '',
      delivery_lead_time: form.delivery_lead_time || '',
      tax_rate: Number(form.tax_rate) || 0,
      discount_amount: Number(form.discount_amount) || 0,
      line_items: JSON.stringify(form._lines),
      subtotal: totals.subtotal,
      tax_amount: totals.taxAmount,
      total_amount: totals.total,
      currency: form.currency || 'USD',
    };
    if (isNew) {
      await base44.entities.Estimate.create(payload);
      toast.success('Quote created');
    } else {
      await base44.entities.Estimate.update(quote.id, payload);
      toast.success('Quote updated');
    }
    setSaving(false);
    onSaved();
    onClose();
  };

  // Build a preview-ready quote object from current form state
  const previewQuote = {
    ...form,
    line_items: JSON.stringify(form._lines),
    tax_rate: form.tax_rate,
    discount_amount: form.discount_amount,
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/70 overflow-y-auto py-6 px-2" onClick={onClose}>
        <div className="bg-card border border-border rounded-2xl w-full max-w-5xl shadow-2xl" onClick={e => e.stopPropagation()}>
          {/* Header */}
          <div className="flex items-center justify-between p-5 border-b border-border">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center">
                <FileText className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h2 className="text-base font-bold">{isNew ? 'New Quote' : `Edit Quote ${quote.estimate_number}`}</h2>
                <p className="text-xs text-muted-foreground">Auto-calculates raw material costs, labor, and overhead per line</p>
              </div>
            </div>
            <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors text-xl leading-none">×</button>
          </div>

          <div className="p-5 space-y-6 overflow-y-auto max-h-[80vh]">
            {/* Quote Header */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="text-xs text-muted-foreground">Quote #</label>
                <Input value={form.estimate_number} onChange={e => setF('estimate_number', e.target.value)} className="mt-1 text-sm" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Project / Job Title</label>
                <Input value={form.project_title || ''} onChange={e => setF('project_title', e.target.value)} placeholder="e.g. Custom Build 2026" className="mt-1 text-sm" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Quote Date</label>
                <Input type="date" value={form.estimate_date} onChange={e => setF('estimate_date', e.target.value)} className="mt-1 text-sm" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Valid Until</label>
                <Input type="date" value={form.expiry_date || ''} onChange={e => setF('expiry_date', e.target.value)} className="mt-1 text-sm" />
              </div>
            </div>

            {/* Customer */}
            <div className="rounded-xl border border-border/60 p-4 space-y-3 bg-muted/10">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Customer / Client</p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground">Name *</label>
                  <Input value={form.customer_name} onChange={e => setF('customer_name', e.target.value)} placeholder="Customer or company name" className="mt-1 text-sm" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Email</label>
                  <Input value={form.customer_email || ''} onChange={e => setF('customer_email', e.target.value)} placeholder="email@example.com" className="mt-1 text-sm" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Phone</label>
                  <Input value={form.customer_phone || ''} onChange={e => setF('customer_phone', e.target.value)} placeholder="Phone number" className="mt-1 text-sm" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-muted-foreground">Delivery / Lead Time</label>
                  <Input value={form.delivery_lead_time || ''} onChange={e => setF('delivery_lead_time', e.target.value)} placeholder="e.g. 2-3 weeks" className="mt-1 text-sm" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Status</label>
                  <Select value={form.status} onValueChange={v => setF('status', v)}>
                    <SelectTrigger className="mt-1 text-sm h-9"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(STATUS_CONFIG).map(([v, c]) => <SelectItem key={v} value={v}>{c.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Line Items */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5" /> Line Items
                  <span className="text-primary ml-1">({form._lines.length})</span>
                </p>
                <Button size="sm" variant="outline" className="gap-1.5 h-7 text-xs" onClick={addLine}>
                  <Plus className="w-3 h-3" /> Add Line
                </Button>
              </div>

              {/* Column Headers */}
              <div className="px-3 mb-1 text-[10px] font-semibold text-muted-foreground uppercase tracking-wide hidden sm:flex items-center gap-6">
                <span className="w-44 shrink-0">Type</span>
                <span className="flex-1">Description</span>
                <span className="ml-auto text-right">Total / Margin</span>
              </div>

              <div className="space-y-2">
                {form._lines.map((line, idx) => (
                  <LineItemRow
                    key={idx}
                    item={line}
                    idx={idx}
                    onChange={updateLine}
                    onRemove={removeLine}
                    expanded={!!expandedLines[idx]}
                    onToggle={() => toggleLine(idx)}
                  />
                ))}
              </div>

              <Button size="sm" variant="ghost" className="mt-2 gap-1.5 text-xs text-muted-foreground hover:text-foreground" onClick={addLine}>
                <Plus className="w-3 h-3" /> Add another line
              </Button>
            </div>

            {/* Totals + Notes */}
            <div className="flex flex-col sm:flex-row gap-4 justify-between">
              <div className="flex-1 space-y-3">
                <div>
                  <label className="text-xs text-muted-foreground">Notes / Scope of Work</label>
                  <textarea value={form.notes || ''} onChange={e => setF('notes', e.target.value)} rows={3}
                    placeholder="Describe scope, conditions, or special instructions..."
                    className="mt-1 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm outline-none focus:ring-1 ring-ring resize-none" />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Payment Terms</label>
                  <Input value={form.terms || ''} onChange={e => setF('terms', e.target.value)}
                    placeholder="e.g. 50% deposit, balance on completion" className="mt-1 text-sm" />
                </div>
              </div>

              {/* Summary Panel */}
              <div className="w-full sm:w-80 rounded-xl border border-border/60 p-4 space-y-2 bg-muted/10 self-start">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3 flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" /> Financial Summary
                </p>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span className="font-medium">${totals.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1.5">
                    <span className="text-muted-foreground">Tax</span>
                    <div className="relative w-16">
                      <input type="number" min={0} max={100} step="0.1" value={form.tax_rate}
                        onChange={e => setF('tax_rate', e.target.value)}
                        className="w-full rounded border border-input bg-transparent px-2 py-0.5 text-xs outline-none text-right" />
                      <span className="absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] text-muted-foreground">%</span>
                    </div>
                  </div>
                  <span>${totals.taxAmount.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Flat Discount ($)</span>
                  <input type="number" min={0} step="0.01" value={form.discount_amount}
                    onChange={e => setF('discount_amount', e.target.value)}
                    className="w-20 rounded border border-input bg-transparent px-2 py-0.5 text-xs outline-none text-right" />
                </div>
                {totals.disc > 0 && (
                  <div className="flex justify-between text-sm text-red-400">
                    <span>Discount Applied</span>
                    <span>-${totals.disc.toFixed(2)}</span>
                  </div>
                )}
                <div className="pt-2 border-t border-border flex justify-between">
                  <span className="font-bold text-sm">Total</span>
                  <span className="font-bold text-emerald-400 text-base">${totals.total.toFixed(2)}</span>
                </div>
                <div className="pt-2 border-t border-border/40 space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Total Cost (all lines)</span>
                    <span className="text-primary font-medium">${totals.totalCost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Gross Profit</span>
                    <span className={`font-bold ${totals.profit >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                      ${totals.profit.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Overall Margin</span>
                    <span className={`font-bold text-sm ${totals.margin >= 30 ? 'text-emerald-400' : totals.margin >= 10 ? 'text-amber-400' : 'text-red-400'}`}>
                      {totals.total > 0 ? `${totals.margin.toFixed(1)}%` : '—'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-4 border-t border-border flex-wrap gap-2">
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={onClose}>Cancel</Button>
              <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setShowPreview(true)}>
                <Printer className="w-3.5 h-3.5" /> Preview
              </Button>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={saving} onClick={() => handleSave('draft')}>Save Draft</Button>
              <Button size="sm" className="gap-1.5" onClick={() => handleSave()} disabled={saving}>
                {saving ? 'Saving...' : isNew ? 'Create Quote' : 'Save Changes'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {showPreview && (
        <PrintPreview quote={previewQuote} onClose={() => setShowPreview(false)} />
      )}
    </>
  );
}

// ── Main QuotingPanel ─────────────────────────────────────────────────────────

export default function QuotingPanel({ estimates, tickets, onAccept, onRefresh, suppliers = [] }) {
  const [filter, setFilter] = useState('all');
  const [accepting, setAccepting] = useState(null);
  const [editingQuote, setEditingQuote] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [previewQuote, setPreviewQuote] = useState(null);

  const filtered = filter === 'all' ? estimates : estimates.filter(e => e.status === filter);

  const handleAccept = async (e) => {
    setAccepting(e.id);
    await onAccept(e);
    setAccepting(null);
  };

  const handleStatusChange = async (estimate, newStatus) => {
    await base44.entities.Estimate.update(estimate.id, { status: newStatus });
    onRefresh();
  };

  const handleDelete = async (estimate) => {
    if (!confirm(`Delete quote ${estimate.estimate_number}?`)) return;
    await base44.entities.Estimate.delete(estimate.id);
    toast.success('Quote deleted');
    onRefresh();
  };

  const openNew = () => { setEditingQuote(null); setShowEditor(true); };
  const openEdit = (q) => { setEditingQuote(q); setShowEditor(true); };
  const ticketsByQuoteNote = (quoteNum) => tickets.filter(t => t.notes?.includes(quoteNum));

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex gap-1 flex-wrap">
          {['all', 'draft', 'sent', 'accepted', 'rejected', 'expired'].map(s => {
            const count = s === 'all' ? estimates.length : estimates.filter(e => e.status === s).length;
            return (
              <button key={s} onClick={() => setFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${filter === s ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
                {s === 'all' ? `All (${count})` : `${s} (${count})`}
              </button>
            );
          })}
        </div>
        <Button size="sm" className="gap-1.5 h-8" onClick={openNew}>
          <Plus className="w-3.5 h-3.5" /> New Quote
        </Button>
      </div>

      {/* Quote List */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center text-muted-foreground border border-dashed border-border/50 rounded-2xl">
          <FileText className="w-10 h-10 mx-auto mb-2 opacity-20" />
          <p className="text-sm font-medium">No quotes found.</p>
          <p className="text-xs mt-1">Create a quote to kick off the production chain.</p>
          <Button size="sm" className="mt-4 gap-1.5" onClick={openNew}><Plus className="w-3.5 h-3.5" /> Create First Quote</Button>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(est => {
            const cfg = STATUS_CONFIG[est.status] || STATUS_CONFIG.draft;
            const StatusIcon = cfg.icon;
            const linked = ticketsByQuoteNote(est.estimate_number);
            let lines = [];
            try { lines = JSON.parse(est.line_items || '[]'); } catch {}
            lines = lines.map(l => ({ ...emptyLine(), ...l, raw_materials: l.raw_materials || [] }));

            const totals = calcQuoteTotals(lines, est.tax_rate || 0, est.discount_amount || 0);

            return (
              <div key={est.id} className={`rounded-xl border p-4 transition-all ${est.status === 'accepted' ? 'border-emerald-500/30 bg-emerald-500/5' : est.status === 'sent' ? 'border-blue-500/20 bg-blue-500/5' : 'border-border/60 bg-card'}`}>
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <Badge className={`text-[9px] h-5 px-1.5 gap-1 ${cfg.color}`}><StatusIcon className="w-2.5 h-2.5" />{cfg.label}</Badge>
                      <span className="text-sm font-bold">{est.estimate_number}</span>
                      {est.project_title && <span className="text-sm text-muted-foreground">— {est.project_title}</span>}
                      <span className="text-muted-foreground text-xs">· {est.customer_name}</span>
                    </div>

                    <div className="flex flex-wrap gap-3 text-xs">
                      <span className="text-emerald-400 font-bold text-sm">${totals.total.toFixed(2)}</span>
                      {totals.totalCost > 0 && <span className="text-muted-foreground">Cost: <span className="text-primary">${totals.totalCost.toFixed(2)}</span></span>}
                      {totals.total > 0 && <span className={`font-semibold ${totals.margin >= 30 ? 'text-emerald-400' : totals.margin >= 10 ? 'text-amber-400' : 'text-red-400'}`}>{totals.margin.toFixed(1)}% margin</span>}
                      {est.estimate_date && <span className="text-muted-foreground">Dated: {new Date(est.estimate_date).toLocaleDateString()}</span>}
                      {est.expiry_date && <span className={new Date(est.expiry_date) < new Date() && est.status !== 'accepted' ? 'text-red-400 font-semibold' : 'text-muted-foreground'}>Expires: {new Date(est.expiry_date).toLocaleDateString()}</span>}
                      {est.delivery_lead_time && <span className="text-muted-foreground">Lead time: {est.delivery_lead_time}</span>}
                    </div>

                    {/* Line Items Preview */}
                    {lines.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {lines.slice(0, 5).map((line, i) => (
                          <span key={i} className={`text-[10px] rounded-lg px-2 py-0.5 ${line.type === 'labor' ? 'bg-blue-500/10 text-blue-400' : line.type === 'raw_material' ? 'bg-amber-500/10 text-amber-400' : line.type === 'discount' ? 'bg-red-500/10 text-red-400' : 'bg-muted/50 text-muted-foreground'}`}>
                            {line.description || '—'} × {line.quantity} {line.unit}
                            {(line.raw_materials || []).length > 0 && <span className="ml-1 text-primary">({line.raw_materials.length} mats)</span>}
                          </span>
                        ))}
                        {lines.length > 5 && <span className="text-[10px] text-muted-foreground">+{lines.length - 5} more</span>}
                      </div>
                    )}

                    {/* Linked production tickets */}
                    {linked.length > 0 && (
                      <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                        <ArrowRight className="w-3 h-3 text-emerald-400" />
                        <span className="text-[10px] text-emerald-400 font-semibold">{linked.length} production ticket{linked.length > 1 ? 's' : ''} created</span>
                        {linked.slice(0, 4).map(t => (
                          <Badge key={t.id} className="text-[9px] h-4 px-1.5 bg-emerald-500/15 text-emerald-400">{t.status.replace(/_/g,' ')}</Badge>
                        ))}
                      </div>
                    )}

                    {est.notes && <p className="text-[10px] text-muted-foreground mt-1.5 italic">"{est.notes}"</p>}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-1.5 items-end shrink-0">
                    <div className="flex gap-1.5 flex-wrap justify-end">
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => setPreviewQuote(est)}>
                        <Printer className="w-3 h-3" /> Preview
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => openEdit(est)}>
                        <Edit2 className="w-3 h-3" /> Edit
                      </Button>
                      {est.status === 'draft' && (
                        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={() => handleStatusChange(est, 'sent')}>
                          <Send className="w-3 h-3" /> Send
                        </Button>
                      )}
                      {(est.status === 'sent' || est.status === 'draft') && (
                        <Button size="sm" className="h-7 text-xs gap-1 bg-emerald-600 hover:bg-emerald-700"
                          disabled={accepting === est.id}
                          onClick={() => handleAccept(est)}>
                          <CheckCircle2 className="w-3 h-3" />
                          {accepting === est.id ? 'Creating...' : 'Accept → Produce'}
                        </Button>
                      )}
                      {est.status === 'sent' && (
                        <Button size="sm" variant="outline" className="h-7 text-xs text-red-400 border-red-500/30" onClick={() => handleStatusChange(est, 'rejected')}>
                          <XCircle className="w-3 h-3 mr-1" /> Reject
                        </Button>
                      )}
                      {est.status === 'accepted' && linked.length === 0 && (
                        <Button size="sm" className="h-7 text-xs gap-1" onClick={() => handleAccept(est)}>
                          <Package className="w-3 h-3" /> Create Tickets
                        </Button>
                      )}
                    </div>
                    <button onClick={() => handleDelete(est)} className="text-[10px] text-muted-foreground hover:text-red-400 transition-colors">delete</button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Quote Editor Modal */}
      {showEditor && (
        <QuoteEditor
          quote={editingQuote}
          onClose={() => { setShowEditor(false); setEditingQuote(null); }}
          onSaved={onRefresh}
          suppliers={suppliers}
        />
      )}

      {/* Print Preview */}
      {previewQuote && (
        <PrintPreview quote={previewQuote} onClose={() => setPreviewQuote(null)} />
      )}
    </div>
  );
}