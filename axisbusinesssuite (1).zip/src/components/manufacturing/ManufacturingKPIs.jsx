import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Package, Clock, DollarSign, CheckCircle2, Truck, AlertTriangle, Pause, XCircle, BarChart2 } from 'lucide-react';

function KPICard({ label, value, sub, icon: Icon, color }) {
  return (
    <Card className="border-border/60">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="min-w-0 flex-1">
            <p className="text-xs text-muted-foreground truncate">{label}</p>
            <p className="text-2xl font-bold mt-1 truncate">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-0.5 truncate">{sub}</p>}
          </div>
          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ml-2 ${color}`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ManufacturingKPIs({ tickets, orders, inventory, invoices }) {
  const activeTickets = tickets.filter(t => ['in_progress', 'queued', 'waiting_materials'].includes(t.status));
  const completedThisMonth = tickets.filter(t => {
    if (t.status !== 'completed' || !t.completed_at) return false;
    const d = new Date(t.completed_at);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const totalRevenue = tickets.reduce((s, t) => s + (t.total_revenue || 0), 0);
  const totalCost = tickets.reduce((s, t) => s + (t.total_cost || 0), 0);
  const grossMargin = totalRevenue > 0 ? (((totalRevenue - totalCost) / totalRevenue) * 100).toFixed(1) : 0;

  const lowStock = inventory.filter(i => i.quantity_on_hand <= i.reorder_point && i.quantity_on_hand >= 0);
  const onHoldTickets = tickets.filter(t => t.status === 'on_hold' || t.status === 'waiting_materials');
  const overdueTickets = tickets.filter(t => {
    if (!t.due_date || t.status === 'completed' || t.status === 'cancelled') return false;
    return new Date(t.due_date) < new Date();
  });
  const activeOrders = orders.filter(o => !['completed', 'cancelled'].includes(o.status));

  // Status breakdown counts
  const statusCounts = {
    backlog: tickets.filter(t => t.status === 'backlog').length,
    waiting_materials: tickets.filter(t => t.status === 'waiting_materials').length,
    queued: tickets.filter(t => t.status === 'queued').length,
    in_progress: tickets.filter(t => t.status === 'in_progress').length,
    quality_check: tickets.filter(t => t.status === 'quality_check').length,
    completed: tickets.filter(t => t.status === 'completed').length,
    on_hold: tickets.filter(t => t.status === 'on_hold').length,
    cancelled: tickets.filter(t => t.status === 'cancelled').length,
  };

  const STATUS_BARS = [
    { key: 'backlog', label: 'Backlog', color: 'bg-slate-500' },
    { key: 'waiting_materials', label: 'Waiting', color: 'bg-amber-500' },
    { key: 'queued', label: 'Queued', color: 'bg-blue-500' },
    { key: 'in_progress', label: 'In Progress', color: 'bg-primary' },
    { key: 'quality_check', label: 'QC', color: 'bg-purple-500' },
    { key: 'completed', label: 'Done', color: 'bg-emerald-500' },
    { key: 'on_hold', label: 'On Hold', color: 'bg-slate-400' },
  ];

  const totalAll = tickets.length || 1;

  return (
    <div className="space-y-3">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPICard
          label="Active Production"
          value={activeTickets.length}
          sub={`${onHoldTickets.length} on hold / waiting`}
          icon={Package}
          color="bg-blue-500/15 text-blue-400"
        />
        <KPICard
          label="Completed This Month"
          value={completedThisMonth.length}
          sub={overdueTickets.length > 0 ? `⚠️ ${overdueTickets.length} overdue` : 'No overdue tickets'}
          icon={CheckCircle2}
          color="bg-emerald-500/15 text-emerald-400"
        />
        <KPICard
          label="Total Revenue (Tracked)"
          value={`$${totalRevenue.toLocaleString()}`}
          sub={`${grossMargin}% gross margin`}
          icon={DollarSign}
          color="bg-primary/15 text-primary"
        />
        <KPICard
          label="Active Orders"
          value={activeOrders.length}
          sub={lowStock.length > 0 ? `⚠️ ${lowStock.length} low stock items` : `${inventory.length} items tracked`}
          icon={Truck}
          color={lowStock.length > 0 ? 'bg-amber-500/15 text-amber-400' : 'bg-purple-500/15 text-purple-400'}
        />
      </div>

      {/* Status Pipeline Strip */}
      {tickets.length > 0 && (
        <Card className="border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Production Pipeline — {tickets.length} total tickets</p>
              {overdueTickets.length > 0 && (
                <span className="text-[10px] text-red-400 font-semibold flex items-center gap-1">
                  <AlertTriangle className="w-3 h-3" /> {overdueTickets.length} overdue
                </span>
              )}
            </div>

            {/* Stacked progress bar */}
            <div className="flex h-3 rounded-full overflow-hidden gap-0.5 mb-3">
              {STATUS_BARS.map(s => {
                const pct = (statusCounts[s.key] / totalAll) * 100;
                if (pct === 0) return null;
                return <div key={s.key} className={`${s.color} transition-all`} style={{ width: `${pct}%` }} title={`${s.label}: ${statusCounts[s.key]}`} />;
              })}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-x-4 gap-y-1.5">
              {STATUS_BARS.map(s => (
                statusCounts[s.key] > 0 && (
                  <div key={s.key} className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                    <span className={`w-2 h-2 rounded-full ${s.color}`} />
                    {s.label}: <span className="font-semibold text-foreground">{statusCounts[s.key]}</span>
                  </div>
                )
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Inventory Alert Strip */}
      {lowStock.length > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-3">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <p className="text-xs font-semibold text-amber-400">{lowStock.length} Inventory Item{lowStock.length > 1 ? 's' : ''} Low / At Reorder Point</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {lowStock.slice(0, 6).map(item => (
              <span key={item.id} className="text-[10px] bg-amber-500/10 text-amber-300 border border-amber-500/20 rounded-lg px-2 py-0.5">
                {item.item_name} — <span className="font-bold">{item.quantity_on_hand}</span> left (reorder at {item.reorder_point})
              </span>
            ))}
            {lowStock.length > 6 && <span className="text-[10px] text-muted-foreground">+{lowStock.length - 6} more</span>}
          </div>
        </div>
      )}
    </div>
  );
}