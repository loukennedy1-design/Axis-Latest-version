import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import {
  Package, Clock, AlertTriangle, CheckCircle2, Pause, XCircle,
  DollarSign, Truck, Search, Edit, ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';
import TicketDetailDrawer from './TicketDetailDrawer';

const STATUS_CONFIG = {
  backlog:           { label: 'Backlog',           color: 'bg-muted text-muted-foreground', icon: Clock },
  waiting_materials: { label: 'Waiting Materials', color: 'bg-amber-500/15 text-amber-400 border-amber-500/30', icon: AlertTriangle },
  queued:            { label: 'Queued',            color: 'bg-blue-500/15 text-blue-400 border-blue-500/30', icon: Clock },
  in_progress:       { label: 'In Progress',       color: 'bg-primary/15 text-primary border-primary/30', icon: Package },
  quality_check:     { label: 'QC Check',          color: 'bg-purple-500/15 text-purple-400 border-purple-500/30', icon: CheckCircle2 },
  completed:         { label: 'Completed',         color: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  on_hold:           { label: 'On Hold',           color: 'bg-slate-500/15 text-slate-400 border-slate-500/30', icon: Pause },
  cancelled:         { label: 'Cancelled',         color: 'bg-red-500/15 text-red-400 border-red-500/30', icon: XCircle },
};

const PRIORITY_COLOR = {
  low: 'text-slate-400',
  medium: 'text-blue-400',
  high: 'text-orange-400',
  urgent: 'text-red-400',
};

const SOURCE_ICON = {
  build_to_order: '🔨',
  from_inventory: '📦',
  partial_inventory: '🔀',
};

const PAY_COLOR = {
  unpaid: 'bg-red-500/15 text-red-400',
  deposit_paid: 'bg-amber-500/15 text-amber-400',
  paid: 'bg-emerald-500/15 text-emerald-400',
  refunded: 'bg-muted text-muted-foreground',
};

function TicketCard({ ticket, onEdit, onStatusChange, onView }) {
  const cfg = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.backlog;
  const Icon = cfg.icon;
  const isOverdue = ticket.due_date && new Date(ticket.due_date) < new Date() && ticket.status !== 'completed' && ticket.status !== 'cancelled';
  const margin = ticket.total_revenue > 0
    ? (((ticket.total_revenue - ticket.total_cost) / ticket.total_revenue) * 100).toFixed(0)
    : null;

  let rawMaterials = [];
  try { rawMaterials = JSON.parse(ticket.raw_materials || '[]'); } catch {}

  return (
    <div className={`bg-card border rounded-xl p-3.5 space-y-2.5 hover:border-primary/40 transition-colors cursor-pointer ${isOverdue ? 'border-red-500/40' : 'border-border/60'}`}
      onClick={() => onView(ticket)}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[10px]">{SOURCE_ICON[ticket.source_type] || '📦'}</span>
            <p className="text-sm font-semibold truncate">{ticket.product_name}</p>
            {isOverdue && <span className="text-[9px] text-red-400 font-semibold">OVERDUE</span>}
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">{ticket.ticket_number}{ticket.account_name ? ` · ${ticket.account_name}` : ''}</p>
        </div>
        <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onClick={e => { e.stopPropagation(); onEdit(ticket); }}>
          <Edit className="w-3 h-3" />
        </Button>
      </div>

      <div className="flex flex-wrap gap-1.5 items-center">
        <Badge className={`text-[9px] h-5 px-1.5 ${cfg.color}`}>
          <Icon className="w-2.5 h-2.5 mr-1" />{cfg.label}
        </Badge>
        <span className={`text-[10px] font-semibold ${PRIORITY_COLOR[ticket.priority]}`}>▲ {ticket.priority}</span>
        <span className="text-[10px] text-muted-foreground ml-auto">Qty: {ticket.quantity}</span>
      </div>

      {/* SKU + Materials count */}
      <div className="flex flex-wrap gap-2 text-[10px] text-muted-foreground">
        {ticket.sku && <span className="font-mono bg-muted/40 rounded px-1">{ticket.sku}</span>}
        {rawMaterials.length > 0 && <span>{rawMaterials.length} component{rawMaterials.length > 1 ? 's' : ''}</span>}
        {ticket.payment_status && ticket.payment_status !== 'unpaid' && (
          <Badge className={`text-[9px] h-4 px-1.5 ${PAY_COLOR[ticket.payment_status] || ''}`}>{ticket.payment_status.replace(/_/g,' ')}</Badge>
        )}
        {ticket.payment_status === 'unpaid' && ticket.total_revenue > 0 && (
          <Badge className="text-[9px] h-4 px-1.5 bg-red-500/15 text-red-400">unpaid</Badge>
        )}
      </div>

      <div className="flex flex-wrap gap-3 text-[10px] text-muted-foreground">
        {ticket.total_revenue > 0 && (
          <span className="flex items-center gap-0.5 text-emerald-400">
            <DollarSign className="w-2.5 h-2.5" />${ticket.total_revenue.toLocaleString()}
            {margin && <span className="text-muted-foreground ml-1">({margin}% margin)</span>}
          </span>
        )}
        {ticket.supplier_name && <span className="flex items-center gap-0.5"><Truck className="w-2.5 h-2.5" />{ticket.supplier_name}</span>}
        {ticket.due_date && <span className={isOverdue ? 'text-red-400' : ''}>Due: {new Date(ticket.due_date).toLocaleDateString()}</span>}
      </div>

      {/* Hours bar if tracked */}
      {ticket.estimated_hours > 0 && (
        <div>
          <div className="flex justify-between text-[9px] text-muted-foreground mb-0.5">
            <span>{ticket.actual_hours || 0}h / {ticket.estimated_hours}h est.</span>
          </div>
          <div className="h-1 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary/60 rounded-full" style={{ width: `${Math.min(100, ((ticket.actual_hours || 0) / ticket.estimated_hours) * 100)}%` }} />
          </div>
        </div>
      )}

      <div onClick={e => e.stopPropagation()}>
        <Select value={ticket.status} onValueChange={v => onStatusChange(ticket, v)}>
          <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            {Object.entries(STATUS_CONFIG).map(([v, c]) => (
              <SelectItem key={v} value={v}>{c.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}

export default function ProductionBoard({ tickets, onEdit, onRefresh }) {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterPriority, setFilterPriority] = useState('all');
  const [view, setView] = useState('list');
  const [viewingTicket, setViewingTicket] = useState(null);

  const handleStatusChange = async (ticket, newStatus) => {
    const updates = { status: newStatus };
    if (newStatus === 'in_progress' && !ticket.started_at) updates.started_at = new Date().toISOString();
    if (newStatus === 'completed') updates.completed_at = new Date().toISOString();
    await base44.entities.ProductionTicket.update(ticket.id, updates);
    toast.success(`Status updated to ${STATUS_CONFIG[newStatus]?.label}`);
    onRefresh();
  };

  const filtered = tickets.filter(t => {
    const matchSearch = !search ||
      t.product_name?.toLowerCase().includes(search.toLowerCase()) ||
      t.ticket_number?.toLowerCase().includes(search.toLowerCase()) ||
      t.account_name?.toLowerCase().includes(search.toLowerCase()) ||
      t.sku?.toLowerCase().includes(search.toLowerCase()) ||
      t.supplier_name?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || t.status === filterStatus;
    const matchPriority = filterPriority === 'all' || t.priority === filterPriority;
    return matchSearch && matchStatus && matchPriority;
  });

  const BOARD_COLUMNS = [
    { statuses: ['backlog'], label: 'Backlog' },
    { statuses: ['waiting_materials', 'queued'], label: 'Queue' },
    { statuses: ['in_progress'], label: 'In Progress' },
    { statuses: ['quality_check'], label: 'QC Check' },
    { statuses: ['completed'], label: 'Done' },
  ];

  return (
    <div className="space-y-3">
      {/* Toolbar */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search product, SKU, customer, supplier..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-8 h-8 text-xs"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="h-8 text-xs w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {Object.entries(STATUS_CONFIG).map(([v, c]) => <SelectItem key={v} value={v}>{c.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterPriority} onValueChange={setFilterPriority}>
          <SelectTrigger className="h-8 text-xs w-28"><SelectValue placeholder="Priority" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            {['urgent','high','medium','low'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex rounded-lg border border-border overflow-hidden">
          {['list','kanban'].map(v => (
            <button key={v} onClick={() => setView(v)}
              className={`px-3 py-1.5 text-xs font-medium capitalize transition-colors ${view === v ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
              {v}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="py-12 text-center text-muted-foreground">
          <Package className="w-10 h-10 mx-auto mb-2 opacity-20" />
          <p className="text-sm">No production tickets found</p>
        </div>
      ) : view === 'kanban' ? (
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {BOARD_COLUMNS.map(col => {
            const colTickets = filtered.filter(t => col.statuses.includes(t.status));
            return (
              <div key={col.label} className="space-y-2">
                <div className="flex items-center justify-between px-1">
                  <p className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{col.label}</p>
                  <span className="text-[10px] bg-muted rounded-full px-1.5 py-0.5">{colTickets.length}</span>
                </div>
                {colTickets.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-border/50 h-20 flex items-center justify-center">
                    <p className="text-[10px] text-muted-foreground/40">Empty</p>
                  </div>
                ) : (
                  colTickets.map(t => (
                    <TicketCard key={t.id} ticket={t} onEdit={onEdit} onStatusChange={handleStatusChange} onView={setViewingTicket} />
                  ))
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Detailed List View */
        <div className="overflow-x-auto rounded-xl border border-border">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {['Product / SKU', 'Customer', 'Status', 'Priority', 'Type', 'Qty', 'Revenue', 'Margin', 'Supplier', 'Payment', 'Due', ''].map(h => (
                  <th key={h} className="px-3 py-2.5 text-left font-semibold text-[10px] text-muted-foreground uppercase tracking-wide whitespace-nowrap">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(t => {
                const cfg = STATUS_CONFIG[t.status] || STATUS_CONFIG.backlog;
                const StatusIcon = cfg.icon;
                const isOverdue = t.due_date && new Date(t.due_date) < new Date() && t.status !== 'completed' && t.status !== 'cancelled';
                const margin = t.total_revenue > 0
                  ? (((t.total_revenue - t.total_cost) / t.total_revenue) * 100).toFixed(0)
                  : '—';
                return (
                  <tr key={t.id} className={`hover:bg-muted/20 transition-colors cursor-pointer ${isOverdue ? 'bg-red-500/5' : ''}`} onClick={() => setViewingTicket(t)}>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[11px]">{SOURCE_ICON[t.source_type] || '📦'}</span>
                        <div>
                          <p className="font-semibold max-w-[140px] truncate">{t.product_name}</p>
                          <p className="text-[10px] text-muted-foreground font-mono">{t.sku || t.ticket_number}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground max-w-[100px] truncate">{t.account_name || '—'}</td>
                    <td className="px-3 py-2.5">
                      <Badge className={`text-[9px] h-5 px-1.5 gap-1 whitespace-nowrap ${cfg.color}`}>
                        <StatusIcon className="w-2.5 h-2.5" />{cfg.label}
                      </Badge>
                      {isOverdue && <span className="block text-[9px] text-red-400 mt-0.5">OVERDUE</span>}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`text-[10px] font-semibold capitalize ${PRIORITY_COLOR[t.priority]}`}>{t.priority}</span>
                    </td>
                    <td className="px-3 py-2.5 text-[10px] text-muted-foreground whitespace-nowrap">
                      {SOURCE_ICON[t.source_type]} {(t.source_type || '').replace(/_/g, ' ')}
                    </td>
                    <td className="px-3 py-2.5 font-medium">{t.quantity}</td>
                    <td className="px-3 py-2.5 text-emerald-400 font-medium whitespace-nowrap">
                      {t.total_revenue > 0 ? `$${t.total_revenue.toLocaleString()}` : '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`text-[10px] font-semibold ${Number(margin) >= 20 ? 'text-emerald-400' : Number(margin) >= 0 ? 'text-amber-400' : 'text-red-400'}`}>
                        {margin !== '—' ? `${margin}%` : '—'}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-muted-foreground max-w-[100px] truncate">{t.supplier_name || '—'}</td>
                    <td className="px-3 py-2.5">
                      {t.payment_status && (
                        <Badge className={`text-[9px] h-4 px-1.5 whitespace-nowrap ${PAY_COLOR[t.payment_status] || 'bg-muted text-muted-foreground'}`}>
                          {t.payment_status.replace(/_/g,' ')}
                        </Badge>
                      )}
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      {t.due_date ? (
                        <span className={`text-[10px] ${isOverdue ? 'text-red-400 font-semibold' : 'text-muted-foreground'}`}>
                          {new Date(t.due_date).toLocaleDateString()}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      <Button size="icon" variant="ghost" className="h-6 w-6" onClick={e => { e.stopPropagation(); onEdit(t); }}>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Detail Drawer */}
      <TicketDetailDrawer
        ticket={viewingTicket}
        open={!!viewingTicket}
        onClose={() => setViewingTicket(null)}
        onEdit={(t) => { setViewingTicket(null); onEdit(t); }}
        onRefresh={onRefresh}
      />
    </div>
  );
}