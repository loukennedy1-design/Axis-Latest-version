import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Slider } from '@/components/ui/slider';
import { Plus, Star, Loader2, Sparkles } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const RATING_COLORS = {
  exceptional: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
  exceeds_expectations: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
  meets_expectations: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
  needs_improvement: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  unsatisfactory: 'bg-red-500/10 text-red-700 border-red-500/20',
};

const emptyForm = {
  employee_id: '', review_period: '', review_date: new Date().toISOString().split('T')[0],
  reviewer_name: '', overall_rating: 'meets_expectations',
  goals_score: 3, skills_score: 3, teamwork_score: 3, communication_score: 3, initiative_score: 3,
  strengths: '', improvements: '', goals_next_period: '', comments: '', salary_adjustment: 0,
};

function StarScore({ label, value, onChange }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <Label className="text-xs">{label}</Label>
        <span className="text-xs font-bold text-primary">{value}/5</span>
      </div>
      <div className="flex gap-1">
        {[1,2,3,4,5].map(n => (
          <button key={n} onClick={() => onChange(n)}
            className={`w-7 h-7 rounded flex items-center justify-center transition-colors ${n <= value ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:bg-primary/20'}`}>
            <Star className="w-3.5 h-3.5" />
          </button>
        ))}
      </div>
    </div>
  );
}

export default function PerformanceReviews({ employees }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [generating, setGenerating] = useState(false);
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const { data: reviews = [] } = useQuery({
    queryKey: ['perf-reviews'],
    queryFn: () => base44.entities.PerformanceReview.list('-review_date'),
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'PerformanceReview', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['perf-reviews'] }); setDialogOpen(false); toast.success('Review saved'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.PerformanceReview.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['perf-reviews'] }); toast.success('Review deleted'); },
  });

  const generateAI = async () => {
    const emp = employees.find(e => e.id === form.employee_id);
    if (!emp) return toast.error('Select an employee first');
    setGenerating(true);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Write a professional performance review for ${emp.first_name} ${emp.last_name}, ${emp.job_title || 'Sales Rep'} in ${emp.department} department.
Review period: ${form.review_period || 'Q1 2026'}
Scores: Goals ${form.goals_score}/5, Skills ${form.skills_score}/5, Teamwork ${form.teamwork_score}/5, Communication ${form.communication_score}/5, Initiative ${form.initiative_score}/5

Generate a balanced, professional review.`,
      response_json_schema: {
        type: 'object',
        properties: {
          strengths: { type: 'string' },
          improvements: { type: 'string' },
          goals_next_period: { type: 'string' },
          comments: { type: 'string' },
        }
      }
    });
    setForm(p => ({ ...p, ...result }));
    setGenerating(false);
    toast.success('AI review generated');
  };

  const handleSave = () => {
    const emp = employees.find(e => e.id === form.employee_id);
    createMut.mutate({ ...form, employee_name: emp ? `${emp.first_name} ${emp.last_name}` : '', owner: user?.email });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Performance Reviews</h3>
        <Button size="sm" onClick={() => { setForm(emptyForm); setDialogOpen(true); }}>
          <Plus className="w-3.5 h-3.5 mr-1.5" />New Review
        </Button>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Employee</TableHead>
              <TableHead>Period</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Reviewer</TableHead>
              <TableHead>Overall Rating</TableHead>
              <TableHead>Avg Score</TableHead>
              <TableHead className="w-16">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reviews.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No reviews yet — create your first one</TableCell></TableRow>
            ) : reviews.map(r => {
              const avg = ((r.goals_score + r.skills_score + r.teamwork_score + r.communication_score + r.initiative_score) / 5).toFixed(1);
              return (
                <TableRow key={r.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium text-sm">{r.employee_name}</TableCell>
                  <TableCell className="text-sm">{r.review_period}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{r.review_date && format(new Date(r.review_date), 'MMM d, yyyy')}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{r.reviewer_name || '—'}</TableCell>
                  <TableCell><Badge variant="outline" className={`text-[10px] ${RATING_COLORS[r.overall_rating] || ''}`}>{r.overall_rating?.replace(/_/g,' ')}</Badge></TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      <span className="font-semibold text-sm">{avg}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMut.mutate(r.id)}>
                      <span className="text-destructive text-xs">✕</span>
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>New Performance Review</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Employee</Label>
                <Select value={form.employee_id} onValueChange={v => f('employee_id', v)}>
                  <SelectTrigger><SelectValue placeholder="Select employee..." /></SelectTrigger>
                  <SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Review Period</Label><Input value={form.review_period} onChange={e => f('review_period', e.target.value)} placeholder="e.g. Q1 2026, Annual 2025" /></div>
              <div><Label>Review Date</Label><Input type="date" value={form.review_date} onChange={e => f('review_date', e.target.value)} /></div>
              <div><Label>Reviewer Name</Label><Input value={form.reviewer_name} onChange={e => f('reviewer_name', e.target.value)} /></div>
              <div className="col-span-2">
                <Label>Overall Rating</Label>
                <Select value={form.overall_rating} onValueChange={v => f('overall_rating', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.keys(RATING_COLORS).map(r => <SelectItem key={r} value={r}>{r.replace(/_/g,' ').replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 p-4 bg-muted/30 rounded-xl">
              <StarScore label="Goal Achievement" value={form.goals_score} onChange={v => f('goals_score', v)} />
              <StarScore label="Technical Skills" value={form.skills_score} onChange={v => f('skills_score', v)} />
              <StarScore label="Teamwork" value={form.teamwork_score} onChange={v => f('teamwork_score', v)} />
              <StarScore label="Communication" value={form.communication_score} onChange={v => f('communication_score', v)} />
              <StarScore label="Initiative" value={form.initiative_score} onChange={v => f('initiative_score', v)} />
              <div><Label className="text-xs">Salary Adjustment ($)</Label><Input type="number" value={form.salary_adjustment} onChange={e => f('salary_adjustment', parseFloat(e.target.value))} /></div>
            </div>

            <Button variant="outline" className="w-full gap-2" onClick={generateAI} disabled={generating || !form.employee_id}>
              {generating ? <><Loader2 className="w-4 h-4 animate-spin" />Generating...</> : <><Sparkles className="w-4 h-4" />Generate Review with AI</>}
            </Button>

            <div><Label>Strengths</Label><Textarea value={form.strengths} onChange={e => f('strengths', e.target.value)} rows={2} /></div>
            <div><Label>Areas for Improvement</Label><Textarea value={form.improvements} onChange={e => f('improvements', e.target.value)} rows={2} /></div>
            <div><Label>Goals for Next Period</Label><Textarea value={form.goals_next_period} onChange={e => f('goals_next_period', e.target.value)} rows={2} /></div>
            <div><Label>Additional Comments</Label><Textarea value={form.comments} onChange={e => f('comments', e.target.value)} rows={2} /></div>

            <Button className="w-full" onClick={handleSave} disabled={!form.employee_id || !form.review_period}>Save Review</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}