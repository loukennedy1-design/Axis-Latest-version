import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, CheckCircle2, XCircle, Clock, CalendarDays, Umbrella } from 'lucide-react';
import { format, differenceInBusinessDays, parseISO } from 'date-fns';
import { toast } from 'sonner';

const TYPE_COLORS = {
  pto: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
  sick: 'bg-red-500/10 text-red-700 border-red-500/20',
  unpaid: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
  bereavement: 'bg-purple-500/10 text-purple-700 border-purple-500/20',
  jury_duty: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  parental: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
};

const STATUS_ICONS = {
  pending: <Clock className="w-3.5 h-3.5 text-amber-500" />,
  approved: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />,
  denied: <XCircle className="w-3.5 h-3.5 text-red-500" />,
  cancelled: <XCircle className="w-3.5 h-3.5 text-muted-foreground" />,
};

export default function TimeOffManager({ employees }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ employee_id: '', type: 'pto', start_date: '', end_date: '', reason: '' });
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const { data: requests = [] } = useQuery({
    queryKey: ['time-off'],
    queryFn: () => base44.entities.TimeOffRequest.list('-created_date'),
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'TimeOffRequest', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['time-off'] }); setDialogOpen(false); toast.success('Request created'); },
  });
  const updateStatusMut = useMutation({
    mutationFn: ({ id, status, notes }) => base44.entities.TimeOffRequest.update(id, { status, manager_notes: notes, reviewed_by: user?.email, reviewed_at: new Date().toISOString() }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['time-off'] }); toast.success('Request updated'); },
  });

  const handleCreate = () => {
    const emp = employees.find(e => e.id === form.employee_id);
    const days = form.start_date && form.end_date ? differenceInBusinessDays(parseISO(form.end_date), parseISO(form.start_date)) + 1 : 1;
    createMut.mutate({ ...form, employee_name: emp ? `${emp.first_name} ${emp.last_name}` : '', employee_email: emp?.email || '', days_requested: days, owner: user?.email });
  };

  const pending = requests.filter(r => r.status === 'pending');
  const approved = requests.filter(r => r.status === 'approved');

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Pending Requests', value: pending.length, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-500/10' },
          { label: 'Approved (YTD)', value: approved.length, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-500/10' },
          { label: 'Total Days Taken', value: approved.reduce((s, r) => s + (r.days_requested || 0), 0), icon: CalendarDays, color: 'text-blue-600', bg: 'bg-blue-500/10' },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <Card key={label}>
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bg}`}><Icon className={`w-5 h-5 ${color}`} /></div>
              <div><p className="text-xl font-bold">{value}</p><p className="text-xs text-muted-foreground">{label}</p></div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Time-Off Requests</h3>
        <Button size="sm" onClick={() => setDialogOpen(true)}><Plus className="w-3.5 h-3.5 mr-1.5" />New Request</Button>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Employee</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Dates</TableHead>
              <TableHead>Days</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead className="w-28">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {requests.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No time-off requests yet</TableCell></TableRow>
            ) : requests.map(req => (
              <TableRow key={req.id} className="hover:bg-muted/30">
                <TableCell className="font-medium text-sm">{req.employee_name || '—'}</TableCell>
                <TableCell><Badge variant="outline" className={`text-[10px] ${TYPE_COLORS[req.type] || ''}`}>{req.type}</Badge></TableCell>
                <TableCell className="text-xs text-muted-foreground">
                  {req.start_date && format(new Date(req.start_date), 'MMM d')} – {req.end_date && format(new Date(req.end_date), 'MMM d, yyyy')}
                </TableCell>
                <TableCell className="font-semibold text-sm">{req.days_requested}d</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1.5 text-xs font-medium">
                    {STATUS_ICONS[req.status]}
                    <span className="capitalize">{req.status}</span>
                  </div>
                </TableCell>
                <TableCell className="text-xs text-muted-foreground max-w-[150px] truncate">{req.reason || '—'}</TableCell>
                <TableCell>
                  {req.status === 'pending' && (
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" className="h-7 text-[11px] text-emerald-600 border-emerald-500/30 hover:bg-emerald-500/10"
                        onClick={() => updateStatusMut.mutate({ id: req.id, status: 'approved' })}>
                        Approve
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 text-[11px] text-red-600 border-red-500/30 hover:bg-red-500/10"
                        onClick={() => updateStatusMut.mutate({ id: req.id, status: 'denied' })}>
                        Deny
                      </Button>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>New Time-Off Request</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Employee</Label>
              <Select value={form.employee_id} onValueChange={v => f('employee_id', v)}>
                <SelectTrigger><SelectValue placeholder="Select employee..." /></SelectTrigger>
                <SelectContent>
                  {employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Type</Label>
              <Select value={form.type} onValueChange={v => f('type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['pto','sick','unpaid','bereavement','jury_duty','parental'].map(t => (
                    <SelectItem key={t} value={t}>{t.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Start Date</Label><Input type="date" value={form.start_date} onChange={e => f('start_date', e.target.value)} /></div>
              <div><Label>End Date</Label><Input type="date" value={form.end_date} onChange={e => f('end_date', e.target.value)} /></div>
            </div>
            <div><Label>Reason (optional)</Label><Textarea value={form.reason} onChange={e => f('reason', e.target.value)} rows={2} /></div>
            <Button className="w-full" onClick={handleCreate} disabled={!form.employee_id || !form.start_date}>Submit Request</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}