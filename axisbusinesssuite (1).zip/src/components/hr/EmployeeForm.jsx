import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ShieldCheck, KeyRound, UserPlus, Ban } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { PORTAL_ROLE_OPTIONS } from '@/hooks/useEmployeeRole';

const empty = {
  first_name: '', last_name: '', email: '', phone: '', job_title: '',
  department: '', employment_type: 'full_time', status: 'active',
  hire_date: '', salary: '', salary_type: 'hourly', pay_frequency: 'biweekly', manager_email: '',
  territory: '', address: '', emergency_contact_name: '', emergency_contact_phone: '',
  pto_balance: 15, sick_balance: 10, notes: '',
};

export { empty as emptyEmployee };

// Maps job roles to their department
const ROLE_TO_DEPT = {
  'Sales Development Rep (SDR)': 'sales',
  'Account Executive (AE)': 'sales',
  'Sales Manager': 'sales',
  'VP of Sales': 'sales',
  'Business Development Rep': 'sales',
  'Inside Sales Rep': 'sales',
  'Field Sales Rep': 'sales',
  'Marketing Manager': 'marketing',
  'Content Marketer': 'marketing',
  'Growth Hacker': 'marketing',
  'SEO Specialist': 'marketing',
  'HR Manager': 'hr',
  'HR Generalist': 'hr',
  'Recruiter': 'hr',
  'Payroll Specialist': 'hr',
  'Software Engineer': 'engineering',
  'Frontend Developer': 'engineering',
  'Backend Developer': 'engineering',
  'DevOps Engineer': 'engineering',
  'Customer Support Rep': 'support',
  'Customer Success Manager': 'support',
  'Finance Manager': 'finance',
  'Accountant': 'finance',
  'Controller': 'finance',
  'Operations Manager': 'operations',
  'Project Manager': 'operations',
  'COO': 'management',
  'CEO': 'management',
  'Director': 'management',
  'VP': 'management',
};

export default function EmployeeForm({ form, setForm, onSave, onCancel, isEdit }) {
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const qc = useQueryClient();
  const portalMut = useMutation({
    mutationFn: async ({ action, payload }) => {
      const res = await base44.functions.invoke('hrAccessControl', { action, ...payload });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: (data) => { qc.invalidateQueries({ queryKey: ['employees'] }); toast.success(data.message || 'Done'); },
    onError: (e) => toast.error(e.message || 'Action failed'),
  });
  const runPortal = (action) => () => {
    if (action === 'revoke_access' && !window.confirm("Revoke this employee's portal access? They'll be signed out and can't log in until re-invited.")) return;
    portalMut.mutate({ action, payload: { employee_id: form.id, portal_role: form.portal_role || 'sales_rep' } });
  };
  const statusLabel = form.portal_status === 'active' ? 'Active' : form.portal_status === 'disabled' ? 'Disabled' : 'Not Invited';
  const statusPillClass = form.portal_status === 'active' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : form.portal_status === 'disabled' ? 'bg-red-500/10 text-red-600 border-red-500/20' : 'bg-muted text-muted-foreground border-border';

  const handleRoleSelect = (role) => {
    const dept = ROLE_TO_DEPT[role] || '';
    setForm(p => ({ ...p, job_title: role, department: dept || p.department }));
  };

  return (
    <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>{isEdit ? 'Edit Employee' : 'Add Employee'}</DialogTitle>
      </DialogHeader>
      <div className="grid grid-cols-2 gap-4">
        <div><Label>First Name *</Label><Input value={form.first_name} onChange={e => f('first_name', e.target.value)} /></div>
        <div><Label>Last Name *</Label><Input value={form.last_name} onChange={e => f('last_name', e.target.value)} /></div>
        <div><Label>Email *</Label><Input type="email" value={form.email} onChange={e => f('email', e.target.value)} /></div>
        <div><Label>Phone</Label><Input value={form.phone} onChange={e => f('phone', e.target.value)} /></div>
        <div>
          <Label>Job Role / Title</Label>
          <Select value={form.job_title} onValueChange={handleRoleSelect}>
            <SelectTrigger><SelectValue placeholder="Select a role..." /></SelectTrigger>
            <SelectContent className="max-h-60">
              {Object.keys(ROLE_TO_DEPT).map(role => (
                <SelectItem key={role} value={role}>{role}</SelectItem>
              ))}
              <SelectItem value="__custom__">Other / Custom Title</SelectItem>
            </SelectContent>
          </Select>
          {form.job_title === '__custom__' && (
            <Input className="mt-1.5" placeholder="Enter custom title..." onChange={e => f('job_title', e.target.value)} />
          )}
        </div>
        <div>
          <Label>Department</Label>
          <Select value={form.department} onValueChange={v => f('department', v)}>
            <SelectTrigger><SelectValue placeholder="Select department..." /></SelectTrigger>
            <SelectContent>
              {['sales','marketing','operations','hr','finance','engineering','support','management'].map(d => (
                <SelectItem key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.job_title && ROLE_TO_DEPT[form.job_title] && (
            <p className="text-[10px] text-emerald-500 mt-1">✓ Auto-assigned based on role</p>
          )}
        </div>
        <div>
          <Label>Employment Type</Label>
          <Select value={form.employment_type} onValueChange={v => f('employment_type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="full_time">Full-Time (W-2)</SelectItem>
              <SelectItem value="part_time">Part-Time</SelectItem>
              <SelectItem value="contractor_1099">1099 Contractor</SelectItem>
              <SelectItem value="intern">Intern</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Status</Label>
          <Select value={form.status} onValueChange={v => f('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="probation">Probation</SelectItem>
              <SelectItem value="on_leave">On Leave</SelectItem>
              <SelectItem value="terminated">Terminated</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Hire Date</Label><Input type="date" value={form.hire_date} onChange={e => f('hire_date', e.target.value)} /></div>
        <div>
          <Label>Salary Type</Label>
          <Select value={form.salary_type} onValueChange={v => f('salary_type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="hourly">Hourly</SelectItem>
              <SelectItem value="commission">Commission</SelectItem>
              <SelectItem value="salary">Salary</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Salary / Rate ($)</Label><Input type="number" value={form.salary} onChange={e => f('salary', e.target.value)} /></div>
        <div>
          <Label>Pay Frequency</Label>
          <Select value={form.pay_frequency} onValueChange={v => f('pay_frequency', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="biweekly">Bi-Weekly</SelectItem>
              <SelectItem value="semimonthly">Semi-Monthly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Manager Email</Label><Input value={form.manager_email} onChange={e => f('manager_email', e.target.value)} /></div>
        <div><Label>Territory</Label><Input value={form.territory} onChange={e => f('territory', e.target.value)} /></div>
        <div className="col-span-2"><Label>Address</Label><Input value={form.address} onChange={e => f('address', e.target.value)} /></div>
        <div><Label>Emergency Contact Name</Label><Input value={form.emergency_contact_name} onChange={e => f('emergency_contact_name', e.target.value)} /></div>
        <div><Label>Emergency Contact Phone</Label><Input value={form.emergency_contact_phone} onChange={e => f('emergency_contact_phone', e.target.value)} /></div>
        <div><Label>PTO Balance (days)</Label><Input type="number" value={form.pto_balance} onChange={e => f('pto_balance', parseFloat(e.target.value))} /></div>
        <div><Label>Sick Balance (days)</Label><Input type="number" value={form.sick_balance} onChange={e => f('sick_balance', parseFloat(e.target.value))} /></div>
        <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} /></div>
      </div>
      {isEdit && (
        <div className="mt-5 rounded-xl border border-border bg-muted/20 p-4">
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold">Portal Access</h3>
            <span className={cn("ml-auto text-[10px] font-semibold px-2 py-0.5 rounded-full border", statusPillClass)}>{statusLabel}</span>
          </div>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Portal Role</Label>
              <Select value={form.portal_role || 'none'} onValueChange={v => f('portal_role', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">No Access</SelectItem>
                  {PORTAL_ROLE_OPTIONS.map(r => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground mt-1">Controls which modules this employee can see and use after logging in.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button size="sm" className="gap-1.5" disabled={!form.id || portalMut.isPending || (form.portal_role || 'none') === 'none'} onClick={runPortal('invite_employee')}>
                <UserPlus className="w-3.5 h-3.5" /> {form.portal_status === 'active' ? 'Resend Invite' : 'Send Invite'}
              </Button>
              <Button size="sm" variant="outline" className="gap-1.5" disabled={!form.id || portalMut.isPending} onClick={runPortal('send_password_reset')}>
                <KeyRound className="w-3.5 h-3.5" /> Reset Password
              </Button>
              <Button size="sm" variant="outline" className="gap-1.5 text-destructive" disabled={!form.id || portalMut.isPending || form.portal_status === 'disabled'} onClick={runPortal('revoke_access')}>
                <Ban className="w-3.5 h-3.5" /> Revoke Access
              </Button>
            </div>
            {!form.id && <p className="text-[10px] text-muted-foreground">Save the employee first to manage portal access.</p>}
          </div>
        </div>
      )}
      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button onClick={onSave}>{isEdit ? 'Update' : 'Add Employee'}</Button>
      </div>
    </DialogContent>
  );
}