import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FileText, FileSignature, Loader2, CheckCircle2, PenLine } from 'lucide-react';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

const DOC_TYPE_LABEL = { offer_letter: 'Offer Letter', nda: 'NDA', i9: 'Form I-9', onboarding_packet: 'Onboarding Packet', contract: 'Contract' };
const STATUS_COLORS = {
  pending_signature: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  signed: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  submitted: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
};

export default function OnboardingDocs() {
  const qc = useQueryClient();
  const [view, setView] = useState(null);
  const [signing, setSigning] = useState(null); // doc being signed
  const [signerName, setSignerName] = useState('');

  const { data: docs = [] } = useQuery({
    queryKey: ['hr-docs-onboarding'],
    queryFn: () => base44.entities.HRDocument.list('-created_date', 200),
  });

  // Only show generated onboarding docs (have linked_candidate_id or are offer/nda/i9)
  const onboarding = docs.filter(d => d.linked_candidate_id || ['offer_letter', 'nda', 'i9', 'onboarding_packet'].includes(d.doc_type));

  const handleSign = async () => {
    if (!signerName.trim()) { toast.error('Type your full name to sign'); return; }
    setSigning({ ...signing, signing: true });
    try {
      const res = await base44.functions.invoke('hrTalentEngine', { action: 'sign_document', document_id: signing.id, signer_name: signerName, signature_data: `Typed: ${signerName}` });
      if (res.data?.error) throw new Error(res.data.error);
      qc.invalidateQueries({ queryKey: ['hr-docs-onboarding'] });
      setSigning(null);
      setSignerName('');
      setView(null);
      toast.success('Document signed successfully');
    } catch (e) {
      toast.error(e.message);
    } finally {
      setSigning(s => s ? { ...s, signing: false } : null);
    }
  };

  const pendingCount = onboarding.filter(d => d.status === 'pending_signature').length;
  const signedCount = onboarding.filter(d => d.status === 'signed').length;
  const completion = onboarding.length > 0 ? Math.round((signedCount / onboarding.length) * 100) : 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-2xl font-bold text-primary">{onboarding.length}</p><p className="text-xs text-muted-foreground">Total Docs</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-2xl font-bold text-amber-400">{pendingCount}</p><p className="text-xs text-muted-foreground">Pending Signature</p></div>
        <div className="rounded-xl border border-border bg-card p-4"><p className="text-2xl font-bold text-emerald-400">{completion}%</p><p className="text-xs text-muted-foreground">Completion</p></div>
      </div>

      {onboarding.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <FileSignature className="w-8 h-8 mx-auto mb-3 opacity-40" />No onboarding documents yet. Open an applicant in the Applicants tab and click "Generate Onboarding Docs" to create AI-generated Offer Letters, NDAs, and I-9s.
        </div>
      ) : (
        <div className="space-y-2">
          {onboarding.map(d => (
            <div key={d.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0"><FileText className="w-4 h-4 text-primary" /></div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{d.title}</p>
                <p className="text-xs text-muted-foreground truncate">{d.linked_candidate_name || d.employee_name} · {DOC_TYPE_LABEL[d.doc_type] || d.doc_type}</p>
              </div>
              <Badge className={`text-[10px] ${STATUS_COLORS[d.status] || ''}`}>{d.status.replace('_', ' ')}</Badge>
              <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setView(d)}>View</Button>
            </div>
          ))}
        </div>
      )}

      {/* Document viewer + e-sign */}
      <Dialog open={!!view} onOpenChange={(o) => { if (!o) { setView(null); setSigning(null); setSignerName(''); } }}>
        <DialogContent className="max-w-3xl max-h-[88vh] overflow-y-auto">
          {view && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />{view.title}
                  {view.status === 'signed' && <Badge className="bg-emerald-500/10 text-emerald-400"><CheckCircle2 className="w-3 h-3 mr-1" />Signed</Badge>}
                </DialogTitle>
              </DialogHeader>

              <div className="bg-background border border-border rounded-lg p-6 max-h-[55vh] overflow-y-auto prose prose-sm prose-invert max-w-none whitespace-pre-wrap font-mono text-xs leading-relaxed">
                <ReactMarkdown>{view.document_content || 'No document content available.'}</ReactMarkdown>
              </div>

              {view.status === 'signed' ? (
                <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/10 p-4 text-sm">
                  <p className="flex items-center gap-2 text-emerald-400 font-semibold"><CheckCircle2 className="w-4 h-4" />Signed electronically</p>
                  <p className="text-xs text-muted-foreground mt-1">Signed by {view.signer_name} on {view.signed_date || (view.signed_at && view.signed_at.split('T')[0])}</p>
                </div>
              ) : signing ? (
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-4 space-y-3">
                  <p className="flex items-center gap-2 font-semibold text-sm"><PenLine className="w-4 h-4 text-primary" />E-Signature</p>
                  <p className="text-xs text-muted-foreground">Type your full legal name below to sign this document electronically. This constitutes a legally binding signature.</p>
                  <div><Label className="text-xs">Full legal name</Label><Input className="mt-1" value={signerName} onChange={e => setSignerName(e.target.value)} placeholder="Jane Q. Public" /></div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => { setSigning(null); setSignerName(''); }}>Cancel</Button>
                    <Button size="sm" className="gap-2 bg-emerald-600 hover:bg-emerald-700" disabled={signing.signing} onClick={handleSign}>
                      {signing.signing ? <Loader2 className="w-4 h-4 animate-spin" /> : <PenLine className="w-4 h-4" />}Sign Document
                    </Button>
                  </div>
                </div>
              ) : (
                <Button className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700" onClick={() => setSigning(view)}>
                  <PenLine className="w-4 h-4" />E-Sign This Document
                </Button>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}