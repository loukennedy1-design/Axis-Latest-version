import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { BookOpen, GraduationCap, Sparkles, Clock, Award, Play, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function LearningTab() {
  const qc = useQueryClient();
  const [genOpen, setGenOpen] = useState(false);
  const [genTopic, setGenTopic] = useState('');

  const { data: courses = [] } = useQuery({ queryKey: ['courses'], queryFn: () => base44.entities.CourseContent.list('-created_date', 100) });
  const { data: progress = [] } = useQuery({ queryKey: ['learning-progress'], queryFn: () => base44.entities.LearningProgress.list('-created_date', 100) });

  const generate = useMutation({
    mutationFn: async (topic) => {
      return base44.functions.invoke('generateCourseContent', { topic });
    },
    onSuccess: () => { toast.success('Course content generated'); qc.invalidateQueries(['courses']); setGenOpen(false); setGenTopic(''); },
    onError: () => toast.error('Course generation failed'),
  });

  const completedCount = progress.filter(p => p.status === 'completed' || p.completion_percentage >= 100).length;
  const inProgressCount = progress.filter(p => p.status !== 'completed' && p.completion_percentage > 0).length;

  return (
    <div className="space-y-5">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="p-4 rounded-xl border border-border bg-gradient-to-br from-blue-500/10 to-blue-600/5">
          <BookOpen className="w-5 h-5 text-blue-500 mb-2" />
          <p className="text-2xl font-bold">{courses.length}</p>
          <p className="text-xs text-muted-foreground">Courses Available</p>
        </div>
        <div className="p-4 rounded-xl border border-border bg-gradient-to-br from-emerald-500/10 to-emerald-600/5">
          <GraduationCap className="w-5 h-5 text-emerald-500 mb-2" />
          <p className="text-2xl font-bold">{completedCount}</p>
          <p className="text-xs text-muted-foreground">Completed</p>
        </div>
        <div className="p-4 rounded-xl border border-border bg-gradient-to-br from-amber-500/10 to-amber-600/5">
          <Clock className="w-5 h-5 text-amber-500 mb-2" />
          <p className="text-2xl font-bold">{inProgressCount}</p>
          <p className="text-xs text-muted-foreground">In Progress</p>
        </div>
        <div className="p-4 rounded-xl border border-border bg-gradient-to-br from-purple-500/10 to-purple-600/5">
          <Award className="w-5 h-5 text-purple-500 mb-2" />
          <p className="text-2xl font-bold">{progress.filter(p => p.certificate_issued).length}</p>
          <p className="text-xs text-muted-foreground">Certificates</p>
        </div>
      </div>

      {/* Generate */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">AI-powered course generation and training management</p>
        <Button size="sm" onClick={() => setGenOpen(true)}><Sparkles className="w-4 h-4 mr-1" />Generate Course</Button>
      </div>

      {/* Course list */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {courses.map(course => {
          const courseProgress = progress.find(p => p.course_id === course.id || p.course_content_id === course.id);
          const pct = courseProgress?.completion_percentage || 0;
          return (
            <Card key={course.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-sm">{course.title || course.topic || 'Untitled Course'}</h3>
                  {pct >= 100 && <Badge className="bg-emerald-500/10 text-emerald-600 text-[10px]"><Award className="w-3 h-3 mr-1" />Done</Badge>}
                </div>
                {course.description && <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{course.description}</p>}
                <div className="space-y-1">
                  <div className="flex justify-between text-xs"><span className="text-muted-foreground">Progress</span><span className="font-semibold">{pct}%</span></div>
                  <Progress value={pct} className="h-1.5" />
                </div>
                <Button variant="outline" size="sm" className="w-full mt-3"><Play className="w-3.5 h-3.5 mr-1" />{pct > 0 ? 'Continue' : 'Start Course'}</Button>
              </CardContent>
            </Card>
          );
        })}
        {courses.length === 0 && <div className="col-span-full text-center py-12 text-muted-foreground"><BookOpen className="w-8 h-8 mx-auto mb-2 opacity-40" /><p>No courses yet — generate your first AI course!</p></div>}
      </div>

      <Dialog open={genOpen} onOpenChange={setGenOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Generate AI Course</DialogTitle></DialogHeader>
          <div>
            <Label>Course Topic</Label>
            <Input value={genTopic} onChange={e => setGenTopic(e.target.value)} placeholder="e.g. Sales Techniques, Safety Training, Onboarding" />
            <p className="text-xs text-muted-foreground mt-1">Our AI will generate a complete course with lessons, quizzes, and materials.</p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGenOpen(false)}>Cancel</Button>
            <Button onClick={() => generate.mutate(genTopic)} disabled={!genTopic || generate.isPending}><Sparkles className="w-4 h-4 mr-1" />Generate</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}