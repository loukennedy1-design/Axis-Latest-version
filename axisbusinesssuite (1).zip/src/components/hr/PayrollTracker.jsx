import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calculator, DollarSign, Loader2, Play, Check, AlertTriangle, Info } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const STATUS_COLORS = {
  draft: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  processed: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  paid: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
};

// Default pay period: current biweekly period
function defaultPeriod() {
  const now = new Date();
  const start = new Date(now);
  start.setDate(now.getDate() - now.getDay() - 7); // last Sunday
  const end = new Date(start);
  end.setDate(start.getDate() + 13);
  const payDate = new Date(end);
  payDate.setDate(end.getDate() + 3);
  const fmt = d => d.toISOString().split('T')[0];
  return { start: fmt(start), end: fmt(end), payDate: fmt(payDate) };
}

export default function PayrollTracker({ employees = [] }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const period = defaultPeriod();

  const [periodStart, setPeriodStart] = useState(period.start);
  const [periodEnd, setPeriodEnd] = useState(period.end);
  const [payDate, setPayDate] = useState(period.payDate);
  const [preview, setPreview] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const { data: records = [] } = useQuery({
    queryKey: ['payroll'],
    queryFn: () => base44.entities.PayrollRecord.list('-pay_date'),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PayrollRecord.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['payroll'] }); toast.success('Status updated'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.PayrollRecord.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['payroll'] }); toast.success('Record deleted'); },
  });

  // Step 1: Preview
  const handlePreview = async () => {
    if (!periodStart || !periodEnd) { toast.error('Select a pay period first'); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke('calculatePayroll', {
        action: 'calculate_preview',
        pay_period_start: periodStart,
        pay_period_end: periodEnd,
        pay_date: payDate,
      });
      if (res.data?.error) throw new Error(res.data.error);
      setPreview(res.data);
      setPreviewOpen(true);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  // Step 2: Confirm & Run
  const handleRunPayroll = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('calculatePayroll', {
        action: 'run_payroll',
        pay_period_start: periodStart,
        pay_period_end: periodEnd,
        pay_date: payDate,
      });
      if (res.data?.error) throw new Error(res.data.error);
      qc.invalidateQueries({ queryKey: ['payroll'] });
      setPreviewOpen(false);
      setPreview(null);
      const { saved_count, skipped_count, total_net } = res.data;
      toast.success(`Payroll run complete — ${saved_count} records created, $${total_net?.toLocaleString()} total net${skipped_count > 0 ? ` (${skipped_count} skipped, already exist)` : ''}`);
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  };

  const totalPaid = records.filter(r => r.status === 'paid').reduce((s, r) => s + (r.net_pay || 0), 0);
  const totalPending = records.filter(r => r.status !== 'paid').reduce((s, r) => s + (r.net_pay || 0), 0);
  const totalRecords = records.length;

  return (
    <div className="space-y-6">
      {/* KPI cards */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Total Paid (YTD)', value: `$${totalPaid.toLocaleString()}`, bg: 'bg-emerald-500/10', color: 'text-emerald-600' },
          { label: 'Pending / Draft', value: `$${totalPending.toLocaleString()}`, bg: 'bg-amber-500/10', color: 'text-amber-600' },
          { label: 'Total Records', value: totalRecords, bg: 'bg-primary/10', color: 'text-primary' },
        ].map(({ label, value, bg, color }) => (
          <Card key={label}>
            <CardContent className="p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bg}`}>
                <DollarSign className={`w-5 h-5 ${color}`} />
              </div>
              <div>
                <p className={`text-xl font-bold ${color}`}>{value}</p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Auto-Calculate Panel */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-5">
          <div className="flex items-start gap-3 mb-4">
            <Calculator className="w-5 h-5 text-primary mt-0.5" />
            <div>
              <h3 className="font-semibold text-sm">Auto-Calculate Payroll</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                Automatically calculates gross pay, taxes (federal, state, SS, Medicare), commissions, and net pay for all active employees based on their pay type and salary on file.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3 mb-4">
            <div>
              <Label className="text-xs">Period Start</Label>
              <Input type="date" value={periodStart} onChange={e => setPeriodStart(e.target.value)} className="h-8 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Period End</Label>
              <Input type="date" value={periodEnd} onChange={e => setPeriodEnd(e.target.value)} className="h-8 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Pay Date</Label>
              <Input type="date" value={payDate} onChange={e => setPayDate(e.target.value)} className="h-8 text-sm" />
            </div>
          </div>
          <Button onClick={handlePreview} disabled={loading} className="w-full gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Calculator className="w-4 h-4" />}
            Preview & Calculate Payroll for All Employees
          </Button>
        </CardContent>
      </Card>

      {/* Records Table */}
      <div className="flex justify-between items-center">
        <h3 className="font-semibold">Payroll Records</h3>
        <span className="text-xs text-muted-foreground">{records.length} records</span>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Employee</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Pay Period</TableHead>
              <TableHead>Gross</TableHead>
              <TableHead>Commission</TableHead>
              <TableHead>Taxes</TableHead>
              <TableHead>Net Pay</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-28">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {records.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center py-12 text-muted-foreground">
                  <Calculator className="w-8 h-8 mx-auto mb-2 opacity-30" />
                  <p>No payroll records yet. Use Auto-Calculate above to generate payroll.</p>
                </TableCell>
              </TableRow>
            ) : records.map(r => {
              const taxes = (r.federal_tax || 0) + (r.state_tax || 0) + (r.social_security || 0) + (r.medicare || 0);
              return (
                <TableRow key={r.id} className="hover:bg-muted/30">
                  <TableCell className="font-medium text-sm">{r.employee_name}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="text-[10px] capitalize">{r.pay_type || 'salary'}</Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {r.pay_period_start && format(new Date(r.pay_period_start), 'MMM d')} – {r.pay_period_end && format(new Date(r.pay_period_end), 'MMM d, yyyy')}
                  </TableCell>
                  <TableCell className="text-sm">${(r.gross_pay || 0).toLocaleString()}</TableCell>
                  <TableCell className="text-sm text-primary">{r.commission > 0 ? `+$${(r.commission || 0).toLocaleString()}` : '—'}</TableCell>
                  <TableCell className="text-sm text-destructive/70">-${taxes.toLocaleString()}</TableCell>
                  <TableCell className="font-bold text-emerald-600">${(r.net_pay || 0).toLocaleString()}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[r.status] || ''}`}>{r.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {r.status === 'draft' && (
                        <Button size="sm" variant="outline" className="h-7 text-[11px]" onClick={() => updateMut.mutate({ id: r.id, data: { status: 'processed' } })}>Process</Button>
                      )}
                      {r.status === 'processed' && (
                        <Button size="sm" variant="outline" className="h-7 text-[11px] text-emerald-600 border-emerald-500/30" onClick={() => updateMut.mutate({ id: r.id, data: { status: 'paid' } })}>Mark Paid</Button>
                      )}
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMut.mutate(r.id)}>
                        <span className="text-destructive text-xs">✕</span>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-primary" />
              Payroll Preview — {periodStart} to {periodEnd}
            </DialogTitle>
          </DialogHeader>

          {preview && (
            <div className="space-y-4">
              {/* Summary cards */}
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: 'Employees', value: preview.summary?.employee_count, color: 'text-foreground' },
                  { label: 'Total Gross', value: `$${(preview.summary?.total_gross || 0).toLocaleString()}`, color: 'text-amber-600' },
                  { label: 'Total Taxes', value: `$${(preview.summary?.total_taxes || 0).toLocaleString()}`, color: 'text-destructive/70' },
                  { label: 'Total Net Pay', value: `$${(preview.summary?.total_net || 0).toLocaleString()}`, color: 'text-emerald-600' },
                ].map(s => (
                  <Card key={s.label}>
                    <CardContent className="p-3 text-center">
                      <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-sm">
                <Info className="w-4 h-4 text-amber-600 shrink-0" />
                <span className="text-amber-700">Review the entries below. Taxes are estimated using 2024 federal brackets + 5% state flat rate. Commission amounts are pulled from approved RepCommission records for this period.</span>
              </div>

              <div className="bg-card border border-border rounded-xl overflow-hidden max-h-64 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead>Employee</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Gross</TableHead>
                      <TableHead>Commission</TableHead>
                      <TableHead>Fed Tax</TableHead>
                      <TableHead>State Tax</TableHead>
                      <TableHead>SS+Medicare</TableHead>
                      <TableHead className="font-bold">Net Pay</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(preview.preview || []).map((r, i) => (
                      <TableRow key={i} className="text-sm">
                        <TableCell className="font-medium">{r.employee_name}</TableCell>
                        <TableCell><Badge variant="outline" className="text-[10px] capitalize">{r.pay_type}</Badge></TableCell>
                        <TableCell>${(r.gross_pay || 0).toLocaleString()}</TableCell>
                        <TableCell className="text-primary">{r.commission > 0 ? `+$${r.commission.toLocaleString()}` : '—'}</TableCell>
                        <TableCell className="text-destructive/70">-${(r.federal_tax || 0).toLocaleString()}</TableCell>
                        <TableCell className="text-destructive/70">-${(r.state_tax || 0).toLocaleString()}</TableCell>
                        <TableCell className="text-destructive/70">-${((r.social_security || 0) + (r.medicare || 0)).toLocaleString()}</TableCell>
                        <TableCell className="font-bold text-emerald-600">${(r.net_pay || 0).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex gap-3 pt-2">
                <Button variant="outline" className="flex-1" onClick={() => setPreviewOpen(false)}>Cancel</Button>
                <Button className="flex-1 gap-2 bg-emerald-600 hover:bg-emerald-700" onClick={handleRunPayroll} disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                  Confirm & Run Payroll
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}