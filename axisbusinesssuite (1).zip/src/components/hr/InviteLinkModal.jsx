import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Copy, Mail, Check, Clock, Loader2, Link2 } from 'lucide-react';
import { toast } from 'sonner';

export default function InviteLinkModal({ open, onOpenChange, inviteData, employeeId, employeeName, onRevoked }) {
  const [copied, setCopied] = useState(false);
  const [sending, setSending] = useState(false);
  const [revoking, setRevoking] = useState(false);

  if (!inviteData) return null;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(inviteData.invite_url);
      setCopied(true);
      toast.success('Link copied to clipboard');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback for older browsers
      const el = document.createElement('textarea');
      el.value = inviteData.invite_url;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleSendEmail = async () => {
    setSending(true);
    try {
      const res = await base44.functions.invoke('hrPortalInvite', {
        action: 'send_invite_email',
        employee_id: employeeId,
      });
      if (res.data?.success) {
        toast.success(res.data.message || 'Invite email sent');
        onOpenChange(false);
      } else {
        toast.error(res.data?.error || 'Could not send email');
      }
    } catch (e) {
      toast.error(e?.response?.data?.error || 'Could not send email');
    } finally {
      setSending(false);
    }
  };

  const handleRevoke = async () => {
    if (!window.confirm('Revoke this invite link? The employee will no longer be able to use it to activate their account.')) return;
    setRevoking(true);
    try {
      const res = await base44.functions.invoke('hrPortalInvite', {
        action: 'revoke_invite',
        employee_id: employeeId,
      });
      if (res.data?.success) {
        toast.success(res.data.message || 'Invite revoked');
        onOpenChange(false);
        onRevoked?.();
      } else {
        toast.error(res.data?.error || 'Could not revoke');
      }
    } catch (e) {
      toast.error(e?.response?.data?.error || 'Could not revoke');
    } finally {
      setRevoking(false);
    }
  };

  const expiresIn = () => {
    if (!inviteData.expires_at) return '72 hours';
    const ms = new Date(inviteData.expires_at).getTime() - Date.now();
    if (ms <= 0) return 'expired';
    const hrs = Math.floor(ms / (1000 * 60 * 60));
    if (hrs >= 24) return `${Math.floor(hrs / 24)} day(s)`;
    return `${hrs} hour(s)`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Link2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-base">Invite Link Ready</DialogTitle>
              <DialogDescription className="text-xs">
                for {employeeName || inviteData.employee_email}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          {/* Role badge */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Portal role:</span>
            <span className="text-xs font-semibold text-primary bg-primary/10 border border-primary/20 rounded-full px-2.5 py-0.5">
              {inviteData.role_label || 'Team Member'}
            </span>
          </div>

          {/* Invite URL — read-only */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Invite URL</label>
            <div className="relative">
              <Input
                readOnly
                value={inviteData.invite_url}
                className="pr-10 text-xs font-mono h-10 bg-muted/30 select-all"
                onClick={(e) => e.target.select()}
              />
              <button
                onClick={handleCopy}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary transition-colors p-1"
                title="Copy link"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Expiry note */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Clock className="w-3.5 h-3.5" />
            <span>Expires in <span className="text-foreground font-medium">{expiresIn()}</span></span>
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-2 pt-2">
            <Button onClick={handleCopy} size="lg" className="w-full">
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied!' : 'Copy Link'}
            </Button>
            <Button onClick={handleSendEmail} variant="outline" size="lg" className="w-full" disabled={sending}>
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              Send via Email
            </Button>
            <Button onClick={handleRevoke} variant="ghost" size="sm" className="w-full text-destructive hover:text-destructive" disabled={revoking}>
              {revoking ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Revoke Invite Link'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}