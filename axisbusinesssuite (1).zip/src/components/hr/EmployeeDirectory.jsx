import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Search, Pencil, Trash2, Mail, User, ArrowRight, UserPlus, KeyRound, Link2 } from 'lucide-react';
import InviteLinkModal from './InviteLinkModal';
import { format } from 'date-fns';
import { toast } from 'sonner';
import EmployeeForm, { emptyEmployee } from './EmployeeForm';
import { PORTAL_ROLE_OPTIONS } from '@/hooks/useEmployeeRole';

const STATUS_COLORS = {
  active: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
  probation: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  on_leave: 'bg-blue-500/10 text-blue-700 border-blue-500/20',
  terminated: 'bg-red-500/10 text-red-700 border-red-500/20',
};

const DEPT_COLORS = {
  sales: 'bg-primary/10 text-primary', marketing: 'bg-pink-500/10 text-pink-700',
  operations: 'bg-slate-500/10 text-slate-700', hr: 'bg-purple-500/10 text-purple-700',
  finance: 'bg-emerald-500/10 text-emerald-700', engineering: 'bg-blue-500/10 text-blue-700',
  support: 'bg-amber-500/10 text-amber-700', management: 'bg-red-500/10 text-red-700',
};

const PORTAL_BADGES = {
  not_invited: 'bg-zinc-500/10 text-zinc-500 border-zinc-500/20',
  invite_sent: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  active: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  disabled: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const portalStatusInfo = (emp) => {
  if (emp.portal_status === 'active') return { label: 'Active', cls: PORTAL_BADGES.active };
  if (emp.portal_status === 'disabled') return { label: 'Disabled', cls: PORTAL_BADGES.disabled };
  if (emp.invite_token) return { label: 'Invite Sent', cls: PORTAL_BADGES.invite_sent };
  return { label: 'Not Invited', cls: PORTAL_BADGES.not_invited };
};

export default function EmployeeDirectory({ onSelectEmployee }) {
  const { user } = useCurrentUser();
  const subscriberEmail = user?.account_owner_email || user?.email;
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editEmp, setEditEmp] = useState(null);
  const [form, setForm] = useState(emptyEmployee);
  const [inviteRole, setInviteRole] = useState({});
  const [inviteModal, setInviteModal] = useState({ open: false, data: null, employeeId: null, employeeName: '' });

  const { data: employees = [], isLoading } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list('-hire_date'),
  });

  const createMut = useMutation({
    mutationFn: (data) => base44.entities.Employee.create({ ...data, owner: subscriberEmail, employee_email: data.email }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['employees'] });
      setDialogOpen(false);
      setForm(emptyEmployee);
      toast.success('Employee added');
    },
    onError: (err) => {
      console.error('Create failed:', err);
      toast.error('Failed to add employee: ' + (err?.message || 'Unknown error'));
    },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Employee.update(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['employees'] });
      setDialogOpen(false);
      setEditEmp(null);
      setForm(emptyEmployee);
      toast.success('Employee updated');
    },
    onError: (err) => {
      console.error('Update failed:', err);
      toast.error('Failed to update employee: ' + (err?.message || 'Unknown error'));
    },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Employee.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['employees'] }); toast.success('Employee removed'); },
  });

  const confirmDeleteEmp = (id) => {
    if (window.confirm('Delete this employee? This will remove all associated data.')) {
      deleteMut.mutate(id);
    }
  };

  const portalAction = async (action, payload) => {
    const res = await base44.functions.invoke('hrAccessControl', { action, ...payload });
    if (res.data?.error) throw new Error(res.data.error);
    return res.data;
  };

  const generateInviteMut = useMutation({
    mutationFn: async ({ employee_id, portal_role }) => {
      const res = await base44.functions.invoke('hrPortalInvite', { action: 'generate_invite', employee_id, portal_role });
      if (res.data?.error) throw new Error(res.data.error);
      return { ...res.data, employee_id };
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['employees'] });
      setInviteModal({ open: true, data, employeeId: data.employee_id, employeeName: data.employee_name || '' });
    },
    onError: (e) => toast.error(e.message || 'Could not generate invite'),
  });
  const resetMut = useMutation({
    mutationFn: (employee_id) => portalAction('send_password_reset', { employee_id }),
    onSuccess: (data) => toast.success(data.message || 'Reset link sent'),
    onError: (e) => toast.error(e.message || 'Could not send reset'),
  });

  const openNew = () => { setEditEmp(null); setForm(emptyEmployee); setDialogOpen(true); };
  const openEdit = (emp) => { setEditEmp(emp); setForm(emp); setDialogOpen(true); };
  const handleSave = () => {
    if (editEmp) updateMut.mutate({ id: editEmp.id, data: form });
    else createMut.mutate({ ...form, owner: subscriberEmail });
  };

  const filtered = employees.filter(e => {
    const name = `${e.first_name} ${e.last_name} ${e.email} ${e.job_title}`.toLowerCase();
    return name.includes(search.toLowerCase())
      && (deptFilter === 'all' || e.department === deptFilter)
      && (statusFilter === 'all' || e.status === statusFilter);
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3 flex-1 flex-wrap">
          <div className="relative min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search employees..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={deptFilter} onValueChange={setDeptFilter}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Department" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              {['sales','marketing','operations','hr','finance','engineering','support','management'].map(d => (
                <SelectItem key={d} value={d}>{d.charAt(0).toUpperCase() + d.slice(1)}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-32"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="probation">Probation</SelectItem>
              <SelectItem value="on_leave">On Leave</SelectItem>
              <SelectItem value="terminated">Terminated</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" />Add Employee</Button>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Employee</TableHead>
              <TableHead>Title / Dept</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Portal</TableHead>
              <TableHead>Hire Date</TableHead>
              <TableHead>PTO Left</TableHead>
              <TableHead>Routing</TableHead>
              <TableHead className="w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-10 text-muted-foreground">Loading...</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={8} className="text-center py-16">
                  <User className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">No employees found</p>
                  <Button size="sm" variant="outline" className="mt-3" onClick={openNew}><Plus className="w-3.5 h-3.5 mr-1.5" />Add First Employee</Button>
                </TableCell>
              </TableRow>
            ) : filtered.map(emp => (
              <TableRow key={emp.id} className="hover:bg-muted/30 cursor-pointer" onClick={() => onSelectEmployee?.(emp)}>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                      {emp.first_name[0]}{emp.last_name[0]}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{emp.first_name} {emp.last_name}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1"><Mail className="w-3 h-3" />{emp.email}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <p className="text-sm font-medium">{emp.job_title || '—'}</p>
                  <Badge variant="outline" className={`text-[10px] mt-0.5 ${DEPT_COLORS[emp.department] || ''}`}>{emp.department}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-[10px]">{emp.employment_type?.replace(/_/g, ' ') || '—'}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[emp.status] || ''}`}>{emp.status}</Badge>
                </TableCell>
                <TableCell>
                  {(() => { const pi = portalStatusInfo(emp); return <Badge variant="outline" className={`text-[10px] ${pi.cls}`}>{pi.label}</Badge>; })()}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {emp.hire_date ? format(new Date(emp.hire_date), 'MMM d, yyyy') : '—'}
                </TableCell>
                <TableCell>
                  <span className={`text-sm font-semibold ${(emp.pto_balance || 0) < 3 ? 'text-red-500' : 'text-emerald-600'}`}>
                    {emp.pto_balance || 0}d
                  </span>
                </TableCell>
                <TableCell>
                  {emp.department === 'sales' ? (
                    <span className="flex items-center gap-1 text-[10px] font-semibold text-primary bg-primary/10 border border-primary/20 rounded-full px-2 py-0.5 w-fit">
                      <ArrowRight className="w-3 h-3" />Sales Team
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground capitalize">{emp.department}</span>
                  )}
                </TableCell>
                <TableCell onClick={e => e.stopPropagation()}>
                  <div className="flex gap-1 items-center">
                    <Button variant="ghost" size="icon" className="h-7 w-7" title="Generate Invite Link" disabled={generateInviteMut.isPending} onClick={() => generateInviteMut.mutate({ employee_id: emp.id, portal_role: emp.portal_role && emp.portal_role !== 'none' ? emp.portal_role : 'sales_rep' })}>
                      <Link2 className="w-3.5 h-3.5 text-primary" />
                    </Button>
                    {emp.portal_status === 'active' && (
                      <Button variant="ghost" size="icon" className="h-7 w-7" title="Send Password Reset" onClick={() => { if (window.confirm(`Send a password reset link to ${emp.email}?`)) resetMut.mutate(emp.id); }}><KeyRound className="w-3.5 h-3.5" /></Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(emp)}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => confirmDeleteEmp(emp.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <InviteLinkModal
        open={inviteModal.open}
        onOpenChange={(v) => setInviteModal(s => ({ ...s, open: v }))}
        inviteData={inviteModal.data}
        employeeId={inviteModal.employeeId}
        employeeName={inviteModal.employeeName}
        onRevoked={() => qc.invalidateQueries({ queryKey: ['employees'] })}
      />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <EmployeeForm form={form} setForm={setForm} onSave={handleSave} onCancel={() => setDialogOpen(false)} isEdit={!!editEmp} />
      </Dialog>
    </div>
  );
}