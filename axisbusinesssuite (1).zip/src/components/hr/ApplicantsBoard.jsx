import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Sparkles, Calendar, FileSignature, Loader2, TrendingUp, TrendingDown, Minus, Mail, Phone, MapPin } from 'lucide-react';
import ScheduleMeetingDialog from '@/components/meet/ScheduleMeetingDialog';
import { toast } from 'sonner';

const STATUS_COLORS = {
  new: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  screening: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  interview_scheduled: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  interviewed: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
  offer_sent: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  hired: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  rejected: 'bg-red-500/10 text-red-400 border-red-500/20',
  archived: 'bg-muted text-muted-foreground',
};

function scoreColor(s) { return s >= 80 ? 'text-emerald-400' : s >= 60 ? 'text-amber-400' : s >= 40 ? 'text-orange-400' : 'text-red-400'; }
function recIcon(r) { return r === 'advance' ? TrendingUp : r === 'reject' ? TrendingDown : Minus; }

export default function ApplicantsBoard() {
  const qc = useQueryClient();
  const [selected, setSelected] = useState(null);
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [schedulePrefill, setSchedulePrefill] = useState(null);

  const { data: candidates = [] } = useQuery({ queryKey: ['candidates-all'], queryFn: () => base44.entities.Candidate.list('-created_date', 300) });

  const score = useMutation({
    mutationFn: (candidate_id) => base44.functions.invoke('hrTalentEngine', { action: 'score_applicant', candidate_id }),
    onSuccess: (res) => {
      if (res.data?.error) { toast.error(res.data.error); return; }
      qc.invalidateQueries({ queryKey: ['candidates-all'] });
      toast.success(`AI score: ${res.data.ai_fit_score}/100 — ${res.data.recommendation}`);
    },
  });

  const generateDocs = useMutation({
    mutationFn: (payload) => base44.functions.invoke('hrTalentEngine', { action: 'generate_onboarding_docs', ...payload }),
    onSuccess: (res) => {
      if (res.data?.error) { toast.error(res.data.error); return; }
      qc.invalidateQueries({ queryKey: ['hr-docs'] });
      toast.success(res.data.message || 'Onboarding docs generated & emailed');
    },
  });

  const updateStatus = useMutation({
    mutationFn: ({ id, status }) => base44.entities.Candidate.update(id, { status }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['candidates-all'] }),
  });

  const sorted = [...candidates].sort((a, b) => (b.ai_fit_score || 0) - (a.ai_fit_score || 0));
  const parsed = (c) => { try { return JSON.parse(c.ai_analysis || '{}'); } catch { return {}; } };

  const openSchedule = (c) => {
    setSchedulePrefill({
      title: `Interview — ${c.first_name} ${c.last_name} for ${c.position_applied || 'open role'}`,
      department: 'recruitment',
      linked_record_type: 'candidate',
      linked_record_id: c.id,
      guest_name: `${c.first_name} ${c.last_name}`,
      guest_email: c.email,
    });
    setScheduleOpen(true);
    updateStatus.mutate({ id: c.id, status: 'interview_scheduled' });
  };

  const sel = selected ? candidates.find(c => c.id === selected) : null;
  const selAnalysis = sel ? parsed(sel) : {};

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{candidates.length} applicants — ranked by AI fit score</p>
      </div>

      {candidates.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Sparkles className="w-8 h-8 mx-auto mb-3 opacity-40" />No applicants yet. They'll appear here automatically when someone applies via your public Careers page.
        </div>
      ) : (
        <div className="space-y-2">
          {sorted.map(c => {
            const a = parsed(c);
            const RecIcon = recIcon(a.recommendation);
            return (
              <div key={c.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl hover:border-primary/30 transition-all cursor-pointer" onClick={() => setSelected(c.id)}>
                <div className={`w-12 h-12 rounded-xl flex flex-col items-center justify-center bg-background/60 border border-border shrink-0`}>
                  <span className={`text-lg font-bold leading-none ${scoreColor(c.ai_fit_score || 0)}`}>{c.ai_fit_score || '—'}</span>
                  <span className="text-[9px] text-muted-foreground">SCORE</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{c.first_name} {c.last_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{c.position_applied || 'General applicant'} · {c.source || 'direct'}</p>
                </div>
                {a.recommendation && (
                  <Badge variant="outline" className={`capitalize text-[10px] hidden sm:flex ${a.recommendation === 'advance' ? 'text-emerald-400' : a.recommendation === 'reject' ? 'text-red-400' : 'text-amber-400'}`}>
                    <RecIcon className="w-3 h-3 mr-1" />{a.recommendation}
                  </Badge>
                )}
                <Badge className={`capitalize text-[10px] ${STATUS_COLORS[c.status] || ''}`}>{c.status.replace('_', ' ')}</Badge>
                <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={(e) => { e.stopPropagation(); setScheduleOpen(false); setSelected(c.id); }}>View</Button>
              </div>
            );
          })}
        </div>
      )}

      {/* Candidate detail */}
      <Dialog open={!!selected} onOpenChange={(o) => !o && setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[88vh] overflow-y-auto">
          {sel && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <span>{sel.first_name} {sel.last_name}</span>
                  <Badge className={`capitalize ${STATUS_COLORS[sel.status] || ''}`}>{sel.status.replace('_', ' ')}</Badge>
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{sel.email}</span>
                  {sel.phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{sel.phone}</span>}
                  {sel.current_company && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{sel.current_company}</span>}
                </div>

                {/* AI Score block */}
                <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-primary" />
                      <span className="font-semibold text-sm">AI Fit Assessment</span>
                    </div>
                    {sel.ai_fit_score ? (
                      <span className={`text-2xl font-bold ${scoreColor(sel.ai_fit_score)}`}>{sel.ai_fit_score}<span className="text-sm text-muted-foreground">/100</span></span>
                    ) : null}
                  </div>
                  {!sel.ai_fit_score ? (
                    <Button size="sm" className="w-full gap-2" disabled={score.isPending} onClick={() => score.mutate(sel.id)}>
                      {score.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}Run AI Screening
                    </Button>
                  ) : (
                    <div className="space-y-2 text-sm">
                      {selAnalysis.summary && <p className="text-muted-foreground">{selAnalysis.summary}</p>}
                      {selAnalysis.strengths?.length > 0 && (
                        <div><p className="text-xs font-semibold text-emerald-400 mb-1">Strengths</p><ul className="text-xs space-y-0.5">{selAnalysis.strengths.map((s, i) => <li key={i} className="text-muted-foreground">• {s}</li>)}</ul></div>
                      )}
                      {selAnalysis.gaps?.length > 0 && (
                        <div><p className="text-xs font-semibold text-amber-400 mb-1">Gaps</p><ul className="text-xs space-y-0.5">{selAnalysis.gaps.map((s, i) => <li key={i} className="text-muted-foreground">• {s}</li>)}</ul></div>
                      )}
                      <Button size="sm" variant="outline" className="w-full mt-1" disabled={score.isPending} onClick={() => score.mutate(sel.id)}>Re-run screening</Button>
                    </div>
                  )}
                </div>

                {/* Resume preview */}
                {sel.resume_text && (
                  <div>
                    <p className="text-xs font-semibold mb-1">Resume</p>
                    <p className="text-xs text-muted-foreground bg-muted/40 rounded-lg p-3 max-h-32 overflow-y-auto whitespace-pre-wrap">{sel.resume_text}</p>
                  </div>
                )}
                {sel.interview_feedback && (
                  <div>
                    <p className="text-xs font-semibold mb-1">Interview Notes (auto-saved from AXIS Meet)</p>
                    <p className="text-xs text-muted-foreground bg-muted/40 rounded-lg p-3 max-h-32 overflow-y-auto whitespace-pre-wrap">{sel.interview_feedback}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <Button variant="outline" size="sm" className="gap-2" onClick={() => openSchedule(sel)}>
                    <Calendar className="w-4 h-4" />Schedule Interview
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2" onClick={() => updateStatus.mutate({ id: sel.id, status: 'offer_sent' })}>
                    <FileSignature className="w-4 h-4" />Mark Offer Sent
                  </Button>
                  <Button size="sm" className="gap-2 col-span-2 bg-emerald-600 hover:bg-emerald-700" disabled={generateDocs.isPending} onClick={() => generateDocs.mutate({ candidate_id: sel.id, job_title: sel.position_applied })}>
                    {generateDocs.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSignature className="w-4 h-4" />}Generate Onboarding Docs (Offer, NDA, I-9)
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <ScheduleMeetingDialog open={scheduleOpen} onOpenChange={setScheduleOpen} prefill={schedulePrefill} />
    </div>
  );
}