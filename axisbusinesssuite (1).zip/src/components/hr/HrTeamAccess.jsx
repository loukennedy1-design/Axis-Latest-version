import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Users, Clock, Star, Briefcase, Sparkles, DollarSign, FileText, FileSignature,
  ShieldCheck, Save, Loader2, Lock, UserCog,
} from 'lucide-react';
import { toast } from 'sonner';

// Area metadata shared with the HR page gating.
const AREAS = [
  { key: 'can_view_employees', label: 'Employees', icon: Users, desc: 'Directory & profiles' },
  { key: 'can_view_timeoff', label: 'Time Off', icon: Clock, desc: 'PTO requests' },
  { key: 'can_view_performance', label: 'Performance', icon: Star, desc: 'Reviews & ratings' },
  { key: 'can_view_jobs', label: 'Job Postings', icon: Briefcase, desc: 'Open roles' },
  { key: 'can_view_applicants', label: 'Applicants', icon: Sparkles, desc: 'Candidate pipeline' },
  { key: 'can_view_payroll', label: 'Payroll', icon: DollarSign, desc: 'Pay & earnings' },
  { key: 'can_view_documents', label: 'Documents', icon: FileText, desc: 'HR files & e-sign' },
  { key: 'can_view_onboarding', label: 'Onboarding', icon: FileSignature, desc: 'New-hire packets' },
];

const ALL_FIELDS = AREAS.map((a) => a.key);

export default function HrTeamAccess() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [drafts, setDrafts] = useState({}); // user_email -> permission object

  const { data, isLoading } = useQuery({
    queryKey: ['hr-team-permissions'],
    queryFn: async () => {
      const res = await base44.functions.invoke('hrAccessControl', { action: 'list_team' });
      return res.data;
    },
  });

  const team = data?.team || [];

  // Resolve a member's effective permissions (saved record, or defaults, overridden by local draft)
  const permsFor = (member) => {
    const saved = member.permissions || {};
    const base = {
      full_access: !!saved.full_access,
      can_view_employees: saved.can_view_employees ?? true,
      can_view_timeoff: saved.can_view_timeoff ?? true,
      can_view_performance: saved.can_view_performance ?? false,
      can_view_jobs: saved.can_view_jobs ?? false,
      can_view_applicants: saved.can_view_applicants ?? false,
      can_view_payroll: saved.can_view_payroll ?? false,
      can_view_documents: saved.can_view_documents ?? true,
      can_view_onboarding: saved.can_view_onboarding ?? false,
    };
    return { ...base, ...(drafts[member.user.email] || {}) };
  };

  const setField = (email, field, value) => {
    setDrafts((d) => ({
      ...d,
      [email]: { ...(d[email] || permsFor(team.find((m) => m.user.email === email))), [field]: value },
    }));
  };

  const saveMut = useMutation({
    mutationFn: async ({ email, perms }) => {
      const res = await base44.functions.invoke('hrAccessControl', { action: 'save', target_email: email, permissions: perms });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: (_d, vars) => {
      setDrafts((d) => { const n = { ...d }; delete n[vars.email]; return n; });
      qc.invalidateQueries({ queryKey: ['hr-team-permissions'] });
      qc.invalidateQueries({ queryKey: ['hr-permissions-mine'] });
      toast.success('Access updated');
    },
    onError: (e) => toast.error(e.message || 'Could not save'),
  });

  const dirtyCount = Object.keys(drafts).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Isolation banner */}
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="p-4 flex items-start gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
          </div>
          <div>
            <p className="text-sm font-semibold text-emerald-400">Tenant-isolated & admin-only</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              You're managing HR access for your account only. Other accounts cannot see your HR data, and you cannot see theirs.
              Only you (the account admin) and your team members appear here.
            </p>
          </div>
        </CardContent>
      </Card>

      {team.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center">
            <UserCog className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
            <p className="font-medium">No team members yet</p>
            <p className="text-sm text-muted-foreground mt-1">
              Invite team members from your account, then return here to control what each person can see and use in HR.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {team.map((member) => {
            const perms = permsFor(member);
            const dirty = !!drafts[member.user.email];
            return (
              <Card key={member.user.id}>
                <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
                      {member.user.full_name?.charAt(0) || member.user.email.charAt(0)}
                    </div>
                    <div>
                      <CardTitle className="text-sm">{member.user.full_name || member.user.email}</CardTitle>
                      <p className="text-xs text-muted-foreground">{member.user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-[10px] capitalize">{member.user.role}</Badge>
                    <Button
                      size="sm"
                      className="h-7 gap-1.5"
                      disabled={!dirty || saveMut.isPending}
                      onClick={() => saveMut.mutate({ email: member.user.email, perms })}
                    >
                      {saveMut.isPending && saveMut.variables?.email === member.user.email
                        ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        : <Save className="w-3.5 h-3.5" />}
                      Save
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pt-0 space-y-4">
                  {/* Full access master toggle */}
                  <div className="flex items-center justify-between rounded-lg border border-primary/20 bg-primary/5 p-3">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-primary" />
                      <div>
                        <p className="text-sm font-semibold">Full HR access</p>
                        <p className="text-[11px] text-muted-foreground">Grant every HR area (same as an admin)</p>
                      </div>
                    </div>
                    <Switch
                      checked={perms.full_access}
                      onCheckedChange={(v) => setField(member.user.email, 'full_access', v)}
                    />
                  </div>

                  {/* Per-area toggles */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {AREAS.map((area) => {
                      const Icon = area.icon;
                      const granted = perms.full_access || perms[area.key];
                      return (
                        <div
                          key={area.key}
                          className={`flex items-center justify-between rounded-lg border p-3 transition-colors ${granted ? 'border-border bg-muted/20' : 'border-border bg-muted/5 opacity-70'}`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${granted ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                              {granted ? <Icon className="w-4 h-4" /> : <Lock className="w-3.5 h-3.5" />}
                            </div>
                            <div className="min-w-0">
                              <p className="text-sm font-medium truncate">{area.label}</p>
                              <p className="text-[11px] text-muted-foreground truncate">{area.desc}</p>
                            </div>
                          </div>
                          <Switch
                            disabled={perms.full_access}
                            checked={granted}
                            onCheckedChange={(v) => setField(member.user.email, area.key, v)}
                          />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}