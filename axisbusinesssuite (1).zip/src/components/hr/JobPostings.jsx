import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Briefcase, Pencil, Power, Trash2, Users, Loader2, MapPin, ExternalLink } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';

const STATUS_COLORS = {
  open: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  closed: 'bg-muted text-muted-foreground',
  draft: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
};

const EMPTY = { title: '', department: '', location: '', employment_type: 'full_time', pay_min: '', pay_max: '', description: '', requirements: '', status: 'open' };

export default function JobPostings() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [deleteId, setDeleteId] = useState(null);
  const { dataOwnerEmail } = useCurrentUser();

  // Use backend function with service role to fetch ALL job postings (not just owner-scoped)
  const { data: jobs = [] } = useQuery({
    queryKey: ['job-postings'],
    queryFn: async () => {
      const res = await base44.functions.invoke('publicCareers', { action: 'list_jobs' });
      return res.data?.jobs || [];
    },
  });

  const save = useMutation({
    mutationFn: async (data) => {
      const payload = {
        ...data,
        pay_min: parseFloat(data.pay_min) || 0,
        pay_max: parseFloat(data.pay_max) || 0,
      };
      if (editing) {
        // Update existing via service role (preserves apply_count, posted_by, etc.)
        return base44.asServiceRole.entities.JobPosting.update(editing.id, payload);
      }
      // Create new — stamp owner/posted_by for RLS and traceability
      return base44.entities.JobPosting.create({
        ...payload,
        owner: dataOwnerEmail || undefined,
        posted_by: dataOwnerEmail || undefined,
        posted_date: new Date().toISOString(),
        apply_count: 0,
      });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['job-postings'] }); setOpen(false); setForm(EMPTY); setEditing(null); toast.success(editing ? 'Job updated' : 'Job posted'); },
    onError: (err) => { toast.error(err?.message || 'Failed to save job posting'); },
  });

  const toggleStatus = useMutation({
    mutationFn: ({ id, status }) => base44.asServiceRole.entities.JobPosting.update(id, { status }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['job-postings'] }),
    onError: (err) => { toast.error(err?.message || 'Failed to update status'); },
  });

  const remove = useMutation({
    mutationFn: (id) => base44.functions.invoke('deleteJobPosting', { job_id: id }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['job-postings'] }); toast.success('Job removed'); },
    onError: (err) => { toast.error(err?.message || 'Failed to delete job posting'); },
  });

  const openEdit = (job) => { setEditing(job); setForm({ title: job.title, department: job.department, location: job.location || '', employment_type: job.employment_type || 'full_time', pay_min: job.pay_min || '', pay_max: job.pay_max || '', description: job.description || '', requirements: job.requirements || '', status: job.status || 'open' }); setOpen(true); };
  const openNew = () => { setEditing(null); setForm(EMPTY); setOpen(true); };
  const confirmDelete = (id) => { setDeleteId(id); };
  const handleDelete = () => { if (deleteId) { remove.mutate(deleteId); setDeleteId(null); } };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">{jobs.length} job postings — public applicants apply via your Careers page</p>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" className="gap-2" onClick={() => window.open('/careers', '_blank')}><ExternalLink className="w-4 h-4" />View Public Page</Button>
          <Button size="sm" className="gap-2" onClick={openNew}><Plus className="w-4 h-4" />New Posting</Button>
        </div>
      </div>

      {jobs.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border p-12 text-center text-muted-foreground text-sm">
          <Briefcase className="w-8 h-8 mx-auto mb-3 opacity-40" />No job postings yet. Create your first one — it'll appear on your public Careers page instantly.
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {jobs.map(job => (
            <div key={job.id} className="rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-all">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0">
                  <h3 className="font-semibold text-sm truncate">{job.title}</h3>
                  <p className="text-xs text-muted-foreground">{job.department}{job.location ? ` · ${job.location}` : ''}</p>
                </div>
                <Badge className={`capitalize ${STATUS_COLORS[job.status] || ''}`}>{job.status}</Badge>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{job.description || 'No description'}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  {job.pay_min ? <span>${job.pay_min.toLocaleString()}{job.pay_max ? `–$${job.pay_max.toLocaleString()}` : '+'}</span> : null}
                  <span className="flex items-center gap-1"><Users className="w-3 h-3" />{job.apply_count || 0} applicants</span>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => toggleStatus.mutate({ id: job.id, status: job.status === 'open' ? 'closed' : 'open' })} title="Open / Close">
                    <Power className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(job)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => confirmDelete(job.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Briefcase className="w-4 h-4" />{editing ? 'Edit Job Posting' : 'New Job Posting'}</DialogTitle></DialogHeader>
          <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-1">
            <div><Label>Title *</Label><Input className="mt-1" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Senior Account Executive" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Department</Label><Input className="mt-1" value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} placeholder="Sales" /></div>
              <div><Label>Location</Label><Input className="mt-1" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="Remote · NYC" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Employment Type</Label>
                <Select value={form.employment_type} onValueChange={v => setForm({ ...form, employment_type: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['full_time', 'part_time', 'contract', 'intern'].map(t => <SelectItem key={t} value={t} className="capitalize">{t.replace('_', ' ')}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{['open', 'draft', 'closed'].map(s => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Pay Min ($)</Label><Input className="mt-1" type="number" value={form.pay_min} onChange={e => setForm({ ...form, pay_min: e.target.value })} placeholder="50000" /></div>
              <div><Label>Pay Max ($)</Label><Input className="mt-1" type="number" value={form.pay_max} onChange={e => setForm({ ...form, pay_max: e.target.value })} placeholder="80000" /></div>
            </div>
            <div><Label>Description</Label><Textarea className="mt-1" rows={4} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Role overview, responsibilities, what the day-to-day looks like..." /></div>
            <div><Label>Requirements</Label><Textarea className="mt-1" rows={3} value={form.requirements} onChange={e => setForm({ ...form, requirements: e.target.value })} placeholder="Required skills, experience, qualifications..." /></div>
            <Button className="w-full" disabled={!form.title || save.isPending} onClick={() => save.mutate(form)}>
              {save.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}{editing ? 'Save Changes' : 'Post Job'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Job Posting</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the posting from your public careers page. All associated applicant data will be preserved, but the job will no longer be visible to candidates.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}