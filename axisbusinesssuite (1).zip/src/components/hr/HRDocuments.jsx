import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, FileText, Upload, ExternalLink, Loader2, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const DOC_TYPE_COLORS = {
  offer_letter: 'bg-blue-500/10 text-blue-700',
  contract: 'bg-purple-500/10 text-purple-700',
  w9: 'bg-amber-500/10 text-amber-700',
  i9: 'bg-amber-500/10 text-amber-700',
  nda: 'bg-red-500/10 text-red-700',
  performance_pip: 'bg-orange-500/10 text-orange-700',
  warning: 'bg-red-500/10 text-red-700',
  policy_acknowledgment: 'bg-slate-500/10 text-slate-600',
  other: 'bg-slate-500/10 text-slate-600',
};

const STATUS_COLORS = {
  pending_signature: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  signed: 'bg-emerald-500/10 text-emerald-700 border-emerald-500/20',
  expired: 'bg-red-500/10 text-red-700 border-red-500/20',
  archived: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
};

const emptyForm = { employee_id: '', title: '', doc_type: 'other', status: 'pending_signature', signed_date: '', expiry_date: '', notes: '' };

export default function HRDocuments({ employees }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [uploading, setUploading] = useState(false);
  const [fileInput, setFileInput] = useState(null);
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const { data: docs = [] } = useQuery({
    queryKey: ['hr-docs'],
    queryFn: () => base44.entities.HRDocument.list('-created_date'),
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'HRDocument', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['hr-docs'] }); setDialogOpen(false); toast.success('Document saved'); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.HRDocument.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['hr-docs'] }); toast.success('Document updated'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.HRDocument.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['hr-docs'] }); toast.success('Document deleted'); },
  });

  const confirmDeleteDoc = (id) => {
    if (window.confirm('Delete this document? This cannot be undone.')) {
      deleteMut.mutate(id);
    }
  };

  const handleUpload = async (file) => {
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(p => ({ ...p, file_url }));
    setUploading(false);
    toast.success('File uploaded');
  };

  const handleSave = () => {
    const emp = employees.find(e => e.id === form.employee_id);
    createMut.mutate({ ...form, employee_name: emp ? `${emp.first_name} ${emp.last_name}` : '', owner: user?.email });
  };

  const pending = docs.filter(d => d.status === 'pending_signature').length;

  return (
    <div className="space-y-4">
      {pending > 0 && (
        <div className="flex items-center gap-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-sm text-amber-700">
          <FileText className="w-4 h-4 shrink-0" />
          <span><strong>{pending} document{pending > 1 ? 's' : ''}</strong> pending signature</span>
        </div>
      )}

      <div className="flex justify-between items-center">
        <h3 className="font-semibold">HR Documents</h3>
        <Button size="sm" onClick={() => { setForm(emptyForm); setDialogOpen(true); }}><Plus className="w-3.5 h-3.5 mr-1.5" />Add Document</Button>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Employee</TableHead>
              <TableHead>Document</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Signed</TableHead>
              <TableHead>Expiry</TableHead>
              <TableHead className="w-24">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {docs.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="text-center py-10 text-muted-foreground">No documents yet</TableCell></TableRow>
            ) : docs.map(doc => (
              <TableRow key={doc.id} className="hover:bg-muted/30">
                <TableCell className="font-medium text-sm">{doc.employee_name || '—'}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    <span className="text-sm">{doc.title}</span>
                  </div>
                </TableCell>
                <TableCell><Badge variant="outline" className={`text-[10px] ${DOC_TYPE_COLORS[doc.doc_type] || ''}`}>{doc.doc_type?.replace(/_/g,' ')}</Badge></TableCell>
                <TableCell><Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[doc.status] || ''}`}>{doc.status?.replace(/_/g,' ')}</Badge></TableCell>
                <TableCell className="text-xs text-muted-foreground">{doc.signed_date ? format(new Date(doc.signed_date), 'MMM d, yyyy') : '—'}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{doc.expiry_date ? format(new Date(doc.expiry_date), 'MMM d, yyyy') : '—'}</TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    {doc.file_url && (
                      <Button variant="ghost" size="icon" className="h-7 w-7" asChild>
                        <a href={doc.file_url} target="_blank" rel="noopener noreferrer"><ExternalLink className="w-3.5 h-3.5" /></a>
                      </Button>
                    )}
                    {doc.status === 'pending_signature' && (
                      <Button size="sm" variant="outline" className="h-7 text-[11px] text-emerald-600" onClick={() => updateMut.mutate({ id: doc.id, data: { status: 'signed', signed_date: new Date().toISOString().split('T')[0] } })}>Sign</Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => confirmDeleteDoc(doc.id)}>
                      <Trash2 className="w-3.5 h-3.5 text-destructive" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Add HR Document</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Employee</Label>
              <Select value={form.employee_id} onValueChange={v => f('employee_id', v)}>
                <SelectTrigger><SelectValue placeholder="Select employee..." /></SelectTrigger>
                <SelectContent>{employees.map(e => <SelectItem key={e.id} value={e.id}>{e.first_name} {e.last_name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Document Title *</Label><Input value={form.title} onChange={e => f('title', e.target.value)} /></div>
            <div>
              <Label>Document Type</Label>
              <Select value={form.doc_type} onValueChange={v => f('doc_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.keys(DOC_TYPE_COLORS).map(t => <SelectItem key={t} value={t}>{t.replace(/_/g,' ').replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => f('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.keys(STATUS_COLORS).map(s => <SelectItem key={s} value={s}>{s.replace(/_/g,' ').replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Signed Date</Label><Input type="date" value={form.signed_date} onChange={e => f('signed_date', e.target.value)} /></div>
              <div><Label>Expiry Date</Label><Input type="date" value={form.expiry_date} onChange={e => f('expiry_date', e.target.value)} /></div>
            </div>
            <div>
              <Label>Upload File (optional)</Label>
              <div className="mt-1">
                <input type="file" className="hidden" ref={r => setFileInput(r)} onChange={e => handleUpload(e.target.files?.[0])} />
                <Button variant="outline" className="w-full gap-2" onClick={() => fileInput?.click()} disabled={uploading}>
                  {uploading ? <><Loader2 className="w-4 h-4 animate-spin" />Uploading...</> : <><Upload className="w-4 h-4" />{form.file_url ? 'Replace File' : 'Upload Document'}</>}
                </Button>
                {form.file_url && <p className="text-xs text-emerald-600 mt-1">✓ File uploaded</p>}
              </div>
            </div>
            <div><Label>Notes</Label><Textarea value={form.notes} onChange={e => f('notes', e.target.value)} rows={2} /></div>
            <Button className="w-full" onClick={handleSave} disabled={!form.employee_id || !form.title}>Save Document</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}