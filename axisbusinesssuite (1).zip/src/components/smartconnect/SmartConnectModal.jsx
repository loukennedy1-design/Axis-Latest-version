import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import {
  ArrowLeft, Loader2, CheckCircle2, X, ShieldCheck, ExternalLink, Mail, Zap,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import {
  EMAIL_PROVIDERS_GRID, INTEGRATION_PROVIDERS_GRID, ProviderIcon, getProviderById,
} from './smartConnectProviders.jsx';
import SmtpConnectStep from './SmtpConnectStep';

function ProviderTile({ provider, onClick }) {
  return (
    <button
      onClick={onClick}
      className="group relative flex flex-col items-start gap-2 p-3.5 rounded-xl border border-border bg-card hover:border-primary/40 hover:bg-accent/30 transition-all text-left"
    >
      <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
        style={{ background: `${provider.brand}1a`, color: provider.brand }}>
        <ProviderIcon id={provider.iconId} className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-sm font-semibold leading-tight">{provider.name}</p>
        <p className="text-[11px] text-muted-foreground mt-0.5 leading-snug line-clamp-2">{provider.tagline}</p>
      </div>
    </button>
  );
}

function SuccessState({ identity, provider, onDone }) {
  return (
    <div className="flex flex-col items-center text-center py-6 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mb-4">
        <CheckCircle2 className="w-9 h-9 text-emerald-400" />
      </div>
      <p className="text-base font-semibold text-emerald-400">Connected</p>
      <p className="text-sm text-muted-foreground mt-1 max-w-xs">
        {provider.name} is linked to <span className="text-foreground font-medium break-all">{identity}</span>
      </p>
      <Button className="mt-5 gap-1.5" onClick={onDone}>
        Done
      </Button>
    </div>
  );
}

function OAuthStep({ provider, onBack, onConnected }) {
  const [starting, setStarting] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const qc = useQueryClient();

  const finishOAuth = useCallback(async () => {
    let identity = '';
    try {
      if (provider.connectorId) {
        // Per-user connector: confirm connection via the provider's status function.
        qc.invalidateQueries({ queryKey: provider.refresh === 'email-accounts' ? ['user-email-accounts'] : ['oauth-connections'] });
        qc.invalidateQueries({ queryKey: ['integration-health'] });
        if (provider.statusFn) {
          await new Promise(r => setTimeout(r, 400));
          const res = await base44.functions.invoke(provider.statusFn, provider.statusArgs || {});
          if (provider.identityKey === 'email') identity = res?.data?.email || '';
          else identity = res?.data?.connected ? provider.name : '';
        } else {
          // No status function — assume the popup consent completed.
          identity = provider.name;
        }
      } else if (provider.refresh === 'email-accounts') {
        qc.invalidateQueries({ queryKey: ['user-email-accounts'] });
        // give the invalidate a tick, then read the gmail_oauth account
        await new Promise(r => setTimeout(r, 400));
        const res = await base44.functions.invoke('manageEmailAccounts', { action: 'list' });
        const acct = (res?.data?.accounts || []).find(a => a.provider === 'gmail_oauth');
        identity = acct?.email_address || '';
      } else {
        qc.invalidateQueries({ queryKey: ['oauth-connections'] });
        const res = await base44.functions.invoke('getOAuthConnections', {});
        const conn = (res?.data?.connections || []).find(c => c.provider === provider.oauthProvider && c.is_active);
        identity = conn?.identity_email || conn?.identity_name || '';
      }
    } catch { /* identity fetch is best-effort */ }
    setWaiting(false);
    onConnected?.(identity || 'your account');
  }, [provider, qc, onConnected]);

  const handleSignIn = async () => {
    setStarting(true);
    try {
      let url;
      if (provider.connectorId) {
        url = await base44.connectors.connectAppUser(provider.connectorId);
      } else {
        const res = await base44.functions.invoke(provider.authFn, provider.authArgs || {});
        url = res?.data?.authorization_url || res?.data?.auth_url || res?.data?.url;
        if (!url) {
          const setup = res?.data?.setup_required;
          toast.error(setup ? res.data.message || 'OAuth not configured — contact your admin.' : 'Could not start sign-in. Please try again.');
          setStarting(false);
          return;
        }
      }
      if (!url) {
        toast.error('Could not start sign-in. Please try again.');
        setStarting(false);
        return;
      }
      const popup = window.open(url, 'smartconnect_oauth', 'width=560,height=760,noopener,noreferrer');
      setStarting(false);
      setWaiting(true);
      const timer = setInterval(() => {
        if (!popup || popup.closed) {
          clearInterval(timer);
          finishOAuth();
        }
      }, 500);
    } catch (e) {
      toast.error('Sign-in failed: ' + (e.message || 'Unknown error'));
      setStarting(false);
    }
  };

  return (
    <div className="space-y-5">
      <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground -ml-1">
        <ArrowLeft className="w-3.5 h-3.5" /> Back to providers
      </button>

      <div className="flex flex-col items-center text-center pt-2">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
          style={{ background: `${provider.brand}1a`, color: provider.brand }}>
          <ProviderIcon id={provider.iconId} className="w-7 h-7" />
        </div>
        <p className="text-base font-semibold">{provider.name}</p>
        <p className="text-xs text-muted-foreground mt-1 max-w-xs">{provider.tagline}</p>
      </div>

      <div className="flex items-start gap-2 bg-muted/40 border border-border rounded-lg p-3">
        <ShieldCheck className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">
          You'll sign in on {provider.name}'s own secure page. AXIS never sees your password.
        </p>
      </div>

      <Button
        className="w-full gap-2 h-11 text-white"
        style={{ background: provider.brand }}
        onClick={handleSignIn}
        disabled={starting || waiting}
      >
        {starting || waiting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ExternalLink className="w-4 h-4" />}
        {waiting ? 'Waiting for sign-in…' : `Sign in with ${provider.name}`}
      </Button>
      <p className="text-[10px] text-center text-muted-foreground">
        A popup will open — complete sign-in there, then return here.
      </p>
    </div>
  );
}

// Gmail simple connect — no OAuth popup, no password.
// Saves a gmail_oauth account; outgoing mail routes through the platform's
// verified shared Gmail connector (no "unverified app" warning).
function GmailSimpleStep({ provider, onBack, onConnected }) {
  const { saveAccount, isSaving } = useEmailAccounts();
  const [emailAddress, setEmailAddress] = useState('');
  const [displayName, setDisplayName] = useState('');

  const handleSave = async () => {
    if (!emailAddress?.trim()) {
      toast.error('Your Gmail address is required');
      return;
    }
    const domain = emailAddress.split('@')[1]?.toLowerCase().trim();
    if (domain && domain !== 'gmail.com' && domain !== 'googlemail.com') {
      toast.error('Please enter a @gmail.com address');
      return;
    }
    try {
      await saveAccount({
        data: {
          provider: 'gmail_oauth',
          email_address: emailAddress.trim(),
          display_name: displayName.trim(),
          label: 'Gmail',
        },
      });
      toast.success('Gmail connected — ready to send');
      onConnected?.(emailAddress.trim());
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
  };

  return (
    <div className="space-y-5">
      <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground -ml-1">
        <ArrowLeft className="w-3.5 h-3.5" /> Back to providers
      </button>

      <div className="flex flex-col items-center text-center pt-2">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
          style={{ background: `${provider.brand}1a`, color: provider.brand }}>
          <ProviderIcon id={provider.iconId} className="w-7 h-7" />
        </div>
        <p className="text-base font-semibold">{provider.name}</p>
        <p className="text-xs text-muted-foreground mt-1 max-w-xs">
          Enter your Gmail address — AXIS sends through its own verified connection. No password, no popup.
        </p>
      </div>

      <div className="flex items-start gap-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">
          <strong className="text-foreground">No OAuth popup, no App Password.</strong> Replies go straight to your inbox via Reply-To.
        </p>
      </div>

      <div className="space-y-3">
        <div>
          <Label className="text-xs mb-1.5 block">Your Gmail Address *</Label>
          <div className="relative">
            <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              type="email"
              placeholder="you@gmail.com"
              value={emailAddress}
              onChange={e => setEmailAddress(e.target.value)}
              className="h-9 text-sm pl-8"
              autoComplete="email"
            />
          </div>
        </div>
        <div>
          <Label className="text-xs mb-1.5 block">Display Name (From)</Label>
          <Input
            placeholder="John Smith"
            value={displayName}
            onChange={e => setDisplayName(e.target.value)}
            className="h-9 text-sm"
          />
        </div>
      </div>

      <Button
        className="w-full gap-2 h-11 text-white"
        style={{ background: provider.brand }}
        onClick={handleSave}
        disabled={isSaving}
      >
        {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        Connect Gmail
      </Button>
    </div>
  );
}

export default function SmartConnectModal({
  open, onOpenChange, mode = 'email', integrationId, onConnected,
}) {
  const [step, setStep] = useState('grid'); // 'grid' | 'oauth' | 'smtp' | 'gmail_simple' | 'success'
  const [selected, setSelected] = useState(null);
  const [identity, setIdentity] = useState('');

  useEffect(() => {
    if (!open) return;
    setIdentity('');
    setStep('grid');
    setSelected(null);
    // If an integration id was passed and it's an oauth integration, jump straight in
    if (integrationId) {
      const p = getProviderById(mode, integrationId);
      if (p) {
        setSelected(p);
        setStep(p.type === 'oauth' ? 'oauth' : p.type === 'gmail_simple' ? 'gmail_simple' : 'smtp');
      }
    }
  }, [open, mode, integrationId]);

  const grid = mode === 'integration' ? INTEGRATION_PROVIDERS_GRID : EMAIL_PROVIDERS_GRID;
  const sectionLabel = mode === 'integration' ? 'Tools & Integrations' : 'Email Accounts';

  const handleConnected = (id) => {
    setIdentity(id);
    setStep('success');
    onConnected?.();
  };

  const handleDone = () => {
    onOpenChange?.(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[480px] max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">
              {mode === 'integration' ? 'Connect a Tool' : 'Add Email Account'}
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {mode === 'integration'
                ? 'Sign in once — AXIS handles the rest.'
                : 'Pick your provider — we set up the rest automatically.'}
            </p>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onOpenChange?.(false)}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {step === 'grid' && (
          <div className="space-y-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{sectionLabel}</p>
            <div className="grid grid-cols-2 gap-2.5">
              {grid.map(p => (
                <ProviderTile key={p.id} provider={p} onClick={() => {
                  setSelected(p);
                  setStep(p.type === 'oauth' ? 'oauth' : p.type === 'gmail_simple' ? 'gmail_simple' : 'smtp');
                }} />
              ))}
            </div>
          </div>
        )}

        {step === 'oauth' && selected && (
          <OAuthStep
            provider={selected}
            onBack={() => { setStep('grid'); setSelected(null); }}
            onConnected={handleConnected}
          />
        )}

        {step === 'smtp' && selected && (
          <SmtpConnectStep
            provider={selected}
            onBack={() => { setStep('grid'); setSelected(null); }}
            onConnected={handleConnected}
          />
        )}

        {step === 'gmail_simple' && selected && (
          <GmailSimpleStep
            provider={selected}
            onBack={() => { setStep('grid'); setSelected(null); }}
            onConnected={handleConnected}
          />
        )}

        {step === 'success' && selected && (
          <SuccessState identity={identity} provider={selected} onDone={handleDone} />
        )}
      </DialogContent>
    </Dialog>
  );
}