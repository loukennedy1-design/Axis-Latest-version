import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Loader2, CheckCircle2, XCircle, Mail, Eye, EyeOff, Shield,
  ChevronDown, ChevronUp, ArrowLeft, Zap, AlertTriangle, Inbox, Send,
} from 'lucide-react';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { base44 } from '@/api/base44Client';
import { EMAIL_PROVIDERS } from '@/components/email/emailProviders';
import { mapSmtpError } from '@/lib/smtpErrorMapper';
import { toast } from 'sonner';

const KNOWN_DOMAIN_MAP = {
  'yahoo.com': 'yahoo', 'yahoo.co.uk': 'yahoo', 'yahoo.ca': 'yahoo', 'yahoo.fr': 'yahoo', 'yahoo.de': 'yahoo',
  'icloud.com': 'icloud', 'me.com': 'icloud', 'mac.com': 'icloud',
  'aol.com': 'aol', 'zoho.com': 'zoho',
  'protonmail.com': 'protonmail', 'proton.me': 'protonmail',
  'fastmail.com': 'fastmail', 'gmx.com': 'gmx', 'gmx.us': 'gmx',
  'mail.com': 'mail_com', 'yandex.com': 'yandex', 'yandex.ru': 'yandex',
  'secureserver.net': 'godaddy', 'privateemail.com': 'namecheap',
  'emailsrvr.com': 'rackspace', 'mxroute.com': 'mxroute', 'awsapps.com': 'amazon_workmail',
};

function detectKnownProvider(email) {
  const domain = email.split('@')[1]?.toLowerCase().trim();
  return domain ? (KNOWN_DOMAIN_MAP[domain] || null) : null;
}

export default function SmtpConnectStep({ provider, onConnected, onBack }) {
  const { saveAccount, isSaving } = useEmailAccounts();
  const preset = EMAIL_PROVIDERS[provider.providerKey] || EMAIL_PROVIDERS.custom;

  const [form, setForm] = useState(() => {
    const p = preset;
    return {
      email_address: '', email_password: '', display_name: '', label: '',
      protocol: 'imap',
      incoming_host: p.imap.host, incoming_port: p.imap.port, incoming_ssl: p.imap.ssl,
      outgoing_host: p.smtp.host, outgoing_port: p.smtp.port, outgoing_ssl: p.smtp.ssl,
    };
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [autoDiscovering, setAutoDiscovering] = useState(false);
  const [discoveryNote, setDiscoveryNote] = useState('');
  const [discovered, setDiscovered] = useState(false);
  const detectRef = useRef(null);

  const [testing, setTesting] = useState(false);
  const [testMessage, setTestMessage] = useState('');
  const [testFix, setTestFix] = useState('');
  const [hasError, setHasError] = useState(false);

  const applyPreset = (key) => {
    const p = EMAIL_PROVIDERS[key] || EMAIL_PROVIDERS.custom;
    setForm(f => ({
      ...f,
      incoming_host: f.protocol === 'pop3' ? p.pop3.host : p.imap.host,
      incoming_port: f.protocol === 'pop3' ? p.pop3.port : p.imap.port,
      incoming_ssl: f.protocol === 'pop3' ? p.pop3.ssl : p.imap.ssl,
      outgoing_host: p.smtp.host, outgoing_port: p.smtp.port, outgoing_ssl: p.smtp.ssl,
    }));
  };

  const autoDiscover = async (email) => {
    setAutoDiscovering(true);
    setDiscoveryNote('');
    try {
      const res = await base44.functions.invoke('autoDiscoverMailSettings', { email_address: email });
      const data = res?.data || {};
      if (data.warning) {
        setDiscoveryNote(data.warning);
        setShowAdvanced(true);
        setDiscovered(false);
        return;
      }
      if (data.success && data.provider && data.provider !== 'custom' && !data.auto_settings) {
        if (EMAIL_PROVIDERS[data.provider]) {
          applyPreset(data.provider);
          setDiscovered(true);
          setDiscoveryNote(`Detected: ${EMAIL_PROVIDERS[data.provider].label}`);
          return;
        }
      }
      if (data.success && data.auto_settings) {
        const s = data.auto_settings;
        setForm(f => ({
          ...f, protocol: s.protocol,
          incoming_host: s.incoming_host, incoming_port: s.incoming_port, incoming_ssl: s.incoming_ssl,
          outgoing_host: s.outgoing_host, outgoing_port: s.outgoing_port, outgoing_ssl: s.outgoing_ssl,
        }));
        setDiscovered(true);
        setDiscoveryNote(`Found: ${s.incoming_host || s.outgoing_host}`);
        setShowAdvanced(false);
        return;
      }
      setShowAdvanced(true);
      setDiscovered(false);
      setDiscoveryNote(data.message || 'Could not auto-detect — enter server details manually.');
    } catch {
      setShowAdvanced(true);
      setDiscovered(false);
      setDiscoveryNote('Auto-detect failed — enter server details manually.');
    } finally {
      setAutoDiscovering(false);
    }
  };

  const handleEmailChange = (email) => {
    setForm(f => ({ ...f, email_address: email }));
    setDiscovered(false);
    setDiscoveryNote('');
    if (provider.providerKey === 'custom' || provider.id === 'other') {
      const known = detectKnownProvider(email);
      if (known && EMAIL_PROVIDERS[known]) {
        applyPreset(known);
        setDiscovered(true);
        setDiscoveryNote(`Detected: ${EMAIL_PROVIDERS[known].label}`);
        return;
      }
      if (detectRef.current) clearTimeout(detectRef.current);
      if (email.includes('@') && email.split('@')[1]?.includes('.')) {
        detectRef.current = setTimeout(() => autoDiscover(email), 800);
      }
    }
  };

  const canConnect = form.email_address?.trim() && form.email_password?.trim() && form.outgoing_host?.trim();

  const handleConnect = async () => {
    setTesting(true);
    setHasError(false);
    setTestMessage('');
    setTestFix('');
    try {
      const res = await base44.functions.invoke('testSmtpConnection', {
        host: form.outgoing_host.trim(),
        port: Number(form.outgoing_port) || 0,
        ssl: form.outgoing_ssl,
        email_address: form.email_address.trim(),
        password: form.email_password.trim(),
      });
      const data = res?.data || {};
      if (!data.success) {
        const { message, fix } = mapSmtpError(data.error || data.message || 'Connection failed');
        setTestMessage(message);
        setTestFix(fix);
        setHasError(true);
        return;
      }
      const payload = {
        label: form.label?.trim() || '',
        provider: provider.providerKey,
        email_address: form.email_address.trim(),
        display_name: form.display_name?.trim() || '',
        protocol: form.protocol,
        incoming_host: form.incoming_host.trim(),
        incoming_port: Number(form.incoming_port) || 0,
        incoming_ssl: form.incoming_ssl,
        outgoing_host: form.outgoing_host.trim(),
        outgoing_port: Number(form.outgoing_port) || 0,
        outgoing_ssl: form.outgoing_ssl,
        email_password: form.email_password.trim(),
        is_default: true,
        is_unverified: false,
      };
      await saveAccount({ data });
      toast.success('Email account connected');
      onConnected?.(form.email_address.trim());
    } catch (e) {
      const raw = e?.response?.data?.error || e?.data?.error || e.message;
      const { message, fix } = mapSmtpError(raw);
      setTestMessage(message);
      setTestFix(fix);
      setHasError(true);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground -ml-1">
        <ArrowLeft className="w-3.5 h-3.5" /> Back to providers
      </button>

      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: `${provider.brand}1a` }}>
          <Mail className="w-4 h-4" style={{ color: provider.brand }} />
        </div>
        <div>
          <p className="text-sm font-semibold">{provider.name}</p>
          <p className="text-[11px] text-muted-foreground">{preset.note ? 'Email + password — we handle the rest' : provider.tagline}</p>
        </div>
      </div>

      <div>
        <Label className="text-xs mb-1.5 block">Email Address</Label>
        <div className="relative">
          <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            type="email" placeholder="you@example.com" value={form.email_address}
            onChange={e => handleEmailChange(e.target.value)} className="h-9 text-sm pl-8" autoComplete="email"
          />
        </div>
        {autoDiscovering && (
          <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
            <Loader2 className="w-3 h-3 animate-spin" /> Detecting settings…
          </p>
        )}
        {!autoDiscovering && discovered && (
          <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> {discoveryNote}
          </p>
        )}
        {!autoDiscovering && !discovered && discoveryNote && (
          <p className="text-[10px] text-amber-400 mt-1 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> {discoveryNote}
          </p>
        )}
      </div>

      <div>
        <Label className="text-xs mb-1.5 block">Password / App Password</Label>
        <div className="relative">
          <Input
            type={showPassword ? 'text' : 'password'} placeholder="••••••••" value={form.email_password}
            onChange={e => setForm(f => ({ ...f, email_password: e.target.value }))}
            className="h-9 text-sm pr-9" autoComplete="current-password"
          />
          <button type="button" onClick={() => setShowPassword(s => !s)}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {preset.helpUrl && (
        <p className="text-[10px] text-muted-foreground">
          {preset.note}{' '}
          <a href={preset.helpUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">View guide →</a>
        </p>
      )}

      <div className="border border-border rounded-xl overflow-hidden">
        <button onClick={() => setShowAdvanced(s => !s)}
          className="w-full flex items-center justify-between px-3 py-2.5 bg-card hover:bg-accent/40 transition-colors">
          <span className="text-xs font-semibold flex items-center gap-1.5"><Shield className="w-3.5 h-3.5" /> Advanced Server Settings</span>
          {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
        {showAdvanced && (
          <div className="p-3 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => { const p = preset; setForm(f => ({ ...f, protocol: 'imap', incoming_host: p.imap.host, incoming_port: p.imap.port, incoming_ssl: p.imap.ssl })); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${form.protocol === 'imap' ? 'bg-primary/10 border-primary text-primary' : 'bg-card border-border text-muted-foreground'}`}>
                <Inbox className="w-3 h-3 inline mr-1" /> IMAP
              </button>
              <button onClick={() => { const p = preset; setForm(f => ({ ...f, protocol: 'pop3', incoming_host: p.pop3.host, incoming_port: p.pop3.port, incoming_ssl: p.pop3.ssl })); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border ${form.protocol === 'pop3' ? 'bg-primary/10 border-primary text-primary' : 'bg-card border-border text-muted-foreground'}`}>
                POP3
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label className="text-[10px] mb-1 block">Incoming Host</Label>
                <Input value={form.incoming_host} onChange={e => setForm(f => ({ ...f, incoming_host: e.target.value }))} className="h-7 text-xs font-mono" placeholder="imap.example.com" />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">Port</Label>
                <Input type="number" value={form.incoming_port} onChange={e => setForm(f => ({ ...f, incoming_port: e.target.value }))} className="h-7 text-xs font-mono" placeholder="993" />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">SSL</Label>
                <button onClick={() => setForm(f => ({ ...f, incoming_ssl: !f.incoming_ssl }))}
                  className={`w-full h-7 rounded-lg text-xs font-medium border ${form.incoming_ssl ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-muted border-border text-muted-foreground'}`}>
                  {form.incoming_ssl ? 'On' : 'Off'}
                </button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div>
                <Label className="text-[10px] mb-1 block flex items-center gap-1"><Send className="w-2.5 h-2.5" /> SMTP Host</Label>
                <Input value={form.outgoing_host} onChange={e => setForm(f => ({ ...f, outgoing_host: e.target.value }))} className="h-7 text-xs font-mono" placeholder="smtp.example.com" />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">Port</Label>
                <Input type="number" value={form.outgoing_port} onChange={e => setForm(f => ({ ...f, outgoing_port: e.target.value }))} className="h-7 text-xs font-mono" placeholder="587" />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">SSL</Label>
                <button onClick={() => setForm(f => ({ ...f, outgoing_ssl: !f.outgoing_ssl }))}
                  className={`w-full h-7 rounded-lg text-xs font-medium border ${form.outgoing_ssl ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-muted border-border text-muted-foreground'}`}>
                  {form.outgoing_ssl ? 'On' : 'Off'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {hasError && (
        <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3 space-y-1.5">
          <p className="text-xs text-destructive break-words flex items-start gap-1.5">
            <XCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {testMessage}
          </p>
          {testFix && <p className="text-xs text-destructive font-semibold border-t border-destructive/20 pt-2">{testFix}</p>}
        </div>
      )}

      <Button className="w-full gap-1.5 h-10" disabled={!canConnect || testing || isSaving} onClick={handleConnect}>
        {testing || isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        {testing ? 'Verifying…' : isSaving ? 'Saving…' : 'Connect'}
      </Button>
    </div>
  );
}