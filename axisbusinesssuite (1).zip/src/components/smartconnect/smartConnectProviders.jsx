// Provider registry for the Smart Connect modal.
// Two groups: Email Accounts (email mode) and Tools & Integrations (integration mode).
// Each OAuth entry names the backend function that returns an `authorization_url`
// (or `auth_url`) we open in a popup. SMTP entries reference an EMAIL_PROVIDERS key.

import React from 'react';
import {
  Mail, Inbox, Sparkles, Calendar, BookOpen, Cloud, Globe, Slack,
  Table, FileText, Presentation, Video, ListTodo, ClipboardList,
  GraduationCap, Database, BarChart3, Search,
} from 'lucide-react';

// Inline brand glyphs for a polished grid (kept tiny).
export function ProviderIcon({ id, className = 'w-5 h-5' }) {
  switch (id) {
    case 'gmail':
    case 'gmail_tool':
      return (
        <svg className={className} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 11v2.4h3.97c-.16 1.03-1.2 3.02-3.97 3.02A4.7 4.7 0 0 1 7.3 12a4.7 4.7 0 0 1 4.7-4.7c1.36 0 2.27.58 2.79 1.07l1.9-1.83C15.4 5.98 13.9 5.3 12 5.3 8.13 5.3 5 8.43 5 12s3.13 6.7 7 6.7c4.04 0 6.72-2.84 6.72-6.84 0-.46-.05-.81-.11-1.16H12z" />
        </svg>
      );
    case 'outlook':
      return (
        <svg className={className} viewBox="0 0 24 24" fill="currentColor">
          <path d="M3 6.5l7-1.5v14L3 17.5v-11zm9-1.7L21 3.5v17l-9-1.3V4.8zm4.7 5.4l-2.2.1v3.9h2.2c1.1 0 1.9-.8 1.9-2s-.8-2-1.9-2z" />
        </svg>
      );
    case 'google_calendar':
      return <Calendar className={className} />;
    case 'quickbooks':
      return <BookOpen className={className} />;
    case 'gdrive':
      return <Cloud className={className} />;
    case 'slack':
      return <Slack className={className} />;
    case 'googlesheets':
      return <Table className={className} />;
    case 'googledocs':
      return <FileText className={className} />;
    case 'googleslides':
      return <Presentation className={className} />;
    case 'googlemeet':
      return <Video className={className} />;
    case 'googletasks':
      return <ListTodo className={className} />;
    case 'googleforms':
      return <ClipboardList className={className} />;
    case 'google_classroom':
      return <GraduationCap className={className} />;
    case 'googlebigquery':
      return <Database className={className} />;
    case 'google_analytics':
      return <BarChart3 className={className} />;
    case 'google_search_console':
      return <Search className={className} />;
    case 'yahoo':
      return <Sparkles className={className} />;
    case 'icloud':
      return <Cloud className={className} />;
    case 'aol':
      return <Mail className={className} />;
    case 'godaddy':
      return <Globe className={className} />;
    case 'other':
      return <Inbox className={className} />;
    default:
      return <Mail className={className} />;
  }
}

export const EMAIL_PROVIDERS_GRID = [
  {
    id: 'gmail', name: 'Gmail', tagline: 'No password needed — sends through AXIS',
    type: 'gmail_simple', refresh: 'email-accounts', iconId: 'gmail', brand: '#EA4335',
  },
  {
    id: 'outlook', name: 'Outlook / Microsoft 365', tagline: 'One-click Microsoft sign-in',
    type: 'oauth', connectorId: '6a73d10108a55c45803be051',
    statusFn: 'outlookSync', statusArgs: { action: 'status' }, identityKey: 'email',
    refresh: 'email-accounts', iconId: 'outlook', brand: '#0078D4',
  },
  {
    id: 'yahoo', name: 'Yahoo', tagline: 'App password required',
    type: 'smtp', providerKey: 'yahoo', iconId: 'yahoo', brand: '#6001D2',
  },
  {
    id: 'icloud', name: 'iCloud', tagline: 'App-specific password',
    type: 'smtp', providerKey: 'icloud', iconId: 'icloud', brand: '#3693F3',
  },
  {
    id: 'aol', name: 'AOL', tagline: 'App password required',
    type: 'smtp', providerKey: 'aol', iconId: 'aol', brand: '#FF0A28',
  },
  {
    id: 'godaddy', name: 'GoDaddy', tagline: 'Workspace email',
    type: 'smtp', providerKey: 'godaddy', iconId: 'godaddy', brand: '#1B6B3A',
  },
  {
    id: 'other', name: 'Other / Business Email', tagline: 'We auto-detect your server',
    type: 'smtp', providerKey: 'custom', iconId: 'other', brand: '#64748B',
  },
];

export const INTEGRATION_PROVIDERS_GRID = [
  {
    id: 'google_calendar', name: 'Google Calendar', tagline: 'Two-way appointment sync',
    type: 'oauth', connectorId: '6a73d0d83a97ff0f968f60fa',
    statusFn: 'getGoogleCalendarStatus', statusArgs: {}, identityKey: null,
    oauthProvider: 'google_calendar', refresh: 'oauth-connections', iconId: 'google_calendar', brand: '#4285F4',
  },
  {
    id: 'gmail_tool', name: 'Gmail', tagline: 'Send email through AXIS',
    type: 'gmail_simple', refresh: 'email-accounts', iconId: 'gmail', brand: '#EA4335',
  },
  {
    id: 'quickbooks', name: 'QuickBooks', tagline: 'Sync your books',
    type: 'oauth', authFn: 'oauthAuthorize', authArgs: { integration_type: 'quickbooks' },
    oauthProvider: 'quickbooks', refresh: 'oauth-connections', iconId: 'quickbooks', brand: '#2CA01C',
  },
  {
    id: 'gdrive', name: 'Google Drive', tagline: 'File storage & sync',
    type: 'oauth', connectorId: '6a73d6530fdc058ce116e85b',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_drive', refresh: 'oauth-connections', iconId: 'gdrive', brand: '#4285F4',
  },
  {
    id: 'googlesheets', name: 'Google Sheets', tagline: 'Read & write spreadsheets',
    type: 'oauth', connectorId: '6a73d656825f282271db92f1',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_sheets', refresh: 'oauth-connections', iconId: 'googlesheets', brand: '#0F9D58',
  },
  {
    id: 'googledocs', name: 'Google Docs', tagline: 'Create & edit documents',
    type: 'oauth', connectorId: '6a73d6580e8ae78c16657288',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_docs', refresh: 'oauth-connections', iconId: 'googledocs', brand: '#4285F4',
  },
  {
    id: 'googleslides', name: 'Google Slides', tagline: 'Create & edit decks',
    type: 'oauth', connectorId: '6a73d65a08a55c45803be36f',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_slides', refresh: 'oauth-connections', iconId: 'googleslides', brand: '#F4B400',
  },
  {
    id: 'googlemeet', name: 'Google Meet', tagline: 'Create meeting links',
    type: 'oauth', connectorId: '6a73d65e9060af3ed24f2d99',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_meet', refresh: 'oauth-connections', iconId: 'googlemeet', brand: '#00897B',
  },
  {
    id: 'googletasks', name: 'Google Tasks', tagline: 'Manage your tasks',
    type: 'oauth', connectorId: '6a73d6623f2ea7a48c132482',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_tasks', refresh: 'oauth-connections', iconId: 'googletasks', brand: '#4285F4',
  },
  {
    id: 'googleforms', name: 'Google Forms', tagline: 'Read form responses',
    type: 'oauth', connectorId: '6a73d664ff35f3a1431721f7',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_forms', refresh: 'oauth-connections', iconId: 'googleforms', brand: '#7C4DFF',
  },
  {
    id: 'google_classroom', name: 'Google Classroom', tagline: 'Courses & rosters',
    type: 'oauth', connectorId: '6a73d666de9f2b45dc3a4d6e',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_classroom', refresh: 'oauth-connections', iconId: 'google_classroom', brand: '#1A73E8',
  },
  {
    id: 'googlebigquery', name: 'Google BigQuery', tagline: 'Run SQL on your data',
    type: 'oauth', connectorId: '6a73d6687d62807144e588c0',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_bigquery', refresh: 'oauth-connections', iconId: 'googlebigquery', brand: '#4285F4',
  },
  {
    id: 'google_analytics', name: 'Google Analytics', tagline: 'Read analytics data',
    type: 'oauth', connectorId: '6a73d66bf610855247e4bcbb',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_analytics', refresh: 'oauth-connections', iconId: 'google_analytics', brand: '#F9AB00',
  },
  {
    id: 'google_search_console', name: 'Google Search Console', tagline: 'Search performance',
    type: 'oauth', connectorId: '6a73d66e894b96c2472bef3d',
    statusFn: null, identityKey: null,
    oauthProvider: 'google_search_console', refresh: 'oauth-connections', iconId: 'google_search_console', brand: '#4285F4',
  },
  {
    id: 'slack', name: 'Slack', tagline: 'DM & channel alerts as you',
    type: 'oauth', connectorId: '6a73d1262ed6255671619bd1',
    statusFn: null, identityKey: null,
    oauthProvider: 'slack', refresh: 'oauth-connections', iconId: 'slack', brand: '#4A154B',
  },
];

export function getProviderById(mode, id) {
  const grid = mode === 'integration' ? INTEGRATION_PROVIDERS_GRID : EMAIL_PROVIDERS_GRID;
  return grid.find(p => p.id === id);
}