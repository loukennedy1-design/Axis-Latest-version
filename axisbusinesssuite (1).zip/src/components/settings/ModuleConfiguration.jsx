import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Zap, Loader2, Save } from 'lucide-react';

const MODULE_GROUPS = [
  {
    label: '⚡ Command',
    modules: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'agent_tasks', label: 'AI Agent Tasks' },
    ]
  },
  {
    label: '👥 CRM',
    modules: [
      { id: 'crm_leads', label: 'Leads' },
      { id: 'crm_appointments', label: 'Appointments' },
      { id: 'crm_tasks', label: 'Follow-Up Tasks' },
      { id: 'crm_call_logs', label: 'Call Logs' },
    ]
  },
  {
    label: '🎯 Lead Generation',
    modules: [
      { id: 'lead_generator', label: 'Lead Generator' },
      { id: 'import_wizard', label: 'Import Wizard' },
      { id: 'import_csv', label: 'Import CSV' },
    ]
  },
  {
    label: '🤖 AI Dialer',
    modules: [
      { id: 'ai_call_bot', label: 'AI Call Bot' },
      { id: 'ai_call_calendar', label: 'Call Calendar' },
    ]
  },
  {
    label: '📈 Sales',
    modules: [
      { id: 'sales_team', label: 'Sales Team' },
      { id: 'lead_scoring', label: 'Lead Scoring' },
      { id: 'nurture_workflows', label: 'Nurture Workflows' },
      { id: 'lead_routing', label: 'Lead Routing' },
      { id: 'coaching_hub', label: 'Coaching Hub' },
      { id: 'my_team', label: 'My Team' },
    ]
  },
  {
    label: '📣 Marketing',
    modules: [
      { id: 'marketing_social', label: 'Social Media AI' },
      { id: 'marketing_video', label: 'Video Marketing AI' },
      { id: 'marketing_omnichannel', label: 'OmniChannel Hub' },
    ]
  },
  {
    label: '💬 Communications',
    modules: [
      { id: 'comm_email', label: 'Email Client' },
      { id: 'comm_sms', label: 'SMS Inbox' },
      { id: 'comm_chat', label: 'AXIS Chat' },
    ]
  },
  {
    label: '🏢 People Ops',
    modules: [
      { id: 'hr_suite', label: 'HR Suite' },
      { id: 'recruitment', label: 'Recruitment' },
      { id: 'ae_onboarding', label: 'AE Onboarding' },
      { id: 'zoom_scheduler', label: 'Zoom & Calendar' },
    ]
  },
  {
    label: '🛡️ Compliance',
    modules: [
      { id: 'compliance_dnc', label: 'DNC Registry' },
      { id: 'compliance', label: 'Compliance' },
      { id: 'compliance_export', label: 'Compliance Export' },
    ]
  },
  {
    label: '🎓 Learning',
    modules: [
      { id: 'academy', label: 'Academy' },
      { id: 'learning_hub', label: 'Learning Hub' },
    ]
  },
  {
    label: '💰 Finance',
    modules: [
      { id: 'finance_ops', label: 'Financial Ops' },
    ]
  },
  {
    label: '🤖 AI Workforce',
    modules: [
      { id: 'ai_digital_employees', label: 'Digital Employees' },
      { id: 'ai_agentic_crm', label: 'Agentic CRM' },
      { id: 'ai_autonomous_scheduler', label: 'Autonomous Scheduler' },
      { id: 'ai_global_workforce', label: 'Global Workforce' },
      { id: 'ai_document_intelligence', label: 'Document Intelligence' },
      { id: 'ai_llm_engine', label: 'LLM Engine' },
      { id: 'ai_production_validation', label: 'Production Validation' },
    ]
  },
];

const ALWAYS_ENABLED = [
  { id: 'account_subscription', label: 'My Subscription' },
  { id: 'account_settings', label: 'My Settings' },
  { id: 'account_api', label: 'API Center' },
];

export default function ModuleConfiguration({ enabledModules, onToggle, onEnableAll, onResetDefaults, onSave, isSaving }) {
  const isModuleEnabled = (moduleId) => {
    return enabledModules.includes(moduleId) || enabledModules.includes('all');
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Enable/Disable Modules
          </CardTitle>
          <p className="text-xs text-muted-foreground">Select which features appear in your sidebar. Changes take effect immediately.</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={onEnableAll} className="text-xs">
              Enable All
            </Button>
            <Button size="sm" variant="outline" onClick={onResetDefaults} className="text-xs">
              Reset to Defaults
            </Button>
          </div>

          {/* Module Groups */}
          <div className="space-y-4">
            {MODULE_GROUPS.map(group => (
              <div key={group.label}>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">{group.label}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {group.modules.map(module => (
                    <label key={module.id} className="flex items-center gap-2 p-2 border border-border rounded-lg cursor-pointer hover:bg-muted/40">
                      <input
                        type="checkbox"
                        checked={isModuleEnabled(module.id)}
                        onChange={() => onToggle(module.id)}
                        className="w-4 h-4"
                      />
                      <span className="text-sm">{module.label}</span>
                    </label>
                  ))}
                </div>
              </div>
            ))}

            {/* Always Enabled */}
            <div>
              <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">⚙️ Account (Always Enabled)</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 opacity-50">
                {ALWAYS_ENABLED.map(module => (
                  <label key={module.id} className="flex items-center gap-2 p-2 border border-border rounded-lg cursor-not-allowed">
                    <input
                      type="checkbox"
                      checked={true}
                      disabled
                      className="w-4 h-4"
                    />
                    <span className="text-sm">{module.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-end mt-4">
            <Button onClick={onSave} disabled={isSaving} size="sm">
              {isSaving ? (
                <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Saving...</>
              ) : (
                <><Save className="w-3.5 h-3.5 mr-1.5" />Save Module Settings</>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}