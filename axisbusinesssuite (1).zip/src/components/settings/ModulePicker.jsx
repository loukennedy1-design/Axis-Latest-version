import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { CheckCircle2, Star } from 'lucide-react';

// ALL available modules grouped for display
export const ALL_MODULE_GROUPS = [
  {
    label: '⚡ Command',
    items: [
      { id: 'dashboard', label: 'Dashboard' },
      { id: 'agent_tasks', label: 'AI Agent Tasks' },
      { id: 'settings', label: 'Settings' },
    ],
    alwaysOn: true,
  },
  {
    label: '👥 CRM',
    items: [
      { id: 'crm_leads', label: 'Leads' },
      { id: 'crm_appointments', label: 'Appointments' },
      { id: 'crm_tasks', label: 'Follow-Up Tasks' },
      { id: 'crm_call_logs', label: 'Call Logs' },
    ],
  },
  {
    label: '🎯 Lead Generation',
    items: [
      { id: 'lead_generator', label: 'Lead Generator' },
      { id: 'import_wizard', label: 'Import Wizard' },
      { id: 'import_csv', label: 'Import CSV' },
    ],
  },
  {
    label: '🤖 AI Dialer',
    items: [
      { id: 'ai_call_bot', label: 'AI Call Bot' },
      { id: 'ai_call_calendar', label: 'Call Calendar' },
    ],
  },
  {
    label: '📈 Sales',
    items: [
      { id: 'sales_team', label: 'Sales Team' },
      { id: 'lead_scoring', label: 'Lead Scoring' },
      { id: 'nurture_workflows', label: 'Nurture Workflows' },
      { id: 'lead_routing', label: 'Lead Routing' },
      { id: 'coaching_hub', label: 'Coaching Hub' },
      { id: 'my_team', label: 'My Team' },
    ],
  },
  {
    label: '📣 Marketing',
    items: [
      { id: 'marketing_social', label: 'Social Media AI' },
      { id: 'marketing_video', label: 'Video Marketing AI' },
      { id: 'marketing_omnichannel', label: 'OmniChannel Hub' },
    ],
  },
  {
    label: '💬 Communications',
    items: [
      { id: 'comm_email', label: 'Email Client' },
      { id: 'comm_sms', label: 'SMS Inbox' },
      { id: 'comm_chat', label: 'AXIS Chat' },
    ],
  },
  {
    label: '🏢 People Ops',
    items: [
      { id: 'hr_suite', label: 'HR Suite' },
      { id: 'recruitment', label: 'Recruitment' },
      { id: 'ae_onboarding', label: 'AE Onboarding' },
      { id: 'zoom_scheduler', label: 'Zoom & Calendar' },
    ],
  },
  {
    label: '🛡️ Compliance',
    items: [
      { id: 'compliance_dnc', label: 'DNC Registry' },
      { id: 'compliance', label: 'Compliance' },
      { id: 'compliance_export', label: 'Compliance Export' },
    ],
  },
  {
    label: '🎓 Learning',
    items: [
      { id: 'academy', label: 'Academy' },
      { id: 'learning_hub', label: 'Learning Hub' },
    ],
  },
  {
    label: '💰 Finance',
    items: [
      { id: 'finance_ops', label: 'Financial Ops' },
    ],
  },
  {
    label: '🤖 AI Workforce',
    items: [
      { id: 'ai_digital_employees', label: 'Digital Employees' },
      { id: 'ai_agentic_crm', label: 'Agentic CRM' },
      { id: 'ai_autonomous_scheduler', label: 'Autonomous Scheduler' },
      { id: 'ai_global_workforce', label: 'Global Workforce' },
      { id: 'ai_document_intelligence', label: 'Document Intelligence' },
      { id: 'ai_llm_engine', label: 'LLM Engine' },
      { id: 'ai_production_validation', label: 'Production Validation' },
    ],
  },
  {
    label: '⚙️ Account',
    items: [
      { id: 'account_subscription', label: 'My Subscription' },
      { id: 'account_settings', label: 'My Settings' },
      { id: 'account_api', label: 'API Center' },
    ],
    alwaysOn: true,
  },
];

const ALWAYS_ON = new Set(['dashboard', 'settings', 'account_subscription', 'account_settings', 'account_api']);

export default function ModulePicker({ enabledModules, recommendedModules = [], onChange }) {
  const [selected, setSelected] = useState(() => new Set(enabledModules || []));

  const toggle = (id) => {
    if (ALWAYS_ON.has(id)) return;
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      onChange([...next]);
      return next;
    });
  };

  const enableAll = () => {
    const all = new Set(ALL_MODULE_GROUPS.flatMap(g => g.items.map(i => i.id)));
    setSelected(all);
    onChange([...all]);
  };

  const enableRecommended = () => {
    const rec = new Set([...ALWAYS_ON, ...(recommendedModules || [])]);
    setSelected(rec);
    onChange([...rec]);
  };

  return (
    <div className="space-y-4">
      {/* Quick actions */}
      <div className="flex gap-2 flex-wrap">
        <Button size="sm" variant="outline" onClick={enableRecommended} className="gap-1.5 text-xs">
          <Star className="w-3 h-3 text-amber-400" /> Use AI Recommendations
        </Button>
        <Button size="sm" variant="outline" onClick={enableAll} className="gap-1.5 text-xs">
          <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Enable All Modules
        </Button>
        <Badge variant="outline" className="ml-auto self-center text-xs">
          {selected.size} of {ALL_MODULE_GROUPS.reduce((a, g) => a + g.items.length, 0)} enabled
        </Badge>
      </div>

      {/* Module groups */}
      <div className="space-y-4 max-h-[55vh] overflow-y-auto pr-1">
        {ALL_MODULE_GROUPS.map(group => (
          <div key={group.label} className="rounded-xl border border-border bg-card/50 p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-semibold">{group.label}</p>
              {group.alwaysOn && <Badge className="text-[10px] bg-primary/10 text-primary border-primary/20">Always On</Badge>}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {group.items.map(item => {
                const isOn = selected.has(item.id);
                const isLocked = ALWAYS_ON.has(item.id);
                const isRecommended = recommendedModules.includes(item.id);
                return (
                  <div
                    key={item.id}
                    onClick={() => toggle(item.id)}
                    className={`flex items-center justify-between p-2.5 rounded-lg border cursor-pointer transition-all ${
                      isLocked
                        ? 'border-primary/30 bg-primary/5 cursor-not-allowed'
                        : isOn
                          ? 'border-primary/40 bg-primary/8'
                          : 'border-border hover:border-primary/30 hover:bg-muted/40'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{item.label}</span>
                      {isRecommended && !isLocked && (
                        <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      )}
                    </div>
                    <Switch
                      checked={isOn}
                      onCheckedChange={() => toggle(item.id)}
                      disabled={isLocked}
                      className="pointer-events-none"
                    />
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}