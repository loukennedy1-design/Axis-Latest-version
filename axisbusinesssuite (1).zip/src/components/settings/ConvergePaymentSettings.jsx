import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  CreditCard, Save, Loader2, ShieldCheck, Zap, CheckCircle2, XCircle,
  Lock, Building2, User, KeyRound, FlaskConical, Rocket
} from 'lucide-react';

export default function ConvergePaymentSettings({ systemSettings }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    converge_active: false,
    converge_merchant_id: '',
    converge_user_id: '',
    converge_terminal_id: '',
    converge_pin: '',
    converge_environment: 'demo',
  });
  const [showPin, setShowPin] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  // True when a PIN is already stored (loaded masked from the server).
  const [hasExistingPin, setHasExistingPin] = useState(false);

  useEffect(() => {
    if (systemSettings) {
      setForm({
        converge_active: systemSettings.converge_active || false,
        converge_merchant_id: systemSettings.converge_merchant_id || '',
        converge_user_id: systemSettings.converge_user_id || '',
        converge_terminal_id: systemSettings.converge_terminal_id || '',
        converge_pin: systemSettings.converge_pin && systemSettings.converge_pin !== '••••••••'
          ? systemSettings.converge_pin : '',
        converge_environment: systemSettings.converge_environment || 'demo',
      });
      // A masked PIN means one is already saved on the server.
      setHasExistingPin(systemSettings.converge_pin === '••••••••');
    }
  }, [systemSettings]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'save', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success('Converge payment settings saved');
    },
    onError: (e) => toast.error('Save failed: ' + e.message),
  });

  const handleSave = () => {
    if (!form.converge_merchant_id || !form.converge_user_id) {
      toast.error('Enter your Account ID and User ID before saving.');
      return;
    }
    // Only require a PIN on first setup; after that, an empty field keeps the
    // stored PIN (the backend preserves it).
    if (!hasExistingPin && !form.converge_pin) {
      toast.error('Enter your Terminal PIN before saving.');
      return;
    }
    saveMutation.mutate({
      converge_active: form.converge_active,
      converge_merchant_id: form.converge_merchant_id.trim(),
      converge_user_id: form.converge_user_id.trim(),
      converge_terminal_id: form.converge_terminal_id.trim(),
      converge_pin: form.converge_pin.trim(),
      converge_environment: form.converge_environment,
    });
  };

  const handleTest = async () => {
    if (!form.converge_merchant_id || !form.converge_user_id) {
      toast.error('Enter and save your Account ID and User ID first.');
      return;
    }
    if (!hasExistingPin && !form.converge_pin) {
      toast.error('Enter and save your Terminal PIN first.');
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      // Request a $0.01 auth-only session — if Converge returns a session token,
      // the credentials and endpoint are valid.
      const res = await base44.functions.invoke('convergeHostedPayment', {
        action: 'session',
        amount: '0.01',
        transaction_type: 'auth_only',
      });
      const data = res?.data || {};
      if (data.success) {
        setTestResult({ success: true, message: `Connected to Converge (${data.environment}). Session created successfully.` });
        toast.success('Converge connection successful');
      } else {
        setTestResult({ success: false, message: data.error || 'Connection failed' });
        toast.error('Converge connection failed');
      }
    } catch (e) {
      const msg = e?.response?.data?.error || e?.data?.error || e.message;
      setTestResult({ success: false, message: msg });
      toast.error('Converge connection failed');
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-primary" />
          AXIS Subscription Billing — Converge by Elavon
        </CardTitle>
        <CardDescription>
          This is AXIS's merchant account for charging subscriber subscription fees (monthly/yearly plans, setup fees). This is NOT for storefront sales — subscribers use their own payment processor for their own customer transactions. Card data is collected directly by Converge via Hosted Payment Modal — AXIS servers never see it, keeping you PCI-compliant.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* Mode banner */}
        <div className={`flex items-start gap-3 rounded-lg p-3 border text-xs ${
          form.converge_environment === 'production'
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
        }`}>
          {form.converge_environment === 'production'
            ? <Rocket className="w-4 h-4 shrink-0 mt-0.5" />
            : <FlaskConical className="w-4 h-4 shrink-0 mt-0.5" />}
          <div>
            <p className="font-semibold">
              {form.converge_environment === 'production' ? 'Production mode — live charges' : 'Demo mode — no real charges'}
            </p>
            <p className="opacity-90">
              {form.converge_environment === 'production'
                ? 'Real credit cards will be charged. Verify in demo first.'
                : 'Use your Converge demo credentials to test the flow before going live.'}
            </p>
          </div>
        </div>

        {/* Active toggle */}
        <div className="flex items-center justify-between rounded-lg border p-3">
          <div className="space-y-0.5">
            <Label>Active for subscription billing</Label>
            <p className="text-xs text-muted-foreground">When enabled, AXIS charges subscriber subscription fees through this Converge merchant account. Subscribers' own storefront sales use their own separate payment processor.</p>
          </div>
          <Switch
            checked={form.converge_active}
            onCheckedChange={(v) => setForm(f => ({ ...f, converge_active: v }))}
          />
        </div>

        {/* Credentials */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5"><Building2 className="w-3.5 h-3.5" /> Account ID (Merchant ID)</Label>
            <Input
              value={form.converge_merchant_id}
              onChange={(e) => setForm(f => ({ ...f, converge_merchant_id: e.target.value }))}
              placeholder="e.g. 2209910"
            />
          </div>
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5"><User className="w-3.5 h-3.5" /> User ID</Label>
            <Input
              value={form.converge_user_id}
              onChange={(e) => setForm(f => ({ ...f, converge_user_id: e.target.value }))}
              placeholder="e.g. myapiuser"
            />
          </div>
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5"><Building2 className="w-3.5 h-3.5" /> Terminal ID</Label>
            <Input
              value={form.converge_terminal_id}
              onChange={(e) => setForm(f => ({ ...f, converge_terminal_id: e.target.value }))}
              placeholder="e.g. 001 (optional)"
            />
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5"><KeyRound className="w-3.5 h-3.5" /> Terminal PIN</Label>
            <div className="relative">
              <Input
                type={showPin ? 'text' : 'password'}
                value={form.converge_pin}
                onChange={(e) => setForm(f => ({ ...f, converge_pin: e.target.value }))}
                placeholder="••••••••"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1 h-7 px-2"
                onClick={() => setShowPin(v => !v)}
              >
                {showPin ? 'Hide' : 'Show'}
              </Button>
            </div>
            {hasExistingPin && !form.converge_pin && (
              <p className="text-[11px] text-muted-foreground">PIN is saved — leave blank to keep it, or type a new one to update.</p>
            )}
          </div>
          <div className="space-y-2">
            <Label>Environment</Label>
            <Select
              value={form.converge_environment}
              onValueChange={(v) => setForm(f => ({ ...f, converge_environment: v }))}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="demo">Demo (test)</SelectItem>
                <SelectItem value="production">Production (live)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Test result */}
        {testResult && (
          <div className={`flex items-start gap-2 rounded-lg p-3 text-xs border ${
            testResult.success
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-destructive/10 border-destructive/30 text-destructive'
          }`}>
            {testResult.success
              ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              : <XCircle className="w-4 h-4 shrink-0 mt-0.5" />}
            <div className="flex-1">
              <p className="font-semibold mb-0.5">
                {testResult.success ? 'Connection successful' : 'Connection failed'}
              </p>
              <p className="opacity-90 break-words">{testResult.message}</p>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2 pt-1">
          <Button size="sm" className="gap-1.5" onClick={handleSave} disabled={saveMutation.isPending}>
            {saveMutation.isPending
              ? <Loader2 className="w-4 h-4 animate-spin" />
              : <Save className="w-4 h-4" />}
            Save Credentials
          </Button>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={handleTest} disabled={testing}>
            {testing
              ? <Loader2 className="w-4 h-4 animate-spin" />
              : <Zap className="w-4 h-4" />}
            Test Connection
          </Button>
          <p className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
            <Lock className="w-2.5 h-2.5" /> PIN encrypted & stored securely
          </p>
        </div>

        <div className="flex items-start gap-2 text-[11px] text-muted-foreground pt-2 border-t">
          <ShieldCheck className="w-3.5 h-3.5 shrink-0 mt-0.5 text-primary" />
          <p>
            The Hosted Payment Modal keeps customers on your page. Card details are entered
            directly into a Converge-hosted iframe, so your server is never exposed to card
            data and you stay within PCI-DSS SAQ-A scope.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}