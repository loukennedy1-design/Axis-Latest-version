import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, Save, LayoutDashboard } from 'lucide-react';
import { toast } from 'sonner';
import ModulePicker from './ModulePicker';

export default function SidebarCustomizer({ user }) {
  const [enabledModules, setEnabledModules] = useState([]);
  const [recommendedModules, setRecommendedModules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
        const settings = res.data?.settings;
        if (settings?.enabled_modules) {
          const parsed = JSON.parse(settings.enabled_modules || '[]');
          setEnabledModules(Array.isArray(parsed) ? parsed : []);
          setRecommendedModules(Array.isArray(parsed) ? parsed : []);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user?.email]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await base44.functions.invoke('saveUserSettings', {
        action: 'save',
        data: { enabled_modules: JSON.stringify(enabledModules) },
      });
      if (res.data?.error) throw new Error(res.data.error);
      window.dispatchEvent(new CustomEvent('axis-sidebar-updated'));
      toast.success('Sidebar updated! Changes are live.');
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <LayoutDashboard className="w-5 h-5 text-primary" />
          <CardTitle>Customize Sidebar Modules</CardTitle>
        </div>
        <CardDescription>
          Choose which modules appear in your sidebar. ⭐ starred items were AI-recommended for your industry.
          Changes apply instantly for all users.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <ModulePicker
          enabledModules={enabledModules}
          recommendedModules={recommendedModules}
          onChange={setEnabledModules}
        />
        <div className="flex justify-end pt-2">
          <Button onClick={handleSave} disabled={saving} className="gap-2">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Sidebar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}