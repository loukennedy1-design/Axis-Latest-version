import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  CheckCircle2, ChevronDown, ChevronUp, Loader2, Info, X, AlertCircle, Video,
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

const GoogleLogo = ({ className = 'w-4 h-4' }) => (
  <svg className={className} viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.16 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
  </svg>
);

const providerButtonStyle = (provider) => {
  if (provider === 'zoom') {
    return 'bg-[#2D8CFF] hover:bg-[#2D8CFF]/90 text-white';
  }
  // Google
  return 'bg-white hover:bg-gray-50 text-gray-700 border border-gray-300';
};

const providerButtonContent = (provider, name) => {
  if (provider === 'zoom') {
    return <><Video className="w-4 h-4 mr-2" />Connect with Zoom</>;
  }
  return <><GoogleLogo className="w-4 h-4 mr-2" />Connect with Google</>;
};

export default function OAuthIntegrationCard({ integration, connection, settings }) {
  const qc = useQueryClient();
  const [expanded, setExpanded] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [disconnecting, setDisconnecting] = useState(false);
  const [setupError, setSetupError] = useState(null);
  const [popupBlocked, setPopupBlocked] = useState(false);

  const isZoom = integration.provider === 'zoom';
  const isConnected = isZoom
    ? (!!connection?.is_active || !!settings?.zoom_client_id)
    : !!connection?.is_active;

  const accountLabel = connection?.email || connection?.name || (isZoom ? 'Zoom (Server-to-Server)' : integration.name);

  const refetch = () => qc.invalidateQueries({ queryKey: ['oauth-connections'] });

  const handleConnect = async () => {
    setConnecting(true);
    setSetupError(null);
    setPopupBlocked(false);
    try {
      const res = await base44.functions.invoke('oauthAuthorize', {
        integration_type: integration.id,
        scopes: integration.scopes || [],
      });
      const data = res.data || res;

      if (data.setup_required) {
        setSetupError(data.message || 'OAuth not configured — contact your admin.');
        return;
      }

      // Zoom server-to-server: no popup, credentials already validated
      if (data.connected) {
        await refetch();
        toast.success(`${integration.name} connected successfully!`);
        return;
      }

      if (!data.auth_url) {
        setSetupError('Failed to start authorization. Please try again.');
        return;
      }

      const popup = window.open(data.auth_url, 'oauth-popup', 'width=600,height=700');
      if (!popup) {
        setPopupBlocked(true);
        return;
      }

      // Poll for popup close, then refetch connection status
      const timer = setInterval(async () => {
        if (popup.closed) {
          clearInterval(timer);
          await refetch();
          setConnecting(false);
        }
      }, 600);
    } catch (err) {
      toast.error(`Connection failed: ${err?.message}`);
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    setDisconnecting(true);
    try {
      const fn = integration.provider === 'google_calendar' ? 'disconnectGoogleCalendar' : 'disconnectOAuth';
      await base44.functions.invoke(fn, { provider: integration.provider });
      await refetch();
      toast.success(`${integration.name} disconnected.`);
    } catch (err) {
      toast.error(`Disconnect failed: ${err?.message}`);
    } finally {
      setDisconnecting(false);
    }
  };

  return (
    <Card className={`transition-all duration-300 overflow-hidden ${
      isConnected
        ? 'border-emerald-500/40 shadow-emerald-500/10 shadow-md'
        : 'border-border hover:border-border/80'
    }`}>
      <CardContent className="p-0">
        {/* Header Row */}
        <div className="p-4 flex items-center gap-4">
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${integration.bg} ring-1 ring-white/5`}>
            {integration.emoji}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm">{integration.name}</span>
              {isConnected ? (
                <Badge className="bg-emerald-500/15 text-emerald-500 border-emerald-500/25 text-xs gap-1 px-2">
                  <CheckCircle2 className="w-3 h-3" /> Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs text-muted-foreground border-dashed">
                  Not connected
                </Badge>
              )}
            </div>
            {isConnected ? (
              <p className="text-xs text-muted-foreground mt-0.5 leading-snug truncate">
                {accountLabel}
              </p>
            ) : (
              <p className="text-xs text-muted-foreground mt-0.5 leading-snug line-clamp-1">{integration.desc}</p>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {isConnected && (
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-destructive hover:text-destructive hover:bg-destructive/10 h-8 px-2"
                onClick={handleDisconnect}
                disabled={disconnecting}
              >
                {disconnecting
                  ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  : <><X className="w-3.5 h-3.5 mr-1" />Disconnect</>}
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs px-3"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded
                ? <><ChevronUp className="w-3.5 h-3.5 mr-1" />Close</>
                : <><ChevronDown className="w-3.5 h-3.5 mr-1" />{isConnected ? 'Details' : 'Learn more'}</>}
            </Button>
          </div>
        </div>

        {/* Expanded Panel */}
        {expanded && (
          <div className="border-t border-border">
            <div className="px-4 py-3 bg-primary/5 border-b border-primary/10 flex items-start gap-3">
              <Info className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">{integration.whatItDoes}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{integration.benefit}</p>
              </div>
            </div>

            <div className="p-4 space-y-4">
              {/* Setup-required / error notices */}
              {setupError && (
                <div className="flex items-start gap-2 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
                  <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                  <p className="text-xs text-amber-600">{setupError}</p>
                </div>
              )}
              {popupBlocked && (
                <div className="flex items-start gap-2 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
                  <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                  <div>
                    <p className="text-xs text-amber-600 font-semibold">Popup blocked</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Allow popups for this site, then click the button again.</p>
                  </div>
                </div>
              )}

              {/* Connect button (only when not connected) */}
              {!isConnected && (
                <>
                  <Button
                    onClick={handleConnect}
                    disabled={connecting}
                    className={`w-full h-10 font-semibold ${providerButtonStyle(integration.provider)}`}
                  >
                    {connecting
                      ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Connecting...</>
                      : providerButtonContent(integration.provider, integration.name)}
                  </Button>
                  <div className="bg-muted/30 border border-border rounded-lg p-3 text-xs text-muted-foreground">
                    <p className="font-semibold mb-1">🔒 Secure OAuth:</p>
                    <ul className="space-y-1">
                      <li>• One-click sign-in — no API keys to copy or paste</li>
                      <li>• You authorize access in a secure popup; we never see your password</li>
                      <li>• Tokens are stored encrypted and can be revoked any time</li>
                    </ul>
                  </div>
                </>
              )}

              {/* Connected summary */}
              {isConnected && (
                <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <p className="text-xs text-emerald-600">
                    Connected as <span className="font-semibold">{accountLabel}</span>
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}