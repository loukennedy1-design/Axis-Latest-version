import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Phone, CheckCircle2, AlertCircle, Loader2, RefreshCw, Zap, Mic,
  Globe, Settings as SettingsIcon, Clock,
} from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import CallProviderSetup from '@/components/callbot/CallProviderSetup';

const PROVIDERS = [
  { id: 'bland', name: 'Bland.ai', icon: Zap, color: 'text-violet-400' },
  { id: 'vapi', name: 'Vapi.ai', icon: Mic, color: 'text-blue-400' },
  { id: 'signalwire', name: 'SignalWire', icon: Phone, color: 'text-emerald-400' },
  { id: 'twilio', name: 'Twilio', icon: Phone, color: 'text-rose-400' },
  { id: 'browser', name: 'Browser AI Voice', icon: Globe, color: 'text-amber-400' },
];

export default function ProviderHealthDashboard() {
  const { user } = useCurrentUser();
  const [testingProvider, setTestingProvider] = useState(null);
  const qc = useQueryClient();

  const { data: sysSettings = [], isLoading } = useQuery({
    queryKey: ['system-settings', user?.email],
    queryFn: () => {
      if (!user?.email) return [];
      return base44.entities.SystemSettings.filter({ key: `industry_${user.email}`, owner: user.email });
    },
    enabled: !!user?.email,
  });

  const { data: callLogs = [] } = useQuery({
    queryKey: ['provider-call-logs', user?.email],
    queryFn: () => base44.entities.CallLog.list('-created_date', 50),
    enabled: !!user?.email,
  });

  const settings = sysSettings[0];

  const handleTestCall = async (providerId) => {
    setTestingProvider(providerId);
    try {
      const testNumber = settings?.twilio_phone_number || settings?.signalwire_phone_number;
      const res = await base44.functions.invoke('dispatchAICall', {
        action: 'test_call',
        provider: providerId,
        phone_number: testNumber,
      });
      const result = res.data || res;
      if (result.success) {
        toast.success(`📞 Test call placed to ${testNumber}!`);
        qc.invalidateQueries({ queryKey: ['system-settings'] });
      } else {
        toast.error(result.error || 'Test call failed');
      }
    } catch (e) {
      toast.error('Test call failed: ' + e.message);
    } finally {
      setTestingProvider(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <CallProviderSetup />

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <SettingsIcon className="w-4 h-4" />
            Provider Health Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-4">
            Each connected provider shows a live status. Click "Test Call" to place a 15-second test call to your own number.
          </p>
          <div className="space-y-2">
            {PROVIDERS.map((provider) => {
              const Icon = provider.icon;
              const isActive = settings?.provider_type === provider.id || settings?.default_call_service === provider.id;
              const isVerified = settings ? !!settings[`${provider.id}_verified`] : false;
              const hasCredentials = settings ? checkHasCredentials(provider.id, settings) : false;
              const lastCall = getLastCallForProvider(provider.id, callLogs);
              const isTesting = testingProvider === provider.id;

              // Status: green (verified+active), yellow (has creds but not verified), red (no creds)
              const status = !hasCredentials ? 'red' : isVerified ? 'green' : 'yellow';
              const statusColor = status === 'green' ? 'bg-emerald-400' : status === 'yellow' ? 'bg-amber-400' : 'bg-muted-foreground';
              const statusLabel = status === 'green' ? 'Verified' : status === 'yellow' ? 'Needs validation' : 'Not configured';

              return (
                <div
                  key={provider.id}
                  className={cn(
                    'flex items-center justify-between p-3 rounded-lg border transition-colors',
                    isActive ? 'border-primary/30 bg-primary/5' : 'border-border hover:bg-muted/30',
                  )}
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center bg-muted/50', provider.color)}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className={cn('absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-background', statusColor)} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{provider.name}</p>
                        {isActive && (
                          <Badge className="text-[9px] bg-primary/10 text-primary border-primary/20">ACTIVE</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-muted-foreground mt-0.5">
                        <span className="flex items-center gap-1">
                          {status === 'green' ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> :
                           status === 'yellow' ? <AlertCircle className="w-3 h-3 text-amber-400" /> :
                           <AlertCircle className="w-3 h-3 text-muted-foreground" />}
                          {statusLabel}
                        </span>
                        {lastCall && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            Last call: {new Date(lastCall.created_date).toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {hasCredentials && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleTestCall(provider.id)}
                        disabled={isTesting}
                        className="gap-1.5 text-xs h-7"
                      >
                        {isTesting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Phone className="w-3 h-3" />}
                        Test Call
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function checkHasCredentials(providerId, settings) {
  if (providerId === 'browser') return true;
  if (providerId === 'bland') return !!settings.bland_api_key;
  if (providerId === 'vapi') return !!settings.vapi_api_key && !!settings.vapi_assistant_id;
  if (providerId === 'signalwire') return !!settings.signalwire_project_id && !!settings.signalwire_api_token && !!settings.signalwire_space_url;
  if (providerId === 'twilio') return !!settings.twilio_account_sid && !!settings.twilio_auth_token;
  return false;
}

function getLastCallForProvider(providerId, callLogs) {
  const providerName = providerId.charAt(0).toUpperCase() + providerId.slice(1);
  return callLogs.find(c => (c.called_by || '').toLowerCase() === providerName.toLowerCase());
}