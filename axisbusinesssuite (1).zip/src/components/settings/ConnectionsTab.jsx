import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Loader2, CheckCircle2, XCircle, Circle, ExternalLink, Zap, AlertTriangle, Sparkles,
} from 'lucide-react';
import { INTEGRATIONS } from '@/lib/integrations';
import { useIntegrationHealth } from '@/hooks/useIntegrationHealth';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import ConnectionDrawer from '@/components/connections/ConnectionDrawer';
import SmartConnectModal from '@/components/smartconnect/SmartConnectModal';

// Maps an INTEGRATIONS oauth id to the Smart Connect integration grid id.
const SMART_CONNECT_ID_MAP = {
  calendar: 'google_calendar',
  gmail: 'gmail_tool',
  outlook: 'outlook',
  slack: 'slack',
  quickbooks: 'quickbooks',
  gdrive: 'gdrive',
  googlesheets: 'googlesheets',
  googledocs: 'googledocs',
  googleslides: 'googleslides',
  googlemeet: 'googlemeet',
  googletasks: 'googletasks',
  googleforms: 'googleforms',
  google_classroom: 'google_classroom',
  googlebigquery: 'googlebigquery',
  google_analytics: 'google_analytics',
  google_search_console: 'google_search_console',
};
const SMART_CONNECT_MODE = {
  outlook: 'email',
};

const STATUS_META = {
  connected: { color: 'emerald', label: 'Connected', icon: CheckCircle2 },
  failed: { color: 'red', label: 'Needs attention', icon: AlertTriangle },
  unset: { color: 'muted', label: 'Not set up', icon: Circle },
  loading: { color: 'muted', label: 'Checking…', icon: Loader2 },
};

export default function ConnectionsTab({ onLaunchWizard }) {
  const health = useIntegrationHealth();
  const { user } = useCurrentUser();
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const [drawerIntegration, setDrawerIntegration] = useState(null);
  const [smartConnectOpen, setSmartConnectOpen] = useState(false);
  const [smartConnectId, setSmartConnectId] = useState(null);
  const [smartConnectMode, setSmartConnectMode] = useState('integration');

  const ctx = { oauth: health.oauth, twilioConfig: health.twilioConfig, settings: health.settings };

  const getStatus = (integration) => {
    if (health.loading) return 'loading';
    return integration.status?.(ctx) || 'unset';
  };

  const handleOpen = (integration) => {
    if (integration.category === 'oauth' && SMART_CONNECT_ID_MAP[integration.id]) {
      setSmartConnectId(SMART_CONNECT_ID_MAP[integration.id]);
      setSmartConnectMode(SMART_CONNECT_MODE[integration.id] || 'integration');
      setSmartConnectOpen(true);
    } else {
      setDrawerIntegration(integration);
    }
  };
  const handleConnected = () => {
    health.refetchAll();
  };

  const visibleIntegrations = INTEGRATIONS.filter(i => !i.adminOnly || isAdmin);
  const connectedCount = visibleIntegrations.filter(i => getStatus(i) === 'connected').length;
  const needsAttention = visibleIntegrations.filter(i => getStatus(i) === 'failed').length;

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground max-w-2xl">
          Connect your tools so AXIS can call, email, charge, and schedule automatically. Once connected, everything runs in the background — green means active and working.
        </p>
        <Button variant="outline" size="sm" onClick={onLaunchWizard} className="gap-1.5 shrink-0">
          <Sparkles className="w-3.5 h-3.5" /> Run Setup Wizard
        </Button>
      </div>

      {/* Summary strip */}
      <div className="flex items-center gap-3 text-xs">
        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
          <CheckCircle2 className="w-3 h-3 mr-1" /> {connectedCount} connected
        </Badge>
        {needsAttention > 0 && (
          <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30">
            <AlertTriangle className="w-3 h-3 mr-1" /> {needsAttention} need attention
          </Badge>
        )}
        <span className="text-muted-foreground">{visibleIntegrations.length} total</span>
      </div>

      {/* Card grid — 2 cols mobile, 4 desktop */}
      <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
        {visibleIntegrations.map(integration => {
          const status = getStatus(integration);
          const meta = STATUS_META[status];
          const Icon = integration.icon;
          const StatusIcon = meta.icon;
          const cardBorder =
            status === 'connected' ? 'border-emerald-500/30'
            : status === 'failed' ? 'border-amber-500/40'
            : 'border-border';
          return (
            <Card key={integration.id} className={`${cardBorder} transition-colors`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="w-11 h-11 rounded-xl bg-primary/12 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <StatusBadge status={status} />
                </div>
                <p className="text-sm font-semibold mb-1 leading-tight">{integration.name}</p>
                <p className="text-[11px] text-muted-foreground mb-3 leading-snug line-clamp-2">{integration.tagline}</p>
                <Button
                  variant={status === 'connected' ? 'outline' : 'default'}
                  size="sm"
                  onClick={() => handleOpen(integration)}
                  className="w-full gap-1.5"
                >
                  {status === 'failed' ? (
                    <>
                      <Zap className="w-3.5 h-3.5" /> Fix Now
                    </>
                  ) : status === 'connected' ? (
                    'Manage'
                  ) : (
                    <>
                      {integration.category === 'oauth' ? 'Connect' : 'Set up'}
                      <ExternalLink className="w-3 h-3" />
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <ConnectionDrawer
        integration={drawerIntegration}
        settings={health.settings}
        connected={drawerIntegration ? getStatus(drawerIntegration) === 'connected' : false}
        open={!!drawerIntegration}
        onOpenChange={(o) => !o && setDrawerIntegration(null)}
        onConnected={handleConnected}
      />

      <SmartConnectModal
        open={smartConnectOpen}
        onOpenChange={setSmartConnectOpen}
        mode={smartConnectMode}
        integrationId={smartConnectId}
        onConnected={handleConnected}
      />
    </div>
  );
}

function StatusBadge({ status }) {
  const meta = STATUS_META[status];
  const Icon = meta.icon;
  const spin = status === 'loading';
  const classes =
    status === 'connected' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
    : status === 'failed' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
    : 'bg-muted text-muted-foreground border-border';
  return (
    <Badge variant="outline" className={classes}>
      <Icon className={`w-3 h-3 mr-1 ${spin ? 'animate-spin' : ''}`} />
      {meta.label}
    </Badge>
  );
}