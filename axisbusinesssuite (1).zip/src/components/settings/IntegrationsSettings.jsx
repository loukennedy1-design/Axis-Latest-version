import React from 'react';
import AutonomousIntegrations from './AutonomousIntegrations';

export default function IntegrationsSettings() {
  return (
    <div className="space-y-6">
      <AutonomousIntegrations />
    </div>
  );
}