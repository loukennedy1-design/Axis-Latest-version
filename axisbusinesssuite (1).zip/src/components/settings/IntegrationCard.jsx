import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  CheckCircle2, ExternalLink, ChevronDown, ChevronUp,
  Loader2, Save, Eye, EyeOff, Info, Zap, X
} from 'lucide-react';

export default function IntegrationCard({ integration, settings, onSave, isSaving }) {
  const [expanded, setExpanded] = useState(false);
  const [localValues, setLocalValues] = useState({});
  const [showKeys, setShowKeys] = useState({});

  const isConnected = integration.keyField ? !!settings[integration.keyField] : false;
  const getValue = (field) =>
    localValues[field] !== undefined ? localValues[field] : (settings[field] || '');
  const hasChanges = Object.keys(localValues).some(k => localValues[k] !== settings[k]);

  const handleSave = () => {
    onSave(localValues);
    setLocalValues({});
    setExpanded(false);
  };

  const handleDisconnect = () => {
    const cleared = {};
    if (integration.fields) {
      integration.fields.forEach(f => { cleared[f.field] = ''; });
    }
    onSave(cleared);
    setLocalValues({});
  };

  return (
    <Card className={`transition-all duration-300 overflow-hidden ${
      isConnected
        ? 'border-emerald-500/40 shadow-emerald-500/10 shadow-md'
        : 'border-border hover:border-border/80'
    }`}>
      <CardContent className="p-0">
        {/* Header Row */}
        <div className="p-4 flex items-center gap-4">
          {/* Icon */}
          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0 ${integration.bg} ring-1 ring-white/5`}>
            {integration.emoji}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-bold text-sm">{integration.name}</span>
              {isConnected ? (
                <Badge className="bg-emerald-500/15 text-emerald-500 border-emerald-500/25 text-xs gap-1 px-2">
                  <CheckCircle2 className="w-3 h-3" /> Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs text-muted-foreground border-dashed">
                  Not connected
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-0.5 leading-snug line-clamp-1">{integration.desc}</p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2 shrink-0">
            {isConnected && !expanded && (
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-destructive h-8 px-2"
                onClick={handleDisconnect}
              >
                <X className="w-3.5 h-3.5" />
              </Button>
            )}
            <Button
              variant={isConnected ? 'outline' : 'default'}
              size="sm"
              className="h-8 text-xs px-3"
              onClick={() => setExpanded(!expanded)}
            >
              {expanded
                ? <><ChevronUp className="w-3.5 h-3.5 mr-1" /> Close</>
                : isConnected
                  ? <><ChevronDown className="w-3.5 h-3.5 mr-1" /> Edit</>
                  : <><Zap className="w-3.5 h-3.5 mr-1" /> Connect</>
              }
            </Button>
          </div>
        </div>

        {/* Expanded Panel */}
        {expanded && (
          <div className="border-t border-border">
            {/* What it does banner */}
            <div className="px-4 py-3 bg-primary/5 border-b border-primary/10 flex items-start gap-3">
              <Info className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">{integration.whatItDoes}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{integration.benefit}</p>
              </div>
            </div>

            <div className="p-4 space-y-5">
              {/* Steps */}
              <div>
                <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
                  How to get your credentials
                </p>
                <ol className="space-y-3">
                  {integration.steps.map((step, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-muted border border-border text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5 text-muted-foreground">
                        {i + 1}
                      </div>
                      <div className="flex-1 pt-0.5">
                        <p className="text-sm text-foreground/90 leading-snug">{step.text}</p>
                        {step.link && (
                          <a
                            href={step.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 text-xs text-primary font-medium mt-1 hover:underline"
                          >
                            <ExternalLink className="w-3 h-3" />
                            {step.linkLabel || 'Open →'}
                          </a>
                        )}
                      </div>
                    </li>
                  ))}
                </ol>
              </div>

              {/* Credential fields */}
              {integration.fields && (
                <div className="space-y-4 pt-1 border-t border-border">
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground pt-3">
                    Paste your credentials below
                  </p>
                  {integration.fields.map(f => (
                    <div key={f.field} className="space-y-1.5">
                      <Label className="text-sm font-semibold">{f.label}</Label>
                      <p className="text-xs text-muted-foreground">{f.hint}</p>
                      <div className="relative">
                        <Input
                          type={f.secret && !showKeys[f.field] ? 'password' : 'text'}
                          value={getValue(f.field)}
                          onChange={e => setLocalValues(prev => ({ ...prev, [f.field]: e.target.value }))}
                          placeholder={f.placeholder}
                          className="pr-10 font-mono text-sm"
                        />
                        {f.secret && (
                          <button
                            type="button"
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                            onClick={() => setShowKeys(prev => ({ ...prev, [f.field]: !prev[f.field] }))}
                          >
                            {showKeys[f.field] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}

                  <div className="bg-muted/30 border border-border rounded-lg p-3 text-xs text-muted-foreground">
                    <p className="font-semibold mb-1">🔒 Security & Privacy:</p>
                    <ul className="space-y-1">
                      <li>• Your credentials are encrypted at rest and stored securely</li>
                      <li>• Only YOU can access your own credentials (RLS protection)</li>
                      <li>• Credentials are used server-side only — never sent to the browser</li>
                      <li>• Backend functions retrieve credentials securely for API calls</li>
                    </ul>
                  </div>

                  <div className="flex gap-2 pt-1">
                    <Button
                      onClick={handleSave}
                      disabled={isSaving || !hasChanges}
                      className="flex-1"
                    >
                      {isSaving
                        ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
                        : <><CheckCircle2 className="w-4 h-4 mr-2" />Save & Connect {integration.name}</>
                      }
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => { setExpanded(false); setLocalValues({}); }}
                      className="px-4"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}

              {/* OAuth link only (no fields) */}
              {!integration.fields && integration.oauthUrl && (
                <a href={integration.oauthUrl} target="_blank" rel="noopener noreferrer" className="block">
                  <Button className="w-full">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Open {integration.name} to Connect
                  </Button>
                </a>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}