import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart3, TrendingUp, Users, Activity, Phone, Calendar, Shield, AlertTriangle, CheckCircle2, Clock, Zap, Bot } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { format, subDays } from 'date-fns';
import { useCurrentUser } from '@/hooks/useCurrentUser';

function StatCard({ icon: Icon, label, value, sub, color = 'text-primary' }) {
  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
          <Icon className={`w-5 h-5 ${color}`} />
        </div>
        <div>
          <p className="text-2xl font-bold leading-none">{value}</p>
          <p className="text-xs text-muted-foreground mt-1">{label}</p>
          {sub && <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-3))', 'hsl(var(--chart-5))', 'hsl(var(--chart-4))'];

export default function SettingsAnalytics() {
  const { user } = useCurrentUser();

  const { data: leads = [] } = useQuery({
    queryKey: ['analytics-leads', user?.email],
    queryFn: () => base44.entities.Lead.list('-created_date', 500),
    enabled: !!user,
  });

  const { data: callLogs = [] } = useQuery({
    queryKey: ['analytics-calls', user?.email],
    queryFn: () => base44.entities.CallLog.list('-created_date', 300),
    enabled: !!user,
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['analytics-appts', user?.email],
    queryFn: () => base44.entities.Appointment.list('-created_date', 200),
    enabled: !!user,
  });

  const { data: agentTasks = [] } = useQuery({
    queryKey: ['analytics-agent-tasks', user?.email],
    queryFn: () => base44.entities.AgentTask.list('-created_date', 100),
    enabled: !!user,
  });

  const now = new Date();

  // Lead status breakdown
  const statusCounts = leads.reduce((acc, l) => {
    acc[l.status] = (acc[l.status] || 0) + 1;
    return acc;
  }, {});
  const statusData = Object.entries(statusCounts).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));

  // Calls per day (last 7 days)
  const callsByDay = Array.from({ length: 7 }, (_, i) => {
    const day = subDays(now, 6 - i);
    const dayStr = format(day, 'MMM d');
    const count = callLogs.filter(c => format(new Date(c.created_date), 'MMM d') === dayStr).length;
    return { day: dayStr, calls: count };
  });

  // Call outcomes
  const outcomeCounts = callLogs.reduce((acc, c) => {
    const key = c.outcome || c.status || 'other';
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const outcomeData = Object.entries(outcomeCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));

  // Appointment statuses
  const apptStatusCounts = appointments.reduce((acc, a) => {
    acc[a.status] = (acc[a.status] || 0) + 1;
    return acc;
  }, {});
  const apptData = Object.entries(apptStatusCounts).map(([name, value]) => ({ name, value }));

  // Key metrics
  const totalLeads = leads.length;
  const newLeads = leads.filter(l => l.status === 'new').length;
  const apptSet = leads.filter(l => l.status === 'appointment_set').length;
  const totalCalls = callLogs.length;
  const callsToday = callLogs.filter(c => format(new Date(c.created_date), 'yyyy-MM-dd') === format(now, 'yyyy-MM-dd')).length;
  const conversionRate = totalCalls > 0 ? ((apptSet / totalCalls) * 100).toFixed(1) : 0;
  const failedCalls = callLogs.filter(c => c.status === 'failed').length;
  const complianceRate = totalCalls > 0 ? (((totalCalls - failedCalls) / totalCalls) * 100).toFixed(1) : 100;
  const activeAgentTasks = agentTasks.filter(t => t.status === 'active').length;
  const totalTaskRuns = agentTasks.reduce((s, t) => s + (t.run_count || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <BarChart3 className="w-5 h-5 text-primary" />
        <h2 className="text-lg font-semibold">System Analytics</h2>
        <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">Live</Badge>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={Users} label="Total Leads" value={totalLeads} sub={`${newLeads} in queue`} color="text-blue-500" />
        <StatCard icon={Phone} label="Total Calls" value={totalCalls} sub={`${callsToday} today`} color="text-emerald-500" />
        <StatCard icon={Calendar} label="Appointments Set" value={apptSet} sub={`${conversionRate}% conversion`} color="text-primary" />
        <StatCard icon={Shield} label="Compliance Rate" value={`${complianceRate}%`} sub={`${failedCalls} failed calls`} color={complianceRate >= 95 ? 'text-emerald-500' : 'text-red-500'} />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <StatCard icon={Bot} label="AI Agent Tasks" value={activeAgentTasks} sub="active tasks" color="text-purple-500" />
        <StatCard icon={Zap} label="Total Task Runs" value={totalTaskRuns} sub="all-time" color="text-amber-500" />
        <StatCard icon={Activity} label="Calls This Week" value={callsByDay.reduce((s, d) => s + d.calls, 0)} sub="last 7 days" color="text-cyan-500" />
        <StatCard icon={TrendingUp} label="Appt Rate" value={`${conversionRate}%`} sub="calls → booked" color="text-pink-500" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Calls per day */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-500" />Calls — Last 7 Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={callsByDay} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="calls" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Lead Status Breakdown */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-500" />Lead Status Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            {statusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={160}>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                    {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No lead data yet</div>
            )}
          </CardContent>
        </Card>

        {/* Call Outcomes */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-500" />Call Outcomes
            </CardTitle>
          </CardHeader>
          <CardContent>
            {outcomeData.length > 0 ? (
              <ResponsiveContainer width="100%" height={160}>
                <BarChart data={outcomeData} layout="vertical" margin={{ top: 0, right: 10, left: 60, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 10 }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 9 }} width={60} />
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="value" fill="hsl(var(--chart-3))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No call data yet</div>
            )}
          </CardContent>
        </Card>

        {/* Appointment Statuses */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Calendar className="w-4 h-4 text-primary" />Appointment Statuses
            </CardTitle>
          </CardHeader>
          <CardContent>
            {apptData.length > 0 ? (
              <div className="space-y-2 pt-2">
                {apptData.map((item, i) => (
                  <div key={item.name} className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-xs capitalize flex-1">{item.name}</span>
                    <span className="text-xs font-semibold">{item.value}</span>
                    <div className="w-24 bg-muted rounded-full h-1.5">
                      <div className="h-1.5 rounded-full" style={{ width: `${(item.value / appointments.length) * 100}%`, background: COLORS[i % COLORS.length] }} />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-40 flex items-center justify-center text-muted-foreground text-sm">No appointment data yet</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* System Health Summary */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />System Health Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            {[
              { label: 'Leads with Consent', value: leads.filter(l => l.consent_given).length, total: totalLeads, good: true },
              { label: 'Calls Completed', value: callLogs.filter(c => c.status === 'completed').length, total: totalCalls, good: true },
              { label: 'DNC-safe Leads', value: leads.filter(l => l.status !== 'do_not_call').length, total: totalLeads, good: true },
              { label: 'Booked Appointments', value: appointments.filter(a => a.status === 'scheduled' || a.status === 'confirmed').length, total: appointments.length, good: true },
            ].map(item => {
              const pct = item.total > 0 ? Math.round((item.value / item.total) * 100) : 0;
              return (
                <div key={item.label} className="p-3 rounded-lg border border-border bg-muted/30">
                  <p className="text-xs text-muted-foreground">{item.label}</p>
                  <p className="text-lg font-bold mt-0.5">{item.value}<span className="text-xs text-muted-foreground font-normal ml-1">/ {item.total}</span></p>
                  <div className="w-full bg-muted rounded-full h-1.5 mt-1.5">
                    <div className="h-1.5 rounded-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-1">{pct}%</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}