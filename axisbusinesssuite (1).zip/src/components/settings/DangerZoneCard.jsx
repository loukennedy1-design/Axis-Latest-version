import React, { useState } from 'react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function DangerZoneCard({ user }) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [emailInput, setEmailInput] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleOpen = () => {
    setStep(1);
    setEmailInput('');
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setStep(1);
    setEmailInput('');
  };

  const handleConfirm = async () => {
    setSubmitting(true);
    try {
      await base44.functions.invoke('reactivateUserAccount', {
        action: 'deactivate',
        user_email: user.email,
      });
      toast.success('Account closure request received. Redirecting...');
      handleClose();
      setTimeout(() => {
        window.location.href = '/';
      }, 3000);
    } catch (e) {
      const detail = e?.response?.data?.error || e?.data?.error || e.message;
      toast.error('Failed to submit closure request: ' + detail);
    }
    setSubmitting(false);
  };

  const emailMatches = emailInput.trim().toLowerCase() === user?.email?.trim().toLowerCase();

  return (
    <>
      <Card className="border-destructive/30 bg-destructive/5">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-4 h-4" /> Danger Zone
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <p className="text-sm text-muted-foreground">
            Permanently close your account. All leads, call logs, appointments, invoices,
            and settings will be scheduled for deletion after a 30-day grace period.
            This action cannot be undone once the grace period expires.
          </p>
          <Button
            variant="outline"
            className="no-select gap-2 text-destructive border-destructive/30 hover:bg-destructive/10"
            onClick={handleOpen}
          >
            <AlertTriangle className="w-4 h-4" /> Request Account Closure
          </Button>
        </CardContent>
      </Card>

      <AlertDialog open={open} onOpenChange={(v) => !v && handleClose()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              {step === 1 ? 'Account Closure Request' : 'Confirm Your Email'}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-3">
                {step === 1 ? (
                  <>
                    <p>
                      You are about to request permanent closure of your account
                      <strong className="text-foreground"> ({user?.email})</strong>.
                    </p>
                    <p>
                      The following data will be <strong className="text-destructive">permanently deleted</strong> after a
                      30-day grace period:
                    </p>
                    <ul className="list-disc list-inside text-xs space-y-1 ml-2">
                      <li>All leads and contact data</li>
                      <li>Call logs and recordings</li>
                      <li>Appointments and calendar entries</li>
                      <li>Invoices and financial records</li>
                      <li>Account settings and preferences</li>
                    </ul>
                    <p className="text-destructive font-medium">
                      ⚠️ This action cannot be undone once the 30-day grace period expires.
                    </p>
                    <p className="text-xs">
                      You will be signed out immediately. An administrator will be notified of this request.
                    </p>
                  </>
                ) : (
                  <>
                    <p>
                      To confirm, type your email address exactly as shown below:
                    </p>
                    <p className="font-mono text-sm bg-muted/40 rounded px-3 py-2 border border-border">
                      {user?.email}
                    </p>
                    <div>
                      <Label>Confirm Email</Label>
                      <Input
                        autoFocus
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        placeholder="Type your email to confirm"
                        className="mt-1"
                      />
                    </div>
                  </>
                )}
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            {step === 1 ? (
              <>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={() => setStep(2)}>
                  Continue
                </AlertDialogAction>
              </>
            ) : (
              <>
                <AlertDialogCancel onClick={() => setStep(1)}>Back</AlertDialogCancel>
                <AlertDialogAction
                  onClick={handleConfirm}
                  disabled={!emailMatches || submitting}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {submitting ? (
                    <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" />Submitting...</>
                  ) : (
                    'Confirm Closure'
                  )}
                </AlertDialogAction>
              </>
            )}
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}