import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Zap, CheckCircle2, Loader2, ExternalLink, AlertCircle,
  ArrowRight, Shield, Key, Globe, Calendar, Mail, MessageSquare,
  Users, BarChart3, FileText, Play, Sparkles, Bot, Video, Clock
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

const INTEGRATIONS = [
  {
    id: 'googlecalendar',
    name: 'Google Calendar',
    desc: 'Real-time sync of all meetings and events',
    icon: Calendar,
    color: 'text-emerald-600',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
    scopes: ['https://www.googleapis.com/auth/calendar'],
    category: 'scheduling',
    priority: 2,
  },
  {
    id: 'gmail',
    name: 'Gmail',
    desc: 'Send/receive emails directly from CRM',
    icon: Mail,
    color: 'text-red-600',
    bg: 'bg-red-500/10',
    border: 'border-red-500/20',
    scopes: ['https://www.googleapis.com/auth/gmail.send', 'https://www.googleapis.com/auth/gmail.readonly'],
    category: 'communication',
    priority: 3,
  },
  {
    id: 'googledrive',
    name: 'Google Drive',
    desc: 'Attach and share documents automatically',
    icon: FileText,
    color: 'text-yellow-600',
    bg: 'bg-yellow-500/10',
    border: 'border-yellow-500/20',
    scopes: ['https://www.googleapis.com/auth/drive.readonly'],
    category: 'storage',
    priority: 4,
  },
  {
    id: 'slack',
    name: 'Slack',
    desc: 'Get real-time alerts in your team channels',
    icon: MessageSquare,
    color: 'text-purple-600',
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/20',
    scopes: ['channels:read', 'chat:write', 'users:read'],
    category: 'communication',
    priority: 5,
  },
  {
    id: 'hubspot',
    name: 'HubSpot',
    desc: 'Bi-directional contact and deal sync',
    icon: Users,
    color: 'text-orange-600',
    bg: 'bg-orange-500/10',
    border: 'border-orange-500/20',
    scopes: ['crm.objects.contacts.read', 'crm.objects.contacts.write', 'crm.objects.deals.read'],
    category: 'crm',
    priority: 6,
  },
  {
    id: 'salesforce',
    name: 'Salesforce',
    desc: 'Enterprise CRM integration with lead sync',
    icon: BarChart3,
    color: 'text-sky-600',
    bg: 'bg-sky-500/10',
    border: 'border-sky-500/20',
    scopes: ['api', 'refresh_token'],
    category: 'crm',
    priority: 7,
  },
  {
    id: 'linkedin',
    name: 'LinkedIn',
    desc: 'Import leads and auto-post content',
    icon: Globe,
    color: 'text-sky-600',
    bg: 'bg-sky-500/10',
    border: 'border-sky-500/20',
    scopes: ['r_liteprofile', 'r_emailaddress', 'w_member_social'],
    category: 'social',
    priority: 8,
  },
  {
    id: 'zoom',
    name: 'Zoom',
    desc: 'Auto-generate Zoom meeting links for appointments',
    icon: Video,
    color: 'text-cyan-600',
    bg: 'bg-cyan-500/10',
    border: 'border-cyan-500/20',
    scopes: [],
    category: 'communication',
    priority: 9,
  },
];

export default function AutonomousIntegrations() {
  const qc = useQueryClient();
  const [connecting, setConnecting] = useState(null);
  const [autoMode, setAutoMode] = useState(false);
  const [autoQueue, setAutoQueue] = useState([]);
  const navigate = useNavigate();

  const { data: connections = [] } = useQuery({
    queryKey: ['oauth-connections'],
    queryFn: async () => {
      const res = await base44.functions.invoke('getOAuthConnections', {});
      return res.data?.connections || [];
    },
  });

  const connectMut = useMutation({
    mutationFn: async (integration) => {
      setConnecting(integration.id);
      try {
        const res = await base44.functions.invoke('oauthAuthorize', {
          integration_type: integration.id,
          scopes: integration.scopes,
        });
        const data = res.data || res;

        if (data.setup_required) {
          throw new Error(data.message || 'OAuth not configured — contact your admin.');
        }

        // Zoom server-to-server: no popup needed
        if (data.connected) {
          return { success: true, integration_id: integration.id };
        }

        if (!data.auth_url) {
          throw new Error('Failed to get authorization URL');
        }

        const popup = window.open(data.auth_url, '_blank', 'width=600,height=700');

        return new Promise((resolve) => {
          const checkClosed = setInterval(() => {
            if (!popup || popup.closed) {
              clearInterval(checkClosed);
              resolve({ success: true, integration_id: integration.id });
            }
          }, 500);
        });
      } catch (error) {
        throw error;
      }
    },
    onSuccess: (result) => {
      qc.invalidateQueries({ queryKey: ['oauth-connections'] });
      toast.success(`${INTEGRATIONS.find(i => i.id === result.integration_id)?.name} connected successfully!`);

      if (autoMode) {
        const remaining = autoQueue.filter(id => id !== result.integration_id);
        if (remaining.length > 0) {
          setAutoQueue(remaining);
          const next = INTEGRATIONS.find(i => i.id === remaining[0]);
          if (next) setTimeout(() => connectMut.mutate(next), 1500);
        } else {
          setAutoMode(false);
          setAutoQueue([]);
          toast.success('Quick Connect complete — all integrations connected!');
        }
      }
    },
    onError: (error) => {
      toast.error(`Connection failed: ${error.message}`);
    },
    onSettled: () => {
      setConnecting(null);
    },
  });

  const handleQuickConnect = () => {
    const unconnected = INTEGRATIONS.filter(i => !connections.find(c => c.provider === i.id));
    if (unconnected.length === 0) {
      toast.success('All integrations are already connected!');
      return;
    }
    setAutoQueue(unconnected.map(i => i.id));
    setAutoMode(true);
    connectMut.mutate(unconnected[0]);
  };

  const connectedCount = connections.length;
  const totalIntegrations = INTEGRATIONS.length;
  const progress = Math.round((connectedCount / totalIntegrations) * 100);

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/8 via-card to-purple-500/5">
        <CardContent className="p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-5 h-5 text-primary" />
                <h2 className="text-lg font-bold">Autonomous Integration Hub</h2>
                <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                  <Sparkles className="w-3 h-3 mr-1" />AI-Powered Setup
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Connect your accounts in one click. The system will automatically configure everything for you.
                Simply log into each account when prompted, and our AI handles the rest.
              </p>
              
              {/* Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">{connectedCount} of {totalIntegrations} connected</span>
                  <span className="font-semibold text-primary">{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <Button
                onClick={handleQuickConnect}
                disabled={connectMut.isPending}
                className="bg-primary hover:bg-primary/90"
              >
                {connectMut.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
                Quick Connect All
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate('/settings')}>
                Manual Setup
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Auto Mode Status */}
      {autoMode && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4 flex items-center gap-4">
            <Bot className="w-8 h-8 text-primary" />
            <div className="flex-1">
              <p className="font-semibold text-sm">Autonomous Setup in Progress</p>
              <p className="text-xs text-muted-foreground">
                {connecting 
                  ? `Connecting to ${INTEGRATIONS.find(i => i.id === connecting)?.name}... Please complete the OAuth flow in the popup window.`
                  : 'Preparing next connection...'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              {connecting && <Loader2 className="w-5 h-5 text-primary animate-spin" />}
              <Button variant="outline" size="sm" onClick={() => { setAutoMode(false); setAutoQueue([]); }}>
                Stop
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Integration Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {INTEGRATIONS.map((integration) => {
          const isConnected = connections.find(c => c.provider === integration.id);
          const isConnecting = connecting === integration.id;
          const isNextInAuto = autoMode && !connecting && autoQueue[0] === integration.id && !isConnected;

          return (
            <Card 
              key={integration.id} 
              className={`border transition-all ${
                isNextInAuto 
                  ? 'border-primary/50 bg-primary/10 ring-2 ring-primary/20' 
                  : isConnected 
                  ? 'border-emerald-500/30 bg-emerald-500/5' 
                  : 'border-border'
              }`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 rounded-xl ${integration.bg} flex items-center justify-center shrink-0`}>
                    <integration.icon className={`w-6 h-6 ${integration.color}`} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className={`font-semibold text-sm ${integration.color}`}>{integration.name}</h3>
                      {isConnected && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                      {isNextInAuto && !isConnected && (
                        <Badge className="bg-primary/20 text-primary border-primary/30 text-[10px]">
                          <ArrowRight className="w-3 h-3 mr-1" />Next
                        </Badge>
                      )}
                    </div>
                    
                    <p className="text-xs text-muted-foreground mb-2">{integration.desc}</p>
                    
                    {/* Scopes */}
                    <div className="flex flex-wrap gap-1 mb-3">
                      {integration.scopes.slice(0, 3).map((scope, i) => (
                        <Badge key={i} variant="outline" className="text-[9px] px-1.5 py-0.5 h-auto">
                          <Shield className="w-2.5 h-2.5 mr-0.5" />
                          {scope.split(':')[0]}
                        </Badge>
                      ))}
                      {integration.scopes.length > 3 && (
                        <Badge variant="outline" className="text-[9px] px-1.5 py-0.5 h-auto">
                          +{integration.scopes.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <Button
                      size="sm"
                      variant={isConnected ? 'outline' : 'default'}
                      className={`w-full text-xs h-9 ${
                        isConnected
                          ? 'border-emerald-500/30 text-emerald-700 hover:bg-emerald-500/10'
                          : ''
                      }`}
                      disabled={isConnecting}
                      onClick={() => !isConnected && connectMut.mutate(integration)}
                    >
                      {isConnected ? (
                        <><CheckCircle2 className="w-3.5 h-3.5 mr-2" />Connected</>
                      ) : isConnecting ? (
                        <><Loader2 className="w-3.5 h-3.5 mr-2 animate-spin" />Connecting...</>
                      ) : (
                        <><Zap className="w-3.5 h-3.5 mr-2" />Connect</>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* API Integrations Note */}
      <Card className="border-dashed">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-sm mb-1">API Key Integrations</h3>
              <p className="text-xs text-muted-foreground mb-3">
                Twilio SMS and Square Payments require API credentials. These are configured automatically during onboarding or can be set manually in Settings.
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <ExternalLink className="w-3 h-3 mr-1" />Twilio Docs
                </Button>
                <Button variant="outline" size="sm">
                  <ExternalLink className="w-3 h-3 mr-1" />Square Docs
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}