import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Users, Phone, Calendar } from 'lucide-react';

const TABS = [
  { path: '/app', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/leads', label: 'Leads', icon: Users },
  { path: '/call-logs', label: 'Calls', icon: Phone },
  { path: '/appointments', label: 'Appts', icon: Calendar },
];

export default function MobileBottomNav() {
  const location = useLocation();

  return (
    <nav
      className="no-select fixed bottom-0 left-0 right-0 z-50 flex items-stretch border-t border-border md:hidden"
      style={{
        background: 'hsl(var(--sidebar-background))',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {TABS.map((tab) => {
        const active = location.pathname === tab.path;
        const Icon = tab.icon;
        return (
          <Link
            key={tab.path}
            to={tab.path}
            className="no-select flex flex-1 flex-col items-center justify-center gap-0.5 py-2 transition-colors"
            style={{ minHeight: 44 }}
          >
            <Icon
              className={`w-5 h-5 ${active ? 'text-primary' : 'text-muted-foreground'}`}
            />
            <span
              className={`text-[10px] font-medium ${active ? 'text-primary' : 'text-muted-foreground'}`}
            >
              {tab.label}
            </span>
            <div
              className="absolute bottom-0 h-0.5 rounded-full transition-all duration-200"
              style={{
                width: active ? 24 : 0,
                background: 'hsl(var(--primary))',
              }}
            />
          </Link>
        );
      })}
    </nav>
  );
}