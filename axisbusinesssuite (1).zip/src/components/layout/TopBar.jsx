import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, LogOut, Menu, AlertCircle, CheckCircle2, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GlobalSearch from '@/components/layout/GlobalSearch';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuth } from '@/lib/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { ShoppingCart } from 'lucide-react';
import ManualSalePanel from '@/components/inventory/ManualSalePanel';

export default function TopBar({ user, onMobileMenuOpen }) {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const initials = user?.full_name
    ? user.full_name.split(' ').map(n => n[0]).join('').toUpperCase()
    : 'U';
  
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [saleOpen, setSaleOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const prevUnreadRef = useRef(0);
  const markingRef = useRef(false);

  const { data: saleSettings } = useQuery({
    queryKey: ['subscriber-sale-settings', user?.email],
    queryFn: () => base44.functions.invoke('getSubscriberSaleSettings', {}),
    enabled: !!user?.email,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });
  const sellsProducts = !!saleSettings?.data?.sells_products || !!saleSettings?.data?.is_retail;

  useEffect(() => {
    let unsubscribe = null;
    const loadNotifications = async () => {
      try {
        // Per-user in-app alerts (meeting invitations, task assignments, etc.)
        // RLS scopes UserNotification to the current user automatically.
        let userNotices = [];
        try {
          const userNotifs = await base44.entities.UserNotification.list('-created_date', 20);
          userNotices = userNotifs.map(n => ({
            id: n.id,
            title: n.title,
            description: n.body,
            severity: n.severity,
            department: n.type || 'alert',
            created_at: n.created_date,
            read: !!n.read,
            type: 'user',
            link: n.link || '',
          }));
        } catch (_) {}

        // Global system notices
        let systemNotices = [];
        try {
          const insights = await base44.entities.OperationalInsight.filter({ status: 'new' }, '-created_date', 10);
          systemNotices = insights.map(insight => ({
            id: insight.id,
            title: insight.title,
            description: insight.description,
            severity: insight.severity,
            department: insight.department,
            created_at: insight.created_date,
            read: false,
            type: 'system',
            link: '',
          }));
        } catch (_) {}

        const all = [...userNotices, ...systemNotices]
          .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        setNotifications(all);
        setUnreadCount(all.filter(n => !n.read).length);
      } catch (error) {
        console.error('Failed to load notifications:', error);
      }
    };

    loadNotifications();

    // Live-update the bell the moment a new per-user alert is created.
    // Skip re-fetching while a mark-as-read operation is in progress to avoid
    // race conditions where stale data overwrites the optimistic update.
    try {
      unsubscribe = base44.entities.UserNotification.subscribe(() => {
        if (markingRef.current) return;
        loadNotifications();
      });
    } catch (_) {}

    return () => { if (unsubscribe) unsubscribe(); };
  }, []);

  // Play an audible bell when a new notification arrives (unread count goes up).
  useEffect(() => {
    if (unreadCount > prevUnreadRef.current) {
      playBellSound();
    }
    prevUnreadRef.current = unreadCount;
  }, [unreadCount]);

  // Uses the Web Audio API to generate a pleasant bell tone — no external file needed.
  const playBellSound = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Two-tone bell: a higher note followed by a slightly lower one.
      const tones = [880, 660];
      tones.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;
        const start = now + i * 0.18;
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(0.3, start + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, start + 0.5);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + 0.5);
      });

      // Close the audio context after the sound finishes to free resources.
      setTimeout(() => { try { ctx.close(); } catch (_) {} }, 1200);
    } catch (_) { /* audio not available */ }
  };

  const markAllAsRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
    markingRef.current = true;
    try {
      await Promise.all([
        base44.entities.UserNotification.updateMany(
          { recipient_email: user?.email, read: false },
          { $set: { read: true } }
        ).catch(() => {}),
        base44.entities.OperationalInsight.updateMany(
          { status: 'new' },
          { $set: { status: 'acknowledged' } }
        ).catch(() => {}),
      ]);
    } catch (e) {
      console.warn('mark notifications read failed:', e);
    } finally {
      setTimeout(() => { markingRef.current = false; }, 1500);
    }
  };

  const markNotificationRead = async (notification) => {
    if (notification.read) return;
    setNotifications(prev => prev.map(n => n.id === notification.id ? { ...n, read: true } : n));
    setUnreadCount(prev => Math.max(0, prev - 1));
    markingRef.current = true;
    try {
      if (notification.type === 'user') {
        await base44.entities.UserNotification.update(notification.id, { read: true });
      } else if (notification.type === 'system') {
        await base44.entities.OperationalInsight.update(notification.id, { status: 'acknowledged' });
      }
    } catch (e) {
      console.warn('mark notification read failed:', e);
    } finally {
      setTimeout(() => { markingRef.current = false; }, 1500);
    }
  };
  
  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'critical': return AlertCircle;
      case 'high': return AlertCircle;
      case 'medium': return Info;
      case 'low': return Info;
      default: return CheckCircle2;
    }
  };
  
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'text-destructive bg-destructive/10 border-destructive/20';
      case 'high': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
      case 'medium': return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
      case 'low': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      default: return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
    }
  };

  return (
    <header className="h-14 sm:h-16 border-b border-border bg-card/80 backdrop-blur-sm flex items-center justify-between px-3 sm:px-4 md:px-6 sticky top-0 z-40">
      <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0 max-w-md">
        <Button variant="ghost" size="icon" className="lg:hidden shrink-0 h-8 w-8" onClick={onMobileMenuOpen}>
          <Menu className="w-5 h-5" />
        </Button>
        <GlobalSearch />
      </div>

      <div className="flex items-center gap-2 sm:gap-3 shrink-0">
        {sellsProducts && (
          <Button
            onClick={() => setSaleOpen(true)}
            className="bg-primary text-primary-foreground hover:bg-primary/90 h-9 px-4 gap-2 font-semibold shadow-sm shadow-primary/30"
          >
            <ShoppingCart className="w-4 h-4" />
            <span className="hidden sm:inline">New Sale</span>
          </Button>
        )}

        <Button 
          variant="ghost" 
          size="icon" 
          className="relative h-8 w-8 sm:h-9 sm:w-9"
          onClick={() => setNotificationsOpen(true)}
        >
          <Bell className="w-[18px] h-[18px]" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-primary rounded-full" />
          )}
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 pl-2 sm:pl-3 pr-1 py-1 rounded-full hover:bg-muted transition-colors">
              <div className="text-right hidden sm:block max-w-[120px]">
                <p className="text-sm font-medium leading-none truncate">{user?.full_name || 'User'}</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 capitalize">{user?.role || 'user'}</p>
              </div>
              <Avatar className="h-8 w-8 shrink-0">
                <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">{initials}</AvatarFallback>
              </Avatar>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => {
              logout(false);
              window.location.href = '/';
            }}>
              <LogOut className="w-4 h-4 mr-2" /> Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        {/* New Sale Sheet */}
        <Sheet open={saleOpen} onOpenChange={setSaleOpen}>
          <SheetContent side="right" className="w-full sm:max-w-3xl p-0 overflow-y-auto">
            <SheetHeader className="px-6 pt-6 pb-2 text-left">
              <SheetTitle className="flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-primary" />
                Point of Sale
              </SheetTitle>
              <SheetDescription>Ring up a manual sale — inventory syncs with your storefront automatically.</SheetDescription>
            </SheetHeader>
            <div className="px-6 pb-6">
              <ManualSalePanel />
            </div>
          </SheetContent>
        </Sheet>

        {/* Notifications Sheet */}
        <Sheet open={notificationsOpen} onOpenChange={setNotificationsOpen}>
          <SheetContent className="w-full sm:max-w-md">
            <SheetHeader>
              <div className="flex items-center justify-between">
                <div>
                  <SheetTitle>System Notices</SheetTitle>
                  <SheetDescription>
                    {unreadCount > 0 ? `${unreadCount} unread notification${unreadCount > 1 ? 's' : ''}` : 'All caught up!'}
                  </SheetDescription>
                </div>
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                    Mark all read
                  </Button>
                )}
              </div>
            </SheetHeader>
            <ScrollArea className="h-[calc(100vh-8rem)] mt-4">
              <div className="space-y-3">
                {notifications.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Bell className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p className="text-sm">No system notices at the moment</p>
                  </div>
                ) : (
                  notifications.map(notification => {
                    const SeverityIcon = getSeverityIcon(notification.severity);
                    return (
                      <div
                        key={notification.id}
                        onClick={() => {
                          markNotificationRead(notification);
                          if (notification.link) navigate(notification.link);
                        }}
                        className={`p-4 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors ${
                          notification.read 
                            ? 'bg-muted/30 border-border' 
                            : 'bg-card border-primary/20 shadow-sm'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${getSeverityColor(notification.severity)}`}>
                            <SeverityIcon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className={`text-sm font-semibold ${!notification.read ? 'text-foreground' : 'text-muted-foreground'}`}>
                                {notification.title}
                              </h4>
                              {!notification.read && (
                                <Badge variant="outline" className="text-[10px] h-5 px-1.5">New</Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              {notification.description}
                            </p>
                            <div className="flex items-center gap-2 mt-2 text-[10px] text-muted-foreground">
                              <Badge variant="secondary" className="h-4 px-1 text-[9px]">
                                {notification.department}
                              </Badge>
                              <span>
                                {new Date(notification.created_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </ScrollArea>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}