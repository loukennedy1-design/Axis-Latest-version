import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ChevronLeft, ChevronRight, ChevronDown, Crown, Lock, LayoutDashboard, Settings, UserCog } from 'lucide-react';
import { cn } from '@/lib/utils';
import DesktopAppDownload from '@/components/layout/DesktopAppDownload';
import IntegrationHealthIndicator from '@/components/connections/IntegrationHealthIndicator';
import { useEmployeeRole } from '@/hooks/useEmployeeRole';
import {
  moduleNavMapping, navGroupStructure, adminItems, adminSystemItems,
} from '@/components/layout/navConfig';

export default function Sidebar({ user, collapsed, onCollapse, onMobileClose }) {
  const location = useLocation();
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [enabledModules, setEnabledModules] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [openGroup, setOpenGroup] = useState(null);

  // Super admin check
  useEffect(() => {
    if (!user?.email) return;
    base44.functions.invoke('verifyAccessCode', { type: 'super_admin_check' })
      .then(res => { if (res.data?.isSuperAdmin) setIsSuperAdmin(true); })
      .catch(() => {});
  }, [user?.email]);



  // Fetch enabled modules + listen for sidebar updates
  useEffect(() => {
    const fetchSettings = async () => {
      if (!user?.email) return;
      try {
        const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
        const settings = res.data?.settings;
        if (settings?.enabled_modules) {
          const modules = JSON.parse(settings.enabled_modules || '[]');
          setEnabledModules(Array.isArray(modules) ? modules : []);
        } else {
          setEnabledModules(user?.onboarding_completed ? Object.keys(moduleNavMapping) : ['dashboard', 'settings', 'account_settings', 'account_api']);
        }
      } catch (error) {
        setEnabledModules(['dashboard', 'settings', 'account_settings', 'account_api']);
      } finally {
        setIsLoading(false);
      }
    };
    fetchSettings();
    const handler = () => fetchSettings();
    window.addEventListener('axis-sidebar-updated', handler);
    return () => window.removeEventListener('axis-sidebar-updated', handler);
  }, [user?.email, user?.onboarding_completed]);

  const { isSubUser, portalRole, allowedModules, landing } = useEmployeeRole();
  const isEmployeeScope = isSubUser && !!portalRole;
  const isModuleAllowed = (id) => !isEmployeeScope || allowedModules === null || allowedModules.includes(id);

  // Auto-open the group containing the active route (single-open accordion)
  useEffect(() => {
    const activeGroup = navGroupStructure.find(g =>
      g.items.some(id => {
        const item = moduleNavMapping[id];
        return item && location.pathname === item.path;
      })
    );
    if (activeGroup) {
      setOpenGroup(activeGroup.label);
      return;
    }
    const allAdminPaths = [...adminItems, ...adminSystemItems].map(a => a.path);
    if (allAdminPaths.includes(location.pathname) || location.pathname === '/admin') {
      setOpenGroup('Admin Controls');
    }
  }, [location.pathname]);

  const toggleGroup = (label) => {
    setOpenGroup(prev => prev === label ? null : label);
  };

  const handleNavClick = () => {
    if (onMobileClose) onMobileClose();
  };

  const isActive = (path) => location.pathname === path;

  // All items always listed; disabled ones show as locked
  const resolveVisibleIds = (group) => {
    return group.items.filter(id => moduleNavMapping[id]);
  };

  // Render a single nav item (expanded or collapsed)
  const renderItem = (id) => {
    const item = moduleNavMapping[id];
    if (!item) return null;
    const active = isActive(item.path);
    const employeeBlocked = isEmployeeScope && !isModuleAllowed(id);

    if (!employeeBlocked) {
      return (
        <Link
          key={item.path}
          to={item.path}
          onClick={handleNavClick}
          title={collapsed ? item.label : undefined}
          className={cn(
            "flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-sm transition-all mb-0.5",
            active
              ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium"
              : "text-sidebar-foreground/60 hover:bg-sidebar-accent",
            collapsed && "justify-center px-2 py-2"
          )}
        >
          <item.icon className="w-4 h-4 flex-shrink-0" />
          {!collapsed && <span className="truncate">{item.label}</span>}
        </Link>
      );
    }
    return (
      <div
        key={item.path}
        title={collapsed ? `${item.label} (locked)` : undefined}
        className={cn(
          "flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-sm opacity-50 cursor-not-allowed mb-0.5",
          collapsed && "justify-center px-2 py-2"
        )}
      >
        <item.icon className="w-4 h-4 flex-shrink-0" />
        {!collapsed && <span className="truncate flex-1">{item.label}</span>}
        {!collapsed && <Lock className="w-3 h-3 text-sidebar-foreground/40" />}
      </div>
    );
  };

  // Collapsed mode: icon-only group header with tooltip
  const renderCollapsedGroup = (group) => {
    const visibleIds = resolveVisibleIds(group);
    if (visibleIds.length === 0) return null;
    const isOpen = openGroup === group.label;
    return (
      <div key={group.label} className="px-2 mb-0.5">
        <button
          onClick={() => toggleGroup(group.label)}
          title={group.label}
          className={cn(
            "flex items-center justify-center w-full py-2.5 rounded-lg transition-all",
            isOpen
              ? "text-sidebar-primary bg-sidebar-accent"
              : "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent"
          )}
        >
          <group.icon className="w-5 h-5 flex-shrink-0" />
        </button>
      </div>
    );
  };

  // Expanded mode: accordion group with header + children
  const renderExpandedGroup = (group) => {
    const visibleIds = resolveVisibleIds(group);
    if (visibleIds.length === 0) return null;
    const isOpen = openGroup === group.label;
    return (
      <div key={group.label} className="px-3 mb-0.5">
        <button
          onClick={() => toggleGroup(group.label)}
          className={cn(
            "flex items-center gap-2.5 w-full py-2 px-3 rounded-lg text-sm font-medium transition-all",
            isOpen
              ? "text-sidebar-foreground bg-sidebar-accent/50 border-l-2 border-sidebar-primary"
              : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent border-l-2 border-transparent"
          )}
        >
          <span className="text-base leading-none flex-shrink-0">{group.emoji}</span>
          <span className="truncate flex-1 text-left">{group.label}</span>
          <ChevronDown className={cn("w-4 h-4 flex-shrink-0 transition-transform duration-200", isOpen ? "rotate-180" : "")} />
        </button>
        {isOpen && (
          <div className="mt-0.5 pl-2">
            {visibleIds.map(id => renderItem(id))}
          </div>
        )}
      </div>
    );
  };

  // Admin Controls section (amber-themed, admin/super_admin only)
  const renderAdminGroup = () => {
    if (!isAdmin) return null;
    const isOpen = openGroup === 'Admin Controls';
    const allItems = [...adminItems, ...adminSystemItems];

    if (collapsed) {
      return (
        <div className="px-2 mt-1 mb-0.5">
          <button
            onClick={() => toggleGroup('Admin Controls')}
            title="Admin Controls"
            className={cn(
              "flex items-center justify-center w-full py-2.5 rounded-lg transition-all",
              isOpen
                ? "text-amber-400 bg-amber-500/10"
                : "text-amber-400/70 hover:text-amber-400 hover:bg-amber-500/10"
            )}
          >
            <Crown className="w-5 h-5" />
          </button>
        </div>
      );
    }
    return (
      <div className="px-3 mt-1 mb-0.5">
        <button
          onClick={() => toggleGroup('Admin Controls')}
          className={cn(
            "flex items-center gap-2.5 w-full py-2 px-3 rounded-lg text-sm font-medium transition-all border-l-2",
            isOpen
              ? "text-amber-400 bg-amber-500/10 border-amber-500"
              : "text-amber-400/70 hover:text-amber-400 hover:bg-amber-500/10 border-transparent"
          )}
        >
          <span className="text-base leading-none flex-shrink-0">👑</span>
          <span className="truncate flex-1 text-left">Admin Controls</span>
          <ChevronDown className={cn("w-4 h-4 flex-shrink-0 transition-transform duration-200", isOpen ? "rotate-180" : "")} />
        </button>
        {isOpen && (
          <div className="mt-0.5 pl-2">
            {allItems.map(item => {
              const active = isActive(item.path);
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={handleNavClick}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-sm transition-all mb-0.5",
                    active
                      ? "bg-amber-500/20 text-amber-300 font-medium"
                      : "text-amber-400/60 hover:text-amber-300 hover:bg-amber-500/10"
                  )}
                >
                  <item.icon className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{item.label}</span>
                </Link>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  const dashboardPath = isEmployeeScope ? landing : '/app';

  return (
    <aside className={cn(
      "fixed left-0 top-0 h-screen bg-sidebar text-sidebar-foreground flex flex-col z-50 transition-all duration-300 border-r border-sidebar-border overflow-hidden",
      collapsed ? "w-[68px]" : "w-64"
    )}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-sidebar-border flex-shrink-0">
        <img src="https://media.base44.com/images/public/69ef71210cace64a00bec165/db6b11da8_ChatGPTImageMay8202612_44_40PM.png" alt="AXIS" className="h-8 flex-shrink-0" />
        {!collapsed && (
          <div className="min-w-0">
            <span className="font-poppins font-bold text-sm tracking-widest bg-gradient-to-r from-[#F5C842] to-[#D4AF37] bg-clip-text text-transparent leading-none block uppercase">Axis</span>
            <span className="text-[9px] tracking-[0.15em] text-sidebar-foreground/40 leading-none uppercase font-poppins">Business Super Suite</span>
          </div>
        )}
      </div>

      {/* Super Admin badge */}
      {isSuperAdmin && (
        <div className={cn("px-3 py-2 border-b border-sidebar-border flex-shrink-0", collapsed && "px-2")}>
          <Link
            to="/admin"
            onClick={handleNavClick}
            title={collapsed ? 'Super Admin' : undefined}
            className={cn(
              "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-bold transition-all",
              isActive('/admin')
                ? "bg-amber-500/30 text-amber-300 shadow-md"
                : "text-amber-400 hover:text-amber-300 hover:bg-amber-500/20 border border-amber-500/40",
              collapsed && "justify-center px-2"
            )}
          >
            <Crown className="w-5 h-5 flex-shrink-0 text-amber-400" />
            {!collapsed && <span className="truncate">⚡ Super Admin</span>}
          </Link>
        </div>
      )}

      {/* Nav (scrollable) */}
      <nav className="flex-1 py-2 overflow-y-auto no-scrollbar min-h-0">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-6 h-6 border-2 border-sidebar-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            {/* Pinned Dashboard at top */}
            <div className={cn("px-3 mb-2", collapsed && "px-2")}>
              <Link
                to={dashboardPath}
                onClick={handleNavClick}
                title={collapsed ? 'Dashboard' : undefined}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                  isActive(dashboardPath)
                    ? "bg-sidebar-primary text-sidebar-primary-foreground"
                    : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
                  collapsed && "justify-center px-2"
                )}
              >
                <LayoutDashboard className="w-5 h-5 flex-shrink-0" />
                {!collapsed && <span className="truncate">Dashboard</span>}
              </Link>
            </div>

            {/* Accordion groups */}
            {navGroupStructure.map(group => (
              collapsed ? renderCollapsedGroup(group) : renderExpandedGroup(group)
            ))}
            {renderAdminGroup()}
          </>
        )}
      </nav>

      {/* Pinned Settings + My Settings (above footer, outside scroll) */}
      {!isLoading && (
        <div className={cn(
          "border-t border-sidebar-border flex-shrink-0 py-1.5",
          collapsed ? "px-2" : "px-3"
        )}>
          <Link
            to="/settings"
            onClick={handleNavClick}
            title={collapsed ? 'Settings' : undefined}
            className={cn(
              "flex items-center gap-3 px-3 py-1.5 rounded-lg text-sm font-medium transition-all mb-0.5",
              isActive('/settings')
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
              collapsed && "justify-center px-2 py-2"
            )}
          >
            <Settings className="w-5 h-5 flex-shrink-0" />
            {!collapsed && <span className="truncate">Settings</span>}
          </Link>
          <Link
            to="/my-settings"
            onClick={handleNavClick}
            title={collapsed ? 'My Settings' : undefined}
            className={cn(
              "flex items-center gap-3 px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
              isActive('/my-settings')
                ? "bg-sidebar-primary text-sidebar-primary-foreground"
                : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
              collapsed && "justify-center px-2 py-2"
            )}
          >
            <UserCog className="w-5 h-5 flex-shrink-0" />
            {!collapsed && <span className="truncate">My Settings</span>}
          </Link>
        </div>
      )}

      {/* Footer */}
      {!collapsed ? (
        <div className="px-4 py-2 border-t border-sidebar-border flex-shrink-0 space-y-2">
          <IntegrationHealthIndicator collapsed={false} />
          {!isAdmin && !isEmployeeScope && (
            <Link to="/pricing" className="flex items-center justify-center gap-1 text-xs font-semibold text-amber-400 hover:text-amber-300 transition-colors py-1">
              Upgrade Plan →
            </Link>
          )}
          <DesktopAppDownload collapsed={false} />
        </div>
      ) : (
        <div className="px-2 py-2 border-t border-sidebar-border flex-shrink-0 space-y-1">
          <IntegrationHealthIndicator collapsed />
          <div className="flex justify-center">
            <DesktopAppDownload collapsed />
          </div>
        </div>
      )}

      {/* Collapse toggle */}
      <button
        onClick={() => onCollapse(!collapsed)}
        className="flex items-center justify-center h-10 border-t border-sidebar-border text-sidebar-foreground/40 hover:text-sidebar-foreground transition-colors flex-shrink-0"
      >
        {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
    </aside>
  );
}