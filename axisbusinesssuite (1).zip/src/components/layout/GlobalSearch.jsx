import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Search, X, Users, Phone, Calendar, ListTodo, Package, FileText, DollarSign, Briefcase, MessageSquare, Mail, ArrowRight, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const SEARCH_SOURCES = [
  { entity: 'Lead', label: 'Leads', icon: Users, color: 'text-blue-500', path: '/leads', fields: ['first_name', 'last_name', 'phone', 'email', 'company'], display: l => `${l.first_name || ''} ${l.last_name || ''}`.trim() || l.phone, sub: l => l.company || l.email || l.phone },
  { entity: 'CallLog', label: 'Call Logs', icon: Phone, color: 'text-green-500', path: '/call-logs', fields: ['lead_name', 'phone_number', 'ai_summary'], display: c => c.lead_name || c.phone_number, sub: c => c.ai_summary?.slice(0, 60) || c.status },
  { entity: 'Appointment', label: 'Appointments', icon: Calendar, color: 'text-purple-500', path: '/appointments', fields: ['lead_name', 'lead_email', 'lead_phone'], display: a => a.lead_name || 'Unknown', sub: a => a.scheduled_date ? new Date(a.scheduled_date).toLocaleString() : a.status },
  { entity: 'FollowUpTask', label: 'Tasks', icon: ListTodo, color: 'text-amber-500', path: '/tasks', fields: ['lead_name', 'notes', 'task_type'], display: t => t.lead_name || t.task_type, sub: t => t.notes?.slice(0, 60) || t.status },
  { entity: 'Employee', label: 'Employees', icon: Briefcase, color: 'text-rose-500', path: '/hr', fields: ['first_name', 'last_name', 'email', 'department', 'position'], display: e => `${e.first_name || ''} ${e.last_name || ''}`.trim(), sub: e => e.department || e.position },
  { entity: 'Invoice', label: 'Invoices', icon: DollarSign, color: 'text-emerald-500', path: '/financial-ops', fields: ['invoice_number', 'customer_name', 'customer_email'], display: i => i.invoice_number || i.customer_name, sub: i => `$${i.total_amount || 0} · ${i.status}` },
  { entity: 'Document', label: 'Documents', icon: FileText, color: 'text-slate-500', path: '/document-intelligence', fields: ['title', 'description', 'document_type'], display: d => d.title || d.document_type, sub: d => d.description?.slice(0, 60) || d.status },
  { entity: 'EmailMessage', label: 'Emails', icon: Mail, color: 'text-cyan-500', path: '/email', fields: ['subject', 'from_email', 'to_email', 'body_preview'], display: e => e.subject || '(no subject)', sub: e => e.from_email || e.to_email },
  { entity: 'SmsMessage', label: 'SMS', icon: MessageSquare, color: 'text-teal-500', path: '/sms', fields: ['body', 'phone_number', 'contact_name'], display: s => s.contact_name || s.phone_number, sub: s => s.body?.slice(0, 60) },
];

function highlight(text, query) {
  if (!text || !query) return text;
  const idx = text.toLowerCase().indexOf(query.toLowerCase());
  if (idx === -1) return text;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="bg-primary/20 text-primary rounded px-0.5">{text.slice(idx, idx + query.length)}</mark>
      {text.slice(idx + query.length)}
    </>
  );
}

export default function GlobalSearch() {
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const containerRef = useRef(null);
  const debounceRef = useRef(null);
  const navigate = useNavigate();

  const search = useCallback(async (q) => {
    if (!q || q.trim().length < 2) { setResults([]); setLoading(false); return; }
    setLoading(true);
    const term = q.trim().toLowerCase();
    const allResults = [];

    await Promise.all(
      SEARCH_SOURCES.map(async (source) => {
        try {
          const records = await base44.entities[source.entity].list('-created_date', 200);
          const matched = records.filter(r =>
            source.fields.some(f => r[f] && String(r[f]).toLowerCase().includes(term))
          ).slice(0, 5);
          matched.forEach(r => allResults.push({ ...r, _source: source }));
        } catch (_) {}
      })
    );

    setResults(allResults);
    setLoading(false);
  }, []);

  useEffect(() => {
    clearTimeout(debounceRef.current);
    if (query.trim().length >= 2) {
      setLoading(true);
      debounceRef.current = setTimeout(() => search(query), 400);
    } else {
      setResults([]);
      setLoading(false);
    }
    return () => clearTimeout(debounceRef.current);
  }, [query, search]);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // Keyboard shortcut Cmd/Ctrl+K
  useEffect(() => {
    const handler = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen(true);
        setTimeout(() => inputRef.current?.focus(), 50);
      }
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  const handleSelect = (item) => {
    navigate(item._source.path);
    setOpen(false);
    setQuery('');
    setResults([]);
  };

  const grouped = SEARCH_SOURCES.map(src => ({
    source: src,
    items: results.filter(r => r._source.entity === src.entity),
  })).filter(g => g.items.length > 0);

  return (
    <div ref={containerRef} className="relative flex-1 min-w-0 max-w-md">
      <div className="flex items-center gap-2">
        <Search className="w-4 h-4 text-muted-foreground hidden sm:block shrink-0" />
        <input
          ref={inputRef}
          value={query}
          onChange={e => { setQuery(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          placeholder="Search anything... (⌘K)"
          className="border-0 bg-transparent shadow-none text-sm hidden sm:block w-full outline-none placeholder:text-muted-foreground text-foreground"
        />
        {query && (
          <button onClick={() => { setQuery(''); setResults([]); }} className="hidden sm:flex shrink-0 text-muted-foreground hover:text-foreground">
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {open && query.trim().length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-xl shadow-2xl z-[100] overflow-hidden" style={{ minWidth: '360px' }}>
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-6 text-muted-foreground text-sm">
              <Loader2 className="w-4 h-4 animate-spin" /> Searching...
            </div>
          ) : grouped.length === 0 ? (
            <div className="py-6 text-center text-muted-foreground text-sm">No results for "{query}"</div>
          ) : (
            <div className="max-h-[420px] overflow-y-auto divide-y divide-border">
              {grouped.map(({ source, items }) => {
                const Icon = source.icon;
                return (
                  <div key={source.entity}>
                    <div className="px-3 py-2 flex items-center gap-2">
                      <Icon className={`w-3.5 h-3.5 ${source.color}`} />
                      <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{source.label}</span>
                      <span className="text-[10px] text-muted-foreground ml-auto">{items.length} result{items.length > 1 ? 's' : ''}</span>
                    </div>
                    {items.map(item => (
                      <button
                        key={item.id}
                        onClick={() => handleSelect(item)}
                        className="w-full flex items-center justify-between gap-3 px-3 py-2.5 hover:bg-muted/60 text-left group transition-colors"
                      >
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-medium truncate text-foreground group-hover:text-primary transition-colors">
                            {highlight(String(item._source.display(item)), query)}
                          </p>
                          {item._source.sub(item) && (
                            <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                              {highlight(String(item._source.sub(item)), query)}
                            </p>
                          )}
                        </div>
                        <ArrowRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </button>
                    ))}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}