import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Rocket, AlertCircle, ArrowRight, Zap, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export default function IndustryOnboardingGate({ user }) {
  const navigate = useNavigate();
  const location = useLocation();
  const qc = useQueryClient();
  const [skipping, setSkipping] = useState(false);

  // Don't block if already on the onboarding page
  if (location.pathname === '/industry-onboarding') return null;

  const handleStartOnboarding = () => {
    navigate('/industry-onboarding');
  };

  const handleSkipEnableAll = async () => {
    setSkipping(true);
    try {
      // Call backend to create SystemSettings AND mark onboarding complete on user record
      await base44.functions.invoke('configureIndustryAdapter', { skip_all: true });
      toast.success('All modules enabled!');
      setTimeout(() => {
        window.location.href = '/app';
      }, 800);
    } catch (e) {
      console.error('Skip failed:', e);
      toast.error('Failed: ' + (e.message || 'Unknown error'));
      setSkipping(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full border-primary/20 shadow-2xl">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
            <Rocket className="w-8 h-8 text-primary" />
          </div>
          <CardTitle className="text-2xl font-bold">Welcome to Axis Business Suite!</CardTitle>
          <CardDescription className="text-lg mt-2">
            Let's configure your workspace for your industry
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-muted/50 rounded-lg p-4 border border-primary/10">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-semibold mb-2">Industry configuration required</p>
                <p className="text-muted-foreground">
                  To provide you with the most relevant features and AI-powered tools, 
                  we need to understand your business needs. This quick setup will 
                  customize your dashboard, modules, and workflows.
                </p>
              </div>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="bg-card rounded-lg p-4 border border-border">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <span className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs">1</span>
                Business Profile
              </h4>
              <p className="text-sm text-muted-foreground">
                Tell us about your company, industry, and team size
              </p>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <span className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs">2</span>
                Team Capabilities
              </h4>
              <p className="text-sm text-muted-foreground">
                Configure sales, marketing, HR, and recruiting features
              </p>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <span className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs">3</span>
                AI Configuration
              </h4>
              <p className="text-sm text-muted-foreground">
                Set up your AI assistant, calling preferences, and automation
              </p>
            </div>
            <div className="bg-card rounded-lg p-4 border border-border">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <span className="w-6 h-6 bg-primary/10 rounded-full flex items-center justify-center text-xs">4</span>
                Module Activation
              </h4>
              <p className="text-sm text-muted-foreground">
                Get personalized modules and workflows for your needs
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button 
              onClick={handleStartOnboarding} 
              size="lg" 
              className="flex-1 text-base"
            >
              Start Configuration
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button
              onClick={handleSkipEnableAll}
              size="lg"
              variant="outline"
              className="flex-1 text-base gap-2"
              disabled={skipping}
            >
              {skipping ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {skipping ? 'Enabling...' : 'Skip & Enable Everything'}
            </Button>
          </div>

          <p className="text-center text-xs text-muted-foreground">
            "Skip & Enable Everything" turns on all modules instantly. You can customize anytime in Settings.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}