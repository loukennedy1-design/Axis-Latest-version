import React, { useState, useMemo } from 'react';
import { MonitorDown } from 'lucide-react';
import { cn } from '@/lib/utils';

// Installer download URLs — update these when builds are published.
const DOWNLOADS = {
  windows: 'https://axisbusiness.app/download/axis-setup.exe',
  mac: 'https://axisbusiness.app/download/Axis.dmg',
};

function detectOS() {
  if (typeof navigator === 'undefined') return 'windows';
  const ua = navigator.userAgent || '';
  if (/Mac|iPhone|iPad|iPod/i.test(ua)) return 'mac';
  if (/Windows/i.test(ua)) return 'windows';
  return 'windows';
}

export default function DesktopAppDownload({ collapsed }) {
  const os = useMemo(detectOS, []);
  const [hovered, setHovered] = useState(false);
  const primaryUrl = DOWNLOADS[os];

  return (
    <div
      className={cn('relative', collapsed && 'flex justify-center')}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <a
        href={primaryUrl}
        download
        title={collapsed ? 'Download Desktop App — Windows & Mac available' : undefined}
        className={cn(
          'flex items-center gap-2.5 rounded-lg border border-sidebar-border bg-sidebar-accent/40 text-sidebar-foreground/70 hover:text-sidebar-foreground hover:border-primary/40 hover:bg-primary/5 transition-all',
          collapsed ? 'justify-center w-10 h-10' : 'px-2.5 py-2 w-full'
        )}
      >
        <MonitorDown className="w-4 h-4 flex-shrink-0 text-primary/80" />
        {!collapsed && (
          <span className="text-[11px] font-semibold leading-tight">Download Desktop App</span>
        )}
      </a>

      {/* Expanded tooltip / sub-label when not collapsed */}
      {!collapsed && hovered && (
        <div className="absolute bottom-full left-0 right-0 mb-1.5 rounded-md bg-popover border border-sidebar-border px-2 py-1 text-[9px] text-muted-foreground shadow-lg z-10">
          Windows &amp; Mac available
        </div>
      )}

      {/* Collapsed tooltip */}
      {collapsed && hovered && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 whitespace-nowrap rounded-md bg-popover border border-sidebar-border px-2 py-1 text-[10px] text-popover-foreground shadow-lg z-10">
          Download Desktop App
          <div className="text-[9px] text-muted-foreground text-center">Windows &amp; Mac</div>
        </div>
      )}
    </div>
  );
}