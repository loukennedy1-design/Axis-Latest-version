import React, { useState, useEffect } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import AIAssistant from '@/components/ai/AIAssistant';
import TrialExpiredGate from './TrialExpiredGate';
import TrinityWelcomeModal from '@/components/trinity/TrinityWelcomeModal';
import AnniversaryReviewModal from '@/components/anniversary/AnniversaryReviewModal';
import LaunchPad from '@/components/trinity/LaunchPad';
import HintBubble from '@/components/trinity/HintBubble';
import UsageMonitor from '@/components/usage/UsageMonitor';
import { base44 } from '@/api/base44Client';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { Loader2, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useEmployeeRole } from '@/hooks/useEmployeeRole';
import MobileBottomNav from './MobileBottomNav';

export default function AppLayout() {
  const { user, loading } = useCurrentUser();
  const navigate = useNavigate();
  const location = useLocation();
  const qc = useQueryClient();
  const { isSubUser, portalRole, landing, isPathAllowed } = useEmployeeRole();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);
  const [showTrinityWelcome, setShowTrinityWelcome] = useState(false);
  const [isRep, setIsRep] = useState(null);

  // Admins and super_admins are never sales reps — skip the query entirely
  const isAdminUser = user?.role === 'admin' || user?.role === 'super_admin';

  // Check if user is a sales rep - redirect to Rep Portal
  const { data: repProfile } = useQuery({
    queryKey: ['is-sales-rep', user?.email],
    queryFn: () => base44.entities.SalesRep.filter({ email: user.email }),
    enabled: !!user?.email && !isAdminUser,
    select: (records) => records?.[0] || null,
    retry: 1,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    // Admins skip rep redirect entirely
    if (isAdminUser) {
      setIsRep(false);
      return;
    }
    if (repProfile) {
      setIsRep(true);
      navigate('/rep-portal', { replace: true });
    } else if (repProfile === null && user) {
      setIsRep(false);
    }
  }, [repProfile, user, navigate, isAdminUser]);

  // Role-specific landing: employees land on their role's dashboard, not /app.
  useEffect(() => {
    if (isSubUser && portalRole && location.pathname === '/app' && landing !== '/app') {
      navigate(landing, { replace: true });
    }
  }, [isSubUser, portalRole, location.pathname, landing, navigate]);

  // Check if the user's trial has expired
  const { data: trialRecord } = useQuery({
    queryKey: ['trial-status', user?.email],
    queryFn: () => base44.entities.TrialInvite.filter({ email: user.email }),
    enabled: !!user?.email && user?.role !== 'admin' && user?.role !== 'super_admin',
    select: (records) => records?.[0] || null,
    retry: 1,
    staleTime: 5 * 60 * 1000,
  });

  const isTrialExpired = (() => {
    if (!trialRecord) return false;
    if (user?.role === 'admin' || user?.role === 'super_admin') return false;
    if (user?.email === 'loukennedy1@gmail.com') return false;
    if (trialRecord.billing_disabled || trialRecord.free_trial_override) return false;
    if (trialRecord.status === 'converted') return false;
    if (!trialRecord.trial_end) return false;
    return new Date(trialRecord.trial_end) < new Date();
  })();

  const hasIndustryConfig = !!user?.onboarding_completed || user?.role === 'admin' || user?.role === 'super_admin' || (isSubUser && portalRole) || !!repProfile;
  const requiresIndustryOnboarding = !hasIndustryConfig && user?.role !== 'admin' && user?.role !== 'super_admin' && !(isSubUser && portalRole) && !repProfile;

  // Show Trinity welcome on first login (when user hasn't seen it yet) — skip for reps
  useEffect(() => {
    if (user && !user.trinity_welcome_seen && !repProfile && !isAdminUser) {
      setShowTrinityWelcome(true);
    }
  }, [user, repProfile, isAdminUser]);



  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    setIsDesktop(mq.matches);
    const handler = (e) => {
      setIsDesktop(e.matches);
      if (e.matches) setMobileOpen(false);
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  // Dark mode: match system theme in WebView environments (only if no explicit class is set)
  useEffect(() => {
    const root = document.documentElement;
    const hasExplicit = root.classList.contains('dark') || root.classList.contains('light');
    if (hasExplicit) return;

    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    if (mq.matches) root.classList.add('dark');

    const handler = (e) => {
      if (e.matches) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);



  const desktopMargin = collapsed ? 68 : 240;

  // Show spinner while checking auth and rep status
  if (loading || isRep === null) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  // Role-based access gate: employees can only visit routes their role allows.
  const accessDenied = isSubUser && portalRole && !isPathAllowed(location.pathname);
  if (accessDenied) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background p-6">
        <div className="max-w-sm text-center space-y-4">
          <div className="w-14 h-14 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
            <ShieldAlert className="w-7 h-7 text-destructive" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Access Denied</h1>
            <p className="text-sm text-muted-foreground mt-1">Your role doesn't include this area. Return to your home dashboard to continue.</p>
          </div>
          <Button onClick={() => navigate(landing, { replace: true })}>Go to my home</Button>
        </div>
      </div>
    );
  }

  // First-run: full-screen Launch Pad (no sidebar, no topbar)
  if (requiresIndustryOnboarding) {
    return (
      <LaunchPad
        user={user}
        onComplete={() => {
          // Force a refetch of the user so onboarding_completed flag updates
          qc.invalidateQueries();
          // Navigate to dashboard
          window.location.href = '/app';
        }}
      />
    );
  }

  return (
    <UsageMonitor>
      <div className="min-h-screen bg-background font-inter">
        {/* Mobile overlay */}
        {mobileOpen && (
          <div
            className="fixed inset-0 bg-black/60 z-40 lg:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}

        {/* Sidebar */}
        <div className={`fixed left-0 top-0 h-screen z-50 transition-transform duration-300 ease-in-out ${mobileOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0`}>
          <Sidebar user={user} collapsed={collapsed} onCollapse={setCollapsed} onMobileClose={() => setMobileOpen(false)} />
        </div>

        {/* Main content */}
        <div
          className="transition-all duration-300 min-w-0"
          style={{ marginLeft: isDesktop ? desktopMargin : 0 }}
        >
          <TopBar user={user} onMobileMenuOpen={() => setMobileOpen(true)} />
          <main className="p-3 sm:p-4 md:p-6 overflow-x-hidden max-w-full min-h-[calc(100vh-3.5rem)] sm:min-h-[calc(100vh-4rem)] pb-20 lg:pb-0" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
            <Outlet context={{ user }} />
          </main>
        </div>
        <MobileBottomNav />
        <AIAssistant />
        <TrinityWelcomeModal 
          isOpen={showTrinityWelcome}
          onClose={() => setShowTrinityWelcome(false)} 
          user={user}
          hasIndustryConfig={hasIndustryConfig}
        />
        <HintBubble />
        <AnniversaryReviewModal user={user} />
        {isTrialExpired && <TrialExpiredGate user={user} trial={trialRecord} />}
      </div>
    </UsageMonitor>
  );
}