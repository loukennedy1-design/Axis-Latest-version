import React, { useState } from 'react';
import { CreditCard, Clock, CheckCircle, Loader2, Shield, Zap, Phone, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { PLANS } from '@/lib/pricing';
import { toast } from 'sonner';

const KEY_FEATURES = [
  { icon: Bot, label: 'AI Call Bot — unlimited automated dialing' },
  { icon: Phone, label: 'Full CRM + lead management' },
  { icon: Zap, label: 'AI Agent Tasks & automation' },
  { icon: Shield, label: 'FCC-compliant compliance tools' },
];

export default function TrialExpiredGate({ user, trial }) {
  const [loading, setLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(PLANS[1]?.key || PLANS[0]?.key);

  const handleCheckout = async () => {
    const plan = PLANS.find(p => p.key === selectedPlan);
    if (!plan) return;
    setLoading(true);
    try {
      const response = await base44.functions.invoke('createTrialAndCharge', {
        email: user?.email || '',
        fullName: user?.full_name || '',
        planKey: plan.key,
        planPrice: plan.price,
        isYearly: false,
        discount: 0,
      });
      if (response.data?.checkoutUrl) {
        window.location.href = response.data.checkoutUrl;
      } else {
        toast.error(response.data?.error || 'Could not start checkout. Please try again.');
        setLoading(false);
      }
    } catch {
      toast.error('Checkout failed. Please contact support.');
      setLoading(false);
    }
  };

  const trialEndDate = trial?.trial_end
    ? new Date(trial.trial_end).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : 'recently';

  const selectedPlanObj = PLANS.find(p => p.key === selectedPlan);

  return (
    <div className="fixed inset-0 z-[9999] bg-background/95 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/30 mb-4">
            <Clock className="w-8 h-8 text-amber-500" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Your free trial has ended</h1>
          <p className="text-muted-foreground mt-2">
            Your {trial?.trial_duration_days || ''}-day trial expired on <strong>{trialEndDate}</strong>. Choose a plan to keep all your data and continue using Axis.
          </p>
        </div>

        {/* Features reminder */}
        <div className="grid grid-cols-2 gap-2 mb-6">
          {KEY_FEATURES.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2 p-3 rounded-lg bg-muted/40 border border-border text-sm">
              <Icon className="w-4 h-4 text-primary shrink-0" />
              <span>{label}</span>
            </div>
          ))}
        </div>

        {/* Plan selector */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {PLANS.map(plan => (
            <button
              key={plan.key}
              onClick={() => setSelectedPlan(plan.key)}
              className={`relative rounded-xl border-2 p-4 text-left transition-all ${
                selectedPlan === plan.key
                  ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
                  : 'border-border bg-card hover:border-primary/40'
              }`}
            >
              {plan.highlight && (
                <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap">
                  MOST POPULAR
                </span>
              )}
              {selectedPlan === plan.key && (
                <CheckCircle className="absolute top-3 right-3 w-4 h-4 text-primary" />
              )}
              <p className="font-bold text-sm">{plan.label}</p>
              <p className="text-2xl font-black text-primary mt-1">
                ${plan.price}<span className="text-xs font-normal text-muted-foreground">/mo</span>
              </p>
              <p className="text-xs text-muted-foreground mt-1">{plan.max_leads === 999999 ? 'Unlimited' : plan.max_leads.toLocaleString()} leads</p>
            </button>
          ))}
        </div>

        {/* CTA */}
        <Button
          size="lg"
          className="w-full h-14 text-base font-semibold gap-2"
          onClick={handleCheckout}
          disabled={loading}
        >
          {loading ? (
            <><Loader2 className="w-5 h-5 animate-spin" />Redirecting to checkout...</>
          ) : (
            <><CreditCard className="w-5 h-5" />Subscribe to {selectedPlanObj?.label} — ${selectedPlanObj?.price}/mo</>
          )}
        </Button>

        <p className="text-center text-xs text-muted-foreground mt-3">
          Secured by Square · Cancel anytime · All your data is safe
        </p>
      </div>
    </div>
  );
}