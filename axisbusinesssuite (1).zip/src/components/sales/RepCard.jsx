import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent } from '@/components/ui/card';
import { Pencil, Trash2, Phone, Calendar, Link, Copy, DollarSign, TrendingUp, MapPin, Clock } from 'lucide-react';

const ROLE_COLORS = {
  manager: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  senior_rep: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  rep: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  sdr: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
};

const STATUS_COLORS = {
  active: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  inactive: 'bg-muted text-muted-foreground',
  on_leave: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  probation: 'bg-orange-500/10 text-orange-600 border-orange-500/20',
  terminated: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const PAY_TYPE_LABELS = {
  salary: 'Salary',
  hourly: 'Hourly',
  commission_only: 'Commission Only',
  salary_plus_commission: 'Salary + Commission',
};

export default function RepCard({ rep, calls, appointments, referrals, onEdit, onDelete, onCopyLink }) {
  const repCalls = calls.filter(c => c.called_by === rep.name || c.owner === rep.email);
  const repAppts = appointments.filter(a => a.assigned_to === rep.email);
  const repReferrals = referrals.filter(r => r.rep_id === rep.id || r.tracking_code === rep.tracking_code);
  const approvedReferrals = repReferrals.filter(r => r.commission_status === 'approved');

  const callRate = rep.target_calls_per_day > 0
    ? Math.min(100, Math.round((repCalls.length / (rep.target_calls_per_day * 30)) * 100)) : 0;
  const apptRate = rep.target_appointments_per_week > 0
    ? Math.min(100, Math.round((repAppts.length / (rep.target_appointments_per_week * 4)) * 100)) : 0;

  const totalCommission = approvedReferrals.reduce((s, r) => s + (r.commission_amount || 0), 0);

  const formatPay = () => {
    if (rep.pay_type === 'hourly') return `$${rep.hourly_rate || 0}/hr`;
    if (rep.pay_type === 'commission_only') return `${Math.round((rep.commission_rate || 0.2) * 100)}% commission`;
    if (rep.base_salary) return `$${(rep.base_salary || 0).toLocaleString()}/mo base`;
    return '—';
  };

  const tenure = rep.hire_date
    ? (() => {
        const ms = Date.now() - new Date(rep.hire_date).getTime();
        const days = Math.floor(ms / 86400000);
        if (days < 30) return `${days}d`;
        if (days < 365) return `${Math.floor(days / 30)}mo`;
        return `${(days / 365).toFixed(1)}yr`;
      })()
    : null;

  return (
    <Card className="hover:shadow-lg transition-all border-border/60">
      <CardContent className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 flex items-center justify-center text-primary font-bold text-xl">
              {rep.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <p className="font-semibold leading-tight">{rep.name}</p>
              <p className="text-xs text-muted-foreground">{rep.email}</p>
              {rep.phone && <p className="text-xs text-muted-foreground">{rep.phone}</p>}
            </div>
          </div>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onEdit(rep)}><Pencil className="w-3.5 h-3.5" /></Button>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => onDelete(rep.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
          </div>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          <Badge variant="outline" className={`capitalize text-[10px] ${ROLE_COLORS[rep.role] || ''}`}>{rep.role?.replace(/_/g, ' ')}</Badge>
          <Badge variant="outline" className={`capitalize text-[10px] ${STATUS_COLORS[rep.status] || ''}`}>{rep.status?.replace(/_/g, ' ')}</Badge>
          {tenure && <Badge variant="outline" className="text-[10px]"><Clock className="w-2.5 h-2.5 mr-1" />{tenure}</Badge>}
          {rep.territory && <Badge variant="outline" className="text-[10px]"><MapPin className="w-2.5 h-2.5 mr-1" />{rep.territory}</Badge>}
        </div>

        {/* Pay Info */}
        <div className="bg-muted/40 rounded-lg p-2.5 mb-3 grid grid-cols-2 gap-2 text-xs">
          <div>
            <p className="text-muted-foreground text-[10px] uppercase tracking-wide">Pay Type</p>
            <p className="font-semibold">{PAY_TYPE_LABELS[rep.pay_type] || '—'}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-[10px] uppercase tracking-wide">Base / Rate</p>
            <p className="font-semibold text-emerald-600">{formatPay()}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-[10px] uppercase tracking-wide">Commission Rate</p>
            <p className="font-semibold">{Math.round((rep.commission_rate || 0.2) * 100)}%</p>
          </div>
          <div>
            <p className="text-muted-foreground text-[10px] uppercase tracking-wide">OTE (Annual)</p>
            <p className="font-semibold text-blue-400">{rep.ote ? `$${(rep.ote / 1000).toFixed(0)}k` : '—'}</p>
          </div>
        </div>

        {/* Performance Bars */}
        <div className="space-y-2.5 mb-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground flex items-center gap-1"><Phone className="w-3 h-3" />Calls (30d)</span>
              <span className={`font-semibold ${callRate >= 80 ? 'text-emerald-500' : callRate >= 50 ? 'text-amber-500' : 'text-red-400'}`}>{repCalls.length} / {rep.target_calls_per_day * 30}</span>
            </div>
            <Progress value={callRate} className="h-1.5" />
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground flex items-center gap-1"><Calendar className="w-3 h-3" />Appointments (mo)</span>
              <span className={`font-semibold ${apptRate >= 80 ? 'text-emerald-500' : apptRate >= 50 ? 'text-amber-500' : 'text-red-400'}`}>{repAppts.length} / {rep.target_appointments_per_week * 4}</span>
            </div>
            <Progress value={apptRate} className="h-1.5" />
          </div>
        </div>

        {/* Metrics Row */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs border border-border/50 rounded-lg p-2 mb-3">
          <div>
            <p className="text-muted-foreground text-[10px]">Referrals</p>
            <p className="font-bold text-primary">{repReferrals.length}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-[10px]">Earned</p>
            <p className="font-bold text-emerald-500">${totalCommission.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground text-[10px]">Rev Target</p>
            <p className="font-bold text-amber-400">${((rep.target_revenue_per_month || 0) / 1000).toFixed(0)}k</p>
          </div>
        </div>

        {/* Referral Link */}
        {rep.tracking_code && (
          <div className="flex items-center justify-between text-xs border-t border-border pt-2.5">
            <span className="text-muted-foreground flex items-center gap-1"><Link className="w-3 h-3" /><span className="font-mono font-semibold text-foreground">{rep.tracking_code}</span></span>
            <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-1 px-2" onClick={() => onCopyLink(rep.tracking_code)}>
              <Copy className="w-3 h-3" />Copy Link
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}