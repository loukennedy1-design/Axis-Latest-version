import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';

const generateTrackingCode = (name) => {
  const base = name ? name.replace(/\s+/g, '').toUpperCase().slice(0, 4) : 'REP';
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${base}-${rand}`;
};

export default function RepFormDialog({ open, onOpenChange, form, setForm, editRep, onSave, saving, appUrl }) {
  const f = (key, val) => setForm(prev => ({ ...prev, [key]: val }));
  const num = (key, val) => setForm(prev => ({ ...prev, [key]: parseFloat(val) || 0 }));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg">{editRep ? 'Edit Sales Rep' : 'Add Sales Rep'}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="basic" className="mt-2">
          <TabsList className="w-full">
            <TabsTrigger value="basic" className="flex-1">Basic Info</TabsTrigger>
            <TabsTrigger value="comp" className="flex-1">Compensation</TabsTrigger>
            <TabsTrigger value="targets" className="flex-1">Targets</TabsTrigger>
            <TabsTrigger value="tracking" className="flex-1">Tracking</TabsTrigger>
          </TabsList>

          {/* BASIC INFO */}
          <TabsContent value="basic" className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Full Name *</Label>
                <Input value={form.name} onChange={e => f('name', e.target.value)} placeholder="Jane Smith" />
              </div>
              <div>
                <Label>Email *</Label>
                <Input type="email" value={form.email} onChange={e => f('email', e.target.value)} placeholder="jane@company.com" />
              </div>
              <div>
                <Label>Phone</Label>
                <Input value={form.phone || ''} onChange={e => f('phone', e.target.value)} placeholder="+1 (555) 000-0000" />
              </div>
              <div>
                <Label>Role</Label>
                <Select value={form.role} onValueChange={v => f('role', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="manager">Manager</SelectItem>
                    <SelectItem value="senior_rep">Senior Rep</SelectItem>
                    <SelectItem value="rep">Rep</SelectItem>
                    <SelectItem value="sdr">SDR</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select value={form.status} onValueChange={v => f('status', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="probation">Probation</SelectItem>
                    <SelectItem value="on_leave">On Leave</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="terminated">Terminated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Hire Date</Label>
                <Input type="date" value={form.hire_date || ''} onChange={e => f('hire_date', e.target.value)} />
              </div>
              <div>
                <Label>Territory</Label>
                <Input value={form.territory || ''} onChange={e => f('territory', e.target.value)} placeholder="e.g. Northeast, SMB, SaaS" />
              </div>
              <div className="col-span-2">
                <Label>Zoom User ID (optional)</Label>
                <Input value={form.zoom_user_id || ''} onChange={e => f('zoom_user_id', e.target.value)} placeholder="zoom_user@company.com" />
              </div>
              <div className="col-span-2">
                <Label>Internal Notes</Label>
                <Textarea value={form.notes || ''} onChange={e => f('notes', e.target.value)} placeholder="Any notes about this rep..." rows={2} />
              </div>
            </div>
          </TabsContent>

          {/* COMPENSATION */}
          <TabsContent value="comp" className="space-y-4 mt-4">
            <div className="p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20 text-xs text-emerald-700 dark:text-emerald-400 mb-2">
              💰 Define the rep's pay structure, commission rates, and on-target earnings
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Pay Type</Label>
                <Select value={form.pay_type || 'salary_plus_commission'} onValueChange={v => f('pay_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="salary">Salary Only</SelectItem>
                    <SelectItem value="hourly">Hourly</SelectItem>
                    <SelectItem value="commission_only">Commission Only</SelectItem>
                    <SelectItem value="salary_plus_commission">Salary + Commission</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {(form.pay_type === 'salary' || form.pay_type === 'salary_plus_commission') && (
                <div>
                  <Label>Monthly Base Salary ($)</Label>
                  <Input type="number" value={form.base_salary || ''} onChange={e => num('base_salary', e.target.value)} placeholder="5000" />
                </div>
              )}

              {form.pay_type === 'hourly' && (
                <div>
                  <Label>Hourly Rate ($)</Label>
                  <Input type="number" value={form.hourly_rate || ''} onChange={e => num('hourly_rate', e.target.value)} placeholder="25" />
                </div>
              )}

              <div>
                <Label>Commission Type</Label>
                <Select value={form.commission_type || 'revenue_share'} onValueChange={v => f('commission_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="revenue_share">Revenue Share (%)</SelectItem>
                    <SelectItem value="flat_rate">Flat Rate per Referral</SelectItem>
                    <SelectItem value="per_deal">Per Closed Deal</SelectItem>
                    <SelectItem value="tiered">Tiered Commission</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Commission Rate (%)</Label>
                <Input type="number" step="0.5" value={Math.round((form.commission_rate || 0.2) * 100)} onChange={e => f('commission_rate', (parseFloat(e.target.value) || 0) / 100)} placeholder="20" />
                <p className="text-[10px] text-muted-foreground mt-1">e.g. 20 = 20% of referred revenue</p>
              </div>

              <div>
                <Label>Per-Deal Commission ($)</Label>
                <Input type="number" value={form.commission_per_deal || ''} onChange={e => num('commission_per_deal', e.target.value)} placeholder="500" />
              </div>

              <div>
                <Label>Monthly Draw ($)</Label>
                <Input type="number" value={form.draw_amount || ''} onChange={e => num('draw_amount', e.target.value)} placeholder="0" />
                <p className="text-[10px] text-muted-foreground mt-1">Advance against future commissions</p>
              </div>

              <div>
                <Label>Monthly Bonus Target ($)</Label>
                <Input type="number" value={form.bonus_target || ''} onChange={e => num('bonus_target', e.target.value)} placeholder="1000" />
              </div>

              <div>
                <Label>OTE — Annual On-Target Earnings ($)</Label>
                <Input type="number" value={form.ote || ''} onChange={e => num('ote', e.target.value)} placeholder="80000" />
              </div>

              <div>
                <Label>Monthly Revenue Quota ($)</Label>
                <Input type="number" value={form.quota_monthly || ''} onChange={e => num('quota_monthly', e.target.value)} placeholder="30000" />
              </div>

              <div className="col-span-2">
                <Label>Benefits (comma-separated)</Label>
                <Input
                  value={(() => { try { return JSON.parse(form.benefits || '[]').join(', '); } catch { return form.benefits || ''; } })()}
                  onChange={e => f('benefits', JSON.stringify(e.target.value.split(',').map(s => s.trim()).filter(Boolean)))}
                  placeholder="Health Insurance, 401k, Laptop, Cell Phone Stipend"
                />
              </div>
            </div>
          </TabsContent>

          {/* TARGETS */}
          <TabsContent value="targets" className="space-y-4 mt-4">
            <div className="p-3 rounded-lg bg-blue-500/5 border border-blue-500/20 text-xs text-blue-700 dark:text-blue-400 mb-2">
              🎯 Set daily, weekly, and monthly performance targets for this rep
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Daily Call Target</Label>
                <Input type="number" value={form.target_calls_per_day || 50} onChange={e => num('target_calls_per_day', e.target.value)} />
                <p className="text-[10px] text-muted-foreground mt-1">Calls per day goal</p>
              </div>
              <div>
                <Label>Weekly Appointment Target</Label>
                <Input type="number" value={form.target_appointments_per_week || 10} onChange={e => num('target_appointments_per_week', e.target.value)} />
                <p className="text-[10px] text-muted-foreground mt-1">Booked meetings per week</p>
              </div>
              <div className="col-span-2">
                <Label>Monthly Revenue Target ($)</Label>
                <Input type="number" value={form.target_revenue_per_month || 10000} onChange={e => num('target_revenue_per_month', e.target.value)} />
              </div>
            </div>
          </TabsContent>

          {/* TRACKING */}
          <TabsContent value="tracking" className="space-y-4 mt-4">
            <div className="p-3 rounded-lg bg-purple-500/5 border border-purple-500/20 text-xs text-purple-700 dark:text-purple-400 mb-2">
              🔗 Unique referral tracking link — share this with prospects to attribute signups to this rep
            </div>
            <div>
              <Label>Tracking Code</Label>
              <div className="flex gap-2">
                <Input value={form.tracking_code || ''} onChange={e => f('tracking_code', e.target.value)} placeholder="Auto-generated on save" />
                <Button type="button" variant="outline" onClick={() => f('tracking_code', generateTrackingCode(form.name))}>Generate</Button>
              </div>
              {form.tracking_code && (
                <div className="mt-2 p-2.5 bg-muted/50 rounded-lg border text-xs font-mono break-all">
                  {appUrl}/pricing?ref={form.tracking_code}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 mt-4 pt-4 border-t border-border">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={onSave} disabled={!form.name || !form.email || saving}>
            {saving ? 'Saving...' : editRep ? 'Update Rep' : 'Add Rep'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}