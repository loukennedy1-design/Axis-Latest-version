import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Bot, X, Send, Minimize2, Maximize2, Sparkles, RefreshCw, Wrench, CheckCircle2, AlertCircle } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

// ─── System fixes Trinity AI can perform ────────────────────────────────────

const SYSTEM_ACTIONS = {
  fix_lead_consent: {
    label: 'Fix lead consent',
    description: 'Sets consent_given=true for all leads with status=new that have no consent',
    run: async () => {
      const leads = await base44.entities.Lead.filter({ consent_given: false, status: 'new' });
      let fixed = 0;
      for (const lead of leads) {
        await base44.entities.Lead.update(lead.id, { consent_given: true, consent_date: new Date().toISOString() });
        fixed++;
      }
      return `Fixed consent for ${fixed} leads.`;
    }
  },
  reset_stuck_leads: {
    label: 'Reset stuck leads',
    description: 'Resets leads stuck in "contacted" back to "new" so the bot can retry them',
    run: async () => {
      const leads = await base44.entities.Lead.filter({ status: 'contacted' });
      let reset = 0;
      for (const lead of leads) {
        await base44.entities.Lead.update(lead.id, { status: 'new', call_attempts: 0 });
        reset++;
      }
      return `Reset ${reset} stuck leads back to "new".`;
    }
  },
  clear_invalid_leads: {
    label: 'Archive invalid leads',
    description: 'Moves leads with status=invalid to do_not_call to clean up the queue',
    run: async () => {
      const leads = await base44.entities.Lead.filter({ status: 'invalid' });
      let cleared = 0;
      for (const lead of leads) {
        await base44.entities.Lead.update(lead.id, { status: 'do_not_call' });
        cleared++;
      }
      return `Archived ${cleared} invalid leads.`;
    }
  },
  fix_high_attempt_leads: {
    label: 'Reset over-attempted leads',
    description: 'Resets call_attempts=0 on new leads that hit the attempt ceiling',
    run: async () => {
      const leads = await base44.entities.Lead.filter({ status: 'new' });
      const stuck = leads.filter(l => l.call_attempts >= 3);
      let fixed = 0;
      for (const lead of stuck) {
        await base44.entities.Lead.update(lead.id, { call_attempts: 0 });
        fixed++;
      }
      return `Reset call attempts for ${fixed} leads.`;
    }
  },
  fix_dnc_leads: {
    label: 'Sync DNC to leads',
    description: 'Marks leads whose phone is on the DNC list as do_not_call',
    run: async () => {
      const [leads, dncEntries] = await Promise.all([
        base44.entities.Lead.list(),
        base44.entities.DNCEntry.list()
      ]);
      const dncNumbers = new Set(dncEntries.map(d => d.phone?.replace(/\D/g, '')));
      let synced = 0;
      for (const lead of leads) {
        const clean = lead.phone?.replace(/\D/g, '');
        if (clean && dncNumbers.has(clean) && lead.status !== 'do_not_call') {
          await base44.entities.Lead.update(lead.id, { status: 'do_not_call' });
          synced++;
        }
      }
      return `Synced DNC — marked ${synced} leads as do_not_call.`;
    }
  },
  fix_unassigned_leads: {
    label: 'Report unassigned leads',
    description: 'Lists how many leads have no assigned AE',
    run: async () => {
      const leads = await base44.entities.Lead.list();
      const unassigned = leads.filter(l => !l.assigned_to);
      return `Found ${unassigned.length} unassigned leads out of ${leads.length} total. Go to Leads → Bulk Actions → Assign to AE to fix.`;
    }
  },
  check_expired_trials: {
    label: 'Check expired trials',
    description: 'Reports how many active trials have passed their end date',
    run: async () => {
      const trials = await base44.entities.TrialInvite.filter({ status: 'active' });
      const now = new Date();
      const expired = trials.filter(t => t.trial_end && new Date(t.trial_end) <= now);
      const expiringSoon = trials.filter(t => {
        if (!t.trial_end) return false;
        const daysLeft = (new Date(t.trial_end) - now) / (1000 * 60 * 60 * 24);
        return daysLeft > 0 && daysLeft <= 3;
      });
      return `Found ${expired.length} expired trial(s) needing billing and ${expiringSoon.length} expiring within 3 days. Go to Super Admin → Movement tab to review.`;
    }
  },
  create_cs_ticket: {
    label: 'Create support ticket',
    description: 'Creates a customer service ticket and routes it to the CS team for AI triage and response',
    run: async (context = {}) => {
      const user = await base44.auth.me().catch(() => null);
      const inquiry = context.inquiry || context.message || 'Customer needs assistance';
      const ticketId = `CS-${Date.now().toString(36).toUpperCase()}`;
      await base44.entities.CSTicket.create({
        ticket_id: ticketId,
        subject: inquiry.slice(0, 80),
        customer_email: user?.email || 'unknown',
        customer_name: user?.full_name || user?.email || 'Customer',
        inquiry,
        source: 'trinity_chat',
        status: 'new',
        messages: JSON.stringify([{ sender: 'customer', sender_email: user?.email || '', body: inquiry, timestamp: new Date().toISOString() }])
      });
      return `Support ticket ${ticketId} created. Our CS team is reviewing your inquiry now — the AI will attempt to resolve it automatically, and if it can't, a live agent will pick it up from the CS Dashboard.`;
    }
  },
  check_system_health: {
    label: 'Check system health',
    description: 'Quick health check: lead queue, DNC, unread SMS, failed calls',
    run: async () => {
      const [leads, callLogs, dnc] = await Promise.all([
        base44.entities.Lead.list(),
        base44.entities.CallLog.filter({ status: 'failed' }),
        base44.entities.DNCEntry.list(),
      ]);
      const newLeads = leads.filter(l => l.status === 'new').length;
      const noConsent = leads.filter(l => !l.consent_given && l.status === 'new').length;
      const lines = [
        `📋 Total leads: ${leads.length} (${newLeads} in queue)`,
        noConsent > 0 ? `⚠️ ${noConsent} leads missing consent` : '✅ All queued leads have consent',
        `📵 DNC entries: ${dnc.length}`,
        callLogs.length > 0 ? `⚠️ ${callLogs.length} failed calls recently` : '✅ No recent failed calls',
      ];
      return lines.join('\n');
    }
  },
};

// ─── Keyword → action mapping ──────────────────────────────────────────────

function detectIntentedAction(text) {
  const t = text.toLowerCase();
  if ((t.includes('consent') && (t.includes('fix') || t.includes('grant') || t.includes('not calling'))) ||
      (t.includes('bot') && t.includes('not call'))) return 'fix_lead_consent';
  if ((t.includes('stuck') || t.includes('contacted') || t.includes('retry')) && (t.includes('lead') || t.includes('bot'))) return 'reset_stuck_leads';
  if (t.includes('invalid') && (t.includes('clean') || t.includes('remove') || t.includes('archive'))) return 'clear_invalid_leads';
  if (t.includes('attempt') && (t.includes('reset') || t.includes('fix') || t.includes('too many'))) return 'fix_high_attempt_leads';
  if (t.includes('dnc') && (t.includes('sync') || t.includes('fix') || t.includes('match'))) return 'fix_dnc_leads';
  if (t.includes('unassigned') || (t.includes('no') && t.includes('assign'))) return 'fix_unassigned_leads';
  if ((t.includes('trial') && (t.includes('expired') || t.includes('expir'))) || t.includes('billing check') || t.includes('overdue')) return 'check_expired_trials';
  if (t.includes('health') || (t.includes('system') && t.includes('check')) || t.includes('everything ok')) return 'check_system_health';
  if (t.includes('customer support') || t.includes('need help') || t.includes('contact support') ||
      t.includes('open a ticket') || t.includes('talk to a human') || t.includes('speak to someone') ||
      t.includes('talk to support') || t.includes('support ticket') || t.includes('live agent')) return 'create_cs_ticket';
  return null;
}

// ─── System prompt ─────────────────────────────────────────────────────────

const SYSTEM_PROMPT = `You are Trinity AI, the built-in AI assistant for the AXIS Business Suite platform. Your tone is corporate professional — clear, direct, and genuinely helpful. You speak the way a knowledgeable colleague would: confident but approachable, warm but never casual. You are easy to talk to and easy to understand. You avoid slang, jargon, and emojis. You get straight to the point while remaining personable and respectful.

You have deep knowledge of every feature in the platform AND you can take real-time corrective actions to fix system issues.

REAL-TIME FIX CAPABILITIES — When users report these issues, tell them you're triggering the fix AND explain what you're doing:
- "fix_lead_consent" → fixes leads with consent missing so the bot can call them
- "reset_stuck_leads" → resets leads stuck in 'contacted' status back to 'new'
- "clear_invalid_leads" → archives invalid leads to clean up the queue
- "fix_high_attempt_leads" → resets call_attempts counter on leads that hit the ceiling
- "fix_dnc_leads" → syncs DNC registry to leads, marking blocked numbers
- "fix_unassigned_leads" → reports how many leads have no AE assigned
- "check_expired_trials" → reports expired/expiring-soon trials needing billing
- "check_system_health" → quick health report: leads, consent, DNC, failed calls

When you detect a user has a fixable problem, proactively offer to run the fix. Be specific about what you'll change. After a fix runs, confirm what was repaired.

The platform includes:
- CS Dashboard (live agent monitoring of customer service tickets)
- Customer Service Team (AI-triaged ticket routing — Trinity creates tickets, AI auto-responds or escalates to live agents)

- AI Call Bot (automated outbound calling with scripts, scheduling, compliance)
- Lead CRM (lead management, statuses, bulk actions, consent tracking)
- CSV Import & Import Wizard (uploading lead lists)
- AI Lead Generator (finding leads from Google Maps, web search)
- DNC Registry & Compliance (TCPA/FCC compliance, Do Not Call lists)
- Appointments & Calendly Integration (automated booking)
- Nurture Workflows (automated follow-up sequences)
- AI Lead Scoring (0-100 scoring, hot/warm/cold tiers)
- Coaching Hub (AI call grading on 5 dimensions)
- Sales Team & AE Management (reps, targets, leaderboard)
- AE Onboarding (14-step onboarding tracker)
- Zoom Scheduler (video interview scheduling)
- Recruitment Module (Indeed integration, candidate pipeline, hire flow)
- Email Client (compose, send, thread tracking)
- AE Chat (internal team messaging)
- SMS Inbox (Twilio-powered two-way SMS)
- Social Media AI (content generation, scheduling, ad manager)
- Human Resources Suite (employees, time-off, payroll, performance reviews, documents)
- Dashboard & Analytics (real-time KPIs, charts, team tracker)
- Settings (company info, calling schedule, bot config, Calendly, integrations)
- API Center (100+ third-party integrations)
- Subscription Management (plans, billing)
- Super Admin Panel (system controls, white label, Movement program)

User roles:
- Admin/Territory Owner: full access to everything
- AE/User: only sees their personal dashboard with assigned leads, their calls, appointments, tasks, onboarding

Common troubleshooting:
- Bot not calling: check consent_given=true on leads, status='new', within calling schedule hours
- Calendly not booking: verify PAT token, click 'Fetch My Info' after saving
- Leads not showing for AE: check assigned_to field matches their exact email
- Import issues: CSV needs at least first_name and phone columns
- DNC not working: enable 'Auto-add to DNC' in Settings > Bot tab

Be helpful, clear, and specific. Give step-by-step instructions when explaining how to do something. Keep responses concise and actionable. When users describe an issue, ask clarifying questions if needed. Format responses with **bold** for key terms and use bullet lists for steps. Always reference where to find things in the platform (e.g., "Go to Settings → Bot tab").`;

// ─── Sub-components ────────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 px-3 py-2">
      <span className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '0ms' }} />
      <span className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '150ms' }} />
      <span className="w-2 h-2 rounded-full bg-primary/60 animate-bounce" style={{ animationDelay: '300ms' }} />
    </div>
  );
}

function ActionResult({ result }) {
  const isError = result?.error;
  return (
    <div className={`flex items-start gap-2 px-3 py-2 rounded-xl text-xs border ${isError ? 'bg-red-500/10 border-red-500/20 text-red-700' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-700'}`}>
      {isError ? <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> : <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5" />}
      <span>{result?.message}</span>
    </div>
  );
}

function Message({ msg }) {
  const isUser = msg.role === 'user';
  if (msg.role === 'action_result') return <ActionResult result={msg} />;

  return (
    <div className={`flex gap-2 ${isUser ? 'justify-end' : 'justify-start'}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
        </div>
      )}
      <div className={`max-w-[82%] rounded-2xl px-3 py-2.5 text-sm leading-relaxed ${
        isUser
          ? 'bg-primary text-primary-foreground rounded-br-sm'
          : 'bg-muted text-foreground rounded-bl-sm'
      }`}>
        {isUser ? (
          <p>{msg.content}</p>
        ) : (
          <ReactMarkdown
            className="prose prose-sm dark:prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
            components={{
              p: ({ children }) => <p className="my-1 leading-relaxed">{children}</p>,
              ul: ({ children }) => <ul className="my-1 ml-3 list-disc space-y-0.5">{children}</ul>,
              ol: ({ children }) => <ol className="my-1 ml-3 list-decimal space-y-0.5">{children}</ol>,
              li: ({ children }) => <li className="text-sm">{children}</li>,
              strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
              code: ({ children }) => <code className="bg-background/60 px-1 py-0.5 rounded text-xs font-mono">{children}</code>,
            }}
          >
            {msg.content}
          </ReactMarkdown>
        )}
      </div>
    </div>
  );
}

const QUICK_PROMPTS = [
  "My bot isn't calling leads — fix it!",
  "Reset my stuck leads",
  "Run a system health check",
  "I need customer support",
  "Check for expired trials",
  "Sync DNC list to leads",
];

// ─── Main Component ────────────────────────────────────────────────────────

const TRINITY_LOGO_URL = "https://media.base44.com/images/public/69ef71210cace64a00bec165/e524896ce_generated_image.png";

export default function AIAssistant() {
  const [open, setOpen] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "Hi, I'm **Trinity AI**, your AI assistant for the AXIS Business Suite.\n\nI can answer questions and **fix system issues in real time** — resetting stuck leads, granting consent, syncing your DNC list, and more. Tell me what you need and I'll take care of it."
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);
  const location = useLocation();

  // Preload the Trinity logo so it's cached and renders instantly
  useEffect(() => {
    const img = new Image();
    img.src = TRINITY_LOGO_URL;
  }, []);

  useEffect(() => {
    if (open) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
      inputRef.current?.focus();
    }
  }, [messages, open]);

  useEffect(() => {
    if (!open && messages.length > 1) setHasNewMessage(true);
  }, [messages]);

  useEffect(() => {
    if (open) setHasNewMessage(false);
  }, [open]);

  const runAction = async (actionKey, context = {}) => {
    const action = SYSTEM_ACTIONS[actionKey];
    if (!action) return;

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `Running **${action.label}** now — one moment.`
    }]);
    setLoading(true);

    try {
      const result = await action.run(context);
      setMessages(prev => [...prev, { role: 'action_result', message: `✅ ${result}`, error: false }]);
      toast.success(`Fix applied: ${result}`);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'action_result', message: `❌ Ran into a snag: ${err.message}`, error: true }]);
      toast.error('Fix failed — see chat for details');
    }
    setLoading(false);
  };

  const sendMessage = async (text) => {
    const userText = (text || input).trim();
    if (!userText || loading) return;

    const currentPage = location.pathname;
    const contextNote = `[User is currently on page: ${currentPage}]`;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userText }]);
    setLoading(true);

    // Detect if the user wants a real-time fix
    const actionKey = detectIntentedAction(userText);

    const conversationHistory = messages
      .filter(m => m.role !== 'action_result')
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
      .join('\n\n');

    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `${SYSTEM_PROMPT}\n\n---\nConversation so far:\n${conversationHistory}\n\n${contextNote}\n\nUser: ${userText}\n\n${actionKey ? `IMPORTANT: The user's message matches the "${actionKey}" fix. Acknowledge you're running it automatically and explain what it will do. Then end with a natural message.` : ''}\n\nAssistant:`,
        model: 'gpt_5_mini'
      });

      const reply = typeof response === 'string' ? response : response?.text || response?.content || JSON.stringify(response);
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);

      // Auto-run the detected action after the AI replies
      if (actionKey) {
        const actionContext = actionKey === 'create_cs_ticket' ? { inquiry: userText } : {};
        setTimeout(() => runAction(actionKey, actionContext), 600);
        return; // loading will be re-managed by runAction
      }
    } catch (err) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: "Something went wrong on my end. Please try again in a moment."
      }]);
    }
    setLoading(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const resetChat = () => {
    setMessages([{
      role: 'assistant',
      content: "Fresh start. I'm Trinity AI, ready to help with any questions or system fixes. What can I do for you?"
    }]);
  };

  return (
    <>
      {/* Floating button */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-black shadow-2xl shadow-black/70 flex items-center justify-center hover:scale-105 transition-transform ring-[3px] ring-red-600 p-[2px]"
          title="Chat with Trinity AI"
        >
          <div className="w-full h-full rounded-full bg-white p-[2px] flex items-center justify-center">
            <img
              src={TRINITY_LOGO_URL}
              alt="Trinity AI"
              className="w-full h-full object-contain rounded-full"
            />
          </div>
          {hasNewMessage && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse" />
          )}
        </button>
      )}

      {/* Chat window */}
      {open && (
        <div
          className={`fixed z-50 bg-background border border-border rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-200 ${
            minimized
              ? 'bottom-4 right-4 h-14 w-72'
              : 'bottom-0 right-0 left-0 h-[75vh] rounded-b-none sm:bottom-6 sm:right-6 sm:left-auto sm:h-[560px] sm:w-[390px] sm:rounded-2xl'
          }`}
        >
          {/* Header */}
          <div className="flex items-center gap-2.5 px-4 h-14 bg-primary text-primary-foreground shrink-0 rounded-t-2xl">
            <div className="w-8 h-8 rounded-full overflow-hidden bg-white/10 flex items-center justify-center shrink-0">
              <img
                src={TRINITY_LOGO_URL}
                alt="Trinity AI"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm leading-none">TRINITY AI</p>
              <p className="text-[10px] text-white/70 mt-0.5 leading-none flex items-center gap-1">
                <Wrench className="w-2.5 h-2.5" /> AI Assistant
              </p>
            </div>
            <div className="flex items-center gap-1">
              <button onClick={resetChat} title="Clear chat" className="p-1.5 rounded hover:bg-white/20 transition-colors">
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => setMinimized(m => !m)} className="p-1.5 rounded hover:bg-white/20 transition-colors">
                {minimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
              </button>
              <button onClick={() => setOpen(false)} className="p-1.5 rounded hover:bg-white/20 transition-colors">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {!minimized && (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
                {messages.map((msg, i) => <Message key={i} msg={msg} />)}
                {loading && (
                  <div className="flex gap-2 justify-start">
                    <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                      <Sparkles className="w-3.5 h-3.5 text-primary animate-pulse" />
                    </div>
                    <div className="bg-muted rounded-2xl rounded-bl-sm">
                      <TypingIndicator />
                    </div>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>

              {/* Quick prompts — show only at start */}
              {messages.length <= 1 && (
                <div className="px-3 pb-2 flex flex-wrap gap-1.5">
                  {QUICK_PROMPTS.map((p, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(p)}
                      className="text-xs px-2.5 py-1.5 rounded-full border border-border bg-muted hover:bg-primary/10 hover:border-primary/30 hover:text-primary transition-colors text-muted-foreground leading-none"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              )}

              {/* Input */}
              <div className="px-3 pb-3 pt-1 border-t border-border shrink-0">
                <div className="flex gap-2 items-end">
                  <textarea
                    ref={inputRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={handleKeyDown}
                    placeholder="Ask Trinity AI..."
                    rows={1}
                    className="flex-1 resize-none bg-muted rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground leading-relaxed max-h-28 overflow-y-auto"
                    style={{ minHeight: '40px' }}
                    disabled={loading}
                  />
                  <Button
                    size="icon"
                    onClick={() => sendMessage()}
                    disabled={!input.trim() || loading}
                    className="h-10 w-10 rounded-xl shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1.5 text-center">Trinity AI · Enter to send</p>
              </div>
            </>
          )}
        </div>
      )}
    </>
  );
}