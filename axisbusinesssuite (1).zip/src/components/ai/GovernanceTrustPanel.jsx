import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle2, AlertTriangle, Info, FileText, Flag, Download, Eye } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export default function GovernanceTrustPanel() {
  const [selectedCheck, setSelectedCheck] = useState(null);
  const queryClient = useQueryClient();

  const { data: status, isLoading } = useQuery({
    queryKey: ['governance-status'],
    queryFn: async () => {
      const res = await base44.functions.invoke('aiGovernanceTrustLayer', { action: 'get_status' });
      return res.data;
    },
  });

  const complianceMutation = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke('aiGovernanceTrustLayer', { action: 'compliance_check' });
      return res.data;
    },
    onSuccess: () => {
      toast.success('Compliance check completed');
      queryClient.invalidateQueries({ queryKey: ['governance-status'] });
    },
  });

  const exportMutation = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke('aiGovernanceTrustLayer', { action: 'export_governance_report' });
      return res.data;
    },
    onSuccess: (data) => {
      toast.success('Governance report exported');
    },
  });

  if (isLoading) {
    return <div className="flex items-center justify-center p-8"><div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" /></div>;
  }

  const overview = status?.overview || {};
  const checks = status?.compliance_checks || [];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'passed': return <CheckCircle2 className="w-4 h-4 text-emerald-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-amber-500" />;
      case 'failed': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <Info className="w-4 h-4 text-muted-foreground" />;
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      passed: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
      warning: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
      failed: 'bg-red-500/10 text-red-500 border-red-500/20',
      info: 'bg-muted text-muted-foreground border-border',
    };
    return colors[status] || colors.info;
  };

  return (
    <div className="space-y-4">
      {/* Header Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-500" />
              <div>
                <p className="text-xs text-muted-foreground">Compliance Rate</p>
                <p className="text-lg font-bold">{overview.compliance_rate || 100}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-blue-500/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">Audit Entries</p>
                <p className="text-lg font-bold">{overview.audit_trail_entries || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className={overview.eu_ai_act_compliant ? 'bg-green-500/5 border-green-500/20' : 'bg-amber-500/5 border-amber-500/20'}>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className={`w-4 h-4 ${overview.eu_ai_act_compliant ? 'text-green-500' : 'text-amber-500'}`} />
              <div>
                <p className="text-xs text-muted-foreground">EU AI Act</p>
                <p className="text-sm font-bold">{overview.eu_ai_act_compliant ? 'Compliant' : 'Review Needed'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className={overview.gdpr_compliant ? 'bg-green-500/5 border-green-500/20' : 'bg-amber-500/5 border-amber-500/20'}>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Shield className={`w-4 h-4 ${overview.gdpr_compliant ? 'text-green-500' : 'text-amber-500'}`} />
              <div>
                <p className="text-xs text-muted-foreground">GDPR</p>
                <p className="text-sm font-bold">{overview.gdpr_compliant ? 'Compliant' : 'Review Needed'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Compliance Checks */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" />
              AI Governance & Transparency Checks
            </CardTitle>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs gap-1"
                onClick={() => complianceMutation.mutate()}
              >
                <Eye className="w-3 h-3" />
                Run Check
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs gap-1"
                onClick={() => exportMutation.mutate()}
              >
                <Download className="w-3 h-3" />
                Export Report
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {checks.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">No compliance checks performed yet</p>
            ) : (
              checks.map((check, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-lg border bg-muted/20 cursor-pointer hover:bg-muted/40 transition-colors"
                  onClick={() => setSelectedCheck(check)}
                >
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {getStatusIcon(check.status)}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{check.check_name}</p>
                      <p className="text-xs text-muted-foreground truncate">{check.details}</p>
                    </div>
                  </div>
                  <Badge className={`text-[10px] px-2 py-0 ${getStatusBadge(check.status)}`}>
                    {check.status}
                  </Badge>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Available Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Governance Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {overview.available_actions?.map((action) => (
              <Badge key={action} variant="outline" className="text-[10px] px-2 py-1 bg-primary/5 text-primary border-primary/20">
                {action.replace(/_/g, ' ')}
              </Badge>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
            <Info className="w-3 h-3" />
            All AI decisions are logged and explainable for EU AI Act compliance
          </p>
        </CardContent>
      </Card>
    </div>
  );
}