import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Users, MessageSquare, Phone, Video, FileText, Search, 
  Clock, TrendingUp, Link2, Brain, Eye, Share2
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

const SOURCE_TYPES = [
  { id: 'slack', label: 'Slack', icon: MessageSquare, color: 'text-purple-500' },
  { id: 'email', label: 'Email', icon: FileText, color: 'text-blue-500' },
  { id: 'calls', label: 'Calls', icon: Phone, color: 'text-green-500' },
  { id: 'meetings', label: 'Meetings', icon: Video, color: 'text-orange-500' },
  { id: 'documents', label: 'Documents', icon: FileText, color: 'text-cyan-500' },
];

export default function DealKnowledgeGraph() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAccount, setSelectedAccount] = useState(null);
  const queryClient = useQueryClient();

  const { data: status, isLoading } = useQuery({
    queryKey: ['knowledge-graph-status'],
    queryFn: async () => {
      const res = await base44.functions.invoke('dealKnowledgeGraph', { action: 'get_status' });
      return res.data;
    },
  });

  const searchMutation = useMutation({
    mutationFn: async (query) => {
      const res = await base44.functions.invoke('dealKnowledgeGraph', {
        action: 'search_knowledge_graph',
        query,
      });
      return res.data;
    },
    onSuccess: (data) => {
      toast.success(`Found ${data.results?.length || 0} relevant items`);
    },
  });

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    searchMutation.mutate(searchQuery);
  };

  if (isLoading) {
    return <div className="flex items-center justify-center p-8"><div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" /></div>;
  }

  const overview = status?.overview || {};

  return (
    <div className="space-y-4">
      {/* Header Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-blue-500/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">Active Deals</p>
                <p className="text-lg font-bold">{overview.active_deals || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-purple-500/5 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-purple-500" />
              <div>
                <p className="text-xs text-muted-foreground">Knowledge Nodes</p>
                <p className="text-lg font-bold">{overview.knowledge_graph_nodes || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-500/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-green-500" />
              <div>
                <p className="text-xs text-muted-foreground">Reconstruction Time</p>
                <p className="text-lg font-bold">{overview.avg_context_reconstruction_time_seconds || 2.3}s</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-emerald-500" />
              <div>
                <p className="text-xs text-muted-foreground">Documents</p>
                <p className="text-lg font-bold">{overview.total_documents || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search Bar */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Search className="w-4 h-4 text-primary" />
            Cross-Platform Deal Context Search
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Search across Slack, email, calls, meetings, documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1"
            />
            <Button onClick={handleSearch} className="gap-2">
              <Search className="w-4 h-4" />
              Search
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            🔍 Search reconstructs full deal context from all platforms in seconds
          </p>
        </CardContent>
      </Card>

      {/* Source Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Knowledge Sources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {SOURCE_TYPES.map((source) => {
              const Icon = source.icon;
              const count = overview.cross_platform_sources?.[source.id] || 0;
              return (
                <div
                  key={source.id}
                  className="p-3 rounded-lg border bg-muted/20 text-center"
                >
                  <Icon className={`w-5 h-5 ${source.color} mx-auto mb-1`} />
                  <p className="text-xs font-semibold mb-0.5">{source.label}</p>
                  <p className="text-lg font-bold text-muted-foreground">{count}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Available Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Knowledge Graph Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {overview.available_actions?.map((action) => (
              <Badge key={action} variant="outline" className="text-[10px] px-2 py-1 bg-primary/5 text-primary border-primary/20">
                {action.replace(/_/g, ' ')}
              </Badge>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-3 flex items-center gap-1">
            <Link2 className="w-3 h-3" />
            Eliminates 6-week ramp time → new hires get full context in 5 minutes
          </p>
        </CardContent>
      </Card>
    </div>
  );
}