import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Activity, Zap, TrendingUp, AlertTriangle, CheckCircle2, Clock, Target, Eye } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

const SIGNAL_TYPES = [
  { id: 'pricing_page_visit', label: 'Pricing Page Visit', icon: Eye, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  { id: 'demo_request', label: 'Demo Request', icon: Zap, color: 'text-green-500', bg: 'bg-green-500/10' },
  { id: 'competitor_mention', label: 'Competitor Mention', icon: AlertTriangle, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  { id: 'funding_event', label: 'Funding Event', icon: TrendingUp, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
  { id: 'job_change', label: 'Job Change', icon: Activity, color: 'text-purple-500', bg: 'bg-purple-500/10' },
  { id: 'tech_stack_change', label: 'Tech Stack Change', icon: Target, color: 'text-cyan-500', bg: 'bg-cyan-500/10' },
];

export default function SignalExecutionPanel() {
  const [selectedSignal, setSelectedSignal] = useState(null);
  const queryClient = useQueryClient();

  const { data: status, isLoading } = useQuery({
    queryKey: ['signal-execution-status'],
    queryFn: async () => {
      const res = await base44.functions.invoke('signalToExecutionEngine', { action: 'get_status' });
      return res.data;
    },
  });

  const detectSignalMutation = useMutation({
    mutationFn: async (signalData) => {
      const res = await base44.functions.invoke('signalToExecutionEngine', {
        action: 'detect_signal',
        ...signalData,
      });
      return res.data;
    },
    onSuccess: () => {
      toast.success('Signal detected and autonomous action triggered!');
      queryClient.invalidateQueries({ queryKey: ['signal-execution-status'] });
    },
    onError: (error) => {
      toast.error(`Failed to detect signal: ${error.message}`);
    },
  });

  const handleSimulateSignal = (signalType) => {
    detectSignalMutation.mutate({
      signal_type: signalType,
      lead_id: `lead_${Date.now()}`,
      signal_data: {
        confidence: Math.floor(Math.random() * 30) + 70,
        urgency: ['low', 'medium', 'high'][Math.floor(Math.random() * 3)],
        description: `Simulated ${signalType.replace(/_/g, ' ')} detected`,
      },
    });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center p-8"><div className="animate-spin w-6 h-6 border-2 border-primary border-t-transparent rounded-full" /></div>;
  }

  const overview = status?.overview || {};

  return (
    <div className="space-y-4">
      {/* Header Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className="bg-blue-500/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">Total Signals</p>
                <p className="text-lg font-bold">{overview.total_signals_detected || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-500/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-green-500" />
              <div>
                <p className="text-xs text-muted-foreground">Active Signals</p>
                <p className="text-lg font-bold">{overview.active_signals || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-purple-500/5 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-purple-500" />
              <div>
                <p className="text-xs text-muted-foreground">Avg Response</p>
                <p className="text-lg font-bold">{overview.avg_response_time_minutes || 15}m</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <div>
                <p className="text-xs text-muted-foreground">Actions Active</p>
                <p className="text-lg font-bold">{overview.autonomous_actions_active || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Signal Types */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Signal Detection & Autonomous Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {SIGNAL_TYPES.map((signal) => {
              const Icon = signal.icon;
              const count = overview.signal_types?.[signal.id] || 0;
              return (
                <div
                  key={signal.id}
                  className={`p-4 rounded-xl border ${signal.bg} border-current/20 cursor-pointer hover:opacity-80 transition-opacity`}
                  onClick={() => setSelectedSignal(signal)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Icon className={`w-5 h-5 ${signal.color}`} />
                    <Badge className="text-[10px] px-1.5 py-0 bg-muted text-muted-foreground border border-border">
                      {count} detected
                    </Badge>
                  </div>
                  <p className="text-sm font-semibold mb-1">{signal.label}</p>
                  <p className="text-xs text-muted-foreground mb-3">
                    {count > 0 ? `${count} signals detected` : 'No signals yet'}
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full h-7 text-xs"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSimulateSignal(signal.id);
                    }}
                  >
                    Simulate Signal
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Available Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Autonomous Actions Available</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {overview.available_actions?.map((action) => (
              <Badge key={action} variant="outline" className="text-[10px] px-2 py-1 bg-primary/5 text-primary border-primary/20">
                {action.replace(/_/g, ' ')}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}