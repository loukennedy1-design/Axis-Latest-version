import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Send, Loader2, Clock, CheckCircle2, XCircle, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';

const PLATFORMS = [
  { id: 'all', label: 'All Platforms', icon: '📢' },
  { id: 'instagram', label: 'Instagram', icon: '📸' },
  { id: 'linkedin', label: 'LinkedIn', icon: '💼' },
  { id: 'facebook', label: 'Facebook', icon: '👍' },
  { id: 'tiktok', label: 'TikTok', icon: '🎵' },
];

const STATUS_ICONS = {
  scheduled: <Clock className="w-3.5 h-3.5 text-amber-400" />,
  publishing: <Loader2 className="w-3.5 h-3.5 text-blue-400 animate-spin" />,
  published: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />,
  failed: <XCircle className="w-3.5 h-3.5 text-red-400" />,
};

function getMinDatetime() {
  const d = new Date();
  d.setMinutes(d.getMinutes() + 30);
  d.setMinutes(0);
  return d.toISOString().slice(0, 16);
}

export default function ScheduleVideoPost({ generatedScript, videoClips, audioUrl, videoType, topic }) {
  const [scheduling, setScheduling] = useState(false);
  const [platform, setPlatform] = useState('all');
  const [scheduledTime, setScheduledTime] = useState('');
  const [caption, setCaption] = useState('');
  const [hashtags, setHashtags] = useState('');
  const [scheduledPosts, setScheduledPosts] = useState([]);
  const [loadingPosts, setLoadingPosts] = useState(false);
  const [showExisting, setShowExisting] = useState(false);

  useEffect(() => {
    if (generatedScript) {
      const parts = [];
      if (generatedScript.hook) parts.push(generatedScript.hook);
      if (generatedScript.cta) parts.push(generatedScript.cta);
      setCaption(parts.join('\n\n') || generatedScript.title || topic);
      setHashtags(generatedScript.hashtags || '');
    }
  }, [generatedScript, topic]);

  const fetchScheduledPosts = async () => {
    setLoadingPosts(true);
    try {
      const res = await base44.functions.invoke('socialIntegrationEngine', {
        action: 'get_scheduled_video_posts',
      });
      setScheduledPosts(res.data?.posts || []);
    } catch (_) { /* silent fail */ }
    setLoadingPosts(false);
  };

  useEffect(() => {
    fetchScheduledPosts();
  }, []);

  const handleSchedule = async () => {
    if (!caption.trim() || !scheduledTime) {
      toast.error('Please add a caption and select a date/time');
      return;
    }
    if (videoClips.length === 0) {
      toast.error('Generate your video first before scheduling');
      return;
    }

    setScheduling(true);
    try {
      const res = await base44.functions.invoke('socialIntegrationEngine', {
        action: 'schedule_video_post',
        platform,
        content: caption,
        scheduled_time: new Date(scheduledTime).toISOString(),
        video_url: videoClips[0],
        video_clips: videoClips,
        audio_url: audioUrl,
        hashtags,
        cta: generatedScript?.cta || '',
        title: generatedScript?.title || topic,
        video_type: videoType,
      });
      toast.success(res.data?.message || 'Video scheduled successfully!');
      fetchScheduledPosts();
      setShowExisting(true);
    } catch (e) {
      toast.error('Failed to schedule video post');
    }
    setScheduling(false);
  };

  const handleCancel = async (postId) => {
    try {
      await base44.functions.invoke('socialIntegrationEngine', {
        action: 'cancel_scheduled_post',
        post_id: postId,
      });
      toast.success('Scheduled post cancelled');
      fetchScheduledPosts();
    } catch (_) {
      toast.error('Failed to cancel post');
    }
  };

  const formatDate = (iso) => {
    return new Date(iso).toLocaleString('en-US', {
      month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
      timeZone: 'America/New_York',
    });
  };

  return (
    <Card className="border-blue-500/20 bg-gradient-to-br from-blue-500/5 to-cyan-500/5">
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2 text-blue-400">
          <Calendar className="w-4 h-4" />Auto-Post to Social Media
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label>Platform</Label>
            <Select value={platform} onValueChange={setPlatform}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                {PLATFORMS.map(p => (
                  <SelectItem key={p.id} value={p.id}>{p.icon} {p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Schedule Date & Time</Label>
            <Input
              type="datetime-local"
              className="mt-1"
              min={getMinDatetime()}
              value={scheduledTime}
              onChange={e => setScheduledTime(e.target.value)}
            />
          </div>
        </div>

        <div>
          <Label>Post Caption</Label>
          <Textarea
            className="mt-1 text-sm"
            rows={3}
            placeholder="Write your social media caption..."
            value={caption}
            onChange={e => setCaption(e.target.value)}
          />
        </div>

        <div>
          <Label>Hashtags</Label>
          <Input
            className="mt-1 text-sm"
            placeholder="#axis #aimarketing #businessgrowth"
            value={hashtags}
            onChange={e => setHashtags(e.target.value)}
          />
        </div>

        <Button
          className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white"
          disabled={scheduling || videoClips.length === 0 || !caption.trim() || !scheduledTime}
          onClick={handleSchedule}
        >
          {scheduling
            ? <><Loader2 className="w-4 h-4 animate-spin" />Scheduling...</>
            : <><Send className="w-4 h-4" />Schedule Auto-Post</>}
        </Button>

        {videoClips.length === 0 && (
          <p className="text-xs text-muted-foreground text-center">Generate your video first to enable scheduling</p>
        )}

        {/* Scheduled Posts List */}
        {scheduledPosts.length > 0 && (
          <div className="pt-2 border-t border-border">
            <button
              onClick={() => setShowExisting(!showExisting)}
              className="w-full flex items-center justify-between text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
            >
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                {scheduledPosts.length} Scheduled Post{scheduledPosts.length !== 1 ? 's' : ''}
              </span>
              {showExisting ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
            {showExisting && (
              <div className="mt-2 space-y-2 max-h-64 overflow-y-auto">
                {scheduledPosts.map(post => (
                  <div key={post.id} className="rounded-lg border border-border bg-muted/20 p-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {STATUS_ICONS[post.status] || <Clock className="w-3.5 h-3.5 text-muted-foreground" />}
                        <Badge variant="outline" className="text-[10px] capitalize shrink-0">{post.platform}</Badge>
                        <span className="text-xs text-muted-foreground truncate">{formatDate(post.scheduled_at)}</span>
                      </div>
                      {post.status === 'scheduled' && (
                        <Button size="icon" variant="ghost" className="h-6 w-6 shrink-0" onClick={() => handleCancel(post.id)}>
                          <Trash2 className="w-3 h-3 text-red-400" />
                        </Button>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{post.content}</p>
                    {post.publish_error && (
                      <p className="text-[10px] text-red-400 mt-1">{post.publish_error}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        <p className="text-[10px] text-muted-foreground text-center">
          Scheduled posts auto-publish at the selected time. Connect your Instagram & LinkedIn accounts in Quick Integrations for auto-posting.
        </p>
      </CardContent>
    </Card>
  );
}