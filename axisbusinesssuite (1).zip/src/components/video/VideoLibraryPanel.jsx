import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Folder, Trash2, Search, Film, RefreshCw, Loader2, Inbox } from 'lucide-react';
import { toast } from 'sonner';
import UnifiedVideoPlayer from '@/components/video/UnifiedVideoPlayer';

function safeParse(str, fallback) {
  try { return JSON.parse(str); } catch { return fallback; }
}

export default function VideoLibraryPanel({ onReuse }) {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeFolder, setActiveFolder] = useState('All');
  const [previewing, setPreviewing] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.VideoLibrary.list('-created_date', 100);
      setVideos(list || []);
    } catch (e) {
      toast.error('Failed to load video library');
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const folders = ['All', ...Array.from(new Set(videos.map(v => v.folder || 'General')))];
  const filtered = videos.filter(v => {
    const folder = v.folder || 'General';
    const matchFolder = activeFolder === 'All' || folder === activeFolder;
    const q = search.toLowerCase();
    const matchSearch = !q || `${v.title} ${v.topic || ''}`.toLowerCase().includes(q);
    return matchFolder && matchSearch;
  });

  const remove = async (id) => {
    try {
      await base44.entities.VideoLibrary.delete(id);
      toast.success('Video removed from library');
      setPreviewing(null);
      load();
    } catch (e) {
      toast.error('Failed to delete video');
    }
  };

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search saved videos..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button variant="outline" size="sm" onClick={load} className="gap-2">
          <RefreshCw className="w-3.5 h-3.5" />Refresh
        </Button>
      </div>

      {/* Folders */}
      {folders.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {folders.map(f => (
            <button
              key={f}
              onClick={() => setActiveFolder(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center gap-1.5 ${
                activeFolder === f
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'border-border bg-muted/30 text-muted-foreground hover:bg-muted/60'
              }`}
            >
              <Folder className="w-3 h-3" />
              {f}
            </button>
          ))}
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="rounded-2xl border border-dashed border-border p-16 text-center">
          <Loader2 className="w-8 h-8 mx-auto mb-3 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground">Loading your video library...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border p-16 text-center text-muted-foreground">
          <Inbox className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">No saved videos yet</p>
          <p className="text-xs mt-1">Generate a video, approve it, and it will appear here for reuse anytime.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(v => {
            const clips = safeParse(v.video_clips, []);
            return (
              <Card key={v.id} className="overflow-hidden flex flex-col group">
                <div className="aspect-video bg-black relative">
                  {clips.length > 0 ? (
                    <video src={clips[0]} muted className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      <Film className="w-8 h-8 opacity-30" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" className="gap-2" onClick={() => setPreviewing(v)}>
                      <Film className="w-3.5 h-3.5" />Preview
                    </Button>
                  </div>
                </div>
                <CardContent className="p-3 flex-1 flex flex-col gap-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{v.title}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{v.topic}</p>
                    </div>
                    <Badge variant="outline" className="shrink-0 text-[10px]">{v.video_type}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1"><Folder className="w-3 h-3" />{v.folder || 'General'}</span>
                    <span>·</span>
                    <span>{v.duration}s</span>
                    {v.audio_url && <><span>·</span><span>narrated</span></>}
                  </div>
                  <div className="flex items-center gap-2 mt-auto pt-1">
                    <Button size="sm" variant="outline" className="flex-1 gap-1.5 text-xs" onClick={() => onReuse(v)}>
                      <RefreshCw className="w-3 h-3" />Reuse
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => remove(v.id)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Preview Modal */}
      {previewing && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4" onClick={() => setPreviewing(null)}>
          <div className="bg-card rounded-2xl border border-border max-w-2xl w-full p-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold truncate">{previewing.title}</h3>
              <Button size="sm" variant="ghost" onClick={() => setPreviewing(null)}>Close</Button>
            </div>
            <UnifiedVideoPlayer
              clips={safeParse(previewing.video_clips, [])}
              audioUrl={previewing.audio_url}
              script={safeParse(previewing.script_json, null)}
            />
            <div className="flex justify-end gap-2 mt-3">
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => { onReuse(previewing); setPreviewing(null); }}>
                <RefreshCw className="w-3.5 h-3.5" />Load into Editor
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}