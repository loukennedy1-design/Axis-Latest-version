import React, { useRef, useState, useEffect, useCallback } from 'react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Play, Pause, Download, RefreshCw, Mic, Video, VolumeX, Volume2,
  Maximize, Minimize, SkipBack, SkipForward, Gauge, X, Trash2,
  Loader2, Clapperboard,
} from 'lucide-react';

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2];

/**
 * UnifiedVideoPlayer — plays AI-generated video clips in sequence,
 * synced to the AI voice narration as the master timeline.
 *
 * Features: seekable progress bar, volume control, playback speed,
 * fullscreen, skip ±10s, clip management (reorder/delete/regenerate).
 */
export default function UnifiedVideoPlayer({
  clips = [],
  audioUrl,
  script,
  onRegenerateVideo,
  onRegenerateAudio,
  onRegenerateClip,
  onDeleteClip,
  onReorderClips,
  generatingVideo,
  generatingAudio,
}) {
  const containerRef = useRef(null);
  const audioRef = useRef(null);
  const clipRefs = useRef([]);
  const [playing, setPlaying] = useState(false);
  const [currentClipIdx, setCurrentClipIdx] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [readyClips, setReadyClips] = useState(() => new Set());
  const [manageMode, setManageMode] = useState(false);
  const [merging, setMerging] = useState(false);
  const [mergeProgress, setMergeProgress] = useState(0);
  const audioCtxRef = useRef(null);
  const audioSourceRef = useRef(null);

  const hasClips = clips.length > 0;
  const hasAudio = !!audioUrl;

  // Audio is the master timeline
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTimeUpdate = () => setCurrentTime(audio.currentTime);
    const onLoadedMeta = () => setAudioDuration(audio.duration || 0);
    const onEnded = () => {
      setPlaying(false);
      setCurrentClipIdx(0);
      setCurrentTime(0);
      clipRefs.current.forEach((v) => v?.pause());
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMeta);
    audio.addEventListener('ended', onEnded);
    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMeta);
      audio.removeEventListener('ended', onEnded);
    };
  }, [audioUrl]);

  // Apply volume + speed to audio
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = muted ? 0 : volume;
    audio.playbackRate = speed;
  }, [volume, muted, speed]);

  // Apply playback speed to all video clips (they're muted, only speed matters)
  useEffect(() => {
    clipRefs.current.forEach((v) => {
      if (v) v.playbackRate = speed;
    });
  }, [speed, clips]);

  // Determine which clip should be visible based on audio progress
  useEffect(() => {
    if (!hasClips || audioDuration === 0) return;
    const clipLen = audioDuration / clips.length;
    const idx = Math.min(Math.floor(currentTime / clipLen), clips.length - 1);
    if (idx !== currentClipIdx) {
      setCurrentClipIdx(idx);
    }
  }, [currentTime, audioDuration, clips.length, hasClips, currentClipIdx]);

  // Sync all clip play/pause state with `playing`
  useEffect(() => {
    clipRefs.current.forEach((v) => {
      if (!v) return;
      if (playing) {
        v.play().catch(() => {});
      } else {
        v.pause();
      }
    });
  }, [playing, clips]);

  // When clip index changes, restart the visible clip for continuous motion
  useEffect(() => {
    const v = clipRefs.current[currentClipIdx];
    if (!v || !playing) return;
    v.currentTime = 0;
    v.play().catch(() => {});
  }, [currentClipIdx]); // eslint-disable-line react-hooks/exhaustive-deps

  // Fullscreen change listener
  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const handleClipLoaded = useCallback((idx) => {
    setReadyClips((prev) => {
      if (prev.has(idx)) return prev;
      const next = new Set(prev);
      next.add(idx);
      return next;
    });
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (playing) {
      audio?.pause();
      clipRefs.current.forEach((v) => v?.pause());
      setPlaying(false);
    } else {
      if (audio) audio.play().catch(() => {});
      clipRefs.current.forEach((v) => v?.play().catch(() => {}));
      setPlaying(true);
    }
  };

  const seek = (time) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = Math.max(0, Math.min(time, audioDuration || 0));
    setCurrentTime(audio.currentTime);
  };

  const skip = (seconds) => seek(currentTime + seconds);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().catch(() => {});
    } else {
      document.exitFullscreen?.().catch(() => {});
    }
  };

  const cycleSpeed = () => {
    const idx = SPEEDS.indexOf(speed);
    const next = SPEEDS[(idx + 1) % SPEEDS.length];
    setSpeed(next);
    setShowSpeedMenu(false);
  };

  const progressPct = audioDuration > 0 ? (currentTime / audioDuration) * 100 : 0;
  const formatTime = (s) => {
    if (!s || isNaN(s)) return '0:00';
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  const downloadClip = async (url, filename) => {
    try {
      const res = await fetch(url);
      const blob = await res.blob();
      const blobUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(blobUrl), 1000);
    } catch (e) {
      window.open(url, '_blank');
    }
  };

  const downloadAllClips = () => {
    clips.forEach((c, i) => {
      setTimeout(() => downloadClip(c, `axis-video-clip-${i + 1}.mp4`), i * 800);
    });
  };

  /**
   * Merges video clips + audio narration into a single unified video file
   * using canvas captureStream + Web Audio API + MediaRecorder.
   * Produces one downloadable .webm with audio baked in — no more separate layers.
   */
  const mergeAndExport = async () => {
    if (!hasClips || !hasAudio || merging) return;
    setMerging(true);
    setMergeProgress(0);

    const audioEl = audioRef.current;
    const prevVolume = audioEl.volume;
    const prevMuted = audioEl.muted;
    let recorder;
    let drawRaf;
    let onEndedHandler;

    try {
      const firstClip = clipRefs.current[0];
      const w = firstClip?.videoWidth || 1280;
      const h = firstClip?.videoHeight || 720;
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');

      // Audio context — create once, reuse (MediaElementSource can only be created once)
      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContext();
      }
      const audioCtx = audioCtxRef.current;
      if (audioCtx.state === 'suspended') await audioCtx.resume();

      if (!audioSourceRef.current) {
        audioSourceRef.current = audioCtx.createMediaElementSource(audioEl);
      }
      const source = audioSourceRef.current;
      const dest = audioCtx.createMediaStreamDestination();
      source.connect(dest);
      source.connect(audioCtx.destination);

      const canvasStream = canvas.captureStream(30);
      const combinedStream = new MediaStream([
        ...canvasStream.getVideoTracks(),
        ...dest.stream.getAudioTracks(),
      ]);

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : 'video/webm';
      recorder = new MediaRecorder(combinedStream, { mimeType });
      const chunks = [];
      recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };

      const exportDone = new Promise((resolve) => {
        recorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'video/webm' });
          resolve(URL.createObjectURL(blob));
        };
      });

      // Reset everything to start
      audioEl.currentTime = 0;
      audioEl.volume = 1;
      audioEl.muted = false;
      clipRefs.current.forEach((v) => {
        if (v) { v.currentTime = 0; v.play().catch(() => {}); }
      });

      recorder.start(100);
      await audioEl.play();
      setPlaying(true);

      // Draw current clip frame to canvas in sync with audio timeline
      const drawFrame = () => {
        if (audioEl.ended) return;
        const clipLen = audioDuration / clips.length;
        const idx = Math.min(Math.floor(audioEl.currentTime / clipLen), clips.length - 1);
        const v = clipRefs.current[idx];
        if (v && v.readyState >= 2) {
          ctx.drawImage(v, 0, 0, w, h);
        }
        setMergeProgress(audioDuration > 0 ? (audioEl.currentTime / audioDuration) * 100 : 0);
        drawRaf = requestAnimationFrame(drawFrame);
      };
      drawFrame();

      onEndedHandler = () => {
        cancelAnimationFrame(drawRaf);
        setMergeProgress(100);
        if (recorder.state !== 'inactive') recorder.stop();
        setPlaying(false);
      };
      audioEl.addEventListener('ended', onEndedHandler, { once: true });

      const mergedUrl = await exportDone;

      const a = document.createElement('a');
      a.href = mergedUrl;
      a.download = 'axis-unified-video.webm';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(mergedUrl), 5000);
      toast.success('Unified video exported — audio & video merged into one file!');
    } catch (e) {
      toast.error('Failed to merge video: ' + e.message);
    } finally {
      audioEl.volume = prevVolume;
      audioEl.muted = prevMuted;
      if (onEndedHandler) audioEl.removeEventListener('ended', onEndedHandler);
      if (drawRaf) cancelAnimationFrame(drawRaf);
      setMerging(false);
      setMergeProgress(0);
    }
  };

  const firstClipReady = hasClips && (readyClips.size > 0 || clips.length === 0);

  // Handle progress bar click/drag for seeking
  const progressBarRef = useRef(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleProgressInteraction = (e) => {
    const bar = progressBarRef.current;
    if (!bar || !audioDuration) return;
    const rect = bar.getBoundingClientRect();
    const x = (e.clientX || e.touches?.[0]?.clientX || 0) - rect.left;
    const pct = Math.max(0, Math.min(1, x / rect.width));
    seek(pct * audioDuration);
  };

  const onProgressDown = (e) => {
    setIsDragging(true);
    handleProgressInteraction(e);
  };

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e) => handleProgressInteraction(e);
    const onUp = () => setIsDragging(false);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
    window.addEventListener('touchmove', onMove);
    window.addEventListener('touchend', onUp);
    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onUp);
    };
  }, [isDragging, audioDuration]); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="space-y-3" ref={containerRef}>
      {/* Hidden audio element (master timeline) */}
      <audio ref={audioRef} src={audioUrl || undefined} preload="metadata" className="hidden" />

      {/* Video display — all clips stacked, crossfaded by opacity */}
      {hasClips ? (
        <div className={`relative w-full rounded-xl overflow-hidden bg-black ${isFullscreen ? 'h-screen' : 'aspect-video'}`}>
          {/* Loading overlay while first clip buffers */}
          {!firstClipReady && (
            <div className="absolute inset-0 z-20 flex items-center justify-center bg-black">
              <RefreshCw className="w-6 h-6 text-white/40 animate-spin" />
            </div>
          )}
          {clips.map((clipUrl, idx) => (
            <video
              key={idx}
              ref={(el) => { clipRefs.current[idx] = el; }}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ease-in-out ${
                idx === currentClipIdx ? 'opacity-100' : 'opacity-0'
              }`}
              src={clipUrl}
              muted
              loop
              playsInline
              preload="auto"
              onLoadedData={() => handleClipLoaded(idx)}
            />
          ))}

          {/* Top overlays */}
          <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 px-2 py-1 rounded-md bg-black/70 backdrop-blur-sm pointer-events-none">
            <span className="text-[10px] font-semibold text-white">
              Clip {currentClipIdx + 1} / {clips.length}
            </span>
          </div>
          <div className="absolute top-3 right-3 z-10 flex items-center gap-1 px-2 py-1 rounded-md bg-black/70 backdrop-blur-sm pointer-events-none">
            <VolumeX className="w-3 h-3 text-white/80" />
            <span className="text-[10px] font-medium text-white/80">Narration</span>
          </div>

          {/* Click-to-toggle on video area */}
          <div
            className="absolute inset-0 z-5 cursor-pointer"
            onClick={togglePlay}
          >
            {/* Center play indicator when paused */}
            {!playing && firstClipReady && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-black/60 backdrop-blur-sm flex items-center justify-center">
                  <Play className="w-7 h-7 text-white ml-1" />
                </div>
              </div>
            )}
          </div>

          {/* Bottom control bar overlay (visible on hover or when paused) */}
          <div className={`absolute bottom-0 left-0 right-0 z-10 bg-gradient-to-t from-black/90 to-transparent px-3 pt-8 pb-2 transition-opacity duration-200 ${playing ? 'opacity-0 hover:opacity-100' : 'opacity-100'}`}>
            {/* Seekable progress bar */}
            <div
              ref={progressBarRef}
              className="h-1.5 bg-white/20 rounded-full overflow-hidden relative cursor-pointer mb-2 group/bar"
              onMouseDown={onProgressDown}
              onTouchStart={onProgressDown}
            >
              <div
                className="h-full bg-pink-500 transition-all duration-100 relative"
                style={{ width: `${progressPct}%` }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-3 rounded-full bg-pink-500 shadow-lg opacity-0 group-hover/bar:opacity-100 transition-opacity" />
              </div>
              {/* Clip boundary markers */}
              {hasClips && audioDuration > 0 && clips.length > 1 && (
                clips.slice(0, -1).map((_, i) => (
                  <div
                    key={i}
                    className="absolute top-0 bottom-0 w-0.5 bg-black/40"
                    style={{ left: `${((i + 1) / clips.length) * 100}%` }}
                  />
                ))
              )}
            </div>

            {/* Control buttons */}
            <div className="flex items-center gap-2">
              <button onClick={togglePlay} className="text-white hover:text-pink-400 transition-colors">
                {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
              </button>
              <button onClick={() => skip(-10)} className="text-white hover:text-pink-400 transition-colors flex items-center gap-0.5">
                <SkipBack className="w-4 h-4" />
                <span className="text-[9px]">10</span>
              </button>
              <button onClick={() => skip(10)} className="text-white hover:text-pink-400 transition-colors flex items-center gap-0.5">
                <SkipForward className="w-4 h-4" />
                <span className="text-[9px]">10</span>
              </button>

              {/* Volume */}
              <div className="flex items-center gap-1.5 group/vol">
                <button onClick={() => setMuted(!muted)} className="text-white hover:text-pink-400 transition-colors">
                  {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={muted ? 0 : volume}
                  onChange={(e) => { setVolume(parseFloat(e.target.value)); setMuted(false); }}
                  className="w-0 group-hover/vol:w-16 transition-all duration-200 accent-pink-500 h-1"
                />
              </div>

              {/* Time */}
              <span className="text-[10px] text-white/80 tabular-nums ml-1">
                {formatTime(currentTime)} / {formatTime(audioDuration)}
              </span>

              <div className="ml-auto flex items-center gap-2">
                {/* Playback speed */}
                <div className="relative">
                  <button
                    onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                    className="text-white hover:text-pink-400 transition-colors flex items-center gap-1"
                  >
                    <Gauge className="w-4 h-4" />
                    <span className="text-[10px] font-semibold">{speed}x</span>
                  </button>
                  {showSpeedMenu && (
                    <div className="absolute bottom-6 right-0 bg-black/95 backdrop-blur-sm rounded-lg border border-white/10 py-1 min-w-[60px]">
                      {SPEEDS.map(s => (
                        <button
                          key={s}
                          onClick={() => { setSpeed(s); setShowSpeedMenu(false); }}
                          className={`block w-full px-3 py-1 text-[10px] text-right hover:bg-white/10 transition-colors ${s === speed ? 'text-pink-400 font-bold' : 'text-white'}`}
                        >
                          {s}x
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Fullscreen */}
                <button onClick={toggleFullscreen} className="text-white hover:text-pink-400 transition-colors">
                  {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : hasAudio ? (
        <div className="w-full rounded-xl bg-black aspect-video flex items-center justify-center">
          <Mic className="w-10 h-10 text-white/20" />
        </div>
      ) : null}

      {/* Standard controls (when not fullscreen, always visible) */}
      {!isFullscreen && (
        <div className="flex items-center gap-3">
          <Button
            size="icon"
            className="rounded-full bg-pink-600 hover:bg-pink-700 text-white h-10 w-10 shrink-0"
            onClick={togglePlay}
            disabled={!hasAudio && !hasClips}
          >
            {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
          </Button>

          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground tabular-nums w-10">{formatTime(currentTime)}</span>
              <div
                ref={progressBarRef}
                className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden relative cursor-pointer"
                onMouseDown={onProgressDown}
                onTouchStart={onProgressDown}
              >
                <div
                  className="h-full bg-pink-500 transition-all duration-200"
                  style={{ width: `${progressPct}%` }}
                />
                {hasClips && audioDuration > 0 && clips.length > 1 && (
                  clips.slice(0, -1).map((_, i) => (
                    <div
                      key={i}
                      className="absolute top-0 bottom-0 w-0.5 bg-black/40"
                      style={{ left: `${((i + 1) / clips.length) * 100}%` }}
                    />
                  ))
                )}
              </div>
              <span className="text-xs text-muted-foreground tabular-nums w-10">{formatTime(audioDuration)}</span>
            </div>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-1.5">
            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setMuted(!muted)}>
              {muted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={muted ? 0 : volume}
              onChange={(e) => { setVolume(parseFloat(e.target.value)); setMuted(false); }}
              className="w-16 accent-pink-500 h-1"
            />
          </div>

          {/* Speed */}
          <Button size="sm" variant="ghost" className="h-8 px-2 text-xs gap-1" onClick={cycleSpeed}>
            <Gauge className="w-3.5 h-3.5" />
            {speed}x
          </Button>

          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={toggleFullscreen}>
            <Maximize className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Clip management */}
      {hasClips && clips.length > 1 && !isFullscreen && (
        <div className="space-y-2">
          <button
            onClick={() => setManageMode(!manageMode)}
            className="text-[10px] font-semibold text-muted-foreground hover:text-primary transition-colors"
          >
            {manageMode ? '✓ Done managing' : 'Manage clips'}
          </button>
          {manageMode && (
            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
              {clips.map((clipUrl, i) => (
                <div key={i} className="relative shrink-0 w-24 aspect-video rounded-lg overflow-hidden border-2 border-border group/clip">
                  <video src={clipUrl} muted className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-1 opacity-0 group-hover/clip:opacity-100 transition-opacity">
                    <button
                      onClick={() => onReorderClips?.(i, i - 1)}
                      disabled={i === 0}
                      className="text-white text-[9px] disabled:opacity-30"
                    >◀</button>
                    <div className="flex gap-1">
                      <button
                        onClick={() => onRegenerateClip?.(i)}
                        disabled={generatingVideo}
                        className="text-white hover:text-pink-400"
                      ><RefreshCw className="w-3 h-3" /></button>
                      <button
                        onClick={() => onDeleteClip?.(i)}
                        className="text-white hover:text-red-400"
                      ><Trash2 className="w-3 h-3" /></button>
                    </div>
                    <button
                      onClick={() => onReorderClips?.(i, i + 1)}
                      disabled={i === clips.length - 1}
                      className="text-white text-[9px] disabled:opacity-30"
                    >▶</button>
                  </div>
                  <span className="absolute top-0.5 left-0.5 px-1 rounded bg-black/80 text-[8px] text-white">{i + 1}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Merge & Export — unified video with audio baked in */}
      {hasClips && hasAudio && (
        <div className="space-y-2">
          <Button
            className="w-full gap-2 bg-gradient-to-r from-pink-600 to-violet-600 hover:from-pink-700 hover:to-violet-700 text-white"
            disabled={merging}
            onClick={mergeAndExport}
          >
            {merging
              ? <><Loader2 className="w-4 h-4 animate-spin" />Merging... {Math.round(mergeProgress)}%</>
              : <><Clapperboard className="w-4 h-4" />Merge & Export Unified Video</>}
          </Button>
          {merging && (
            <div className="h-1.5 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-pink-500 to-violet-500 transition-all duration-200" style={{ width: `${mergeProgress}%` }} />
            </div>
          )}
          {merging && (
            <p className="text-[10px] text-muted-foreground text-center">
              Recording in real-time — audio & video are being merged into one file
            </p>
          )}
        </div>
      )}

      {/* Download + Regenerate */}
      <div className="flex gap-2 flex-wrap">
        {hasClips && (
          <Button size="sm" variant="outline" className="gap-2 text-xs" onClick={() => downloadClip(clips[currentClipIdx], `axis-video-clip-${currentClipIdx + 1}.mp4`)}>
            <Download className="w-3.5 h-3.5" />Download Clip
          </Button>
        )}
        {hasClips && clips.length > 1 && (
          <Button size="sm" variant="outline" className="gap-2 text-xs" onClick={downloadAllClips}>
            <Download className="w-3.5 h-3.5" />Download All
          </Button>
        )}
        {audioUrl && (
          <Button size="sm" variant="outline" className="gap-2 text-xs" onClick={() => downloadClip(audioUrl, 'axis-narration.mp3')}>
            <Download className="w-3.5 h-3.5" />Audio
          </Button>
        )}
        {onRegenerateVideo && (
          <Button size="sm" variant="outline" className="gap-2 text-xs" onClick={onRegenerateVideo} disabled={generatingVideo}>
            {generatingVideo ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Video className="w-3.5 h-3.5" />}
            {hasClips ? 'Regenerate Video' : 'Generate Video'}
          </Button>
        )}
        {onRegenerateAudio && (
          <Button size="sm" variant="outline" className="gap-2 text-xs" onClick={onRegenerateAudio} disabled={generatingAudio}>
            {generatingAudio ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Mic className="w-3.5 h-3.5" />}
            {hasAudio ? 'Regenerate Audio' : 'Generate Audio'}
          </Button>
        )}
      </div>

      {hasClips && clips.length > 1 && (
        <p className="text-[10px] text-muted-foreground text-center">
          {clips.length} clips synced with AI narration · {formatTime(audioDuration)} total
        </p>
      )}
    </div>
  );
}