import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Star, PartyPopper, Clock, Loader2, CheckCircle2, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

const ANNIVERSARY_DAYS = 30;
const SNOOZE_DAYS = 7;

const snoozeKey = (userId) => `ax_review_snooze_${userId || 'anon'}`;

export default function AnniversaryReviewModal({ user }) {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState('prompt'); // 'prompt' | 'form' | 'done'
  const [rating, setRating] = useState(5);
  const [hover, setHover] = useState(0);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const accountDays = user?.created_date
    ? Math.floor((Date.now() - new Date(user.created_date).getTime()) / 86400000)
    : 0;
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';

  // Has this user already submitted a review? (suppress the prompt if so)
  const { data: existing } = useQuery({
    queryKey: ['my-review', user?.email],
    queryFn: () => base44.entities.UserReview.filter({ author_email: user.email }),
    enabled: !!user?.email && !isAdmin,
    select: (r) => (Array.isArray(r) ? r[0] : null) || null,
    retry: 1,
    staleTime: 60 * 1000,
  });

  useEffect(() => {
    if (!user || isAdmin) return;
    if (existing === undefined) return; // still loading
    if (existing) return; // already reviewed
    if (accountDays < ANNIVERSARY_DAYS) return;
    const snooze = Number(localStorage.getItem(snoozeKey(user.id)) || 0);
    if (snooze && Date.now() - snooze < SNOOZE_DAYS * 86400000) return;
    setStep('prompt');
    setRating(5);
    setTitle('');
    setBody('');
    setOpen(true);
  }, [user, isAdmin, existing, accountDays]);

  const snooze = () => {
    if (user?.id) localStorage.setItem(snoozeKey(user.id), String(Date.now()));
    setOpen(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim() || body.trim().length < 10) {
      toast.error('Please add a headline and a short review (at least 10 characters).');
      return;
    }
    setSubmitting(true);
    try {
      await base44.entities.UserReview.create({
        author_name: user.full_name || user.email,
        author_email: user.email,
        rating,
        title: title.trim(),
        body: body.trim(),
        industry: user.industry || '',
        status: 'approved',
      });
      setStep('done');
      toast.success('Thank you! Your review is now live on our website.');
    } catch (err) {
      toast.error(err.message || 'Failed to submit review.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!user || isAdmin) return null;

  return (
    <Dialog open={open} onOpenChange={(o) => (o ? setOpen(true) : snooze())}>
      <DialogContent className="max-w-md">
        {step === 'prompt' && (
          <>
            <DialogHeader>
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center mb-2 mx-auto">
                <PartyPopper className="w-7 h-7 text-amber-500" />
              </div>
              <DialogTitle className="text-center text-xl">You've been with AXIS for 30 days! 🎉</DialogTitle>
              <DialogDescription className="text-center">
                We'd love to hear how it's going. Share a quick review and it'll appear directly on our website for other business owners to see.
              </DialogDescription>
            </DialogHeader>
            <div className="flex flex-col gap-2 pt-2">
              <Button className="w-full gap-2" onClick={() => setStep('form')}>
                <Star className="w-4 h-4" /> Complete Review Now
              </Button>
              <Button variant="ghost" className="w-full gap-2 text-muted-foreground" onClick={snooze}>
                <Clock className="w-4 h-4" /> Remind Me Later
              </Button>
            </div>
          </>
        )}

        {step === 'form' && (
          <form onSubmit={handleSubmit} className="space-y-4">
            <DialogHeader>
              <DialogTitle className="text-lg">Share Your Review</DialogTitle>
              <DialogDescription>Your review goes live on our public reviews page.</DialogDescription>
            </DialogHeader>

            <div className="space-y-1.5">
              <Label>Overall Rating</Label>
              <div className="flex gap-1">
                {Array(5).fill(0).map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setRating(i + 1)}
                    onMouseEnter={() => setHover(i + 1)}
                    onMouseLeave={() => setHover(0)}
                    className="p-0.5"
                    aria-label={`${i + 1} star${i === 0 ? '' : 's'}`}
                  >
                    <Star
                      className={`w-7 h-7 transition-colors ${
                        i < (hover || rating) ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/40'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="rv-title">Headline</Label>
              <Input
                id="rv-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Best sales platform we've used"
                maxLength={120}
                required
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="rv-body">Your Review</Label>
              <Textarea
                id="rv-body"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Tell other business owners about your experience with AXIS…"
                rows={4}
                maxLength={1000}
                required
              />
            </div>

            <div className="flex gap-2 pt-1">
              <Button type="button" variant="ghost" onClick={() => setStep('prompt')}>Back</Button>
              <Button type="submit" className="flex-1 gap-2" disabled={submitting}>
                {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Publishing…</> : 'Publish Review'}
              </Button>
            </div>
          </form>
        )}

        {step === 'done' && (
          <div className="text-center space-y-4 py-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-9 h-9 text-emerald-500" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Thank you!</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Your review is now live on our website.
              </p>
            </div>
            <div className="flex flex-col gap-2">
              <a href="/#reviews" className="block">
                <Button className="w-full gap-2">View it on our reviews page <ArrowRight className="w-4 h-4" /></Button>
              </a>
              <Button variant="ghost" className="w-full" onClick={() => setOpen(false)}>Done</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}