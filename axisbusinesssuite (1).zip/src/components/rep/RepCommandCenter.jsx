import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Phone, Calendar, CheckCircle2, DollarSign, Clock, AlertCircle, ChevronRight } from 'lucide-react';
import { format, isToday, isThisWeek, isThisMonth } from 'date-fns';
import KPIRing from './KPIRing';
import RepActivityFeed from './RepActivityFeed';

export default function RepCommandCenter({ rep, leads, userEmail, subscriberEmail, onGoToTasks, onLeadClick }) {
  const { data: calls = [] } = useQuery({
    queryKey: ['rep-calls', userEmail],
    queryFn: () => base44.entities.CallLog.filter({ called_by: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['rep-tasks', userEmail],
    queryFn: () => base44.entities.FollowUpTask.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['rep-appts', userEmail],
    queryFn: () => base44.entities.Appointment.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: commissions = [] } = useQuery({
    queryKey: ['rep-commissions', rep?.id],
    queryFn: () => base44.entities.RepCommission.filter({ rep_id: rep?.id }),
    enabled: !!rep?.id,
    staleTime: 60000,
  });

  // KPIs
  const callsToday = calls.filter(c => c.created_date && isToday(new Date(c.created_date)) && c.team_notes !== 'NOTE' && c.team_notes !== 'STATUS_CHANGE');
  const callsTodayCount = callsToday.length;
  const callsTarget = rep?.target_calls_per_day || 50;

  const apptsThisWeek = appointments.filter(a =>
    a.scheduled_date && isThisWeek(new Date(a.scheduled_date), { weekStartsOn: 1 }) &&
    (a.status === 'scheduled' || a.status === 'confirmed')
  );
  const apptsTarget = rep?.target_appointments_per_week || 10;

  const openTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');
  const openTasksCount = openTasks.length;

  const commissionMTD = commissions
    .filter(c => c.period && isThisMonth(new Date(c.period + '-01')) || (c.created_date && isThisMonth(new Date(c.created_date))))
    .reduce((sum, c) => sum + (c.net_commission || 0), 0);

  // Today's Schedule
  const todayAppts = appointments
    .filter(a => a.scheduled_date && isToday(new Date(a.scheduled_date)))
    .sort((a, b) => new Date(a.scheduled_date) - new Date(b.scheduled_date));

  const todayTasks = tasks
    .filter(t => t.status !== 'completed' && t.due_date && (isToday(new Date(t.due_date)) || new Date(t.due_date) < new Date()))
    .sort((a, b) => new Date(a.due_date) - new Date(b.due_date));

  return (
    <div className="space-y-4">
      {/* KPI Rings */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KPIRing
          value={callsTodayCount}
          target={callsTarget}
          label="Calls Today"
          color="#ef4444"
          icon={Phone}
        />
        <KPIRing
          value={apptsThisWeek.length}
          target={apptsTarget}
          label="Appts This Week"
          color="#10b981"
          icon={Calendar}
        />
        <KPIRing
          value={openTasksCount}
          target={Math.max(openTasksCount, 1)}
          label="Open Tasks"
          color="#f59e0b"
          icon={CheckCircle2}
        />
        <KPIRing
          value={commissionMTD}
          target={rep?.quota_monthly || rep?.target_revenue_per_month || 10000}
          label="Commission MTD"
          color="#3b82f6"
          icon={DollarSign}
        />
      </div>

      {/* Two-column: Today's Schedule + Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Today's Schedule */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-primary" /> Today's Schedule
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {todayAppts.length === 0 && todayTasks.length === 0 ? (
              <div className="text-center py-6">
                <CheckCircle2 className="w-8 h-8 text-emerald-500/40 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">Nothing scheduled for today</p>
                <p className="text-xs text-muted-foreground/60 mt-1">Enjoy the breathing room or get ahead!</p>
              </div>
            ) : (
              <>
                {todayAppts.map(a => (
                  <div
                    key={a.id}
                    className="flex items-center gap-3 rounded-lg border-l-2 border-l-emerald-500 bg-emerald-500/5 p-2.5 cursor-pointer hover:bg-emerald-500/10 transition-colors"
                    onClick={() => onLeadClick?.({ id: a.lead_id, first_name: a.lead_name, phone: a.lead_phone })}
                  >
                    <div className="shrink-0 text-xs font-bold text-emerald-400 w-14">
                      {format(new Date(a.scheduled_date), 'h:mm a')}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{a.lead_name || 'Appointment'}</p>
                      <p className="text-[10px] text-muted-foreground">{a.duration_minutes || 30} min · {a.status}</p>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  </div>
                ))}
                {todayTasks.map(t => (
                  <div
                    key={t.id}
                    className="flex items-center gap-3 rounded-lg border-l-2 border-l-amber-500 bg-amber-500/5 p-2.5 cursor-pointer hover:bg-amber-500/10 transition-colors"
                    onClick={() => onLeadClick?.({ id: t.lead_id, first_name: t.lead_name, phone: t.lead_phone })}
                  >
                    <div className="shrink-0 text-xs font-bold text-amber-400 w-14">
                      {t.due_date ? format(new Date(t.due_date), 'h:mm') : '—'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{t.lead_name || t.task_type?.replace(/_/g, ' ')}</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{t.task_type?.replace(/_/g, ' ')} · {t.priority}</p>
                    </div>
                    <Badge variant="outline" className="text-[9px] bg-amber-500/10 text-amber-600 border-amber-500/20 shrink-0">Task</Badge>
                  </div>
                ))}
              </>
            )}
            {openTasksCount > 0 && (
              <Button variant="outline" size="sm" className="w-full mt-2 gap-1.5" onClick={onGoToTasks}>
                <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                View all {openTasksCount} open task{openTasksCount > 1 ? 's' : ''}
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Activity Feed */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse" /> Live Activity Feed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <RepActivityFeed userEmail={userEmail} maxItems={20} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}