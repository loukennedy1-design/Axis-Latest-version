import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Phone, StickyNote, Calendar, Mail, CheckCircle2, GitBranch, X } from 'lucide-react';
import { format } from 'date-fns';

const EVENT_STYLES = {
  call: { border: 'border-l-blue-500', icon: Phone, color: 'text-blue-400', label: 'Call' },
  note: { border: 'border-l-amber-500', icon: StickyNote, color: 'text-amber-400', label: 'Note' },
  appointment: { border: 'border-l-emerald-500', icon: Calendar, color: 'text-emerald-400', label: 'Appointment' },
  email: { border: 'border-l-purple-500', icon: Mail, color: 'text-purple-400', label: 'Email' },
  task: { border: 'border-l-slate-500', icon: CheckCircle2, color: 'text-slate-400', label: 'Task' },
  status: { border: 'border-l-indigo-500', icon: GitBranch, color: 'text-indigo-400', label: 'Status' },
};

export default function RepLeadDrawer({ lead, isOpen, onClose }) {
  const leadId = lead?.id;

  const { data: calls = [] } = useQuery({
    queryKey: ['lead-timeline-calls', leadId],
    queryFn: () => base44.entities.CallLog.filter({ lead_id: leadId }),
    enabled: !!leadId && isOpen,
  });
  const { data: tasks = [] } = useQuery({
    queryKey: ['lead-timeline-tasks', leadId],
    queryFn: () => base44.entities.FollowUpTask.filter({ lead_id: leadId }),
    enabled: !!leadId && isOpen,
  });
  const { data: appts = [] } = useQuery({
    queryKey: ['lead-timeline-appts', leadId],
    queryFn: () => base44.entities.Appointment.filter({ lead_id: leadId }),
    enabled: !!leadId && isOpen,
  });
  const { data: emails = [] } = useQuery({
    queryKey: ['lead-timeline-emails', leadId],
    queryFn: () => base44.entities.EmailMessage.filter({ lead_id: leadId }),
    enabled: !!leadId && isOpen,
  });

  const events = [
    ...calls.map(c => ({
      type: c.team_notes === 'NOTE' ? 'note' : c.team_notes === 'STATUS_CHANGE' ? 'status' : 'call',
      date: c.created_date,
      title: c.team_notes === 'NOTE' ? 'Note added' : c.team_notes === 'STATUS_CHANGE' ? 'Status updated' : `Call — ${c.outcome?.replace(/_/g, ' ')}`,
      summary: c.ai_summary || c.transcript || '',
      rep: c.called_by,
      detail: c.duration_seconds ? `${Math.round(c.duration_seconds / 60)} min` : null,
    })),
    ...tasks.map(t => ({
      type: 'task',
      date: t.status === 'completed' ? t.updated_date : t.created_date,
      title: t.status === 'completed' ? `Task completed — ${t.task_type?.replace(/_/g, ' ')}` : `Task created — ${t.task_type?.replace(/_/g, ' ')}`,
      summary: t.notes || '',
      rep: t.assigned_to,
      detail: t.due_date ? `Due: ${format(new Date(t.due_date), 'MMM d')}` : null,
    })),
    ...appts.map(a => ({
      type: 'appointment',
      date: a.created_date,
      title: `Appointment ${a.status}`,
      summary: a.scheduled_date ? `Scheduled for ${format(new Date(a.scheduled_date), 'MMM d, h:mm a')}` : '',
      rep: a.assigned_to,
      detail: a.duration_minutes ? `${a.duration_minutes} min` : null,
    })),
    ...emails.map(e => ({
      type: 'email',
      date: e.created_date,
      title: `Email ${e.direction} — ${e.subject}`,
      summary: e.body?.slice(0, 150) || '',
      rep: e.from_address,
      detail: `→ ${e.to_address}`,
    })),
  ]
    .filter(e => e.date)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-lg overflow-y-auto p-0">
        {lead && (
          <>
            <SheetHeader className="p-5 pb-3 border-b border-border">
              <SheetTitle className="text-lg">{lead.first_name} {lead.last_name}</SheetTitle>
              <SheetDescription className="flex items-center gap-2 flex-wrap">
                <span className="font-mono">{lead.phone}</span>
                {lead.company && <span>· {lead.company}</span>}
                {lead.email && <span>· {lead.email}</span>}
              </SheetDescription>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <Badge variant="outline" className="text-[10px] capitalize">{lead.status?.replace(/_/g, ' ')}</Badge>
                <Badge variant="outline" className="text-[10px]">{lead.call_attempts || 0} calls</Badge>
                {lead.source && <Badge variant="outline" className="text-[10px]">{lead.source}</Badge>}
              </div>
              {lead.notes && (
                <div className="mt-3 rounded-lg bg-amber-500/5 border border-amber-500/20 p-2.5">
                  <p className="text-[10px] text-amber-400 font-semibold mb-1">LEAD NOTES</p>
                  <p className="text-xs text-foreground/80 whitespace-pre-wrap">{lead.notes}</p>
                </div>
              )}
            </SheetHeader>
            <div className="p-5 pt-3">
              <h3 className="text-sm font-semibold mb-3">Activity Timeline</h3>
              {events.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">No activity recorded yet</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {events.map((e, i) => {
                    const style = EVENT_STYLES[e.type] || EVENT_STYLES.call;
                    const Icon = style.icon;
                    return (
                      <div key={i} className={`flex items-start gap-3 rounded-lg border-l-2 ${style.border} bg-card p-3`}>
                        <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${style.color}`} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs font-semibold">{e.title}</span>
                            <span className="text-[10px] text-muted-foreground shrink-0">
                              {format(new Date(e.date), 'MMM d, h:mm a')}
                            </span>
                          </div>
                          {e.summary && <p className="text-xs text-foreground/70 mt-0.5">{e.summary}</p>}
                          <div className="flex items-center gap-2 mt-1">
                            {e.rep && <span className="text-[10px] text-muted-foreground">{e.rep}</span>}
                            {e.detail && <Badge variant="outline" className="text-[9px] h-4">{e.detail}</Badge>}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}