import React from 'react';
import { Outlet } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import RepPortalLoginWall from '@/components/rep/RepPortalLoginWall';

export default function RepPortalEntry() {
  const { isAuthenticated, isLoading, hasChecked } = useAuth();

  if (isLoading || !hasChecked) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <RepPortalLoginWall />;
  }

  return <Outlet />;
}