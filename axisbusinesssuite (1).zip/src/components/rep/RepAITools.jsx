import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Sparkles, Copy, Mail, MessageSquare, Phone, Zap, Target, HelpCircle } from 'lucide-react';
import { toast } from 'sonner';

const copyToClipboard = (text) => {
  navigator.clipboard.writeText(text);
  toast.success('Copied to clipboard!');
};

function AITool({ title, icon: IconComp, description, children }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <IconComp className="w-4 h-4 text-primary" />
          {title}
        </CardTitle>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function LeadQualifier({ leads }) {
  const [selectedLead, setSelectedLead] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    const lead = leads.find(l => l.id === selectedLead);
    if (!lead) return;
    setLoading(true);
    setResult('');
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert sales coach. Analyze this lead and provide:
1. Qualification score (1-10)
2. Key buying signals
3. Recommended next step
4. Best time to call

Lead info:
Name: ${lead.first_name} ${lead.last_name}
Company: ${lead.company || 'N/A'}
Status: ${lead.status}
Call attempts: ${lead.call_attempts || 0}
Notes: ${lead.notes || 'None'}
Source: ${lead.source || 'N/A'}

Be concise and actionable.`,
      });
      setResult(res);
    } catch (e) {
      toast.error('Failed to analyze lead');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Select value={selectedLead} onValueChange={setSelectedLead}>
        <SelectTrigger><SelectValue placeholder="Pick a lead to qualify..." /></SelectTrigger>
        <SelectContent>
          {leads.map(l => (
            <SelectItem key={l.id} value={l.id}>{l.first_name} {l.last_name} {l.company ? `— ${l.company}` : ''}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Button onClick={run} disabled={!selectedLead || loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        Qualify Lead
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

function ObjectionHandler() {
  const [objection, setObjection] = useState('');
  const [style, setStyle] = useState('acknowledge_pivot');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    if (!objection.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const styleLabels = {
        acknowledge_pivot: 'acknowledge and pivot',
        feel_felt_found: 'feel-felt-found technique',
        challenge: 'respectfully challenge',
        deflect: 'deflect and redirect',
      };
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a world-class sales coach. A prospect just said: "${objection}"

Using the ${styleLabels[style]} technique, write 2-3 natural, conversational responses a rep can use right now on the phone. Make them human, not robotic. Keep each under 3 sentences.`,
      });
      setResult(res);
    } catch (e) {
      toast.error('Failed to generate response');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Textarea
        placeholder='Type the objection, e.g. "I need to talk to my spouse first..."'
        value={objection}
        onChange={e => setObjection(e.target.value)}
        className="resize-none h-20"
      />
      <Select value={style} onValueChange={setStyle}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="acknowledge_pivot">Acknowledge & Pivot</SelectItem>
          <SelectItem value="feel_felt_found">Feel-Felt-Found</SelectItem>
          <SelectItem value="challenge">Respectful Challenge</SelectItem>
          <SelectItem value="deflect">Deflect & Redirect</SelectItem>
        </SelectContent>
      </Select>
      <Button onClick={run} disabled={!objection.trim() || loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
        Handle Objection
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

function MessageComposer({ leads, type }) {
  const [selectedLead, setSelectedLead] = useState('');
  const [context, setContext] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    const lead = leads.find(l => l.id === selectedLead);
    setLoading(true);
    setResult('');
    try {
      const leadInfo = lead ? `Lead: ${lead.first_name} ${lead.last_name}, Company: ${lead.company || 'N/A'}, Status: ${lead.status}` : '';
      const prompt = type === 'email'
        ? `Write a professional, personalized sales follow-up email.
${leadInfo}
Context from rep: ${context || 'General follow-up after initial contact'}
Keep it short (under 150 words), friendly, with a clear call to action. Include subject line.`
        : `Write a short, natural SMS follow-up message (under 160 characters).
${leadInfo}
Context: ${context || 'Following up after initial contact'}
Be friendly, personal, and include a clear next step.`;

      const res = await base44.integrations.Core.InvokeLLM({ prompt });
      setResult(res);
    } catch (e) {
      toast.error('Failed to generate message');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Select value={selectedLead} onValueChange={setSelectedLead}>
        <SelectTrigger><SelectValue placeholder="Select lead (optional)..." /></SelectTrigger>
        <SelectContent>
          <SelectItem value="generic">Generic / No specific lead</SelectItem>
          {leads.map(l => (
            <SelectItem key={l.id} value={l.id}>{l.first_name} {l.last_name} {l.company ? `— ${l.company}` : ''}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Textarea
        placeholder="Any extra context? (e.g. 'they asked about pricing', 'called twice no answer')"
        value={context}
        onChange={e => setContext(e.target.value)}
        className="resize-none h-16"
      />
      <Button onClick={run} disabled={loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
        Generate {type === 'email' ? 'Email' : 'SMS'}
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

function CallScriptGen({ rep }) {
  const [prospect, setProspect] = useState('');
  const [goal, setGoal] = useState('appointment');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    setResult('');
    try {
      const goalLabels = { appointment: 'schedule an appointment', qualify: 'qualify the lead', close: 'close the deal', callback: 'secure a callback time' };
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Create a concise, natural-sounding outbound call script for a sales rep.
Rep name: ${rep?.name || 'Alex'}
Prospect info: ${prospect || 'decision maker at a mid-size business'}
Goal: ${goalLabels[goal]}
Style: conversational, confident, not pushy

Include: opening hook, 1-2 qualifying questions, value prop (30 seconds), and a clear close for the goal. Format with labeled sections.`,
      });
      setResult(res);
    } catch (e) {
      toast.error('Failed to generate script');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Textarea
        placeholder="Describe the prospect (e.g. 'owner of a small gym', 'HR manager at a 50-person company')"
        value={prospect}
        onChange={e => setProspect(e.target.value)}
        className="resize-none h-16"
      />
      <Select value={goal} onValueChange={setGoal}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="appointment">Set Appointment</SelectItem>
          <SelectItem value="qualify">Qualify Lead</SelectItem>
          <SelectItem value="close">Close Deal</SelectItem>
          <SelectItem value="callback">Secure Callback</SelectItem>
        </SelectContent>
      </Select>
      <Button onClick={run} disabled={loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Phone className="w-4 h-4" />}
        Generate Script
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border font-mono text-xs leading-relaxed">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

function ValuePropBuilder({ leads }) {
  const [selectedLead, setSelectedLead] = useState('');
  const [product, setProduct] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    const lead = leads.find(l => l.id === selectedLead);
    setLoading(true);
    setResult('');
    try {
      const leadInfo = lead ? `Prospect: ${lead.first_name} ${lead.last_name}, Company: ${lead.company || 'N/A'}, Industry: ${lead.source || 'N/A'}` : 'General prospect';
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a master sales strategist. Create a compelling value proposition.
${leadInfo}
Product/Service: ${product || 'AXIS Business Suite — AI-powered lead calling and appointment scheduling platform'}

Write 3 tailored value propositions (1-2 sentences each), each from a different angle:
1. ROI / Revenue focused
2. Time-saving / Efficiency focused
3. Risk mitigation / Compliance focused

Make them specific to the prospect's likely pain points. Be concise and punchy.`,
      });
      setResult(res);
    } catch (e) {
      toast.error('Failed to generate value props');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Select value={selectedLead} onValueChange={setSelectedLead}>
        <SelectTrigger><SelectValue placeholder="Select lead (optional)..." /></SelectTrigger>
        <SelectContent>
          <SelectItem value="generic">Generic / No specific lead</SelectItem>
          {leads.map(l => (
            <SelectItem key={l.id} value={l.id}>{l.first_name} {l.last_name} {l.company ? `— ${l.company}` : ''}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Textarea
        placeholder="What are you selling? (e.g. 'AXIS lead gen platform', 'SEO services', 'gym membership')"
        value={product}
        onChange={e => setProduct(e.target.value)}
        className="resize-none h-16"
      />
      <Button onClick={run} disabled={loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Target className="w-4 h-4" />}
        Generate Value Props
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

function DiscoveryQuestionGen({ leads }) {
  const [selectedLead, setSelectedLead] = useState('');
  const [focus, setFocus] = useState('pain_points');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const run = async () => {
    const lead = leads.find(l => l.id === selectedLead);
    setLoading(true);
    setResult('');
    try {
      const leadInfo = lead ? `Prospect: ${lead.first_name} ${lead.last_name}, Company: ${lead.company || 'N/A'}, Status: ${lead.status}` : 'General B2B prospect';
      const focusLabels = {
        pain_points: 'uncovering pain points and frustrations',
        budget: 'budget and decision-making authority',
        timeline: 'urgency and buying timeline',
        competition: 'current solutions and competitors they may use',
      };
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an elite sales coach. Generate 5 powerful discovery questions for a sales call.
${leadInfo}
Focus area: ${focusLabels[focus]}

The questions should be open-ended, thought-provoking, and designed to get the prospect talking. Avoid yes/no questions. Number them 1-5.`,
      });
      setResult(res);
    } catch (e) {
      toast.error('Failed to generate questions');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-3">
      <Select value={selectedLead} onValueChange={setSelectedLead}>
        <SelectTrigger><SelectValue placeholder="Select lead (optional)..." /></SelectTrigger>
        <SelectContent>
          <SelectItem value="generic">Generic / No specific lead</SelectItem>
          {leads.map(l => (
            <SelectItem key={l.id} value={l.id}>{l.first_name} {l.last_name} {l.company ? `— ${l.company}` : ''}</SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={focus} onValueChange={setFocus}>
        <SelectTrigger><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="pain_points">Pain Points</SelectItem>
          <SelectItem value="budget">Budget & Authority</SelectItem>
          <SelectItem value="timeline">Urgency & Timeline</SelectItem>
          <SelectItem value="competition">Competition</SelectItem>
        </SelectContent>
      </Select>
      <Button onClick={run} disabled={loading} className="w-full gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <HelpCircle className="w-4 h-4" />}
        Generate Questions
      </Button>
      {result && (
        <div className="relative bg-muted/40 rounded-lg p-3 text-sm whitespace-pre-wrap border border-border">
          {result}
          <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-6 px-2" onClick={() => copyToClipboard(result)}>
            <Copy className="w-3 h-3" />
          </Button>
        </div>
      )}
    </div>
  );
}

export default function RepAITools({ leads = [], rep = null }) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="w-4 h-4 text-primary" />
        <h2 className="text-sm font-semibold">AI Sales Tools</h2>
        <Badge variant="outline" className="text-[10px] bg-primary/10 text-primary border-primary/20">Powered by AI</Badge>
      </div>

      <Tabs defaultValue="objection">
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="objection" className="gap-1.5 text-xs"><Zap className="w-3 h-3" />Objections</TabsTrigger>
          <TabsTrigger value="script" className="gap-1.5 text-xs"><Phone className="w-3 h-3" />Call Script</TabsTrigger>
          <TabsTrigger value="qualify" className="gap-1.5 text-xs"><Sparkles className="w-3 h-3" />Qualifier</TabsTrigger>
          <TabsTrigger value="valueprop" className="gap-1.5 text-xs"><Target className="w-3 h-3" />Value Props</TabsTrigger>
          <TabsTrigger value="discovery" className="gap-1.5 text-xs"><HelpCircle className="w-3 h-3" />Discovery</TabsTrigger>
          <TabsTrigger value="email" className="gap-1.5 text-xs"><Mail className="w-3 h-3" />Email</TabsTrigger>
          <TabsTrigger value="sms" className="gap-1.5 text-xs"><MessageSquare className="w-3 h-3" />SMS</TabsTrigger>
        </TabsList>

        <TabsContent value="objection" className="mt-4">
          <AITool title="Objection Handler" icon={Zap} description="Turn any objection into an opportunity with AI-crafted responses.">
            <ObjectionHandler />
          </AITool>
        </TabsContent>

        <TabsContent value="script" className="mt-4">
          <AITool title="Call Script Generator" icon={Phone} description="Get a custom call script ready before you dial.">
            <CallScriptGen rep={rep} />
          </AITool>
        </TabsContent>

        <TabsContent value="qualify" className="mt-4">
          <AITool title="Lead Qualifier" icon={Sparkles} description="AI analysis of a lead's readiness and recommended next actions.">
            <LeadQualifier leads={leads} />
          </AITool>
        </TabsContent>

        <TabsContent value="valueprop" className="mt-4">
          <AITool title="Value Proposition Builder" icon={Target} description="Generate tailored value props from different angles for any prospect.">
            <ValuePropBuilder leads={leads} />
          </AITool>
        </TabsContent>

        <TabsContent value="discovery" className="mt-4">
          <AITool title="Discovery Question Generator" icon={HelpCircle} description="Get powerful open-ended questions to uncover pain, budget, and urgency.">
            <DiscoveryQuestionGen leads={leads} />
          </AITool>
        </TabsContent>

        <TabsContent value="email" className="mt-4">
          <AITool title="Email Composer" icon={Mail} description="Generate a personalized follow-up email in seconds.">
            <MessageComposer leads={leads} type="email" />
          </AITool>
        </TabsContent>

        <TabsContent value="sms" className="mt-4">
          <AITool title="SMS Composer" icon={MessageSquare} description="Craft a punchy, effective SMS follow-up.">
            <MessageComposer leads={leads} type="sms" />
          </AITool>
        </TabsContent>
      </Tabs>
    </div>
  );
}