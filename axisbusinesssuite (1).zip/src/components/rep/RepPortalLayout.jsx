import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { useAuth } from '@/lib/AuthContext';
import { Bell, LogOut, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import TrinityChatAssistant from '@/components/trinity/TrinityChatAssistant';
import {
  LayoutDashboard, Users, CheckCircle2, Calendar, Link2,
  FileText, Sparkles, Target, Phone, Zap, GraduationCap
} from 'lucide-react';
import { cn } from '@/lib/utils';

const REP_NAV = [
  { tab: 'command', label: 'Command Center', icon: LayoutDashboard },
  { tab: 'leads', label: 'Leads', icon: Users },
  { tab: 'lead_gen', label: 'Lead Generator', icon: Target },
  { tab: 'tasks', label: 'Tasks', icon: CheckCircle2 },
  { tab: 'appointments', label: 'Appointments', icon: Calendar },
  { tab: 'referrals', label: 'Referrals', icon: Link2 },
  { tab: 'documents', label: 'Documents', icon: FileText },
  { tab: 'training', label: 'Sales Training', icon: GraduationCap },
  { tab: 'ai_tools', label: 'AI Sales Tools', icon: Sparkles },
];

export default function RepPortalLayout() {
  const { user, loading } = useCurrentUser();
  const { logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);

  const searchParams = new URLSearchParams(location.search);
  const activeTab = searchParams.get('tab') || 'command';

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    setIsDesktop(mq.matches);
    const handler = (e) => {
      setIsDesktop(e.matches);
      if (e.matches) setMobileOpen(false);
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const hasExplicit = root.classList.contains('dark') || root.classList.contains('light');
    if (hasExplicit) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark');
    if (mq.matches) root.classList.add('dark');
    const handler = (e) => {
      if (e.matches) root.classList.add('dark');
      else root.classList.remove('dark');
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, []);

  if (loading) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-slate-700 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  const initials = user?.full_name
    ? user.full_name.split(' ').map(n => n[0]).join('').toUpperCase()
    : (user?.email?.[0]?.toUpperCase() || 'R');

  const desktopMargin = collapsed ? 68 : 240;

  const handleLogout = async () => {
    await logout('/');
  };

  return (
    <div className="min-h-screen bg-background font-inter">
      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed left-0 top-0 h-screen z-50 transition-transform duration-300 ease-in-out",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        <RepSidebar
          user={user}
          collapsed={collapsed}
          activeTab={activeTab}
          onCollapse={setCollapsed}
          onMobileClose={() => setMobileOpen(false)}
          onLogout={handleLogout}
        />
      </div>

      {/* Main content */}
      <div
        className="transition-all duration-300 min-w-0"
        style={{ marginLeft: isDesktop ? desktopMargin : 0 }}
      >
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex h-14 sm:h-16 items-center gap-3 border-b border-border bg-card/80 backdrop-blur-xl px-3 sm:px-4 safe-area-top">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-extrabold text-sm">
              A
            </div>
            <span className="font-bold text-sm hidden sm:inline">AXIS Rep Portal</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-4.5 w-4.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <DropdownMenuItem className="text-xs text-muted-foreground">
                  No new notifications
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-lg hover:bg-muted px-2 py-1.5 transition-colors">
                  <Avatar className="w-7 h-7">
                    <AvatarFallback className="bg-primary/20 text-primary text-xs font-bold">{initials}</AvatarFallback>
                  </Avatar>
                  <span className="text-xs font-medium hidden sm:inline max-w-[120px] truncate">
                    {user?.full_name || user?.email}
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem className="text-xs text-muted-foreground cursor-default">
                  {user?.email}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleLogout} className="text-destructive gap-2">
                  <LogOut className="w-4 h-4" /> Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="p-3 sm:p-4 md:p-6 overflow-x-hidden max-w-full min-h-[calc(100vh-3.5rem)] sm:min-h-[calc(100vh-4rem)] pb-20 lg:pb-0">
          <Outlet context={{ user }} />
        </main>
      </div>

      <TrinityChatAssistant user={user} autoOpen={false} onboardingMode={false} />
    </div>
  );
}

function RepSidebar({ user, collapsed, activeTab, onCollapse, onMobileClose, onLogout }) {
  const location = useLocation();

  const buildTabUrl = (tab) => `/rep-portal?tab=${tab}`;

  return (
    <aside className={cn(
      "h-full flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-300",
      collapsed ? "w-[68px]" : "w-60"
    )}>
      {/* Logo header */}
      <div className="flex items-center gap-2 px-4 h-14 sm:h-16 border-b border-sidebar-border shrink-0">
        <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-extrabold text-sm shrink-0">
          A
        </div>
        {!collapsed && (
          <span className="font-bold text-sm text-sidebar-foreground">AXIS Rep</span>
        )}
        <button
          className="ml-auto lg:hidden text-muted-foreground"
          onClick={onMobileClose}
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 no-scrollbar space-y-0.5">
        {REP_NAV.map((item) => {
          const isActive = activeTab === item.tab;
          const Icon = item.icon;
          return (
            <Link
              key={item.tab}
              to={buildTabUrl(item.tab)}
              onClick={onMobileClose}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors",
                isActive
                  ? "bg-primary/15 text-primary font-semibold"
                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                collapsed && "justify-center"
              )}
              title={collapsed ? item.label : undefined}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-sidebar-border p-2 space-y-0.5 shrink-0">
        <button
          onClick={onLogout}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors w-full",
            collapsed && "justify-center"
          )}
          title={collapsed ? "Sign Out" : undefined}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>

      {/* Collapse toggle (desktop only) */}
      <button
        className="hidden lg:flex items-center justify-center py-2 border-t border-sidebar-border text-muted-foreground hover:text-foreground hover:bg-sidebar-accent transition-colors"
        onClick={() => onCollapse(!collapsed)}
      >
        {collapsed ? <LayoutDashboard className="w-4 h-4 rotate-180" /> : <LayoutDashboard className="w-4 h-4" />}
      </button>
    </aside>
  );
}