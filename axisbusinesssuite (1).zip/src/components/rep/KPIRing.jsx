import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

export default function KPIRing({ value, target, label, color = '#ef4444', icon: Icon }) {
  const pct = target > 0 ? Math.min(100, Math.round((value / target) * 100)) : 0;
  const data = [
    { name: 'done', value: pct },
    { name: 'remaining', value: Math.max(0, 100 - pct) },
  ];
  const colors = [color, 'hsl(var(--muted))'];

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-card p-4 flex flex-col items-center">
      <div className="w-28 h-28 relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={42}
              outerRadius={54}
              paddingAngle={2}
              dataKey="value"
              startAngle={90}
              endAngle={-270}
              stroke="none"
            >
              {data.map((_, i) => (
                <Cell key={i} fill={colors[i]} />
              ))}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {Icon && <Icon className="w-3.5 h-3.5 mb-0.5" style={{ color }} />}
          <span className="text-xl font-bold leading-none">{value}</span>
          <span className="text-[9px] text-muted-foreground mt-0.5">/ {target}</span>
        </div>
      </div>
      <p className="text-xs text-muted-foreground mt-2 text-center">{label}</p>
      <p className="text-[10px] font-bold mt-0.5" style={{ color }}>{pct}%</p>
    </div>
  );
}