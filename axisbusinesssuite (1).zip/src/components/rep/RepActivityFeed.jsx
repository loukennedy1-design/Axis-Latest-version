import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Phone, StickyNote, Calendar, Mail, CheckCircle2, GitBranch, Activity as ActivityIcon } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const EVENT_STYLES = {
  call: { border: 'border-l-blue-500', icon: Phone, iconColor: 'text-blue-400', bg: 'bg-blue-500/5', label: 'Call logged' },
  note: { border: 'border-l-amber-500', icon: StickyNote, iconColor: 'text-amber-400', bg: 'bg-amber-500/5', label: 'Note added' },
  appointment: { border: 'border-l-emerald-500', icon: Calendar, iconColor: 'text-emerald-400', bg: 'bg-emerald-500/5', label: 'Appointment' },
  email: { border: 'border-l-purple-500', icon: Mail, iconColor: 'text-purple-400', bg: 'bg-purple-500/5', label: 'Email sent' },
  task: { border: 'border-l-slate-500', icon: CheckCircle2, iconColor: 'text-slate-400', bg: 'bg-slate-500/5', label: 'Task' },
  status: { border: 'border-l-indigo-500', icon: GitBranch, iconColor: 'text-indigo-400', bg: 'bg-indigo-500/5', label: 'Status change' },
};

export default function RepActivityFeed({ userEmail, maxItems = 20 }) {
  const { data: calls = [] } = useQuery({
    queryKey: ['rep-calls', userEmail],
    queryFn: () => base44.entities.CallLog.filter({ called_by: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['rep-tasks', userEmail],
    queryFn: () => base44.entities.FollowUpTask.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: appts = [] } = useQuery({
    queryKey: ['rep-appts', userEmail],
    queryFn: () => base44.entities.Appointment.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const { data: emails = [] } = useQuery({
    queryKey: ['rep-emails', userEmail],
    queryFn: () => base44.entities.EmailMessage.filter({ from_address: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const events = [
    ...calls.map(c => ({
      type: c.team_notes === 'NOTE' ? 'note' : c.team_notes === 'STATUS_CHANGE' ? 'status' : 'call',
      date: c.created_date,
      summary: c.ai_summary || c.transcript || `Call to ${c.lead_name || c.phone_number}`,
      leadName: c.lead_name,
      detail: c.outcome?.replace(/_/g, ' '),
    })),
    ...tasks.map(t => ({
      type: 'task',
      date: t.status === 'completed' ? t.updated_date : t.created_date,
      summary: t.status === 'completed' ? `Completed: ${t.task_type?.replace(/_/g, ' ')}` : `New task: ${t.task_type?.replace(/_/g, ' ')}`,
      leadName: t.lead_name,
      detail: t.notes,
    })),
    ...appts.map(a => ({
      type: 'appointment',
      date: a.created_date,
      summary: `${a.lead_name || 'Lead'} — ${a.scheduled_date ? new Date(a.scheduled_date).toLocaleDateString() : 'TBD'}`,
      leadName: a.lead_name,
      detail: a.status,
    })),
    ...emails.map(e => ({
      type: 'email',
      date: e.created_date,
      summary: e.subject,
      leadName: e.lead_name,
      detail: `→ ${e.to_address}`,
    })),
  ]
    .filter(e => e.date)
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, maxItems);

  if (events.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center">
        <ActivityIcon className="w-8 h-8 text-muted-foreground/40 mb-2" />
        <p className="text-sm text-muted-foreground">No recent activity yet</p>
        <p className="text-xs text-muted-foreground/60 mt-1">Log calls, add notes, and complete tasks to see them here</p>
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {events.map((e, i) => {
        const style = EVENT_STYLES[e.type] || EVENT_STYLES.call;
        const Icon = style.icon;
        return (
          <div key={i} className={`flex items-start gap-3 rounded-lg border-l-2 ${style.border} ${style.bg} p-2.5`}>
            <Icon className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${style.iconColor}`} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold">{style.label}</span>
                <span className="text-[10px] text-muted-foreground shrink-0">
                  {formatDistanceToNow(new Date(e.date), { addSuffix: true })}
                </span>
              </div>
              <p className="text-xs text-foreground/80 truncate">{e.summary}</p>
              {e.leadName && (
                <p className="text-[10px] text-muted-foreground/70 truncate">Lead: {e.leadName}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}