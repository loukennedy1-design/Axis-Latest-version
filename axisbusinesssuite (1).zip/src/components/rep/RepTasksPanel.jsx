import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { CheckCircle2, Loader2, Clock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { format, isToday, isPast } from 'date-fns';

const PRIORITY_COLORS = {
  high: 'bg-red-500/10 text-red-600 border-red-500/20',
  medium: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  low: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
};

export default function RepTasksPanel({ userEmail, onLeadClick }) {
  const [completionNotes, setCompletionNotes] = useState({});
  const [activeNoteId, setActiveNoteId] = useState(null);
  const qc = useQueryClient();

  const queryKey = ['rep-tasks', userEmail];

  const { data: tasks = [], isLoading } = useQuery({
    queryKey,
    queryFn: () => base44.entities.FollowUpTask.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const completeMut = useMutation({
    mutationFn: ({ task, note }) => base44.entities.FollowUpTask.update(task.id, {
      status: 'completed',
      notes: note ? `${task.notes || ''}\n[Completed] ${note}`.trim() : task.notes,
    }),
    onMutate: async ({ task }) => {
      await qc.cancelQueries({ queryKey });
      const previous = qc.getQueryData(queryKey);
      qc.setQueryData(queryKey, (old) =>
        old.map(t => t.id === task.id ? { ...t, status: 'completed' } : t)
      );
      return { previous };
    },
    onError: (err, vars, context) => {
      qc.setQueryData(queryKey, context.previous);
      toast.error('Failed to complete task — rolled back');
    },
    onSuccess: () => {
      toast.success('Task completed!');
      qc.invalidateQueries({ queryKey });
      setActiveNoteId(null);
      setCompletionNotes({});
    },
  });

  const sorted = [...tasks].sort((a, b) => {
    if (a.status === 'completed' && b.status !== 'completed') return 1;
    if (a.status !== 'completed' && b.status === 'completed') return -1;
    return new Date(a.due_date || 0) - new Date(b.due_date || 0);
  });

  if (isLoading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  if (sorted.length === 0) {
    return (
      <Card className="p-10 text-center border-dashed">
        <CheckCircle2 className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
        <p className="text-sm text-muted-foreground">No tasks assigned to you</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {sorted.map(task => {
        const isCompleted = task.status === 'completed';
        const dueDate = task.due_date ? new Date(task.due_date) : null;
        const overdue = dueDate && isPast(dueDate) && !isCompleted && !isToday(dueDate);
        const dueToday = dueDate && isToday(dueDate) && !isCompleted;

        return (
          <Card key={task.id} className={`p-3.5 transition-colors ${isCompleted ? 'opacity-50 border-emerald-500/20' : overdue ? 'border-red-500/20 bg-red-500/5' : dueToday ? 'border-amber-500/20 bg-amber-500/5' : 'border-border'}`}>
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="outline" className="text-[10px] capitalize">{task.task_type?.replace(/_/g, ' ')}</Badge>
                  <Badge variant="outline" className={`text-[10px] capitalize ${PRIORITY_COLORS[task.priority] || ''}`}>{task.priority}</Badge>
                  {isCompleted && <Badge variant="outline" className="text-[10px] bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Completed</Badge>}
                  {task.lead_name && (
                    <button
                      className="text-xs text-primary hover:underline"
                      onClick={() => onLeadClick?.({ id: task.lead_id, first_name: task.lead_name, phone: task.lead_phone })}
                    >
                      {task.lead_name}
                    </button>
                  )}
                </div>
                {task.notes && !activeNoteId && <p className="text-xs text-foreground/70 mt-1.5">{task.notes}</p>}
                {dueDate && (
                  <div className={`flex items-center gap-1 mt-1 text-xs ${overdue ? 'text-red-400' : dueToday ? 'text-amber-400' : 'text-muted-foreground'}`}>
                    <Clock className="w-3 h-3" />
                    {overdue ? 'Overdue — ' : dueToday ? 'Due today — ' : ''}
                    {format(dueDate, 'MMM d, h:mm a')}
                  </div>
                )}
              </div>

              {!isCompleted && (
                <div className="shrink-0 flex flex-col items-end gap-1">
                  {activeNoteId === task.id ? (
                    <div className="w-48 space-y-1.5">
                      <Textarea
                        placeholder="Completion note (optional)..."
                        value={completionNotes[task.id] || ''}
                        onChange={e => setCompletionNotes(prev => ({ ...prev, [task.id]: e.target.value }))}
                        rows={2}
                        className="text-xs"
                      />
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          className="h-7 text-xs flex-1 gap-1"
                          disabled={completeMut.isPending}
                          onClick={() => completeMut.mutate({ task, note: completionNotes[task.id]?.trim() || '' })}
                        >
                          {completeMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                          Complete
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 px-2" onClick={() => setActiveNoteId(null)}>Cancel</Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 text-xs gap-1 text-emerald-500 hover:text-emerald-400 hover:bg-emerald-500/10"
                      onClick={() => setActiveNoteId(task.id)}
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" /> Mark Complete
                    </Button>
                  )}
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}