import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { DollarSign, Building2, TrendingUp, ChevronDown, ChevronRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function RepCommissionPanel({ commissions = [] }) {
  const [expandedSections, setExpandedSections] = useState({
    regular: true,
    wl_bonus: false,
    wl_override: false
  });

  const regularCommissions = commissions.filter(c => c.commission_type === 'monthly_residual');
  const wlBonuses = commissions.filter(c => c.commission_type === 'wl_signup_bonus');
  const wlOverrides = commissions.filter(c => c.commission_type === 'wl_override');

  const monthlyTrend = (data) => {
    const sorted = [...data].sort((a, b) => a.period.localeCompare(b.period));
    return sorted.slice(-6).map(c => ({ period: c.period, amount: c.net_commission }));
  };

  const toggleSection = (key) => {
    setExpandedSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const renderCommissionTable = (data, showWLPartner = false) => {
    if (!data || data.length === 0) {
      return (
        <div className="text-center text-muted-foreground py-8">
          No commission records in this category
        </div>
      );
    }

    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Period</TableHead>
            {showWLPartner && <TableHead>WL Partner</TableHead>}
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Amount</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((commission) => (
            <TableRow key={commission.id}>
              <TableCell className="font-medium">{commission.period}</TableCell>
              {showWLPartner && (
                <TableCell>
                  {commission.wl_partner_name || 'N/A'}
                </TableCell>
              )}
              <TableCell>
                <Badge variant={commission.status === 'pending_review' ? 'secondary' : commission.status === 'paid' ? 'default' : 'outline'}>
                  {commission.status.replace('_', ' ')}
                </Badge>
              </TableCell>
              <TableCell className="text-right font-semibold">
                ${commission.net_commission?.toFixed(2) || '0.00'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };

  const renderSection = (title, icon, data, sectionKey, showWLPartner = false) => {
    const isExpanded = expandedSections[sectionKey];
    const total = data.reduce((sum, c) => sum + (c.net_commission || 0), 0);
    const pending = data.filter(c => c.status === 'pending_review').length;

    return (
      <Card>
        <CardHeader className="cursor-pointer" onClick={() => toggleSection(sectionKey)}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                {icon}
              </div>
              <div>
                <CardTitle className="text-base">{title}</CardTitle>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {data.length} records {pending > 0 && `• ${pending} pending`} • Total: ${data.length > 0 ? `$${total.toFixed(2)}` : '$0.00'}
                </p>
              </div>
            </div>
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        </CardHeader>
        {isExpanded && (
          <CardContent className="p-0 pt-2">
            <div className="h-40 mb-4 px-2">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={monthlyTrend(data)}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="period" className="text-xs" />
                  <YAxis className="text-xs" tickFormatter={(value) => `$${value}`} />
                  <Tooltip
                    formatter={(value) => [`$${value}`, 'Commission']}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                  />
                  <Area type="monotone" dataKey="amount" stroke="hsl(var(--primary))" fill="hsl(var(--primary)/0.2)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            {renderCommissionTable(data, showWLPartner)}
          </CardContent>
        )}
      </Card>
    );
  };

  return (
    <div className="space-y-4">
      {renderSection(
        'Regular Subscriber Residuals',
        <DollarSign className="w-4 h-4 text-emerald-500" />,
        regularCommissions,
        'regular'
      )}

      {renderSection(
        'WL Partner Signup Bonuses',
        <Building2 className="w-4 h-4 text-amber-500" />,
        wlBonuses,
        'wl_bonus',
        true
      )}

      {renderSection(
        'WL Downstream Override Earnings',
        <TrendingUp className="w-4 h-4 text-blue-500" />,
        wlOverrides,
        'wl_override',
        true
      )}
    </div>
  );
}