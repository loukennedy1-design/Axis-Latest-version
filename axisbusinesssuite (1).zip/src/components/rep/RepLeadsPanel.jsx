import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Phone, StickyNote, ChevronRight, Loader2, X } from 'lucide-react';
import { toast } from 'sonner';
import RepLogCallModal from './RepLogCallModal';

const STATUS_COLORS = {
  new: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  contacted: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  qualified: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  appointment_set: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  not_interested: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  do_not_call: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const STATUSES = ['new', 'contacted', 'qualified', 'appointment_set', 'not_interested', 'do_not_call', 'invalid'];

export default function RepLeadsPanel({ leads, rep, userEmail, subscriberEmail, onLeadClick }) {
  const [logCallLead, setLogCallLead] = useState(null);
  const [noteLeadId, setNoteLeadId] = useState(null);
  const [noteText, setNoteText] = useState('');
  const [statusLeadId, setStatusLeadId] = useState(null);
  const qc = useQueryClient();

  const statusMut = useMutation({
    mutationFn: async ({ lead, newStatus }) => {
      await base44.entities.Lead.update(lead.id, { status: newStatus });
      // Log status change as a CallLog entry for activity feed
      await base44.entities.CallLog.create({
        lead_id: lead.id,
        lead_name: `${lead.first_name} ${lead.last_name}`.trim(),
        phone_number: lead.phone,
        direction: 'outbound',
        status: 'completed',
        outcome: 'other',
        called_by: userEmail,
        owner: subscriberEmail || rep?.owner || userEmail,
        ai_summary: `Status changed to: ${newStatus.replace(/_/g, ' ')}`,
        team_notes: 'STATUS_CHANGE',
        consent_verified: lead.consent_given || false,
      });
    },
    onSuccess: () => {
      toast.success('Status updated');
      qc.invalidateQueries({ queryKey: ['rep-leads', userEmail] });
      qc.invalidateQueries({ queryKey: ['rep-calls', userEmail] });
      setStatusLeadId(null);
    },
    onError: (e) => toast.error('Failed to update status: ' + e.message),
  });

  const noteMut = useMutation({
    mutationFn: async ({ lead, note }) => {
      const timestamp = new Date().toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' });
      const repName = rep?.name || userEmail;
      const newNotes = lead.notes
        ? `${lead.notes}\n\n[${timestamp}] ${repName}: ${note}`
        : `[${timestamp}] ${repName}: ${note}`;
      await base44.entities.Lead.update(lead.id, { notes: newNotes });
      // Log note addition for activity feed
      await base44.entities.CallLog.create({
        lead_id: lead.id,
        lead_name: `${lead.first_name} ${lead.last_name}`.trim(),
        phone_number: lead.phone,
        direction: 'outbound',
        status: 'completed',
        outcome: 'other',
        called_by: userEmail,
        owner: subscriberEmail || rep?.owner || userEmail,
        ai_summary: note,
        team_notes: 'NOTE',
        consent_verified: lead.consent_given || false,
      });
    },
    onSuccess: () => {
      toast.success('Note added');
      qc.invalidateQueries({ queryKey: ['rep-leads', userEmail] });
      qc.invalidateQueries({ queryKey: ['rep-calls', userEmail] });
      setNoteLeadId(null);
      setNoteText('');
    },
    onError: (e) => toast.error('Failed to add note: ' + e.message),
  });

  return (
    <div className="space-y-2">
      {leads.length === 0 && (
        <Card className="p-10 text-center border-dashed">
          <p className="text-sm text-muted-foreground">No leads assigned to you yet</p>
        </Card>
      )}
      {leads.map(lead => (
        <Card
          key={lead.id}
          className="group p-3.5 border-border hover:border-primary/30 transition-colors"
        >
          <div className="flex items-start gap-3">
            {/* Clickable lead info */}
            <div
              className="flex-1 min-w-0 cursor-pointer"
              onClick={() => onLeadClick(lead)}
            >
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-semibold text-sm">{lead.first_name} {lead.last_name}</span>
                <Badge variant="outline" className={`text-[10px] capitalize ${STATUS_COLORS[lead.status] || ''}`}>
                  {lead.status?.replace(/_/g, ' ')}
                </Badge>
                {lead.call_attempts > 0 && (
                  <Badge variant="outline" className="text-[10px] text-muted-foreground">{lead.call_attempts} calls</Badge>
                )}
              </div>
              <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                <span className="font-mono">{lead.phone}</span>
                {lead.company && <span>· {lead.company}</span>}
                {lead.last_called && <span>· Last: {new Date(lead.last_called).toLocaleDateString()}</span>}
              </div>
            </div>

            {/* Inline action buttons */}
            <div className="flex items-center gap-1 shrink-0">
              {/* Update Status */}
              {statusLeadId === lead.id ? (
                <Select
                  onValueChange={(v) => statusMut.mutate({ lead, newStatus: v })}
                >
                  <SelectTrigger className="h-7 w-[130px] text-xs">
                    <SelectValue placeholder="Set status..." />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map(s => <SelectItem key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 px-2 text-xs opacity-60 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => { e.stopPropagation(); setStatusLeadId(lead.id); }}
                >
                  Status
                </Button>
              )}

              {/* Log Call */}
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs gap-1 opacity-60 group-hover:opacity-100 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setLogCallLead(lead); }}
              >
                <Phone className="w-3 h-3" /> Call
              </Button>

              {/* Add Note */}
              <Button
                size="sm"
                variant="ghost"
                className="h-7 px-2 text-xs gap-1 opacity-60 group-hover:opacity-100 transition-opacity"
                onClick={(e) => { e.stopPropagation(); setNoteLeadId(noteLeadId === lead.id ? null : lead.id); }}
              >
                <StickyNote className="w-3 h-3" /> Note
              </Button>

              {/* Open drawer */}
              <Button
                size="sm"
                variant="ghost"
                className="h-7 w-7 p-0 opacity-60 group-hover:opacity-100 transition-opacity"
                onClick={(e) => { e.stopPropagation(); onLeadClick(lead); }}
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </Button>
            </div>
          </div>

          {/* Inline note textarea */}
          {noteLeadId === lead.id && (
            <div className="mt-3 flex items-start gap-2">
              <Textarea
                placeholder="Add a note about this lead..."
                value={noteText}
                onChange={e => setNoteText(e.target.value)}
                rows={2}
                className="text-xs"
                onClick={e => e.stopPropagation()}
              />
              <div className="flex flex-col gap-1">
                <Button
                  size="sm"
                  className="h-7 text-xs"
                  disabled={!noteText.trim() || noteMut.isPending}
                  onClick={(e) => { e.stopPropagation(); noteMut.mutate({ lead, note: noteText.trim() }); }}
                >
                  {noteMut.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Save'}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 w-7 p-0"
                  onClick={(e) => { e.stopPropagation(); setNoteLeadId(null); setNoteText(''); }}
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            </div>
          )}

          {/* Loading indicator for status change */}
          {statusMut.isPending && statusLeadId === lead.id && (
            <div className="mt-2 flex items-center gap-2 text-xs text-muted-foreground">
              <Loader2 className="w-3 h-3 animate-spin" /> Updating status...
            </div>
          )}
        </Card>
      ))}

      {/* Log Call Modal */}
      {logCallLead && (
        <RepLogCallModal
          lead={logCallLead}
          rep={rep}
          userEmail={userEmail}
          subscriberEmail={subscriberEmail}
          isOpen={!!logCallLead}
          onClose={() => setLogCallLead(null)}
        />
      )}
    </div>
  );
}