import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle2, XCircle, Loader2, ExternalLink, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export default function RepCalendarSync() {
  const { user } = useCurrentUser();
  const [connecting, setConnecting] = useState(false);

  // Google Calendar connection status
  const { data: gcalStatus, isLoading: gcalLoading, refetch: refetchGcal } = useQuery({
    queryKey: ['gcal-status', user?.email],
    queryFn: async () => {
      const res = await base44.functions.invoke('getGoogleCalendarStatus', {});
      return res.data;
    },
    enabled: !!user?.email,
    retry: false,
  });

  // Handle Google Calendar connect
  const handleConnectGcal = async () => {
    setConnecting(true);
    try {
      const res = await base44.functions.invoke('googleCalendarAuth', { redirect: '/rep-portal' });
      const url = res.data?.authorization_url;
      if (url) {
        window.open(url, '_blank');
        toast.info('Complete the Google authorization in the new tab, then return here.');
      }
    } catch (err) {
      toast.error('Failed to start Google Calendar connection');
    } finally {
      setConnecting(false);
    }
  };

  // Handle Google Calendar disconnect
  const handleDisconnectGcal = async () => {
    try {
      await base44.functions.invoke('disconnectGoogleCalendar', {});
      toast.success('Google Calendar disconnected');
      refetchGcal();
    } catch (err) {
      toast.error('Failed to disconnect');
    }
  };

  // Re-check Google Calendar status when window regains focus (after OAuth completes in other tab)
  useEffect(() => {
    const onFocus = () => refetchGcal();
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [refetchGcal]);

  const gcalConnected = gcalStatus?.connected === true;

  return (
    <Card className="border-border">
      <CardContent className="py-3.5 space-y-3">
        <div className="flex items-center gap-2 text-sm font-semibold">
          <RefreshCw className="w-4 h-4 text-primary" />
          Calendar Sync
        </div>

        {/* Google Calendar (Push direction) */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            {gcalLoading ? (
              <Loader2 className="w-4 h-4 text-muted-foreground animate-spin shrink-0" />
            ) : gcalConnected ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            ) : (
              <XCircle className="w-4 h-4 text-muted-foreground shrink-0" />
            )}
            <div className="min-w-0">
              <p className="text-sm font-medium">Google Calendar</p>
              <p className="text-xs text-muted-foreground truncate">
                {gcalConnected
                  ? 'AI appointments auto-push to your calendar'
                  : 'Connect to sync appointments to your calendar'}
              </p>
            </div>
          </div>
          {gcalConnected ? (
            <Button size="sm" variant="outline" className="h-7 text-xs shrink-0" onClick={handleDisconnectGcal}>
              Disconnect
            </Button>
          ) : (
            <Button
              size="sm"
              variant="outline"
              className="h-7 text-xs gap-1 shrink-0"
              onClick={handleConnectGcal}
              disabled={connecting}
            >
              {connecting ? <Loader2 className="w-3 h-3 animate-spin" /> : <ExternalLink className="w-3 h-3" />}
              Connect
            </Button>
          )}
        </div>


      </CardContent>
    </Card>
  );
}