import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { ShieldCheck, Mail, Loader2, AlertCircle, CheckCircle2, LogOut } from 'lucide-react';
import { toast } from 'sonner';

export default function ForcedPasswordReset({ onComplete }) {
  const { logout } = useAuth();
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const sendLink = async () => {
    setSending(true);
    setError('');
    try {
      const res = await base44.functions.invoke('verifyRepPortalAccess', {
        action: 'send_forced_reset_email',
      });
      if (res.data?.error) throw new Error(res.data.error);
      setSent(true);
      // Clear the gate so the rep isn't looped back here after they set their password via email.
      onComplete?.();
    } catch (err) {
      setError(err.message || 'Could not send the setup email. Please try again.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="relative fixed inset-0 flex items-center justify-center overflow-hidden bg-background">
      {/* Background glow + grid */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 animate-pulse rounded-full bg-primary/20 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              'linear-gradient(to right, hsl(var(--primary)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--primary)) 1px, transparent 1px)',
            backgroundSize: '48px 48px',
          }}
        />
      </div>

      {/* Brand card */}
      <div className="relative z-10 w-full max-w-md px-6">
        <div className="flex flex-col items-center rounded-2xl border border-border/60 bg-card/80 p-10 shadow-2xl backdrop-blur-xl">
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-xl bg-primary text-2xl font-extrabold text-primary-foreground shadow-lg shadow-primary/30">
            A
          </div>

          <h1 className="text-center font-poppins text-3xl font-extrabold tracking-tight text-foreground">
            Set Your New Password
          </h1>
          <div className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            Security Update Required
          </div>

          {sent ? (
            <>
              <div className="mt-6 flex h-12 w-12 items-center justify-center rounded-full bg-emerald-500/15">
                <CheckCircle2 className="h-7 w-7 text-emerald-500" />
              </div>
              <p className="mt-4 text-center text-sm text-muted-foreground leading-relaxed">
                We sent a secure "Set your password" link to your email. Open it, choose your new
                password, then sign out and log back in with it.
              </p>
              <Button
                size="lg"
                variant="outline"
                className="mt-6 w-full"
                onClick={() => logout('/rep-login')}
              >
                <LogOut className="h-4 w-4" /> Sign Out
              </Button>
            </>
          ) : (
            <>
              <p className="mt-4 text-center text-xs text-muted-foreground leading-relaxed">
                For your security, you must set a new password before accessing the portal. We'll
                email you a secure link to choose it — no old password needed.
              </p>

              <Button
                size="lg"
                className="mt-6 w-full text-base font-semibold shadow-lg shadow-primary/30"
                disabled={sending}
                onClick={sendLink}
              >
                {sending ? (
                  <><Loader2 className="h-5 w-5 animate-spin" /> Sending…</>
                ) : (
                  <><Mail className="h-5 w-5" /> Send Me a Setup Link</>
                )}
              </Button>

              {error && (
                <div className="mt-3 flex items-center gap-1.5 text-xs text-destructive">
                  <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                  {error}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}