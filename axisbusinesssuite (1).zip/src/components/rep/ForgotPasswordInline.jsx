import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowLeft, Mail, Loader2, CheckCircle2 } from 'lucide-react';

// Inline "Forgot Password?" panel — slides down under the Sign In button.
// On submit it asks the backend to email a reset link (pointing at the
// platform's forgot-password page), then swaps in a confirmation message.
export default function ForgotPasswordInline() {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) { setError('Enter your email'); return; }
    setSending(true);
    setError('');
    try {
      const res = await base44.functions.invoke('hrAccessControl', { action: 'public_send_reset', email: email.trim() });
      if (res.data?.error) throw new Error(res.data.error);
      setSent(true);
    } catch (err) {
      setError(err.message || 'Could not send reset link');
    } finally {
      setSending(false);
    }
  };

  if (!open) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="mt-4 text-xs text-muted-foreground hover:text-primary transition-colors"
      >
        Forgot password?
      </button>
    );
  }

  return (
    <div className="mt-4 w-full">
      {sent ? (
        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3 text-center">
          <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto mb-1.5" />
          <p className="text-sm font-medium text-emerald-400">Check your email</p>
          <p className="text-xs text-muted-foreground mt-1">
            If an account exists for {email}, a password reset link is on its way.
          </p>
          <button
            type="button"
            onClick={() => { setOpen(false); setSent(false); setEmail(''); }}
            className="mt-3 text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1"
          >
            <ArrowLeft className="w-3 h-3" /> Back to sign in
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="rounded-lg border border-border bg-muted/30 p-3">
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-2"
          >
            <ArrowLeft className="w-3 h-3" /> Back
          </button>
          <label className="text-xs font-medium text-foreground flex items-center gap-1.5 mb-1.5">
            <Mail className="w-3.5 h-3.5" /> Enter your email
          </label>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@company.com"
            className="h-9"
            autoFocus
          />
          {error && <p className="text-xs text-destructive mt-1.5">{error}</p>}
          <Button type="submit" size="sm" className="w-full mt-2.5" disabled={sending}>
            {sending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Sending…</> : 'Send Reset Link'}
          </Button>
        </form>
      )}
    </div>
  );
}