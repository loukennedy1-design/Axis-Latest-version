import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  GraduationCap, Phone, Shield, Zap, Target, TrendingUp,
  CheckCircle2, Lock, ChevronRight, Clock, Trophy, Loader2,
  RotateCcw, BookOpen, Award, MessageSquare, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

const SALES_MODULES = [
  {
    id: 'cold_calling_101',
    icon: Phone,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    title: 'Cold Calling Fundamentals',
    duration: '15 min',
    description: 'Master the psychology and structure of a winning cold call.',
    lessons: [
      { title: 'The first 10 seconds: your opening hook', duration: '3 min' },
      { title: 'Pattern interrupts that get attention', duration: '2 min' },
      { title: 'Tone, pace, and confidence on the phone', duration: '3 min' },
      { title: 'The transition from opener to discovery', duration: '3 min' },
      { title: 'Handling the "not interested" brush-off', duration: '4 min' },
    ],
    keyTakeaways: [
      'Your first 10 seconds determine the entire call outcome',
      'Use a pattern interrupt — never start with "How are you today?"',
      'Speak 20% slower than normal conversation pace',
      'Always transition to a question after your opener',
      '"Not interested" is a reflex, not a real answer — pivot with curiosity',
    ],
    quiz: [
      { q: 'What should your cold call opening do?', options: ['Ask how their day is going', 'Deliver a pattern interrupt and a reason for calling', 'Read your entire script', 'Ask for permission to speak'], answer: 1 },
      { q: 'How fast should you speak compared to normal conversation?', options: ['20% faster', 'Same speed', '20% slower', 'It doesn\'t matter'], answer: 2 },
      { q: 'What does "not interested" usually mean on a cold call?', options: ['They truly aren\'t interested', 'They want you to hang up', 'It\'s a reflex, not a real answer', 'They\'re busy'], answer: 2 },
    ],
  },
  {
    id: 'objection_handling',
    icon: Shield,
    color: 'text-amber-500',
    bgColor: 'bg-amber-500/10',
    title: 'Objection Handling Mastery',
    duration: '18 min',
    description: 'Turn every "no" into a "maybe" with proven frameworks.',
    lessons: [
      { title: 'The 4 most common objections decoded', duration: '3 min' },
      { title: 'Feel-Felt-Found technique', duration: '3 min' },
      { title: 'Acknowledge & Pivot method', duration: '3 min' },
      { title: 'Isolating the real objection', duration: '4 min' },
      { title: 'When to challenge vs. when to yield', duration: '5 min' },
    ],
    keyTakeaways: [
      'Price, timing, authority, and need are the 4 core objections',
      'Always acknowledge before pivoting — never argue',
      'Feel-Felt-Found: "I understand how you feel, others felt the same, what they found was..."',
      'Isolate: "Aside from [objection], is there anything else holding you back?"',
      'Challenge only when you\'ve earned trust — yield when you haven\'t',
    ],
    quiz: [
      { q: 'What are the 4 most common objections?', options: ['Price, timing, authority, need', 'Weather, mood, budget, time', 'Color, size, shape, weight', 'Yes, no, maybe, later'], answer: 0 },
      { q: 'What should you always do before pivoting an objection?', options: ['Argue', 'Acknowledge it', 'Hang up', 'Lower the price'], answer: 1 },
      { q: 'In Feel-Felt-Found, what does "Found" refer to?', options: ['Finding the product', 'What others discovered after trying', 'Finding a cheaper option', 'Finding lost time'], answer: 1 },
    ],
  },
  {
    id: 'discovery_mastery',
    icon: Target,
    color: 'text-emerald-500',
    bgColor: 'bg-emerald-500/10',
    title: 'Discovery & Qualification',
    duration: '16 min',
    description: 'Ask the right questions to uncover real pain and buying intent.',
    lessons: [
      { title: 'Open vs closed questions: when to use each', duration: '3 min' },
      { title: 'The BANT framework explained', duration: '3 min' },
      { title: 'Pain-point discovery questions that work', duration: '4 min' },
      { title: 'Active listening on the phone', duration: '3 min' },
      { title: 'Quantifying the cost of inaction', duration: '3 min' },
    ],
    keyTakeaways: [
      'Open questions start with What, How, Tell me about — never Do or Are',
      'BANT = Budget, Authority, Need, Timeline',
      'Ask "What\'s that costing you?" to quantify pain',
      'Silence is a tool — wait 3 seconds after they finish speaking',
      'If you can\'t quantify the cost of doing nothing, you can\'t sell the solution',
    ],
    quiz: [
      { q: 'What does BANT stand for?', options: ['Buy, Ask, Negotiate, Talk', 'Budget, Authority, Need, Timeline', 'Before, After, Now, Tomorrow', 'Business, Account, Name, Title'], answer: 1 },
      { q: 'How should you start open-ended questions?', options: ['Do you...?', 'Are you...?', 'What or How...', 'Can you...?'], answer: 2 },
      { q: 'How long should you wait after a prospect finishes speaking?', options: ['Immediately jump in', '1 second', '3 seconds', '10 seconds'], answer: 2 },
    ],
  },
  {
    id: 'closing_techniques',
    icon: TrendingUp,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10',
    title: 'Closing Techniques That Convert',
    duration: '14 min',
    description: 'Seal the deal with natural, pressure-free closing strategies.',
    lessons: [
      { title: 'The assumptive close', duration: '3 min' },
      { title: 'The summary close', duration: '2 min' },
      { title: 'The alternative choice close', duration: '3 min' },
      { title: 'Creating urgency without being pushy', duration: '3 min' },
      { title: 'Handling last-minute hesitation', duration: '3 min' },
    ],
    keyTakeaways: [
      'The assumptive close: "So shall we get you set up for next week?"',
      'Summarize the value before asking for the commitment',
      'Offer two options, not yes/no: "Would Tuesday or Thursday work?"',
      'Real urgency comes from the cost of inaction, not fake scarcity',
      'Last-minute hesitation = unaddressed objection — go back to discovery',
    ],
    quiz: [
      { q: 'What is the assumptive close?', options: ['Asking "Do you want to buy?"', 'Assuming the sale is made and discussing next steps', 'Assuming they\'ll say no', 'Asking for a discount'], answer: 1 },
      { q: 'What should you do before asking for the commitment?', options: ['Lower the price', 'Summarize the value', 'Change the subject', 'End the call'], answer: 1 },
      { q: 'What does last-minute hesitation usually indicate?', options: ['They\'re ready to buy', 'An unaddressed objection', 'They want to think about it', 'Nothing important'], answer: 1 },
    ],
  },
  {
    id: 'follow_up_strategies',
    icon: MessageSquare,
    color: 'text-cyan-500',
    bgColor: 'bg-cyan-500/10',
    title: 'Follow-Up & Nurture Strategies',
    duration: '12 min',
    description: 'Most deals close on follow-up — learn to persist without pestering.',
    lessons: [
      { title: 'The fortune is in the follow-up: the stats', duration: '2 min' },
      { title: 'Multi-channel follow-up: call, email, SMS', duration: '3 min' },
      { title: 'Value-first follow-up messages', duration: '3 min' },
      { title: 'When to hold \'em, when to fold \'em', duration: '2 min' },
      { title: 'Building a cadence that works', duration: '2 min' },
    ],
    keyTakeaways: [
      '80% of sales require 5+ touchpoints — most reps give up after 2',
      'Vary your channels: don\'t just call, mix in email and SMS',
      'Every follow-up must add value, not just "checking in"',
      'A 7-touch cadence over 2 weeks is the sweet spot',
      'Set a clear disqualification criteria — don\'t chase forever',
    ],
    quiz: [
      { q: 'How many touchpoints do 80% of sales require?', options: ['1-2', '3-4', '5 or more', '10+'], answer: 2 },
      { q: 'What should every follow-up message include?', options: ['Just "checking in"', 'Added value', 'A discount', 'An ultimatum'], answer: 1 },
      { q: 'What is the recommended touchpoint cadence?', options: ['All in one day', '7 touches over 2 weeks', 'Once a month', 'Whenever you feel like it'], answer: 1 },
    ],
  },
  {
    id: 'mindset_resilience',
    icon: Zap,
    color: 'text-red-500',
    bgColor: 'bg-red-500/10',
    title: 'Sales Mindset & Resilience',
    duration: '10 min',
    description: 'Build the mental toughness to thrive in sales.',
    lessons: [
      { title: 'Rejection is redirection: reframing "no"', duration: '2 min' },
      { title: 'Activity vs outcome: controlling what you can', duration: '2 min' },
      { title: 'The daily success routine of top closers', duration: '3 min' },
      { title: 'Burnout prevention and energy management', duration: '3 min' },
    ],
    keyTakeaways: [
      'Every "no" gets you closer to "yes" — it\'s a numbers game',
      'Focus on activity (calls made), not outcome (deals closed)',
      'Top closers start with a morning routine: review goals, visualize, warm up',
      'Take breaks every 90 minutes — phone fatigue is real',
      'Track your ratios: know your calls-to-appointments-to-closes',
    ],
    quiz: [
      { q: 'What should you focus on controlling?', options: ['Whether prospects buy', 'Your activity (calls made)', 'The weather', 'The economy'], answer: 1 },
      { q: 'How often should you take breaks during calling?', options: ['Never', 'Every 30 minutes', 'Every 90 minutes', 'Once a day'], answer: 2 },
      { q: 'What should you track to improve?', options: ['Your feelings', 'Your ratios (calls → appts → closes)', 'Your competitor\'s prices', 'Nothing'], answer: 1 },
    ],
  },
];

const PROGRESS_KEY = 'rep_sales_training_progress';

function loadProgress() {
  try {
    return JSON.parse(localStorage.getItem(PROGRESS_KEY) || '{}');
  } catch {
    return {};
  }
}

function saveProgress(progress) {
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
}

export default function RepSalesTraining({ rep }) {
  const [progress, setProgress] = useState({});
  const [activeModule, setActiveModule] = useState(null);
  const [view, setView] = useState('curriculum'); // curriculum | lesson | quiz | result
  const [quizAnswers, setQuizAnswers] = useState({});
  const [quizScore, setQuizScore] = useState(null);
  const [aiTip, setAiTip] = useState('');
  const [loadingTip, setLoadingTip] = useState(false);

  useEffect(() => {
    setProgress(loadProgress());
  }, []);

  const updateProgress = (moduleId, data) => {
    const updated = { ...progress, [moduleId]: { ...progress[moduleId], ...data } };
    setProgress(updated);
    saveProgress(updated);
  };

  const markLessonComplete = (moduleId) => {
    updateProgress(moduleId, { lessonCompleted: true });
  };

  const startQuiz = (moduleId) => {
    setActiveModule(moduleId);
    setView('quiz');
    setQuizAnswers({});
    setQuizScore(null);
  };

  const submitQuiz = () => {
    const module = SALES_MODULES.find(m => m.id === activeModule);
    if (!module) return;
    let correct = 0;
    module.quiz.forEach((q, i) => {
      if (quizAnswers[i] === q.answer) correct++;
    });
    const score = Math.round((correct / module.quiz.length) * 100);
    setQuizScore(score);
    setView('result');
    if (score >= 70) {
      updateProgress(activeModule, { completed: true, score });
      toast.success(`Module complete! Score: ${score}%`);
    } else {
      toast.error(`Score: ${score}% — you need 70% to pass. Review and retry!`);
    }
  };

  const resetModule = (moduleId) => {
    const updated = { ...progress };
    delete updated[moduleId];
    setProgress(updated);
    saveProgress(updated);
    setView('curriculum');
    setActiveModule(null);
  };

  const generateTip = async (module) => {
    setLoadingTip(true);
    setAiTip('');
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a world-class sales trainer. Give me one actionable, specific pro tip for: "${module.title}".
The tip should be something a sales rep can apply immediately on their next call. Keep it under 3 sentences. Be specific and practical.`,
      });
      setAiTip(res);
    } catch (e) {
      toast.error('Failed to generate tip');
    } finally {
      setLoadingTip(false);
    }
  };

  const completedCount = SALES_MODULES.filter(m => progress[m.id]?.completed).length;
  const overallProgress = Math.round((completedCount / SALES_MODULES.length) * 100);

  // CURRICULUM VIEW
  if (view === 'curriculum' || !activeModule) {
    return (
      <div className="space-y-4">
        {/* Header */}
        <Card className="border-primary/20 bg-gradient-to-br from-primary/8 via-card to-purple-500/5">
          <CardContent className="py-5">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="w-14 h-14 rounded-xl bg-primary/15 flex items-center justify-center">
                <GraduationCap className="w-7 h-7 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-lg font-bold">Sales Training Academy</h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {completedCount === SALES_MODULES.length
                    ? '🏆 All modules complete! You\'re a sales champion.'
                    : `${completedCount} of ${SALES_MODULES.length} modules completed`}
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-primary">{overallProgress}%</p>
                <Progress value={overallProgress} className="w-24 h-1.5 mt-1" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Module cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SALES_MODULES.map((module, idx) => {
            const modProgress = progress[module.id];
            const isCompleted = modProgress?.completed;
            const isLocked = idx > 0 && !progress[SALES_MODULES[idx - 1].id]?.completed && !isCompleted;
            const Icon = module.icon;

            return (
              <Card
                key={module.id}
                className={`relative overflow-hidden transition-all ${
                  isLocked ? 'opacity-50' : 'hover:border-primary/30 cursor-pointer'
                } ${isCompleted ? 'border-emerald-500/30' : ''}`}
                onClick={() => !isLocked && (setActiveModule(module.id), setView('lesson'))}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-lg ${module.bgColor} flex items-center justify-center shrink-0`}>
                      <Icon className={`w-5 h-5 ${module.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-muted-foreground">MODULE {idx + 1}</span>
                        {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                        {isLocked && <Lock className="w-3.5 h-3.5 text-muted-foreground" />}
                      </div>
                      <p className="font-semibold text-sm mt-0.5">{module.title}</p>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{module.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className="text-[10px] gap-0.5">
                          <Clock className="w-2.5 h-2.5" /> {module.duration}
                        </Badge>
                        {isCompleted && (
                          <Badge variant="outline" className="text-[10px] bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                            Score: {modProgress.score}%
                          </Badge>
                        )}
                      </div>
                    </div>
                    {!isLocked && <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Certificate */}
        {completedCount === SALES_MODULES.length && (
          <Card className="border-amber-500/30 bg-gradient-to-br from-amber-500/10 to-card">
            <CardContent className="py-6 text-center">
              <Trophy className="w-12 h-12 text-amber-500 mx-auto mb-2" />
              <p className="font-bold text-lg">Sales Certification Earned!</p>
              <p className="text-sm text-muted-foreground mt-1">
                You've completed all {SALES_MODULES.length} training modules. You're ready to close!
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  const module = SALES_MODULES.find(m => m.id === activeModule);
  if (!module) return null;
  const Icon = module.icon;

  // LESSON VIEW
  if (view === 'lesson') {
    return (
      <div className="space-y-4 max-w-3xl">
        <Button variant="ghost" size="sm" className="gap-1 text-xs" onClick={() => { setView('curriculum'); setActiveModule(null); }}>
          <ChevronRight className="w-3.5 h-3.5 rotate-180" /> Back to Curriculum
        </Button>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl ${module.bgColor} flex items-center justify-center`}>
                <Icon className={`w-6 h-6 ${module.color}`} />
              </div>
              <div>
                <CardTitle className="text-base">{module.title}</CardTitle>
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                  <Clock className="w-3 h-3" /> {module.duration} · {module.lessons.length} lessons
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{module.description}</p>

            {/* Lessons */}
            <div className="space-y-2">
              <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Lessons</p>
              {module.lessons.map((lesson, i) => (
                <div key={i} className="flex items-center gap-3 rounded-lg border border-border bg-card p-3">
                  <div className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{lesson.title}</p>
                  </div>
                  <span className="text-[10px] text-muted-foreground shrink-0">{lesson.duration}</span>
                </div>
              ))}
            </div>

            {/* Key Takeaways */}
            <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-primary mb-2 flex items-center gap-1">
                <BookOpen className="w-3.5 h-3.5" /> Key Takeaways
              </p>
              <ul className="space-y-1.5">
                {module.keyTakeaways.map((takeaway, i) => (
                  <li key={i} className="text-xs text-foreground/80 flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                    {takeaway}
                  </li>
                ))}
              </ul>
            </div>

            {/* AI Pro Tip */}
            <div className="rounded-lg border border-purple-500/20 bg-purple-500/5 p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-purple-500 mb-2 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> AI Pro Tip
              </p>
              {aiTip ? (
                <p className="text-xs text-foreground/80">{aiTip}</p>
              ) : loadingTip ? (
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="w-3 h-3 animate-spin" /> Generating tip...
                </div>
              ) : (
                <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => generateTip(module)}>
                  <Sparkles className="w-3 h-3" /> Get a pro tip
                </Button>
              )}
            </div>

            {/* Continue button */}
            <Button
              className="w-full gap-2"
              onClick={() => {
                markLessonComplete(module.id);
                startQuiz(module.id);
              }}
            >
              {progress[module.id]?.lessonCompleted ? 'Retake Quiz' : 'Continue to Quiz'}
              <ChevronRight className="w-4 h-4" />
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // QUIZ VIEW
  if (view === 'quiz') {
    return (
      <div className="space-y-4 max-w-2xl">
        <Button variant="ghost" size="sm" className="gap-1 text-xs" onClick={() => setView('lesson')}>
          <ChevronRight className="w-3.5 h-3.5 rotate-180" /> Back to Lesson
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Award className="w-4 h-4 text-primary" />
              {module.title} — Knowledge Check
            </CardTitle>
            <p className="text-xs text-muted-foreground">Score 70% or higher to complete this module.</p>
          </CardHeader>
          <CardContent className="space-y-5">
            {module.quiz.map((q, qi) => (
              <div key={qi}>
                <p className="text-sm font-medium mb-2">{qi + 1}. {q.q}</p>
                <div className="space-y-1.5">
                  {q.options.map((opt, oi) => (
                    <button
                      key={oi}
                      onClick={() => setQuizAnswers({ ...quizAnswers, [qi]: oi })}
                      className={`w-full text-left text-xs rounded-lg border px-3 py-2 transition-colors ${
                        quizAnswers[qi] === oi
                          ? 'border-primary bg-primary/10 text-primary font-medium'
                          : 'border-border hover:border-primary/30'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <Button
              className="w-full gap-2"
              disabled={Object.keys(quizAnswers).length < module.quiz.length}
              onClick={submitQuiz}
            >
              Submit Quiz
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // RESULT VIEW
  if (view === 'result') {
    const passed = quizScore >= 70;
    return (
      <div className="space-y-4 max-w-md mx-auto">
        <Card className={passed ? 'border-emerald-500/30' : 'border-amber-500/30'}>
          <CardContent className="py-8 text-center">
            {passed ? (
              <CheckCircle2 className="w-14 h-14 text-emerald-500 mx-auto mb-3" />
            ) : (
              <RotateCcw className="w-14 h-14 text-amber-500 mx-auto mb-3" />
            )}
            <p className="text-3xl font-bold">{quizScore}%</p>
            <p className="text-sm font-medium mt-1">
              {passed ? 'Module Complete!' : 'Almost there!'}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              {passed
                ? 'You\'ve mastered this module. Keep it up!'
                : 'You need 70% to pass. Review the takeaways and try again.'}
            </p>

            <div className="flex flex-col gap-2 mt-5">
              {passed ? (
                <Button className="w-full gap-2" onClick={() => { setView('curriculum'); setActiveModule(null); }}>
                  <ChevronRight className="w-4 h-4" /> Continue to Next Module
                </Button>
              ) : (
                <Button className="w-full gap-2" onClick={() => { setView('lesson'); setQuizAnswers({}); }}>
                  <BookOpen className="w-4 h-4" /> Review Lesson
                </Button>
              )}
              <Button variant="ghost" size="sm" className="text-xs" onClick={() => { setView('curriculum'); setActiveModule(null); }}>
                Back to Curriculum
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}