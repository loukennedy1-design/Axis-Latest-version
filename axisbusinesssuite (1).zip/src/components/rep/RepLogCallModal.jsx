import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Phone } from 'lucide-react';
import { toast } from 'sonner';

const OUTCOMES = [
  { value: 'appointment_set', label: 'Appointment Set' },
  { value: 'callback_requested', label: 'Callback Requested' },
  { value: 'not_interested', label: 'Not Interested' },
  { value: 'wrong_number', label: 'Wrong Number' },
  { value: 'dnc_requested', label: 'DNC Requested' },
  { value: 'voicemail_left', label: 'Voicemail Left' },
  { value: 'other', label: 'Other' },
];

export default function RepLogCallModal({ lead, rep, userEmail, subscriberEmail, isOpen, onClose }) {
  const [outcome, setOutcome] = useState('callback_requested');
  const [duration, setDuration] = useState('5');
  const [notes, setNotes] = useState('');
  const qc = useQueryClient();

  const logCallMut = useMutation({
    mutationFn: async () => {
      const owner = subscriberEmail || rep?.owner || userEmail;
      await base44.entities.CallLog.create({
        lead_id: lead.id,
        lead_name: `${lead.first_name} ${lead.last_name}`.trim(),
        phone_number: lead.phone,
        direction: 'outbound',
        status: 'completed',
        outcome,
        duration_seconds: parseInt(duration) * 60 || 0,
        called_by: userEmail,
        owner,
        transcript: notes,
        ai_summary: notes || `Call logged — ${outcome.replace(/_/g, ' ')}`,
        consent_verified: lead.consent_given || false,
      });
      // Update lead's last_called and call_attempts
      await base44.entities.Lead.update(lead.id, {
        last_called: new Date().toISOString(),
        call_attempts: (lead.call_attempts || 0) + 1,
      });
    },
    onSuccess: () => {
      toast.success('Call logged successfully');
      qc.invalidateQueries({ queryKey: ['rep-calls', userEmail] });
      qc.invalidateQueries({ queryKey: ['rep-leads', userEmail] });
      qc.invalidateQueries({ queryKey: ['rep-activity'] });
      setOutcome('callback_requested');
      setDuration('5');
      setNotes('');
      onClose();
    },
    onError: (e) => toast.error('Failed to log call: ' + e.message),
  });

  if (!lead) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Phone className="w-4 h-4 text-primary" /> Log Call
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="rounded-lg bg-muted/40 p-3">
            <p className="font-medium text-sm">{lead.first_name} {lead.last_name}</p>
            <p className="text-xs text-muted-foreground font-mono">{lead.phone}</p>
            {lead.company && <p className="text-xs text-muted-foreground">{lead.company}</p>}
          </div>
          <div>
            <Label>Outcome</Label>
            <Select value={outcome} onValueChange={setOutcome}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {OUTCOMES.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Duration (minutes)</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {['1', '3', '5', '10', '15', '20', '30', '45', '60'].map(d => (
                  <SelectItem key={d} value={d}>{d} min</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Call Notes</Label>
            <Textarea
              placeholder="What was discussed? Key takeaways?"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              rows={3}
            />
          </div>
          <Button
            className="w-full gap-2"
            onClick={() => logCallMut.mutate()}
            disabled={logCallMut.isPending}
          >
            {logCallMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Phone className="w-4 h-4" />}
            Log Call
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}