import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Clock, CalendarClock, Loader2, Video } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_COLORS = {
  scheduled: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  confirmed: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  completed: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  cancelled: 'bg-red-500/10 text-red-600 border-red-500/20',
  no_show: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const APPT_STATUSES = ['scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'];

function toLocalInputValue(isoDate) {
  if (!isoDate) return '';
  const d = new Date(isoDate);
  const tzOffset = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
}

export default function RepAppointmentsPanel({ userEmail, onLeadClick }) {
  const [rescheduleAppt, setRescheduleAppt] = useState(null);
  const [newDate, setNewDate] = useState('');
  const qc = useQueryClient();
  const queryKey = ['rep-appts', userEmail];

  const { data: appointments = [], isLoading } = useQuery({
    queryKey,
    queryFn: () => base44.entities.Appointment.filter({ assigned_to: userEmail }),
    enabled: !!userEmail,
    staleTime: 30000,
    refetchInterval: 60000,
  });

  const rescheduleMut = useMutation({
    mutationFn: ({ appt, dateStr }) => base44.entities.Appointment.update(appt.id, {
      scheduled_date: new Date(dateStr).toISOString(),
    }),
    onMutate: async ({ appt, dateStr }) => {
      await qc.cancelQueries({ queryKey });
      const previous = qc.getQueryData(queryKey);
      qc.setQueryData(queryKey, (old) =>
        old.map(a => a.id === appt.id ? { ...a, scheduled_date: new Date(dateStr).toISOString() } : a)
      );
      return { previous };
    },
    onError: (err, vars, context) => {
      qc.setQueryData(queryKey, context.previous);
      toast.error('Failed to reschedule — rolled back');
    },
    onSuccess: () => {
      toast.success('Appointment rescheduled');
      qc.invalidateQueries({ queryKey });
      setRescheduleAppt(null);
      setNewDate('');
    },
  });

  const statusMut = useMutation({
    mutationFn: ({ appt, status }) => base44.entities.Appointment.update(appt.id, { status }),
    onMutate: async ({ appt, status }) => {
      await qc.cancelQueries({ queryKey });
      const previous = qc.getQueryData(queryKey);
      qc.setQueryData(queryKey, (old) =>
        old.map(a => a.id === appt.id ? { ...a, status } : a)
      );
      return { previous };
    },
    onError: (err, vars, context) => {
      qc.setQueryData(queryKey, context.previous);
      toast.error('Failed to update status — rolled back');
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey });
    },
  });

  const sorted = [...appointments].sort((a, b) => {
    const aDate = new Date(a.scheduled_date || 0);
    const bDate = new Date(b.scheduled_date || 0);
    return bDate - aDate;
  });

  if (isLoading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  if (sorted.length === 0) {
    return (
      <Card className="p-10 text-center border-dashed">
        <Calendar className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
        <p className="text-sm text-muted-foreground">No appointments scheduled</p>
      </Card>
    );
  }

  return (
    <div className="space-y-2">
      {sorted.map(appt => {
        const isPast = appt.scheduled_date && new Date(appt.scheduled_date) < new Date();
        const isActive = appt.status === 'scheduled' || appt.status === 'confirmed';

        return (
          <Card key={appt.id} className="p-3.5 border-border hover:border-primary/30 transition-colors">
            <div className="flex items-start gap-3">
              {/* Date block */}
              <div className="shrink-0 w-12 text-center">
                <div className="rounded-lg bg-primary/10 border border-primary/20 py-1">
                  <p className="text-[10px] text-primary font-semibold uppercase">
                    {appt.scheduled_date ? format(new Date(appt.scheduled_date), 'MMM') : '—'}
                  </p>
                  <p className="text-lg font-bold text-primary leading-none">
                    {appt.scheduled_date ? format(new Date(appt.scheduled_date), 'd') : '—'}
                  </p>
                </div>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  {appt.lead_name && (
                    <button
                      className="font-semibold text-sm text-foreground hover:text-primary"
                      onClick={() => onLeadClick?.({ id: appt.lead_id, first_name: appt.lead_name, phone: appt.lead_phone })}
                    >
                      {appt.lead_name}
                    </button>
                  )}
                  <Badge variant="outline" className={`text-[10px] capitalize ${STATUS_COLORS[appt.status] || ''}`}>
                    {appt.status?.replace(/_/g, ' ')}
                  </Badge>
                </div>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  {appt.scheduled_date && (
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {format(new Date(appt.scheduled_date), 'h:mm a')}
                    </span>
                  )}
                  <span>{appt.duration_minutes || 30} min</span>
                  {appt.lead_phone && <span className="font-mono">{appt.lead_phone}</span>}
                </div>
                {appt.notes && <p className="text-xs text-foreground/70 mt-1.5">{appt.notes}</p>}
                {appt.lead_email && (
                  <a href={`mailto:${appt.lead_email}`} className="text-xs text-primary hover:underline mt-1 inline-block">
                    {appt.lead_email}
                  </a>
                )}
              </div>

              {/* Actions */}
              <div className="shrink-0 flex flex-col gap-1.5 items-end">
                {isActive && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-7 px-2 text-xs gap-1"
                    onClick={() => {
                      setRescheduleAppt(appt);
                      setNewDate(toLocalInputValue(appt.scheduled_date));
                    }}
                  >
                    <CalendarClock className="w-3.5 h-3.5" /> Reschedule
                  </Button>
                )}
                <Select
                  value={appt.status}
                  onValueChange={(v) => statusMut.mutate({ appt, status: v })}
                >
                  <SelectTrigger className="h-7 w-[120px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {APPT_STATUSES.map(s => (
                      <SelectItem key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        );
      })}

      {/* Reschedule Modal */}
      <Dialog open={!!rescheduleAppt} onOpenChange={() => setRescheduleAppt(null)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarClock className="w-4 h-4 text-primary" /> Reschedule Appointment
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {rescheduleAppt?.lead_name && (
              <p className="text-sm font-medium">{rescheduleAppt.lead_name}</p>
            )}
            <div>
              <label className="text-sm font-medium mb-1.5 block">New Date & Time</label>
              <input
                type="datetime-local"
                value={newDate}
                onChange={e => setNewDate(e.target.value)}
                className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>
            <Button
              className="w-full gap-2"
              disabled={!newDate || rescheduleMut.isPending}
              onClick={() => rescheduleMut.mutate({ appt: rescheduleAppt, dateStr: newDate })}
            >
              {rescheduleMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CalendarClock className="w-4 h-4" />}
              Confirm Reschedule
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}