import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Loader2, ArrowRight, AlertCircle, ShieldCheck } from "lucide-react";

export default function RepPortalLoginWall() {
  const [email, setEmail] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [error, setError] = useState("");
  const [inviteSent, setInviteSent] = useState(false);

  const handleContinue = async (e) => {
    e.preventDefault();
    const trimmed = email.trim().toLowerCase();
    if (!trimmed) { setError("Enter your email address"); return; }
    setVerifying(true);
    setError("");
    try {
      const res = await base44.functions.invoke("verifyRepPortalAccess", {
        action: "check_email",
        email: trimmed,
      });
      if (res.data?.error) throw new Error(res.data.error);
      if (!res.data?.valid) {
        throw new Error("This email is not registered as a rep. Contact your administrator.");
      }
      if (res.data?.invited) {
        setInviteSent(true);
        return;
      }
      base44.auth.redirectToLogin("/rep-portal");
    } catch (err) {
      setError(err.message || "Could not verify email");
    } finally {
      setVerifying(false);
    }
  };

  return (
    <div className="relative fixed inset-0 flex items-center justify-center overflow-hidden bg-background">
      {/* Background glow + grid */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/2 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/2 animate-pulse rounded-full bg-primary/20 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(to right, hsl(var(--primary)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--primary)) 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />
      </div>

      {/* Brand card */}
      <div className="relative z-10 w-full max-w-md px-6">
        <div className="flex flex-col items-center rounded-2xl border border-border/60 bg-card/80 p-10 shadow-2xl backdrop-blur-xl">
          <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-xl bg-primary text-2xl font-extrabold text-primary-foreground shadow-lg shadow-primary/30">
            A
          </div>

          <h1 className="text-center font-poppins text-3xl font-extrabold tracking-tight text-foreground">
            Portal Log In
          </h1>
          <div className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            Company Use Only
          </div>

          {inviteSent ? (
            <div className="mt-6 w-full rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-5 text-center">
              <Mail className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-semibold text-emerald-400">Check Your Email</p>
              <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
                We sent an invitation to <span className="font-medium text-foreground">{email}</span>.
                Click the link in that email to set up your password, then come back here to log in.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-4"
                onClick={() => { setInviteSent(false); setEmail(""); }}
              >
                Back to Login
              </Button>
            </div>
          ) : (
          <>
          <form onSubmit={handleContinue} className="mt-6 w-full space-y-3">
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                className="pl-9"
                autoComplete="email"
                autoFocus
              />
            </div>

            {error && (
              <div className="flex items-center gap-1.5 text-xs text-destructive">
                <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                {error}
              </div>
            )}

            <Button
              type="submit"
              size="lg"
              className="w-full text-base font-semibold shadow-lg shadow-primary/30"
              disabled={verifying || !email.trim()}
            >
              {verifying ? (
                <><Loader2 className="h-5 w-5 animate-spin" /> Verifying…</>
              ) : (
                <>Continue <ArrowRight className="h-4 w-4" /></>
              )}
            </Button>
          </form>

          <p className="mt-4 text-center text-xs text-muted-foreground leading-relaxed">
            First time here? Just enter your email and you'll be prompted to set a password after signing in.
          </p>
          </>
          )}
        </div>
      </div>
    </div>
  );
}