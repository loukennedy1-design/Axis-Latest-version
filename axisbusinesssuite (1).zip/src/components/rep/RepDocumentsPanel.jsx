import React, { useState, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Upload, ExternalLink, Loader2, Plus, Trash2, FileUp, ShieldCheck, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const DOC_TYPES = [
  'offer_letter', 'contract', 'w9', 'i9', 'nda',
  'resume', 'certification', 'identification', 'tax_form',
  'beneficiary_form', 'policy_acknowledgment', 'other'
];

const DOC_TYPE_COLORS = {
  offer_letter: 'bg-blue-500/10 text-blue-600',
  contract: 'bg-purple-500/10 text-purple-600',
  w9: 'bg-amber-500/10 text-amber-600',
  i9: 'bg-amber-500/10 text-amber-600',
  nda: 'bg-red-500/10 text-red-600',
  resume: 'bg-emerald-500/10 text-emerald-600',
  certification: 'bg-cyan-500/10 text-cyan-600',
  identification: 'bg-orange-500/10 text-orange-600',
  tax_form: 'bg-rose-500/10 text-rose-600',
  beneficiary_form: 'bg-indigo-500/10 text-indigo-600',
  policy_acknowledgment: 'bg-slate-500/10 text-slate-600',
  other: 'bg-slate-500/10 text-slate-600',
};

const STATUS_COLORS = {
  pending_signature: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  signed: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  expired: 'bg-red-500/10 text-red-600 border-red-500/20',
  archived: 'bg-slate-500/10 text-slate-600 border-slate-500/20',
  submitted: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  under_review: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
};

const emptyForm = { title: '', doc_type: 'resume', notes: '', file_url: '' };

export default function RepDocumentsPanel({ rep }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef(null);
  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const { data: docs = [], isLoading } = useQuery({
    queryKey: ['rep-documents', user?.email],
    queryFn: () => base44.entities.HRDocument.filter({ employee_email: user?.email }),
    enabled: !!user?.email,
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'HRDocument', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rep-documents'] });
      setDialogOpen(false);
      setForm(emptyForm);
      toast.success('Document uploaded successfully');
    },
    onError: (err) => toast.error(`Failed to upload: ${err?.message || 'Unknown error'}`),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.HRDocument.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['rep-documents'] });
      toast.success('Document deleted');
    },
  });

  const handleUpload = async (file) => {
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File too large — max 10MB');
      return;
    }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setForm(p => ({ ...p, file_url, title: p.title || file.name.replace(/\.[^.]+$/, '') }));
      toast.success('File uploaded');
    } catch (err) {
      toast.error('Upload failed: ' + (err?.message || 'Unknown error'));
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleUpload(file);
  };

  const handleSave = () => {
    if (!form.title || !form.file_url) {
      toast.error('Please provide a title and upload a file');
      return;
    }
    createMut.mutate({
      ...form,
      employee_id: rep?.id || user?.email,
      employee_name: rep?.name || user?.full_name || '',
      employee_email: user?.email,
      status: 'submitted',
      uploaded_by_rep: true,
      owner: user?.email,
    });
  };

  const pendingCount = docs.filter(d => d.status === 'pending_signature' || d.status === 'submitted' || d.status === 'under_review').length;

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card>
          <CardContent className="py-4 flex items-center gap-3">
            <FileText className="w-8 h-8 text-primary opacity-30" />
            <div>
              <p className="text-2xl font-bold">{docs.length}</p>
              <p className="text-xs text-muted-foreground">Total Documents</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-4 flex items-center gap-3">
            <Clock className="w-8 h-8 text-amber-500 opacity-30" />
            <div>
              <p className="text-2xl font-bold text-amber-600">{pendingCount}</p>
              <p className="text-xs text-muted-foreground">Pending Review</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="py-4 flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-emerald-500 opacity-30" />
            <div>
              <p className="text-2xl font-bold text-emerald-600">{docs.filter(d => d.status === 'signed').length}</p>
              <p className="text-xs text-muted-foreground">Signed / Approved</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload card */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <FileUp className="w-4 h-4 text-primary" />
            Upload Document
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={`rounded-xl border-2 border-dashed p-8 text-center transition-all cursor-pointer ${dragOver ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40'}`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.txt"
              onChange={(e) => handleUpload(e.target.files?.[0])}
            />
            {uploading ? (
              <>
                <Loader2 className="w-8 h-8 mx-auto mb-3 text-primary animate-spin" />
                <p className="text-sm font-medium">Uploading...</p>
              </>
            ) : form.file_url ? (
              <>
                <FileText className="w-8 h-8 mx-auto mb-3 text-emerald-500" />
                <p className="text-sm font-medium text-emerald-600">File ready to save</p>
                <p className="text-xs text-muted-foreground mt-1 truncate">{form.file_url}</p>
              </>
            ) : (
              <>
                <Upload className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium">Drop a file here or click to browse</p>
                <p className="text-xs text-muted-foreground mt-1">PDF, DOC, DOCX, JPG, PNG, TXT — max 10MB</p>
              </>
            )}
          </div>
          {form.file_url && (
            <div className="mt-3 space-y-3">
              <div>
                <Label>Document Title</Label>
                <Input className="mt-1" value={form.title} onChange={e => f('title', e.target.value)} placeholder="e.g. W-9 Form 2026" />
              </div>
              <div>
                <Label>Document Type</Label>
                <Select value={form.doc_type} onValueChange={v => f('doc_type', v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DOC_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace(/_/g,' ').replace(/\b\w/g, c => c.toUpperCase())}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Notes (optional)</Label>
                <Textarea className="mt-1" rows={2} value={form.notes} onChange={e => f('notes', e.target.value)} placeholder="Any context for HR..." />
              </div>
              <Button className="w-full gap-2" onClick={handleSave} disabled={!form.title || !form.file_url || createMut.isPending}>
                {createMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Submit Document to HR
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Documents table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">My Documents</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Document</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Uploaded</TableHead>
                <TableHead className="w-20">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></TableCell></TableRow>
              ) : docs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-10 text-muted-foreground">
                    <FileText className="w-10 h-10 mx-auto mb-2 opacity-30" />
                    No documents uploaded yet
                  </TableCell>
                </TableRow>
              ) : docs.map(doc => (
                <TableRow key={doc.id} className="hover:bg-muted/30">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <FileText className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      <span className="text-sm font-medium">{doc.title}</span>
                      {doc.uploaded_by_rep && <Badge variant="outline" className="text-[9px] bg-primary/5 text-primary">Mine</Badge>}
                    </div>
                    {doc.notes && <p className="text-xs text-muted-foreground mt-0.5 truncate max-w-[200px]">{doc.notes}</p>}
                  </TableCell>
                  <TableCell><Badge variant="outline" className={`text-[10px] ${DOC_TYPE_COLORS[doc.doc_type] || ''}`}>{doc.doc_type?.replace(/_/g,' ')}</Badge></TableCell>
                  <TableCell><Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[doc.status] || ''}`}>{doc.status?.replace(/_/g,' ')}</Badge></TableCell>
                  <TableCell className="text-xs text-muted-foreground">{doc.created_date ? format(new Date(doc.created_date), 'MMM d, yyyy') : '—'}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      {doc.file_url && (
                        <Button variant="ghost" size="icon" className="h-7 w-7" asChild>
                          <a href={doc.file_url} target="_blank" rel="noopener noreferrer"><ExternalLink className="w-3.5 h-3.5" /></a>
                        </Button>
                      )}
                      {doc.uploaded_by_rep && (
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMut.mutate(doc.id)}>
                          <Trash2 className="w-3.5 h-3.5 text-destructive" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}