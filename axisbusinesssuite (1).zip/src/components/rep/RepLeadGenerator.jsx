import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Search, Sparkles, MapPin, Phone, Globe, Star,
  Plus, Loader2, Building2, CheckCircle2, Zap, Target, ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

const QUICK_CATEGORIES = [
  'Restaurants', 'Plumbers', 'Dentists', 'Auto Repair', 'Real Estate Agents',
  'Salons', 'Law Firms', 'Gyms', 'Contractors', 'HVAC', 'Landscaping',
  'Insurance Agents', 'Accountants', 'Chiropractors', 'Car Dealerships',
];

const LEAD_COUNTS = ['10', '20', '30', '50'];

export default function RepLeadGenerator({ rep, userEmail, subscriberEmail, onLeadClick }) {
  const [zipCode, setZipCode] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [leadCount, setLeadCount] = useState('20');
  const [radius, setRadius] = useState('10');
  const [generating, setGenerating] = useState(false);
  const [results, setResults] = useState([]);
  const [selected, setSelected] = useState(new Set());
  const [importing, setImporting] = useState(false);
  const qc = useQueryClient();

  const generate = async () => {
    if (!zipCode || !businessType) {
      toast.error('Enter a zip code and business type');
      return;
    }
    setGenerating(true);
    setResults([]);
    setSelected(new Set());

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a B2B lead generation expert with access to Google Places and Foursquare data.
Find ${leadCount} local businesses matching:
Business Type: ${businessType}
Location: Zip code ${zipCode}, within ${radius} miles radius
Use realistic business data that would be found in Google Maps and Foursquare.
Return exactly ${leadCount} businesses with realistic local business data.`,
        model: 'gpt_5_mini',
        add_context_from_internet: false,
        response_json_schema: {
          type: 'object',
          properties: {
            leads: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  business_name: { type: 'string' },
                  phone: { type: 'string' },
                  address: { type: 'string' },
                  city: { type: 'string' },
                  state: { type: 'string' },
                  website: { type: 'string' },
                  email: { type: 'string' },
                  rating: { type: 'number' },
                  review_count: { type: 'number' },
                  category: { type: 'string' },
                }
              }
            },
            search_summary: { type: 'string' }
          }
        }
      });

      const leads = (result?.leads || [])
        .filter(l => l.business_name && l.phone)
        .map(l => ({ ...l, selected: false }));

      setResults(leads);
      if (leads.length === 0) {
        toast.error('No leads found. Try a different location or business type.');
      } else {
        toast.success(`Found ${leads.length} businesses in ${zipCode}`);
      }
    } catch (err) {
      toast.error(err.message || 'Generation failed. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const toggleSelect = (i) => {
    const s = new Set(selected);
    s.has(i) ? s.delete(i) : s.add(i);
    setSelected(s);
  };

  const toggleAll = () => {
    if (selected.size === results.length) setSelected(new Set());
    else setSelected(new Set(results.map((_, i) => i)));
  };

  const importToLeads = async () => {
    const toImport = results.filter((_, i) => selected.has(i));
    if (!toImport.length) {
      toast.error('Select at least one lead');
      return;
    }
    setImporting(true);

    const ownerEmail = subscriberEmail || rep?.owner || userEmail;

    const leadsData = toImport.map(l => ({
      first_name: l.business_name.split(' ')[0] || l.business_name,
      last_name: l.business_name.split(' ').slice(1).join(' ') || '',
      phone: l.phone || '',
      email: l.email || '',
      company: l.business_name,
      source: `Lead Generator — ${businessType} in ${zipCode}`,
      notes: `${l.address ? l.address + ', ' : ''}${l.city || ''} ${l.state || ''} | Rating: ${l.rating || 'N/A'} | ${l.website || ''}`.trim(),
      status: 'new',
      consent_given: false,
      call_attempts: 0,
      owner: ownerEmail,
      assigned_to: userEmail,
    }));

    try {
      const response = await base44.functions.invoke('bulkImportLeads', { leads: leadsData });
      const successCount = response.data?.imported || 0;
      const failedCount = response.data?.failed || 0;

      if (successCount > 0) {
        toast.success(`${successCount} lead${successCount > 1 ? 's' : ''} imported to your pipeline!`);
      }
      if (failedCount > 0) {
        toast.warning(`${failedCount} leads failed to import`);
      }

      // Track generated leads
      for (const l of toImport) {
        try {
          await base44.functions.invoke('createRecord', {
            entity: 'GeneratedLead',
            data: {
              ...l,
              zip_code: zipCode,
              source: 'google_places',
              search_query: `${businessType} in ${zipCode}`,
              status: 'imported',
              owner: ownerEmail,
            }
          });
        } catch (genErr) {
          // non-blocking
        }
      }

      qc.invalidateQueries({ queryKey: ['rep-leads', userEmail] });
      setResults([]);
      setSelected(new Set());
    } catch (err) {
      toast.error('Import failed — ' + err.message);
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Search Card */}
      <Card className="border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            AI Lead Generator
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            Find local businesses by type and location. Imported leads go straight to your pipeline.
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Quick categories */}
          <div className="flex flex-wrap gap-1.5">
            {QUICK_CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setBusinessType(cat)}
                className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                  businessType === cat
                    ? 'border-primary bg-primary/10 text-primary font-medium'
                    : 'border-border text-muted-foreground hover:border-primary/40 hover:text-foreground'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Inputs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div>
              <label className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Business Type</label>
              <Input
                placeholder="e.g. Plumbers"
                value={businessType}
                onChange={e => setBusinessType(e.target.value)}
                className="mt-0.5 h-8 text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Zip Code</label>
              <Input
                placeholder="33101"
                value={zipCode}
                onChange={e => setZipCode(e.target.value.replace(/[^0-9]/g, '').slice(0, 5))}
                className="mt-0.5 h-8 text-sm"
              />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide">Radius (mi)</label>
              <Select value={radius} onValueChange={setRadius}>
                <SelectTrigger className="mt-0.5 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['5', '10', '15', '25', '50'].map(r => <SelectItem key={r} value={r}>{r} mi</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-medium uppercase tracking-wide"># of Leads</label>
              <Select value={leadCount} onValueChange={setLeadCount}>
                <SelectTrigger className="mt-0.5 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {LEAD_COUNTS.map(n => <SelectItem key={n} value={n}>{n}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={generate}
            disabled={!zipCode || !businessType || generating}
            className="w-full gap-2"
          >
            {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            {generating ? 'Searching...' : 'Find Leads'}
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {results.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-primary" />
                {results.length} Businesses Found
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={toggleAll}>
                  {selected.size === results.length ? 'Deselect All' : 'Select All'}
                </Button>
                <Button
                  size="sm"
                  className="h-7 text-xs gap-1"
                  disabled={selected.size === 0 || importing}
                  onClick={importToLeads}
                >
                  {importing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
                  Import ({selected.size})
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-8"></TableHead>
                  <TableHead>Business</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead className="hidden md:table-cell">Location</TableHead>
                  <TableHead className="hidden sm:table-cell">Rating</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.map((lead, i) => (
                  <TableRow key={i} className="hover:bg-muted/30 cursor-pointer" onClick={() => toggleSelect(i)}>
                    <TableCell>
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                        selected.has(i) ? 'bg-primary border-primary' : 'border-border'
                      }`}>
                        {selected.has(i) && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                        <div>
                          <p className="text-sm font-medium">{lead.business_name}</p>
                          {lead.website && (
                            <a
                              href={lead.website.startsWith('http') ? lead.website : `https://${lead.website}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={e => e.stopPropagation()}
                              className="text-[10px] text-primary hover:underline flex items-center gap-0.5"
                            >
                              <Globe className="w-2.5 h-2.5" /> {lead.website}
                            </a>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-xs font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-muted-foreground" />
                        {lead.phone}
                      </span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {lead.city ? `${lead.city}, ${lead.state}` : lead.address || '—'}
                      </span>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">
                      {lead.rating ? (
                        <Badge variant="outline" className="text-[10px] gap-0.5">
                          <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                          {lead.rating}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Empty state */}
      {results.length === 0 && !generating && (
        <Card className="border-dashed">
          <CardContent className="py-10 text-center">
            <Target className="w-10 h-10 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm font-medium text-muted-foreground">Find your next prospects</p>
            <p className="text-xs text-muted-foreground/60 mt-1">
              Pick a business type, enter a zip code, and let AI find local businesses ready to be called.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}