import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  X, Star, Phone, Mail, Briefcase, GraduationCap, Award,
  ExternalLink, Video, FileText, Clock, CheckCircle2, XCircle,
  Building2, Calendar, Send, UserCheck
} from 'lucide-react';
import { format } from 'date-fns';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const STATUS_COLORS = {
  new: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  screening: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  interview_scheduled: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  interviewed: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20',
  offer_sent: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  hired: 'bg-emerald-600/10 text-emerald-700 border-emerald-600/20',
  rejected: 'bg-red-500/10 text-red-600 border-red-500/20',
};

function StarRating({ value }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star key={i} className={`w-3.5 h-3.5 ${i <= value ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground/30'}`} />
      ))}
    </div>
  );
}

export default function CandidateProfileDrawer({ candidate, onClose, onRefresh, onScheduleInterview, onHire }) {
  const [interviewNotes, setInterviewNotes] = useState(candidate.interview_notes || '');
  const [outcome, setOutcome] = useState(candidate.interview_outcome || 'pending');
  const [saving, setSaving] = useState(false);
  const [sendingOffer, setSendingOffer] = useState(false);

  const safeParse = (val) => { try { return val ? JSON.parse(val) : []; } catch { return []; } };
  const skills = safeParse(candidate.skills);
  const workHistory = safeParse(candidate.work_history);
  const education = safeParse(candidate.education);

  const saveInterviewOutcome = async () => {
    setSaving(true);
    const updates = {
      interview_notes: interviewNotes,
      interview_outcome: outcome,
    };
    if (outcome === 'pass' && candidate.status === 'interview_scheduled') {
      updates.status = 'interviewed';
    } else if (outcome === 'fail') {
      updates.status = 'rejected';
    }
    await base44.entities.Candidate.update(candidate.id, updates);
    setSaving(false);
    toast.success('Interview outcome saved');
    onRefresh();
  };

  const sendOffer = async () => {
    setSendingOffer(true);
    await base44.entities.Candidate.update(candidate.id, {
      status: 'offer_sent',
      offer_sent_date: new Date().toISOString(),
    });
    await base44.integrations.Core.SendEmail({
      to: candidate.email,
      subject: `🎉 Offer Letter — ${candidate.position_applied}`,
      body: `Hi ${candidate.first_name},\n\nWe are thrilled to extend an offer for the ${candidate.position_applied} position!\n\nAfter your interview, we were very impressed with your background and believe you would be a fantastic addition to our team.\n\nPlease reply to this email or contact us to discuss the next steps, including your start date, compensation, and any questions you may have.\n\nWe look forward to welcoming you aboard!\n\nBest regards,\nThe Hiring Team`,
    });
    setSendingOffer(false);
    toast.success('Offer letter sent to candidate');
    onRefresh();
  };

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div className="flex-1 bg-black/40" onClick={onClose} />

      {/* Drawer */}
      <div className="w-full max-w-2xl bg-background border-l shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between p-5 border-b bg-card">
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary text-2xl font-black">
              {candidate.first_name?.[0]?.toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-bold">{candidate.first_name} {candidate.last_name}</h2>
              <p className="text-sm text-muted-foreground">{candidate.current_title || candidate.position_applied}</p>
              <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[candidate.status]}`}>
                  {candidate.status?.replace(/_/g, ' ')}
                </Badge>
                {candidate.source === 'indeed' && (
                  <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-600 border-blue-500/20">
                    Indeed
                  </Badge>
                )}
                <StarRating value={candidate.rating || 0} />
              </div>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-muted transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Contact Info + Quick Actions */}
          <div className="p-5 border-b space-y-3">
            <div className="grid grid-cols-2 gap-3 text-sm">
              {candidate.email && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Mail className="w-3.5 h-3.5 shrink-0" />
                  <a href={`mailto:${candidate.email}`} className="hover:text-primary truncate">{candidate.email}</a>
                </div>
              )}
              {candidate.phone && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="w-3.5 h-3.5 shrink-0" />
                  <span>{candidate.phone}</span>
                </div>
              )}
              {candidate.current_company && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Building2 className="w-3.5 h-3.5 shrink-0" />
                  <span>{candidate.current_company}</span>
                </div>
              )}
              {candidate.years_experience > 0 && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Briefcase className="w-3.5 h-3.5 shrink-0" />
                  <span>{candidate.years_experience} years experience</span>
                </div>
              )}
              {candidate.apply_date && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="w-3.5 h-3.5 shrink-0" />
                  <span>Applied {format(new Date(candidate.apply_date), 'MMM d, yyyy')}</span>
                </div>
              )}
            </div>

            {/* External links */}
            <div className="flex gap-2 flex-wrap">
              {candidate.indeed_profile_url && (
                <a href={candidate.indeed_profile_url} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                    <ExternalLink className="w-3 h-3" />View on Indeed
                  </Button>
                </a>
              )}
              {candidate.linkedin_url && (
                <a href={candidate.linkedin_url} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                    <ExternalLink className="w-3 h-3" />LinkedIn
                  </Button>
                </a>
              )}
              {candidate.zoom_join_url && (
                <a href={candidate.zoom_join_url} target="_blank" rel="noopener noreferrer">
                  <Button size="sm" className="h-7 text-xs gap-1 bg-blue-600 hover:bg-blue-700">
                    <Video className="w-3 h-3" />Join Zoom Interview
                  </Button>
                </a>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex gap-2 pt-1 flex-wrap">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={() => onScheduleInterview(candidate)}>
                <Video className="w-3.5 h-3.5" />Schedule Interview
              </Button>
              {(candidate.status === 'interviewed') && (
                <Button size="sm" className="gap-1.5 text-xs bg-amber-500 hover:bg-amber-600" onClick={sendOffer} disabled={sendingOffer}>
                  <Send className="w-3.5 h-3.5" />{sendingOffer ? 'Sending...' : 'Send Offer Letter'}
                </Button>
              )}
              {(candidate.status === 'offer_sent' || candidate.status === 'interviewed') && (
                <Button size="sm" className="gap-1.5 text-xs bg-emerald-600 hover:bg-emerald-700" onClick={() => onHire(candidate)}>
                  <UserCheck className="w-3.5 h-3.5" />Hire & Onboard
                </Button>
              )}
            </div>
          </div>

          {/* Skills */}
          {skills.length > 0 && (
            <div className="p-5 border-b">
              <div className="flex items-center gap-2 mb-3">
                <Award className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Skills</h3>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {skills.map((s, i) => (
                  <span key={i} className="bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full font-medium">{s}</span>
                ))}
              </div>
            </div>
          )}

          {/* Work History */}
          {workHistory.length > 0 && (
            <div className="p-5 border-b">
              <div className="flex items-center gap-2 mb-3">
                <Briefcase className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Work History</h3>
              </div>
              <div className="space-y-3">
                {workHistory.map((w, i) => (
                  <div key={i} className="pl-3 border-l-2 border-primary/20">
                    <p className="font-semibold text-sm">{w.title}</p>
                    <p className="text-xs text-muted-foreground">{w.company} · {w.duration}</p>
                    {w.description && <p className="text-xs text-muted-foreground mt-1">{w.description}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {education.length > 0 && (
            <div className="p-5 border-b">
              <div className="flex items-center gap-2 mb-3">
                <GraduationCap className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Education</h3>
              </div>
              <div className="space-y-2">
                {education.map((e, i) => (
                  <div key={i} className="pl-3 border-l-2 border-primary/20">
                    <p className="font-semibold text-sm">{e.degree}</p>
                    <p className="text-xs text-muted-foreground">{e.school} · {e.year}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Resume / Full Profile Text */}
          {candidate.resume_text && (
            <div className="p-5 border-b">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-4 h-4 text-primary" />
                <h3 className="font-semibold text-sm">Resume / Profile Summary</h3>
              </div>
              <div className="bg-muted/40 rounded-xl p-4 text-xs leading-relaxed whitespace-pre-wrap text-muted-foreground font-mono border">
                {candidate.resume_text}
              </div>
            </div>
          )}

          {/* Notes from Indeed application */}
          {candidate.notes && (
            <div className="p-5 border-b">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-4 h-4 text-muted-foreground" />
                <h3 className="font-semibold text-sm">Application Notes</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">{candidate.notes}</p>
            </div>
          )}

          {/* Interview section */}
          <div className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Video className="w-4 h-4 text-primary" />
              <h3 className="font-semibold text-sm">Interview Outcome</h3>
            </div>

            {candidate.interview_date && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground mb-3 p-2.5 bg-purple-500/5 border border-purple-500/20 rounded-lg">
                <Clock className="w-3.5 h-3.5 text-purple-600" />
                Zoom interview scheduled for {format(new Date(candidate.interview_date), 'MMM d, yyyy h:mm a')}
              </div>
            )}

            <div className="space-y-3">
              <div>
                <Label className="text-xs">Outcome</Label>
                <Select value={outcome} onValueChange={setOutcome}>
                  <SelectTrigger className="h-8 text-xs mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">⏳ Pending</SelectItem>
                    <SelectItem value="pass">✅ Pass — Move Forward</SelectItem>
                    <SelectItem value="fail">❌ Fail — Reject</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Interview Notes</Label>
                <Textarea
                  value={interviewNotes}
                  onChange={e => setInterviewNotes(e.target.value)}
                  placeholder="Strengths, concerns, key observations..."
                  className="mt-1 text-xs"
                  rows={3}
                />
              </div>
              <Button size="sm" className="gap-1.5 text-xs w-full" onClick={saveInterviewOutcome} disabled={saving}>
                {saving ? 'Saving...' : 'Save Interview Outcome'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}