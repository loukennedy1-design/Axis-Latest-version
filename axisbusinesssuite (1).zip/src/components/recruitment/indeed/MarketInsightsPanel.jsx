import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { BarChart3, Loader2, DollarSign, TrendingUp, Building2, Clock, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function MarketInsightsPanel({ liveMode }) {
  const [jobTitle, setJobTitle] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState(null);

  const handleSearch = async () => {
    if (!jobTitle) { toast.error('Enter a job title'); return; }
    setLoading(true);
    setInsights(null);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', {
        action: 'get_market_insights',
        job_title: jobTitle,
        location,
      });
      if (res.data?.error) throw new Error(res.data.error);
      setInsights(res.data.insights);
      toast.success('Market insights loaded');
    } catch (e) {
      toast.error('Failed to load insights: ' + e.message);
    }
    setLoading(false);
  };

  const demandColor = (level) => {
    const colors = {
      very_high: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
      high: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
      medium: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
      low: 'bg-red-500/10 text-red-600 border-red-500/30',
    };
    return colors[level?.toLowerCase()] || 'bg-muted text-muted-foreground border-border';
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-blue-500" />
            <p className="font-semibold text-sm">Market Insights</p>
            <Badge variant="outline" className={`text-[10px] ml-auto ${liveMode ? 'text-emerald-600 border-emerald-500/30' : 'text-amber-600 border-amber-500/30'}`}>
              {liveMode ? 'Live API' : 'AI + Web'}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            Get real-time salary benchmarks, hiring demand trends, competitor activity, and in-demand skills for any role.
          </p>
          <div className="flex gap-2 flex-wrap">
            <Input
              value={jobTitle}
              onChange={e => setJobTitle(e.target.value)}
              placeholder="Job title, e.g. Account Executive"
              className="flex-1 min-w-40"
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
            />
            <Input
              value={location}
              onChange={e => setLocation(e.target.value)}
              placeholder="Location (optional)"
              className="w-44"
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Sparkles className="w-4 h-4 mr-1" />}
              Get Insights
            </Button>
          </div>
        </CardContent>
      </Card>

      {loading && (
        <div className="text-center py-12">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
          <p className="text-sm text-muted-foreground">Analyzing market data for {jobTitle}...</p>
        </div>
      )}

      {insights && (
        <div className="space-y-4">
          {/* Summary */}
          <Card>
            <CardContent className="p-4">
              <p className="text-sm font-semibold mb-1">Market Summary</p>
              <p className="text-sm text-muted-foreground">{insights.market_summary}</p>
            </CardContent>
          </Card>

          {/* Salary Benchmark */}
          {insights.salary_benchmark && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-4 h-4 text-emerald-500" />
                  <p className="text-sm font-semibold">Salary Benchmark</p>
                </div>
                <div className="grid grid-cols-3 gap-2 mb-3">
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Min</p>
                    <p className="text-sm font-bold">${(insights.salary_benchmark.min / 1000).toFixed(0)}k</p>
                  </div>
                  <div className="text-center p-2 bg-emerald-500/10 rounded-lg">
                    <p className="text-xs text-muted-foreground">Median</p>
                    <p className="text-sm font-bold text-emerald-600">${(insights.salary_benchmark.median / 1000).toFixed(0)}k</p>
                  </div>
                  <div className="text-center p-2 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground">Max</p>
                    <p className="text-sm font-bold">${(insights.salary_benchmark.max / 1000).toFixed(0)}k</p>
                  </div>
                </div>
                {insights.salary_benchmark.percentiles && (
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="text-center"><span className="text-muted-foreground">P25: </span>${(insights.salary_benchmark.percentiles.p25 / 1000).toFixed(0)}k</div>
                    <div className="text-center"><span className="text-muted-foreground">P50: </span>${(insights.salary_benchmark.percentiles.p50 / 1000).toFixed(0)}k</div>
                    <div className="text-center"><span className="text-muted-foreground">P75: </span>${(insights.salary_benchmark.percentiles.p75 / 1000).toFixed(0)}k</div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Hiring Demand */}
          {insights.hiring_demand && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-blue-500" />
                  <p className="text-sm font-semibold">Hiring Demand</p>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                  <Badge className={`capitalize text-xs ${demandColor(insights.hiring_demand.level)}`}>{insights.hiring_demand.level}</Badge>
                  <Badge variant="outline" className="text-xs capitalize">{insights.hiring_demand.trend}</Badge>
                  <span className="text-xs text-muted-foreground">{insights.hiring_demand.monthly_postings?.toLocaleString() || '—'} monthly postings</span>
                  <span className="text-xs text-muted-foreground">Competition: {insights.hiring_demand.competition_level}</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Competitor Activity */}
          {insights.competitor_activity?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4 text-purple-500" />
                  <p className="text-sm font-semibold">Competitor Activity</p>
                </div>
                <div className="space-y-2">
                  {insights.competitor_activity.map((c, i) => (
                    <div key={i} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                      <div>
                        <p className="text-sm font-medium">{c.company}</p>
                        <p className="text-xs text-muted-foreground">{c.avg_salary_posted || '—'}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline" className="text-[10px]">{c.job_count} jobs</Badge>
                        <p className="text-[10px] text-muted-foreground mt-0.5 capitalize">{c.hiring_urgency}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Top Skills Demand */}
          {insights.top_skills_demand?.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <p className="text-sm font-semibold mb-3">In-Demand Skills</p>
                <div className="space-y-2">
                  {insights.top_skills_demand.map((s, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <span className="text-sm w-32 truncate">{s.skill}</span>
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${s.demand_percentage}%` }} />
                      </div>
                      <span className="text-xs text-muted-foreground w-20 text-right">{s.demand_percentage}% · {s.trend}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Best Time to Hire + Recommendation */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {insights.best_time_to_hire && (
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-4 h-4 text-orange-500" />
                    <p className="text-sm font-semibold">Best Time to Hire</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{insights.best_time_to_hire.notes}</p>
                  <p className="text-xs mt-1">Peak season: <span className="font-medium">{insights.best_time_to_hire.peak_season}</span></p>
                  <p className="text-xs">Recommended: <span className="font-medium">{insights.best_time_to_hire.recommended_duration_days} days</span></p>
                </CardContent>
              </Card>
            )}
            <Card>
              <CardContent className="p-4">
                <p className="text-sm font-semibold mb-2">💡 Hiring Recommendation</p>
                <p className="text-xs text-muted-foreground">{insights.hiring_recommendation}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {!loading && !insights && (
        <Card className="border-dashed">
          <CardContent className="py-12 text-center">
            <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="font-semibold mb-1">Market Insights</p>
            <p className="text-sm text-muted-foreground">Enter a job title to get salary benchmarks, demand trends, and competitor data</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}