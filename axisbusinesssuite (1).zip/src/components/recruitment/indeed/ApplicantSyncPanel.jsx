import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Loader2, RefreshCw, UserPlus, Star } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

export default function ApplicantSyncPanel({ liveMode, stats }) {
  const qc = useQueryClient();
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState(null);

  const { data: candidates = [] } = useQuery({
    queryKey: ['indeed-candidates'],
    queryFn: () => base44.entities.Candidate.filter({ source: 'indeed' }),
  });

  const handleSync = async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', { action: 'sync_applicants', max_per_job: 5 });
      if (res.data?.error) throw new Error(res.data.error);
      setSyncResult(res.data);
      qc.invalidateQueries({ queryKey: ['indeed-candidates'] });
      qc.invalidateQueries({ queryKey: ['candidates'] });
      toast.success(res.data.message || 'Applicants synced');
    } catch (e) {
      toast.error('Sync failed: ' + e.message);
    }
    setSyncing(false);
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-500" />
              <p className="font-semibold text-sm">Applicant Auto-Sync</p>
            </div>
            <Badge variant="outline" className={`text-[10px] ${liveMode ? 'text-emerald-600 border-emerald-500/30' : 'text-amber-600 border-amber-500/30'}`}>
              {liveMode ? 'Live API' : 'AI Mode'}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            Pulls new applicants from all active Indeed job postings, parses resumes, extracts skills, and AI-scores each candidate automatically.
          </p>
          <div className="grid grid-cols-4 gap-2 mb-3">
            <div className="text-center p-2 bg-muted rounded-lg">
              <p className="text-lg font-bold">{stats?.total_indeed_candidates ?? candidates.length}</p>
              <p className="text-[10px] text-muted-foreground">Total</p>
            </div>
            <div className="text-center p-2 bg-blue-500/10 rounded-lg">
              <p className="text-lg font-bold text-blue-600">{stats?.new_applicants ?? 0}</p>
              <p className="text-[10px] text-muted-foreground">New</p>
            </div>
            <div className="text-center p-2 bg-purple-500/10 rounded-lg">
              <p className="text-lg font-bold text-purple-600">{stats?.interviewed ?? 0}</p>
              <p className="text-[10px] text-muted-foreground">Interview</p>
            </div>
            <div className="text-center p-2 bg-emerald-500/10 rounded-lg">
              <p className="text-lg font-bold text-emerald-600">{stats?.hired ?? 0}</p>
              <p className="text-[10px] text-muted-foreground">Hired</p>
            </div>
          </div>
          <Button onClick={handleSync} disabled={syncing} className="w-full">
            {syncing ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Syncing applicants...</> : <><RefreshCw className="w-4 h-4 mr-2" />Sync Now</>}
          </Button>
        </CardContent>
      </Card>

      {syncResult && (
        <Card className="border-emerald-500/20">
          <CardContent className="p-4">
            <p className="font-semibold text-sm mb-2">Sync Results</p>
            <div className="flex gap-4 mb-3 text-sm">
              <span className="flex items-center gap-1"><UserPlus className="w-4 h-4 text-emerald-500" />{syncResult.imported} imported</span>
              {syncResult.skipped > 0 && <span className="text-muted-foreground">{syncResult.skipped} duplicates skipped</span>}
            </div>
            {syncResult.new_applicants?.length > 0 && (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {syncResult.new_applicants.map((a, i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                    <div>
                      <p className="text-sm font-medium">{a.name}</p>
                      <p className="text-xs text-muted-foreground">{a.job}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-[10px]">{a.recommendation}</Badge>
                      <Badge className={`text-[10px] ${a.score >= 75 ? 'bg-emerald-500' : a.score >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}>
                        <Star className="w-3 h-3 mr-0.5" />{a.score}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Recent Indeed candidates */}
      <div>
        <p className="text-sm font-semibold mb-2">Recent Indeed Candidates</p>
        {candidates.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-8 text-center">
              <Users className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No Indeed candidates yet. Run a sync to pull applicants.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {candidates.slice(0, 15).map(c => (
              <Card key={c.id}>
                <CardContent className="p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-600 font-bold text-sm">
                      {c.first_name?.[0]}
                    </div>
                    <div>
                      <p className="text-sm font-medium">{c.first_name} {c.last_name}</p>
                      <p className="text-xs text-muted-foreground">{c.position_applied || '—'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {c.ai_fit_score > 0 && (
                      <Badge className={`text-[10px] ${c.ai_fit_score >= 75 ? 'bg-emerald-500' : c.ai_fit_score >= 50 ? 'bg-amber-500' : 'bg-red-500'}`}>
                        {c.ai_fit_score}
                      </Badge>
                    )}
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {c.apply_date ? formatDistanceToNow(new Date(c.apply_date), { addSuffix: true }) : ''}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}