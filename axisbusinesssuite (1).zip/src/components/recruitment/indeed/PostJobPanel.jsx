import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Briefcase, Loader2, Sparkles, CheckCircle2, DollarSign, Users } from 'lucide-react';
import { toast } from 'sonner';

export default function PostJobPanel({ liveMode }) {
  const qc = useQueryClient();
  const [selectedJobId, setSelectedJobId] = useState('');
  const [posting, setPosting] = useState(false);
  const [result, setResult] = useState(null);

  const { data: jobPostings = [] } = useQuery({
    queryKey: ['job-postings'],
    queryFn: () => base44.entities.JobPosting.list('-created_date'),
  });

  const draftJobs = jobPostings.filter(j => j.status === 'draft' || (j.status === 'active' && !j.indeed_posted));

  const handlePost = async () => {
    if (!selectedJobId) { toast.error('Select a job posting first'); return; }
    setPosting(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', { action: 'post_job', job_id: selectedJobId });
      if (res.data?.error) throw new Error(res.data.error);
      setResult(res.data);
      qc.invalidateQueries({ queryKey: ['job-postings'] });
      toast.success(res.data.message || 'Job posted to Indeed');
    } catch (e) {
      toast.error('Posting failed: ' + e.message);
    }
    setPosting(false);
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <Briefcase className="w-4 h-4 text-blue-500" />
            <p className="font-semibold text-sm">Post a Job to Indeed</p>
            <Badge variant="outline" className={`text-[10px] ml-auto ${liveMode ? 'text-emerald-600 border-emerald-500/30' : 'text-amber-600 border-amber-500/30'}`}>
              {liveMode ? 'Live API' : 'AI Mode'}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            Select a draft job posting. Our AI will optimize the title, summary, and full posting for maximum Indeed visibility before publishing.
          </p>
          <div className="flex gap-2">
            <Select value={selectedJobId} onValueChange={setSelectedJobId}>
              <SelectTrigger className="flex-1"><SelectValue placeholder="Select a job posting..." /></SelectTrigger>
              <SelectContent>
                {draftJobs.length === 0 ? (
                  <SelectItem value="_none" disabled>No draft jobs available</SelectItem>
                ) : draftJobs.map(job => (
                  <SelectItem key={job.id} value={job.id}>{job.title} — {job.location || 'Remote'}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={handlePost} disabled={posting || !selectedJobId || selectedJobId === '_none'}>
              {posting ? <><Loader2 className="w-4 h-4 animate-spin mr-1" />Posting...</> : <><Sparkles className="w-4 h-4 mr-1" />Post to Indeed</>}
            </Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card className="border-emerald-500/20">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <p className="font-semibold text-sm">Job Posted Successfully</p>
              <Badge variant="outline" className="text-[10px] ml-auto">{result.indeed_job_id}</Badge>
            </div>
            {result.optimized_posting && (
              <>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Optimized Title</p>
                  <p className="text-sm font-medium">{result.optimized_posting.title}</p>
                </div>
                <div className="p-3 bg-muted rounded-lg">
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Summary</p>
                  <p className="text-sm">{result.optimized_posting.summary}</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 bg-muted rounded-lg flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Suggested Daily Budget</p>
                      <p className="text-sm font-bold">${result.optimized_posting.suggested_daily_budget || '—'}</p>
                    </div>
                  </div>
                  <div className="p-3 bg-muted rounded-lg flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-500" />
                    <div>
                      <p className="text-xs text-muted-foreground">Est. Applicants</p>
                      <p className="text-sm font-bold">{result.optimized_posting.estimated_applicants || '—'}</p>
                    </div>
                  </div>
                </div>
                <details className="mt-2">
                  <summary className="text-xs font-semibold text-muted-foreground cursor-pointer hover:text-foreground">View Full Posting</summary>
                  <div className="mt-2 p-3 bg-muted rounded-lg text-xs whitespace-pre-wrap max-h-64 overflow-y-auto">
                    {result.optimized_posting.full_posting}
                  </div>
                </details>
              </>
            )}
            {!liveMode && (
              <p className="text-xs text-amber-600 bg-amber-500/5 border border-amber-500/20 rounded-lg p-2">
                ⚠️ Running in AI simulation mode. Add INDEED_API_TOKEN and INDEED_EMPLOYER_ID secrets for live Indeed posting.
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {draftJobs.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center">
            <Briefcase className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm font-medium">No draft jobs available</p>
            <p className="text-xs text-muted-foreground">Create a job posting in the Jobs tab first</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}