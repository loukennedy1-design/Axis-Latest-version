import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { KeyRound, Building2, Loader2, CheckCircle2, ExternalLink, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';

export default function IndeedSettingsPanel({ liveMode, employerId, onSaved }) {
  const [apiToken, setApiToken] = useState('');
  const [employerIdVal, setEmployerIdVal] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [hasStored, setHasStored] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const res = await base44.entities.SystemSettings.filter({});
        const settings = Array.isArray(res) ? res[0] : null;
        if (settings?.indeed_api_token) {
          setHasStored(true);
          setApiToken(''); // don't expose the stored token
          setEmployerIdVal(settings.indeed_employer_id || '');
        } else if (employerId) {
          setEmployerIdVal(employerId);
        }
      } catch (_) { /* ignore */ }
      setLoading(false);
    })();
  }, [employerId]);

  const handleSave = async () => {
    if (!apiToken.trim() && !employerIdVal.trim()) {
      toast.error('Enter your API token and Employer ID');
      return;
    }
    setSaving(true);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', {
        action: 'save_indeed_settings',
        api_token: apiToken.trim() || undefined,
        employer_id: employerIdVal.trim() || undefined,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(res.data?.message || 'Indeed credentials saved');
      setApiToken('');
      setHasStored(true);
      onSaved?.();
    } catch (e) {
      toast.error(e.message || 'Failed to save credentials');
    }
    setSaving(false);
  };

  const handleClear = async () => {
    setSaving(true);
    try {
      await base44.functions.invoke('indeedEnterpriseEngine', { action: 'save_indeed_settings', clear: true });
      setHasStored(false);
      setApiToken('');
      setEmployerIdVal('');
      toast.success('Indeed credentials cleared');
      onSaved?.();
    } catch (e) {
      toast.error(e.message || 'Failed to clear credentials');
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="text-center py-8">
        <Loader2 className="w-6 h-6 animate-spin mx-auto text-primary" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            <CardTitle className="text-base">Indeed API Credentials</CardTitle>
          </div>
          <Badge className={liveMode ? 'bg-emerald-500' : 'bg-amber-500'}>
            {liveMode ? 'LIVE' : 'AI MODE'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1.5">
          <Label className="text-xs flex items-center gap-1.5">
            <KeyRound className="w-3.5 h-3.5" /> Indeed API Token
          </Label>
          <Input
            type="password"
            placeholder={hasStored ? '•••••••••••••••• (saved — enter new to replace)' : 'Paste your Indeed API token'}
            value={apiToken}
            onChange={(e) => setApiToken(e.target.value)}
            disabled={saving}
          />
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs flex items-center gap-1.5">
            <Building2 className="w-3.5 h-3.5" /> Indeed Employer ID
          </Label>
          <Input
            placeholder="Your Indeed Employer ID"
            value={employerIdVal}
            onChange={(e) => setEmployerIdVal(e.target.value)}
            disabled={saving}
          />
        </div>

        <div className="rounded-lg border border-border bg-muted/30 p-3 text-xs text-muted-foreground space-y-1.5">
          <p className="font-semibold text-foreground">How to get your credentials:</p>
          <p>1. Log in to your <a href="https://employers.indeed.com" target="_blank" rel="noopener noreferrer" className="text-primary inline-flex items-center gap-0.5 hover:underline">Indeed Employer account <ExternalLink className="w-3 h-3" /></a></p>
          <p>2. Navigate to Settings → API / Developer settings</p>
          <p>3. Generate an API Token and copy your Employer ID</p>
          <p>4. Paste both above and click Save — the hub switches to Live mode instantly</p>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleSave} disabled={saving || (!apiToken.trim() && !employerIdVal.trim() && !hasStored)}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
            {hasStored ? 'Update Credentials' : 'Save & Activate Live Mode'}
          </Button>
          {hasStored && (
            <Button variant="outline" onClick={handleClear} disabled={saving}>
              Clear
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}