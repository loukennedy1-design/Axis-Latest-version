import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Megaphone, Loader2, DollarSign, MousePointerClick, Users, TrendingUp, Pause, Play } from 'lucide-react';
import { toast } from 'sonner';

export default function SponsoredCampaignsPanel({ liveMode }) {
  const [loading, setLoading] = useState(false);
  const [campaigns, setCampaigns] = useState([]);
  const [summary, setSummary] = useState(null);
  const [recommendation, setRecommendation] = useState('');

  const fetchCampaigns = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', {
        action: 'manage_sponsored_campaign',
        campaign_action: 'list',
      });
      if (res.data?.error) throw new Error(res.data.error);
      setCampaigns(res.data.campaigns || []);
      setSummary(res.data.summary || null);
      setRecommendation(res.data.recommendation || '');
      toast.success(`Loaded ${res.data.campaigns?.length || 0} campaigns`);
    } catch (e) {
      toast.error('Failed to load campaigns: ' + e.message);
    }
    setLoading(false);
  };

  React.useEffect(() => { fetchCampaigns(); }, []);

  const handlePause = async (campaignId) => {
    try {
      await base44.functions.invoke('indeedEnterpriseEngine', {
        action: 'manage_sponsored_campaign',
        campaign_action: 'pause',
        campaign_id: campaignId,
      });
      toast.success('Campaign paused');
      fetchCampaigns();
    } catch (e) {
      toast.error('Failed to pause: ' + e.message);
    }
  };

  return (
    <div className="space-y-4">
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-blue-500" />
              <p className="font-semibold text-sm">Sponsored Campaigns</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={`text-[10px] ${liveMode ? 'text-emerald-600 border-emerald-500/30' : 'text-amber-600 border-amber-500/30'}`}>
                {liveMode ? 'Live API' : 'AI Mode'}
              </Badge>
              <Button variant="outline" size="sm" onClick={fetchCampaigns} disabled={loading}>
                {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <TrendingUp className="w-3.5 h-3.5" />}
              </Button>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Manage Indeed sponsored job campaigns. Track spend, cost-per-applicant, and conversion rates across all promotions.
          </p>
        </CardContent>
      </Card>

      {summary && (
        <div className="grid grid-cols-3 gap-3">
          <Card>
            <CardContent className="p-3 flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-emerald-500" />
              <div>
                <p className="text-xs text-muted-foreground">Total Spent</p>
                <p className="text-lg font-bold">${summary.total_spent?.toFixed(2) || '0.00'}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-blue-500" />
              <div>
                <p className="text-xs text-muted-foreground">Applications</p>
                <p className="text-lg font-bold">{summary.total_applications || 0}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-purple-500" />
              <div>
                <p className="text-xs text-muted-foreground">Avg CPA</p>
                <p className="text-lg font-bold">${summary.average_cpa?.toFixed(2) || '0.00'}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {recommendation && (
        <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg">
          <p className="text-xs font-semibold text-blue-600 mb-1">💡 AI Recommendation</p>
          <p className="text-xs text-muted-foreground">{recommendation}</p>
        </div>
      )}

      {loading && campaigns.length === 0 ? (
        <div className="text-center py-8"><Loader2 className="w-6 h-6 animate-spin mx-auto text-muted-foreground" /></div>
      ) : campaigns.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center">
            <Megaphone className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No campaigns found. Post jobs and sponsor them on Indeed to see campaigns here.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {campaigns.map((c, i) => (
            <Card key={i}>
              <CardContent className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold">{c.job_title}</p>
                  <Badge variant="outline" className={`text-[10px] capitalize ${
                    c.status === 'active' ? 'text-emerald-600 border-emerald-500/30' :
                    c.status === 'paused' ? 'text-amber-600 border-amber-500/30' :
                    'text-muted-foreground'
                  }`}>{c.status}</Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                  <div className="flex items-center gap-1">
                    <DollarSign className="w-3 h-3 text-emerald-500" />
                    <span className="text-muted-foreground">Spent:</span>
                    <span className="font-medium">${c.total_spent?.toFixed(2) || '0'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <MousePointerClick className="w-3 h-3 text-blue-500" />
                    <span className="text-muted-foreground">Clicks:</span>
                    <span className="font-medium">{c.clicks || 0}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3 text-purple-500" />
                    <span className="text-muted-foreground">Apps:</span>
                    <span className="font-medium">{c.applications || 0}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-orange-500" />
                    <span className="text-muted-foreground">CPA:</span>
                    <span className="font-medium">${c.cost_per_applicant?.toFixed(2) || '0.00'}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-2 pt-2 border-t">
                  <span className="text-[10px] text-muted-foreground">
                    {c.days_running || 0} days running · ${(c.daily_budget || 0).toFixed(2)}/day
                  </span>
                  {c.status === 'active' && (
                    <Button variant="ghost" size="sm" className="h-6 text-xs" onClick={() => handlePause(c.campaign_id)}>
                      <Pause className="w-3 h-3 mr-1" />Pause
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}