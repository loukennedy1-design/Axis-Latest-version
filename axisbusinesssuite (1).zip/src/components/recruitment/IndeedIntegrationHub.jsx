import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Briefcase, Users, Megaphone, BarChart3, Zap, Loader2, Wifi, WifiOff, Settings as SettingsIcon } from 'lucide-react';
import PostJobPanel from '@/components/recruitment/indeed/PostJobPanel';
import ApplicantSyncPanel from '@/components/recruitment/indeed/ApplicantSyncPanel';
import SponsoredCampaignsPanel from '@/components/recruitment/indeed/SponsoredCampaignsPanel';
import MarketInsightsPanel from '@/components/recruitment/indeed/MarketInsightsPanel';
import IndeedSettingsPanel from '@/components/recruitment/indeed/IndeedSettingsPanel';

export default function IndeedIntegrationHub() {
  const [tab, setTab] = useState('sync');
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showSettings, setShowSettings] = useState(false);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('indeedEnterpriseEngine', { action: 'get_status' });
      if (res.data?.error) throw new Error(res.data.error);
      setStatus(res.data);
    } catch (_) {
      // ignore — status card shows loading
    }
    setLoading(false);
  };

  useEffect(() => { fetchStatus(); }, []);

  const liveMode = status?.live_mode;

  return (
    <div className="space-y-4">
      {/* Status header */}
      <Card className={`border ${liveMode ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-amber-500/30 bg-amber-500/5'}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${liveMode ? 'bg-emerald-500/20' : 'bg-amber-500/20'}`}>
                {liveMode ? <Wifi className="w-5 h-5 text-emerald-500" /> : <WifiOff className="w-5 h-5 text-amber-500" />}
              </div>
              <div>
                <p className="font-bold text-sm">Indeed Enterprise Integration</p>
                <p className="text-xs text-muted-foreground">
                  {liveMode ? `Live API · Employer ID: ${status?.employer_id}` : 'AI Simulation Mode · Click "API Settings" to enter your Indeed credentials'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge className={liveMode ? 'bg-emerald-500' : 'bg-amber-500'}>
                {liveMode ? 'LIVE' : 'AI MODE'}
              </Badge>
              <Button variant="outline" size="sm" onClick={() => setShowSettings(s => !s)} className="gap-1.5">
                <SettingsIcon className="w-3.5 h-3.5" /> API Settings
              </Button>
            </div>
          </div>

          {!loading && status?.stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
              <div className="text-center p-2 bg-card rounded-lg border">
                <p className="text-xl font-bold">{status.stats.total_indeed_candidates}</p>
                <p className="text-[10px] text-muted-foreground">Indeed Candidates</p>
              </div>
              <div className="text-center p-2 bg-card rounded-lg border">
                <p className="text-xl font-bold text-blue-600">{status.stats.active_postings}</p>
                <p className="text-[10px] text-muted-foreground">Active Postings</p>
              </div>
              <div className="text-center p-2 bg-card rounded-lg border">
                <p className="text-xl font-bold text-purple-600">{status.stats.interviewed}</p>
                <p className="text-[10px] text-muted-foreground">In Interview</p>
              </div>
              <div className="text-center p-2 bg-card rounded-lg border">
                <p className="text-xl font-bold text-emerald-600">{status.stats.hired}</p>
                <p className="text-[10px] text-muted-foreground">Hired</p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Settings panel (collapsible) */}
      {showSettings && (
        <IndeedSettingsPanel
          liveMode={liveMode}
          employerId={status?.employer_id}
          onSaved={fetchStatus}
        />
      )}

      {/* Capability tabs */}
      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="sync" className="gap-1 text-xs"><Users className="w-3.5 h-3.5" />Sync</TabsTrigger>
          <TabsTrigger value="post" className="gap-1 text-xs"><Briefcase className="w-3.5 h-3.5" />Post Job</TabsTrigger>
          <TabsTrigger value="campaigns" className="gap-1 text-xs"><Megaphone className="w-3.5 h-3.5" />Campaigns</TabsTrigger>
          <TabsTrigger value="insights" className="gap-1 text-xs"><BarChart3 className="w-3.5 h-3.5" />Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="sync" className="mt-4">
          {loading ? <LoadingState /> : <ApplicantSyncPanel liveMode={liveMode} stats={status?.stats} />}
        </TabsContent>
        <TabsContent value="post" className="mt-4">
          {loading ? <LoadingState /> : <PostJobPanel liveMode={liveMode} />}
        </TabsContent>
        <TabsContent value="campaigns" className="mt-4">
          {loading ? <LoadingState /> : <SponsoredCampaignsPanel liveMode={liveMode} />}
        </TabsContent>
        <TabsContent value="insights" className="mt-4">
          {loading ? <LoadingState /> : <MarketInsightsPanel liveMode={liveMode} />}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function LoadingState() {
  return (
    <div className="text-center py-12">
      <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
      <p className="text-sm text-muted-foreground">Loading Indeed integration...</p>
    </div>
  );
}