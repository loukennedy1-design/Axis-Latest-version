import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Mic, Brain, Zap, Heart, Target } from 'lucide-react';

const VOICES = [
  { id: 'professional', label: 'Professional', desc: 'Polished, authoritative, trust-building', icon: '👔' },
  { id: 'friendly', label: 'Friendly', desc: 'Warm, approachable, personable', icon: '😊' },
  { id: 'energetic', label: 'Energetic', desc: 'High energy, enthusiastic, exciting', icon: '⚡' },
  { id: 'calm', label: 'Calm', desc: 'Measured, reassuring, low-pressure', icon: '🧘' },
  { id: 'assertive', label: 'Assertive', desc: 'Direct, confident, results-focused', icon: '💪' },
  { id: 'conversational', label: 'Conversational', desc: 'Natural, casual, like talking to a friend', icon: '💬' },
];

const STYLES = [
  { id: 'consultative', label: 'Consultative', desc: 'Ask questions, discover needs, offer solutions' },
  { id: 'challenger', label: 'Challenger', desc: 'Educate, tailor, and take control of the conversation' },
  { id: 'solution_seller', label: 'Solution Seller', desc: 'Diagnose pain points, prescribe the solution' },
  { id: 'relationship_builder', label: 'Relationship Builder', desc: 'Build rapport first, sell second' },
  { id: 'direct_closer', label: 'Direct Closer', desc: 'Value-first, ask for the appointment quickly' },
];

const OBJECTION_STYLES = [
  { id: 'acknowledge_pivot', label: 'Acknowledge & Pivot', desc: 'Validate then redirect to value' },
  { id: 'feel_felt_found', label: 'Feel Felt Found', desc: 'Classic "I understand how you feel..."' },
  { id: 'challenge', label: 'Challenge', desc: 'Gently challenge the assumption' },
  { id: 'deflect', label: 'Deflect & Refocus', desc: 'Redirect to what matters most' },
];

export default function VoicePersonalityPanel({ settings, onChange }) {
  const set = (key, val) => onChange({ ...settings, [key]: val });

  return (
    <div className="space-y-5">
      {/* Agent Identity */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Mic className="w-4 h-4 text-primary" />
            Agent Identity
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>Agent Name (how the bot introduces itself)</Label>
            <Input
              value={settings.bot_agent_name || ''}
              onChange={e => set('bot_agent_name', e.target.value)}
              placeholder="e.g. Alex, Jordan, Sam..."
            />
            <p className="text-xs text-muted-foreground mt-1">Replaces [Agent Name] in your script automatically</p>
          </div>
        </CardContent>
      </Card>

      {/* Voice Tone */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="w-4 h-4 text-primary" />
            Voice Tone & Energy
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {VOICES.map(v => (
              <button
                key={v.id}
                onClick={() => set('bot_voice', v.id)}
                className={`text-left p-3 rounded-xl border-2 transition-all ${
                  settings.bot_voice === v.id
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/40 hover:bg-muted/30'
                }`}
              >
                <div className="text-xl mb-1">{v.icon}</div>
                <div className="font-semibold text-sm">{v.label}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{v.desc}</div>
                {settings.bot_voice === v.id && (
                  <Badge className="mt-2 bg-primary/10 text-primary border-primary/20 text-[10px]">Active</Badge>
                )}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Sales Methodology */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Sales Methodology & Personality Style
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {STYLES.map(s => (
              <button
                key={s.id}
                onClick={() => set('bot_personality_style', s.id)}
                className={`w-full text-left p-3 rounded-lg border-2 transition-all flex items-start gap-3 ${
                  settings.bot_personality_style === s.id
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/30'
                }`}
              >
                <div className={`w-4 h-4 rounded-full border-2 flex-shrink-0 mt-0.5 transition-all ${
                  settings.bot_personality_style === s.id
                    ? 'border-primary bg-primary'
                    : 'border-muted-foreground'
                }`} />
                <div>
                  <div className="font-medium text-sm">{s.label}</div>
                  <div className="text-xs text-muted-foreground">{s.desc}</div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Objection Handling */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Brain className="w-4 h-4 text-primary" />
            Objection Handling Style
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {OBJECTION_STYLES.map(o => (
              <button
                key={o.id}
                onClick={() => set('bot_objection_style', o.id)}
                className={`text-left p-3 rounded-xl border-2 transition-all ${
                  settings.bot_objection_style === o.id
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/30'
                }`}
              >
                <div className="font-semibold text-sm">{o.label}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{o.desc}</div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Fine Tuning */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary" />
            Fine Tuning
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Talking Speed</Label>
            <div className="flex gap-2 mt-2">
              {['slow', 'normal', 'fast'].map(speed => (
                <button
                  key={speed}
                  onClick={() => set('bot_talking_speed', speed)}
                  className={`flex-1 py-2 rounded-lg border-2 text-sm font-medium capitalize transition-all ${
                    settings.bot_talking_speed === speed
                      ? 'border-primary bg-primary/5 text-primary'
                      : 'border-border hover:border-primary/30'
                  }`}
                >
                  {speed === 'slow' ? '🐢 Slow' : speed === 'normal' ? '🚶 Normal' : '🚀 Fast'}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label>Empathy Level (mirroring lead's emotional tone)</Label>
            <div className="flex gap-2 mt-2">
              {['low', 'medium', 'high'].map(level => (
                <button
                  key={level}
                  onClick={() => set('bot_empathy_level', level)}
                  className={`flex-1 py-2 rounded-lg border-2 text-sm font-medium capitalize transition-all ${
                    settings.bot_empathy_level === level
                      ? 'border-primary bg-primary/5 text-primary'
                      : 'border-border hover:border-primary/30'
                  }`}
                >
                  {level === 'low' ? '📊 Low' : level === 'medium' ? '💛 Medium' : '❤️ High'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 border border-border rounded-lg">
            <div>
              <Label className="mb-0">Allow Light Humor</Label>
              <p className="text-xs text-muted-foreground mt-0.5">Bot uses appropriate humor to build rapport</p>
            </div>
            <Switch
              checked={settings.bot_use_humor || false}
              onCheckedChange={v => set('bot_use_humor', v)}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}