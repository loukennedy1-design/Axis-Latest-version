import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Bluetooth, BluetoothConnected, BluetoothSearching,
  Headphones, Mic, Volume2, Phone, RefreshCw, Loader2, X, CheckCircle2
} from 'lucide-react';
import { toast } from 'sonner';

/**
 * BluetoothConnection — uses the Web Bluetooth API to connect to nearby
 * Bluetooth devices (headsets, phones) and the Media Devices API to
 * select Bluetooth audio input/output. This lets the rep use a Bluetooth
 * headset or a cell phone connected via Bluetooth as the audio source
 * for both manual and AI calls.
 */
export default function BluetoothConnection({ device, onChange }) {
  const [scanning, setScanning] = useState(false);
  const [audioDevices, setAudioDevices] = useState({ inputs: [], outputs: [] });
  const [selectedInput, setSelectedInput] = useState('');
  const [selectedOutput, setSelectedOutput] = useState('');
  const [connected, setConnected] = useState(false);
  const [bluetoothSupported, setBluetoothSupported] = useState(true);

  // ── Check Web Bluetooth support ───────────────────────────────────
  useEffect(() => {
    if (typeof navigator === 'undefined' || !navigator.bluetooth) {
      setBluetoothSupported(false);
    }
  }, []);

  // ── Enumerate audio devices (includes Bluetooth headsets) ─────────
  const refreshAudioDevices = useCallback(async () => {
    try {
      // Request permission first (needed for labels to appear)
      await navigator.mediaDevices.getUserMedia({ audio: true }).then(s => s.getTracks().forEach(t => t.stop())).catch(() => {});
      const devices = await navigator.mediaDevices.enumerateDevices();
      const inputs = devices.filter(d => d.kind === 'audioinput');
      const outputs = devices.filter(d => d.kind === 'audiooutput');
      setAudioDevices({ inputs, outputs });
      // Auto-select Bluetooth devices if found
      const btInput = inputs.find(d => /bluetooth|bt|headphone|airpods|galaxy buds/i.test(d.label));
      const btOutput = outputs.find(d => /bluetooth|bt|headphone|airpods|galaxy buds/i.test(d.label));
      if (btInput && !selectedInput) setSelectedInput(btInput.deviceId);
      if (btOutput && !selectedOutput) setSelectedOutput(btOutput.deviceId);
    } catch (e) {
      // Permission denied or not supported
    }
  }, [selectedInput, selectedOutput]);

  useEffect(() => { refreshAudioDevices(); }, []);

  // ── Connect to a Bluetooth device via Web Bluetooth API ───────────
  const handleBluetoothConnect = async () => {
    if (!navigator.bluetooth) {
      toast.error('Web Bluetooth is not supported in this browser. Use Chrome or Edge on desktop, or Chrome on Android.');
      return;
    }
    setScanning(true);
    try {
      const btDevice = await navigator.bluetooth.requestDevice({
        // Accept all Bluetooth audio devices nearby
        acceptAllDevices: true,
        optionalServices: ['generic_access', 'battery_service', 'device_information'],
      });

      const deviceInfo = {
        id: btDevice.id,
        name: btDevice.name || 'Bluetooth Device',
        type: 'bluetooth',
      };
      onChange?.(deviceInfo);
      setConnected(true);
      toast.success(`Connected to ${deviceInfo.name} via Bluetooth`);

      // Listen for disconnection
      btDevice.addEventListener('gattserverdisconnected', () => {
        setConnected(false);
        toast.info(`${deviceInfo.name} disconnected`);
        onChange?.(null);
      });

      // Try to connect GATT server (for battery/service info)
      try {
        const server = await btDevice.gatt.connect();
      } catch (_) {
        // GATT connection optional — device is still available for audio routing
      }

      // Refresh audio device list after connecting
      setTimeout(() => refreshAudioDevices(), 1000);
    } catch (e) {
      if (e.name !== 'NotFoundError') {
        toast.error(`Bluetooth connection failed: ${e.message}`);
      }
    } finally {
      setScanning(false);
    }
  };

  // ── Disconnect ────────────────────────────────────────────────────
  const handleDisconnect = () => {
    setConnected(false);
    onChange?.(null);
    toast.info('Bluetooth device disconnected');
  };

  // ── Apply audio device selection ───────────────────────────────────
  const applyAudioSelection = async () => {
    try {
      // Test that we can get a stream from the selected input
      if (selectedInput) {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            deviceId: { exact: selectedInput },
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        stream.getTracks().forEach(t => t.stop());
      }
      // Note: audio output selection requires setSinkId on audio elements
      // which is supported in Chrome/Edge
      toast.success('Audio devices updated');
    } catch (e) {
      toast.error(`Failed to apply audio settings: ${e.message}`);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm flex items-center gap-2">
          <Headphones className="w-4 h-4 text-primary" />
          Bluetooth & Audio Device Connection
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {!bluetoothSupported && (
          <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs text-amber-600">
            Web Bluetooth is not available in this browser. For full Bluetooth pairing, use Chrome or Edge. You can still select a Bluetooth headset below if your OS has it connected.
          </div>
        )}

        {/* Bluetooth pairing */}
        <div className="flex items-center justify-between p-3 rounded-lg border border-border bg-muted/20">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${connected ? 'bg-primary/20' : 'bg-muted'}`}>
              {connected ? <BluetoothConnected className="w-4 h-4 text-primary" /> : <Bluetooth className="w-4 h-4 text-muted-foreground" />}
            </div>
            <div>
              <p className="text-sm font-medium">
                {device ? device.name : 'No device paired'}
              </p>
              <p className="text-xs text-muted-foreground">
                {connected ? 'Bluetooth audio source active' : 'Pair a headset or cell phone for calls'}
              </p>
            </div>
          </div>
          {connected ? (
            <Button variant="outline" size="sm" onClick={handleDisconnect}>
              <X className="w-3.5 h-3.5" /> Disconnect
            </Button>
          ) : (
            <Button size="sm" onClick={handleBluetoothConnect} disabled={scanning || !bluetoothSupported}>
              {scanning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <BluetoothSearching className="w-3.5 h-3.5" />}
              {scanning ? 'Scanning...' : 'Pair Device'}
            </Button>
          )}
        </div>

        {/* Audio device selection */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Audio Routing</p>
            <Button variant="ghost" size="sm" onClick={refreshAudioDevices} className="h-6 text-xs">
              <RefreshCw className="w-3 h-3" /> Refresh
            </Button>
          </div>

          {/* Microphone input */}
          <div>
            <label className="text-xs text-muted-foreground flex items-center gap-1.5 mb-1">
              <Mic className="w-3 h-3" /> Microphone (Input)
            </label>
            <select
              value={selectedInput}
              onChange={e => setSelectedInput(e.target.value)}
              className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
            >
              <option value="">Default microphone</option>
              {audioDevices.inputs.map(d => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || `Microphone ${d.deviceId.slice(0, 8)}`}
                </option>
              ))}
            </select>
          </div>

          {/* Speaker output */}
          <div>
            <label className="text-xs text-muted-foreground flex items-center gap-1.5 mb-1">
              <Volume2 className="w-3 h-3" /> Speaker (Output)
            </label>
            <select
              value={selectedOutput}
              onChange={e => setSelectedOutput(e.target.value)}
              className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
            >
              <option value="">Default speaker</option>
              {audioDevices.outputs.map(d => (
                <option key={d.deviceId} value={d.deviceId}>
                  {d.label || `Speaker ${d.deviceId.slice(0, 8)}`}
                </option>
              ))}
            </select>
          </div>

          <Button size="sm" onClick={applyAudioSelection} className="w-full">
            <CheckCircle2 className="w-3.5 h-3.5" /> Apply Audio Settings
          </Button>
        </div>

        {/* Info note */}
        <div className="p-2 rounded-lg bg-muted/20 text-[11px] text-muted-foreground flex gap-2">
          <Phone className="w-3 h-3 mt-0.5 flex-shrink-0 text-primary/60" />
          <span>
            When you dial a lead, the call routes through your connected Bluetooth device or cell phone.
            For AI calls, the selected microphone captures your coaching voice and the speaker plays the AI conversation.
          </span>
        </div>
      </CardContent>
    </Card>
  );
}