import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Phone, PhoneOff, Play, Pause, Square, SkipForward, Clock,
  User, Building2, Calendar, X, CheckCircle2, Voicemail, PhoneCall,
  ListChecks, Headphones, ChevronRight, AlertCircle, RotateCcw,
  Globe, MessageCircle
} from 'lucide-react';
import { toast } from 'sonner';
import BluetoothConnection from './BluetoothConnection';
import CallCoachingPanel from './CallCoachingPanel';

const DISPOSITIONS = [
  { id: 'appointment_set', label: 'Appointment Set', icon: Calendar, color: 'bg-emerald-500 hover:bg-emerald-600 text-white' },
  { id: 'interested', label: 'Interested', icon: CheckCircle2, color: 'bg-primary hover:bg-primary/90 text-primary-foreground' },
  { id: 'callback_requested', label: 'Callback', icon: RotateCcw, color: 'bg-blue-500 hover:bg-blue-600 text-white' },
  { id: 'not_interested', label: 'Not Interested', icon: X, color: 'bg-amber-500 hover:bg-amber-600 text-white' },
  { id: 'voicemail', label: 'Voicemail', icon: Voicemail, color: 'bg-slate-500 hover:bg-slate-600 text-white' },
  { id: 'no_answer', label: 'No Answer', icon: PhoneOff, color: 'bg-muted hover:bg-muted/80 text-foreground' },
  { id: 'do_not_call', label: 'DNC', icon: AlertCircle, color: 'bg-red-500 hover:bg-red-600 text-white' },
];

const MANUAL_SERVICES = [
  { id: 'phone_link', label: 'Phone Link', icon: Phone, hint: 'tel: — routes via your cell phone or Windows Phone Link' },
  { id: 'google_voice', label: 'Google Voice', icon: PhoneCall, hint: 'Opens the Google Voice web dialer pre-filled with the number' },
  { id: 'whatsapp', label: 'WhatsApp', icon: MessageCircle, hint: 'Opens wa.me to chat/call via WhatsApp' },
  { id: 'custom_url', label: 'Custom', icon: Globe, hint: 'Your own dialer URL — use {phone} as the number placeholder' },
];

export default function ManualDialerMode({ eligibleLeads, script, settings, onCallLogged, onRefresh, bluetoothDevice, onBluetoothChange, providerType }) {
  const [autoDialing, setAutoDialing] = useState(false);
  const [paused, setPaused] = useState(false);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [inCall, setInCall] = useState(false);
  const [callStartTime, setCallStartTime] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [countdown, setCountdown] = useState(0);
  const [notes, setNotes] = useState('');
  const [stats, setStats] = useState({ called: 0, appointments: 0, notInterested: 0, noAnswer: 0, dnc: 0 });
  const [callOutcome, setCallOutcome] = useState(null);
  const [showBluetooth, setShowBluetooth] = useState(false);
  const [manualService, setManualService] = useState(
    () => localStorage.getItem('axis_manual_call_service') || 'phone_link'
  );
  const [customDialerUrl, setCustomDialerUrl] = useState(
    () => localStorage.getItem('axis_manual_custom_dialer_url') || ''
  );

  const callStartTimeRef = useRef(null);
  const countdownRef = useRef(null);
  const autoDialingRef = useRef(false);
  const pausedRef = useRef(false);
  const notesRef = useRef('');
  const currentLeadRef = useRef(null);
  const manualServiceRef = useRef(manualService);
  const customDialerUrlRef = useRef(customDialerUrl);

  const gapSeconds = settings?.call_gap_seconds || 30;
  const currentLead = eligibleLeads[currentIdx];

  // ── Elapsed timer ──────────────────────────────────────────────────
  useEffect(() => {
    if (!callStartTime) return;
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - callStartTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [callStartTime]);

  // ── Keep refs in sync ──────────────────────────────────────────────
  useEffect(() => { autoDialingRef.current = autoDialing; }, [autoDialing]);
  useEffect(() => { pausedRef.current = paused; }, [paused]);
  useEffect(() => { notesRef.current = notes; }, [notes]);
  useEffect(() => { currentLeadRef.current = currentLead; }, [currentLead]);
  useEffect(() => {
    manualServiceRef.current = manualService;
    localStorage.setItem('axis_manual_call_service', manualService);
  }, [manualService]);
  useEffect(() => {
    customDialerUrlRef.current = customDialerUrl;
    localStorage.setItem('axis_manual_custom_dialer_url', customDialerUrl);
  }, [customDialerUrl]);

  // ── Initiate a call via the selected manual calling service ─────────
  const initiateCall = useCallback((lead) => {
    if (!lead?.phone) {
      toast.error('This lead has no phone number — skipping');
      return false;
    }
    const cleaned = lead.phone.replace(/\s|\(|\)|-/g, '');
    const digits = cleaned.replace(/\D/g, '');
    const e164 = digits.length === 10 ? '1' + digits : digits;
    const service = manualServiceRef.current;

    setInCall(true);
    setCallStartTime(Date.now());
    setElapsed(0);
    setCallOutcome(null);
    setNotes('');

    if (service === 'google_voice') {
      // Open Google Voice's web dialer pre-filled with the lead's number (E.164).
      window.open(`https://voice.google.com/u/0/calls?a=nc,${encodeURIComponent('+' + e164)}`, '_blank', 'noopener,noreferrer');
      toast.success(`Opening Google Voice to call ${lead.first_name} ${lead.last_name} — ${lead.phone}`, { duration: 4000 });
    } else if (service === 'whatsapp') {
      window.open(`https://wa.me/${e164}`, '_blank', 'noopener,noreferrer');
      toast.success(`Opening WhatsApp for ${lead.first_name} ${lead.last_name} — ${lead.phone}`, { duration: 4000 });
    } else if (service === 'custom_url') {
      const template = (customDialerUrlRef.current || '').trim();
      if (!template.includes('{phone}')) {
        toast.error('Add a custom dialer URL containing {phone} in the Calling Service settings below.');
        setInCall(false);
        setCallStartTime(null);
        return false;
      }
      window.open(template.replace('{phone}', e164), '_blank', 'noopener,noreferrer');
      toast.success(`Opening custom dialer for ${lead.first_name} ${lead.last_name} — ${lead.phone}`, { duration: 4000 });
    } else {
      // phone_link — tel: protocol (cell phone via Bluetooth, or Windows Phone Link)
      try {
        window.location.href = `tel:${cleaned}`;
      } catch (_) {
        // Some browsers block programmatic tel: — user can click the dial button manually
      }
      toast.success(`Dialing ${lead.first_name} ${lead.last_name} — ${lead.phone}`, { duration: 3000 });
    }
    return true;
  }, []);

  // ── Start auto-dial sequence ───────────────────────────────────────
  const startAutoDial = () => {
    if (eligibleLeads.length === 0) {
      toast.error('No eligible leads in queue');
      return;
    }
    setAutoDialing(true);
    setPaused(false);
    setCurrentIdx(0);
    setStats({ called: 0, appointments: 0, notInterested: 0, noAnswer: 0, dnc: 0 });
    toast.success(`Auto-dialing started — ${eligibleLeads.length} leads queued, ${gapSeconds}s between calls`);
    // Start the first call after a brief delay
    setTimeout(() => initiateCall(eligibleLeads[0]), 500);
  };

  // ── Pause / resume ─────────────────────────────────────────────────
  const togglePause = () => {
    setPaused(p => {
      const next = !p;
      toast.info(next ? 'Auto-dial paused' : 'Auto-dial resumed');
      return next;
    });
  };

  // ── Stop auto-dial ────────────────────────────────────────────────
  const stopAutoDial = () => {
    setAutoDialing(false);
    setPaused(false);
    setInCall(false);
    setCallStartTime(null);
    setCountdown(0);
    if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
    toast.info('Auto-dialing stopped');
  };

  // ── Handle disposition ─────────────────────────────────────────────
  const handleDisposition = async (outcome) => {
    const lead = currentLeadRef.current;
    if (!lead) return;

    setCallOutcome(outcome);
    setInCall(false);
    setCallStartTime(null);

    // Update stats
    setStats(s => ({
      ...s,
      called: s.called + 1,
      appointments: s.appointments + (outcome === 'appointment_set' ? 1 : 0),
      notInterested: s.notInterested + (outcome === 'not_interested' ? 1 : 0),
      noAnswer: s.noAnswer + (outcome === 'no_answer' ? 1 : 0),
      dnc: s.dnc + (outcome === 'do_not_call' ? 1 : 0),
    }));

    // Log the call
    try {
      await base44.functions.invoke('axisVoiceEngine', {
        action: 'log_call',
        lead,
        transcript: '',
        summary: notesRef.current || `Manual call — ${outcome}`,
        outcome,
        duration_seconds: elapsed,
        direction: 'manual',
      });
      onCallLogged?.();
    } catch (_) { /* non-fatal */ }

    // If auto-dialing, advance to next lead after gap
    if (autoDialingRef.current && !pausedRef.current) {
      const nextIdx = currentIdx + 1;
      if (nextIdx >= eligibleLeads.length) {
        setAutoDialing(false);
        toast.success('Auto-dialing complete — all leads processed');
        setCurrentIdx(0);
        return;
      }
      // Countdown then dial next
      setCountdown(gapSeconds);
      countdownRef.current = setInterval(() => {
        setCountdown(c => {
          if (c <= 1) {
            if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
            setCurrentIdx(nextIdx);
            setCountdown(0);
            // Small delay to let state settle before dialing
            setTimeout(() => {
              if (autoDialingRef.current && !pausedRef.current) {
                initiateCall(eligibleLeads[nextIdx]);
              }
            }, 200);
            return 0;
          }
          return c - 1;
        });
      }, 1000);
    }
  };

  // ── Skip lead (no call made) ───────────────────────────────────────
  const skipLead = () => {
    const nextIdx = currentIdx + 1;
    if (nextIdx >= eligibleLeads.length) {
      setAutoDialing(false);
      toast.info('End of queue reached');
      return;
    }
    setCurrentIdx(nextIdx);
    if (autoDialingRef.current && !pausedRef.current) {
      setTimeout(() => initiateCall(eligibleLeads[nextIdx]), 500);
    }
  };

  // ── Manual dial (single call, not part of auto-sequence) ───────────
  const manualDial = (lead) => {
    setCurrentIdx(eligibleLeads.findIndex(l => l.id === lead.id));
    setAutoDialing(false);
    initiateCall(lead);
  };

  // ── End the live call (deactivate) without logging a disposition ──
  const endCall = () => {
    setInCall(false);
    setCallStartTime(null);
    setElapsed(0);
    setCallOutcome(null);
    toast.info('Call ended');
  };

  // ── Cleanup on unmount ────────────────────────────────────────────
  useEffect(() => {
    return () => {
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, []);

  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4">
      {/* Control bar */}
      <Card className="border-primary/20">
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${autoDialing ? 'bg-emerald-500/20' : 'bg-primary/10'}`}>
                <PhoneCall className={`w-5 h-5 ${autoDialing ? 'text-emerald-400 animate-pulse' : 'text-primary'}`} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Manual Dialer</h3>
                <p className="text-xs text-muted-foreground">
                  {autoDialing
                    ? `Auto-dialing · Lead ${currentIdx + 1} of ${eligibleLeads.length}${paused ? ' · PAUSED' : ''}`
                    : `${eligibleLeads.length} leads ready · ${gapSeconds}s between calls`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBluetooth(s => !s)}
                className={bluetoothDevice ? 'border-primary/40 text-primary' : ''}
              >
                <Headphones className="w-3.5 h-3.5" />
                {bluetoothDevice ? 'Device Connected' : 'Bluetooth'}
              </Button>
              {!autoDialing ? (
                <Button size="sm" onClick={startAutoDial} disabled={eligibleLeads.length === 0}>
                  <Play className="w-3.5 h-3.5" /> Start Dialing
                </Button>
              ) : (
                <>
                  <Button size="sm" variant="outline" onClick={togglePause}>
                    {paused ? <><Play className="w-3.5 h-3.5" /> Resume</> : <><Pause className="w-3.5 h-3.5" /> Pause</>}
                  </Button>
                  <Button size="sm" variant="destructive" onClick={stopAutoDial}>
                    <Square className="w-3.5 h-3.5" /> Stop
                  </Button>
                </>
              )}
            </div>
          </div>

          {/* Session stats */}
          {(autoDialing || stats.called > 0) && (
            <div className="grid grid-cols-5 gap-2 mt-4">
              {[
                { label: 'Called', value: stats.called, color: 'text-primary' },
                { label: 'Appts', value: stats.appointments, color: 'text-emerald-400' },
                { label: 'Not Interested', value: stats.notInterested, color: 'text-amber-400' },
                { label: 'No Answer', value: stats.noAnswer, color: 'text-slate-400' },
                { label: 'DNC', value: stats.dnc, color: 'text-red-400' },
              ].map(s => (
                <div key={s.label} className="text-center p-2 rounded-lg bg-muted/30">
                  <p className={`text-lg font-bold ${s.color}`}>{s.value}</p>
                  <p className="text-[10px] text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Calling service selector — how manual (non-AI) calls are placed */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="text-xs font-semibold flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-primary" /> Calling Service
              </p>
              <p className="text-[10px] text-muted-foreground mt-0.5">How manual calls are placed (non-AI mode)</p>
            </div>
            <div className="flex items-center gap-1.5 flex-wrap">
              {MANUAL_SERVICES.map(s => {
                const active = manualService === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => setManualService(s.id)}
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${active ? 'bg-primary text-primary-foreground border-primary' : 'border-border bg-muted/30 text-muted-foreground hover:text-foreground'}`}
                    title={s.hint}
                  >
                    <s.icon className="w-3.5 h-3.5" />
                    {s.label}
                  </button>
                );
              })}
            </div>
          </div>
          {manualService === 'custom_url' && (
            <div className="mt-3 flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
              <input
                value={customDialerUrl}
                onChange={e => setCustomDialerUrl(e.target.value)}
                placeholder="https://app.skype.com/call/{phone}"
                className="flex-1 h-8 rounded-md border border-input bg-transparent px-2.5 text-xs font-mono focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>
          )}
          <p className="text-[10px] text-muted-foreground mt-2">
            {MANUAL_SERVICES.find(s => s.id === manualService)?.hint}
            {manualService === 'custom_url' && ' — use {phone} where the E.164 number should go (e.g. Skype, RingCentral, OpenPhone).'}
          </p>

          {manualService === 'google_voice' && (
            <p className="text-[10px] text-muted-foreground mt-2">
              Make sure you're signed into Google Voice in your browser — calls open in a new tab, no account connection needed.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Bluetooth connection panel (collapsible) */}
      {showBluetooth && (
        <BluetoothConnection device={bluetoothDevice} onChange={onBluetoothChange} />
      )}

      {/* Countdown between calls */}
      {countdown > 0 && (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-amber-400 animate-pulse" />
              <div>
                <p className="text-sm font-medium">Next call in {countdown}s</p>
                <p className="text-xs text-muted-foreground">
                  {eligibleLeads[currentIdx + 1]?.first_name} {eligibleLeads[currentIdx + 1]?.last_name} — {eligibleLeads[currentIdx + 1]?.phone}
                </p>
              </div>
            </div>
            <Button size="sm" variant="outline" onClick={() => setCountdown(0)}>
              Skip Wait <SkipForward className="w-3.5 h-3.5 ml-1" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Current call view */}
      {currentLead && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Left: Lead info + call controls */}
          <div className="space-y-4">
            <Card className={inCall ? 'border-emerald-500/30 bg-emerald-500/5' : ''}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <User className="w-4 h-4 text-primary" />
                    {currentLead.first_name} {currentLead.last_name}
                  </CardTitle>
                  {inCall && (
                    <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 animate-pulse text-[10px]">
                      ● LIVE {formatTime(elapsed)}
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-1.5 text-xs">
                  {currentLead.phone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="w-3 h-3" />
                      <a href={`tel:${currentLead.phone.replace(/\s|\(|\)|-/g, '')}`} className="font-mono text-primary hover:underline">
                        {currentLead.phone}
                      </a>
                    </div>
                  )}
                  {currentLead.company && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Building2 className="w-3 h-3" /> {currentLead.company}
                    </div>
                  )}
                </div>

                {!inCall ? (
                  <Button
                    className="w-full"
                    onClick={() => manualDial(currentLead)}
                    disabled={!currentLead.phone}
                  >
                    <Phone className="w-4 h-4 mr-2" /> Dial Now
                  </Button>
                ) : (
                  <>
                    <Button variant="destructive" size="sm" className="w-full h-8 mb-2" onClick={endCall}>
                      <PhoneOff className="w-3.5 h-3.5 mr-1.5" /> End Call
                    </Button>
                    {/* Disposition buttons */}
                    <div className="space-y-1.5">
                      <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">Call Disposition</p>
                      <div className="grid grid-cols-2 gap-1.5">
                        {DISPOSITIONS.map(d => (
                          <Button
                            key={d.id}
                            size="sm"
                            className={`h-8 text-xs ${d.color}`}
                            onClick={() => handleDisposition(d.id)}
                          >
                            <d.icon className="w-3 h-3 mr-1" />
                            {d.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </>
                )}

                {callOutcome && (
                  <div className="p-2 rounded-lg bg-muted/40 text-xs flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Marked: <strong className="capitalize">{callOutcome.replace(/_/g, ' ')}</strong></span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Notes */}
            {inCall && (
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-xs flex items-center gap-1.5"><ListChecks className="w-3.5 h-3.5" /> Call Notes</CardTitle></CardHeader>
                <CardContent>
                  <Textarea
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                    placeholder="Take notes during the call..."
                    rows={4}
                    className="text-sm"
                  />
                </CardContent>
              </Card>
            )}
          </div>

          {/* Middle: Script display */}
          <div className="lg:col-span-1">
            <Card className="h-full">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs flex items-center gap-1.5">
                  <ListChecks className="w-3.5 h-3.5 text-primary" /> Call Script
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] overflow-y-auto rounded-lg border border-border bg-muted/20 p-3">
                  <pre className="whitespace-pre-wrap text-xs leading-relaxed text-muted-foreground font-sans">
                    {script || 'No script configured. Go to Agent Config to set up your call script.'}
                  </pre>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right: Call coaching */}
          <div className="lg:col-span-1">
            <CallCoachingPanel inCall={inCall} elapsed={elapsed} callOutcome={callOutcome} />
          </div>
        </div>
      )}

      {/* Queue */}
      {eligibleLeads.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xs flex items-center gap-1.5">
                <ChevronRight className="w-3.5 h-3.5" /> Up Next ({eligibleLeads.length - currentIdx - 1} remaining)
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={onRefresh} className="text-xs h-6">Refresh</Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-1 max-h-[200px] overflow-y-auto">
              {eligibleLeads.slice(currentIdx + 1, currentIdx + 11).map((lead, i) => (
                <div key={lead.id} className={`flex items-center justify-between p-2 rounded-lg border ${i === 0 && autoDialing ? 'border-amber-500/30 bg-amber-500/5' : 'border-border hover:bg-muted/30'}`}>
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xs text-muted-foreground w-6">{currentIdx + 1 + i + 1}</span>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{lead.first_name} {lead.last_name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{lead.phone}</p>
                    </div>
                  </div>
                  {!autoDialing && (
                    <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => manualDial(lead)} disabled={!lead.phone}>
                      <Phone className="w-3 h-3" /> Dial
                    </Button>
                  )}
                </div>
              ))}
              {eligibleLeads.length - currentIdx - 1 > 10 && (
                <p className="text-xs text-muted-foreground text-center py-2">+ {eligibleLeads.length - currentIdx - 11} more...</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {eligibleLeads.length === 0 && (
        <Card><CardContent className="py-12 text-center">
          <PhoneOff className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">No eligible leads in queue. Import leads with consent to start dialing.</p>
        </CardContent></Card>
      )}
    </div>
  );
}