import { useState, useEffect, useRef, useCallback } from 'react';
import { Mic, MicOff, Volume2, Brain, Loader2, PhoneOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

/**
 * AIVoiceInterface
 * Real-time AI voice conversation using Web Speech API.
 * Non-blocking mic permission + Chrome TTS keepalive to prevent screen freeze.
 */
export default function AIVoiceInterface({ script, lead, onConversationComplete, isActive }) {
  const [callStatus, setCallStatus] = useState('idle');
  const [conversationHistory, setConversationHistory] = useState([]);
  const [liveText, setLiveText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [browserSupported, setBrowserSupported] = useState(true);
  const [micError, setMicError] = useState(null);

  const recognitionRef = useRef(null);
  const synthRef = useRef(null);
  const voicesRef = useRef([]);
  const conversationRef = useRef([]);
  const currentStepRef = useRef(0);
  const callStatusRef = useRef('idle');
  const isListeningRef = useRef(false);
  const silenceTimerRef = useRef(null);
  const synthKeepaliveRef = useRef(null);
  const startedRef = useRef(false);

  useEffect(() => {
    callStatusRef.current = callStatus;
  }, [callStatus]);

  // Load voices async (Chrome loads them lazily)
  const loadVoices = useCallback(() => {
    const v = window.speechSynthesis.getVoices();
    if (v.length) {
      voicesRef.current = v;
    }
  }, []);

  // Initialize speech synthesis and recognition once
  useEffect(() => {
    if (typeof window === 'undefined') return;

    synthRef.current = window.speechSynthesis;

    // Voices may not be ready immediately in Chrome
    loadVoices();
    window.speechSynthesis.addEventListener('voiceschanged', loadVoices);

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setBrowserSupported(false);
      return;
    }

    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = 'en-US';

    rec.onresult = (event) => {
      const result = event.results[event.resultIndex];
      const text = result[0].transcript;
      setLiveText(text);
      if (result.isFinal && text.trim()) {
        handleUserSpeech(text.trim());
      }
    };

    rec.onerror = (event) => {
      if (event.error === 'not-allowed') {
        isListeningRef.current = false;
        setMicError('Microphone access denied. Please allow mic access and try again.');
      }
      // no-speech is normal — onend will restart
    };

    rec.onend = () => {
      if (isListeningRef.current && callStatusRef.current !== 'completed') {
        clearTimeout(silenceTimerRef.current);
        silenceTimerRef.current = setTimeout(() => {
          if (isListeningRef.current && callStatusRef.current !== 'completed') {
            try { rec.start(); } catch (_) {}
          }
        }, 300);
      }
    };

    recognitionRef.current = rec;

    return () => {
      clearTimeout(silenceTimerRef.current);
      clearInterval(synthKeepaliveRef.current);
      window.speechSynthesis.removeEventListener('voiceschanged', loadVoices);
      try { rec.stop(); } catch (_) {}
      synthRef.current?.cancel();
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Chrome bug: speechSynthesis pauses after ~15s if tab loses focus.
  // Keepalive: pause+resume every 10s while speaking.
  const startSynthKeepalive = useCallback(() => {
    clearInterval(synthKeepaliveRef.current);
    synthKeepaliveRef.current = setInterval(() => {
      if (synthRef.current?.speaking) {
        synthRef.current.pause();
        synthRef.current.resume();
      }
    }, 10000);
  }, []);

  const stopSynthKeepalive = useCallback(() => {
    clearInterval(synthKeepaliveRef.current);
  }, []);

  const speak = useCallback((text, onDone) => {
    if (!synthRef.current || !text) { onDone?.(); return; }
    synthRef.current.cancel();

    // Small delay so cancel() fully clears the queue before adding new utterance
    setTimeout(() => {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1;
      utterance.pitch = 1;
      utterance.volume = 1;

      const voices = voicesRef.current.length ? voicesRef.current : synthRef.current.getVoices();
      const preferred =
        voices.find(v => v.lang.startsWith('en-US') && (v.name.includes('Google') || v.name.includes('Natural'))) ||
        voices.find(v => v.lang.startsWith('en')) ||
        voices[0];
      if (preferred) utterance.voice = preferred;

      utterance.onstart = () => {
        setIsSpeaking(true);
        startSynthKeepalive();
      };
      utterance.onend = () => {
        setIsSpeaking(false);
        stopSynthKeepalive();
        onDone?.();
      };
      utterance.onerror = (e) => {
        // 'interrupted' is expected when we cancel — not a real error
        if (e.error !== 'interrupted') {
          setIsSpeaking(false);
          stopSynthKeepalive();
          onDone?.();
        }
      };

      synthRef.current.speak(utterance);
    }, 50);
  }, [startSynthKeepalive, stopSynthKeepalive]);

  const startListening = useCallback(() => {
    if (!recognitionRef.current) return;
    isListeningRef.current = true;
    try { recognitionRef.current.start(); } catch (_) {}
  }, []);

  const stopListening = useCallback(() => {
    isListeningRef.current = false;
    clearTimeout(silenceTimerRef.current);
    try { recognitionRef.current?.stop(); } catch (_) {}
  }, []);

  const finishCall = useCallback((outcome) => {
    if (callStatusRef.current === 'completed') return;
    setCallStatus('completed');
    callStatusRef.current = 'completed';
    stopListening();
    stopSynthKeepalive();
    synthRef.current?.cancel();
    setIsSpeaking(false);
    onConversationComplete?.(conversationRef.current, outcome);
  }, [stopListening, stopSynthKeepalive, onConversationComplete]);

  const getScriptLine = useCallback((stepIndex) => {
    const steps = script.split('\n\n').filter(s => s.trim());
    if (stepIndex >= steps.length) return null;
    return steps[stepIndex]
      .replace(/\[.*?\]/g, '')
      .replace(/^["']+|["']+$/g, '')
      .replace(/^[•\-]\s*/gm, '')
      .replace(/\[Lead Name\]/g, `${lead?.first_name || ''} ${lead?.last_name || ''}`)
      .replace(/\[Company Name\]/g, 'Axis AI')
      .trim();
  }, [script, lead]);

  const handleUserSpeech = useCallback((userText) => {
    if (callStatusRef.current === 'completed') return;
    const lower = userText.toLowerCase();

    const updated = [...conversationRef.current, { role: 'user', text: userText }];
    conversationRef.current = updated;
    setConversationHistory([...updated]);
    setLiveText('');

    if (lower.includes('stop') || lower.includes('remove') || lower.includes('unsubscribe') || lower.includes("don't call") || lower.includes('do not call')) {
      const resp = "Understood. You will no longer be contacted. Have a great day.";
      conversationRef.current = [...updated, { role: 'assistant', text: resp }];
      setConversationHistory([...conversationRef.current]);
      speak(resp, () => finishCall('dnc_requested'));
      return;
    }

    if (lower.includes('not interested') || lower.includes('no thanks') || lower.includes('no thank you') || lower.includes('goodbye') || lower.includes('busy')) {
      const resp = "I completely understand. Thank you for your time, have a wonderful day!";
      conversationRef.current = [...updated, { role: 'assistant', text: resp }];
      setConversationHistory([...conversationRef.current]);
      speak(resp, () => finishCall('not_interested'));
      return;
    }

    const lastAI = updated.filter(h => h.role === 'assistant').pop();
    if ((lower.includes('yes') || lower.includes('sure') || lower.includes('okay') || lower.includes('ok') || lower.includes('sounds good') || lower.includes('perfect') || lower.includes('that works')) &&
        lastAI && (lastAI.text.includes('work better') || lastAI.text.includes('available') || lastAI.text.includes('which time') || lastAI.text.includes('prefer'))) {
      const resp = "Perfect! I've got you scheduled. You'll receive a confirmation shortly. Looking forward to speaking with you!";
      conversationRef.current = [...updated, { role: 'assistant', text: resp }];
      setConversationHistory([...conversationRef.current]);
      speak(resp, () => finishCall('appointment_set'));
      return;
    }

    stopListening();
    setCallStatus('responding');
    const nextStep = currentStepRef.current;
    const line = getScriptLine(nextStep) || "Thank you for your time. Have a wonderful day!";
    const isLastStep = nextStep >= script.split('\n\n').filter(s => s.trim()).length - 1;

    currentStepRef.current = nextStep + 1;
    const aiUpdated = [...conversationRef.current, { role: 'assistant', text: line }];
    conversationRef.current = aiUpdated;
    setConversationHistory([...aiUpdated]);

    speak(line, () => {
      if (isLastStep) {
        finishCall('not_interested');
      } else {
        setCallStatus('listening');
        startListening();
      }
    });
  }, [speak, finishCall, startListening, stopListening, getScriptLine, script]);

  const startCall = useCallback(async () => {
    if (startedRef.current) return;
    startedRef.current = true;

    setCallStatus('intro');
    setConversationHistory([]);
    conversationRef.current = [];
    currentStepRef.current = 1;
    setMicError(null);

    // Request mic permission non-blocking — use Promise so UI stays responsive
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Release immediately — SpeechRecognition manages its own audio input
      stream.getTracks().forEach(t => t.stop());
    } catch (err) {
      startedRef.current = false;
      setCallStatus('idle');
      const isNotFound = err?.name === 'NotFoundError' || err?.name === 'DevicesNotFoundError';
      const isDenied = err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError';
      setMicError(
        isNotFound
          ? 'No microphone found. Please connect a mic or headset and try again.'
          : isDenied
          ? 'Microphone access blocked. Click the 🔒 lock icon → Site settings → Allow Microphone, then retry.'
          : `Microphone error: ${err?.message || 'Unknown'}. Check your system audio settings.`
      );
      return;
    }

    // Ensure voices are loaded before speaking
    if (!voicesRef.current.length) {
      voicesRef.current = synthRef.current?.getVoices() || [];
    }

    const opening = getScriptLine(0) || `Hi, is this ${lead?.first_name}? I'm an AI assistant calling about a quick opportunity. Do you have 60 seconds?`;
    const openingWithName = opening
      .replace('[Lead Name]', `${lead?.first_name || ''} ${lead?.last_name || ''}`)
      .replace('[Company Name]', 'Axis AI');

    const firstMsg = { role: 'assistant', text: openingWithName };
    conversationRef.current = [firstMsg];
    setConversationHistory([firstMsg]);
    setCallStatus('responding');

    speak(openingWithName, () => {
      if (callStatusRef.current !== 'completed') {
        setCallStatus('listening');
        startListening();
      }
    });
  }, [getScriptLine, lead, speak, startListening]);

  useEffect(() => {
    if (isActive && callStatus === 'idle' && !startedRef.current) {
      startCall();
    }
  }, [isActive]); // eslint-disable-line react-hooks/exhaustive-deps

  const stopCall = () => {
    startedRef.current = false;
    finishCall('call_stopped');
  };

  if (!browserSupported) {
    return (
      <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-700 text-sm">
        <p className="font-semibold">⚠️ Browser Not Supported</p>
        <p className="mt-1">AI Voice requires Chrome or Edge. Please switch browsers and try again.</p>
        <Button variant="outline" size="sm" className="mt-3" onClick={() => onConversationComplete?.([], 'no_answer')}>
          Skip to Next Lead
        </Button>
      </div>
    );
  }

  if (micError) {
    return (
      <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-sm space-y-3">
        <p className="font-semibold text-red-400">🎤 Microphone / Audio Error</p>
        <p className="text-red-300">{micError}</p>
        <div className="text-xs text-muted-foreground space-y-1">
          <p className="font-medium text-foreground">To fix this:</p>
          <p>1. Click the 🔒 lock icon in your browser's address bar</p>
          <p>2. Set <strong>Microphone</strong> → <strong>Allow</strong></p>
          <p>3. Ensure your system mic &amp; speakers are set as default in <strong>System Settings → Sound</strong></p>
          <p>4. Click <strong>Retry</strong> below</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" onClick={() => {
            startedRef.current = false;
            setMicError(null);
            setCallStatus('idle');
            setTimeout(() => startCall(), 100);
          }}>Retry</Button>
          <Button variant="outline" size="sm" onClick={() => {
            setMicError(null);
            onConversationComplete?.([], 'no_answer');
          }}>Skip Lead</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Status bar */}
      <div className={cn(
        "p-4 rounded-xl border flex items-center justify-between",
        callStatus === 'completed' ? 'border-emerald-500/30 bg-emerald-500/5' :
        callStatus === 'responding' ? 'border-primary/30 bg-primary/5' :
        callStatus === 'listening' ? 'border-blue-500/30 bg-blue-500/5' :
        'border-border bg-muted/30'
      )}>
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-full flex items-center justify-center",
            callStatus === 'completed' ? 'bg-emerald-500/20' :
            callStatus === 'responding' ? 'bg-primary/20 animate-pulse' :
            callStatus === 'listening' ? 'bg-blue-500/20' :
            'bg-muted'
          )}>
            {callStatus === 'intro' ? <Loader2 className="w-5 h-5 text-muted-foreground animate-spin" /> :
             callStatus === 'responding' ? <Volume2 className={cn("w-5 h-5", isSpeaking ? 'text-primary animate-pulse' : 'text-muted-foreground')} /> :
             callStatus === 'listening' ? <Mic className="w-5 h-5 text-blue-600" /> :
             callStatus === 'completed' ? <Brain className="w-5 h-5 text-emerald-600" /> :
             <MicOff className="w-5 h-5 text-muted-foreground" />}
          </div>
          <div>
            <p className="font-semibold text-sm">
              {callStatus === 'idle' && 'AI Voice Ready'}
              {callStatus === 'intro' && 'Requesting microphone...'}
              {callStatus === 'listening' && 'Listening to lead...'}
              {callStatus === 'responding' && (isSpeaking ? 'AI speaking...' : 'AI thinking...')}
              {callStatus === 'completed' && 'Call Completed'}
            </p>
            {liveText && callStatus === 'listening' && (
              <p className="text-xs text-blue-600 italic mt-0.5">"{liveText}"</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {callStatus !== 'idle' && callStatus !== 'completed' && (
            <Badge className={cn(
              "animate-pulse text-xs",
              callStatus === 'responding' ? 'bg-primary/10 text-primary border-primary/20' :
              'bg-blue-500/10 text-blue-600 border-blue-500/20'
            )}>
              {callStatus === 'responding' ? '🔊 Speaking' : '🎤 Listening'}
            </Badge>
          )}
        </div>
      </div>

      {/* Conversation transcript */}
      {conversationHistory.length > 0 && (
        <div className="rounded-xl border border-border bg-card p-4 space-y-2 max-h-52 overflow-y-auto">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Live Conversation</p>
          {conversationHistory.map((msg, idx) => (
            <div key={idx} className={cn(
              "p-2.5 rounded-lg text-sm",
              msg.role === 'user' ? 'bg-blue-500/10 border border-blue-500/20 ml-6' : 'bg-primary/10 border border-primary/20 mr-6'
            )}>
              <p className="text-[10px] font-semibold mb-0.5">{msg.role === 'user' ? '👤 Lead' : '🤖 AI'}</p>
              <p className="text-muted-foreground text-xs">{msg.text}</p>
            </div>
          ))}
        </div>
      )}

      {/* Controls */}
      <div className="flex items-center justify-center gap-3">
        {callStatus === 'idle' ? (
          <Button onClick={startCall} size="lg" className="gap-2 shadow-lg shadow-primary/20">
            <Brain className="w-5 h-5" />Start AI Call
          </Button>
        ) : callStatus === 'completed' ? (
          <p className="text-sm text-emerald-600 font-medium">✓ Call complete — moving to next lead...</p>
        ) : (
          <Button onClick={stopCall} variant="destructive" size="lg" className="gap-2">
            <PhoneOff className="w-5 h-5" />End Call Early
          </Button>
        )}
      </div>
    </div>
  );
}