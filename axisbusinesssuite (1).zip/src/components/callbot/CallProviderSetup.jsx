import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Zap, CheckCircle2, Loader2, ArrowLeft, Shield, ExternalLink,
  Phone, Globe, Mic, Settings, AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';

const PROVIDERS = [
  {
    id: 'bland',
    name: 'Bland.ai',
    icon: Zap,
    color: 'text-violet-400',
    bg: 'from-violet-500/10 to-violet-500/5',
    border: 'border-violet-500/30',
    badge: '⚡ Easiest — 1 field',
    difficulty: 1,
    description: 'AI-powered calling that handles the entire conversation autonomously. Just paste your API key and you\'re calling in 2 minutes.',
    fields: [
      { key: 'bland_api_key', label: 'Bland.ai API Key', type: 'password', placeholder: 'org-xxxxxxxx-xxxx-xxxx', required: true,
        help: 'Found in Bland.ai Dashboard → API Keys tab.',
        link: 'https://app.bland.ai/api-keys' },
    ],
  },
  {
    id: 'vapi',
    name: 'Vapi.ai',
    icon: Mic,
    color: 'text-blue-400',
    bg: 'from-blue-500/10 to-blue-500/5',
    border: 'border-blue-500/30',
    badge: '⚡ Simple — 2 fields',
    difficulty: 1,
    description: 'Real-time AI voice conversations on Vapi\'s infrastructure. Enter your API key and select an assistant.',
    fields: [
      { key: 'vapi_api_key', label: 'Vapi.ai API Key', type: 'password', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx', required: true,
        help: 'Found in Vapi Dashboard → API Keys.',
        link: 'https://dashboard.vapi.ai/api-keys' },
      { key: 'vapi_assistant_id', label: 'Assistant ID', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx', required: true,
        help: 'Create an assistant in Vapi Dashboard → Assistants, then copy its ID.',
        link: 'https://dashboard.vapi.ai/assistants' },
    ],
  },
  {
    id: 'signalwire',
    name: 'SignalWire',
    icon: Phone,
    color: 'text-emerald-400',
    bg: 'from-emerald-500/10 to-emerald-500/5',
    border: 'border-emerald-500/30',
    badge: '🔧 Advanced — 3 fields',
    difficulty: 2,
    description: 'A cheaper, developer-friendly Twilio alternative. Uses the same REST API format at lower per-minute rates.',
    fields: [
      { key: 'signalwire_space_url', label: 'Space URL', type: 'text', placeholder: 'yourspace.signalwire.com', required: true,
        help: 'Found in your SignalWire Dashboard URL bar — it\'s the subdomain before .signalwire.com.',
        link: 'https://signalwire.com/dashboard' },
      { key: 'signalwire_project_id', label: 'Project ID', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxx', required: true,
        help: 'Dashboard → API → REST API → Project ID. It\'s the long UUID at the top of your API credentials page.',
        link: 'https://signalwire.com/dashboard/credentials' },
      { key: 'signalwire_api_token', label: 'API Token', type: 'password', placeholder: 'PTxxxxxxxxxxxxxxxxxxxxxxxx', required: true,
        help: 'Dashboard → API → REST API → Token. Click "Copy" next to the token field.',
        link: 'https://signalwire.com/dashboard/credentials' },
      { key: 'signalwire_phone_number', label: 'From Number (E.164)', type: 'text', placeholder: '+15551234567', required: true,
        help: 'Buy a number in Dashboard → Phone Numbers, then copy it here in E.164 format.',
        link: 'https://signalwire.com/dashboard/phone-numbers' },
    ],
  },
  {
    id: 'twilio',
    name: 'Twilio',
    icon: Phone,
    color: 'text-rose-400',
    bg: 'from-rose-500/10 to-rose-500/5',
    border: 'border-rose-500/30',
    badge: '🔧 3 fields',
    difficulty: 2,
    description: 'The industry standard for programmatic calling. Use your existing Twilio account or create one in minutes.',
    fields: [
      { key: 'twilio_account_sid', label: 'Account SID', type: 'text', placeholder: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', required: true,
        help: 'Console → Home → Account Info → Account SID (starts with AC).',
        link: 'https://console.twilio.com' },
      { key: 'twilio_auth_token', label: 'Auth Token', type: 'password', placeholder: '••••••••••••••••••••••••', required: true,
        help: 'Console → Home → Account Info → Auth Token (click "Show" to reveal, then copy).',
        link: 'https://console.twilio.com' },
      { key: 'twilio_phone_number', label: 'Twilio Phone Number', type: 'text', placeholder: '+15551234567', required: true,
        help: 'Console → Phone Numbers → Manage → Active numbers. Buy one if you don\'t have it yet.',
        link: 'https://console.twilio.com/us1/develop/phone-numbers/manage/active' },
    ],
  },
  {
    id: 'browser',
    name: 'Browser AI Voice',
    icon: Globe,
    color: 'text-amber-400',
    bg: 'from-amber-500/10 to-amber-500/5',
    border: 'border-amber-500/30',
    badge: '⚡ No credentials — instant',
    difficulty: 0,
    description: 'Use your computer\'s microphone and speakers. The AI speaks and listens in real-time through your browser. Perfect for testing.',
    fields: [],
  },
  {
    id: 'google_voice',
    name: 'Google Voice',
    icon: Phone,
    color: 'text-blue-400',
    bg: 'from-blue-500/10 to-blue-500/5',
    border: 'border-blue-500/30',
    badge: '📞 Manual · No API key',
    difficulty: 0,
    description: 'Place outbound calls through your Google Voice number. Clicking Dial opens Google Voice pre-filled with the lead\'s number — just sign in to your Google Voice account. Best for manual dialing.',
    fields: [],
  },
];

export default function CallProviderSetup({ onProviderConnected, compact = false }) {
  const [step, setStep] = useState(0); // 0=select, 1=credentials, 2=validate
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [credentials, setCredentials] = useState({});
  const [validating, setValidating] = useState(false);
  const [validationResult, setValidationResult] = useState(null);
  const [saving, setSaving] = useState(false);
  const qc = useQueryClient();
  const { user } = useCurrentUser();

  const { data: sysSettings = [] } = useQuery({
    queryKey: ['system-settings', user?.email],
    queryFn: () => {
      if (!user?.email) return [];
      return base44.entities.SystemSettings.filter({ key: `industry_${user.email}`, owner: user.email });
    },
    enabled: !!user?.email,
  });

  const settings = sysSettings[0];
  const activeProvider = settings?.provider_type && settings.provider_type !== 'none'
    ? settings.provider_type
    : settings?.default_call_service && !['ai_simulation', 'phone_link', 'zoom', 'whatsapp', 'custom_api'].includes(settings.default_call_service)
    ? settings.default_call_service
    : null;

  // If a provider is already connected, show the setup as complete
  if (activeProvider && !selectedProvider && step === 0 && !compact) {
    const provider = PROVIDERS.find(p => p.id === activeProvider);
    if (provider) {
      return (
        <Card className={cn('border-emerald-500/30 bg-gradient-to-br from-emerald-500/5 to-card', provider.bg)}>
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <p className="font-semibold text-sm">{provider.name} is connected</p>
                  <p className="text-xs text-muted-foreground">
                    {settings[`${activeProvider}_verified`] ? '✅ Credentials verified' : '⚠️ Not verified yet'}
                    {settings.last_test_call_at && ` · Last test: ${new Date(settings.last_test_call_at).toLocaleDateString()}`}
                  </p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => { setSelectedProvider(provider); setStep(1); }}>
                <Settings className="w-3.5 h-3.5 mr-1.5" />Manage
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    }
  }

  const selectProvider = (provider) => {
    setSelectedProvider(provider);
    // Pre-fill existing credentials
    const existing = {};
    if (settings) {
      provider.fields.forEach(f => {
        if (settings[f.key]) existing[f.key] = settings[f.key];
      });
    }
    setCredentials(existing);
    if (provider.id === 'browser') {
      setStep(2); // Skip credentials, go to activate
    } else {
      setStep(1);
    }
  };

  const handleValidate = async () => {
    if (!selectedProvider || selectedProvider.id === 'browser') {
      await handleActivateBrowser();
      return;
    }

    // Check required fields
    const missing = selectedProvider.fields.filter(f => f.required && !credentials[f.key]);
    if (missing.length > 0) {
      toast.error(`Please fill in: ${missing.map(f => f.label).join(', ')}`);
      return;
    }

    setValidating(true);
    setValidationResult(null);

    try {
      // Save credentials first
      await saveCredentials();

      // Then validate
      const res = await base44.functions.invoke('dispatchAICall', {
        action: 'validate',
        provider: selectedProvider.id,
      });

      const result = res.data || res;
      setValidationResult(result);

      if (result.valid) {
        toast.success(`✅ ${selectedProvider.name} credentials verified!`);
        // Mark as active provider
        await activateProvider();
        setStep(2);
      } else {
        toast.error(result.message || 'Validation failed');
      }
    } catch (e) {
      setValidationResult({ valid: false, message: e.message });
      toast.error('Validation failed: ' + e.message);
    } finally {
      setValidating(false);
    }
  };

  const saveCredentials = async () => {
    const payload = { ...credentials };
    await base44.functions.invoke('saveUserSettings', {
      action: 'save',
      data: payload,
    });
    qc.invalidateQueries({ queryKey: ['system-settings'] });
    // Wait a moment for the invalidation to refetch
    await new Promise(r => setTimeout(r, 500));
  };

  const activateProvider = async () => {
    setSaving(true);
    try {
      const payload = {
        provider_type: selectedProvider.id,
        default_call_service: selectedProvider.id,
        [`${selectedProvider.id}_verified`]: true,
        [`${selectedProvider.id}_verified_at`]: new Date().toISOString(),
      };

      if (settings) {
        await base44.entities.SystemSettings.update(settings.id, payload);
      } else {
        await base44.functions.invoke('createRecord', {
          entity: 'SystemSettings',
          data: { key: `industry_${user.email}`, ...payload, owner: user.email },
        });
      }
      qc.invalidateQueries({ queryKey: ['system-settings'] });

      if (selectedProvider.id === 'bland' || selectedProvider.id === 'vapi') {
        toast.success(`🚀 ${selectedProvider.name} is active! The AI will now place real autonomous calls.`);
      } else if (selectedProvider.id === 'browser') {
        toast.success(`🎤 Browser AI Voice is active! Click "Start Dialing" to begin.`);
      } else {
        toast.success(`📞 ${selectedProvider.name} is active! The dialer will use it for outbound calls.`);
      }

      onProviderConnected?.(selectedProvider.id);
    } catch (e) {
      toast.error('Failed to activate: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleActivateBrowser = async () => {
    setSaving(true);
    try {
      const payload = {
        provider_type: 'browser',
        default_call_service: 'browser',
      };
      if (settings) {
        await base44.entities.SystemSettings.update(settings.id, payload);
      } else {
        await base44.functions.invoke('createRecord', {
          entity: 'SystemSettings',
          data: { key: `industry_${user.email}`, ...payload, owner: user.email },
        });
      }
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success('🎤 Browser AI Voice activated! No credentials needed — just click Start Dialing.');
      onProviderConnected?.('browser');
      setStep(2);
    } catch (e) {
      toast.error('Failed to activate: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  // Activate a no-credentials manual provider (e.g. Google Voice).
  const handleActivateNoCreds = async () => {
    setSaving(true);
    try {
      const payload = {
        provider_type: selectedProvider.id,
        default_call_service: selectedProvider.id,
        [`${selectedProvider.id}_verified`]: true,
        [`${selectedProvider.id}_verified_at`]: new Date().toISOString(),
      };
      if (settings) {
        await base44.entities.SystemSettings.update(settings.id, payload);
      } else {
        await base44.functions.invoke('createRecord', {
          entity: 'SystemSettings',
          data: { key: `industry_${user.email}`, ...payload, owner: user.email },
        });
      }
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success(`📞 ${selectedProvider.name} is active! Use the Manual Dialer to place calls through your Google Voice number.`);
      onProviderConnected?.(selectedProvider.id);
      setStep(2);
    } catch (e) {
      toast.error('Failed to activate: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleTestCall = async () => {
    // For Bland.ai/Vapi.ai: the test call goes TO the user's own number (caller_id_number)
    // For Twilio/SignalWire: the test call goes FROM their purchased number TO the user's number
    const testNumber = settings?.caller_id_number || settings?.twilio_phone_number || settings?.signalwire_phone_number || credentials.twilio_phone_number || credentials.signalwire_phone_number;
    if (!testNumber && selectedProvider.id !== 'browser') {
      toast.error('Add your phone number in Settings → Your Business (Caller ID Number) to place a test call to yourself.');
      return;
    }
    setValidating(true);
    try {
      const res = await base44.functions.invoke('dispatchAICall', {
        action: 'test_call',
        provider: selectedProvider.id,
        phone_number: testNumber,
      });
      const result = res.data || res;
      if (result.success) {
        toast.success(`📞 Test call placed to ${testNumber}! Check your phone in a few seconds.`);
        // Update last test call timestamp
        if (settings) {
          await base44.entities.SystemSettings.update(settings.id, { last_test_call_at: new Date().toISOString() });
          qc.invalidateQueries({ queryKey: ['system-settings'] });
        }
      } else {
        toast.error(result.error || 'Test call failed');
      }
    } catch (e) {
      toast.error('Test call failed: ' + e.message);
    } finally {
      setValidating(false);
    }
  };

  const reset = () => {
    setStep(0);
    setSelectedProvider(null);
    setCredentials({});
    setValidationResult(null);
  };

  // ── Step 0: Provider Selection ─────────────────────────────────────
  if (step === 0) {
    return (
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-card">
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center text-primary font-bold text-sm">1</div>
            <h3 className="font-semibold text-base">Connect Your Calling Service</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-4 ml-10">
            Pick a provider below — you'll be making real AI calls in under 10 minutes. Bland.ai and Vapi.ai are recommended for fully autonomous calling.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {PROVIDERS.map((provider) => {
              const Icon = provider.icon;
              const isActive = activeProvider === provider.id;
              return (
                <button
                  key={provider.id}
                  onClick={() => selectProvider(provider)}
                  className={cn(
                    'relative text-left p-4 rounded-xl border-2 transition-all hover:scale-[1.02] bg-gradient-to-br',
                    provider.bg, provider.border,
                    isActive && 'ring-2 ring-emerald-500/50',
                  )}
                >
                  {isActive && (
                    <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center">
                      <CheckCircle2 className="w-3 h-3 text-white" />
                    </div>
                  )}
                  <div className="flex items-start gap-3">
                    <div className={cn('w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 bg-background/50', provider.color)}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="font-semibold text-sm">{provider.name}</p>
                      </div>
                      <Badge variant="outline" className={cn('text-[10px] mb-1.5', provider.color)}>
                        {provider.badge}
                      </Badge>
                      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">{provider.description}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>
    );
  }

  // ── Step 1: Enter Credentials ─────────────────────────────────────
  if (step === 1 && selectedProvider) {
    return (
      <Card className={cn('border-2 bg-gradient-to-br', selectedProvider.bg, selectedProvider.border)}>
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <button onClick={reset} className="p-1 rounded hover:bg-muted/50">
              <ArrowLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <div className="flex items-center gap-2">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm bg-primary/15 text-primary')}>2</div>
              <h3 className="font-semibold text-base">Enter {selectedProvider.name} Credentials</h3>
            </div>
          </div>

          {selectedProvider.fields.length === 0 ? (
            <div className="text-center py-6">
              {selectedProvider.id === 'browser'
                ? <Globe className="w-10 h-10 text-amber-400 mx-auto mb-3" />
                : <Phone className="w-10 h-10 text-blue-400 mx-auto mb-3" />}
              <p className="text-sm font-medium mb-1">No credentials needed!</p>
              <p className="text-xs text-muted-foreground mb-4">
                {selectedProvider.id === 'browser'
                  ? "Browser AI Voice uses your computer's microphone and speakers directly."
                  : "Google Voice opens the web dialer pre-filled with each lead's number. Make sure you're signed in to your Google Voice account."}
              </p>
              <Button
                onClick={selectedProvider.id === 'browser' ? handleActivateBrowser : handleActivateNoCreds}
                disabled={saving}
                className="gap-2"
              >
                {saving
                  ? <Loader2 className="w-4 h-4 animate-spin" />
                  : selectedProvider.id === 'browser' ? <Mic className="w-4 h-4" /> : <Phone className="w-4 h-4" />}
                {saving ? 'Activating...' : `Activate ${selectedProvider.name}`}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {selectedProvider.fields.map((field) => (
                <div key={field.key} className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label className="text-xs font-medium">{field.label}{field.required && <span className="text-rose-500 ml-0.5">*</span>}</Label>
                    {field.link && (
                      <a href={field.link} target="_blank" rel="noopener noreferrer" className="text-[10px] text-primary hover:underline flex items-center gap-0.5">
                        <ExternalLink className="w-2.5 h-2.5" />Get it
                      </a>
                    )}
                  </div>
                  <Input
                    type={field.type || 'text'}
                    placeholder={field.placeholder}
                    value={credentials[field.key] || ''}
                    onChange={e => setCredentials(c => ({ ...c, [field.key]: e.target.value }))}
                    className="h-9 text-sm"
                  />
                  {field.help && (
                    <p className="text-[10px] text-muted-foreground flex items-start gap-1">
                      <Shield className="w-2.5 h-2.5 mt-0.5 flex-shrink-0" />
                      {field.help}
                    </p>
                  )}
                </div>
              ))}

              <div className="flex items-center gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={reset}>
                  <ArrowLeft className="w-3.5 h-3.5 mr-1" />Back
                </Button>
                <Button onClick={handleValidate} disabled={validating} size="sm" className="gap-2 ml-auto">
                  {validating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                  {validating ? 'Validating...' : 'Test & Activate'}
                </Button>
              </div>

              {validationResult && !validationResult.valid && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-lg flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-medium text-rose-400">Validation Failed</p>
                    <p className="text-xs text-muted-foreground">{validationResult.message}</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  // ── Step 2: Validated / Active ────────────────────────────────────
  if (step === 2 && selectedProvider) {
    const Icon = selectedProvider.icon;
    return (
      <Card className={cn('border-2 border-emerald-500/30 bg-gradient-to-br from-emerald-500/5 to-card', selectedProvider.bg)}>
        <CardContent className="p-5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-semibold text-base flex items-center gap-2">
                <Icon className={cn('w-4 h-4', selectedProvider.color)} />
                {selectedProvider.name} is ready!
              </h3>
              <p className="text-xs text-muted-foreground">Your calling service is connected and verified.</p>
            </div>
          </div>

          {selectedProvider.id !== 'browser' && selectedProvider.id !== 'google_voice' && (
            <div className="space-y-3">
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <p className="text-xs text-emerald-700">Credentials verified successfully.</p>
              </div>

              <Button onClick={handleTestCall} disabled={validating} variant="outline" size="sm" className="gap-2 w-full">
                {validating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Phone className="w-3.5 h-3.5" />}
                {validating ? 'Placing test call...' : 'Place a 15-second Test Call'}
              </Button>
              <p className="text-[10px] text-muted-foreground text-center">
                We'll call your own number to confirm everything works end-to-end.
              </p>
            </div>
          )}

          {selectedProvider.id === 'google_voice' && (
            <div className="space-y-3">
              <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg flex items-center gap-2">
                <Phone className="w-4 h-4 text-blue-400 flex-shrink-0" />
                <p className="text-xs text-blue-700">Google Voice is ready. Use the Manual Dialer — each call opens Google Voice pre-filled with the lead's number.</p>
              </div>
              <a href="https://voice.google.com" target="_blank" rel="noopener noreferrer" className="text-xs text-primary hover:underline flex items-center gap-1 justify-center">
                <ExternalLink className="w-3 h-3" /> Open Google Voice
              </a>
            </div>
          )}

          <div className="flex items-center gap-2 pt-3 border-t border-border mt-3">
            <Button variant="outline" size="sm" onClick={reset}>
              <Settings className="w-3.5 h-3.5 mr-1" />Switch Provider
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return null;
}