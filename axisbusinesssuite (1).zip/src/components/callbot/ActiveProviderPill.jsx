import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { cn } from '@/lib/utils';
import { ChevronDown } from 'lucide-react';
import { useCurrentUser } from '@/hooks/useCurrentUser';

const PROVIDER_LABELS = {
  axis_native_ai: 'AXIS Native AI',
  bland: 'Bland.ai',
  vapi: 'Vapi.ai',
  signalwire: 'SignalWire',
  twilio: 'Twilio',
  browser: 'Browser AI',
  google_voice: 'Google Voice',
  custom_api: 'Custom API',
  ai_simulation: 'AI Simulation',
  phone_link: 'Phone Link',
  zoom: 'AXIS Meet',
  whatsapp: 'WhatsApp',
  none: 'Not Connected',
};

const PROVIDER_COLORS = {
  axis_native_ai: 'bg-primary/15 text-primary border-primary/30',
  bland: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  vapi: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  signalwire: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  twilio: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
  browser: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  google_voice: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  custom_api: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  ai_simulation: 'bg-primary/10 text-primary border-primary/20',
  phone_link: 'bg-muted text-muted-foreground border-border',
  zoom: 'bg-primary/10 text-primary border-primary/20',
  whatsapp: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  none: 'bg-muted text-muted-foreground border-border',
};

/**
 * ActiveProviderPill — shows the current calling provider name and status.
 * Clicking it opens the provider settings drawer.
 */
export default function ActiveProviderPill({ onClick }) {
  const { user } = useCurrentUser();
  const [testing, setTesting] = useState(false);

  const { data: sysSettings = [] } = useQuery({
    queryKey: ['system-settings', user?.email],
    queryFn: () => {
      if (!user?.email) return [];
      return base44.entities.SystemSettings.filter({ key: `industry_${user.email}`, owner: user.email });
    },
    enabled: !!user?.email,
  });

  const settings = sysSettings[0];
  const providerType = settings?.provider_type && settings.provider_type !== 'none'
    ? settings.provider_type
    : settings?.default_call_service || 'none';

  const isVerified = settings ? !!settings[`${providerType}_verified`] : false;
  const label = PROVIDER_LABELS[providerType] || 'Not Connected';
  const colorClass = PROVIDER_COLORS[providerType] || PROVIDER_COLORS.none;

  const statusDot = providerType === 'none' ? 'bg-muted-foreground'
    : isVerified ? 'bg-emerald-400'
    : 'bg-amber-400';

  return (
    <button
      onClick={onClick}
      className={cn(
        'flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all hover:scale-[1.02]',
        colorClass,
      )}
      title="Click to manage calling provider"
    >
      <span className={cn('w-2 h-2 rounded-full', statusDot, !isVerified && providerType !== 'none' && 'animate-pulse')} />
      <span>{label}</span>
      <ChevronDown className="w-3 h-3 opacity-50" />
    </button>
  );
}