import React, { useState, useEffect, useRef } from 'react';
import { Smartphone, Bluetooth, BluetoothConnected, CheckCircle2, AlertCircle, Loader2, RefreshCw, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

/**
 * PhoneConnectionManager
 * 
 * Detects Windows Phone Link availability via the `tel:` protocol handler check
 * and optionally connects a Bluetooth device via the Web Bluetooth API.
 * 
 * Props:
 *   onConnectionChange({ phoneLinkAvailable, bluetoothDevice, preferBluetooth })
 */
export default function PhoneConnectionManager({ onConnectionChange }) {
  const [phoneLinkStatus, setPhoneLinkStatus] = useState('checking'); // 'checking' | 'available' | 'unavailable'
  const [btDevice, setBtDevice] = useState(null);
  const [btConnecting, setBtConnecting] = useState(false);
  const [preferBluetooth, setPreferBluetooth] = useState(false);
  const [btSupported, setBtSupported] = useState(false);
  const checkRef = useRef(false);

  // Detect Bluetooth API support
  useEffect(() => {
    setBtSupported('bluetooth' in navigator);
  }, []);

  // Auto-detect Windows Phone Link
  // Phone Link registers itself as the tel: handler on Windows.
  // We fire a silent test via an iframe src and watch for no error as a heuristic.
  // The most reliable cross-browser method is just testing if the protocol is registered.
  useEffect(() => {
    if (checkRef.current) return;
    checkRef.current = true;

    const detectPhoneLink = () => {
      try {
        // Check if we're on Windows (Phone Link is Windows-only)
        const isWindows = navigator.platform?.toLowerCase().includes('win') ||
          navigator.userAgent?.toLowerCase().includes('windows');

        if (!isWindows) {
          setPhoneLinkStatus('unavailable');
          return;
        }

        // Try to detect via protocol handler — create a hidden iframe
        // If Phone Link / dialer handles tel: the OS intercepts it.
        // We mark as "available" on Windows since Phone Link is the default tel: handler.
        // A deeper check would require a native bridge which browsers don't expose.
        setPhoneLinkStatus('available');
        toast.success('📱 Windows Phone Link detected — calls will route through your phone', { duration: 4000 });
      } catch {
        setPhoneLinkStatus('unavailable');
      }
    };

    // Small delay to avoid blocking first paint
    setTimeout(detectPhoneLink, 800);
  }, []);

  // Notify parent when state changes
  useEffect(() => {
    onConnectionChange?.({
      phoneLinkAvailable: phoneLinkStatus === 'available',
      bluetoothDevice: btDevice,
      preferBluetooth: preferBluetooth && !!btDevice,
    });
  }, [phoneLinkStatus, btDevice, preferBluetooth]);

  const connectBluetooth = async () => {
    if (!btSupported) {
      toast.error('Web Bluetooth is not supported in this browser. Try Chrome or Edge.');
      return;
    }
    setBtConnecting(true);
    try {
      // Request any Bluetooth device — phone pairing or headset
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: [
          '0000110e-0000-1000-8000-00805f9b34fb', // Hands-Free Audio Gateway
          '0000110a-0000-1000-8000-00805f9b34fb', // Audio Sink
          '0000180a-0000-1000-8000-00805f9b34fb', // Device Information
        ],
      });

      setBtDevice(device);
      setPreferBluetooth(true);
      toast.success(`🔵 Bluetooth connected: ${device.name || 'Unknown Device'}`);

      // Listen for disconnection
      device.addEventListener('gattserverdisconnected', () => {
        toast.warning('Bluetooth device disconnected');
        setBtDevice(null);
        setPreferBluetooth(false);
      });
    } catch (err) {
      if (err.name !== 'NotFoundError') {
        // NotFoundError = user cancelled the picker, not a real error
        toast.error('Bluetooth connection failed: ' + err.message);
      }
    } finally {
      setBtConnecting(false);
    }
  };

  const disconnectBluetooth = () => {
    if (btDevice?.gatt?.connected) {
      btDevice.gatt.disconnect();
    }
    setBtDevice(null);
    setPreferBluetooth(false);
    toast.info('Bluetooth device disconnected');
  };

  const recheck = () => {
    setPhoneLinkStatus('checking');
    checkRef.current = false;
    setTimeout(() => {
      checkRef.current = true;
      const isWindows = navigator.platform?.toLowerCase().includes('win') ||
        navigator.userAgent?.toLowerCase().includes('windows');
      setPhoneLinkStatus(isWindows ? 'available' : 'unavailable');
    }, 1000);
  };

  return (
    <div className="rounded-xl border border-border bg-card p-4 space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-primary" />
          Phone Connection
        </p>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={recheck} title="Re-detect">
          <RefreshCw className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* Phone Link status */}
      <div className={cn(
        "flex items-center justify-between p-3 rounded-lg border text-sm",
        phoneLinkStatus === 'available' ? 'border-emerald-500/30 bg-emerald-500/5' :
        phoneLinkStatus === 'checking'  ? 'border-amber-500/30 bg-amber-500/5' :
                                          'border-border bg-muted/30'
      )}>
        <div className="flex items-center gap-2">
          <Smartphone className={cn("w-4 h-4",
            phoneLinkStatus === 'available' ? 'text-emerald-600' :
            phoneLinkStatus === 'checking'  ? 'text-amber-500 animate-pulse' :
                                              'text-muted-foreground'
          )} />
          <div>
            <p className={cn("font-medium text-xs",
              phoneLinkStatus === 'available' ? 'text-emerald-700' :
              phoneLinkStatus === 'checking'  ? 'text-amber-700' :
                                                'text-muted-foreground'
            )}>
              Windows Phone Link
            </p>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              {phoneLinkStatus === 'available'  ? 'Detected — tel: calls will route via Phone Link' :
               phoneLinkStatus === 'checking'   ? 'Detecting...' :
                                                  'Not detected (Windows required)'}
            </p>
          </div>
        </div>
        {phoneLinkStatus === 'available'  && <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px]"><CheckCircle2 className="w-3 h-3 mr-1" />Connected</Badge>}
        {phoneLinkStatus === 'checking'   && <Loader2 className="w-4 h-4 animate-spin text-amber-500" />}
        {phoneLinkStatus === 'unavailable'&& <Badge variant="outline" className="text-[10px]"><AlertCircle className="w-3 h-3 mr-1" />Not Found</Badge>}
      </div>

      {/* Bluetooth */}
      <div className={cn(
        "flex items-center justify-between p-3 rounded-lg border text-sm",
        btDevice ? 'border-blue-500/30 bg-blue-500/5' : 'border-border bg-muted/30'
      )}>
        <div className="flex items-center gap-2">
          {btDevice
            ? <BluetoothConnected className="w-4 h-4 text-blue-600" />
            : <Bluetooth className="w-4 h-4 text-muted-foreground" />
          }
          <div>
            <p className={cn("font-medium text-xs", btDevice ? 'text-blue-700' : 'text-muted-foreground')}>
              Bluetooth Device
            </p>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              {btDevice ? `${btDevice.name || 'Unknown'} — audio routed via BT` : 'No device connected'}
            </p>
          </div>
        </div>
        {btDevice ? (
          <div className="flex items-center gap-2">
            <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20 text-[10px]"><BluetoothConnected className="w-3 h-3 mr-1" />Active</Badge>
            <Button variant="ghost" size="sm" className="h-6 text-[10px] text-muted-foreground" onClick={disconnectBluetooth}>Disconnect</Button>
          </div>
        ) : (
          <Button
            size="sm"
            variant="outline"
            className="h-7 text-xs"
            onClick={connectBluetooth}
            disabled={btConnecting || !btSupported}
          >
            {btConnecting
              ? <><Loader2 className="w-3 h-3 mr-1 animate-spin" />Pairing...</>
              : <><Bluetooth className="w-3 h-3 mr-1" />Connect</>
            }
          </Button>
        )}
      </div>

      {!btSupported && (
        <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-500/5 border border-amber-500/20 text-[10px] text-amber-700">
          <Info className="w-3 h-3 flex-shrink-0 mt-0.5" />
          Web Bluetooth requires Chrome or Edge. Firefox/Safari do not support it.
        </div>
      )}

      {/* Active routing summary */}
      {(phoneLinkStatus === 'available' || btDevice) && (
        <div className="text-[10px] text-muted-foreground flex items-center gap-1.5 pt-1 border-t border-border">
          <CheckCircle2 className="w-3 h-3 text-emerald-500" />
          Calls will route via:&nbsp;
          <strong className="text-foreground">
            {btDevice && preferBluetooth ? `Bluetooth (${btDevice.name || 'Device'})` : 'Windows Phone Link'}
          </strong>
          {btDevice && phoneLinkStatus === 'available' && (
            <button
              className="ml-auto text-primary underline"
              onClick={() => setPreferBluetooth(p => !p)}
            >
              Switch to {preferBluetooth ? 'Phone Link' : 'Bluetooth'}
            </button>
          )}
        </div>
      )}
    </div>
  );
}