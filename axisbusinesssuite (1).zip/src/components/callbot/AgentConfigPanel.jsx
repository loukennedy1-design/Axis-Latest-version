import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Bot, Save, Mic, Volume2 } from 'lucide-react';
import AvailabilityScheduler from './AvailabilityScheduler';
import { toast } from 'sonner';

const VOICE_OPTIONS = [
  { value: 'alloy', label: 'Alloy — Neutral, balanced' },
  { value: 'echo', label: 'Echo — Warm, male' },
  { value: 'shimmer', label: 'Shimmer — Bright, female' },
  { value: 'nova', label: 'Nova — Energetic, female' },
  { value: 'sage', label: 'Sage — Calm, thoughtful' },
  { value: 'coral', label: 'Coral — Confident, assertive' },
  { value: 'verse', label: 'Verse — Deep, authoritative' },
];

/**
 * AgentConfigPanel — configures the AI voice agent personality, script,
 * and voice selection. All settings are saved to SystemSettings.
 */
export default function AgentConfigPanel({ settings, voiceSettings, script, meetingAvailability, onAvailabilityChange, onSave, onChange }) {
  const [localScript, setLocalScript] = useState(script);
  const [localVoice, setLocalVoice] = useState(voiceSettings);

  useEffect(() => {
    setLocalScript(script);
  }, [script]);

  useEffect(() => {
    setLocalVoice(voiceSettings);
  }, [voiceSettings]);

  const handleSave = () => {
    onSave({ script: localScript, voiceSettings: localVoice });
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-primary" />
            AI Voice Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label className="text-xs">OpenAI Realtime Voice</Label>
            <Select
              value={localVoice.openai_voice || 'alloy'}
              onValueChange={(v) => setLocalVoice({ ...localVoice, openai_voice: v })}
            >
              <SelectTrigger className="mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {VOICE_OPTIONS.map((v) => (
                  <SelectItem key={v.value} value={v.value}>
                    {v.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground mt-1">
              This voice will be used for all AI calls. Powered by OpenAI Realtime API.
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Bot className="w-4 h-4 text-primary" />
            Agent Persona
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Agent Name</Label>
              <Input
                value={localVoice.bot_agent_name || ''}
                onChange={(e) => setLocalVoice({ ...localVoice, bot_agent_name: e.target.value })}
                placeholder="e.g. Alex"
                className="mt-1 h-8 text-sm"
              />
            </div>
            <div>
              <Label className="text-xs">Voice Tone</Label>
              <Select
                value={localVoice.bot_voice || 'professional'}
                onValueChange={(v) => setLocalVoice({ ...localVoice, bot_voice: v })}
              >
                <SelectTrigger className="mt-1 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="energetic">Energetic</SelectItem>
                  <SelectItem value="calm">Calm</SelectItem>
                  <SelectItem value="assertive">Assertive</SelectItem>
                  <SelectItem value="conversational">Conversational</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Sales Style</Label>
              <Select
                value={localVoice.bot_personality_style || 'consultative'}
                onValueChange={(v) => setLocalVoice({ ...localVoice, bot_personality_style: v })}
              >
                <SelectTrigger className="mt-1 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="consultative">Consultative</SelectItem>
                  <SelectItem value="challenger">Challenger</SelectItem>
                  <SelectItem value="solution_seller">Solution Seller</SelectItem>
                  <SelectItem value="relationship_builder">Relationship Builder</SelectItem>
                  <SelectItem value="direct_closer">Direct Closer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Objection Style</Label>
              <Select
                value={localVoice.bot_objection_style || 'acknowledge_pivot'}
                onValueChange={(v) => setLocalVoice({ ...localVoice, bot_objection_style: v })}
              >
                <SelectTrigger className="mt-1 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="acknowledge_pivot">Acknowledge & Pivot</SelectItem>
                  <SelectItem value="feel_felt_found">Feel, Felt, Found</SelectItem>
                  <SelectItem value="challenge">Challenge</SelectItem>
                  <SelectItem value="deflect">Deflect</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Talking Speed</Label>
              <Select
                value={localVoice.bot_talking_speed || 'normal'}
                onValueChange={(v) => setLocalVoice({ ...localVoice, bot_talking_speed: v })}
              >
                <SelectTrigger className="mt-1 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="slow">Slow</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                  <SelectItem value="fast">Fast</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Empathy Level</Label>
              <Select
                value={localVoice.bot_empathy_level || 'medium'}
                onValueChange={(v) => setLocalVoice({ ...localVoice, bot_empathy_level: v })}
              >
                <SelectTrigger className="mt-1 h-8 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between p-2 rounded-lg border border-border">
            <Label className="text-xs mb-0">Use Humor</Label>
            <input
              type="checkbox"
              checked={localVoice.bot_use_humor || false}
              onChange={(e) => setLocalVoice({ ...localVoice, bot_use_humor: e.target.checked })}
              className="w-4 h-4"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Mic className="w-4 h-4 text-primary" />
            Call Script
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={localScript}
            onChange={(e) => setLocalScript(e.target.value)}
            rows={16}
            className="font-mono text-sm"
            placeholder="Enter your call script here..."
          />
          <p className="text-xs text-muted-foreground mt-2">
            Placeholders: [Agent Name], [Company Name], [Lead Name], [dates]
          </p>
        </CardContent>
      </Card>

      <AvailabilityScheduler
        availability={meetingAvailability}
        onChange={onAvailabilityChange}
      />

      <div className="flex justify-end">
        <Button onClick={handleSave}>
          <Save className="w-4 h-4 mr-2" />
          Save Agent Settings
        </Button>
      </div>
    </div>
  );
}