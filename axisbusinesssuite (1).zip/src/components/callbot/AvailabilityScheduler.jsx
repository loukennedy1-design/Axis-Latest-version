import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CalendarClock, Plus, Trash2, Clock } from 'lucide-react';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const DEFAULT_AVAILABILITY = {
  duration_minutes: 30,
  days: DAYS.map(day => ({
    day,
    enabled: day !== 'Saturday' && day !== 'Sunday',
    start: '09:00',
    end: '17:00',
  })),
};

/**
 * AvailabilityScheduler — lets users set their meeting availability.
 * The AI call bot uses this when offering appointment time slots to leads.
 *
 * Props:
 *  - availability: { duration_minutes, days: [{ day, enabled, start, end }] }
 *  - onChange: (newAvailability) => void
 */
export default function AvailabilityScheduler({ availability, onChange }) {
  const [local, setLocal] = useState(availability || DEFAULT_AVAILABILITY);

  useEffect(() => {
    setLocal(availability || DEFAULT_AVAILABILITY);
  }, [availability]);

  const update = (updater) => {
    const next = typeof updater === 'function' ? updater({ ...local, days: [...local.days] }) : updater;
    setLocal(next);
    onChange?.(next);
  };

  const toggleDay = (dayName) => {
    update(prev => ({
      ...prev,
      days: prev.days.map(d => d.day === dayName ? { ...d, enabled: !d.enabled } : d),
    }));
  };

  const updateDay = (dayName, field, value) => {
    update(prev => ({
      ...prev,
      days: prev.days.map(d => d.day === dayName ? { ...d, [field]: value } : d),
    }));
  };

  const enabledCount = local.days.filter(d => d.enabled).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm flex items-center gap-2">
          <CalendarClock className="w-4 h-4 text-primary" />
          Meeting Availability
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Set when you're available for booked meetings. The AI call bot uses these times when offering appointment slots to leads.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Meeting duration */}
        <div className="flex items-center gap-3 p-3 rounded-lg border border-border bg-card">
          <Clock className="w-4 h-4 text-primary shrink-0" />
          <div className="flex-1">
            <Label className="text-xs">Meeting Duration</Label>
            <p className="text-[10px] text-muted-foreground">How long each booked meeting lasts</p>
          </div>
          <Select
            value={String(local.duration_minutes || 30)}
            onValueChange={(v) => update(prev => ({ ...prev, duration_minutes: Number(v) }))}
          >
            <SelectTrigger className="w-28 h-8 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[15, 30, 45, 60, 90].map(d => (
                <SelectItem key={d} value={String(d)}>{d} min</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Weekly grid */}
        <div className="space-y-2">
          {local.days.map((day) => (
            <div
              key={day.day}
              className={`flex items-center gap-3 p-2.5 rounded-lg border transition-all ${
                day.enabled
                  ? 'border-primary/20 bg-primary/5'
                  : 'border-border bg-card opacity-60'
              }`}
            >
              {/* Enable toggle */}
              <button
                onClick={() => toggleDay(day.day)}
                className={`relative w-9 h-5 rounded-full transition-colors shrink-0 ${
                  day.enabled ? 'bg-primary' : 'bg-muted'
                }`}
              >
                <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${
                  day.enabled ? 'translate-x-4' : 'translate-x-0.5'
                }`} />
              </button>

              {/* Day name */}
              <span className="text-xs font-medium w-24 shrink-0">{day.day}</span>

              {/* Time range */}
              {day.enabled ? (
                <div className="flex items-center gap-2 flex-1">
                  <Input
                    type="time"
                    value={day.start}
                    onChange={(e) => updateDay(day.day, 'start', e.target.value)}
                    className="h-7 text-xs w-28"
                  />
                  <span className="text-xs text-muted-foreground">to</span>
                  <Input
                    type="time"
                    value={day.end}
                    onChange={(e) => updateDay(day.day, 'end', e.target.value)}
                    className="h-7 text-xs w-28"
                  />
                </div>
              ) : (
                <span className="text-xs text-muted-foreground flex-1">Unavailable</span>
              )}
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground pt-1">
          <CalendarClock className="w-3 h-3" />
          {enabledCount} {enabledCount === 1 ? 'day' : 'days'} available · {local.duration_minutes || 30}-min meetings
        </div>
      </CardContent>
    </Card>
  );
}