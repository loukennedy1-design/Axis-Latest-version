import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PhoneOff, Mic, MicOff, Radio, User, Building2, Phone, Loader2, PhoneCall, AlertCircle } from 'lucide-react';
import WaveformVisualizer from './WaveformVisualizer';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

/**
 * LiveCallPanel — connects to OpenAI Realtime API via WebSocket for
 * sub-300ms natural voice conversation. Handles audio I/O through the
 * browser mic/speaker, streaming transcript, and AI function-calling
 * (book_appointment, flag_for_followup, update_lead_status, end_call).
 *
 * Twilio places the actual phone call to the lead; the browser bridges
 * audio between the phone (via speaker) and the AI.
 */
export default function LiveCallPanel({
  lead,
  sessionConfig,
  voiceSettings,
  script,
  onEndCall,
  onOutcome,
}) {
  const [wsConnected, setWsConnected] = useState(false);
  const [micActive, setMicActive] = useState(true);
  const [transcript, setTranscript] = useState([]);
  const [aiSpeaking, setAiSpeaking] = useState(false);
  const [userSpeaking, setUserSpeaking] = useState(false);
  const [connecting, setConnecting] = useState(true);
  const [error, setError] = useState(null);
  const [callSid, setCallSid] = useState(null);
  const [callStartTime, setCallStartTime] = useState(null);
  const [elapsed, setElapsed] = useState(0);
  const [functionCallStatus, setFunctionCallStatus] = useState(null);

  const wsRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const micStreamRef = useRef(null);
  const processorRef = useRef(null);
  const micSourceRef = useRef(null);
  const transcriptEndRef = useRef(null);
  const callSidRef = useRef(null);
  const functionCallIdRef = useRef(null);

  // ── Elapsed timer ──────────────────────────────────────────────────
  useEffect(() => {
    if (!callStartTime) return;
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - callStartTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [callStartTime]);

  // ── Auto-scroll transcript ─────────────────────────────────────────
  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  // ── Audio helpers ──────────────────────────────────────────────────
  const float32ToInt16 = (float32) => {
    const int16 = new Int16Array(float32.length);
    for (let i = 0; i < float32.length; i++) {
      const s = Math.max(-1, Math.min(1, float32[i]));
      int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return int16;
  };

  const int16ToBase64 = (int16) => {
    const bytes = new Uint8Array(int16.buffer);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
    return btoa(binary);
  };

  const base64ToInt16 = (base64) => {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Int16Array(bytes.buffer);
  };

  const int16ToFloat32 = (int16) => {
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) float32[i] = int16[i] / 0x8000;
    return float32;
  };

  // ── Play received AI audio ─────────────────────────────────────────
  const playAudio = useCallback((base64Audio) => {
    const ctx = audioContextRef.current;
    if (!ctx) return;
    try {
      const int16 = base64ToInt16(base64Audio);
      const float32 = int16ToFloat32(int16);
      const sampleRate = 24000;
      const audioBuffer = ctx.createBuffer(1, float32.length, sampleRate);
      audioBuffer.copyToChannel(float32, 0);
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(analyserRef.current || ctx.destination);
      source.connect(ctx.destination);
      source.start();
    } catch (e) {
      // silently ignore audio decode errors
    }
  }, []);

  // ── Handle function calls from the AI ──────────────────────────────
  const handleFunctionCall = useCallback(async (functionCall) => {
    const { name, arguments: argsString, call_id } = functionCall;
    let args = {};
    try { args = JSON.parse(argsString); } catch (_) {}

    setFunctionCallStatus(`AI is calling: ${name}...`);

    try {
      let result = { success: true };

      if (name === 'book_appointment') {
        const res = await base44.functions.invoke('axisVoiceEngine', {
          action: 'book_appointment',
          lead,
          date: args.date,
          time: args.time,
          notes: args.notes,
        });
        result = res.data || res;
        if (result.success) {
          toast.success(`Appointment booked for ${lead.first_name}!`);
          onOutcome?.('appointment_set');
        }
      } else if (name === 'flag_for_followup') {
        const res = await base44.functions.invoke('axisVoiceEngine', {
          action: 'flag_followup',
          lead,
          reason: args.reason,
          priority: args.priority,
        });
        result = res.data || res;
        if (result.success) {
          toast.info(`Follow-up task created for ${lead.first_name}`);
          onOutcome?.('callback_requested');
        }
      } else if (name === 'update_lead_status') {
        const res = await base44.functions.invoke('axisVoiceEngine', {
          action: 'update_lead_status',
          lead,
          status: args.status,
        });
        result = res.data || res;
      } else if (name === 'end_call') {
        result = { success: true, outcome: args.outcome };
        onOutcome?.(args.outcome);
        // Send result then end
      }

      setFunctionCallStatus(null);

      // Send function call result back to the Realtime API
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'conversation.item.create',
          item: {
            type: 'function_call_output',
            call_id: call_id,
            output: JSON.stringify(result),
          },
        }));
        // Trigger AI to respond to the function result
        wsRef.current.send(JSON.stringify({ type: 'response.create' }));
      }
    } catch (e) {
      setFunctionCallStatus(null);
      // Still send a result so the AI can continue
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'conversation.item.create',
          item: {
            type: 'function_call_output',
            call_id: call_id,
            output: JSON.stringify({ success: false, error: e.message }),
          },
        }));
        wsRef.current.send(JSON.stringify({ type: 'response.create' }));
      }
    }
  }, [lead, onOutcome]);

  // ── WebSocket message handler ──────────────────────────────────────
  const handleWsMessage = useCallback((event) => {
    try {
      const data = JSON.parse(event.data);
      switch (data.type) {
        case 'session.created':
        case 'session.updated':
          setWsConnected(true);
          setConnecting(false);
          break;

        case 'input_audio_buffer.speech_started':
          setUserSpeaking(true);
          setAiSpeaking(false);
          break;

        case 'input_audio_buffer.speech_stopped':
          setUserSpeaking(false);
          break;

        case 'input_audio_buffer.committed':
          // Audio committed, waiting for AI response
          break;

        case 'conversation.item.input_audio_transcription.completed':
          if (data.transcript) {
            setTranscript(prev => [...prev, { role: 'user', text: data.transcript }]);
          }
          break;

        case 'conversation.item.created':
          if (data.item?.type === 'message' && data.item?.content?.[0]?.transcript) {
            // AI message transcript (full)
          }
          break;

        case 'response.audio_transcript.delta':
          // AI speaking transcript — accumulate
          setTranscript(prev => {
            const last = prev[prev.length - 1];
            if (last?.role === 'assistant' && !last.complete) {
              return [...prev.slice(0, -1), { role: 'assistant', text: last.text + data.delta, complete: false }];
            }
            return [...prev, { role: 'assistant', text: data.delta, complete: false }];
          });
          break;

        case 'response.audio_transcript.done':
          setTranscript(prev => {
            const last = prev[prev.length - 1];
            if (last?.role === 'assistant') {
              return [...prev.slice(0, -1), { ...last, complete: true, text: data.transcript || last.text }];
            }
            return prev;
          });
          break;

        case 'response.output_audio.delta':
          setAiSpeaking(true);
          playAudio(data.delta);
          break;

        case 'response.output_audio.done':
          setAiSpeaking(false);
          break;

        case 'response.function_call':
          handleFunctionCall(data);
          break;

        case 'error':
          console.error('[Realtime API Error]', data);
          setError(data.message || 'Realtime API error');
          break;
      }
    } catch (e) {
      // ignore parse errors
    }
  }, [playAudio, handleFunctionCall]);

  // ── Connect to OpenAI Realtime API ────────────────────────────────
  useEffect(() => {
    if (!sessionConfig?.ephemeral_key) {
      setError('No session token received. Please try again.');
      setConnecting(false);
      return;
    }

    let cancelled = false;

    const connect = async () => {
      try {
        // Create AudioContext for audio I/O
        const ctx = new AudioContext({ sampleRate: 24000 });
        audioContextRef.current = ctx;
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;
        analyserRef.current = analyser;

        // Get microphone access
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        if (cancelled) return;
        micStreamRef.current = stream;

        const source = ctx.createMediaStreamSource(stream);
        micSourceRef.current = source;
        source.connect(analyser);

        // ScriptProcessorNode for capturing audio
        const processor = ctx.createScriptProcessor(4096, 1, 1);
        processorRef.current = processor;
        processor.onaudioprocess = (e) => {
          if (!micActive || !wsRef.current || wsRef.current.readyState !== WebSocket.OPEN) return;
          const input = e.inputBuffer.getChannelData(0);
          const int16 = float32ToInt16(input);
          const base64 = int16ToBase64(int16);
          wsRef.current.send(JSON.stringify({
            type: 'input_audio_buffer.append',
            audio: base64,
          }));
        };
        source.connect(processor);
        processor.connect(ctx.destination);

        // Connect to OpenAI Realtime API via WebSocket
        const ws = new WebSocket(
          'wss://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview',
          [
            'realtime',
            `openai-insecure-api-key.${sessionConfig.ephemeral_key}`,
            'openai-beta.realtime-v1',
          ]
        );
        wsRef.current = ws;

        ws.onopen = () => {
          // Session is configured server-side via the ephemeral session
          // Just send a response.create to trigger the first AI message
          ws.send(JSON.stringify({ type: 'response.create' }));
        };

        ws.onmessage = handleWsMessage;

        ws.onerror = (e) => {
          console.error('[WebSocket error]', e);
          setError('Connection to AI voice engine failed. Check your network and try again.');
          setConnecting(false);
        };

        ws.onclose = () => {
          setWsConnected(false);
        };
      } catch (e) {
        if (cancelled) return;
        console.error('[Setup error]', e);
        setError(e.message || 'Failed to start voice session. Make sure microphone access is granted.');
        setConnecting(false);
      }
    };

    connect();

    return () => {
      cancelled = true;
      // Cleanup
      if (wsRef.current) {
        try { wsRef.current.close(); } catch (_) {}
      }
      if (processorRef.current) {
        try { processorRef.current.disconnect(); } catch (_) {}
      }
      if (micSourceRef.current) {
        try { micSourceRef.current.disconnect(); } catch (_) {}
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach(t => t.stop());
      }
      if (audioContextRef.current) {
        try { audioContextRef.current.close(); } catch (_) {}
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionConfig?.ephemeral_key]);

  // ── Also initiate Twilio call to the lead ─────────────────────────
  useEffect(() => {
    if (!sessionConfig?.initiate_call || !lead?.phone) return;
    const placeCall = async () => {
      try {
        const res = await base44.functions.invoke('axisVoiceEngine', {
          action: 'initiate_call',
          lead,
        });
        const data = res.data || res;
        if (data.success) {
          setCallSid(data.call_sid);
          callSidRef.current = data.call_sid;
          setCallStartTime(Date.now());
          toast.success(`Calling ${lead.first_name} via Twilio...`);
        } else {
          toast.error(`Twilio call failed: ${data.error || 'Unknown error'}`);
        }
      } catch (e) {
        toast.error(`Failed to place call: ${e.message}`);
      }
    };
    placeCall();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionConfig?.initiate_call]);

  // ── Toggle mic ─────────────────────────────────────────────────────
  const toggleMic = () => {
    setMicActive(prev => !prev);
  };

  // ── End call ──────────────────────────────────────────────────────
  const handleEndCall = async () => {
    if (callSidRef.current) {
      try {
        await base44.functions.invoke('axisVoiceEngine', {
          action: 'end_call',
          call_sid: callSidRef.current,
        });
      } catch (_) {}
    }
    if (wsRef.current) {
      try { wsRef.current.close(); } catch (_) {}
    }
    onEndCall?.();
  };

  const formatTime = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  if (connecting) {
    return (
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-8 flex flex-col items-center justify-center space-y-3">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-sm font-medium">Connecting to AXIS Native AI Voice Engine...</p>
          <p className="text-xs text-muted-foreground">Establishing real-time audio session</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="border-destructive/30 bg-destructive/5">
        <CardContent className="p-8 flex flex-col items-center justify-center space-y-3">
          <AlertCircle className="w-8 h-8 text-destructive" />
          <p className="text-sm font-medium">Connection Error</p>
          <p className="text-xs text-muted-foreground text-center max-w-md">{error}</p>
          <Button variant="outline" size="sm" onClick={onEndCall}>
            <PhoneOff className="w-4 h-4 mr-2" /> Close
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Active Call Header */}
      <Card className={`border-2 ${aiSpeaking ? 'border-primary/50 bg-primary/5' : userSpeaking ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-border'}`}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${wsConnected ? 'bg-primary/20' : 'bg-muted'}`}>
                <PhoneCall className={`w-5 h-5 ${wsConnected ? 'text-primary animate-pulse' : 'text-muted-foreground'}`} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold">Live AI Call</h3>
                  {wsConnected && (
                    <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px] animate-pulse">
                      ● LIVE
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground font-mono">{formatTime(elapsed)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={toggleMic} className="h-8">
                {micActive ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4 text-destructive" />}
              </Button>
              <Button variant="destructive" size="sm" onClick={handleEndCall} className="h-8">
                <PhoneOff className="w-4 h-4 mr-1" /> End Call
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Waveform */}
          <div className="bg-card/50 rounded-lg p-4 mb-4">
            <WaveformVisualizer analyser={analyserRef.current} isActive={wsConnected && (aiSpeaking || userSpeaking || micActive)} />
            <div className="flex items-center justify-center gap-4 mt-2">
              {aiSpeaking && (
                <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">
                  <Radio className="w-3 h-3 mr-1 animate-pulse" /> AI Speaking
                </Badge>
              )}
              {userSpeaking && (
                <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-xs">
                  <Mic className="w-3 h-3 mr-1" /> Lead Speaking
                </Badge>
              )}
              {functionCallStatus && (
                <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-xs">
                  {functionCallStatus}
                </Badge>
              )}
            </div>
          </div>

          {/* Lead Profile Sidebar + Transcript */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Lead Profile */}
            <div className="space-y-3">
              <div className="p-3 rounded-lg border border-border bg-card/50">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">{lead.first_name} {lead.last_name}</p>
                    <p className="text-[10px] text-muted-foreground">Lead</p>
                  </div>
                </div>
                <div className="space-y-1.5 text-xs">
                  {lead.phone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="w-3 h-3" />
                      <span className="font-mono">{lead.phone}</span>
                    </div>
                  )}
                  {lead.company && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Building2 className="w-3 h-3" />
                      <span>{lead.company}</span>
                    </div>
                  )}
                  {lead.email && (
                    <div className="text-muted-foreground truncate">{lead.email}</div>
                  )}
                </div>
                {lead.notes && (
                  <div className="mt-2 p-2 rounded bg-muted/30 text-[11px] text-muted-foreground">
                    {lead.notes.slice(0, 150)}
                  </div>
                )}
              </div>
            </div>

            {/* Live Transcript */}
            <div className="lg:col-span-2">
              <div className="h-[300px] overflow-y-auto rounded-lg border border-border bg-card/50 p-3 space-y-2">
                {transcript.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Waiting for conversation to start...
                  </div>
                ) : (
                  transcript.map((msg, i) => (
                    <div key={i} className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}>
                      <div className={`max-w-[80%] rounded-lg px-3 py-1.5 text-sm ${
                        msg.role === 'user'
                          ? 'bg-muted text-foreground'
                          : 'bg-primary/10 text-foreground border border-primary/20'
                      }`}>
                        <span className="text-[10px] font-semibold text-muted-foreground block mb-0.5">
                          {msg.role === 'user' ? 'Lead' : 'AI Agent'}
                        </span>
                        {msg.text}
                      </div>
                    </div>
                  ))
                )}
                <div ref={transcriptEndRef} />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}