import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Lightbulb, Target, MessageSquare, ShieldCheck, Clock,
  TrendingUp, AlertTriangle, CheckCircle2, Brain
} from 'lucide-react';

const CALL_STAGES = [
  { time: 0, label: 'Opening', icon: MessageSquare, tips: [
    'State your name and company clearly',
    'Disclose if you\'re an AI — offer opt-out',
    'Ask "Do you have 60 seconds?" to get a quick yes',
    'Smile while speaking — it changes your tone',
  ]},
  { time: 15, label: 'Qualifying', icon: Target, tips: [
    'Ask one question at a time — don\'t overwhelm',
    'Listen for pain points and take notes',
    'Use open-ended questions: "What\'s your biggest challenge with...?"',
    'Confirm the need before pitching: "So if I can solve X, would that be valuable?"',
  ]},
  { time: 45, label: 'Value Pitch', icon: TrendingUp, tips: [
    'Connect your solution to their stated pain',
    'Use a case study or specific outcome: "We helped [similar company] achieve [result]"',
    'Keep it under 30 seconds — brevity builds interest',
    'Ask "Does that sound like it could work for you?"',
  ]},
  { time: 90, label: 'Objection Handling', icon: AlertTriangle, tips: [
    'Acknowledge first: "I understand that concern..."',
    'Never argue — pivot to value: "Many clients felt that way, until..."',
    'Max 2 objection attempts — then offer a callback',
    'Common objections: price → ROI; timing → urgency; trust → social proof',
  ]},
  { time: 120, label: 'Closing', icon: CheckCircle2, tips: [
    'Offer two time options: "Would Tuesday 2pm or Wednesday 10am work?"',
    'Confirm explicitly: "So I have you down for [day] at [time] — correct?"',
    'Mention what happens next: "You\'ll get a confirmation email shortly"',
    'Thank them for their time',
  ]},
  { time: 180, label: 'Wrap-Up', icon: Clock, tips: [
    'Summarize agreed next steps',
    'Set expectations on follow-up timing',
    'Add any notes before dispositions',
    'If no appointment: log a callback for 3-5 days out',
  ]},
];

export default function CallCoachingPanel({ inCall, elapsed, callOutcome }) {
  const [currentStage, setCurrentStage] = useState(0);

  useEffect(() => {
    if (!inCall) { setCurrentStage(0); return; }
    // Find the current stage based on elapsed seconds
    let stage = 0;
    for (let i = 0; i < CALL_STAGES.length; i++) {
      if (elapsed >= CALL_STAGES[i].time) stage = i;
    }
    setCurrentStage(stage);
  }, [elapsed, inCall]);

  const stage = CALL_STAGES[currentStage];

  return (
    <Card className="h-full border-primary/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-xs flex items-center gap-1.5">
          <Brain className="w-3.5 h-3.5 text-primary" /> Live Call Coaching
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {!inCall ? (
          <div className="flex flex-col items-center justify-center h-[400px] text-center">
            <Lightbulb className="w-10 h-10 text-muted-foreground/30 mb-3" />
            <p className="text-sm text-muted-foreground">Coaching tips appear during your call</p>
            <p className="text-xs text-muted-foreground/70 mt-1">Stage-based guidance adapts as the call progresses</p>
          </div>
        ) : callOutcome ? (
          <div className="flex flex-col items-center justify-center h-[400px] text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mb-3" />
            <p className="text-sm font-medium">Call completed</p>
            <Badge className="mt-2 capitalize">{callOutcome.replace(/_/g, ' ')}</Badge>
          </div>
        ) : (
          <>
            {/* Current stage badge */}
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-primary/10 border border-primary/20">
              <div className="flex items-center gap-2">
                <stage.icon className="w-4 h-4 text-primary" />
                <div>
                  <p className="text-sm font-semibold">{stage.label}</p>
                  <p className="text-[10px] text-muted-foreground">{formatTime(elapsed)} elapsed</p>
                </div>
              </div>
              <Badge variant="outline" className="text-[10px]">Stage {currentStage + 1}/{CALL_STAGES.length}</Badge>
            </div>

            {/* Coaching tips for current stage */}
            <div className="space-y-1.5">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium flex items-center gap-1">
                <Lightbulb className="w-3 h-3" /> Tips for this stage
              </p>
              {stage.tips.map((tip, i) => (
                <div key={i} className="flex gap-2 p-2 rounded-lg bg-muted/20 text-xs">
                  <span className="text-primary/40 flex-shrink-0">{i + 1}.</span>
                  <span className="text-muted-foreground leading-relaxed">{tip}</span>
                </div>
              ))}
            </div>

            {/* Stage progress bar */}
            <div className="flex gap-1 mt-3">
              {CALL_STAGES.map((s, i) => (
                <div
                  key={i}
                  className={`h-1 flex-1 rounded-full transition-colors ${i <= currentStage ? 'bg-primary' : 'bg-muted'}`}
                />
              ))}
            </div>

            {/* Quick compliance reminder */}
            {currentStage === 0 && (
              <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 flex gap-2">
                <ShieldCheck className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-600">
                  Remember: disclose AI if applicable, offer opt-out ("say stop"), and respect DNC requests immediately.
                </p>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}

function formatTime(s) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}:${sec.toString().padStart(2, '0')}`;
}