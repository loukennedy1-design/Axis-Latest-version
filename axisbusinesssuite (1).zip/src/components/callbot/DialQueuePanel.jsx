import React from 'react';
import { Phone, Shield, Clock, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import StatusBadge from '@/components/shared/StatusBadge';
import ClickToCall from '@/components/shared/ClickToCall';

/**
 * DialQueuePanel — shows the lead queue with consent status, last called,
 * and call attempts. One-click dial and batch launch controls.
 */
export default function DialQueuePanel({
  eligibleLeads,
  dncList,
  onDial,
  onBatchDial,
  onRefresh,
  isDialing,
  currentLeadId,
  requireConsent,
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-semibold">Dial Queue</h3>
          <Badge variant="outline" className="text-xs">{eligibleLeads.length} ready</Badge>
          {requireConsent && (
            <Badge variant="outline" className="text-xs text-emerald-600 border-emerald-500/30">
              <Shield className="w-3 h-3 mr-1" />Consent required
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={onRefresh} className="text-xs">
            Refresh
          </Button>
          {eligibleLeads.length > 0 && (
            <Button size="sm" onClick={onBatchDial} disabled={isDialing} className="text-xs">
              {isDialing ? 'Dialing...' : `Launch All (${eligibleLeads.length})`}
            </Button>
          )}
        </div>
      </div>

      {eligibleLeads.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-border rounded-lg">
          <Phone className="w-10 h-10 mx-auto mb-2 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No eligible leads in queue.</p>
          <p className="text-xs text-muted-foreground/70 mt-1">
            Import leads with consent, or adjust your calling settings.
          </p>
        </div>
      ) : (
        <div className="space-y-1.5 max-h-[500px] overflow-y-auto pr-1">
          {eligibleLeads.map((lead, idx) => {
            const isCurrent = isDialing && lead.id === currentLeadId;
            return (
              <div
                key={lead.id}
                className={`flex items-center justify-between p-2.5 rounded-lg border transition-all ${
                  isCurrent
                    ? 'border-primary bg-primary/10 shadow-sm'
                    : 'border-border hover:bg-muted/40'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                      isCurrent ? 'bg-primary text-primary-foreground animate-pulse' : 'bg-primary/10 text-primary'
                    }`}
                  >
                    {idx + 1}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">
                      {lead.first_name} {lead.last_name}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <ClickToCall phone={lead.phone} showIcon={false} />
                      {lead.company && <span className="truncate">- {lead.company}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  {lead.consent_given && (
                    <Badge variant="outline" className="text-[10px] text-emerald-600 border-emerald-500/30">
                      Consent
                    </Badge>
                  )}
                  <span className="text-[10px] text-muted-foreground">{lead.call_attempts || 0}x</span>
                  <StatusBadge status={lead.status} />
                  <Button
                    size="sm"
                    variant={isCurrent ? 'default' : 'outline'}
                    className="h-7 px-2 text-xs"
                    disabled={isDialing}
                    onClick={() => onDial(lead)}
                  >
                    <Phone className="w-3 h-3 mr-1" />
                    Dial
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {dncList.length > 0 && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2">
          <AlertTriangle className="w-3 h-3 text-amber-500" />
          {dncList.length} numbers on DNC list (excluded from queue)
        </div>
      )}
    </div>
  );
}