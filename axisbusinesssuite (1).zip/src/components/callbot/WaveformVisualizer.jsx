import React, { useRef, useEffect, useState } from 'react';

/**
 * WaveformVisualizer — renders a live audio waveform from an AnalyserNode.
 * Falls back to a pulsing animation when no analyser is connected.
 */
export default function WaveformVisualizer({ analyser, isActive }) {
  const canvasRef = useRef(null);
  const [bars, setBars] = useState(Array(48).fill(8));
  const rafRef = useRef(null);

  useEffect(() => {
    if (!analyser || !isActive) {
      setBars(Array(48).fill(8));
      return;
    }
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      analyser.getByteFrequencyData(dataArray);
      const numBars = 48;
      const step = Math.floor(bufferLength / numBars);
      const newBars = [];
      for (let i = 0; i < numBars; i++) {
        let sum = 0;
        for (let j = 0; j < step; j++) {
          sum += dataArray[i * step + j];
        }
        const avg = sum / step;
        const height = Math.max(4, (avg / 255) * 60);
        newBars.push(height);
      }
      setBars(newBars);
      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [analyser, isActive]);

  return (
    <div className="flex items-end justify-center gap-[2px] h-16 w-full">
      {bars.map((h, i) => (
        <div
          key={i}
          className={`w-1.5 rounded-full transition-all duration-75 ${isActive ? 'bg-primary' : 'bg-muted-foreground/30'}`}
          style={{
            height: `${h}px`,
            opacity: isActive ? 0.4 + (h / 60) * 0.6 : 0.3,
          }}
        />
      ))}
    </div>
  );
}