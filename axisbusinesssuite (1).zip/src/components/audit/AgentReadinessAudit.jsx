import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  CheckCircle2, XCircle, AlertTriangle, RefreshCw, Bot, Zap,
  Shield, Activity, Brain, Network, ChevronDown, ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';

const statusConfig = {
  pass: { icon: CheckCircle2, color: 'text-emerald-500', badge: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20', label: 'Pass' },
  fail: { icon: XCircle, color: 'text-red-500', badge: 'bg-red-500/10 text-red-600 border-red-500/20', label: 'Fail' },
  warn: { icon: AlertTriangle, color: 'text-amber-500', badge: 'bg-amber-500/10 text-amber-600 border-amber-500/20', label: 'Warning' },
};

const readinessConfig = {
  Ready: { badge: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' },
  'Needs Attention': { badge: 'bg-amber-500/10 text-amber-600 border-amber-500/20' },
  Blocked: { badge: 'bg-red-500/10 text-red-600 border-red-500/20' },
};

const opStatusConfig = {
  Online: { color: 'text-emerald-500', dot: 'bg-emerald-500' },
  Degraded: { color: 'text-amber-500', dot: 'bg-amber-500' },
  Offline: { color: 'text-red-500', dot: 'bg-red-500' },
};

function AgentCard({ agent }) {
  const [expanded, setExpanded] = useState(false);
  const opCfg = opStatusConfig[agent.operational_status] || opStatusConfig.Online;

  return (
    <div className={`rounded-lg border ${
      agent.readiness === 'Ready' ? 'border-emerald-500/20' :
      agent.readiness === 'Blocked' ? 'border-red-500/30' : 'border-amber-500/20'
    } bg-muted/20 overflow-hidden`}>
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center justify-between p-3 border-b border-border hover:bg-muted/30 transition-colors"
      >
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-2 h-2 rounded-full ${opCfg.dot} shrink-0`} />
          <span className="font-semibold text-sm truncate">{agent.agent_name}</span>
          {agent.categories.slice(0, 2).map(cat => (
            <Badge key={cat} variant="outline" className="text-[9px] py-0 shrink-0 hidden sm:inline-flex">{cat}</Badge>
          ))}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className={`text-sm font-bold ${opCfg.color}`}>{agent.health_score}</span>
          <Badge className={readinessConfig[agent.readiness]?.badge || readinessConfig.Ready.badge}>
            {agent.readiness}
          </Badge>
          {expanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>
      {expanded && (
        <div className="p-3 space-y-1">
          <div className="grid grid-cols-3 gap-2 mb-2 text-[10px]">
            <div className="text-center p-1.5 rounded bg-muted/30">
              <p className="text-muted-foreground">Tools</p>
              <p className="font-semibold">{agent.tool_count}</p>
            </div>
            <div className="text-center p-1.5 rounded bg-muted/30">
              <p className="text-muted-foreground">Memory</p>
              <p className="font-semibold">{agent.memory_status}</p>
            </div>
            <div className="text-center p-1.5 rounded bg-muted/30">
              <p className="text-muted-foreground">Startup</p>
              <p className="font-semibold">{agent.startup_time_ms}ms</p>
            </div>
          </div>
          {agent.checks.map((check, ci) => {
            const cfg = statusConfig[check.status] || statusConfig.pass;
            const CheckIcon = cfg.icon;
            return (
              <div key={ci} className="flex items-start gap-2 text-xs">
                <CheckIcon className={`w-3.5 h-3.5 ${cfg.color} mt-0.5 shrink-0`} />
                <div>
                  <span className={check.status === 'fail' ? 'text-red-500' : check.status === 'warn' ? 'text-amber-500' : 'text-muted-foreground'}>{check.name}</span>
                  {check.detail && <span className="text-muted-foreground/70 ml-1">— {check.detail}</span>}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default function AgentReadinessAudit() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const runAudit = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('aiAgentReadinessAudit', {});
      setData(res.data);
      toast.success(`Agent audit complete — ${res.data.summary.ready}/${res.data.agents_discovered} agents ready`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Agent audit failed');
    }
    setLoading(false);
  };

  return (
    <Card className="border-violet-500/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Bot className="w-5 h-5 text-violet-500" />
            Phase 15: AI Agent Initialization & Readiness Audit
          </CardTitle>
          <Button variant="outline" size="sm" onClick={runAudit} disabled={loading}>
            {loading ? <><RefreshCw className="w-4 h-4 mr-1 animate-spin" />Auditing...</> : <><Zap className="w-4 h-4 mr-1" />Run Agent Audit</>}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!data && !loading && (
          <div className="text-center py-8 text-muted-foreground">
            <Bot className="w-10 h-10 mx-auto mb-2 opacity-40" />
            <p>Initialize and validate every registered AI agent in Audit Mode.</p>
            <p className="text-xs mt-1">Discovers all agents, validates memory, tools, permissions, and orchestration. No autonomous actions taken.</p>
          </div>
        )}

        {loading && (
          <div className="text-center py-8">
            <RefreshCw className="w-8 h-8 mx-auto mb-2 animate-spin text-violet-500" />
            <p className="text-sm text-muted-foreground">Initializing and validating all AI agents...</p>
          </div>
        )}

        {data && !loading && (
          <div className="space-y-4">
            {/* Overall Status */}
            <div className={`flex items-center justify-between p-4 rounded-lg border ${
              data.summary.audit_passed ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-amber-500/5 border-amber-500/20'
            }`}>
              <div className="flex items-center gap-3">
                {data.summary.audit_passed ? (
                  <Shield className="w-8 h-8 text-emerald-500" />
                ) : (
                  <AlertTriangle className="w-8 h-8 text-amber-500" />
                )}
                <div>
                  <p className="text-2xl font-bold">{data.summary.avg_health_score}<span className="text-sm text-muted-foreground">/100 avg health</span></p>
                  <p className="text-xs text-muted-foreground">
                    {data.summary.ready} ready · {data.summary.needs_attention} needs attention · {data.summary.blocked} blocked
                  </p>
                </div>
              </div>
              <Badge className={data.summary.audit_passed ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-amber-500/10 text-amber-600 border-amber-500/20'}>
                {data.summary.audit_passed ? 'All Agents Ready' : 'Action Required'}
              </Badge>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="rounded-lg border border-border bg-muted/20 p-3 text-center">
                <Bot className="w-4 h-4 text-violet-500 mx-auto mb-1" />
                <p className="text-xl font-bold">{data.agents_discovered}</p>
                <p className="text-[10px] text-muted-foreground">Agents Discovered</p>
              </div>
              <div className="rounded-lg border border-border bg-muted/20 p-3 text-center">
                <Brain className="w-4 h-4 text-blue-500 mx-auto mb-1" />
                <p className="text-xl font-bold">{data.memory_stores.filter(m => m.status === 'available').length}/{data.memory_stores.length}</p>
                <p className="text-[10px] text-muted-foreground">Memory Stores</p>
              </div>
              <div className="rounded-lg border border-border bg-muted/20 p-3 text-center">
                <Network className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
                <p className="text-xl font-bold">{data.categories_covered.length}</p>
                <p className="text-[10px] text-muted-foreground">Categories Covered</p>
              </div>
              <div className="rounded-lg border border-border bg-muted/20 p-3 text-center">
                <Activity className="w-4 h-4 text-amber-500 mx-auto mb-1" />
                <p className="text-xl font-bold">{data.summary.total_errors + data.summary.total_warnings}</p>
                <p className="text-[10px] text-muted-foreground">Errors + Warnings</p>
              </div>
            </div>

            {/* Memory Stores */}
            <div>
              <p className="text-xs font-semibold mb-1.5 flex items-center gap-1"><Brain className="w-3.5 h-3.5 text-blue-500" /> Memory Stores</p>
              <div className="flex flex-wrap gap-2">
                {data.memory_stores.map(m => {
                  const cfg = m.status === 'available' ? statusConfig.pass : statusConfig.fail;
                  const Icon = cfg.icon;
                  return (
                    <Badge key={m.store} className={cfg.badge}>
                      <Icon className="w-3 h-3 mr-1" />{m.store}
                    </Badge>
                  );
                })}
              </div>
            </div>

            {/* Orchestration */}
            <div>
              <p className="text-xs font-semibold mb-1.5 flex items-center gap-1"><Network className="w-3.5 h-3.5 text-emerald-500" /> Inter-Agent Orchestration</p>
              <div className="flex flex-wrap gap-2">
                <Badge className={data.orchestration.trinity_present ? statusConfig.pass.badge : statusConfig.fail.badge}>
                  {data.orchestration.trinity_present ? <CheckCircle2 className="w-3 h-3 mr-1" /> : <XCircle className="w-3 h-3 mr-1" />}
                  Trinity Orchestrator
                </Badge>
                <Badge className={data.orchestration.agent_registration === 'pass' ? statusConfig.pass.badge : statusConfig.fail.badge}>
                  Agent Registration
                </Badge>
                <Badge className={data.orchestration.message_routing === 'pass' ? statusConfig.pass.badge : statusConfig.fail.badge}>
                  Message Routing
                </Badge>
                <Badge className={data.orchestration.task_delegation === 'pass' ? statusConfig.pass.badge : statusConfig.fail.badge}>
                  Task Delegation
                </Badge>
                <Badge className={data.orchestration.audit_trail === 'pass' ? statusConfig.pass.badge : statusConfig.fail.badge}>
                  Audit Trail
                </Badge>
              </div>
            </div>

            {/* Agent Cards */}
            <div className="grid md:grid-cols-2 gap-2">
              {data.agents.map((agent, idx) => <AgentCard key={idx} agent={agent} />)}
            </div>

            <p className="text-xs text-muted-foreground text-center pt-2">
              Audit completed in {data.audit_duration_ms}ms · {new Date(data.timestamp).toLocaleString()}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}