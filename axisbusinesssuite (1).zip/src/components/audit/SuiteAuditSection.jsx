import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, AlertTriangle, RefreshCw, ClipboardCheck } from 'lucide-react';
import { toast } from 'sonner';

const statusConfig = {
  pass: { icon: CheckCircle2, color: 'text-emerald-500', badge: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20', label: 'Pass' },
  fail: { icon: XCircle, color: 'text-red-500', badge: 'bg-red-500/10 text-red-600 border-red-500/20', label: 'Fail' },
  warn: { icon: AlertTriangle, color: 'text-amber-500', badge: 'bg-amber-500/10 text-amber-600 border-amber-500/20', label: 'Warning' },
};

export default function SuiteAuditSection() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const runAudit = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('suiteAuditReport', {});
      setData(res.data);
      toast.success(`Audit complete — ${res.data.summary.health_pct}% healthy`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Audit failed to run');
    }
    setLoading(false);
  };

  return (
    <Card className="border-primary/30">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ClipboardCheck className="w-5 h-5 text-primary" />
            Suite Audit Report — 11 Modules
          </CardTitle>
          <Button variant="outline" size="sm" onClick={runAudit} disabled={loading}>
            {loading ? <><RefreshCw className="w-4 h-4 mr-1 animate-spin" />Running...</> : <><RefreshCw className="w-4 h-4 mr-1" />Re-run Audit</>}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {!data && !loading && (
          <div className="text-center py-8 text-muted-foreground">
            <ClipboardCheck className="w-10 h-10 mx-auto mb-2 opacity-40" />
            <p>Click "Re-run Audit" to verify all 11 modules are production-ready.</p>
            <p className="text-xs mt-1">Checks entity schemas, imports, routes, RLS rules, and cross-module integration.</p>
          </div>
        )}

        {loading && (
          <div className="text-center py-8">
            <RefreshCw className="w-8 h-8 mx-auto mb-2 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground">Running production-readiness checks...</p>
          </div>
        )}

        {data && !loading && (
          <div className="space-y-4">
            {/* Summary */}
            <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-br from-primary/8 to-card border border-primary/20">
              <div>
                <p className="text-3xl font-bold text-primary">{data.summary.health_pct}%</p>
                <p className="text-xs text-muted-foreground">{data.summary.passed} passed · {data.summary.failed} failed · {data.summary.total} total checks</p>
              </div>
              <Badge className={data.summary.health_pct === 100 ? 'bg-emerald-500/10 text-emerald-600' : data.summary.health_pct >= 80 ? 'bg-amber-500/10 text-amber-600' : 'bg-red-500/10 text-red-600'}>
                {data.summary.health_pct === 100 ? 'All Systems Go' : data.summary.health_pct >= 80 ? 'Minor Issues' : 'Critical Issues'}
              </Badge>
            </div>

            {/* Module audit cards */}
            <div className="grid md:grid-cols-2 gap-3">
              {data.modules.map((mod, idx) => {
                const modPass = mod.checks.every(c => c.status === 'pass');
                const modFail = mod.checks.some(c => c.status === 'fail');
                const Icon = modPass ? statusConfig.pass.icon : statusConfig.fail.icon;
                const color = modPass ? 'text-emerald-500' : 'text-red-500';
                const borderColor = modPass ? 'border-emerald-500/20' : 'border-red-500/30';

                return (
                  <div key={idx} className={`rounded-lg border ${borderColor} bg-muted/20 overflow-hidden`}>
                    <div className="flex items-center justify-between p-3 border-b border-border">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-4 h-4 ${color}`} />
                        <span className="font-semibold text-sm">{mod.module}</span>
                      </div>
                      <Badge className={modPass ? statusConfig.pass.badge : statusConfig.fail.badge}>
                        {mod.checks.filter(c => c.status === 'pass').length}/{mod.checks.length}
                      </Badge>
                    </div>
                    <div className="p-3 space-y-1">
                      {mod.checks.map((check, ci) => {
                        const cfg = statusConfig[check.status] || statusConfig.pass;
                        const CheckIcon = cfg.icon;
                        return (
                          <div key={ci} className="flex items-start gap-2 text-xs">
                            <CheckIcon className={`w-3.5 h-3.5 ${cfg.color} mt-0.5 shrink-0`} />
                            <div>
                              <span className={check.status === 'fail' ? 'text-red-500' : 'text-muted-foreground'}>{check.name}</span>
                              {check.detail && <p className="text-muted-foreground/70 mt-0.5">{check.detail}</p>}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            <p className="text-xs text-muted-foreground text-center pt-2">
              Last run: {new Date(data.timestamp).toLocaleString()}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}