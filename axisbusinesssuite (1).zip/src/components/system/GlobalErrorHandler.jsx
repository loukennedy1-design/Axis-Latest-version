import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

/**
 * GlobalErrorHandler — Mounts once at the app root and captures ALL uncaught
 * errors that bypass React's ErrorBoundary:
 *
 *   1. window.onerror           — uncaught JavaScript exceptions
 *   2. unhandledrejection        — unhandled Promise rejections (failed API calls,
 *                                  async/await without try-catch, etc.)
 *
 * Every captured error is sent to the `reportSystemError` backend function,
 * which creates an AIAutomationLog entry that triggers Trinity's autonomous
 * incident response. Trinity then diagnoses, self-heals if safe, or escalates.
 *
 * This component renders nothing — it's a side-effect-only listener.
 */
export default function GlobalErrorHandler({ children }) {
  const lastReportRef = useRef({});

  useEffect(() => {
    const reportError = (errorData) => {
      // In-browser dedup: don't report the same error more than once per 30s
      const fp = (errorData.error_message || '').slice(0, 100);
      const now = Date.now();
      if (lastReportRef.current[fp] && now - lastReportRef.current[fp] < 30000) return;
      lastReportRef.current[fp] = now;

      // Fire-and-forget — never blocks UI, never throws
      base44.functions.invoke('reportSystemError', errorData).catch(() => {
        // Silent fail — we never want the error reporter to cause more errors
      });
    };

    // (1) Uncaught JavaScript exceptions
    const handleOnError = (event) => {
      if (!event?.error && !event?.message) return;
      reportError({
        error_message: event.message || String(event.error),
        error_stack: event.error?.stack || '',
        error_type: event.error?.name || 'UncaughtError',
        source: 'frontend',
        page_url: window.location.href,
        user_agent: navigator.userAgent,
      });
    };

    // (2) Unhandled Promise rejections (API failures, async errors)
    const handleRejection = (event) => {
      const reason = event?.reason;
      if (!reason) return;
      const isObject = typeof reason === 'object';
      reportError({
        error_message: isObject ? (reason.message || JSON.stringify(reason)) : String(reason),
        error_stack: isObject ? (reason.stack || '') : '',
        error_type: isObject ? (reason.name || 'UnhandledRejection') : 'UnhandledRejection',
        source: 'api',
        page_url: window.location.href,
        user_agent: navigator.userAgent,
      });
    };

    window.addEventListener('error', handleOnError);
    window.addEventListener('unhandledrejection', handleRejection);

    return () => {
      window.removeEventListener('error', handleOnError);
      window.removeEventListener('unhandledrejection', handleRejection);
    };
  }, []);

  return children;
}