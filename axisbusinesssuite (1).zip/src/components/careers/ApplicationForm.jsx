import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Upload, CheckCircle2, X, Loader2, Send, Briefcase, MapPin, Building2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ApplicationForm({ job, onClose, onSuccess }) {
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    linkedin_url: '',
    current_company: '',
    current_title: '',
    cover_letter: '',
    resume_url: '',
    resume_filename: '',
  });
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleUpload = async (file) => {
    if (!file) return;
    if (!['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(file.type)) {
      toast.error('Please upload a PDF or Word document');
      return;
    }
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set('resume_url', file_url);
      set('resume_filename', file.name);
      toast.success('Resume uploaded');
    } catch (e) {
      toast.error('Failed to upload resume');
    } finally {
      setUploading(false);
    }
  };

  const submit = async () => {
    if (!form.first_name || !form.last_name || !form.email) {
      toast.error('Please fill in your name and email');
      return;
    }
    setSubmitting(true);
    try {
      const res = await base44.functions.invoke('publicCareers', {
        action: 'submit_application',
        job_id: job.id,
        first_name: form.first_name,
        last_name: form.last_name,
        email: form.email,
        phone: form.phone,
        linkedin_url: form.linkedin_url,
        current_company: form.current_company,
        current_title: form.current_title,
        cover_letter: form.cover_letter,
        file_url: form.resume_url,
      });
      if (res.data?.error) throw new Error(res.data.error);
      setDone(true);
      onSuccess?.();
      toast.success('Application submitted!');
    } catch (e) {
      toast.error(e.message || 'Failed to submit application');
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div className="text-center py-8">
        <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-8 h-8 text-emerald-400" />
        </div>
        <h3 className="font-semibold text-lg mb-2">Application Received!</h3>
        <p className="text-sm text-muted-foreground mb-6">
          Thanks for applying, {form.first_name || 'candidate'}. Our team will review your application for <strong>{job.title}</strong> and reach out if there's a fit.
        </p>
        <Button variant="outline" onClick={onClose}>Close</Button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Job header */}
      <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Briefcase className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-base">{job.title}</h3>
            <div className="flex flex-wrap gap-2 mt-1 text-xs text-muted-foreground">
              {job.department && <span className="flex items-center gap-1"><Building2 className="w-3 h-3" />{job.department}</span>}
              {job.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{job.location}</span>}
              <Badge className="capitalize text-[10px]">{job.employment_type?.replace('_', ' ')}</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Personal info */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Personal Information</h4>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>First Name *</Label>
            <Input className="mt-1" value={form.first_name} onChange={e => set('first_name', e.target.value)} placeholder="Jane" />
          </div>
          <div>
            <Label>Last Name *</Label>
            <Input className="mt-1" value={form.last_name} onChange={e => set('last_name', e.target.value)} placeholder="Doe" />
          </div>
          <div>
            <Label>Email *</Label>
            <Input className="mt-1" type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="jane@example.com" />
          </div>
          <div>
            <Label>Phone</Label>
            <Input className="mt-1" value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="+1 (555) 123-4567" />
          </div>
        </div>
      </div>

      {/* Professional info */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Professional Information</h4>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Current Title</Label>
            <Input className="mt-1" value={form.current_title} onChange={e => set('current_title', e.target.value)} placeholder="Account Manager" />
          </div>
          <div>
            <Label>Current Company</Label>
            <Input className="mt-1" value={form.current_company} onChange={e => set('current_company', e.target.value)} placeholder="Acme Inc." />
          </div>
          <div className="col-span-2">
            <Label>LinkedIn URL (optional)</Label>
            <Input className="mt-1" value={form.linkedin_url} onChange={e => set('linkedin_url', e.target.value)} placeholder="https://linkedin.com/in/yourprofile" />
          </div>
        </div>
      </div>

      {/* Resume upload */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Resume</h4>
        <div className="p-4 rounded-xl border border-border bg-muted/30">
          {!form.resume_url ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <Upload className="w-8 h-8 text-muted-foreground mb-3" />
              <p className="text-sm font-medium mb-1">Upload your resume</p>
              <p className="text-xs text-muted-foreground mb-3">PDF or Word document (max 10MB)</p>
              <input
                type="file"
                id="resume-upload"
                accept=".pdf,.doc,.docx"
                className="hidden"
                onChange={e => handleUpload(e.target.files?.[0])}
                disabled={uploading}
              />
              <Button variant="outline" onClick={() => document.getElementById('resume-upload').click()} disabled={uploading} className="gap-2">
                {uploading ? <><Loader2 className="w-4 h-4 animate-spin" />Uploading...</> : <><Upload className="w-4 h-4" />Select File</>}
              </Button>
            </div>
          ) : (
            <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-emerald-700">{form.resume_filename}</p>
                  <p className="text-xs text-emerald-600">Ready to submit</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { set('resume_url', ''); set('resume_filename', ''); }}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Cover letter */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Cover Letter <span className="text-muted-foreground font-normal">(optional)</span></h4>
        <Textarea
          className="min-h-[120px]"
          value={form.cover_letter}
          onChange={e => set('cover_letter', e.target.value)}
          placeholder="Tell us why you're interested in this role and what makes you a great fit..."
        />
      </div>

      {/* Submit */}
      <div className="flex gap-2 pt-2">
        <Button variant="outline" onClick={onClose} className="flex-1">Cancel</Button>
        <Button onClick={submit} disabled={submitting || !form.first_name || !form.last_name || !form.email} className="flex-1 gap-2">
          {submitting ? <><Loader2 className="w-4 h-4 animate-spin" />Submitting...</> : <><Send className="w-4 h-4" />Submit Application</>}
        </Button>
      </div>
    </div>
  );
}