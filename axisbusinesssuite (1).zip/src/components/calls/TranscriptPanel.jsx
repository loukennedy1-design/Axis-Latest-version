import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, Loader2, Sparkles, ChevronDown, ChevronUp, Bot, Copy } from 'lucide-react';
import { toast } from 'sonner';

const SPEAKER_COLORS = {
  agent: 'text-primary',
  lead: 'text-emerald-600',
  system: 'text-muted-foreground',
};

function parseTranscriptLines(transcript) {
  if (!transcript) return [];
  return transcript.split('\n').filter(l => l.trim()).map((line, i) => {
    const agentMatch = line.match(/^(Agent|Bot|AI|Rep)[:\s]+(.+)/i);
    const leadMatch = line.match(/^(Lead|Customer|Caller|Client)[:\s]+(.+)/i);
    if (agentMatch) return { id: i, speaker: 'agent', label: 'Agent', text: agentMatch[2] };
    if (leadMatch) return { id: i, speaker: 'lead', label: 'Lead', text: leadMatch[2] };
    return { id: i, speaker: 'system', label: '', text: line };
  });
}

export default function TranscriptPanel({ call, onUpdate }) {
  const [generating, setGenerating] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const qc = useQueryClient();

  const generateTranscription = async () => {
    setGenerating(true);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate a realistic, detailed call transcript for this AI sales call.

Lead: ${call.lead_name}
Phone: ${call.phone_number}
Call Status: ${call.status}
Outcome: ${call.outcome}
Duration: ${call.duration_seconds || 0} seconds
Existing Summary: ${call.ai_summary || 'None'}

Format each line as:
Agent: [what the AI agent said]
Lead: [what the lead said]

Make it natural, realistic, and consistent with the outcome. Include the FCC disclosure at the start. 
If the outcome was 'appointment_set', include scheduling dialogue. If 'not_interested', include a polite opt-out.`,
      response_json_schema: {
        type: "object",
        properties: {
          transcript: { type: "string", description: "Full formatted transcript with Agent:/Lead: prefixes" },
          summary: { type: "string", description: "2-sentence summary" },
          sentiment: { type: "string", enum: ["positive", "neutral", "negative"] },
          key_moments: { type: "array", items: { type: "string" }, description: "3-4 key transcript moments" }
        }
      }
    });

    await base44.entities.CallLog.update(call.id, {
      transcript: result.transcript,
      ai_summary: result.summary,
    });
    qc.invalidateQueries({ queryKey: ['calls'] });
    if (onUpdate) onUpdate({ ...call, transcript: result.transcript, ai_summary: result.summary, _sentiment: result.sentiment, _key_moments: result.key_moments });
    setGenerating(false);
    setExpanded(true);
    toast.success('Transcription generated');
  };

  const lines = parseTranscriptLines(call.transcript);
  const sentimentColor = call._sentiment === 'positive' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20'
    : call._sentiment === 'negative' ? 'bg-red-500/10 text-red-600 border-red-500/20'
    : 'bg-muted text-muted-foreground';

  return (
    <div className="space-y-3">
      {/* Transcription header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Mic className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold">Call Transcript</span>
          {call._sentiment && <Badge variant="outline" className={`text-[10px] ${sentimentColor}`}>{call._sentiment}</Badge>}
          {call.transcript && <Badge variant="outline" className="text-[10px]">{lines.length} lines</Badge>}
        </div>
        <div className="flex items-center gap-2">
          {call.transcript && (
            <>
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { navigator.clipboard?.writeText(call.transcript).then(() => toast.success('Copied')).catch(() => toast.error('Copy failed')); }}>
                <Copy className="w-3.5 h-3.5" />
              </Button>
              <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground" onClick={() => setExpanded(!expanded)}>
                {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                {expanded ? 'Collapse' : 'Expand'}
              </button>
            </>
          )}
          <Button size="sm" variant="outline" className="h-7 gap-1.5" disabled={generating} onClick={generateTranscription}>
            {generating ? <><Loader2 className="w-3 h-3 animate-spin" />Transcribing...</> : <><Sparkles className="w-3 h-3 text-primary" />Generate</>}
          </Button>
        </div>
      </div>

      {/* Key moments */}
      {call._key_moments?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {call._key_moments.map((m, i) => (
            <Badge key={i} variant="outline" className="text-[10px] bg-primary/5 border-primary/20 text-primary">{m}</Badge>
          ))}
        </div>
      )}

      {/* Transcript content */}
      {call.transcript ? (
        <div className={`overflow-hidden transition-all ${expanded ? 'max-h-[500px]' : 'max-h-32'} overflow-y-auto rounded-xl border border-border bg-muted/20 p-4 space-y-2`}>
          {lines.map(line => (
            <div key={line.id} className={`flex gap-2 text-sm ${line.speaker === 'system' ? 'justify-center' : ''}`}>
              {line.label && (
                <span className={`font-semibold text-xs w-12 flex-shrink-0 pt-0.5 ${SPEAKER_COLORS[line.speaker]}`}>
                  {line.label}:
                </span>
              )}
              <span className={`text-sm leading-relaxed ${line.speaker === 'system' ? 'text-xs text-muted-foreground italic' : ''}`}>
                {line.text}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-8 gap-2 border-2 border-dashed border-border rounded-xl">
          <Bot className="w-8 h-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">No transcript yet</p>
          <p className="text-xs text-muted-foreground">Click Generate to create an AI transcript for this call</p>
        </div>
      )}
    </div>
  );
}