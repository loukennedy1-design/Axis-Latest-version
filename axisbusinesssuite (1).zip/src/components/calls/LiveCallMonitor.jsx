import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Phone, Mic, Loader2, Clock, User, Bot, MessageSquare,
  Send, X, AlertCircle, CheckCircle2, Headphones
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const CALL_STATUS_CONFIG = {
  in_progress: { label: 'Live', color: 'bg-red-500/10 text-red-600 border-red-500/20 animate-pulse', icon: Mic },
  completed: { label: 'Completed', color: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20', icon: CheckCircle2 },
  failed: { label: 'Failed', color: 'bg-red-500/10 text-red-600 border-red-500/20', icon: AlertCircle },
  scheduled: { label: 'Scheduled', color: 'bg-blue-500/10 text-blue-600 border-blue-500/20', icon: Clock },
};

function LiveCallCard({ call, onView, onAddNote }) {
  const statusConf = CALL_STATUS_CONFIG[call.status] || CALL_STATUS_CONFIG.completed;
  const StatusIcon = statusConf.icon;

  return (
    <Card className={`transition-all hover:shadow-md ${call.status === 'in_progress' ? 'border-red-500/30 bg-red-500/5' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* Status indicator */}
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
            call.status === 'in_progress' ? 'bg-red-500/20' : 'bg-primary/10'
          }`}>
            {call.status === 'in_progress' ? (
              <Mic className="w-5 h-5 text-red-500 animate-pulse" />
            ) : (
              <Phone className="w-5 h-5 text-primary" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <h3 className="font-semibold text-sm">{call.lead_name || 'Unknown Lead'}</h3>
              <Badge className={`text-[10px] px-1.5 ${statusConf.color}`}>
                <StatusIcon className="w-2.5 h-2.5 mr-0.5" />
                {statusConf.label}
              </Badge>
              {call.status === 'in_progress' && (
                <span className="text-[10px] text-red-500 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                  LIVE
                </span>
              )}
            </div>

            <div className="flex items-center gap-3 text-[10px] text-muted-foreground mb-2">
              <span className="flex items-center gap-1">
                <Phone className="w-2.5 h-2.5" />
                {call.phone_number}
              </span>
              {call.duration_seconds && (
                <span className="flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" />
                  {Math.floor(call.duration_seconds / 60)}:{String(call.duration_seconds % 60).padStart(2, '0')}
                </span>
              )}
              <span>{format(new Date(call.created_date), 'h:mm a')}</span>
            </div>

            {/* Live transcript preview */}
            {call.transcript && (
              <div className="mb-2 p-2 rounded-lg bg-muted/50 border border-border">
                <p className="text-[10px] text-muted-foreground line-clamp-2">
                  {call.transcript}
                </p>
              </div>
            )}

            {/* Actions */}
            <div className="flex items-center gap-2 mt-2">
              <Button
                size="sm"
                variant="outline"
                className="h-7 text-xs gap-1"
                onClick={() => onView(call)}
              >
                <Headphones className="w-3 h-3" />
                {call.status === 'in_progress' ? 'Listen Live' : 'View Transcript'}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="h-7 text-xs gap-1"
                onClick={() => onAddNote(call)}
              >
                <MessageSquare className="w-3 h-3" />
                Add Note
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function LiveTranscriptViewer({ call, onClose, onAddNote }) {
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const addNoteMutation = useMutation({
    mutationFn: async (noteText) => {
      const existingNotes = call.team_notes ? JSON.parse(call.team_notes) : [];
      const newNote = {
        text: noteText,
        added_by: 'user',
        added_at: new Date().toISOString(),
      };
      await base44.entities.CallLog.update(call.id, {
        team_notes: JSON.stringify([...existingNotes, newNote]),
      });
    },
    onSuccess: () => {
      toast.success('Note added to call');
      setNote('');
      onAddNote();
    },
  });

  const handleAddNote = () => {
    if (!note.trim()) {
      toast.error('Please enter a note');
      return;
    }
    addNoteMutation.mutate(note);
  };

  const notes = call.team_notes ? JSON.parse(call.team_notes) : [];

  return (
    <div className="space-y-4">
      {/* Call info */}
      <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50 border border-border">
        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
          call.status === 'in_progress' ? 'bg-red-500/20 animate-pulse' : 'bg-primary/10'
        }`}>
          <Phone className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-sm">{call.lead_name}</p>
          <p className="text-xs text-muted-foreground">{call.phone_number}</p>
        </div>
        <Badge className={CALL_STATUS_CONFIG[call.status]?.color}>
          {CALL_STATUS_CONFIG[call.status]?.label}
        </Badge>
      </div>

      {/* Live transcript */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Mic className="w-4 h-4 text-primary" />
          <p className="text-sm font-semibold">Call Transcript</p>
          {call.status === 'in_progress' && (
            <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-[10px]">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse mr-1" />
              Live
            </Badge>
          )}
        </div>
        <ScrollArea className="h-64 rounded-xl border border-border p-4 bg-muted/30">
          {call.transcript ? (
            <div className="space-y-2">
              {call.transcript.split('\n').map((line, i) => (
                <p key={i} className="text-sm leading-relaxed">
                  {line.startsWith('AI:') ? (
                    <span className="flex items-start gap-2">
                      <Bot className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                      <span><strong className="text-primary">AI:</strong> {line.replace('AI:', '')}</span>
                    </span>
                  ) : line.startsWith('Lead:') ? (
                    <span className="flex items-start gap-2">
                      <User className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
                      <span><strong>Lead:</strong> {line.replace('Lead:', '')}</span>
                    </span>
                  ) : (
                    line
                  )}
                </p>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
              <Mic className="w-8 h-8 mb-2 opacity-30" />
              <p className="text-sm">No transcript available</p>
            </div>
          )}
        </ScrollArea>
      </div>

      {/* Team notes */}
      {notes.length > 0 && (
        <div>
          <div className="flex items-center gap-2 mb-2">
            <MessageSquare className="w-4 h-4 text-primary" />
            <p className="text-sm font-semibold">Team Notes ({notes.length})</p>
          </div>
          <ScrollArea className="h-32 rounded-xl border border-border p-3 bg-muted/30">
            <div className="space-y-2">
              {notes.map((noteItem, i) => (
                <div key={i} className="text-xs p-2 rounded-lg bg-background border border-border">
                  <p className="text-muted-foreground leading-relaxed">{noteItem.text}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">
                    — {format(new Date(noteItem.added_at), 'h:mm a')}
                  </p>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Add note */}
      <div>
        <p className="text-sm font-semibold mb-2">Add Team Note</p>
        <Textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Add a note for your team (e.g., 'Follow up on pricing tomorrow', 'Lead mentioned competitor X')"
          className="min-h-[80px]"
        />
        <div className="flex gap-2 mt-2">
          <Button
            onClick={handleAddNote}
            disabled={saving || !note.trim()}
            className="gap-2"
            size="sm"
          >
            <Send className="w-3.5 h-3.5" />
            Add Note
          </Button>
          <Button variant="outline" onClick={onClose} size="sm">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function LiveCallMonitor({ onClose }) {
  const [selectedCall, setSelectedCall] = useState(null);
  const [noteCall, setNoteCall] = useState(null);

  const { data: calls = [], isLoading, refetch } = useQuery({
    queryKey: ['live-calls'],
    queryFn: () => base44.entities.CallLog.filter(
      { status: { $in: ['in_progress', 'completed'] } },
      '-created_date',
      20
    ),
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const liveCalls = calls.filter(c => c.status === 'in_progress');
  const recentCalls = calls.filter(c => c.status === 'completed').slice(0, 5);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
            <Mic className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Live Call Monitor</h2>
            <p className="text-xs text-muted-foreground">
              {liveCalls.length} active call{liveCalls.length !== 1 ? 's' : ''} · Monitor transcripts and add team notes
            </p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Live calls */}
      {liveCalls.length > 0 ? (
        <div>
          <p className="text-xs font-semibold text-red-500 mb-2 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
            Live Now
          </p>
          <div className="grid gap-3">
            {liveCalls.map(call => (
              <LiveCallCard
                key={call.id}
                call={call}
                onView={setSelectedCall}
                onAddNote={setNoteCall}
              />
            ))}
          </div>
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <Mic className="w-8 h-8 mx-auto mb-2 text-muted-foreground opacity-30" />
            <p className="text-sm text-muted-foreground">No active calls right now</p>
            <p className="text-xs text-muted-foreground mt-1">Live calls will appear here when in progress</p>
          </CardContent>
        </Card>
      )}

      {/* Recent completed */}
      {recentCalls.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground mb-2">Recently Completed</p>
          <div className="grid gap-3">
            {recentCalls.map(call => (
              <LiveCallCard
                key={call.id}
                call={call}
                onView={setSelectedCall}
                onAddNote={setNoteCall}
              />
            ))}
          </div>
        </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div className="flex justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      )}

      {/* Transcript viewer dialog */}
      <Dialog open={!!selectedCall} onOpenChange={() => setSelectedCall(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2">
                <Headphones className="w-5 h-5 text-primary" />
                Call Transcript — {selectedCall?.lead_name}
              </DialogTitle>
              <Button variant="ghost" size="sm" onClick={() => setSelectedCall(null)}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </DialogHeader>
          {selectedCall && (
            <LiveTranscriptViewer
              call={selectedCall}
              onClose={() => setSelectedCall(null)}
              onAddNote={() => {
                refetch();
                setSelectedCall(null);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* Quick add note dialog */}
      <Dialog open={!!noteCall} onOpenChange={() => setNoteCall(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Team Note</DialogTitle>
          </DialogHeader>
          {noteCall && (
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-muted/50 border border-border">
                <p className="text-sm font-semibold">{noteCall.lead_name}</p>
                <p className="text-xs text-muted-foreground">{noteCall.phone_number}</p>
              </div>
              <QuickAddNote
                call={noteCall}
                onSuccess={() => {
                  setNoteCall(null);
                  refetch();
                }}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function QuickAddNote({ call, onSuccess }) {
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const addNoteMutation = useMutation({
    mutationFn: async (noteText) => {
      const existingNotes = call.team_notes ? JSON.parse(call.team_notes) : [];
      const newNote = {
        text: noteText,
        added_by: 'user',
        added_at: new Date().toISOString(),
      };
      await base44.entities.CallLog.update(call.id, {
        team_notes: JSON.stringify([...existingNotes, newNote]),
      });
    },
    onSuccess: () => {
      toast.success('Note added');
      onSuccess();
    },
  });

  const handleSave = () => {
    if (!note.trim()) {
      toast.error('Please enter a note');
      return;
    }
    addNoteMutation.mutate(note);
  };

  return (
    <div className="space-y-3">
      <Textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Add a note for your team..."
        className="min-h-[100px]"
      />
      <div className="flex gap-2 justify-end">
        <Button variant="outline" onClick={() => setNote(null)} disabled={saving}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={saving || !note.trim()} className="gap-2">
          <Send className="w-3.5 h-3.5" />
          {saving ? 'Adding...' : 'Add Note'}
        </Button>
      </div>
    </div>
  );
}