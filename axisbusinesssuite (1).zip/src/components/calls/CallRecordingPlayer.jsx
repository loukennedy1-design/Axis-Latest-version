import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Play, Pause, RotateCcw, Volume2, AlertTriangle, CheckCircle, 
  TrendingUp, TrendingDown, Minus, Brain, Target, MessageSquare,
  Phone, Clock, AlertCircle, Award, X
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const FLAG_CONFIG = {
  interrupted_customer: { label: 'Interrupted Customer', severity: 'high', icon: AlertTriangle },
  missed_close: { label: 'Missed Close Opportunity', severity: 'high', icon: Target },
  negative_tone: { label: 'Negative Tone', severity: 'high', icon: TrendingDown },
  talked_too_much: { label: 'Talked Too Much', severity: 'medium', icon: MessageSquare },
  missed_objection: { label: 'Missed Objection', severity: 'high', icon: AlertCircle },
  no_empathy: { label: 'Lacked Empathy', severity: 'medium', icon: AlertCircle },
  unclear_value: { label: 'Unclear Value Prop', severity: 'medium', icon: AlertCircle },
  compliance_risk: { label: 'Compliance Risk', severity: 'critical', icon: AlertTriangle },
  rushed_pitch: { label: 'Rushed Pitch', severity: 'medium', icon: Clock },
  no_qualifying: { label: 'No Qualifying Questions', severity: 'medium', icon: AlertCircle },
};

const SCORE_CONFIG = {
  excellent: { min: 90, color: 'text-emerald-600', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
  good: { min: 70, color: 'text-blue-600', bg: 'bg-blue-500/10', border: 'border-blue-500/20' },
  fair: { min: 50, color: 'text-amber-600', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
  poor: { min: 0, color: 'text-red-600', bg: 'bg-red-500/10', border: 'border-red-500/20' },
};

function getScoreConfig(score) {
  if (score >= 90) return SCORE_CONFIG.excellent;
  if (score >= 70) return SCORE_CONFIG.good;
  if (score >= 50) return SCORE_CONFIG.fair;
  return SCORE_CONFIG.poor;
}

export default function CallRecordingPlayer({ call, onClose, onAnalyze }) {
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [analyzing, setAnalyzing] = useState(false);

  const coachingFlags = call.coaching_flags ? JSON.parse(call.coaching_flags) : [];
  const coachingRecommendations = call.coaching_recommendations ? JSON.parse(call.coaching_recommendations) : [];
  const qualityMetrics = call.quality_metrics ? JSON.parse(call.quality_metrics) : {};
  const scoreConfig = getScoreConfig(call.coaching_score || 0);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    if (audioRef.current) {
      audioRef.current.currentTime = percentage * duration;
    }
  };

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      await onAnalyze(call.id);
      toast.success('Call analysis complete');
    } catch (err) {
      toast.error('Analysis failed');
    }
    setAnalyzing(false);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="space-y-4">
      {/* Hidden audio element */}
      {call.recording_url && (
        <audio
          ref={audioRef}
          src={call.recording_url}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={() => setIsPlaying(false)}
        />
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Phone className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold">{call.lead_name}</h3>
            <p className="text-xs text-muted-foreground">{call.phone_number}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className={scoreConfig.bg + ' ' + scoreConfig.color + ' border ' + scoreConfig.border}>
            <Award className="w-3 h-3 mr-1" />
            Score: {call.coaching_score || 0}/100
          </Badge>
          {call.requires_coaching && (
            <Badge className="bg-red-500/10 text-red-600 border-red-500/20">
              <AlertTriangle className="w-3 h-3 mr-1" />
              Coaching Required
            </Badge>
          )}
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Recording Player */}
      <Card>
        <CardContent className="p-4">
          <div className="space-y-3">
            {/* Progress bar */}
            <div
              className="h-2 bg-muted rounded-full cursor-pointer relative group"
              onClick={handleSeek}
            >
              <div
                className="h-full bg-primary rounded-full transition-all"
                style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-primary rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ left: `calc(${(currentTime / (duration || 1)) * 100}% - 8px)` }}
              />
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Button
                  size="icon"
                  variant="outline"
                  className="w-10 h-10 rounded-full"
                  onClick={togglePlay}
                  disabled={!call.recording_url}
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-8 h-8"
                  onClick={() => {
                    if (audioRef.current) {
                      audioRef.current.currentTime = 0;
                      setCurrentTime(0);
                    }
                  }}
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
                <span className="text-sm font-mono">
                  {formatTime(currentTime)} / {formatTime(duration || call.recording_duration || 0)}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-muted-foreground" />
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-24"
                />
              </div>
            </div>

            {!call.recording_url && (
              <div className="text-center py-3 text-sm text-muted-foreground bg-muted/50 rounded-lg">
                <AlertCircle className="w-4 h-4 mx-auto mb-1" />
                No recording available for this call
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Coaching Analysis */}
      {call.coaching_analyzed ? (
        <div className="space-y-4">
          {/* Quality Metrics */}
          <Card>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold">Quality Metrics</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {Object.entries(qualityMetrics).map(([metric, score]) => (
                  <div key={metric} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="capitalize text-muted-foreground">{metric.replace(/_/g, ' ')}</span>
                      <span className={`font-medium ${score >= 80 ? 'text-emerald-600' : score >= 60 ? 'text-amber-600' : 'text-red-600'}`}>
                        {score}%
                      </span>
                    </div>
                    <Progress value={score} className="h-1.5" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Coaching Flags */}
          {coachingFlags.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  <p className="text-sm font-semibold">Coaching Flags ({coachingFlags.length})</p>
                </div>
                <div className="space-y-2">
                  {coachingFlags.map((flag, i) => {
                    const config = FLAG_CONFIG[flag] || { label: flag, severity: 'medium', icon: AlertCircle };
                    const Icon = config.icon;
                    return (
                      <div
                        key={i}
                        className={`flex items-center gap-2 p-2 rounded-lg border ${
                          config.severity === 'critical' ? 'bg-red-500/10 border-red-500/20' :
                          config.severity === 'high' ? 'bg-amber-500/10 border-amber-500/20' :
                          'bg-blue-500/10 border-blue-500/20'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${
                          config.severity === 'critical' ? 'text-red-600' :
                          config.severity === 'high' ? 'text-amber-600' :
                          'text-blue-600'
                        }`} />
                        <span className="text-sm font-medium">{config.label}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          {coachingRecommendations.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Brain className="w-4 h-4 text-primary" />
                  <p className="text-sm font-semibold">AI Recommendations</p>
                </div>
                <ScrollArea className="h-40">
                  <ul className="space-y-2">
                    {coachingRecommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                        <span className="text-muted-foreground">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <Card>
          <CardContent className="p-6 text-center space-y-3">
            <Brain className="w-10 h-10 mx-auto text-muted-foreground opacity-30" />
            <div>
              <p className="font-medium text-sm">No coaching analysis yet</p>
              <p className="text-xs text-muted-foreground mt-1">AI will analyze the call and provide quality metrics, flags, and recommendations</p>
            </div>
            <Button
              onClick={handleAnalyze}
              disabled={analyzing || !call.transcript}
              className="gap-2"
            >
              {analyzing ? (
                <><RotateCcw className="w-4 h-4 animate-spin" />Analyzing...</>
              ) : (
                <><Brain className="w-4 h-4" />Analyze Call</>
              )}
            </Button>
            {!call.transcript && (
              <p className="text-xs text-amber-600">
                <AlertCircle className="w-3 h-3 inline mr-1" />
                Transcript required for analysis
              </p>
            )}
          </CardContent>
        </Card>
      )}

      {/* Call Info */}
      <div className="grid grid-cols-3 gap-3 text-xs">
        <div className="p-3 rounded-lg bg-muted/50 text-center">
          <p className="text-muted-foreground">Duration</p>
          <p className="font-semibold mt-1">{formatTime(call.duration_seconds || 0)}</p>
        </div>
        <div className="p-3 rounded-lg bg-muted/50 text-center">
          <p className="text-muted-foreground">Outcome</p>
          <p className="font-semibold mt-1 capitalize">{call.outcome?.replace(/_/g, ' ')}</p>
        </div>
        <div className="p-3 rounded-lg bg-muted/50 text-center">
          <p className="text-muted-foreground">Date</p>
          <p className="font-semibold mt-1">{format(new Date(call.created_date), 'MMM d')}</p>
        </div>
      </div>
    </div>
  );
}