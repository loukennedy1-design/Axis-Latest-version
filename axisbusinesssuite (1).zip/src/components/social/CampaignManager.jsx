import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Trash2, Play, Pause, Target, DollarSign, Users, BarChart3, Sparkles, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const OBJECTIVES = [
  { value: 'lead_generation', label: '🎯 Lead Generation' },
  { value: 'brand_awareness', label: '📣 Brand Awareness' },
  { value: 'sales', label: '💰 Sales' },
  { value: 'engagement', label: '💬 Engagement' },
  { value: 'recruitment', label: '👥 Recruitment' },
];

const PLATFORMS_OPTIONS = ['facebook', 'instagram', 'linkedin', 'twitter', 'tiktok'];
const PLATFORM_ICONS = { facebook: '📘', instagram: '📸', linkedin: '🔗', twitter: '🐦', tiktok: '🎵' };

const STATUS_COLORS = {
  active: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  paused: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  completed: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  draft: 'bg-muted text-muted-foreground border-border',
};

const INDUSTRIES = [
  'Real Estate', 'Insurance', 'Solar Energy', 'Mortgage & Lending', 'Healthcare',
  'Legal Services', 'Financial Planning', 'Home Services', 'Automotive', 'Recruiting',
];

export default function CampaignManager() {
  const qc = useQueryClient();
  const [showCreate, setShowCreate] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [selectedPlatforms, setSelectedPlatforms] = useState(['facebook']);
  const [form, setForm] = useState({ name: '', industry: '', objective: 'lead_generation', total_budget: 500, start_date: '', end_date: '', notes: '' });
  const setF = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const { data: campaigns = [] } = useQuery({
    queryKey: ['social-campaigns'],
    queryFn: () => base44.entities.SocialCampaign.list('-created_date', 50),
  });

  const { data: posts = [] } = useQuery({
    queryKey: ['social-posts'],
    queryFn: () => base44.entities.SocialPost.list('-created_date', 200),
  });

  const createCampaign = useMutation({
    mutationFn: async (data) => {
      const me = await base44.auth.me();
      const res = await base44.functions.invoke('createRecord', { entity: 'SocialCampaign', data: { ...data, owner: me.email } });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries(['social-campaigns']); setShowCreate(false); toast.success('Campaign created!'); },
  });

  const updateCampaign = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SocialCampaign.update(id, data),
    onSuccess: () => { qc.invalidateQueries(['social-campaigns']); toast.success('Updated!'); },
  });

  const deleteCampaign = useMutation({
    mutationFn: (id) => base44.entities.SocialCampaign.delete(id),
    onSuccess: () => { qc.invalidateQueries(['social-campaigns']); toast.success('Deleted'); },
  });

  const autoGenerateCampaign = async () => {
    if (!form.industry || !form.name) { toast.error('Fill in campaign name and industry first'); return; }
    setGenerating(true);
    try {
      const prompt = `Create a complete social media campaign strategy for a ${form.industry} business.

Campaign Name: ${form.name}
Objective: ${form.objective}
Budget: $${form.total_budget}
Platforms: ${selectedPlatforms.join(', ')}

Return a JSON object with:
{
  "strategy": "2-3 sentence campaign strategy overview",
  "content_mix": "recommended % split between post types",
  "posting_frequency": "recommended posting schedule",
  "kpis": "key metrics to track",
  "audience_segments": "3 audience segments to target",
  "notes": "detailed campaign notes and recommendations"
}`;
      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            strategy: { type: 'string' }, content_mix: { type: 'string' },
            posting_frequency: { type: 'string' }, kpis: { type: 'string' },
            audience_segments: { type: 'string' }, notes: { type: 'string' },
          },
        },
      });
      setF('notes', `STRATEGY: ${result.strategy}\n\nCONTENT MIX: ${result.content_mix}\n\nSCHEDULE: ${result.posting_frequency}\n\nKPIs: ${result.kpis}\n\nAUDIENCES: ${result.audience_segments}\n\nNOTES: ${result.notes}`);
      toast.success('Campaign strategy generated!');
    } catch { toast.error('Generation failed'); }
    setGenerating(false);
  };

  const handleSubmit = () => {
    if (!form.name || !form.industry) { toast.error('Name and industry required'); return; }
    createCampaign.mutate({ ...form, platforms: JSON.stringify(selectedPlatforms), posts_count: 0, total_reach: 0, total_leads: 0 });
  };

  const togglePlatform = (p) => {
    setSelectedPlatforms(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]);
  };

  const getCampaignPosts = (campaign) => posts.filter(p => p.industry === campaign.industry);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Campaigns ({campaigns.length})</h3>
        <Button size="sm" className="gap-2" onClick={() => setShowCreate(true)}>
          <Plus className="w-3.5 h-3.5" /> New Campaign
        </Button>
      </div>

      {campaigns.length === 0 && (
        <div className="text-center py-16 border-2 border-dashed border-border rounded-xl">
          <Target className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-40" />
          <p className="text-muted-foreground text-sm">No campaigns yet. Create your first AI-powered campaign!</p>
          <Button size="sm" className="mt-3 gap-2" onClick={() => setShowCreate(true)}>
            <Plus className="w-3.5 h-3.5" /> Create Campaign
          </Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {campaigns.map(campaign => {
          const platformList = (() => { try { return JSON.parse(campaign.platforms || '[]'); } catch { return []; } })();
          const campaignPosts = getCampaignPosts(campaign);
          const budgetPct = campaign.total_budget > 0 ? Math.min(100, Math.round((campaign.spent_budget / campaign.total_budget) * 100)) : 0;

          return (
            <Card key={campaign.id} className={campaign.status === 'active' ? 'border-emerald-500/30' : ''}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-sm">{campaign.name}</CardTitle>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{campaign.industry}</p>
                  </div>
                  <Badge className={`text-[10px] ${STATUS_COLORS[campaign.status]}`}>{campaign.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Platforms */}
                <div className="flex gap-1 flex-wrap">
                  {platformList.map(p => (
                    <span key={p} className="text-[10px] bg-muted px-1.5 py-0.5 rounded">{PLATFORM_ICONS[p]} {p}</span>
                  ))}
                </div>

                {/* KPIs */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  {[
                    { label: 'Posts', val: campaignPosts.length, icon: BarChart3 },
                    { label: 'Reach', val: campaign.total_reach?.toLocaleString() || '0', icon: Users },
                    { label: 'Leads', val: campaign.total_leads || 0, icon: Target },
                  ].map(({ label, val, icon: Icon }) => (
                    <div key={label} className="bg-muted/30 rounded-lg p-2">
                      <div className="text-sm font-bold">{val}</div>
                      <div className="text-[9px] text-muted-foreground flex items-center justify-center gap-0.5">
                        <Icon className="w-2.5 h-2.5" />{label}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Budget */}
                {campaign.total_budget > 0 && (
                  <div>
                    <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                      <span>Budget: ${campaign.spent_budget || 0} spent</span>
                      <span>${campaign.total_budget} total</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full">
                      <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${budgetPct}%` }} />
                    </div>
                  </div>
                )}

                {/* Dates */}
                {campaign.start_date && (
                  <p className="text-[10px] text-muted-foreground">
                    {format(new Date(campaign.start_date), 'MMM d')}
                    {campaign.end_date && ` → ${format(new Date(campaign.end_date), 'MMM d, yyyy')}`}
                  </p>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-1">
                  {campaign.status === 'active' ? (
                    <Button size="sm" variant="outline" className="flex-1 text-xs gap-1" onClick={() => updateCampaign.mutate({ id: campaign.id, data: { status: 'paused' } })}>
                      <Pause className="w-3 h-3" /> Pause
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" className="flex-1 text-xs gap-1 text-emerald-400 border-emerald-500/30 hover:bg-emerald-500/10" onClick={() => updateCampaign.mutate({ id: campaign.id, data: { status: 'active' } })}>
                      <Play className="w-3 h-3" /> Activate
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive text-xs gap-1" onClick={() => deleteCampaign.mutate(campaign.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>New Social Campaign</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Label className="text-xs">Campaign Name *</Label>
                <Input value={form.name} onChange={e => setF('name', e.target.value)} placeholder="e.g. Summer Lead Push 2024" />
              </div>
              <div>
                <Label className="text-xs">Industry *</Label>
                <Select value={form.industry} onValueChange={v => setF('industry', v)}>
                  <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>{INDUSTRIES.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Objective</Label>
                <Select value={form.objective} onValueChange={v => setF('objective', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{OBJECTIVES.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Total Budget ($)</Label>
                <Input type="number" value={form.total_budget} onChange={e => setF('total_budget', Number(e.target.value))} />
              </div>
              <div>
                <Label className="text-xs">Start Date</Label>
                <Input type="date" value={form.start_date} onChange={e => setF('start_date', e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">End Date</Label>
                <Input type="date" value={form.end_date} onChange={e => setF('end_date', e.target.value)} />
              </div>
            </div>

            <div>
              <Label className="text-xs mb-2 block">Platforms</Label>
              <div className="flex flex-wrap gap-2">
                {PLATFORMS_OPTIONS.map(p => (
                  <button
                    key={p}
                    onClick={() => togglePlatform(p)}
                    className={`px-3 py-1.5 rounded-lg border text-xs transition-all ${selectedPlatforms.includes(p) ? 'border-primary bg-primary/10 text-primary' : 'border-border text-muted-foreground'}`}
                  >
                    {PLATFORM_ICONS[p]} {p}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label className="text-xs">Notes / Strategy</Label>
                <Button size="sm" variant="outline" className="h-6 text-[10px] gap-1" onClick={autoGenerateCampaign} disabled={generating}>
                  {generating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  AI Generate Strategy
                </Button>
              </div>
              <textarea
                value={form.notes}
                onChange={e => setF('notes', e.target.value)}
                placeholder="Campaign notes and strategy..."
                className="w-full min-h-[100px] text-xs bg-muted/30 border border-border rounded-lg p-2.5 text-foreground resize-none focus:outline-none focus:ring-1 focus:ring-ring"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button variant="outline" className="flex-1" onClick={() => setShowCreate(false)}>Cancel</Button>
              <Button className="flex-1 gap-2" onClick={handleSubmit} disabled={createCampaign.isPending}>
                {createCampaign.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                Create Campaign
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}