import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, Copy, Calendar, Save, ImageIcon, RefreshCw, Send } from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import VideoGenerator from '@/components/shared/VideoGenerator';

const INDUSTRIES = [
  'Real Estate', 'Insurance', 'Solar Energy', 'Mortgage & Lending', 'Healthcare',
  'Legal Services', 'Financial Planning', 'Home Services', 'Automotive', 'Education',
  'E-commerce', 'Restaurant & Food', 'Fitness & Wellness', 'Technology / SaaS', 'Recruiting',
];

const PLATFORMS = [
  { value: 'facebook', label: '📘 Facebook', color: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
  { value: 'instagram', label: '📸 Instagram', color: 'bg-pink-500/10 text-pink-400 border-pink-500/30' },
  { value: 'linkedin', label: '🔗 LinkedIn', color: 'bg-sky-500/10 text-sky-400 border-sky-500/30' },
  { value: 'twitter', label: '🐦 Twitter/X', color: 'bg-slate-500/10 text-slate-300 border-slate-500/30' },
  { value: 'tiktok', label: '🎵 TikTok', color: 'bg-purple-500/10 text-purple-400 border-purple-500/30' },
  { value: 'all', label: '🌐 All Platforms', color: 'bg-primary/10 text-primary border-primary/30' },
];

const TONES = ['Professional', 'Friendly & Casual', 'Bold & Urgent', 'Inspirational', 'Humorous', 'Educational'];
const OBJECTIVES = [
  { value: 'leads', label: '🎯 Generate Leads' },
  { value: 'awareness', label: '📣 Brand Awareness' },
  { value: 'traffic', label: '🔗 Drive Traffic' },
  { value: 'engagement', label: '💬 Boost Engagement' },
  { value: 'conversions', label: '💰 Drive Sales' },
];
const POST_TYPES = ['organic', 'ad', 'story', 'reel'];

function GeneratedPostCard({ post, platform, onSave, onSchedule }) {
  const [saving, setSaving] = useState(false);
  const [imageLoading, setImageLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState(null);

  const generateImage = async () => {
    setImageLoading(true);
    try {
      const res = await base44.integrations.Core.GenerateImage({ prompt: post.image_prompt });
      setImageUrl(res.url);
    } catch {
      toast.error('Failed to generate image');
    }
    setImageLoading(false);
  };

  const handleSave = async (status = 'draft') => {
    setSaving(true);
    try {
      const me = await base44.auth.me();
      const created = await base44.functions.invoke('createRecord', {
        entity: 'SocialPost',
        data: {
          title: post.title,
          content: post.content,
          cta: post.cta,
          hashtags: post.hashtags,
          target_audience: post.target_audience,
          platform,
          image_url: imageUrl,
          status: 'draft',
          approval_status: 'pending_admin_approval',
          submitted_by_email: me.email,
          submitted_at: new Date().toISOString(),
          ai_generated: true,
          owner: me.email,
        }
      });
      const recordId = created?.data?.id || created?.id;
      if (recordId) {
        await base44.functions.invoke('submitContentForApproval', {
          content_type: 'social_post',
          content_id: recordId,
          content_title: post.title,
          submitter_email: me.email,
        });
      }
      toast.success('Submitted for admin approval — you will be notified once reviewed.');
    } catch {
      toast.error('Failed to submit post for approval');
    }
    setSaving(false);
  };

  const platformInfo = PLATFORMS.find(p => p.value === platform) || PLATFORMS[5];

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold">{post.title}</CardTitle>
          <Badge className={platformInfo.color}>{platformInfo.label}</Badge>
        </div>
        {post.target_audience && (
          <p className="text-[11px] text-muted-foreground">👥 {post.target_audience}</p>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Post Content */}
        <div className="bg-muted/40 rounded-lg p-3">
          <p className="text-sm whitespace-pre-wrap leading-relaxed">{post.content}</p>
        </div>

        {/* CTA & Time */}
        <div className="flex flex-wrap gap-2 text-xs">
          {post.cta && <span className="bg-primary/10 text-primary px-2 py-1 rounded border border-primary/20">🎯 {post.cta}</span>}
          {post.best_time && <span className="bg-muted px-2 py-1 rounded text-muted-foreground">⏰ Best: {post.best_time}</span>}
        </div>

        {/* Hashtags */}
        {post.hashtags && (
          <div className="flex flex-wrap gap-1">
            {post.hashtags.split(' ').slice(0, 8).map(tag => (
              <span key={tag} className="text-[10px] text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded">#{tag}</span>
            ))}
          </div>
        )}

        {/* AI Image */}
        {imageUrl ? (
          <img src={imageUrl} alt="Generated" className="w-full h-40 object-cover rounded-lg" />
        ) : (
          <button
            onClick={generateImage}
            disabled={imageLoading}
            className="w-full h-24 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center gap-2 text-muted-foreground hover:border-primary/50 hover:text-primary transition-colors text-xs"
          >
            {imageLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
            {imageLoading ? 'Generating image...' : 'Generate AI Image'}
          </button>
        )}

        {/* Image prompt */}
        {post.image_prompt && (
          <p className="text-[10px] text-muted-foreground italic">📷 Visual: {post.image_prompt}</p>
        )}

        {/* AI Video */}
        {post.image_prompt && (
          <VideoGenerator
            prompt={`A short social media video clip. ${post.content}. Visual concept: ${post.image_prompt}. Target audience: ${post.target_audience || 'general audience'}. Call to action: ${post.cta || ''}.`}
            label="Generate Video Clip"
            aspectRatio="9:16"
            compact
            buttonClassName="w-full justify-center text-xs gap-1"
          />
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-1">
          <Button size="sm" variant="outline" className="flex-1 text-xs gap-1" onClick={() => { navigator.clipboard.writeText(post.content); toast.success('Copied!'); }}>
            <Copy className="w-3 h-3" /> Copy
          </Button>
          <Button size="sm" className="flex-1 text-xs gap-1 bg-amber-600 hover:bg-amber-700 text-white" disabled={saving} onClick={() => handleSave('draft')}>
            {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
            Submit for Approval
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ContentStudio() {
  const { user } = useCurrentUser();
  const [config, setConfig] = useState({
    industry: '',
    platform: 'facebook',
    post_type: 'organic',
    objective: 'leads',
    tone: 'Professional',
    company_name: '',
    count: 3,
  });
  const [loading, setLoading] = useState(false);
  const [posts, setPosts] = useState([]);

  const set = (k, v) => setConfig(prev => ({ ...prev, [k]: v }));

  const generate = async () => {
    if (!config.industry) { toast.error('Please select an industry'); return; }
    setLoading(true);
    setPosts([]);
    try {
      const res = await base44.functions.invoke('generateSocialContent', config);
      setPosts(res.data.posts || []);
      if (!res.data.posts?.length) toast.error('No posts returned — try again');
    } catch {
      toast.error('Failed to generate content');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* Config Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" /> AI Content Generator
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
            <div>
              <Label className="text-xs">Industry *</Label>
              <Select value={config.industry} onValueChange={v => set('industry', v)}>
                <SelectTrigger><SelectValue placeholder="Select industry" /></SelectTrigger>
                <SelectContent>
                  {INDUSTRIES.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Platform</Label>
              <Select value={config.platform} onValueChange={v => set('platform', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PLATFORMS.map(p => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Post Type</Label>
              <Select value={config.post_type} onValueChange={v => set('post_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {POST_TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Objective</Label>
              <Select value={config.objective} onValueChange={v => set('objective', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {OBJECTIVES.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Tone</Label>
              <Select value={config.tone} onValueChange={v => set('tone', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TONES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Company / Brand Name</Label>
              <Input value={config.company_name} onChange={e => set('company_name', e.target.value)} placeholder="e.g. Axis Solar" />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Label className="text-xs whitespace-nowrap">Posts to generate:</Label>
              {[1, 3, 5, 10].map(n => (
                <button
                  key={n}
                  onClick={() => set('count', n)}
                  className={`w-8 h-8 rounded-lg text-xs font-bold transition-all border ${config.count === n ? 'bg-primary text-primary-foreground border-primary' : 'border-border text-muted-foreground hover:border-primary/50'}`}
                >{n}</button>
              ))}
            </div>
            <Button onClick={generate} disabled={loading} className="ml-auto gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {loading ? `Generating ${config.count} posts...` : `Generate ${config.count} AI Posts`}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Loading skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: config.count }).map((_, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-5 animate-pulse space-y-3">
              <div className="h-4 bg-muted rounded w-2/3" />
              <div className="h-24 bg-muted rounded" />
              <div className="h-3 bg-muted rounded w-1/2" />
              <div className="h-20 bg-muted rounded" />
            </div>
          ))}
        </div>
      )}

      {/* Generated Posts */}
      {posts.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">{posts.length} AI-Generated Posts</h3>
            <Button variant="outline" size="sm" className="gap-2" onClick={generate} disabled={loading}>
              <RefreshCw className="w-3 h-3" /> Regenerate
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {posts.map((post, i) => (
              <GeneratedPostCard key={i} post={post} platform={config.platform} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}