import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus, Eye, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const PLATFORM_COLORS = {
  facebook: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  instagram: 'bg-pink-500/20 text-pink-400 border-pink-500/30',
  linkedin: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
  twitter: 'bg-slate-500/20 text-slate-300 border-slate-500/30',
  tiktok: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  all: 'bg-primary/20 text-primary border-primary/30',
};

const STATUS_COLORS = {
  draft: 'bg-muted text-muted-foreground',
  scheduled: 'bg-amber-500/20 text-amber-400',
  published: 'bg-emerald-500/20 text-emerald-400',
  failed: 'bg-destructive/20 text-destructive',
};

const PLATFORM_ICONS = { facebook: '📘', instagram: '📸', linkedin: '🔗', twitter: '🐦', tiktok: '🎵', all: '🌐' };

export default function PostCalendar() {
  const qc = useQueryClient();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(null);
  const [selectedPost, setSelectedPost] = useState(null);

  const { data: posts = [] } = useQuery({
    queryKey: ['social-posts'],
    queryFn: () => base44.entities.SocialPost.list('-created_date', 200),
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.SocialPost.delete(id),
    onSuccess: () => { qc.invalidateQueries(['social-posts']); toast.success('Post deleted'); },
  });

  const updateStatusMut = useMutation({
    mutationFn: ({ id, status }) => base44.entities.SocialPost.update(id, { status }),
    onSuccess: () => { qc.invalidateQueries(['social-posts']); toast.success('Status updated'); },
  });

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Pad to start on Sunday
  const startPad = monthStart.getDay();
  const paddedDays = [...Array(startPad).fill(null), ...days];

  const getPostsForDay = (day) => {
    if (!day) return [];
    return posts.filter(p => {
      const dateField = p.scheduled_at || p.created_date;
      return dateField && isSameDay(new Date(dateField), day);
    });
  };

  const dayPosts = selectedDay ? getPostsForDay(selectedDay) : [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* Calendar */}
      <div className="lg:col-span-2">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">{format(currentMonth, 'MMMM yyyy')}</CardTitle>
              <div className="flex gap-1">
                <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => setCurrentMonth(m => subMonths(m, 1))}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => setCurrentMonth(m => addMonths(m, 1))}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {/* Day headers */}
            <div className="grid grid-cols-7 mb-2">
              {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => (
                <div key={d} className="text-center text-[10px] font-semibold text-muted-foreground py-2">{d}</div>
              ))}
            </div>
            {/* Days */}
            <div className="grid grid-cols-7 gap-1">
              {paddedDays.map((day, i) => {
                const dayPostsList = day ? getPostsForDay(day) : [];
                const isSelected = day && selectedDay && isSameDay(day, selectedDay);
                const isToday = day && isSameDay(day, new Date());
                return (
                  <div
                    key={i}
                    onClick={() => day && setSelectedDay(day)}
                    className={`min-h-[72px] rounded-lg p-1.5 border cursor-pointer transition-all ${
                      !day ? 'opacity-0 pointer-events-none border-transparent' :
                      isSelected ? 'border-primary bg-primary/10' :
                      'border-border hover:border-primary/40 hover:bg-muted/30'
                    }`}
                  >
                    {day && (
                      <>
                        <div className={`text-xs font-semibold mb-1 w-5 h-5 flex items-center justify-center rounded-full ${isToday ? 'bg-primary text-primary-foreground' : 'text-foreground'}`}>
                          {format(day, 'd')}
                        </div>
                        <div className="space-y-0.5">
                          {dayPostsList.slice(0, 2).map(p => (
                            <div key={p.id} className={`text-[9px] px-1 py-0.5 rounded truncate ${STATUS_COLORS[p.status]}`}>
                              {PLATFORM_ICONS[p.platform]} {p.title || p.content?.slice(0,15)}
                            </div>
                          ))}
                          {dayPostsList.length > 2 && (
                            <div className="text-[9px] text-muted-foreground px-1">+{dayPostsList.length - 2} more</div>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="flex flex-wrap gap-3 mt-4 pt-3 border-t border-border">
              {Object.entries(STATUS_COLORS).map(([s, cls]) => (
                <div key={s} className="flex items-center gap-1.5 text-[10px]">
                  <div className={`w-2 h-2 rounded-full ${cls.split(' ')[0]}`} />
                  <span className="capitalize text-muted-foreground">{s}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Day Detail / Post List */}
      <div>
        <Card className="sticky top-4">
          <CardHeader>
            <CardTitle className="text-sm">
              {selectedDay ? format(selectedDay, 'EEEE, MMM d') : 'Select a Day'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!selectedDay && (
              <p className="text-xs text-muted-foreground text-center py-8">Click a day on the calendar to see posts</p>
            )}
            {selectedDay && dayPosts.length === 0 && (
              <div className="text-center py-6">
                <p className="text-xs text-muted-foreground mb-3">No posts scheduled</p>
              </div>
            )}
            <div className="space-y-3">
              {dayPosts.map(post => (
                <div key={post.id} className="border border-border rounded-lg p-3 space-y-2">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-1 flex-wrap">
                        <Badge className={`text-[9px] px-1 py-0 ${PLATFORM_COLORS[post.platform]}`}>
                          {PLATFORM_ICONS[post.platform]} {post.platform}
                        </Badge>
                        <Badge className={`text-[9px] px-1 py-0 ${STATUS_COLORS[post.status]}`}>{post.status}</Badge>
                      </div>
                      <p className="text-xs text-foreground line-clamp-2">{post.content}</p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Select
                      value={post.status}
                      onValueChange={v => updateStatusMut.mutate({ id: post.id, status: v })}
                    >
                      <SelectTrigger className="h-6 text-[10px] flex-1"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="scheduled">Scheduled</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setSelectedPost(post)}>
                      <Eye className="w-3 h-3" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-6 w-6 text-destructive hover:text-destructive" onClick={() => deleteMut.mutate(post.id)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* All posts summary */}
            <div className="mt-4 pt-3 border-t border-border">
              <p className="text-[10px] text-muted-foreground font-semibold mb-2">THIS MONTH</p>
              <div className="grid grid-cols-2 gap-2 text-center">
                {[
                  { label: 'Total', val: posts.length, cls: 'text-foreground' },
                  { label: 'Published', val: posts.filter(p => p.status === 'published').length, cls: 'text-emerald-400' },
                  { label: 'Scheduled', val: posts.filter(p => p.status === 'scheduled').length, cls: 'text-amber-400' },
                  { label: 'Drafts', val: posts.filter(p => p.status === 'draft').length, cls: 'text-muted-foreground' },
                ].map(({ label, val, cls }) => (
                  <div key={label} className="bg-muted/30 rounded p-2">
                    <div className={`text-lg font-bold ${cls}`}>{val}</div>
                    <div className="text-[9px] text-muted-foreground">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}