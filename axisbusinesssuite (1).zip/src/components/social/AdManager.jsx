import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, DollarSign, Target, Users, TrendingUp, Eye, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

const INDUSTRIES = [
  'Real Estate', 'Insurance', 'Solar Energy', 'Mortgage & Lending', 'Healthcare',
  'Legal Services', 'Financial Planning', 'Home Services', 'Automotive', 'Recruiting',
];

const AD_OBJECTIVES = [
  { value: 'leads', label: '🎯 Lead Generation', desc: 'Collect names, emails, and phones directly in the ad' },
  { value: 'conversions', label: '💰 Conversions', desc: 'Drive people to take action on your website' },
  { value: 'traffic', label: '🔗 Website Traffic', desc: 'Send people to your landing page or website' },
  { value: 'awareness', label: '📣 Brand Awareness', desc: 'Maximize reach and brand recall' },
  { value: 'engagement', label: '💬 Post Engagement', desc: 'Boost likes, comments, and shares' },
];

const PLATFORMS = ['facebook', 'instagram', 'linkedin', 'twitter', 'tiktok'];
const PLATFORM_ICONS = { facebook: '📘', instagram: '📸', linkedin: '🔗', twitter: '🐦', tiktok: '🎵' };

export default function AdManager() {
  const qc = useQueryClient();
  const [generating, setGenerating] = useState(false);
  const [generatedAd, setGeneratedAd] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);
  const [imageLoading, setImageLoading] = useState(false);

  const [config, setConfig] = useState({
    industry: '',
    platform: 'facebook',
    objective: 'leads',
    budget: 20,
    audience: '',
    usp: '',
    company_name: '',
  });
  const set = (k, v) => setConfig(prev => ({ ...prev, [k]: v }));

  const { data: ads = [] } = useQuery({
    queryKey: ['social-ads'],
    queryFn: () => base44.entities.SocialPost.filter({ post_type: 'ad' }),
  });

  const deleteAd = useMutation({
    mutationFn: (id) => base44.entities.SocialPost.delete(id),
    onSuccess: () => { qc.invalidateQueries(['social-ads']); toast.success('Ad deleted'); },
  });

  const generateAd = async () => {
    if (!config.industry) { toast.error('Select an industry'); return; }
    setGenerating(true);
    setGeneratedAd(null);
    setImageUrl(null);
    try {
      const prompt = `You are an expert performance marketer specializing in paid social ads. Create a high-converting ${config.platform} AD for a ${config.industry} business.

Campaign Objective: ${config.objective}
Daily Budget: $${config.budget}
Target Audience: ${config.audience || 'homeowners, decision makers, local market'}
Unique Selling Proposition: ${config.usp || 'trusted local experts, proven results, free consultation'}
Company: ${config.company_name || 'our company'}

Create a complete ad creative with:
- Attention-grabbing HEADLINE (max 40 chars for Facebook/Instagram, max 70 for LinkedIn)
- Primary TEXT / copy (2-3 short paragraphs, hook + value + urgency)
- Description (1 sentence benefit statement)
- Strong CTA button text (from: Learn More, Sign Up, Get Quote, Book Now, Contact Us, Download, Apply Now)
- Suggested targeting criteria (age, interests, behaviors)
- Recommended bid strategy
- Ad creative visual concept (detailed image prompt for AI generation)
- A/B test variant headline

Return JSON with this exact structure:
{
  "headline": "...",
  "primary_text": "...",
  "description": "...",
  "cta": "...",
  "targeting": "...",
  "bid_strategy": "...",
  "image_prompt": "...",
  "ab_headline": "...",
  "estimated_cpl": "...",
  "hashtags": "..."
}`;

      const result = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: 'object',
          properties: {
            headline: { type: 'string' }, primary_text: { type: 'string' },
            description: { type: 'string' }, cta: { type: 'string' },
            targeting: { type: 'string' }, bid_strategy: { type: 'string' },
            image_prompt: { type: 'string' }, ab_headline: { type: 'string' },
            estimated_cpl: { type: 'string' }, hashtags: { type: 'string' },
          },
        },
      });
      setGeneratedAd(result);
    } catch {
      toast.error('Failed to generate ad');
    }
    setGenerating(false);
  };

  const generateAdImage = async () => {
    if (!generatedAd?.image_prompt) return;
    setImageLoading(true);
    try {
      const res = await base44.integrations.Core.GenerateImage({ prompt: generatedAd.image_prompt });
      setImageUrl(res.url);
    } catch { toast.error('Image generation failed'); }
    setImageLoading(false);
  };

  const saveAd = async () => {
    try {
      const me = await base44.auth.me();
      await base44.functions.invoke('createRecord', {
        entity: 'SocialPost',
        data: {
          title: generatedAd.headline,
          content: generatedAd.primary_text,
          cta: generatedAd.cta,
          hashtags: generatedAd.hashtags,
          target_audience: generatedAd.targeting,
          platform: config.platform,
          post_type: 'ad',
          ad_objective: config.objective,
          ad_budget: config.budget,
          image_url: imageUrl,
          status: 'draft',
          ai_generated: true,
          owner: me.email,
          industry: config.industry,
        }
      });
      qc.invalidateQueries(['social-ads']);
      toast.success('Ad saved to library!');
    } catch { toast.error('Failed to save'); }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Config */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary" /> AI Ad Creator
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Industry *</Label>
                <Select value={config.industry} onValueChange={v => set('industry', v)}>
                  <SelectTrigger><SelectValue placeholder="Select..." /></SelectTrigger>
                  <SelectContent>{INDUSTRIES.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Platform</Label>
                <Select value={config.platform} onValueChange={v => set('platform', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {PLATFORMS.map(p => <SelectItem key={p} value={p}>{PLATFORM_ICONS[p]} {p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-xs">Campaign Objective</Label>
              <div className="grid grid-cols-1 gap-2 mt-1">
                {AD_OBJECTIVES.map(obj => (
                  <button
                    key={obj.value}
                    onClick={() => set('objective', obj.value)}
                    className={`text-left p-2.5 rounded-lg border text-xs transition-all ${config.objective === obj.value ? 'border-primary bg-primary/10' : 'border-border hover:border-primary/40'}`}
                  >
                    <div className="font-medium">{obj.label}</div>
                    <div className="text-muted-foreground text-[10px]">{obj.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Daily Budget ($)</Label>
                <Input type="number" value={config.budget} onChange={e => set('budget', Number(e.target.value))} min={1} />
              </div>
              <div>
                <Label className="text-xs">Company Name</Label>
                <Input value={config.company_name} onChange={e => set('company_name', e.target.value)} placeholder="Brand name" />
              </div>
            </div>
            <div>
              <Label className="text-xs">Target Audience (optional)</Label>
              <Input value={config.audience} onChange={e => set('audience', e.target.value)} placeholder="e.g. homeowners 35-65, small business owners..." />
            </div>
            <div>
              <Label className="text-xs">Unique Selling Proposition (optional)</Label>
              <Input value={config.usp} onChange={e => set('usp', e.target.value)} placeholder="e.g. #1 rated, save 30%, free quote..." />
            </div>

            <Button onClick={generateAd} disabled={generating} className="w-full gap-2">
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {generating ? 'Crafting your ad...' : 'Generate AI Ad'}
            </Button>
          </CardContent>
        </Card>

        {/* Preview */}
        <div>
          {generatedAd ? (
            <Card className="border-primary/20">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Ad Preview — {PLATFORM_ICONS[config.platform]} {config.platform}</CardTitle>
                  <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px]">${config.budget}/day</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Mock ad frame */}
                <div className="border border-border rounded-xl overflow-hidden">
                  {imageUrl ? (
                    <img src={imageUrl} alt="Ad visual" className="w-full h-48 object-cover" />
                  ) : (
                    <button
                      onClick={generateAdImage}
                      disabled={imageLoading}
                      className="w-full h-40 bg-gradient-to-br from-muted to-muted/50 flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors text-xs"
                    >
                      {imageLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Target className="w-5 h-5" />}
                      {imageLoading ? 'Generating...' : 'Click to Generate Ad Image'}
                    </button>
                  )}
                  <div className="p-3 bg-card">
                    <p className="text-xs text-muted-foreground mb-1">{config.company_name || 'Your Business'} · Sponsored</p>
                    <p className="text-sm font-bold leading-snug">{generatedAd.headline}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{generatedAd.primary_text}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[10px] text-muted-foreground">{generatedAd.description}</span>
                      <Badge className="bg-primary text-primary-foreground text-[10px] px-2 py-0.5">{generatedAd.cta}</Badge>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="bg-muted/30 rounded p-2">
                    <div className="text-muted-foreground mb-0.5">Targeting</div>
                    <div className="text-foreground">{generatedAd.targeting}</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2">
                    <div className="text-muted-foreground mb-0.5">Est. Cost/Lead</div>
                    <div className="text-emerald-400 font-bold">{generatedAd.estimated_cpl}</div>
                  </div>
                  <div className="bg-muted/30 rounded p-2 col-span-2">
                    <div className="text-muted-foreground mb-0.5">A/B Test Variant Headline</div>
                    <div className="text-foreground italic">"{generatedAd.ab_headline}"</div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 text-xs" onClick={() => navigator.clipboard.writeText(generatedAd.primary_text).then(() => toast.success('Copied!'))}>Copy Copy</Button>
                  <Button size="sm" className="flex-1 text-xs" onClick={saveAd}>Save to Library</Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="h-full border-2 border-dashed border-border rounded-xl flex items-center justify-center text-muted-foreground text-sm p-8 text-center">
              <div>
                <Target className="w-10 h-10 mx-auto mb-3 opacity-30" />
                <p>Configure your ad parameters and click Generate to create an AI-optimized ad creative</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Saved Ads Library */}
      {ads.length > 0 && (
        <div>
          <h3 className="font-semibold text-sm mb-3">Ad Library ({ads.length})</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {ads.map(ad => (
              <Card key={ad.id} className="relative">
                <CardContent className="p-4 space-y-2">
                  {ad.image_url && <img src={ad.image_url} alt="" className="w-full h-28 object-cover rounded-lg" />}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Badge className="text-[9px] px-1 py-0">{PLATFORM_ICONS[ad.platform]} {ad.platform}</Badge>
                    <Badge variant="outline" className="text-[9px] px-1 py-0">{ad.ad_objective}</Badge>
                    {ad.ad_budget > 0 && <Badge className="text-[9px] px-1 py-0 bg-emerald-500/10 text-emerald-400">${ad.ad_budget}/day</Badge>}
                  </div>
                  <p className="text-xs font-semibold line-clamp-1">{ad.title}</p>
                  <p className="text-[10px] text-muted-foreground line-clamp-2">{ad.content}</p>
                  <Button variant="ghost" size="icon" className="absolute top-2 right-2 h-6 w-6 text-destructive hover:text-destructive" onClick={() => deleteAd.mutate(ad.id)}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}