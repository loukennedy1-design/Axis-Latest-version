import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Users, Heart, MousePointerClick, Target } from 'lucide-react';

const PLATFORM_COLORS = {
  facebook: '#1877F2',
  instagram: '#E1306C',
  linkedin: '#0A66C2',
  twitter: '#1DA1F2',
  tiktok: '#69C9D0',
  all: '#F5C842',
};

const PLATFORM_ICONS = { facebook: '📘', instagram: '📸', linkedin: '🔗', twitter: '🐦', tiktok: '🎵', all: '🌐' };

export default function SocialDashboard() {
  const { data: posts = [] } = useQuery({
    queryKey: ['social-posts'],
    queryFn: () => base44.entities.SocialPost.list('-created_date', 200),
  });

  const { data: campaigns = [] } = useQuery({
    queryKey: ['social-campaigns'],
    queryFn: () => base44.entities.SocialCampaign.list('-created_date', 50),
  });

  const totalReach = posts.reduce((a, p) => a + (p.performance_reach || 0), 0);
  const totalLikes = posts.reduce((a, p) => a + (p.performance_likes || 0), 0);
  const totalClicks = posts.reduce((a, p) => a + (p.performance_clicks || 0), 0);
  const totalLeads = posts.reduce((a, p) => a + (p.performance_leads || 0), 0);

  // Posts by platform
  const platformCounts = posts.reduce((acc, p) => { acc[p.platform] = (acc[p.platform] || 0) + 1; return acc; }, {});
  const platformData = Object.entries(platformCounts).map(([name, value]) => ({ name, value, fill: PLATFORM_COLORS[name] || '#888' }));

  // Posts by status
  const statusCounts = posts.reduce((acc, p) => { acc[p.status] = (acc[p.status] || 0) + 1; return acc; }, {});

  // Posts over time (last 7 days)
  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toISOString().slice(0, 10);
    return {
      name: d.toLocaleDateString('en', { weekday: 'short' }),
      posts: posts.filter(p => (p.created_date || '').startsWith(dateStr)).length,
    };
  });

  const kpis = [
    { label: 'Total Reach', value: totalReach.toLocaleString(), icon: Users, color: 'text-blue-400' },
    { label: 'Total Likes', value: totalLikes.toLocaleString(), icon: Heart, color: 'text-pink-400' },
    { label: 'Total Clicks', value: totalClicks.toLocaleString(), icon: MousePointerClick, color: 'text-amber-400' },
    { label: 'Leads Generated', value: totalLeads.toLocaleString(), icon: Target, color: 'text-emerald-400' },
  ];

  return (
    <div className="space-y-5">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {kpis.map(({ label, value, icon: Icon, color }) => (
          <Card key={label}>
            <CardContent className="p-4 flex items-center gap-3">
              <Icon className={`w-7 h-7 ${color} shrink-0`} />
              <div>
                <div className="text-xl font-bold">{value}</div>
                <div className="text-[11px] text-muted-foreground">{label}</div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Posts', val: posts.length },
          { label: 'Published', val: posts.filter(p => p.status === 'published').length },
          { label: 'Scheduled', val: posts.filter(p => p.status === 'scheduled').length },
          { label: 'Active Campaigns', val: campaigns.filter(c => c.status === 'active').length },
        ].map(({ label, val }) => (
          <Card key={label}>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{val}</div>
              <div className="text-[11px] text-muted-foreground">{label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Posts over time */}
        <Card>
          <CardHeader><CardTitle className="text-sm">Posts Created — Last 7 Days</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={last7}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
                <Bar dataKey="posts" name="Posts" fill="hsl(43,67%,52%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Platform distribution */}
        <Card>
          <CardHeader><CardTitle className="text-sm">Posts by Platform</CardTitle></CardHeader>
          <CardContent>
            {platformData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height={140}>
                  <PieChart>
                    <Pie data={platformData} cx="50%" cy="50%" innerRadius={35} outerRadius={60} paddingAngle={3} dataKey="value">
                      {platformData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex flex-wrap gap-2 mt-2">
                  {platformData.map(d => (
                    <div key={d.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: d.fill }} />
                      {PLATFORM_ICONS[d.name]} {d.name} ({d.value})
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">No posts yet</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent posts */}
      <Card>
        <CardHeader><CardTitle className="text-sm">Recent Posts</CardTitle></CardHeader>
        <CardContent>
          {posts.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">No posts created yet</p>}
          <div className="space-y-2">
            {posts.slice(0, 8).map(post => (
              <div key={post.id} className="flex items-start gap-3 py-2 border-b border-border/50 last:border-0">
                <span className="text-lg">{PLATFORM_ICONS[post.platform]}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                    <span className="text-xs font-semibold truncate">{post.title || post.content?.slice(0, 40)}</span>
                    <Badge className={`text-[9px] px-1 py-0 capitalize ${
                      post.status === 'published' ? 'bg-emerald-500/20 text-emerald-400' :
                      post.status === 'scheduled' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-muted text-muted-foreground'
                    }`}>{post.status}</Badge>
                    {post.post_type === 'ad' && <Badge className="text-[9px] px-1 py-0 bg-primary/20 text-primary">AD</Badge>}
                  </div>
                  <p className="text-[10px] text-muted-foreground line-clamp-1">{post.content}</p>
                </div>
                <div className="text-right text-[10px] text-muted-foreground shrink-0">
                  {post.performance_reach > 0 && <div>👁 {post.performance_reach.toLocaleString()}</div>}
                  {post.performance_likes > 0 && <div>❤️ {post.performance_likes}</div>}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}