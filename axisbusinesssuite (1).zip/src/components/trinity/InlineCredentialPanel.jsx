import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ChevronDown, ExternalLink, Loader2, CheckCircle2, X, Info, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { toast } from 'sonner';

// AXIS AI — no character avatar, using Sparkles icon

const APP_URL = typeof window !== 'undefined' ? window.location.origin : 'https://app.axisbusinesssuite.com';

export default function InlineCredentialPanel({ tool, user, onConnected, onClose }) {
  if (tool === 'phone') return <TwilioPanel onConnected={onConnected} onClose={onClose} />;
  if (tool === 'calendar') return <CalendarPanel onConnected={onConnected} onClose={onClose} />;
  if (tool === 'email') return <EmailPanel onConnected={onConnected} onClose={onClose} />;
  return null;
}

function PanelShell({ title, subtitle, icon: Icon, children, onClose }) {
  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 300 }}
      className="fixed top-0 right-0 h-full w-full sm:w-[440px] bg-card border-l border-border z-[70] flex flex-col shadow-2xl"
    >
      {/* Header */}
      <div className="px-6 py-5 border-b border-border flex items-start gap-3 bg-gradient-to-r from-amber-500/10 to-transparent">
        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0"><Sparkles className="w-4 h-4 text-primary" /></div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-bold flex items-center gap-2">
            <Icon className="w-4 h-4 text-amber-500" />
            {title}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>
        </div>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground p-1 rounded-lg hover:bg-muted">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto px-6 py-5">
        {children}
      </div>
    </motion.div>
  );
}

function HelpExpander({ label, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-1.5">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1 text-[11px] text-amber-600 hover:text-amber-500 font-medium"
      >
        <ChevronDown className={`w-3 h-3 transition-transform ${open ? 'rotate-180' : ''}`} />
        Where do I find this?
      </button>
      {open && (
        <div className="mt-1.5 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/15 text-xs text-muted-foreground">
          {children}
        </div>
      )}
    </div>
  );
}

function FieldTooltip({ label, technical }) {
  return (
    <div className="flex items-center gap-1 mb-1.5">
      <Label className="text-xs font-medium">{label}</Label>
      <span className="group relative inline-flex">
        <Info className="w-3 h-3 text-muted-foreground cursor-help" />
        <span className="absolute left-4 top-0 hidden group-hover:block z-10 bg-popover border border-border rounded-md px-2 py-1 text-[10px] whitespace-nowrap shadow-lg">
          {technical}
        </span>
      </span>
    </div>
  );
}

// ── Twilio Panel ──────────────────────────────────────────────
function TwilioPanel({ onConnected, onClose }) {
  const [sid, setSid] = useState('');
  const [token, setToken] = useState('');
  const [phone, setPhone] = useState('');
  const [saving, setSaving] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const handleSaveAndVerify = async () => {
    if (!sid.trim() || !token.trim() || !phone.trim()) {
      toast.error('Please fill in all three fields');
      return;
    }
    setSaving(true);
    try {
      // Save credentials
      await base44.functions.invoke('saveUserSettings', {
        action: 'save',
        data: {
          twilio_account_sid: sid.trim(),
          twilio_auth_token: token.trim(),
          twilio_phone_number: phone.trim(),
        },
      });

      // Verify
      setVerifying(true);
      const verifyRes = await base44.functions.invoke('getTwilioConfig', { action: 'verifyCredentials' });
      setVerifying(false);

      if (verifyRes.data?.valid) {
        toast.success(`Phone connected as ${verifyRes.data.friendly_name || 'Twilio'}!`);
        onConnected('phone');
      } else {
        toast.error(verifyRes.data?.message || 'Credentials saved but verification failed. You can fix later.');
        // Still mark as connected since they saved creds
        onConnected('phone');
      }
    } catch (e) {
      console.error('Twilio save failed:', e);
      toast.error('Failed to save: ' + (e.message || 'unknown error'));
    } finally {
      setSaving(false);
      setVerifying(false);
    }
  };

  return (
    <PanelShell title="Connect Your Phone" subtitle="AXIS AI pre-filled what it could — just enter these 3 fields" icon={PhoneIcon} onClose={onClose}>
      <div className="space-y-5">
        <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/15 p-3 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
          <p className="text-xs text-muted-foreground">I've handled the redirect URI and environment. You just need your Twilio console credentials.</p>
        </div>

        <div>
          <FieldTooltip label="Account ID" technical="twilio_account_sid" />
          <Input value={sid} onChange={(e) => setSid(e.target.value)} placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxx" className="h-10" />
          <HelpExpander>
            Go to <a href="https://console.twilio.com" target="_blank" rel="noreferrer" className="text-amber-600 underline inline-flex items-center gap-0.5">twilio.com → Console <ExternalLink className="w-2.5 h-2.5" /></a> — it's at the top of the page.
          </HelpExpander>
        </div>

        <div>
          <FieldTooltip label="Secret Key" technical="twilio_auth_token" />
          <Input type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="Your auth token" className="h-10" />
          <HelpExpander>
            In Twilio Console → Home, find "Auth Token" right below your Account SID. Click show to reveal it.
          </HelpExpander>
        </div>

        <div>
          <FieldTooltip label="Phone Number" technical="twilio_phone_number" />
          <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+15551234567" className="h-10" />
          <HelpExpander>
            In Twilio Console → Phone Numbers → Manage → Active numbers. Must be in E.164 format (starts with +1).
          </HelpExpander>
        </div>

        <Button onClick={handleSaveAndVerify} disabled={saving || verifying} className="w-full h-11 bg-amber-600 hover:bg-amber-700">
          {saving || verifying ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> {verifying ? 'Verifying...' : 'Saving...'}</>
          ) : (
            <>Connect Phone</>
          )}
        </Button>
      </div>
    </PanelShell>
  );
}

// ── Google Calendar Panel ────────────────────────────────────
function CalendarPanel({ onConnected, onClose }) {
  const [connecting, setConnecting] = useState(false);

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const res = await base44.functions.invoke('googleCalendarAuth', {});
      const url = res.data?.auth_url || res.data?.url;
      if (url) {
        window.location.href = url;
      } else {
        throw new Error('No auth URL returned');
      }
    } catch (e) {
      console.error('Calendar connect failed:', e);
      toast.error('Failed to start Google Calendar connection');
      setConnecting(false);
    }
  };

  return (
    <PanelShell title="Connect Your Calendar" subtitle="Google Calendar sync — appointments will flow both ways" icon={CalIcon} onClose={onClose}>
      <div className="space-y-5">
        <div className="rounded-lg bg-emerald-500/5 border border-emerald-500/15 p-3 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
          <p className="text-xs text-muted-foreground">This is a one-click OAuth connection. Google will ask for permission to manage your calendar events.</p>
        </div>

        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">AXIS AI will:</p>
          <ul className="space-y-1.5 text-xs text-foreground/80">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Open Google's secure login page</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Request calendar read/write permission</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Sync all AXIS appointments automatically</li>
          </ul>
        </div>

        <Button onClick={handleConnect} disabled={connecting} className="w-full h-11 bg-amber-600 hover:bg-amber-700">
          {connecting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Connect Google Calendar'}
        </Button>

        <button onClick={() => onConnected('calendar')} className="w-full text-xs text-muted-foreground hover:text-foreground py-1">
          I'll connect later
        </button>
      </div>
    </PanelShell>
  );
}

// ── Email Panel ──────────────────────────────────────────────
function EmailPanel({ onConnected, onClose }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [provider, setProvider] = useState('gmail');
  const [saving, setSaving] = useState(false);

  const PROVIDER_CONFIG = {
    gmail: { incoming_host: 'imap.gmail.com', incoming_port: 993, outgoing_host: 'smtp.gmail.com', outgoing_port: 587 },
    outlook: { incoming_host: 'outlook.office365.com', incoming_port: 993, outgoing_host: 'smtp.office365.com', outgoing_port: 587 },
    yahoo: { incoming_host: 'imap.mail.yahoo.com', incoming_port: 993, outgoing_host: 'smtp.mail.yahoo.com', outgoing_port: 587 },
    icloud: { incoming_host: 'imap.mail.me.com', incoming_port: 993, outgoing_host: 'smtp.mail.me.com', outgoing_port: 587 },
  };

  const handleSave = async () => {
    if (!email.trim() || !password.trim()) {
      toast.error('Please enter your email and password');
      return;
    }
    setSaving(true);
    try {
      const cfg = PROVIDER_CONFIG[provider] || PROVIDER_CONFIG.gmail;
      await base44.functions.invoke('saveUserSettings', {
        action: 'save',
        data: {
          email_provider: provider,
          email_address: email.trim(),
          email_password: password.trim(),
          email_incoming_host: cfg.incoming_host,
          email_incoming_port: cfg.incoming_port,
          email_outgoing_host: cfg.outgoing_host,
          email_outgoing_port: cfg.outgoing_port,
          email_incoming_ssl: true,
          email_outgoing_ssl: true,
        },
      });
      toast.success('Email settings saved!');
      onConnected('email');
    } catch (e) {
      toast.error('Failed to save: ' + (e.message || 'unknown error'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <PanelShell title="Connect Your Email" subtitle="Send and receive emails from within AXIS" icon={MailIcon} onClose={onClose}>
      <div className="space-y-5">
        <div>
          <FieldTooltip label="Email Provider" technical="email_provider" />
          <div className="flex flex-wrap gap-2">
            {Object.keys(PROVIDER_CONFIG).map(p => (
              <button
                key={p}
                onClick={() => setProvider(p)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                  provider === p ? 'bg-amber-600 text-white' : 'bg-muted text-muted-foreground border-border'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <div>
          <FieldTooltip label="Email Address" technical="email_address" />
          <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="h-10" />
          <HelpExpander>
            The email address you'll use to send and receive messages through AXIS.
          </HelpExpander>
        </div>

        <div>
          <FieldTooltip label="App Password" technical="email_password" />
          <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your app-specific password" className="h-10" />
          <HelpExpander>
            For Gmail: use an <a href="https://myaccount.google.com/apppasswords" target="_blank" rel="noreferrer" className="text-amber-600 underline inline-flex items-center gap-0.5">App Password <ExternalLink className="w-2.5 h-2.5" /></a>, not your regular password. 2FA must be enabled.
          </HelpExpander>
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full h-11 bg-amber-600 hover:bg-amber-700">
          {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Connect Email'}
        </Button>
      </div>
    </PanelShell>
  );
}

// Inline SVG icons (avoid importing wrong lucide names)
function PhoneIcon(props) {
  return <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>;
}
function CalIcon(props) {
  return <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>;
}
function MailIcon(props) {
  return <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>;
}