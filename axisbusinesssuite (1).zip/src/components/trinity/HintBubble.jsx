import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles } from 'lucide-react';

// Trinity avatar removed — using Sparkles icon instead

// Static hint config keyed by route path
const HINT_CONFIG = {
  '/call-bot': {
    target: 'page',
    text: "No leads yet? Add one on the Leads page first, then return here — your AI agent requires contacts to call.",
  },
  '/leads': {
    target: 'page',
    text: "Import a CSV or add leads individually — Trinity AI can qualify them automatically.",
  },
  '/appointments': {
    target: 'page',
    text: "Appointments are auto-created when your AI bot books a call. You can also add them manually here.",
  },
  '/hr': {
    target: 'page',
    text: "Your HR suite is ready. Add employees or post a job to start managing your team.",
  },
  '/settings': {
    target: 'page',
    text: "Find your Twilio Account ID at twilio.com → Console → top of page. Need help? Ask Trinity AI!",
  },
  '/dashboard': {
    target: 'page',
    text: "Welcome. This is your operations center. Review the Getting Started checklist above to begin.",
  },
};

const STORAGE_KEY = 'axis_hints_dismissed';

function getDismissedHints() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}

function dismissHint(route) {
  try {
    const dismissed = getDismissedHints();
    if (!dismissed.includes(route)) {
      dismissed.push(route);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dismissed));
    }
  } catch {}
}

export default function HintBubble({ route: routeProp }) {
  const location = useLocation();
  const route = routeProp || location.pathname;
  const [visible, setVisible] = useState(false);
  const hint = HINT_CONFIG[route];

  useEffect(() => {
    if (!hint) {
      setVisible(false);
      return;
    }
    const dismissed = getDismissedHints();
    if (dismissed.includes(route)) {
      setVisible(false);
      return;
    }
    // Small delay so it appears after page settles
    const timer = setTimeout(() => setVisible(true), 600);
    // Auto-dismiss after 10 seconds
    const autoTimer = setTimeout(() => {
      setVisible(false);
      dismissHint(route);
    }, 10000);
    return () => {
      clearTimeout(timer);
      clearTimeout(autoTimer);
    };
  }, [route, hint]);

  if (!hint || !visible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 10, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 10, scale: 0.95 }}
        className="fixed bottom-24 right-6 z-[35] max-w-xs"
      >
        <div className="relative rounded-xl border border-amber-500/30 bg-card shadow-xl overflow-hidden">
          {/* Amber top accent */}
          <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-amber-500 to-amber-400" />
          <div className="p-3.5 flex items-start gap-2.5">
            <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-foreground/90 leading-relaxed">{hint.text}</p>
            </div>
            <button
              onClick={() => { setVisible(false); dismissHint(route); }}
              className="text-muted-foreground hover:text-foreground shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
        {/* Speech bubble pointer */}
        <div className="absolute -bottom-1 right-8 w-3 h-3 bg-card border-b border-r border-amber-500/30 rotate-45" />
      </motion.div>
    </AnimatePresence>
  );
}