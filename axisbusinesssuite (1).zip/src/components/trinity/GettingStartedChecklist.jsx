import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { Phone, UserPlus, PhoneCall, Calendar, CheckCircle2, PartyPopper, Sparkles, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const TASKS = [
  { key: 'setup_phone_connected', label: 'Connect your phone', icon: Phone, route: '/settings', tab: 'connections' },
  { key: 'setup_calendar_connected', label: 'Connect your calendar', icon: Calendar, route: '/settings' },
  { key: 'setup_lead_added', label: 'Import or add your first lead', icon: UserPlus, route: '/leads' },
  { key: 'setup_call_run', label: 'Run your first AI call', icon: PhoneCall, route: '/call-bot' },
  { key: 'setup_appt_scheduled', label: 'Schedule your first appointment', icon: Calendar, route: '/appointments' },
];

export default function GettingStartedChecklist() {
  const navigate = useNavigate();
  const [showCelebration, setShowCelebration] = useState(false);

  const { data: settings } = useQuery({
    queryKey: ['system-settings-checklist'],
    queryFn: async () => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
      return res.data?.settings || {};
    },
  });

  // Check completion — if setup_completed_at is set, don't render
  const completed = settings ? TASKS.filter(t => settings[t.key]).length : 0;
  const allDone = settings ? completed === TASKS.length : false;

  // Auto-complete: if all tasks are done but setup_completed_at not set, mark it
  useEffect(() => {
    if (allDone && settings && !settings.setup_completed_at) {
      base44.functions.invoke('saveUserSettings', {
        action: 'save',
        data: { setup_completed_at: new Date().toISOString() },
      }).then(() => {
        setShowCelebration(true);
        setTimeout(() => setShowCelebration(false), 4000);
      }).catch(() => {});
    }
  }, [allDone, settings]);

  if (!settings) return null;
  if (settings.setup_completed_at) return null;
  if (allDone) {
    return (
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="rounded-xl border border-emerald-500/30 bg-gradient-to-r from-emerald-500/10 to-amber-500/10 p-5 flex items-center gap-3"
          >
            <PartyPopper className="w-6 h-6 text-amber-500" />
            <div>
              <p className="text-sm font-bold">You're all set! 🎉</p>
              <p className="text-xs text-muted-foreground">All setup tasks complete. Your AXIS system is fully operational.</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  }

  const progress = (completed / TASKS.length) * 100;

  return (
    <div className="rounded-xl border border-amber-500/20 bg-gradient-to-br from-amber-500/5 via-card to-card overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-4 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <h3 className="text-sm font-bold">Getting Started</h3>
          <span className="text-xs text-muted-foreground">{completed} of {TASKS.length} done</span>
        </div>
        <button
          onClick={() => navigate('/settings')}
          className="text-[11px] text-muted-foreground hover:text-foreground"
        >
          Ask AXIS AI for help →
        </button>
      </div>

      {/* Horizontal progress bar */}
      <div className="px-5 pb-3">
        <div className="flex items-center gap-1">
          {TASKS.map((task, idx) => {
            const done = !!settings[task.key];
            return (
              <React.Fragment key={task.key}>
                <button
                  onClick={() => !done && navigate(task.route)}
                  className={`flex flex-col items-center gap-1 transition-all ${done ? '' : 'cursor-pointer hover:scale-105'}`}
                  title={task.label}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                    done
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-500'
                      : 'bg-muted border-border text-muted-foreground'
                  }`}>
                    {done ? <CheckCircle2 className="w-4 h-4" /> : <task.icon className="w-3.5 h-3.5" />}
                  </div>
                </button>
                {idx < TASKS.length - 1 && (
                  <div className={`flex-1 h-0.5 rounded-full transition-all ${settings[TASKS[idx].key] ? 'bg-emerald-500/40' : 'bg-border'}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Next task row */}
      <div className="px-5 pb-4">
        {TASKS.filter(t => !settings[t.key]).slice(0, 1).map(task => (
          <button
            key={task.key}
            onClick={() => navigate(task.route)}
            className="w-full flex items-center justify-between p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 hover:bg-amber-500/15 transition-colors group"
          >
            <div className="flex items-center gap-3">
              <task.icon className="w-4 h-4 text-amber-500" />
              <div className="text-left">
                <p className="text-xs font-medium text-foreground">{task.label}</p>
                <p className="text-[11px] text-muted-foreground">Click to do this now</p>
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-amber-500 group-hover:translate-x-0.5 transition-transform" />
          </button>
        ))}
      </div>
    </div>
  );
}