import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, CheckCircle2, Phone, Calendar, Mail, Building2, Sparkles, LayoutGrid } from 'lucide-react';

// AXIS AI — no character avatar, using Sparkles icon

const MODULE_LABELS = {
  dashboard: 'Dashboard',
  crm_leads: 'Leads',
  ai_call_bot: 'AI Call Bot',
  crm_appointments: 'Appointments',
  crm_call_logs: 'Call Logs',
  settings: 'Settings',
  ai_call_calendar: 'Call Calendar',
  axis_meet: 'AXIS Meet',
  hr_suite: 'HR Suite',
  recruitment: 'Recruitment',
  learning_center: 'Onboarding',
  finance_ops: 'Financial Ops',
};

const VOICE_LABELS = {
  professional: 'Professional',
  friendly: 'Friendly',
  energetic: 'Energetic',
  calm: 'Calm',
  assertive: 'Direct',
  conversational: 'Conversational',
};

const PERSONALITY_LABELS = {
  consultative: 'Consultative',
  challenger: 'Challenger',
  solution_seller: 'Solution Seller',
  relationship_builder: 'Relationship Builder',
  direct_closer: 'Direct Closer',
};

export default function SetupPreviewPanel({ config }) {
  const { companyName, industry, useCase, agentName, voice, personalityStyle, modules = [], connectedTools = [], botScript } = config;

  const useCaseLabel = {
    call_leads: 'Call Bot & Leads',
    scheduling: 'Scheduling',
    hr: 'HR & Recruiting',
    finance: 'Finance',
    all: 'All Features',
  }[useCase] || '—';

  return (
    <div className="h-full flex flex-col bg-gradient-to-b from-card to-background border-r border-border">
      {/* Header */}
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <h2 className="text-sm font-semibold tracking-tight">Your Setup Preview</h2>
        </div>
        <p className="text-xs text-muted-foreground">This updates live as AXIS AI configures your system</p>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
        {/* Company card */}
        <Section icon={Building2} label="Business">
          <AnimatePresence mode="wait">
            <motion.div
              key={companyName || 'empty'}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-1"
            >
            <p className="text-sm font-medium text-foreground">{companyName || <span className="text-muted-foreground italic">Not set yet</span>}</p>
            <p className="text-xs text-muted-foreground capitalize">{industry ? industry.replace(/_/g, ' ') : 'Industry pending'}</p>
            </motion.div>
          </AnimatePresence>
        </Section>

        {/* AI Agent card */}
        <Section icon={Bot} label="AI Agent">
          <AnimatePresence mode="wait">
            <motion.div
              key={agentName || 'empty'}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2"
            >
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center"><Sparkles className="w-3.5 h-3.5 text-primary" /></div>
                <p className="text-sm font-medium text-foreground">{agentName || <span className="text-muted-foreground italic">Pending</span>}</p>
              </div>
              {(voice || personalityStyle) && (
                <div className="flex flex-wrap gap-1.5">
                  {voice && <Chip>{VOICE_LABELS[voice] || voice} voice</Chip>}
                  {personalityStyle && <Chip>{PERSONALITY_LABELS[personalityStyle] || personalityStyle}</Chip>}
                </div>
              )}
              {botScript && (
                <div className="mt-2 p-2.5 rounded-lg bg-amber-500/5 border border-amber-500/20">
                  <p className="text-[11px] text-muted-foreground mb-1 font-medium">Opening script ready ✓</p>
                  <p className="text-xs text-foreground/80 line-clamp-3">{botScript}</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </Section>

        {/* Modules card */}
        <Section icon={LayoutGrid} label="Sidebar Modules">
          <AnimatePresence mode="wait">
            <motion.div
              key={useCase || 'empty'}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2"
            >
              <p className="text-xs text-muted-foreground mb-1">Configured for: <span className="font-medium text-foreground">{useCaseLabel}</span></p>
              {modules.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {modules.map(m => (
                    <Chip key={m}>{MODULE_LABELS[m] || m}</Chip>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground italic">Choose your main goal to activate modules</p>
              )}
            </motion.div>
          </AnimatePresence>
        </Section>

        {/* Connected tools card */}
        <Section icon={Phone} label="Connected Tools">
          <div className="space-y-2">
            <ToolRow icon={Phone} label="Phone (Twilio)" connected={connectedTools.includes('phone')} />
            <ToolRow icon={Calendar} label="Calendar" connected={connectedTools.includes('calendar')} />
            <ToolRow icon={Mail} label="Email" connected={connectedTools.includes('email')} />
          </div>
        </Section>
      </div>
    </div>
  );
}

function Section({ icon: Icon, label, children }) {
  return (
    <div className="rounded-xl border border-border bg-card/50 p-4">
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-3.5 h-3.5 text-amber-500" />
        <span className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      {children}
    </div>
  );
}

function Chip({ children }) {
  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-primary/10 text-primary text-[11px] font-medium border border-primary/20">
      {children}
    </span>
  );
}

function ToolRow({ icon: Icon, label, connected }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <Icon className="w-3.5 h-3.5 text-muted-foreground" />
        <span className="text-xs text-foreground">{label}</span>
      </div>
      {connected ? (
        <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-500">
          <CheckCircle2 className="w-3.5 h-3.5" />
          Connected
        </span>
      ) : (
        <span className="text-[11px] text-muted-foreground">Not connected</span>
      )}
    </div>
  );
}