import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import ReactMarkdown from 'react-markdown';
import { Send, Sparkles, X, Headphones } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Trinity AI — powered by the in-app agent with SupportConversation tool access

export default function TrinityChatAssistant({ user, onboardingMode = false, autoOpen = false }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(autoOpen);
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [onboardingData, setOnboardingData] = useState({});
  const [conversationId, setConversationId] = useState(null);
  const scrollRef = useRef(null);
  const conversationRef = useRef(null);
  const [hasInitialized, setHasInitialized] = useState(false);

  const onboardingQuestions = [
    {
      key: 'industry',
      question: "Let's configure AXIS for your business. First, what industry are you in?",
      placeholder: "e.g., Retail, Manufacturing, Healthcare, Real Estate, Consulting, E-commerce, SaaS, Financial Services..."
    },
    {
      key: 'company_size',
      question: "Understood. How large is your organization?",
      placeholder: "e.g., Solo founder, 2-10, 11-50, 51-200, 200-500, 500+ employees"
    },
    {
      key: 'departments',
      question: "Which departments will use AXIS? (Select all that apply)",
      placeholder: "e.g., Sales, Marketing, Customer Support, Operations, HR/Recruiting, Finance, Production, Fulfillment"
    },
    {
      key: 'primary_use_case',
      question: "What's your PRIMARY business goal with AXIS? Be specific about what success looks like.",
      placeholder: "e.g., Automate lead follow-up and increase conversion by 30%, Reduce manual admin work by 50%, Centralize all customer communications..."
    },
    {
      key: 'current_tools',
      question: "What tools/systems are you currently using? (This helps me plan integrations and migrations)",
      placeholder: "e.g., Salesforce, HubSpot, QuickBooks, Excel, Slack, Google Workspace, Monday.com, or 'nothing organized yet'"
    },
    {
      key: 'top_challenges',
      question: "What are your top 3 operational pain points right now? (Rank by priority)",
      placeholder: "e.g., 1) Leads falling through cracks, 2) Team communication silos, 3) Manual reporting taking too long..."
    },
    {
      key: 'team_structure',
      question: "Describe your team structure and roles. Who will need what kind of access?",
      placeholder: "e.g., 2 sales reps needing lead management, 1 support person for tickets, 1 admin for reporting..."
    },
    {
      key: 'workflow_preferences',
      question: "How do you prefer work to flow? (e.g., highly structured with approvals, flexible and autonomous, hybrid)",
      placeholder: "Describe your preferred work style..."
    },
    {
      key: 'automation_level',
      question: "What's your comfort level with AI automation? (Full autonomy = AI acts independently, Semi-automated = AI suggests and you approve, Manual = you control everything)",
      placeholder: "Choose your automation comfort level..."
    },
    {
      key: 'kpi_focus',
      question: "What are the top 3-5 metrics/KPIs you care about most? (What should your dashboard highlight?)",
      placeholder: "e.g., Revenue, Lead conversion rate, Response time, Customer satisfaction, Team productivity, Cost per acquisition..."
    },
    {
      key: 'compliance_needs',
      question: "Any compliance or regulatory requirements? (e.g., GDPR, HIPAA, SOC2, TCPA, industry-specific)",
      placeholder: "List any compliance needs or 'none'"
    },
    {
      key: 'growth_plans',
      question: "What are your growth plans for the next 6-12 months? (Helps me scale the system appropriately)",
      placeholder: "e.g., Doubling team size, Expanding to new markets, Adding product lines, Scaling customer base..."
    },
    {
      key: 'budget_tier',
      question: "Which plan tier best fits your needs? (Starter = core features, Professional = advanced automation, Enterprise = full white-glove)",
      placeholder: "Starter, Professional, or Enterprise"
    },
    {
      key: 'timeline',
      question: "What's your ideal timeline to have AXIS fully operational?",
      placeholder: "e.g., ASAP (this week), Within 2 weeks, Within a month, Flexible"
    },
    {
      key: 'special_requirements',
      question: "Anything else I should know? (Special workflows, unique requirements, deal-breakers, or specific expectations)",
      placeholder: "Share any additional details or 'nothing else'"
    }
  ];

  // Initialize — create or load a Trinity agent conversation (regular mode only)
  useEffect(() => {
    if (!isOpen || hasInitialized) return;
    setHasInitialized(true);

    if (onboardingMode) {
      setMessages([{ role: 'assistant', content: onboardingQuestions[0].question }]);
      return;
    }

    // Regular mode — use the in-app agent conversation API
    setMessages([{ role: 'assistant', content: "Hi, I'm Trinity AI. How can I help you today?" }]);

    (async () => {
      try {
        const existing = await base44.agents.listConversations({ agent_name: 'trinity' });
        if (existing && existing.length > 0) {
          conversationRef.current = existing[0];
          setConversationId(existing[0].id);
          if (existing[0].messages?.length > 0) {
            setMessages(existing[0].messages);
          }
        } else {
          const conv = await base44.agents.createConversation({
            agent_name: 'trinity',
            metadata: { name: 'Trinity Support Chat', description: 'In-system support with Trinity AI' }
          });
          conversationRef.current = conv;
          setConversationId(conv.id);
        }
      } catch (e) {
        console.warn('Trinity conversation init failed, falling back to direct LLM:', e);
      }
    })();
  }, [isOpen, hasInitialized, onboardingMode]);

  // Subscribe to conversation updates for streaming responses
  useEffect(() => {
    if (!conversationId || onboardingMode) return;
    const unsubscribe = base44.agents.subscribeToConversation(conversationId, (data) => {
      if (data.messages && data.messages.length > 0) {
        setMessages(data.messages);
        // Stop loading spinner once the assistant starts responding
        const lastMsg = data.messages[data.messages.length - 1];
        if (lastMsg && lastMsg.role === 'assistant' && (lastMsg.content || lastMsg.tool_calls)) {
          setIsLoading(false);
        }
      }
    });
    return () => { if (typeof unsubscribe === 'function') unsubscribe(); };
  }, [conversationId, onboardingMode]);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      if (onboardingMode && onboardingStep < onboardingQuestions.length) {
        // Onboarding flow — keep existing structured questionnaire logic
        const currentQuestion = onboardingQuestions[onboardingStep];
        setOnboardingData(prev => ({ ...prev, [currentQuestion.key]: userMessage }));

        if (onboardingStep < onboardingQuestions.length - 1) {
          setOnboardingStep(prev => prev + 1);
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: onboardingQuestions[onboardingStep + 1].question
          }]);
        } else {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: "Understood — I have everything I need. Configuring your AXIS system now."
          }]);

          const configPayload = {
            industry: onboardingData.industry,
            company_size: onboardingData.company_size,
            departments: onboardingData.departments,
            primary_use_case: onboardingData.primary_use_case,
            current_tools: onboardingData.current_tools,
            top_challenges: onboardingData.top_challenges,
            team_structure: onboardingData.team_structure,
            workflow_preferences: onboardingData.workflow_preferences,
            automation_level: onboardingData.automation_level,
            kpi_focus: onboardingData.kpi_focus,
            compliance_needs: onboardingData.compliance_needs,
            growth_plans: onboardingData.growth_plans,
            budget_tier: onboardingData.budget_tier,
            timeline: onboardingData.timeline,
            special_requirements: onboardingData.special_requirements,
          };

          try {
            const result = await base44.functions.invoke('configureIndustryAdapter', configPayload);
            const enabledCount = result.enabled_modules?.length || 0;
            const configuredWorkflows = result.configured_workflows?.length || 0;

            setMessages(prev => [...prev, {
              role: 'assistant',
              content: `Configuration complete. I've built a custom AXIS instance for your ${onboardingData.industry} business:\n\n- Enabled ${enabledCount} modules\n- Configured ${configuredWorkflows} automated workflows\n- Dashboards tracking: ${onboardingData.kpi_focus}\n- Aligned with your ${onboardingData.automation_level} automation preference\n\nOptimized for: ${onboardingData.primary_use_case}\n\nYour dashboard is ready. You can explore the platform or ask me any questions to begin.`
            }]);
          } catch (configError) {
            console.error('Configuration error:', configError);
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: `Configuration complete. I've set up your AXIS system based on your requirements — the dashboard is ready with custom modules for your ${onboardingData.industry} business. You can explore the features or ask me any questions.`
            }]);
          }
        }
        setIsLoading(false);
      } else if (conversationRef.current) {
        // Regular chat — send via the in-app agent API
        // The subscription will deliver the streamed response + any tool calls
        await base44.agents.addMessage(conversationRef.current, {
          role: 'user',
          content: userMessage
        });
      } else {
        // Fallback — direct LLM call if agent conversation failed to init
        const response = await base44.integrations.Core.InvokeLLM({
          prompt: `You are Trinity AI, the AI assistant for the AXIS Business Suite platform. Your demeanor is that of a supportive mentor and consultative executive — warm, encouraging, and genuinely helpful. Speak in clear, modern, professional English. Keep answers SHORT and FAST — one or two sentences when possible. If the user needs support or a demo, tell them their request can be logged in the Support Hub.\n\nCurrent user: ${user?.email || 'unknown'} | Role: ${user?.role || 'user'}\n\nUser message: ${userMessage}\n\nRespond concisely and directly.`,
          model: 'gpt_5_mini'
        });
        setMessages(prev => [...prev, { role: 'assistant', content: response }]);
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Error getting Trinity AI response:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'I encountered an issue processing that request. Please try again.'
      }]);
      setIsLoading(false);
    }
  };

  const renderMessageContent = (msg) => {
    if (msg.role === 'user') {
      return <p className="whitespace-pre-wrap">{msg.content}</p>;
    }
    // Assistant message — render as markdown for rich formatting
    return <ReactMarkdown className="text-sm prose prose-sm prose-invert max-w-none [&_p]:my-1 [&_ul]:my-1 [&_ol]:my-1 [&_li]:my-0.5">{msg.content || ''}</ReactMarkdown>;
  };

  const renderToolCall = (toolCall, idx) => {
    const status = toolCall.status || '';
    const isRunning = ['pending', 'running', 'in_progress'].includes(status);
    const isFailed = ['failed', 'error'].includes(status);
    const name = toolCall.name || 'Tool';
    const label = toolCall.display_projection?.label || name;

    return (
      <div key={idx} className="flex items-center gap-1.5 text-[10px] text-blue-300 mt-1 ml-1">
        {isRunning ? (
          <Sparkles className="w-3 h-3 animate-pulse" />
        ) : isFailed ? (
          <X className="w-3 h-3 text-red-400" />
        ) : (
          <Headphones className="w-3 h-3 text-emerald-400" />
        )}
        <span className={isFailed ? 'text-red-400' : isRunning ? 'text-blue-300' : 'text-emerald-400'}>
          {isRunning ? (toolCall.display_projection?.active_label || `${label}...`) :
           isFailed ? (toolCall.display_projection?.error_label || `${label} failed`) :
           (toolCall.display_projection?.label || label)}
        </span>
      </div>
    );
  };

  return (
    <>
      {/* Chat Button */}
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full overflow-hidden bg-background hover:ring-2 hover:ring-primary/60 shadow-lg hover:shadow-xl transition-all flex items-center justify-center z-40"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        aria-label="Trinity AI assistant"
      >
        {isOpen ? (
          <X className="w-6 h-6 text-foreground" />
        ) : (
          <img
            src="https://media.base44.com/images/public/69ef71210cace64a00bec165/a9bb86067_f7634e0a-8018-46e0-a6f6-72d3a941baf1.png"
            alt="Trinity AI"
            className="w-full h-full object-cover"
          />
        )}
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 w-[calc(100vw-3rem)] sm:w-96 h-[500px] rounded-2xl shadow-2xl z-40 overflow-hidden flex flex-col"
          >
            <Card className="h-full bg-slate-900 border-slate-700 rounded-2xl flex flex-col">
              {/* Header */}
              <div className="bg-gradient-to-r from-blue-600 to-cyan-500 px-6 py-4 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full overflow-hidden bg-white/10 flex items-center justify-center">
                  <img
                    src="https://media.base44.com/images/public/69ef71210cace64a00bec165/a9bb86067_f7634e0a-8018-46e0-a6f6-72d3a941baf1.png"
                    alt="Trinity AI"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">TRINITY AI</h3>
                  <p className="text-xs text-blue-100">Support &amp; Lead Assistant</p>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="ml-auto w-7 h-7 rounded-lg flex items-center justify-center text-white/80 hover:text-white hover:bg-white/20 transition-colors"
                  aria-label="Close Trinity AI"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 px-4 py-4">
                <div className="space-y-4">
                  {messages.map((msg, idx) => (
                    <motion.div
                      key={idx}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] px-4 py-2 rounded-lg text-sm ${
                          msg.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-800 text-slate-100 border border-slate-700'
                        }`}
                      >
                        {renderMessageContent(msg)}
                        {msg.tool_calls?.map((tc, i) => renderToolCall(tc, i))}
                      </div>
                    </motion.div>
                  ))}
                  {isLoading && (
                    <div className="flex gap-2 items-center">
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  )}
                  <div ref={scrollRef} />
                </div>
              </ScrollArea>

              {/* Input */}
              <form onSubmit={handleSendMessage} className="border-t border-slate-700 px-4 py-3 bg-slate-950">
                <div className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask Trinity AI..."
                    disabled={isLoading}
                    className="bg-slate-800 border-slate-700 text-white placeholder-slate-500 h-9"
                  />
                  <Button
                    type="submit"
                    disabled={isLoading || !input.trim()}
                    size="icon"
                    className="h-9 w-9 bg-blue-600 hover:bg-blue-700"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}