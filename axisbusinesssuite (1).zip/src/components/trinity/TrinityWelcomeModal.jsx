import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader } from '@/components/ui/dialog';
import { Sparkles, ArrowRight } from 'lucide-react';

// Trinity AI — branded with logo image

export default function TrinityWelcomeModal({ isOpen, onClose, user, hasIndustryConfig }) {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleStartOnboarding = async () => {
    setIsLoading(true);
    try {
      await base44.auth.updateMe({ trinity_welcome_seen: true });
      onClose();
      navigate('/industry-onboarding');
    } catch (error) {
      console.error('Error starting onboarding:', error);
      setIsLoading(false);
    }
  };

  const handleSkip = async () => {
    try {
      await base44.auth.updateMe({ trinity_welcome_seen: true });
      onClose();
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md border-0 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 overflow-hidden p-0">
        {/* Trinity Image */}
        <div className="relative w-full h-48 bg-gradient-to-b from-slate-800 to-slate-900 flex items-center justify-center overflow-hidden">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-background flex items-center justify-center drop-shadow-2xl ring-2 ring-primary/40">
            <img
              src="https://media.base44.com/images/public/69ef71210cace64a00bec165/a9bb86067_f7634e0a-8018-46e0-a6f6-72d3a941baf1.png"
              alt="Trinity AI"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent pointer-events-none" />
        </div>

        {/* Content */}
        <div className="px-6 pb-6">
          <div className="flex items-center gap-2 mb-3">
            <img
              src="https://media.base44.com/images/public/69ef71210cace64a00bec165/a9bb86067_f7634e0a-8018-46e0-a6f6-72d3a941baf1.png"
              alt="Trinity AI"
              className="w-6 h-6 rounded-full object-cover"
            />
            <h2 className="text-xl font-bold text-foreground">Welcome to Trinity AI</h2>
          </div>

          <p className="text-sm text-muted-foreground mb-2">
            I'm Trinity AI — your onboarding guide and platform assistant.
          </p>

          <p className="text-sm text-muted-foreground mb-6">
            I'll get your dashboard live, configure your industry settings, and handle anything you need on the AXIS platform. This process is straightforward and structured.
          </p>

          {!hasIndustryConfig && (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-3 mb-6">
              <p className="text-xs font-semibold text-blue-300 mb-1">Getting Started</p>
              <p className="text-xs text-blue-200">
                Let's get your dashboard live — we'll start by configuring your industry and business profile.
              </p>
            </div>
          )}

          {/* Actions */}
          <div className="space-y-3">
            <Button
              onClick={handleStartOnboarding}
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white gap-2"
            >
              {hasIndustryConfig ? 'Talk to Trinity AI' : 'Start Setup'}
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button
              onClick={handleSkip}
              variant="outline"
              className="w-full text-muted-foreground"
              disabled={isLoading}
            >
              Skip for Now
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center mt-4">
            You can always chat with Trinity AI later via the dashboard
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}