import React, { useState, useRef, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Send, Sparkles, CheckCircle2, Loader2, ArrowRight, ArrowLeft, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import SetupPreviewPanel from './SetupPreviewPanel';
import InlineCredentialPanel from './InlineCredentialPanel';
import { INDUSTRIES } from '@/lib/industries';

// AXIS AI — no character avatar, using Sparkles icon
const AXIS_LOGO = 'https://media.base44.com/images/public/69ef71210cace64a00bec165/79702e41a_image.png';

// Industries are imported from @/lib/industries (shared registry).

const USE_CASES = [
  { value: 'call_leads', label: 'Call bot & leads' },
  { value: 'scheduling', label: 'Scheduling' },
  { value: 'hr', label: 'HR & Recruiting' },
  { value: 'finance', label: 'Finance' },
  { value: 'all', label: 'All of it' },
];

const TONES = ['friendly', 'professional', 'direct', 'consultative'];

const USE_CASE_MODULES = {
  call_leads: ['dashboard', 'crm_leads', 'ai_call_bot', 'crm_appointments', 'crm_call_logs', 'settings'],
  scheduling: ['dashboard', 'crm_appointments', 'ai_call_calendar', 'axis_meet', 'settings'],
  hr: ['dashboard', 'hr_suite', 'recruitment', 'learning_center', 'settings'],
  finance: ['dashboard', 'finance_ops', 'settings'],
  all: null, // null = all modules
};

const TOOL_OPTIONS = [
  { value: 'phone', label: 'Phone (Twilio)' },
  { value: 'calendar', label: 'Calendar (Google)' },
  { value: 'email', label: 'Email' },
  { value: 'skip', label: "I'll do this later" },
];

export default function LaunchPad({ user, onComplete }) {
  const [step, setStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState(new Set());
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [answers, setAnswers] = useState({});
  const [previewConfig, setPreviewConfig] = useState({
    companyName: '', industry: '', useCase: '', agentName: '', voice: '', personalityStyle: '', modules: [], connectedTools: [], botScript: '',
  });
  const [credentialTool, setCredentialTool] = useState(null);
  const [connectedTools, setConnectedTools] = useState([]);
  const scrollRef = useRef(null);
  const inputRef = useRef(null);

  const QUESTIONS = [
    {
      key: 'company_name',
      prompt: `Welcome to AXIS. I'm your AXIS AI assistant — I'll have your system configured in a few minutes. First, what's your company name?`,
      type: 'text',
      placeholder: 'e.g. Acme Corp',
    },
    {
      key: 'industry',
      prompt: `Understood, {company}. What industry are you in? This allows me to tailor your scripts and modules.`,
      type: 'select',
      options: INDUSTRIES,
    },
    {
      key: 'use_case',
      prompt: `Noted. What is the primary objective you want AXIS to handle for you right now?`,
      type: 'choice',
      options: USE_CASES,
    },
    {
      key: 'agent_config',
      prompt: `Understood. Now let's configure your AI agent. What should we name them, and what tone should they use? (e.g. "Alex, professional")`,
      type: 'agent',
    },
    {
      key: 'first_tool',
      prompt: `Final step. Which tool would you like to connect first? I'll guide you through the process.`,
      type: 'choice',
      options: TOOL_OPTIONS,
    },
  ];

  // Greeting on mount
  useEffect(() => {
    setMessages([{ role: 'assistant', content: QUESTIONS[0].prompt }]);
  }, []);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  // Focus input on text steps
  useEffect(() => {
    if (QUESTIONS[step]?.type === 'text' && inputRef.current && !isLoading) {
      inputRef.current.focus();
    }
  }, [step, isLoading]);

  const updatePreview = useCallback((key, value) => {
    setAnswers(prev => {
      const next = { ...prev, [key]: value };
      setPreviewConfig({
        companyName: next.company_name || '',
        industry: next.industry || '',
        useCase: next.use_case || '',
        agentName: next.agent_config?.name || '',
        voice: next.agent_config?.voice || '',
        personalityStyle: next.agent_config?.personality || '',
        modules: next.use_case ? (USE_CASE_MODULES[next.use_case] || []) : [],
        connectedTools: connectedTools,
        botScript: next.bot_script || '',
      });
      return next;
    });
  }, [connectedTools]);

  const saveSettings = async (data) => {
    try {
      await base44.functions.invoke('saveUserSettings', { action: 'save', data });
    } catch (e) {
      console.error('saveUserSettings failed:', e);
    }
  };

  const goToStep = (targetStep) => {
    if (completedSteps.has(targetStep) || targetStep < step) {
      setStep(targetStep);
    }
  };

  const goBack = () => {
    if (step > 0) {
      setStep(s => s - 1);
    }
  };

  const handleSubmit = async (value) => {
    if (isLoading) return;
    const question = QUESTIONS[step];
    setCompletedSteps(prev => new Set([...prev, step]));

    // Record user message
    const displayValue = typeof value === 'string' ? value : JSON.stringify(value);
    setMessages(prev => [...prev, { role: 'user', content: displayValue }]);
    setInput('');
    setIsLoading(true);

    try {
      // Process the answer based on step
      if (step === 0) {
        // Company name
        updatePreview('company_name', value);
        setAnswers(prev => ({ ...prev, company_name: value }));
        await saveSettings({ company_name: value });
        // Next question with interpolation
        const nextPrompt = QUESTIONS[1].prompt.replace('{company}', value);
        setMessages(prev => [...prev, { role: 'assistant', content: nextPrompt }]);
        setStep(1);
      } else if (step === 1) {
        // Industry
        const industryLabel = INDUSTRIES.find(i => i.value === value)?.label || value;
        updatePreview('industry', value);
        setAnswers(prev => ({ ...prev, industry: value }));
        await saveSettings({ industry: value });
        setMessages(prev => [...prev, { role: 'assistant', content: `Understood — ${industryLabel}. ${QUESTIONS[2].prompt}` }]);
        setStep(2);
      } else if (step === 2) {
        // Use case — save modules immediately
        const useCaseLabel = USE_CASES.find(u => u.value === value)?.label || value;
        const modules = USE_CASE_MODULES[value];
        updatePreview('use_case', value);
        setAnswers(prev => ({ ...prev, use_case: value }));
        // Save modules + mark onboarding
        const moduleIds = modules === null ? ['all'] : (modules || ['dashboard', 'settings']);
        await saveSettings({
          enabled_modules: JSON.stringify(moduleIds),
        });
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `Complete — I've configured your sidebar for ${useCaseLabel}. You can customize it anytime in Settings → Appearance.\n\n${QUESTIONS[3].prompt}`,
        }]);
        setStep(3);
      } else if (step === 3) {
        // Agent config — parse "Name, tone"
        const agentName = value.name || `${value.name || 'Alex'} from ${answers.company_name || 'your company'}`;
        const tone = value.tone || 'professional';
        const voiceMap = { friendly: 'friendly', professional: 'professional', direct: 'assertive', consultative: 'calm' };
        const personalityMap = { call_leads: 'consultative', scheduling: 'relationship_builder', hr: 'solution_seller', finance: 'solution_seller', all: 'consultative' };
        const voice = voiceMap[tone] || 'professional';
        const personality = personalityMap[answers.use_case] || 'consultative';

        // Generate bot script via backend
        setMessages(prev => [...prev, { role: 'assistant', content: 'Generating your AI agent\'s opening script...' }]);
        setIsLoading(true);

        let botScript = '';
        try {
          const res = await base44.functions.invoke('trinitySetupAssistant', {
            action: 'setup_generate_bot_config',
            industry: answers.industry,
            use_case: answers.use_case,
            tone,
            company_name: answers.company_name,
            agent_name: agentName,
          });
          botScript = res.data?.config?.bot_script || '';
          const config = res.data?.config || {};
          // Save all bot config
          await saveSettings({
            bot_agent_name: config.bot_agent_name || agentName,
            bot_voice: config.bot_voice || voice,
            bot_personality_style: config.bot_personality_style || personality,
            bot_script: botScript,
          });
          updatePreview('agent_config', { name: config.bot_agent_name || agentName, voice: config.bot_voice || voice, personality: config.bot_personality_style || personality });
          setAnswers(prev => ({ ...prev, agent_config: { name: config.bot_agent_name || agentName, voice, tone, personality: config.bot_personality_style || personality }, bot_script: botScript }));
        } catch (e) {
          console.error('Bot config generation failed:', e);
          await saveSettings({ bot_agent_name: agentName, bot_voice: voice, bot_personality_style: personality });
          updatePreview('agent_config', { name: agentName, voice, personality });
        }

        setIsLoading(false);
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `Your AI agent is ready — ${agentName}, ${voice} voice, ${personality} style. The opening script is configured.\n\nYou can adjust it later in Call Bot settings. Now, let's connect your first tool.\n\n${QUESTIONS[4].prompt}`,
        }]);
        setStep(4);
      } else if (step === 4) {
        // First tool
        const toolValue = value;
        setAnswers(prev => ({ ...prev, first_tool: toolValue }));

        if (toolValue === 'phone' || toolValue === 'calendar' || toolValue === 'email') {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `Let's connect your ${toolValue === 'phone' ? 'phone (Twilio)' : toolValue === 'calendar' ? 'calendar (Google)' : 'email'}. I've opened a form on the right with all available fields pre-filled. You'll need to enter the 1-2 fields that require your credentials.`,
          }]);
          setCredentialTool(toolValue);
          // The InlineCredentialPanel will call onConnected when done
        } else {
          // Skip
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `Understood. You can connect your tools anytime from Settings → Connections. Your dashboard is ready.`,
          }]);
          // Finalize — mark onboarding complete on user record
          try {
            await base44.auth.updateMe({ onboarding_completed: true, trinity_welcome_seen: true });
          } catch (e) {
            console.error('updateMe failed:', e);
          }
          setTimeout(() => onComplete && onComplete(), 1500);
        }
      }
    } catch (error) {
      console.error('LaunchPad error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: 'I encountered a minor issue, but we can proceed. ' + (QUESTIONS[step + 1]?.prompt || '') }]);
      if (step < QUESTIONS.length - 1) setStep(prev => prev + 1);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToolConnected = async (tool) => {
    const newTools = [...new Set([...connectedTools, tool])];
    setConnectedTools(newTools);
    const flag = tool === 'phone' ? 'setup_phone_connected' : tool === 'calendar' ? 'setup_calendar_connected' : null;
    if (flag) await saveSettings({ [flag]: true });
    setCredentialTool(null);

    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `${tool === 'phone' ? 'Phone connected — your AI can now make calls.' : tool === 'calendar' ? 'Calendar connected — appointments will sync automatically.' : 'Connected.'}\n\nSetup is complete. Let me take you to your dashboard.`,
    }]);

    try {
      await base44.auth.updateMe({ onboarding_completed: true, trinity_welcome_seen: true });
    } catch (e) {
      console.error('updateMe failed:', e);
    }
    setTimeout(() => onComplete && onComplete(), 1800);
  };

  const currentQuestion = QUESTIONS[step];
  const needsTextInput = currentQuestion?.type === 'text';
  const needsAgentInput = currentQuestion?.type === 'agent';

  return (
    <div className="fixed inset-0 bg-background z-[60] flex flex-col lg:flex-row overflow-hidden">
      {/* Left: Preview Panel */}
      <div className="hidden lg:block w-[38%] xl:w-[34%] shrink-0">
        <SetupPreviewPanel config={previewConfig} />
      </div>

      {/* Right: AXIS AI Chat */}
      <div className="flex-1 flex flex-col min-w-0 bg-background">
        {/* AXIS logo top-left of chat area */}
        <div className="px-6 py-4 flex items-center gap-2 border-b border-border">
          <img src={AXIS_LOGO} alt="AXIS" className="h-7 object-contain" />
          <span className="text-sm font-bold tracking-tight">AXIS Business Suite</span>
          {step > 0 && !isLoading && (
            <Button variant="ghost" size="sm" onClick={goBack} className="ml-auto">
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </Button>
          )}
        </div>

        {/* Step indicator */}
        <div className="flex items-center gap-1 px-4 sm:px-6 py-2 border-b border-border bg-muted/20 overflow-x-auto no-scrollbar">
          {QUESTIONS.map((q, i) => {
            const isDone = completedSteps.has(i);
            const isCurrent = i === step;
            const canClick = completedSteps.has(i) && i !== step;
            return (
              <button
                key={i}
                onClick={() => canClick && goToStep(i)}
                disabled={!canClick}
                className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs transition-all whitespace-nowrap ${
                  isCurrent ? 'bg-primary/20 text-primary font-semibold' :
                  isDone ? 'text-emerald-500 hover:bg-muted cursor-pointer' :
                  'text-muted-foreground opacity-50'
                }`}
              >
                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  isDone ? 'bg-emerald-500 text-white' :
                  isCurrent ? 'bg-primary text-white' : 'bg-muted-foreground/30 text-muted-foreground'
                }`}>
                  {isDone ? <Check className="w-3 h-3" /> : i + 1}
                </span>
                <span className="hidden sm:inline">{q.key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</span>
              </button>
            );
          })}
        </div>

        {/* Chat area */}
        <div className="flex-1 flex flex-col min-h-0">
          <ScrollArea className="flex-1">
            <div className="px-4 sm:px-8 py-6 max-w-2xl mx-auto space-y-4">
              {/* Mobile preview summary */}
              <div className="lg:hidden">
                <MobilePreview config={previewConfig} />
              </div>

              {messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} gap-2`}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-7 h-7 rounded-full bg-primary/20 flex items-center justify-center shrink-0 mt-0.5"><Sparkles className="w-3.5 h-3.5 text-primary" /></div>
                  )}
                  <div
                    className={`max-w-[85%] px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-primary text-primary-foreground rounded-br-md'
                        : 'bg-card border border-border text-card-foreground rounded-bl-md'
                    }`}
                  >
                    {msg.content}
                  </div>
                </motion.div>
              ))}
              {isLoading && (
                <div className="flex items-center gap-2 pl-9">
                  <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="w-2 h-2 bg-amber-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
              )}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          {/* Input area */}
          <div className="border-t border-border px-4 sm:px-8 py-4 bg-card/30">
            <div className="max-w-2xl mx-auto">
              {needsTextInput && (
                <form onSubmit={(e) => { e.preventDefault(); if (input.trim()) handleSubmit(input.trim()); }} className="flex gap-2">
                  <Input
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={currentQuestion.placeholder}
                    disabled={isLoading}
                    className="flex-1 h-11"
                  />
                  <Button type="submit" disabled={isLoading || !input.trim()} size="lg" className="bg-amber-600 hover:bg-amber-700">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              )}

              {currentQuestion?.type === 'select' && !isLoading && (
                <div className="space-y-2">
                  <Select onValueChange={(v) => { if (v) handleSubmit(v); }}>
                    <SelectTrigger className="h-11"><SelectValue placeholder="Select your industry..." /></SelectTrigger>
                    <SelectContent>
                      {currentQuestion.options.map(opt => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {currentQuestion?.type === 'choice' && !isLoading && (
                <div className="flex flex-wrap gap-2">
                  {currentQuestion.options.map(opt => (
                    <Button
                      key={opt.value}
                      variant="outline"
                      onClick={() => handleSubmit(opt.value)}
                      disabled={isLoading}
                      className="h-10 px-4 hover:bg-amber-500/10 hover:border-amber-500/40 hover:text-amber-500"
                    >
                      {opt.label}
                    </Button>
                  ))}
                </div>
              )}

              {needsAgentInput && !isLoading && (
                <AgentInputForm onSubmit={handleSubmit} company={answers.company_name} />
              )}

              {currentQuestion?.type === 'text' && !needsTextInput && !isLoading && null}
            </div>
          </div>
        </div>
      </div>

      {/* Inline Credential Panel */}
      <AnimatePresence>
        {credentialTool && (
          <InlineCredentialPanel
            tool={credentialTool}
            user={user}
            onConnected={handleToolConnected}
            onClose={() => setCredentialTool(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function AgentInputForm({ onSubmit, company }) {
  const [name, setName] = useState('');
  const [tone, setTone] = useState('professional');

  return (
    <div className="space-y-3 rounded-xl border border-border bg-card/50 p-4">
      <div className="space-y-1.5">
        <label className="text-xs font-medium text-muted-foreground">Agent name</label>
        <Input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={`e.g. Alex from ${company || 'Acme'}`}
          className="h-10"
        />
      </div>
      <div className="space-y-1.5">
        <label className="text-xs font-medium text-muted-foreground">Tone</label>
        <div className="flex flex-wrap gap-2">
          {TONES.map(t => (
            <button
              key={t}
              type="button"
              onClick={() => setTone(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                tone === t
                  ? 'bg-amber-600 text-white border-amber-600'
                  : 'bg-muted text-muted-foreground border-border hover:bg-muted/80'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>
      <Button
        onClick={() => onSubmit({ name: name.trim(), tone })}
        disabled={!name.trim()}
        className="w-full bg-amber-600 hover:bg-amber-700"
      >
        <Sparkles className="w-4 h-4" />
        Generate My AI Agent
      </Button>
      <p className="text-[11px] text-muted-foreground text-center">AXIS AI will create a custom opening script based on your industry and tone</p>
    </div>
  );
}

function MobilePreview({ config }) {
  return (
    <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 mb-4">
      <div className="flex items-center gap-2 mb-2">
        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
        <span className="text-xs font-semibold text-amber-600">Live Preview</span>
      </div>
      <div className="space-y-1 text-xs">
        <p><span className="text-muted-foreground">Company:</span> <span className="font-medium">{config.companyName || '—'}</span></p>
        <p><span className="text-muted-foreground">AI Agent:</span> <span className="font-medium">{config.agentName || '—'}</span></p>
        <p><span className="text-muted-foreground">Modules:</span> <span className="font-medium">{config.modules.length}</span></p>
      </div>
    </div>
  );
}