import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Check, Loader2, Sparkles, Rocket } from 'lucide-react';
import { toast } from 'sonner';
import { PLANS, getSetupFeeBreakdown, SETUP_FEE_TOTAL } from '@/lib/pricing';

const SETUP_DELIVERABLES = [
  'Full system configuration by an AXIS specialist',
  'Twilio number & AI call bot setup',
  'Lead import & pipeline configuration',
  'Google Calendar two-way sync',
  'AXIS Meet video conferencing activation',
  'Social Media AI scheduling & publishing',
  'HR suite & Recruitment ATS onboarding',
  'Email & SMS inbox integration',
  'Live Zoom session with your specialist',
  '30 days of follow-up support',
];

export default function WhiteGloveSetupTiers() {
  const [selectedPlanKey, setSelectedPlanKey] = useState('growth');
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [requesting, setRequesting] = useState(false);

  const selectedPlan = PLANS.find(p => p.key === selectedPlanKey) || PLANS[1];
  const breakdown = getSetupFeeBreakdown(selectedPlan.price);

  const handleBookNow = () => {
    setShowConfirmModal(true);
  };

  const handleConfirm = async () => {
    setRequesting(true);
    try {
      const user = await base44.auth.me();
      const userName = user.full_name || user.email;

      // Create a Converge Hosted Payment session for the $2,000 setup fee
      const response = await base44.functions.invoke('convergeSetupFee', {
        email: user.email,
        fullName: userName,
        planKey: selectedPlan.key,
        amount: breakdown.total,
      });
      const data = response.data || {};

      if (data.processor === 'converge' && data.paymentHtml) {
        // Redirect to Converge's secure hosted payment page
        document.open();
        document.write(data.paymentHtml);
        document.close();
        return;
      }

      // Fallback: send email notification if Converge is unavailable
      const adminBody = `New White Glove Setup request (payment processor pending):\n\n  User: ${userName}\n  Email: ${user.email}\n  Plan: ${selectedPlan.label} ($${selectedPlan.price}/mo)\n  Total Due Today: $${breakdown.total.toFixed(2)}\n\nPlease reach out within 24 hours to collect payment and schedule the session.`;
      await base44.integrations.Core.SendEmail({
        to: 'hello@axisbusiness.com',
        subject: `🆕 White Glove Setup Request from ${userName} — $${breakdown.total}`,
        body: adminBody,
      });

      toast.info('Our team will contact you within 24 hours to complete payment and schedule your setup session.');
      setShowConfirmModal(false);
    } catch (e) {
      toast.error('Could not process payment. Please try again or contact support.');
    }
    setRequesting(false);
  };

  return (
    <>
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Badge className="bg-yellow-500/15 text-yellow-400 border-yellow-500/30">⚡ White Glove Setup</Badge>
        </div>
        <h2 className="text-2xl font-black">Let our team set everything up for you</h2>
        <p className="text-muted-foreground mt-1 text-sm">
          Skip the DIY. Our specialists configure your entire system live — from core calling to full deployment. One flat setup fee of ${SETUP_FEE_TOTAL} includes your first month's subscription.
        </p>

        {/* Plan selector */}
        <div className="mt-5">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Select your plan — setup fee adjusts to keep total at ${SETUP_FEE_TOTAL}</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {PLANS.map(plan => (
              <button
                key={plan.key}
                onClick={() => setSelectedPlanKey(plan.key)}
                className={`text-left rounded-lg border-2 p-3 transition-all ${
                  selectedPlanKey === plan.key
                    ? 'border-primary bg-primary/5 ring-1 ring-primary/20'
                    : 'border-border hover:border-primary/40'
                }`}
              >
                <p className="font-bold text-sm">{plan.label}</p>
                <p className="text-lg font-black text-primary">${plan.price}<span className="text-xs font-normal text-muted-foreground">/mo</span></p>
              </button>
            ))}
          </div>
        </div>

        {/* Setup card */}
        <Card className="mt-4 border-primary/40 shadow-lg shadow-primary/10">
          <CardContent className="p-5">
            <div className="flex items-start gap-3">
              <div className="inline-flex items-center justify-center w-10 h-10 rounded-lg bg-primary/15 text-primary shrink-0">
                <Rocket className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-lg">Complete White Glove Setup</h3>
                <p className="text-xs text-muted-foreground mt-1">Everything activated end-to-end by an AXIS specialist.</p>
              </div>
              <Badge className="bg-primary/15 text-primary border-primary/30 shrink-0">Most Popular</Badge>
            </div>

            {/* Price breakdown */}
            <div className="mt-4 rounded-xl border border-border bg-background/50 p-4 space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{selectedPlan.label} — First Month</span>
                <span className="font-semibold">${breakdown.firstMonth.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">One-time Setup Fee</span>
                <span className="font-semibold">${breakdown.setupFee.toFixed(2)}</span>
              </div>
              <div className="border-t border-border pt-2 flex items-center justify-between">
                <span className="font-bold">Total Due Today</span>
                <span className="text-3xl font-black text-primary">${breakdown.total.toFixed(0)}</span>
              </div>
              <p className="text-xs text-muted-foreground text-center pt-1">
                Includes first month of the {selectedPlan.label} plan. Recurring billing of ${selectedPlan.price}/mo starts month 2.
              </p>
            </div>

            <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SETUP_DELIVERABLES.map((item, i) => (
                <li key={i} className="flex items-start gap-2 text-sm">
                  <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>

            <Button className="w-full mt-5 font-bold gap-2" onClick={handleBookNow}>
              <Sparkles className="w-4 h-4" /> Book Setup — ${SETUP_FEE_TOTAL} Total
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Confirmation Modal */}
      <Dialog open={showConfirmModal} onOpenChange={(o) => { if (!requesting) setShowConfirmModal(o); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold flex items-center gap-2">
              Confirm White Glove Setup
            </DialogTitle>
            <DialogDescription className="text-sm">
              Review the details below. On confirm we'll email you and our team next steps.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <div className="rounded-lg border bg-muted/40 px-4 py-3 space-y-1.5">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">{selectedPlan.label} — First Month</span>
                <span className="font-semibold">${breakdown.firstMonth.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">One-time Setup Fee</span>
                <span className="font-semibold">${breakdown.setupFee.toFixed(2)}</span>
              </div>
              <div className="border-t border-border pt-1.5 flex items-center justify-between">
                <span className="font-bold">Total Due Today</span>
                <span className="text-2xl font-black text-primary">${breakdown.total.toFixed(0)}</span>
              </div>
            </div>

            <div className="max-h-48 overflow-y-auto rounded-lg border p-4 bg-card">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">What's included</p>
              <ul className="space-y-2">
                {SETUP_DELIVERABLES.map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowConfirmModal(false)} disabled={requesting}>
              Cancel
            </Button>
            <Button onClick={handleConfirm} disabled={requesting} className="gap-2">
              {requesting && <Loader2 className="w-4 h-4 animate-spin" />}
              {requesting ? 'Sending...' : 'Request This Package'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}