import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Star, Check, ArrowRight, Play, Image as ImageIcon, Calendar, Mail, Phone } from 'lucide-react';

export default function BlockRenderer({ block, editable, onEdit, onLeadSubmit }) {
  const wrap = editable ? 'cursor-pointer hover:ring-2 hover:ring-primary/40 rounded-lg transition-all' : '';
  const handleClick = editable && onEdit ? () => onEdit(block) : undefined;

  switch (block.type) {
    case 'hero':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="relative overflow-hidden rounded-xl bg-gradient-to-br from-primary/20 via-card to-primary/5 p-8 md:p-12 text-center">
            {block.image_url && <img src={block.image_url} alt="" className="absolute inset-0 w-full h-full object-cover opacity-30" />}
            <div className="relative">
              <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-3">{block.title || 'Your Headline'}</h1>
              <p className="text-lg text-muted-foreground mb-6 max-w-2xl mx-auto">{block.subtitle || ''}</p>
              {block.cta_text && <Button size="lg">{block.cta_text}</Button>}
            </div>
          </div>
        </div>
      );

    case 'features':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="py-6">
            {block.title && <h2 className="text-2xl font-bold text-center mb-6">{block.title}</h2>}
            <div className="grid md:grid-cols-3 gap-4">
              {(block.items || []).map((f, i) => (
                <Card key={i} className="p-5">
                  {f.icon && <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3"><Check className="w-5 h-5 text-primary" /></div>}
                  <h3 className="font-semibold mb-1">{f.title || `Feature ${i + 1}`}</h3>
                  <p className="text-sm text-muted-foreground">{f.description || ''}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      );

    case 'testimonials':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="py-6">
            {block.title && <h2 className="text-2xl font-bold text-center mb-6">{block.title}</h2>}
            <div className="grid md:grid-cols-2 gap-4">
              {(block.items || []).map((t, i) => (
                <Card key={i} className="p-5">
                  <div className="flex gap-1 mb-2">{[1,2,3,4,5].map(s => <Star key={s} className={`w-4 h-4 ${s <= (t.rating || 5) ? 'text-amber-400 fill-amber-400' : 'text-muted'}`} />)}</div>
                  <p className="text-sm mb-3 italic">"{t.quote || ''}"</p>
                  <p className="text-xs font-semibold">— {t.author || 'Anonymous'}{t.role && <span className="text-muted-foreground font-normal">, {t.role}</span>}</p>
                </Card>
              ))}
            </div>
          </div>
        </div>
      );

    case 'cta':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="rounded-xl bg-gradient-to-r from-primary to-primary/80 p-8 text-center">
            <h2 className="text-2xl font-bold text-primary-foreground mb-2">{block.title || 'Ready to Get Started?'}</h2>
            {block.subtitle && <p className="text-primary-foreground/80 mb-4">{block.subtitle}</p>}
            <Button variant="secondary" size="lg">{block.button_text || 'Get Started'}</Button>
          </div>
        </div>
      );

    case 'pricing':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="py-6">
            {block.title && <h2 className="text-2xl font-bold text-center mb-6">{block.title}</h2>}
            <div className="grid md:grid-cols-3 gap-4">
              {(block.plans || []).map((p, i) => (
                <Card key={i} className={`p-6 ${p.featured ? 'border-primary ring-2 ring-primary/30' : ''}`}>
                  {p.featured && <span className="text-xs font-bold text-primary uppercase tracking-wide">Most Popular</span>}
                  <h3 className="font-bold text-lg">{p.name || `Plan ${i + 1}`}</h3>
                  <p className="text-3xl font-bold my-2">${p.price || 0}<span className="text-sm text-muted-foreground font-normal">/mo</span></p>
                  <ul className="text-sm space-y-1.5 mb-4">
                    {(p.features || []).map((f, j) => <li key={j} className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" />{f}</li>)}
                  </ul>
                  <Button variant={p.featured ? 'default' : 'outline'} className="w-full">{p.button_text || 'Choose'}</Button>
                </Card>
              ))}
            </div>
          </div>
        </div>
      );

    case 'lead_form':
      return (
        <LeadFormBlock block={block} wrap={wrap} handleClick={handleClick} onLeadSubmit={onLeadSubmit} />
      );

    case 'video':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="py-6">
            {block.title && <h2 className="text-2xl font-bold text-center mb-4">{block.title}</h2>}
            {block.url ? (
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video max-w-3xl mx-auto">
                <video src={block.url} controls className="w-full h-full" />
              </div>
            ) : (
              <div className="rounded-xl bg-muted aspect-video max-w-3xl mx-auto flex items-center justify-center"><Play className="w-12 h-12 text-muted-foreground" /></div>
            )}
          </div>
        </div>
      );

    case 'gallery':
      return (
        <div className={wrap} onClick={handleClick}>
          <div className="py-6">
            {block.title && <h2 className="text-2xl font-bold text-center mb-4">{block.title}</h2>}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {(block.images || []).map((img, i) => (
                <div key={i} className="aspect-square rounded-lg overflow-hidden bg-muted">
                  {img.url ? <img src={img.url} alt={img.alt || ''} className="w-full h-full object-cover" /> : <ImageIcon className="w-8 h-8 text-muted-foreground m-auto mt-[45%]" />}
                </div>
              ))}
            </div>
          </div>
        </div>
      );

    case 'booking':
      return (
        <div className={wrap} onClick={handleClick}>
          <Card className="p-6 text-center max-w-2xl mx-auto">
            <Calendar className="w-8 h-8 text-primary mx-auto mb-2" />
            <h2 className="text-2xl font-bold mb-2">{block.title || 'Book an Appointment'}</h2>
            <p className="text-sm text-muted-foreground mb-4">{block.subtitle || 'Schedule a time that works for you'}</p>
            <Button><Calendar className="w-4 h-4 mr-2" />Book Now</Button>
          </Card>
        </div>
      );

    case 'contact':
      return (
        <div className={wrap} onClick={handleClick}>
          <Card className="p-6 text-center max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">{block.title || 'Contact Us'}</h2>
            <div className="flex items-center justify-center gap-6 text-sm">
              {block.email && <a href={`mailto:${block.email}`} className="flex items-center gap-2 hover:text-primary"><Mail className="w-4 h-4" />{block.email}</a>}
              {block.phone && <a href={`tel:${block.phone}`} className="flex items-center gap-2 hover:text-primary"><Phone className="w-4 h-4" />{block.phone}</a>}
            </div>
          </Card>
        </div>
      );

    default:
      return <div className="p-4 text-sm text-muted-foreground border border-dashed rounded-lg">Unknown block type: {block.type}</div>;
  }
}

function LeadFormBlock({ block, wrap, handleClick, onLeadSubmit }) {
  const [form, setForm] = useState({ name: '', email: '', phone: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (onLeadSubmit) onLeadSubmit(form);
    setSubmitted(true);
  };

  return (
    <div className={wrap} onClick={handleClick}>
      <Card className="p-6 max-w-xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-2">{block.title || 'Get in Touch'}</h2>
        <p className="text-sm text-muted-foreground text-center mb-4">{block.subtitle || 'Fill out the form below and we\'ll be in touch'}</p>
        {submitted ? (
          <div className="text-center py-6"><Check className="w-10 h-10 text-emerald-500 mx-auto mb-2" /><p className="font-semibold">Thank you! We'll be in touch soon.</p></div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3" onClick={e => e.stopPropagation()}>
            <Input placeholder="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
            <Input type="email" placeholder="Email Address" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} required />
            <Input placeholder="Phone (optional)" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
            <Button type="submit" className="w-full">{block.button_text || 'Submit'}<ArrowRight className="w-4 h-4 ml-2" /></Button>
          </form>
        )}
      </Card>
    </div>
  );
}