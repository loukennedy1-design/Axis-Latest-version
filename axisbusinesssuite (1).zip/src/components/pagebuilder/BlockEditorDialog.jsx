import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Trash2 } from 'lucide-react';

export default function BlockEditorDialog({ block, open, onClose, onSave }) {
  const [form, setForm] = useState(block || {});

  useEffect(() => { setForm(block || {}); }, [block]);

  if (!form) return null;
  const update = (key, val) => setForm({ ...form, [key]: val });
  const updateArray = (key, idx, field, val) => {
    const arr = [...(form[key] || [])];
    arr[idx] = { ...arr[idx], [field]: val };
    setForm({ ...form, [key]: arr });
  };
  const addArrayItem = (key, template) => setForm({ ...form, [key]: [...(form[key] || []), template] });
  const removeArrayItem = (key, idx) => setForm({ ...form, [key]: (form[key] || []).filter((_, i) => i !== idx) });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader><DialogTitle className="capitalize">Edit {form.type?.replace(/_/g, ' ')} Block</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {form.title !== undefined && <div><Label>Title</Label><Input value={form.title || ''} onChange={e => update('title', e.target.value)} /></div>}
          {form.subtitle !== undefined && <div><Label>Subtitle</Label><Input value={form.subtitle || ''} onChange={e => update('subtitle', e.target.value)} /></div>}
          {form.cta_text !== undefined && <div><Label>Button Text</Label><Input value={form.cta_text || ''} onChange={e => update('cta_text', e.target.value)} /></div>}
          {form.button_text !== undefined && <div><Label>Button Text</Label><Input value={form.button_text || ''} onChange={e => update('button_text', e.target.value)} /></div>}
          {form.image_url !== undefined && <div><Label>Image URL</Label><Input value={form.image_url || ''} onChange={e => update('image_url', e.target.value)} placeholder="https://..." /></div>}
          {form.url !== undefined && <div><Label>Video URL</Label><Input value={form.url || ''} onChange={e => update('url', e.target.value)} placeholder="https://..." /></div>}
          {form.email !== undefined && <div><Label>Email</Label><Input value={form.email || ''} onChange={e => update('email', e.target.value)} /></div>}
          {form.phone !== undefined && <div><Label>Phone</Label><Input value={form.phone || ''} onChange={e => update('phone', e.target.value)} /></div>}

          {/* Array editors */}
          {form.items && form.type === 'features' && (
            <div className="border-t pt-3 space-y-2">
              <Label>Features</Label>
              {form.items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <div className="flex-1 space-y-1">
                    <Input value={item.title || ''} onChange={e => updateArray('items', idx, 'title', e.target.value)} placeholder="Feature title" className="h-8" />
                    <Input value={item.description || ''} onChange={e => updateArray('items', idx, 'description', e.target.value)} placeholder="Description" className="h-8" />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeArrayItem('items', idx)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => addArrayItem('items', { title: '', description: '' })}><Plus className="w-3.5 h-3.5 mr-1" />Add Feature</Button>
            </div>
          )}

          {form.items && form.type === 'testimonials' && (
            <div className="border-t pt-3 space-y-2">
              <Label>Testimonials</Label>
              {form.items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <div className="flex-1 space-y-1">
                    <Textarea value={item.quote || ''} onChange={e => updateArray('items', idx, 'quote', e.target.value)} placeholder="Quote" className="h-16 text-sm" />
                    <Input value={item.author || ''} onChange={e => updateArray('items', idx, 'author', e.target.value)} placeholder="Author" className="h-8" />
                    <Input value={item.role || ''} onChange={e => updateArray('items', idx, 'role', e.target.value)} placeholder="Role" className="h-8" />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeArrayItem('items', idx)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => addArrayItem('items', { quote: '', author: '', role: '', rating: 5 })}><Plus className="w-3.5 h-3.5 mr-1" />Add Testimonial</Button>
            </div>
          )}

          {form.plans && form.type === 'pricing' && (
            <div className="border-t pt-3 space-y-2">
              <Label>Pricing Plans</Label>
              {form.plans.map((plan, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <div className="flex-1 space-y-1">
                    <Input value={plan.name || ''} onChange={e => updateArray('plans', idx, 'name', e.target.value)} placeholder="Plan name" className="h-8" />
                    <Input type="number" value={plan.price || 0} onChange={e => updateArray('plans', idx, 'price', Number(e.target.value))} placeholder="Price" className="h-8" />
                    <Textarea value={(plan.features || []).join('\n')} onChange={e => updateArray('plans', idx, 'features', e.target.value.split('\n'))} placeholder="One feature per line" className="h-20 text-sm" />
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => removeArrayItem('plans', idx)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => addArrayItem('plans', { name: '', price: 0, features: [], featured: false, button_text: 'Choose' })}><Plus className="w-3.5 h-3.5 mr-1" />Add Plan</Button>
            </div>
          )}

          {form.images && form.type === 'gallery' && (
            <div className="border-t pt-3 space-y-2">
              <Label>Gallery Images</Label>
              {form.images.map((img, idx) => (
                <div key={idx} className="flex gap-2 items-center">
                  <Input value={img.url || ''} onChange={e => updateArray('images', idx, 'url', e.target.value)} placeholder="Image URL" className="flex-1 h-8" />
                  <Button variant="ghost" size="icon" onClick={() => removeArrayItem('images', idx)}><Trash2 className="w-4 h-4 text-destructive" /></Button>
                </div>
              ))}
              <Button variant="outline" size="sm" onClick={() => addArrayItem('images', { url: '', alt: '' })}><Plus className="w-3.5 h-3.5 mr-1" />Add Image</Button>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onSave(form)}>Save Block</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}