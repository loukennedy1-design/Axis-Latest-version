import React from 'react';
import { Layout, Grid, Star, Megaphone, DollarSign, Mail, Play, Image as ImageIcon, Calendar, Phone, Plus } from 'lucide-react';

const blockTypes = [
  { type: 'hero', label: 'Hero', icon: Layout, desc: 'Headline + CTA' },
  { type: 'features', label: 'Features', icon: Grid, desc: '3-column features' },
  { type: 'testimonials', label: 'Testimonials', icon: Star, desc: 'Customer reviews' },
  { type: 'cta', label: 'Call to Action', icon: Megaphone, desc: 'Bold CTA banner' },
  { type: 'pricing', label: 'Pricing', icon: DollarSign, desc: 'Pricing plans' },
  { type: 'lead_form', label: 'Lead Capture', icon: Mail, desc: 'Email capture form' },
  { type: 'video', label: 'Video', icon: Play, desc: 'Embedded video' },
  { type: 'gallery', label: 'Image Gallery', icon: ImageIcon, desc: 'Photo grid' },
  { type: 'booking', label: 'Booking Widget', icon: Calendar, desc: 'Appointment booking' },
  { type: 'contact', label: 'Contact Form', icon: Phone, desc: 'Contact info' },
];

export const defaultBlockContent = {
  hero: { title: 'Your Headline Here', subtitle: 'A compelling subheadline that explains your value proposition.', cta_text: 'Get Started', image_url: '' },
  features: { title: 'Why Choose Us', items: [{ title: 'Feature One', description: 'Description of your first feature.' }, { title: 'Feature Two', description: 'Description of your second feature.' }, { title: 'Feature Three', description: 'Description of your third feature.' }] },
  testimonials: { title: 'What Our Customers Say', items: [{ quote: 'This product changed our business!', author: 'Jane Doe', role: 'CEO, Acme', rating: 5 }] },
  cta: { title: 'Ready to Get Started?', subtitle: 'Join thousands of happy customers today.', button_text: 'Sign Up Now' },
  pricing: { title: 'Simple, Transparent Pricing', plans: [{ name: 'Starter', price: 29, features: ['Up to 100 users', 'Email support', 'Basic analytics'], featured: false, button_text: 'Choose Starter' }, { name: 'Pro', price: 99, features: ['Unlimited users', 'Priority support', 'Advanced analytics'], featured: true, button_text: 'Choose Pro' }, { name: 'Enterprise', price: 299, features: ['Everything in Pro', 'Dedicated manager', 'Custom integrations'], featured: false, button_text: 'Contact Sales' }] },
  lead_form: { title: 'Get in Touch', subtitle: "Fill out the form below and we'll be in touch", button_text: 'Submit' },
  video: { title: 'See It in Action', url: '' },
  gallery: { title: 'Our Gallery', images: [{ url: '', alt: '' }] },
  booking: { title: 'Book an Appointment', subtitle: 'Schedule a time that works for you' },
  contact: { title: 'Contact Us', email: '', phone: '' },
};

export default function BlockPalette({ onAdd }) {
  return (
    <div className="space-y-2">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Add Block</p>
      <div className="grid grid-cols-2 gap-2">
        {blockTypes.map(bt => {
          const Icon = bt.icon;
          return (
            <button key={bt.type} onClick={() => onAdd(bt.type)} className="flex flex-col items-center gap-1 p-3 rounded-lg border border-border bg-card hover:border-primary hover:bg-primary/5 transition-all text-center">
              <Icon className="w-5 h-5 text-primary" />
              <span className="text-xs font-medium">{bt.label}</span>
              <span className="text-[10px] text-muted-foreground">{bt.desc}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}