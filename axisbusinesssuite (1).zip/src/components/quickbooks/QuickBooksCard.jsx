import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, Link2, Unlink, Settings as SettingsIcon } from 'lucide-react';
import { toast } from 'sonner';
import QuickBooksSyncPanel from './QuickBooksSyncPanel';

const QB_GREEN = '#2CA01C';

export default function QuickBooksCard() {
  const qc = useQueryClient();
  const [panelOpen, setPanelOpen] = useState(false);

  const { data: status, isLoading } = useQuery({
    queryKey: ['quickbooks-status'],
    queryFn: async () => (await base44.functions.invoke('quickbooksSync', { action: 'get_status' })).data,
    refetchOnWindowFocus: true,
  });

  const syncMut = useMutation({
    mutationFn: () => base44.functions.invoke('quickbooksSync', { action: 'sync' }),
    onSuccess: (r) => {
      const total = r.data?.total_synced || 0;
      toast.success(`QuickBooks synced ${total} records`);
      qc.invalidateQueries(['quickbooks-status']);
    },
    onError: (e) => toast.error(`Sync failed: ${e.response?.data?.error || e.message}`),
  });

  const connect = async () => {
    try {
      const res = await base44.functions.invoke('oauthAuthorize', { integration_type: 'quickbooks' });
      if (res.data?.auth_url) {
        const popup = window.open(res.data.auth_url, '_blank', 'width=600,height=700');
        toast.success('Complete QuickBooks authorization in the popup');
        if (popup) {
          const t = setInterval(() => {
            if (popup.closed) {
              clearInterval(t);
              qc.invalidateQueries(['quickbooks-status']);
              toast.success('QuickBooks connected');
            }
          }, 1000);
        }
      } else if (res.data?.setup_required) {
        toast.error(res.data.message);
        setPanelOpen(true);
      }
    } catch (e) {
      toast.error(`Connection error: ${e.message}`);
    }
  };

  const disconnect = async () => {
    try {
      await base44.functions.invoke('quickbooksSync', { action: 'disconnect' });
      toast.success('QuickBooks disconnected');
      qc.invalidateQueries(['quickbooks-status']);
    } catch (e) {
      toast.error(`Disconnect failed: ${e.message}`);
    }
  };

  const connected = !!status?.connected;
  const lastSynced = status?.last_synced_at ? new Date(status.last_synced_at).toLocaleString() : 'Never';

  return (
    <>
      <Card
        className="border-2 transition-shadow"
        style={{ borderColor: connected ? `${QB_GREEN}40` : undefined }}
      >
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${QB_GREEN}15` }}
              >
                <span className="text-xl font-bold" style={{ color: QB_GREEN }}>QB</span>
              </div>
              <div>
                <CardTitle className="text-lg">QuickBooks Online</CardTitle>
                <CardDescription className="text-xs">Financial, contacts & payroll sync</CardDescription>
              </div>
            </div>
            {connected ? (
              <Badge style={{ backgroundColor: `${QB_GREEN}20`, color: QB_GREEN }}>Connected</Badge>
            ) : (
              <Badge variant="outline">Not Connected</Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {isLoading ? (
            <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
          ) : (
            <>
              {connected && (
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Account</span>
                    <span className="font-medium truncate max-w-[150px]">{status.identity_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Sync</span>
                    <span>{lastSynced}</span>
                  </div>
                </div>
              )}
              <div className="flex gap-2">
                {connected ? (
                  <>
                    <Button size="sm" className="flex-1" disabled={syncMut.isPending} onClick={() => syncMut.mutate()}>
                      {syncMut.isPending ? (
                        <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                      ) : (
                        <RefreshCw className="w-3 h-3 mr-1" />
                      )}
                      Sync Now
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setPanelOpen(true)}>
                      <SettingsIcon className="w-3 h-3" />
                    </Button>
                    <Button size="sm" variant="outline" onClick={disconnect}>
                      <Unlink className="w-3 h-3" />
                    </Button>
                  </>
                ) : (
                  <>
                    <Button size="sm" className="flex-1" style={{ backgroundColor: QB_GREEN }} onClick={connect}>
                      <Link2 className="w-3 h-3 mr-1" /> Connect
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setPanelOpen(true)}>
                      <SettingsIcon className="w-3 h-3" />
                    </Button>
                  </>
                )}
              </div>
            </>
          )}
        </CardContent>
      </Card>
      <QuickBooksSyncPanel
        open={panelOpen}
        onOpenChange={setPanelOpen}
        onConnect={connect}
      />
    </>
  );
}