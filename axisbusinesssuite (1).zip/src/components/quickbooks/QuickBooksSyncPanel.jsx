import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, Link2, Save, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const QB_GREEN = '#2CA01C';

const DATA_TYPES = [
  { key: 'invoices', label: 'Invoices' },
  { key: 'bills', label: 'Bills' },
  { key: 'expenses', label: 'Expenses / Purchases' },
  { key: 'accounts', label: 'Chart of Accounts' },
  { key: 'customers', label: 'Customers → Leads' },
  { key: 'vendors', label: 'Vendors → Suppliers' },
  { key: 'employees', label: 'Employees → HR' },
];

export default function QuickBooksSyncPanel({ open, onOpenChange, onConnect }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [clientId, setClientId] = useState('');
  const [clientSecret, setClientSecret] = useState('');
  const [env, setEnv] = useState('production');
  const [selectedTypes, setSelectedTypes] = useState(DATA_TYPES.map((d) => d.key));

  const settingsKey = user?.email ? `global_${user.email}` : '';

  const { data: settings } = useQuery({
    queryKey: ['qb-settings', settingsKey],
    queryFn: async () => (await base44.entities.SystemSettings.filter({ key: settingsKey }))[0] || null,
    enabled: !!settingsKey && open,
  });

  const { data: status } = useQuery({
    queryKey: ['quickbooks-status'],
    queryFn: async () => (await base44.functions.invoke('quickbooksSync', { action: 'get_status' })).data,
    enabled: open,
  });

  useEffect(() => {
    if (settings) {
      setClientId(settings.quickbooks_client_id || '');
      setClientSecret(settings.quickbooks_client_secret || '');
      setEnv(settings.quickbooks_environment || 'production');
    }
    if (status?.selected_data_types) setSelectedTypes(status.selected_data_types);
  }, [settings, status]);

  const saveSettings = useMutation({
    mutationFn: async () => {
      if (settings?.id) {
        await base44.entities.SystemSettings.update(settings.id, {
          quickbooks_client_id: clientId,
          quickbooks_client_secret: clientSecret,
          quickbooks_environment: env,
        });
      } else {
        await base44.entities.SystemSettings.create({
          key: settingsKey,
          quickbooks_client_id: clientId,
          quickbooks_client_secret: clientSecret,
          quickbooks_environment: env,
          owner: user.email,
        });
      }
    },
    onSuccess: () => {
      toast.success('QuickBooks credentials saved');
      qc.invalidateQueries(['qb-settings', settingsKey]);
    },
    onError: (e) => toast.error(`Save failed: ${e.message}`),
  });

  const updateSettings = useMutation({
    mutationFn: (data) => base44.functions.invoke('quickbooksSync', { action: 'update_settings', ...data }),
    onSuccess: () => qc.invalidateQueries(['quickbooks-status']),
  });

  const syncNow = useMutation({
    mutationFn: () => base44.functions.invoke('quickbooksSync', { action: 'sync', data_types: selectedTypes }),
    onSuccess: (r) => {
      const total = r.data?.total_synced || 0;
      const counts = r.data?.counts || {};
      const breakdown = Object.entries(counts).filter(([, v]) => v > 0).map(([k, v]) => `${v} ${k}`).join(', ');
      toast.success(`Synced ${total} records${breakdown ? ` (${breakdown})` : ''}`);
      qc.invalidateQueries(['quickbooks-status']);
    },
    onError: (e) => toast.error(`Sync failed: ${e.response?.data?.error || e.message}`),
  });

  const toggleType = (key) =>
    setSelectedTypes((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));

  const hasCreds = !!(settings?.quickbooks_client_id && settings?.quickbooks_client_secret);
  const connected = !!status?.connected;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="font-bold" style={{ color: QB_GREEN }}>QuickBooks Online</span>
            {connected && (
              <Badge style={{ backgroundColor: `${QB_GREEN}20`, color: QB_GREEN }}>Connected</Badge>
            )}
          </DialogTitle>
          <DialogDescription>
            Import financial, contact, and payroll data from QuickBooks into AXIS.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5">
          {/* Credentials section */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold">Step 1 — QuickBooks OAuth Credentials</h4>
            {!hasCreds && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs">
                <AlertCircle className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                <span>
                  Create an Intuit app at{' '}
                  <a href="https://developer.intuit.com" target="_blank" rel="noreferrer" className="underline">developer.intuit.com</a>,{' '}
                  add <code className="bg-muted px-1 rounded">{window.location.origin}/api/oauth/callback</code> as a
                  redirect URI, then paste your Client ID and Secret here.
                </span>
              </div>
            )}
            <div className="grid gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Client ID</Label>
                <Input value={clientId} onChange={(e) => setClientId(e.target.value)} placeholder="ABCD1234..." />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Client Secret</Label>
                <Input type="password" value={clientSecret} onChange={(e) => setClientSecret(e.target.value)} placeholder="••••••••" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Environment</Label>
                <Select value={env} onValueChange={setEnv}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="production">Production</SelectItem>
                    <SelectItem value="sandbox">Sandbox</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={() => saveSettings.mutate()}
              disabled={saveSettings.isPending || (!clientId && !clientSecret)}
            >
              {saveSettings.isPending ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Save className="w-3 h-3 mr-1" />}
              Save Credentials
            </Button>
          </div>

          {/* Connection + sync section */}
          {hasCreds && (
            <div className="space-y-4 border-t pt-4">
              <h4 className="text-sm font-semibold">Step 2 — Connect & Import</h4>
              {!connected ? (
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Credentials saved. Connect your QuickBooks company to start importing.
                  </p>
                  <Button onClick={onConnect} style={{ backgroundColor: QB_GREEN }}>
                    <Link2 className="w-4 h-4 mr-2" /> Connect to QuickBooks
                  </Button>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between text-sm">
                    <div>
                      <p className="font-medium">{status?.identity_name || 'QuickBooks Company'}</p>
                      <p className="text-xs text-muted-foreground">
                        Last synced: {status?.last_synced_at ? new Date(status.last_synced_at).toLocaleString() : 'Never'}
                      </p>
                    </div>
                    <Button size="sm" onClick={() => syncNow.mutate()} disabled={syncNow.isPending}>
                      {syncNow.isPending ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <RefreshCw className="w-3 h-3 mr-1" />}
                      Sync Now
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-xs font-semibold">Data to Import</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {DATA_TYPES.map((d) => (
                        <label key={d.key} className="flex items-center gap-2 text-sm cursor-pointer">
                          <Checkbox checked={selectedTypes.includes(d.key)} onCheckedChange={() => toggleType(d.key)} />
                          {d.label}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between rounded-lg border p-3">
                    <div>
                      <p className="text-sm font-medium">Daily Auto-Sync</p>
                      <p className="text-xs text-muted-foreground">Automatically pull new data every day</p>
                    </div>
                    <Switch
                      checked={!!status?.autosync}
                      onCheckedChange={(v) => updateSettings.mutate({ autosync: v, data_types: selectedTypes })}
                    />
                  </div>

                  {status?.logs?.length > 0 && (
                    <div className="space-y-2">
                      <Label className="text-xs font-semibold">Recent Syncs</Label>
                      <div className="space-y-1 max-h-40 overflow-y-auto">
                        {status.logs.map((l) => (
                          <div key={l.id} className="flex items-center justify-between text-xs border rounded px-2 py-1.5">
                            <span className="text-muted-foreground">
                              {l.completed_at ? new Date(l.completed_at).toLocaleString() : '—'}
                            </span>
                            <span className="font-medium">{l.records_synced || 0} records</span>
                            <Badge
                              variant={l.sync_status === 'completed' ? 'default' : 'destructive'}
                              className="text-xs"
                            >
                              {l.sync_status}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}