import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Loader2, Award, Trophy, Users, GraduationCap, CheckCircle2, Circle,
  RefreshCw, Search, ChevronDown, ChevronRight, Download, ShieldCheck,
  Briefcase, Mail, Clock, BookCheck,
} from 'lucide-react';

const pretty = (s) => String(s || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

function verificationId(employeeId, dateEarned) {
  const tail = (employeeId || 'XXXX').slice(-6).toUpperCase();
  const stamp = dateEarned ? new Date(dateEarned).toISOString().slice(0, 10).replace(/-/g, '') : 'PENDING';
  return `AXIS-CERT-${tail}-${stamp}`;
}

function handlePrint(cert) {
  const win = window.open('', '_blank');
  if (!win) return;
  win.document.write(`
    <html><head><title>${cert.certName}</title>
    <style>
      body { font-family: 'Inter', Arial, sans-serif; background:#0a0a0a; color:#fff; display:flex; justify-content:center; align-items:center; min-height:100vh; margin:0; }
      .cert { width:800px; border:3px solid hsl(0,100%,50%); border-radius:20px; padding:60px; text-align:center; background:linear-gradient(135deg,#1a1a1a,#0a0a0a); }
      h1 { font-size:36px; color:hsl(0,100%,50%); margin-bottom:10px; }
      h2 { font-size:24px; margin-bottom:30px; }
      .name { font-size:28px; font-weight:bold; margin:20px 0; }
      .meta { color:#999; font-size:14px; margin-top:30px; }
      .badge { font-size:64px; }
    </style></head><body>
      <div class="cert">
        <div class="badge">🏆</div>
        <h1>Certificate of Completion</h1>
        <p>This certifies that</p>
        <div class="name">${cert.staffName}</div>
        <p>has successfully completed all required training modules and is hereby recognized as a</p>
        <h2>${cert.certName}</h2>
        <div class="meta">
          Verification ID: ${cert.verificationId}<br>
          Date Earned: ${new Date(cert.dateEarned).toLocaleDateString()}<br>
          AXIS Workforce Intelligence · Trinity
        </div>
      </div>
    </body></html>`);
  win.document.close();
  setTimeout(() => win.print(), 500);
}

export default function StaffCertificationsLedger({ user }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState({});

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', { action: 'get_team_progress' });
      if (res.data?.success) setRows(res.data.rows || []);
      else setError(res.data?.error || 'Failed to load staff certifications');
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) =>
      [r.name, r.email, r.path_name, r.position, r.department, pretty(r.position), pretty(r.department)]
        .some((v) => String(v || '').toLowerCase().includes(q)));
  }, [rows, query]);

  const stats = useMemo(() => {
    const total = rows.length;
    const certified = rows.filter((r) => r.completion_pct === 100 && !r.refresher_required && r.capstone_passed).length;
    const inProgress = rows.filter((r) => r.completed > 0 && r.completion_pct < 100).length;
    const modulesCompleted = rows.reduce((s, r) => s + (r.completed || 0), 0);
    return { total, certified, inProgress, modulesCompleted };
  }, [rows]);

  if (loading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  if (error) return <Card><CardContent className="py-8 text-center"><p className="text-sm text-destructive">{error}</p><Button variant="outline" size="sm" className="mt-3" onClick={load}>Retry</Button></CardContent></Card>;
  if (rows.length === 0) return null;

  const certifiedRows = filtered.filter((r) => r.completion_pct === 100 && !r.refresher_required && r.capstone_passed);
  const pendingRows = filtered.filter((r) => !(r.completion_pct === 100 && !r.refresher_required && r.capstone_passed));

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2 pt-2">
        <ShieldCheck className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-bold tracking-tight">Staff Certifications</h3>
        <span className="text-xs text-muted-foreground">· {user?.full_name || user?.email} workspace</span>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><Users className="w-3 h-3" /> Staff in Program</p>
          <p className="text-xl font-bold">{stats.total}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><Trophy className="w-3 h-3" /> Certified</p>
          <p className="text-xl font-bold text-emerald-500">{stats.certified}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><GraduationCap className="w-3 h-3" /> In Progress</p>
          <p className="text-xl font-bold text-amber-500">{stats.inProgress}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><BookCheck className="w-3 h-3" /> Modules Completed</p>
          <p className="text-xl font-bold text-primary">{stats.modulesCompleted}</p>
        </CardContent></Card>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
        <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search staff by name, role, or path…" className="pl-9 h-9" />
      </div>

      {/* Earned credentials */}
      {certifiedRows.length > 0 && (
        <div className="space-y-3">
          <h4 className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Earned Credentials</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {certifiedRows.map((r) => {
              const dateEarned = r.last_active || new Date().toISOString();
              const cert = {
                staffName: r.name,
                certName: r.path_name,
                verificationId: verificationId(r.employee_id, dateEarned),
                dateEarned,
              };
              const isOpen = !!expanded[r.employee_id];
              return (
                <Card key={r.employee_id} className="border-primary/30 bg-gradient-to-br from-primary/10 via-card to-purple-500/5">
                  <CardContent className="p-5">
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
                        <Trophy className="w-6 h-6 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 mb-1.5"><CheckCircle2 className="w-3 h-3 mr-1" /> Certified</Badge>
                        <p className="font-bold text-sm">{r.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{r.path_name}</p>
                        <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                          {r.position && <span className="flex items-center gap-0.5"><Briefcase className="w-2.5 h-2.5" /> {pretty(r.position)}</span>}
                          {r.email && <span className="flex items-center gap-0.5"><Mail className="w-2.5 h-2.5" /> {r.email}</span>}
                        </div>
                        <p className="text-[10px] text-muted-foreground font-mono mt-1.5">ID: {cert.verificationId}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => handlePrint(cert)}>
                            <Download className="w-3 h-3 mr-1" /> Print
                          </Button>
                          <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => setExpanded((m) => ({ ...m, [r.employee_id]: !m[r.employee_id] }))}>
                            {isOpen ? <ChevronDown className="w-3 h-3 mr-1" /> : <ChevronRight className="w-3 h-3 mr-1" />} Modules
                          </Button>
                        </div>
                      </div>
                    </div>
                    {isOpen && r.modules && (
                      <div className="mt-3 pt-3 border-t border-border space-y-1.5">
                        {r.modules.map((m, i) => (
                          <div key={m.id || i} className="flex items-center gap-2 text-xs">
                            {m.refresher_required ? <RefreshCw className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                              : m.completed ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                              : <Circle className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />}
                            <span className="flex-1 truncate">{i + 1}. {m.title}</span>
                            {m.quiz_score !== null && m.quiz_score !== undefined && <span className="text-[10px] text-muted-foreground font-mono">{m.quiz_score}/5</span>}
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* In progress / not started */}
      {pendingRows.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">In Progress</h4>
          {pendingRows.map((r) => {
            const isOpen = !!expanded[r.employee_id];
            return (
              <Card key={r.employee_id}>
                <CardContent className="pt-4">
                  <div className="flex items-center gap-3 cursor-pointer" onClick={() => setExpanded((m) => ({ ...m, [r.employee_id]: !m[r.employee_id] }))}>
                    <div className="w-10 h-10 rounded-full bg-muted/60 flex items-center justify-center shrink-0">
                      <Award className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm">{r.name}</p>
                      <p className="text-xs text-muted-foreground truncate">{r.path_name}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs font-bold text-primary">{r.completion_pct}%</p>
                      <p className="text-[10px] text-muted-foreground">{r.completed}/{r.total_modules} modules</p>
                    </div>
                    {isOpen ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                  </div>
                  <Progress value={r.completion_pct} className="h-1.5 mt-3" />
                  {isOpen && r.modules && (
                    <div className="mt-3 pt-3 border-t border-border space-y-1.5">
                      {r.modules.map((m, i) => (
                        <div key={m.id || i} className="flex items-center gap-2 text-xs">
                          {m.refresher_required ? <RefreshCw className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                            : m.completed ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            : <Circle className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />}
                          <span className={`flex-1 truncate ${m.completed ? '' : 'text-muted-foreground'}`}>{i + 1}. {m.title}</span>
                          {m.refresher_required && <Badge variant="outline" className="text-[9px] border-rose-500/30 text-rose-500">Retake</Badge>}
                          {m.quiz_score !== null && m.quiz_score !== undefined && <span className="text-[10px] text-muted-foreground font-mono">{m.quiz_score}/5</span>}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {filtered.length === 0 && (
        <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">No staff match “{query}”.</CardContent></Card>
      )}
    </div>
  );
}