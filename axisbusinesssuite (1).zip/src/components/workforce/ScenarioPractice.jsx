import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Target, CheckCircle2, XCircle, ArrowRight, Trophy } from 'lucide-react';

const PASS_THRESHOLD = 3;

export default function ScenarioPractice({ scenarios, onComplete, onProceed }) {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  if (!scenarios || scenarios.length === 0) {
    return (
      <div className="rounded-xl border border-border bg-muted/20 p-6 text-center">
        <p className="text-sm text-muted-foreground">No scenario practice available for this module.</p>
      </div>
    );
  }

  const s = scenarios[current];

  const select = (idx) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === s.answer) setScore((v) => v + 1);
  };

  const next = () => {
    if (current + 1 >= scenarios.length) {
      setDone(true);
      onComplete(score);
    } else {
      setCurrent((c) => c + 1);
      setSelected(null);
      setAnswered(false);
    }
  };

  if (done) {
    const passed = score >= PASS_THRESHOLD;
    return (
      <div className={`rounded-xl p-6 border text-center ${passed ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-amber-500/10 border-amber-500/20'}`}>
        <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-3">
          {passed ? <Trophy className="w-7 h-7 text-primary" /> : <Target className="w-7 h-7 text-amber-500" />}
        </div>
        <p className="font-bold text-lg">{passed ? 'Practice Complete!' : 'Keep Practicing'}</p>
        <p className="text-sm text-muted-foreground mt-1">You scored {score} out of {scenarios.length}</p>
        {!passed && <p className="text-sm mt-2 text-amber-500">You need {PASS_THRESHOLD}/{scenarios.length} correct to unlock the module test.</p>}
        <div className="flex gap-2 justify-center mt-4">
          <Button variant="outline" size="sm" onClick={() => { setCurrent(0); setSelected(null); setAnswered(false); setScore(0); setDone(false); }}>
            Retry Scenarios
          </Button>
          {passed && onProceed && (
            <Button size="sm" onClick={onProceed}>
              Take Module Test <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
          <Target className="w-3.5 h-3.5" /> Scenario {current + 1} of {scenarios.length}
        </p>
        <Progress value={(current / scenarios.length) * 100} className="w-24 h-2" />
      </div>

      <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
        <p className="text-sm font-medium leading-relaxed">{s.situation}</p>
      </div>

      <p className="text-xs font-semibold text-muted-foreground">What is the best first response?</p>

      <div className="space-y-2">
        {s.options.map((opt, idx) => {
          let style = 'border-border bg-card hover:bg-muted/40 cursor-pointer';
          if (answered) {
            if (idx === s.answer) style = 'border-emerald-500 bg-emerald-500/10';
            else if (idx === selected && idx !== s.answer) style = 'border-red-500 bg-red-500/10';
            else style = 'border-border bg-muted/20 opacity-50';
          }
          return (
            <button key={idx} onClick={() => select(idx)} className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${style}`}>
              <span className="font-medium mr-2">{['A', 'B', 'C', 'D'][idx]}.</span>{opt}
              {answered && idx === s.answer && <CheckCircle2 className="w-4 h-4 inline ml-2 text-emerald-500" />}
              {answered && idx === selected && idx !== s.answer && <XCircle className="w-4 h-4 inline ml-2 text-red-500" />}
            </button>
          );
        })}
      </div>

      {answered && (
        <div className="rounded-lg border border-border bg-muted/30 p-3">
          <p className="text-xs font-semibold mb-1">{selected === s.answer ? '✓ Correct' : '✗ Not quite'}</p>
          <p className="text-sm text-muted-foreground">{s.explanation}</p>
        </div>
      )}

      {answered && (
        <Button onClick={next} className="w-full">
          {current + 1 >= scenarios.length ? 'See Results' : 'Next Scenario'} <ArrowRight className="w-4 h-4 ml-1" />
        </Button>
      )}
    </div>
  );
}