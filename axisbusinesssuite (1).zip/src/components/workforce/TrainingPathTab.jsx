import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  CheckCircle2, Lock, ChevronRight, Clock, Loader2,
  GraduationCap, Sparkles, AlertCircle,
} from 'lucide-react';
import ProgressRing from '@/components/learning/ProgressRing';
import CapstoneAssessment from '@/components/workforce/CapstoneAssessment';
import { MODULE_TYPE_META } from '@/lib/workforceIndustries';

export default function TrainingPathTab({ user, userProgress, onOpenModule, onRefresh }) {
  const [employee, setEmployee] = useState(null);
  const [loading, setLoading] = useState(true);
  const [path, setPath] = useState(null);

  useEffect(() => {
    if (user?.email) loadEmployee();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.email]);

  const loadEmployee = async () => {
    setLoading(true);
    try {
      const records = await base44.entities.Employee.filter({ email: user.email }, '-created_date', 5);
      const emp = records?.[0];
      setEmployee(emp || null);
      if (emp?.training_path) {
        try { setPath(JSON.parse(emp.training_path)); } catch { setPath(null); }
      } else {
        setPath(null);
      }
    } catch {
      setEmployee(null);
      setPath(null);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!path || !path.path_modules?.length) {
    return (
      <div className="max-w-2xl mx-auto text-center py-12 space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
          <GraduationCap className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-bold">No Training Path Assigned Yet</h2>
          <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">
            Your manager hasn't assigned a training path to you yet. Once assigned, Trinity will build your personalized learning journey here — tailored to your industry, department, and role.
          </p>
        </div>
        <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4 max-w-md mx-auto">
          <p className="text-xs text-amber-500 flex items-center gap-2 justify-center">
            <AlertCircle className="w-4 h-4" /> Ask your manager to assign your role under Module Library → Assign to Employee.
          </p>
        </div>
      </div>
    );
  }

  const modules = path.path_modules;
  const completed = modules.filter((m) => userProgress[m.id]?.completed).length;
  const progressPct = Math.round((completed / modules.length) * 100);
  const nextModule = modules.find((m) => !userProgress[m.id]?.completed);

  return (
    <div className="space-y-5">
      {/* Welcome header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-purple-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <ProgressRing value={progressPct} size={72} stroke={7} label="Path" />
            <div>
              <p className="text-xs text-muted-foreground">Welcome back,</p>
              <h2 className="text-lg font-bold">{user?.full_name || user?.email}</h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <Badge variant="outline" className="text-xs border-primary/30 text-primary">{path.path_name}</Badge>
                <span className="text-xs text-muted-foreground">{completed}/{modules.length} modules</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">Powered by Trinity AI</span>
          </div>
        </div>
      </div>

      {/* Path modules — sequential unlock */}
      <div className="space-y-3">
        {modules.map((mod, idx) => {
          const progress = userProgress[mod.id];
          const isComplete = progress?.completed;
          const prevComplete = idx === 0 || userProgress[modules[idx - 1].id]?.completed;
          const isLocked = !prevComplete && !isComplete;
          const isCurrent = !isComplete && !isLocked && nextModule?.id === mod.id;
          const meta = MODULE_TYPE_META[mod.module_type] || MODULE_TYPE_META.fundamentals;
          const refresher = progress?.refresher_required;

          return (
            <div
              key={mod.id}
              onClick={() => !isLocked && onOpenModule({ ...mod, index: idx }, path)}
              className={`rounded-xl border p-5 transition-all ${
                isLocked ? 'border-border bg-muted/20 opacity-50 cursor-not-allowed'
                : isComplete ? 'border-emerald-500/30 bg-emerald-500/5 cursor-pointer hover:border-emerald-500/50'
                : isCurrent ? 'border-primary/40 bg-primary/5 cursor-pointer hover:border-primary/60 ring-1 ring-primary/20'
                : 'border-border bg-card cursor-pointer hover:border-primary/30 hover:bg-primary/5'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-11 h-11 rounded-xl ${meta.bg} flex items-center justify-center shrink-0 text-lg`}>
                  {isLocked ? <Lock className="w-5 h-5 text-muted-foreground" />
                  : isComplete ? <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  : <span>{meta.icon}</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Module {idx + 1}</span>
                    <Badge variant="outline" className={`text-[10px] ${meta.color} border-current/20`}>{meta.label}</Badge>
                    <span className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> {mod.est_minutes || 25} min</span>
                    {isComplete && progress?.quiz_score !== undefined && (
                      <Badge variant="outline" className="text-[10px] ml-auto text-emerald-500 border-emerald-500/30">{progress.quiz_score}/5 ✓</Badge>
                    )}
                    {refresher && <Badge className="text-[10px] ml-auto bg-amber-500/10 text-amber-500 border-amber-500/20">Refresher Required</Badge>}
                  </div>
                  <p className="font-semibold text-sm">{mod.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{mod.description}</p>
                  {mod.topics?.length > 0 && (
                    <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                      {mod.topics.slice(0, 3).map((t, i) => (
                        <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-muted/40 text-muted-foreground">{t}</span>
                      ))}
                    </div>
                  )}
                  <div className="flex items-center mt-2">
                    {!isLocked && !isComplete && (
                      <span className="text-xs text-primary font-medium flex items-center gap-1 ml-auto">
                        {isCurrent ? 'Continue' : 'Start'} <ChevronRight className="w-3 h-3" />
                      </span>
                    )}
                    {isComplete && !refresher && (
                      <span className="text-xs text-emerald-500 font-medium flex items-center gap-1 ml-auto">
                        Review <ChevronRight className="w-3 h-3" />
                      </span>
                    )}
                    {isComplete && refresher && (
                      <span className="text-xs text-amber-500 font-medium flex items-center gap-1 ml-auto">
                        Retake <ChevronRight className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {completed === modules.length && (
        <CapstoneAssessment path={path} employee={employee} user={user} onComplete={loadEmployee} />
      )}
    </div>
  );
}