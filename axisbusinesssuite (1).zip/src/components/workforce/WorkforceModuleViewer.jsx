import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  ArrowLeft, ArrowRight, ClipboardCheck, Play, FileText, Clock,
  CheckCircle2, Sparkles, RefreshCw, Loader2, Target, Lightbulb, Lock,
} from 'lucide-react';
import QuizComponent from '@/components/learning/QuizComponent';
import ScenarioPractice from './ScenarioPractice';
import TrinityChatPanel from './TrinityChatPanel';
import { MODULE_TYPE_META } from '@/lib/workforceIndustries';

export default function WorkforceModuleViewer({
  module,
  pathContext,
  userProgress,
  onPassQuiz,
  onContribute,
  onBack,
}) {
  const [view, setView] = useState('lesson'); // lesson | practice | test
  const [content, setContent] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showContribute, setShowContribute] = useState(false);
  const [contributeText, setContributeText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [scenarioPassed, setScenarioPassed] = useState(false);

  const meta = MODULE_TYPE_META[module.module_type] || MODULE_TYPE_META.fundamentals;
  const pathName = pathContext?.path_name || '';
  const companyKnowledgeIds = pathContext?.company_knowledge_ids || [];

  useEffect(() => {
    loadContent();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [module.id]);

  const loadContent = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'generate_module_content',
        industry: pathContext.industry,
        department: pathContext.department,
        position: pathContext.position,
        module_index: module.index,
        module_title: module.title,
        module_type: module.module_type,
        topics: module.topics,
        company_knowledge_ids: companyKnowledgeIds,
      });
      const data = res.data || {};
      if (data.success && data.content) {
        setContent(data.content);
      } else {
        toast.error(data.error || 'Failed to load module content');
      }
    } catch (e) {
      toast.error(e.message || 'Failed to load module content');
    } finally {
      setLoading(false);
    }
  };

  const handleScenarioComplete = (score) => {
    setScenarioPassed(score >= 3);
    onPassQuiz?.(module, score, 'scenario');
  };

  const handleContribute = async () => {
    if (!contributeText.trim()) return;
    setSubmitting(true);
    try {
      await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'contribute_knowledge',
        title: `${module.title} — Employee Contribution`,
        content: contributeText,
        department: pathContext.department,
        category: pathContext.department,
        tags: [pathContext.industry, pathContext.department, pathContext.position, module.module_type],
      });
      toast.success('Thank you! Your knowledge contribution was submitted for manager review.');
      setContributeText('');
      setShowContribute(false);
      onContribute?.();
    } catch (e) {
      toast.error('Failed to submit contribution');
    } finally {
      setSubmitting(false);
    }
  };

  const quiz = (content?.quiz?.questions || []).map((q) => ({
    q: q.question || q.q,
    options: q.options || [],
    answer: q.answer ?? 0,
  }));
  const scenarios = content?.scenarios || [];
  const takeaways = content?.key_takeaways || [];
  const quickRef = content?.quick_reference || '';
  const outline = content?.outline;
  const script = content?.script || '';
  const lessons = outline?.lessons || module.lessons || [];

  const moduleContext = `Module: ${module.title}\nTopics: ${(module.topics || []).join(', ')}\n${script ? 'Script excerpt: ' + script.slice(0, 800) : ''}`;

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 flex-wrap mb-4">
        <Button variant="default" size="sm" onClick={onBack} className="gap-1.5 font-semibold shadow-md">
          <ArrowLeft className="w-4 h-4" /> Back to Path
        </Button>
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-lg ${meta.bg} flex items-center justify-center text-base`}>
            {meta.icon}
          </div>
          <div>
            <p className="font-bold text-sm">{module.title}</p>
            <p className="text-xs text-muted-foreground">{pathName} · {meta.label}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <Button size="sm" variant="outline" onClick={() => setShowChat(!showChat)}>
            <Sparkles className="w-3.5 h-3.5 mr-1 text-primary" /> Ask Trinity
          </Button>
          {userProgress?.completed && <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">✓ Completed</Badge>}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Main column */}
        <div className="lg:col-span-2 space-y-4">
          {/* Loading / regenerate */}
          {loading && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-primary/10 border border-primary/30">
              <Loader2 className="w-5 h-5 text-primary animate-spin" />
              <div>
                <p className="text-sm font-semibold text-primary">Trinity is preparing your training module...</p>
                <p className="text-xs text-muted-foreground">Generating lessons, scenarios, and quiz tailored to your role.</p>
              </div>
            </div>
          )}

          {!loading && content && (
            <>
              {/* View switcher */}
              <div className="flex gap-2">
                {[
                  { id: 'lesson', label: '📖 Lesson' },
                  { id: 'practice', label: '🎯 Practice' },
                  { id: 'test', label: '📝 Test' },
                ].map((v) => (
                  <Button
                    key={v.id}
                    variant={view === v.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setView(v.id)}
                    disabled={v.id === 'test' && !scenarioPassed}
                    className={v.id === 'test' && !scenarioPassed ? 'opacity-50 cursor-not-allowed' : ''}
                  >
                    {v.label}
                    {v.id === 'test' && !scenarioPassed && <Lock className="w-3 h-3 ml-1" />}
                  </Button>
                ))}
              </div>

              {view === 'lesson' && (
                <Card>
                  <CardContent className="p-6 space-y-5">
                    <div className={`rounded-xl ${meta.bg} border border-border p-4`}>
                      <p className="font-semibold text-sm">{outline?.description || module.description}</p>
                    </div>

                    <div>
                      <h3 className="font-bold text-sm mb-3">What You'll Learn</h3>
                      <div className="space-y-2">
                        {lessons.map((lesson, i) => (
                          <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/20">
                            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary shrink-0 mt-0.5">{i + 1}</div>
                            <div className="flex-1">
                              <p className="text-sm font-medium">{lesson.title}</p>
                              <p className="text-xs text-muted-foreground">{lesson.duration}{lesson.description ? ` · ${lesson.description}` : ''}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {script && (
                      <details className="rounded-lg border border-border bg-muted/20 p-4">
                        <summary className="font-semibold text-sm cursor-pointer flex items-center gap-2">
                          <FileText className="w-4 h-4 text-primary" /> Instructor Script
                        </summary>
                        <p className="text-xs text-muted-foreground mt-3 whitespace-pre-wrap leading-relaxed">{script}</p>
                      </details>
                    )}

                    {takeaways.length > 0 && (
                      <div>
                        <h3 className="font-bold text-sm mb-3">Key Takeaways</h3>
                        <div className="space-y-2">
                          {takeaways.map((t, i) => (
                            <div key={i} className="flex items-start gap-2 text-sm">
                              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                              <span>{t}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {quickRef && (
                      <div className="rounded-lg border border-border bg-muted/30 p-4">
                        <p className="font-semibold text-sm flex items-center gap-2"><Lightbulb className="w-4 h-4 text-primary" /> Quick Reference</p>
                        <p className="text-xs text-muted-foreground mt-1">{quickRef}</p>
                      </div>
                    )}

                    <Button className="w-full" onClick={() => setView('practice')}>
                      Start Scenario Practice <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              )}

              {view === 'practice' && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><Target className="w-4 h-4 text-primary" /> Scenario Practice</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <p className="text-xs text-muted-foreground mb-4">
                      Work through realistic scenarios. Pass 3 out of {scenarios.length || 4} to unlock the module test.
                    </p>
                    <ScenarioPractice
                      scenarios={scenarios}
                      onComplete={handleScenarioComplete}
                      onProceed={() => setView('test')}
                    />
                  </CardContent>
                </Card>
              )}

              {view === 'test' && scenarioPassed && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2"><ClipboardCheck className="w-4 h-4 text-primary" /> Module Test — {module.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="bg-muted/30 rounded-lg p-3 text-xs text-muted-foreground mb-4">
                      Answer all 5 questions. You need 4 out of 5 to pass and complete this module.
                    </div>
                    {quiz.length > 0 ? (
                      <QuizComponent quiz={quiz} onPass={(s) => onPassQuiz(module, s, 'quiz')} onFail={() => {}} onContinue={onBack} />
                    ) : (
                      <p className="text-sm text-muted-foreground">Quiz unavailable. Regenerate the module to load the test.</p>
                    )}
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {/* Contribute knowledge */}
          {!loading && content && (
            <Card>
              <CardContent className="p-4">
                {showContribute ? (
                  <div className="space-y-2">
                    <p className="text-sm font-semibold flex items-center gap-2"><Lightbulb className="w-4 h-4 text-primary" /> Contribute Your Knowledge</p>
                    <p className="text-xs text-muted-foreground">Share a tip, procedure, or lesson learned. Your manager will review it and add it to future training.</p>
                    <textarea
                      value={contributeText}
                      onChange={(e) => setContributeText(e.target.value)}
                      rows={3}
                      placeholder="e.g. The fastest way to process a return is to verify the receipt first, then..."
                      className="w-full bg-card border border-border rounded-md px-3 py-2 text-sm"
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleContribute} disabled={submitting || !contributeText.trim()}>
                        {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Submit for Review'}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setShowContribute(false)}>Cancel</Button>
                    </div>
                  </div>
                ) : (
                  <button onClick={() => setShowContribute(true)} className="text-sm text-primary font-medium flex items-center gap-2 hover:underline">
                    <Lightbulb className="w-4 h-4" /> Contribute knowledge from this module
                  </button>
                )}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Trinity chat sidebar */}
        {showChat && (
          <div className="lg:col-span-1">
            <Card className="h-[600px] overflow-hidden">
              <TrinityChatPanel
                industry={pathContext.industry}
                department={pathContext.department}
                moduleContext={moduleContext}
                companyKnowledgeIds={companyKnowledgeIds}
                onClose={() => setShowChat(false)}
              />
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}