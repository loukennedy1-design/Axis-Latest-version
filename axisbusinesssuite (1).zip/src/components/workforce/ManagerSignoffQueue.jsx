import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, ShieldCheck, CheckCircle2, XCircle, Clock, User } from 'lucide-react';
import { toast } from 'sonner';

// Manager sign-off queue for high-level training milestones. An employee's
// proficiency_status only becomes fully_proficient after a manager approves a
// pending milestone here. Shown to admins/managers in the certifications tab.
export default function ManagerSignoffQueue({ user }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [notes, setNotes] = useState({});
  const [busy, setBusy] = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', { action: 'list_pending_signoffs' });
      if (res.data?.success) setRows(res.data.rows || []);
      else toast.error(res.data?.error || 'Failed to load sign-offs');
    } catch (e) {
      toast.error(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const decide = async (id, decision) => {
    setBusy((b) => ({ ...b, [id]: decision }));
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'decide_milestone_approval',
        approval_id: id,
        decision,
        notes: notes[id] || '',
      });
      if (res.data?.success) {
        toast.success(decision === 'approve'
          ? 'Signed off — employee marked fully proficient'
          : 'Sign-off rejected — employee returned to in-training');
        setNotes((n) => ({ ...n, [id]: '' }));
        await load();
      } else {
        toast.error(res.data?.error || 'Decision failed');
      }
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy((b) => ({ ...b, [id]: null }));
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>;
  }
  if (!rows.length) return null;

  return (
    <Card className="border-primary/30">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-bold">Manager Sign-Off Queue</h3>
          <Badge variant="outline" className="text-primary border-primary/30">{rows.length} pending</Badge>
        </div>
        <p className="text-xs text-muted-foreground">
          High-level training milestones awaiting manager approval before an employee reaches{' '}
          <span className="text-foreground font-medium">Fully Proficient</span> status.
        </p>
        <div className="space-y-3">
          {rows.map((r) => (
            <div key={r.id} className="rounded-lg border border-border p-4 bg-muted/20">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold text-sm flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-muted-foreground" /> {r.employee_name || r.employee_email}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">{r.milestone_label || r.milestone}</p>
                  <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" /> {r.requested_at ? new Date(r.requested_at).toLocaleDateString() : '—'}
                    </span>
                    {r.approver_email && <span>· Approver: {r.approver_email}</span>}
                  </div>
                </div>
                <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                  <Clock className="w-3 h-3 mr-1" /> Pending
                </Badge>
              </div>
              <Textarea
                value={notes[r.id] || ''}
                onChange={(e) => setNotes((n) => ({ ...n, [r.id]: e.target.value }))}
                placeholder="Add sign-off notes (optional)…"
                className="mt-3 h-16 text-xs"
              />
              <div className="flex items-center gap-2 mt-3">
                <Button size="sm" disabled={!!busy[r.id]} onClick={() => decide(r.id, 'approve')}>
                  {busy[r.id] === 'approve'
                    ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" />
                    : <CheckCircle2 className="w-3.5 h-3.5 mr-1" />}
                  Approve
                </Button>
                <Button size="sm" variant="outline" disabled={!!busy[r.id]} onClick={() => decide(r.id, 'reject')}>
                  {busy[r.id] === 'reject'
                    ? <Loader2 className="w-3.5 h-3.5 mr-1 animate-spin" />
                    : <XCircle className="w-3.5 h-3.5 mr-1" />}
                  Reject
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}