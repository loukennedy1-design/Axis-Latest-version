import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  ChevronRight, ChevronLeft, Loader2, Building2, Users, Briefcase,
  CheckCircle2, Search, Sparkles, UserPlus, ArrowRight,
} from 'lucide-react';
import {
  WORKFORCE_INDUSTRIES, WORKFORCE_DEPARTMENTS, STANDARD_CURRICULUM,
  MODULE_TYPE_META, getDepartmentLabel, getPositionLabel,
} from '@/lib/workforceIndustries';

export default function ModuleLibraryTab() {
  const [selectedIndustry, setSelectedIndustry] = useState(null);
  const [selectedDept, setSelectedDept] = useState(null);
  const [selectedPos, setSelectedPos] = useState(null);
  const [query, setQuery] = useState('');
  const [employees, setEmployees] = useState([]);
  const [assignOpen, setAssignOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    loadEmployees();
  }, []);

  const loadEmployees = async () => {
    try {
      const records = await base44.entities.Employee.filter({}, '-created_date', 200);
      setEmployees((records || []).filter((e) => e.status === 'active' || e.status === 'probation'));
    } catch { setEmployees([]); }
  };

  const filteredIndustries = query.trim()
    ? WORKFORCE_INDUSTRIES.filter((i) => i.label.toLowerCase().includes(query.toLowerCase()))
    : WORKFORCE_INDUSTRIES;

  const handleAssign = async () => {
    if (!selectedEmployee) { toast.error('Select an employee first'); return; }
    if (!selectedIndustry || !selectedDept || !selectedPos) { toast.error('Select a role first'); return; }
    setGenerating(true);
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'generate_path',
        industry: selectedIndustry,
        department: selectedDept,
        position: selectedPos.id,
        employee_id: selectedEmployee,
      });
      if (res.data?.success) {
        toast.success(`Training path assigned to ${employees.find((e) => e.id === selectedEmployee)?.first_name || 'employee'}!`, { duration: 5000 });
        setAssignOpen(false);
        setSelectedEmployee(null);
      } else {
        toast.error(res.data?.error || 'Failed to assign path');
      }
    } catch (e) {
      toast.error(e.message || 'Failed to assign path');
    } finally {
      setGenerating(false);
    }
  };

  const industryMeta = selectedIndustry ? WORKFORCE_INDUSTRIES.find((i) => i.value === selectedIndustry) : null;

  return (
    <div className="space-y-5">
      {/* Breadcrumb / context */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
        <button onClick={() => { setSelectedIndustry(null); setSelectedDept(null); setSelectedPos(null); }} className="hover:text-primary">Module Library</button>
        {selectedIndustry && (
          <>
            <ChevronRight className="w-3 h-3" />
            <button onClick={() => { setSelectedDept(null); setSelectedPos(null); }} className="hover:text-primary">{industryMeta?.icon} {industryMeta?.label}</button>
          </>
        )}
        {selectedDept && (
          <>
            <ChevronRight className="w-3 h-3" />
            <button onClick={() => setSelectedPos(null)} className="hover:text-primary">{getDepartmentLabel(selectedDept)}</button>
          </>
        )}
        {selectedPos && (
          <>
            <ChevronRight className="w-3 h-3" />
            <span className="text-foreground font-medium">{selectedPos.label}</span>
          </>
        )}
      </div>

      {/* Level 1: Industry grid */}
      {!selectedIndustry && (
        <div className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search industries..."
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-card text-sm focus:outline-none focus:border-primary/50"
            />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
            {filteredIndustries.map((ind) => (
              <button
                key={ind.value}
                onClick={() => setSelectedIndustry(ind.value)}
                className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-center"
              >
                <span className="text-2xl">{ind.icon}</span>
                <p className="text-xs font-semibold leading-tight">{ind.label}</p>
                <span className="text-[10px] text-muted-foreground">{ind.departments.length} departments</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Level 2: Departments */}
      {selectedIndustry && !selectedDept && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setSelectedIndustry(null)}><ChevronLeft className="w-4 h-4" /> Industries</Button>
            <h3 className="text-sm font-bold flex items-center gap-2"><Building2 className="w-4 h-4 text-primary" /> {industryMeta?.label} — Departments</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {industryMeta?.departments.map((deptKey) => {
              const dept = WORKFORCE_DEPARTMENTS[deptKey];
              if (!dept) return null;
              return (
                <button
                  key={deptKey}
                  onClick={() => setSelectedDept(deptKey)}
                  className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left"
                >
                  <span className="text-2xl">{dept.icon}</span>
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{dept.label}</p>
                    <p className="text-xs text-muted-foreground">{dept.positions.length} positions</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Level 3: Positions */}
      {selectedDept && !selectedPos && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setSelectedDept(null)}><ChevronLeft className="w-4 h-4" /> Departments</Button>
            <h3 className="text-sm font-bold flex items-center gap-2"><Users className="w-4 h-4 text-primary" /> {getDepartmentLabel(selectedDept)} — Positions</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {WORKFORCE_DEPARTMENTS[selectedDept]?.positions.map((pos) => (
              <button
                key={pos.id}
                onClick={() => setSelectedPos(pos)}
                className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Briefcase className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{pos.label}</p>
                  <p className="text-xs text-muted-foreground">{STANDARD_CURRICULUM.length} modules</p>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Level 4: Standard curriculum + assign */}
      {selectedPos && (
        <div className="space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={() => setSelectedPos(null)}><ChevronLeft className="w-4 h-4" /> Positions</Button>
              <h3 className="text-sm font-bold flex items-center gap-2"><Briefcase className="w-4 h-4 text-primary" /> {selectedPos.label} — Standard Curriculum</h3>
            </div>
            <Button size="sm" onClick={() => setAssignOpen(true)}>
              <UserPlus className="w-4 h-4 mr-1" /> Assign to Employee
            </Button>
          </div>

          <p className="text-xs text-muted-foreground">
            The standard {STANDARD_CURRICULUM.length}-module curriculum for this role. When assigned, Trinity personalizes every module with {industryMeta?.label} best practices and your company's SOPs.
          </p>

          <div className="space-y-2">
            {STANDARD_CURRICULUM.map((mod, idx) => {
              const meta = MODULE_TYPE_META[mod.module_type] || MODULE_TYPE_META.fundamentals;
              return (
                <div key={idx} className="flex items-start gap-3 p-4 rounded-xl border border-border bg-card">
                  <div className={`w-9 h-9 rounded-lg ${meta.bg} flex items-center justify-center shrink-0 text-base`}>{meta.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Module {idx + 1}</span>
                      <Badge variant="outline" className={`text-[10px] ${meta.color} border-current/20`}>{meta.label}</Badge>
                      <span className="text-xs text-muted-foreground">{mod.est_minutes} min</span>
                    </div>
                    <p className="font-semibold text-sm mt-0.5">{mod.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{mod.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Assign dialog */}
          {assignOpen && (
            <Card className="border-primary/30">
              <CardContent className="p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm flex items-center gap-2"><Sparkles className="w-4 h-4 text-primary" /> Assign Training Path</h4>
                  <Button size="sm" variant="ghost" onClick={() => setAssignOpen(false)}>Cancel</Button>
                </div>
                <div className="rounded-lg border border-border bg-muted/20 p-3 text-xs">
                  <p><strong>Industry:</strong> {industryMeta?.label}</p>
                  <p><strong>Department:</strong> {getDepartmentLabel(selectedDept)}</p>
                  <p><strong>Position:</strong> {selectedPos.label}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-1">Select an active employee:</p>
                  {employees.length === 0 ? (
                    <p className="text-sm text-muted-foreground py-2">No active employees found. Add employees in HR first.</p>
                  ) : (
                    <div className="max-h-48 overflow-y-auto space-y-1">
                      {employees.map((e) => (
                        <button
                          key={e.id}
                          onClick={() => setSelectedEmployee(e.id)}
                          className={`w-full flex items-center gap-2 p-2 rounded-lg border text-left text-sm transition-all ${
                            selectedEmployee === e.id ? 'border-primary bg-primary/10' : 'border-border bg-card hover:bg-muted/30'
                          }`}
                        >
                          <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-xs font-bold shrink-0">
                            {(e.first_name?.[0] || '') + (e.last_name?.[0] || '')}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium truncate">{e.first_name} {e.last_name}</p>
                            <p className="text-[10px] text-muted-foreground truncate">{e.email} · {e.department}</p>
                          </div>
                          {selectedEmployee === e.id && <CheckCircle2 className="w-4 h-4 text-primary" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <Button className="w-full" onClick={handleAssign} disabled={!selectedEmployee || generating}>
                  {generating ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Trinity is building the path...</> : <>Generate & Assign Path <ArrowRight className="w-4 h-4 ml-1" /></>}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}