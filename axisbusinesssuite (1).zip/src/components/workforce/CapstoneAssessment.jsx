import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Trophy, Loader2, ClipboardCheck, CheckCircle2, ShieldCheck, RefreshCw,
} from 'lucide-react';

// Capstone pass threshold: 70% of the generated questions.
const CAPSTONE_PASS_RATIO = 0.7;

export default function CapstoneAssessment({ path, employee, onComplete }) {
  const [phase, setPhase] = useState('idle'); // idle | loading | taking | done
  const [questions, setQuestions] = useState([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  const capstone = path?.capstone;
  const alreadyPassed = !!capstone?.passed;

  const start = async () => {
    setPhase('loading');
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'generate_path_assessment',
        industry: path.industry,
        department: path.department,
        position: path.position,
        modules: path.path_modules,
      });
      const data = res.data || {};
      if (data.success && data.assessment?.questions?.length) {
        setQuestions(data.assessment.questions);
        setCurrentQ(0); setSelected(null); setAnswered(false); setScore(0);
        setPhase('taking');
      } else {
        toast.error(data.error || 'Failed to generate capstone assessment');
        setPhase('idle');
      }
    } catch (e) {
      toast.error(e.message || 'Failed to generate capstone assessment');
      setPhase('idle');
    }
  };

  const handleSelect = (idx) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === questions[currentQ].answer) setScore((s) => s + 1);
  };

  const handleNext = () => {
    if (currentQ + 1 >= questions.length) finish();
    else { setCurrentQ((q) => q + 1); setSelected(null); setAnswered(false); }
  };

  const finish = async () => {
    const passed = score >= Math.ceil(questions.length * CAPSTONE_PASS_RATIO);
    setPhase('done');
    setSubmitting(true);
    try {
      await base44.functions.invoke('trinityWorkforceEngine', {
        action: 'record_path_assessment',
        employee_id: employee.id,
        passed,
        score,
        total: questions.length,
      });
      toast.success(passed ? 'Capstone passed — credential earned! 🎉' : 'Not quite — review the modules and retake the capstone.');
      onComplete?.();
    } catch {
      toast.error('Failed to record capstone result');
    } finally {
      setSubmitting(false);
    }
  };

  const retake = () => { setPhase('idle'); setQuestions([]); };

  // Already certified
  if (alreadyPassed && phase === 'idle') {
    return (
      <Card className="border-primary/30 bg-gradient-to-r from-primary/10 to-purple-500/10">
        <CardContent className="p-6 text-center">
          <Trophy className="w-12 h-12 text-primary mx-auto mb-3" />
          <h2 className="text-xl font-bold">Training Path Complete!</h2>
          <p className="text-muted-foreground mt-1">You've passed the capstone assessment for <strong>{path.path_name}</strong>.</p>
          <div className="flex items-center justify-center gap-3 mt-4">
            <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20"><ShieldCheck className="w-3 h-3 mr-1" /> Certified</Badge>
            <Badge variant="outline" className="text-primary border-primary/30">{capstone.score}/{capstone.total} capstone</Badge>
          </div>
          <Button variant="outline" size="sm" className="mt-4" onClick={start}>
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Retake Assessment
          </Button>
        </CardContent>
      </Card>
    );
  }

  if (phase === 'idle') {
    return (
      <Card className="border-primary/30 bg-gradient-to-r from-primary/10 to-purple-500/10">
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
              <ClipboardCheck className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-bold">Capstone Assessment</h2>
              <p className="text-sm text-muted-foreground mt-1">
                You've completed all modules in <strong>{path.path_name}</strong>. Pass this final assessment to earn your credential.
              </p>
              <ul className="text-xs text-muted-foreground mt-3 space-y-1">
                <li>• 10 cumulative questions drawn from every module</li>
                <li>• Pass threshold: 70% (7/10)</li>
                <li>• You can retake the assessment if you don't pass</li>
              </ul>
              <Button className="mt-4" onClick={start}>Start Final Assessment</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (phase === 'loading') {
    return (
      <Card><CardContent className="p-6 flex items-center gap-3">
        <Loader2 className="w-5 h-5 text-primary animate-spin" />
        <div>
          <p className="text-sm font-semibold text-primary">Trinity is building your capstone assessment…</p>
          <p className="text-xs text-muted-foreground">Drawing questions from all {path.path_modules?.length || 0} modules.</p>
        </div>
      </CardContent></Card>
    );
  }

  if (phase === 'taking') {
    const q = questions[currentQ];
    const total = questions.length;
    const passMark = Math.ceil(total * CAPSTONE_PASS_RATIO);
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><ClipboardCheck className="w-4 h-4 text-primary" /> Capstone Assessment — {path.path_name}</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Question {currentQ + 1} of {total}</p>
            <Progress value={(currentQ / total) * 100} className="w-24 h-2" />
          </div>
          <p className="font-semibold text-sm leading-relaxed mb-4">{q.question}</p>
          <div className="space-y-2">
            {q.options.map((opt, idx) => {
              let style = 'border-border bg-card hover:bg-muted/50 cursor-pointer';
              if (answered) {
                if (idx === q.answer) style = 'border-emerald-500 bg-emerald-500/10';
                else if (idx === selected) style = 'border-red-500 bg-red-500/10';
                else style = 'border-border bg-muted/20 opacity-50';
              }
              return (
                <button key={idx} onClick={() => handleSelect(idx)} className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${style}`}>
                  <span className="font-medium mr-2">{['A', 'B', 'C', 'D'][idx]}.</span>{opt}
                </button>
              );
            })}
          </div>
          {answered && (
            <Button onClick={handleNext} className="w-full mt-4">
              {currentQ + 1 >= total ? 'See Results' : 'Next Question'} →
            </Button>
          )}
          <p className="text-[10px] text-muted-foreground mt-3 text-center">Need {passMark}/{total} to pass.</p>
        </CardContent>
      </Card>
    );
  }

  // phase done
  const total = questions.length || 1;
  const passMark = Math.ceil(total * CAPSTONE_PASS_RATIO);
  const passed = score >= passMark;
  return (
    <Card>
      <CardContent className="p-6 text-center">
        <div className="text-4xl mb-3">{passed ? '🎉' : '📚'}</div>
        <p className="font-bold text-lg">{passed ? 'Capstone Passed!' : 'Almost There'}</p>
        <p className="text-sm text-muted-foreground mt-1">
          You scored {score} out of {total}{passed ? '' : ` — you need ${passMark} to pass.`}
        </p>
        {submitting && <p className="text-xs text-muted-foreground mt-2 flex items-center justify-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Saving…</p>}
        {!submitting && passed && (
          <Button className="mt-4" onClick={() => onComplete?.() || setPhase('idle')}>
            <CheckCircle2 className="w-4 h-4 mr-1" /> View Credential
          </Button>
        )}
        {!submitting && !passed && (
          <Button variant="outline" className="mt-4" onClick={retake}>
            <RefreshCw className="w-4 h-4 mr-1" /> Review & Retake
          </Button>
        )}
      </CardContent>
    </Card>
  );
}