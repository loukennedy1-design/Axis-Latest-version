import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Plus, Loader2, BadgeCheck, Trash2, Upload, FileText,
  CheckCircle2, Clock, ShieldAlert, BookOpen,
} from 'lucide-react';
import { WORKFORCE_DEPARTMENTS } from '@/lib/workforceIndustries';

const DOC_TYPES = [
  { value: 'sop', label: 'SOP', color: 'text-blue-400' },
  { value: 'policy', label: 'Policy', color: 'text-rose-400' },
  { value: 'employee_manual', label: 'Employee Manual', color: 'text-indigo-400' },
  { value: 'training', label: 'Training', color: 'text-amber-400' },
  { value: 'compliance_doc', label: 'Compliance Doc', color: 'text-red-400' },
  { value: 'technical_guide', label: 'Technical Guide', color: 'text-emerald-400' },
  { value: 'documentation', label: 'Documentation', color: 'text-muted-foreground' },
  { value: 'other', label: 'Other', color: 'text-muted-foreground' },
];

const docTypeColor = (t) => DOC_TYPES.find((d) => d.value === t)?.color || 'text-muted-foreground';

export default function CompanyLibraryTab() {
  const [docs, setDocs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [tab, setTab] = useState('library'); // library | queue
  const [form, setForm] = useState({ title: '', doc_type: 'sop', content: '', category: '', tags: '' });

  const load = async () => {
    setLoading(true);
    try {
      const records = await base44.entities.CompanyKnowledge.filter({}, '-created_date', 200);
      setDocs(records || []);
    } catch { setDocs([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const handleCreate = async () => {
    if (!form.title.trim()) { toast.error('Title is required'); return; }
    setUploading(true);
    try {
      await base44.entities.CompanyKnowledge.create({
        title: form.title,
        doc_type: form.doc_type,
        content: form.content,
        category: form.category,
        tags: form.tags ? JSON.stringify(form.tags.split(',').map((t) => t.trim())) : '[]',
        verified: false,
        version: 1,
      });
      toast.success('Document added — verify it to make it part of training.');
      setForm({ title: '', doc_type: 'sop', content: '', category: '', tags: '' });
      setShowCreate(false);
      await load();
    } catch (e) { toast.error('Failed to add document'); }
    finally { setUploading(false); }
  };

  const handleVerify = async (id) => {
    try {
      await base44.entities.CompanyKnowledge.update(id, { verified: true });
      toast.success('Verified — now used in training paths');
      await load();
    } catch { toast.error('Failed to verify'); }
  };

  const handleDelete = async (id) => {
    try {
      await base44.entities.CompanyKnowledge.delete(id);
      await load();
    } catch { toast.error('Failed to delete'); }
  };

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const up = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.CompanyKnowledge.create({
        title: file.name,
        doc_type: 'documentation',
        content: `Uploaded file: ${file.name}`,
        file_url: up.file_url,
        category: form.category,
        tags: '[]',
        verified: false,
        version: 1,
      });
      toast.success('File uploaded — verify it to use in training.');
      await load();
    } catch { toast.error('Upload failed'); }
    finally { setUploading(false); }
  };

  const pending = docs.filter((d) => !d.verified);
  const verified = docs.filter((d) => d.verified);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-base font-bold flex items-center gap-2"><BookOpen className="w-5 h-5 text-primary" /> Company Knowledge Library</h2>
          <p className="text-xs text-muted-foreground">Upload SOPs, handbooks, and policies. Verified docs are woven into training paths automatically.</p>
        </div>
        <div className="flex gap-2">
          <label>
            <input type="file" className="hidden" onChange={handleFile} accept=".pdf,.doc,.docx,.txt,.md" />
            <Button variant="outline" size="sm" asChild disabled={uploading}>
              <span><Upload className="w-4 h-4 mr-1" /> {uploading ? 'Uploading...' : 'Upload File'}</span>
            </Button>
          </label>
          <Button size="sm" onClick={() => setShowCreate(!showCreate)}><Plus className="w-4 h-4 mr-1" /> Add Document</Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card><CardContent className="pt-4">
          <p className="text-xs text-muted-foreground uppercase">Total</p>
          <p className="text-xl font-bold">{docs.length}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-xs text-muted-foreground uppercase flex items-center gap-1"><CheckCircle2 className="w-3 h-3 text-emerald-500" /> Verified</p>
          <p className="text-xl font-bold text-emerald-500">{verified.length}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-xs text-muted-foreground uppercase flex items-center gap-1"><Clock className="w-3 h-3 text-amber-500" /> Pending</p>
          <p className="text-xl font-bold text-amber-500">{pending.length}</p>
        </CardContent></Card>
      </div>

      {/* Tab toggle */}
      <div className="flex gap-2">
        <Button size="sm" variant={tab === 'library' ? 'default' : 'outline'} onClick={() => setTab('library')}>
          Verified Library ({verified.length})
        </Button>
        <Button size="sm" variant={tab === 'queue' ? 'default' : 'outline'} onClick={() => setTab('queue')}>
          Moderation Queue ({pending.length})
        </Button>
      </div>

      {/* Create form */}
      {showCreate && (
        <Card className="border-primary/30">
          <CardContent className="p-5 space-y-3">
            <Input placeholder="Document title (e.g. Refund Processing SOP)" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <select className="bg-card border border-border rounded-md px-2 py-2 text-sm" value={form.doc_type} onChange={(e) => setForm({ ...form, doc_type: e.target.value })}>
                {DOC_TYPES.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
              </select>
              <select className="bg-card border border-border rounded-md px-2 py-2 text-sm" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                <option value="">No department</option>
                {Object.entries(WORKFORCE_DEPARTMENTS).map(([k, d]) => <option key={k} value={k}>{d.label}</option>)}
              </select>
            </div>
            <textarea placeholder="Full content / procedure text..." value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={5} className="w-full bg-card border border-border rounded-md px-3 py-2 text-sm" />
            <Input placeholder="Tags (comma-separated)" value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} />
            <div className="flex gap-2">
              <Button onClick={handleCreate} disabled={uploading || !form.title.trim()}>
                {uploading ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : 'Add Document'}
              </Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Documents */}
      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : tab === 'queue' ? (
        pending.length === 0 ? (
          <Card><CardContent className="py-10 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-500/40 mx-auto mb-2" />
            <p className="text-sm font-medium">No pending contributions</p>
            <p className="text-xs text-muted-foreground">All documents are verified and in use.</p>
          </CardContent></Card>
        ) : (
          <div className="space-y-2">
            {pending.map((d) => (
              <Card key={d.id} className="border-amber-500/20">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <ShieldAlert className="w-4 h-4 text-amber-500" />
                        <span className={`text-xs font-medium ${docTypeColor(d.doc_type)}`}>{d.doc_type.replace(/_/g, ' ')}</span>
                        {d.category && <span className="text-xs text-muted-foreground">· {d.category}</span>}
                        <Badge className="text-[10px] bg-amber-500/10 text-amber-500 border-amber-500/20">Pending Review</Badge>
                      </div>
                      <h3 className="font-semibold text-sm">{d.title}</h3>
                      {d.content && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{d.content}</p>}
                      {d.file_url && <a href={d.file_url} target="_blank" rel="noreferrer" className="text-xs text-primary flex items-center gap-1 mt-1"><FileText className="w-3 h-3" /> View file</a>}
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Button size="sm" variant="ghost" onClick={() => handleVerify(d.id)} title="Verify"><BadgeCheck className="w-4 h-4 text-emerald-500" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => handleDelete(d.id)} title="Delete"><Trash2 className="w-4 h-4 text-destructive" /></Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )
      ) : verified.length === 0 ? (
        <Card><CardContent className="py-10 text-center">
          <BookOpen className="w-10 h-10 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-sm font-medium">No verified documents yet</p>
          <p className="text-xs text-muted-foreground">Add SOPs and handbooks, then verify them to weave into training.</p>
        </CardContent></Card>
      ) : (
        <div className="space-y-2">
          {verified.map((d) => (
            <Card key={d.id}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className={`text-xs font-medium ${docTypeColor(d.doc_type)}`}>{d.doc_type.replace(/_/g, ' ')}</span>
                      <BadgeCheck className="w-4 h-4 text-emerald-500" />
                      {d.category && <span className="text-xs text-muted-foreground">· {d.category}</span>}
                    </div>
                    <h3 className="font-semibold text-sm">{d.title}</h3>
                    {d.content && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{d.content}</p>}
                    {d.file_url && <a href={d.file_url} target="_blank" rel="noreferrer" className="text-xs text-primary flex items-center gap-1 mt-1"><FileText className="w-3 h-3" /> View file</a>}
                  </div>
                  <div className="flex gap-1 shrink-0">
                    <Button size="sm" variant="ghost" onClick={() => handleDelete(d.id)} title="Delete"><Trash2 className="w-4 h-4 text-destructive" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}