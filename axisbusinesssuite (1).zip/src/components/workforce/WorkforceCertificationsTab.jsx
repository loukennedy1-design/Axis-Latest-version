import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Award, Loader2, Trophy, CheckCircle2, GraduationCap,
} from 'lucide-react';
import StaffCertificationsLedger from '@/components/workforce/StaffCertificationsLedger';
import ManagerSignoffQueue from '@/components/workforce/ManagerSignoffQueue';

export default function WorkforceCertificationsTab({ user }) {
  const [employee, setEmployee] = useState(null);
  const [progress, setProgress] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.email) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.email]);

  const load = async () => {
    setLoading(true);
    try {
      const [emps, progs] = await Promise.all([
        base44.entities.Employee.filter({ email: user.email }, '-created_date', 5),
        base44.entities.LearningProgress.filter({ user_email: user.email }, '-updated_date', 200),
      ]);
      setEmployee(emps?.[0] || null);
      const map = {};
      (progs || []).forEach((p) => { map[p.module_id] = p; });
      setProgress(map);
    } catch {
      setEmployee(null);
      setProgress({});
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  let path = null;
  try { path = employee?.training_path ? JSON.parse(employee.training_path) : null; } catch { /* ignore */ }

  if (!path || !path.path_modules?.length) {
    if (isAdmin) return (<div className="space-y-5"><ManagerSignoffQueue user={user} /><StaffCertificationsLedger user={user} /></div>);
    return (
      <Card><CardContent className="py-12 text-center">
        <Award className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
        <p className="text-sm font-medium">No certifications yet</p>
        <p className="text-xs text-muted-foreground mt-1">Complete your assigned training path to earn a credential.</p>
      </CardContent></Card>
    );
  }

  const modules = path.path_modules;
  const completed = modules.filter((m) => progress[m.id]?.completed).length;
  const capstonePassed = !!path?.capstone?.passed;
  const allDone = completed === modules.length && capstonePassed;
  const completionPct = Math.round((completed / modules.length) * 100);
  const avgScore = (() => {
    const scored = modules.map((m) => progress[m.id]?.quiz_score).filter((s) => s !== undefined && s !== null);
    return scored.length ? (scored.reduce((a, b) => a + b, 0) / scored.length).toFixed(1) : '0.0';
  })();

  return (
    <div className={`space-y-5 ${isAdmin ? '' : 'max-w-3xl mx-auto'}`}>
      {/* Certificate card */}
      <Card className={`relative overflow-hidden ${allDone ? 'border-primary/40 bg-gradient-to-br from-primary/10 via-card to-purple-500/5' : 'border-border'}`}>
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <CardContent className="p-8 text-center relative">
          <div className={`w-20 h-20 rounded-2xl ${allDone ? 'bg-primary/20' : 'bg-muted/40'} flex items-center justify-center mx-auto mb-4`}>
            {allDone ? <Trophy className="w-10 h-10 text-primary" /> : <GraduationCap className="w-10 h-10 text-muted-foreground" />}
          </div>
          <h2 className="text-2xl font-bold tracking-tight">{allDone ? 'Certified' : 'Certification in Progress'}</h2>
          <p className="text-sm text-muted-foreground mt-2">{path.path_name}</p>
          <p className="text-xs text-muted-foreground mt-1">Awarded to {user?.full_name || user?.email}</p>

          <div className="flex items-center justify-center gap-6 mt-6">
            <div>
              <p className="text-2xl font-bold text-primary">{completionPct}%</p>
              <p className="text-xs text-muted-foreground">Complete</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{completed}/{modules.length}</p>
              <p className="text-xs text-muted-foreground">Modules</p>
            </div>
            <div>
              <p className="text-2xl font-bold">{avgScore}/5</p>
              <p className="text-xs text-muted-foreground">Avg Score</p>
            </div>
          </div>

          {allDone && (
            <Badge className="mt-5 bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
              <CheckCircle2 className="w-3 h-3 mr-1" /> Credential Earned
            </Badge>
          )}
          {!allDone && completed === modules.length && (
            <p className="text-xs text-amber-500 mt-3">Complete the Capstone Assessment in your training path to earn this credential.</p>
          )}
        </CardContent>
      </Card>

      {/* Module completion checklist */}
      <Card>
        <CardContent className="p-5">
          <h3 className="font-bold text-sm flex items-center gap-2 mb-3"><Award className="w-4 h-4 text-primary" /> Module Completion</h3>
          <div className="space-y-2">
            {modules.map((m, i) => {
              const p = progress[m.id];
              return (
                <div key={m.id} className="flex items-center gap-2 text-sm">
                  <span className="text-[10px] font-bold text-muted-foreground w-6">M{i + 1}</span>
                  {p?.completed
                    ? <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    : <div className="w-4 h-4 rounded-full border border-border shrink-0" />}
                  <span className={`flex-1 truncate ${p?.completed ? '' : 'text-muted-foreground'}`}>{m.title}</span>
                  {p?.quiz_score !== undefined && (
                    <Badge variant="outline" className={p?.completed ? 'text-emerald-500 border-emerald-500/30' : 'text-muted-foreground'}>{p.quiz_score}/5</Badge>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {isAdmin && (<><ManagerSignoffQueue user={user} /><StaffCertificationsLedger user={user} /></>)}
    </div>
  );
}