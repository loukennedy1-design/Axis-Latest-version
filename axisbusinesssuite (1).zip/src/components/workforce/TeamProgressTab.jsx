import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Loader2, Users, TrendingUp, Award, Users2, Search, ChevronDown,
  ChevronRight, CheckCircle2, Circle, Clock, RefreshCw, Mail,
  Briefcase, GraduationCap, ArrowUpDown,
} from 'lucide-react';

const pretty = (s) =>
  String(s || '').replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

const STATUS_STYLES = {
  not_started: 'bg-muted text-muted-foreground border-border',
  in_progress: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
  complete: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
  refresher: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
};

function employeeStatus(r) {
  if (r.refresher_required) return 'refresher';
  if (r.completion_pct === 100) return 'complete';
  if (r.completed > 0) return 'in_progress';
  return 'not_started';
}

const STATUS_LABELS = {
  not_started: 'Not Started',
  in_progress: 'In Progress',
  complete: 'Complete',
  refresher: 'Refresher Due',
};

export default function TeamProgressTab() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState('');
  const [sortKey, setSortKey] = useState('completion'); // completion | name | last_active
  const [expanded, setExpanded] = useState({});

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('trinityWorkforceEngine', { action: 'get_team_progress' });
      if (res.data?.success) {
        setRows(res.data.rows || []);
      } else {
        setError(res.data?.error || 'Failed to load team progress');
      }
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? rows.filter((r) =>
          [r.name, r.email, r.path_name, r.position, r.department, pretty(r.position), pretty(r.department)]
            .some((v) => String(v || '').toLowerCase().includes(q)))
      : rows;
    const sorted = [...list];
    if (sortKey === 'completion') sorted.sort((a, b) => b.completion_pct - a.completion_pct);
    else if (sortKey === 'name') sorted.sort((a, b) => a.name.localeCompare(b.name));
    else if (sortKey === 'last_active') {
      sorted.sort((a, b) => {
        const ta = a.last_active ? new Date(a.last_active).getTime() : 0;
        const tb = b.last_active ? new Date(b.last_active).getTime() : 0;
        return tb - ta;
      });
    }
    return sorted;
  }, [rows, query, sortKey]);

  const stats = useMemo(() => {
    const total = rows.length;
    const completedPaths = rows.filter((r) => r.completion_pct === 100 && !r.refresher_required).length;
    const inProgress = rows.filter((r) => r.completed > 0 && r.completion_pct < 100).length;
    const avgCompletion = total ? Math.round(rows.reduce((s, r) => s + r.completion_pct, 0) / total) : 0;
    const scored = rows.filter((r) => r.avg_score > 0);
    const avgScore = scored.length
      ? (scored.reduce((s, r) => s + r.avg_score, 0) / scored.length).toFixed(1)
      : '0.0';
    const refreshers = rows.filter((r) => r.refresher_required).length;
    return { total, completedPaths, inProgress, avgCompletion, avgScore, refreshers };
  }, [rows]);

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <Card><CardContent className="py-10 text-center">
        <p className="text-sm text-destructive">{error}</p>
        <Button variant="outline" size="sm" className="mt-3" onClick={load}>Retry</Button>
      </CardContent></Card>
    );
  }

  if (rows.length === 0) {
    return (
      <Card><CardContent className="py-12 text-center">
        <Users2 className="w-12 h-12 text-muted-foreground/40 mx-auto mb-3" />
        <p className="text-sm font-medium">No training paths assigned yet</p>
        <p className="text-xs text-muted-foreground mt-1">Assign paths from the Module Library to see team progress here.</p>
      </CardContent></Card>
    );
  }

  return (
    <div className="space-y-5">
      {/* Overview stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><Users className="w-3 h-3" /> In Training</p>
          <p className="text-xl font-bold">{stats.total}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><TrendingUp className="w-3 h-3" /> Avg Completion</p>
          <p className="text-xl font-bold text-primary">{stats.avgCompletion}%</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><GraduationCap className="w-3 h-3" /> Certified</p>
          <p className="text-xl font-bold text-emerald-500">{stats.completedPaths}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><Award className="w-3 h-3" /> Avg Quiz</p>
          <p className="text-xl font-bold">{stats.avgScore}/5</p>
        </CardContent></Card>
        <Card><CardContent className="pt-4">
          <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1"><RefreshCw className="w-3 h-3" /> Refreshers Due</p>
          <p className={`text-xl font-bold ${stats.refreshers ? 'text-rose-500' : ''}`}>{stats.refreshers}</p>
        </CardContent></Card>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, role, or path…"
            className="pl-9 h-9"
          />
        </div>
        <div className="flex items-center gap-1.5">
          <ArrowUpDown className="w-3.5 h-3.5 text-muted-foreground" />
          {[
            { id: 'completion', label: 'Completion' },
            { id: 'name', label: 'Name' },
            { id: 'last_active', label: 'Last Active' },
          ].map((opt) => (
            <Button
              key={opt.id}
              size="sm"
              variant={sortKey === opt.id ? 'default' : 'outline'}
              className="h-8 text-xs"
              onClick={() => setSortKey(opt.id)}
            >
              {opt.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Employee rows */}
      <div className="space-y-2">
        {filtered.length === 0 && (
          <Card><CardContent className="py-8 text-center text-sm text-muted-foreground">
            No employees match “{query}”.
          </CardContent></Card>
        )}
        {filtered.map((r) => {
          const st = employeeStatus(r);
          const isOpen = !!expanded[r.employee_id];
          return (
            <Card key={r.employee_id} className={isOpen ? 'border-primary/30' : ''}>
              <CardContent className="pt-4">
                <div
                  className="flex items-center gap-3 cursor-pointer"
                  onClick={() => setExpanded((m) => ({ ...m, [r.employee_id]: !m[r.employee_id] }))}
                >
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                    {r.name?.split(' ').map((n) => n[0]).slice(0, 2).join('') || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-sm">{r.name}</p>
                      <Badge variant="outline" className={`text-[10px] ${STATUS_STYLES[st]}`}>{STATUS_LABELS[st]}</Badge>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap mt-0.5">
                      <p className="text-xs text-muted-foreground truncate">{r.path_name}</p>
                      {r.position && (
                        <span className="text-[10px] text-muted-foreground/80 flex items-center gap-0.5">
                          <Briefcase className="w-2.5 h-2.5" /> {pretty(r.position)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <p className="text-xs font-bold text-primary">{r.completion_pct}%</p>
                      <p className="text-[10px] text-muted-foreground">{r.completed}/{r.total_modules} modules</p>
                    </div>
                    {r.avg_score > 0 && (
                      <Badge variant="outline" className="text-xs border-primary/30 text-primary">{r.avg_score}/5</Badge>
                    )}
                    {isOpen
                      ? <ChevronDown className="w-4 h-4 text-muted-foreground" />
                      : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                  </div>
                </div>
                <Progress value={r.completion_pct} className="h-1.5 mt-3" />
                <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                  {r.email && <span className="flex items-center gap-1"><Mail className="w-2.5 h-2.5" /> {r.email}</span>}
                  {r.last_active && <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> Last active {new Date(r.last_active).toLocaleDateString()}</span>}
                </div>

                {/* Module breakdown */}
                {isOpen && r.modules && r.modules.length > 0 && (
                  <div className="mt-4 space-y-1.5 border-t border-border pt-3">
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium mb-1">Module Progress</p>
                    {r.modules.map((m, idx) => (
                      <div key={m.id || idx} className="flex items-center gap-2 text-xs">
                        {m.refresher_required ? (
                          <RefreshCw className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                        ) : m.completed ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                        ) : (
                          <Circle className="w-3.5 h-3.5 text-muted-foreground/40 shrink-0" />
                        )}
                        <span className={`flex-1 truncate ${m.completed ? 'text-foreground' : 'text-muted-foreground'}`}>
                          {idx + 1}. {m.title}
                        </span>
                        {m.refresher_required && (
                          <Badge variant="outline" className="text-[9px] border-rose-500/30 text-rose-500">Retake</Badge>
                        )}
                        {m.quiz_score !== null && m.quiz_score !== undefined && (
                          <span className="text-[10px] text-muted-foreground font-mono">{m.quiz_score}/5</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}