import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Slider } from '@/components/ui/slider';
import { 
  LayoutDashboard, Bell, Moon, Sun, Type, Palette, 
  Eye, Settings, User, CheckCircle2, Loader2, Save, RotateCcw
} from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';

/**
 * PersonalizationSettings - Allow users to customize their experience
 * - Dashboard layout preferences
 * - Notification settings
 * - Theme and accessibility options
 * - Default views and filters
 */
export function PersonalizationSettings() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [loading, setLoading] = useState(false);
  
  // User preferences state
  const [preferences, setPreferences] = useState({
    // Theme
    theme: 'system', // 'light', 'dark', 'system'
    highContrast: false,
    fontSize: 'medium', // 'small', 'medium', 'large'
    
    // Dashboard
    defaultDashboardView: 'overview', // 'overview', 'leads', 'calls', 'team'
    compactMode: false,
    showLiveUpdates: true,
    defaultTimeRange: '7', // days
    
    // Notifications
    emailNotifications: true,
    smsNotifications: false,
    callNotifications: true,
    taskReminders: true,
    
    // Defaults
    defaultLeadStatus: 'new',
    defaultCallOutcome: 'other',
    autoSaveForms: true,
  });

  // Fetch user preferences
  const { data: userSettings } = useQuery({
    queryKey: ['user-settings', user?.email],
    queryFn: () => base44.entities.UserAddon.filter({ user_email: user?.email }),
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (userSettings && userSettings.length > 0) {
      try {
        const prefs = JSON.parse(userSettings[0].preferences || '{}');
        setPreferences(prev => ({ ...prev, ...prefs }));
      } catch (e) {
        console.error('Failed to parse preferences', e);
      }
    }
  }, [userSettings]);

  // Save preferences mutation
  const savePrefs = useMutation({
    mutationFn: async (prefs) => {
      const existing = await base44.entities.UserAddon.filter({ user_email: user?.email });
      if (existing.length > 0) {
        return base44.entities.UserAddon.update(existing[0].id, {
          preferences: JSON.stringify(prefs),
        });
      } else {
        return base44.entities.UserAddon.create({
          user_email: user?.email,
          preferences: JSON.stringify(prefs),
        });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['user-settings'] });
      toast.success('Preferences saved');
    },
    onError: (error) => {
      toast.error('Failed to save: ' + error.message);
    },
  });

  const handleSave = () => {
    setLoading(true);
    savePrefs.mutate(preferences, { onSettled: () => setLoading(false) });
  };

  const handleReset = () => {
    const defaults = {
      theme: 'system',
      highContrast: false,
      fontSize: 'medium',
      defaultDashboardView: 'overview',
      compactMode: false,
      showLiveUpdates: true,
      defaultTimeRange: '7',
      emailNotifications: true,
      smsNotifications: false,
      callNotifications: true,
      taskReminders: true,
      defaultLeadStatus: 'new',
      defaultCallOutcome: 'other',
      autoSaveForms: true,
    };
    setPreferences(defaults);
    toast.success('Preferences reset to defaults');
  };

  const handlePreview = () => {
    // Apply theme preview
    if (preferences.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else if (preferences.theme === 'light') {
      document.documentElement.classList.remove('dark');
    }
    
    // Apply font size
    document.documentElement.style.setProperty('--font-size-scale', 
      preferences.fontSize === 'small' ? '0.875' :
      preferences.fontSize === 'large' ? '1.125' : '1'
    );
    
    // Apply high contrast
    if (preferences.highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  };

  useEffect(() => {
    handlePreview();
  }, [preferences.theme, preferences.fontSize, preferences.highContrast]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold">Personalization</h2>
          <p className="text-sm text-muted-foreground">Customize your workspace</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleReset} className="gap-2">
            <RotateCcw className="w-4 h-4" />
            Reset
          </Button>
          <Button size="sm" onClick={handleSave} disabled={loading} className="gap-2">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Changes
          </Button>
        </div>
      </div>

      <Tabs defaultValue="appearance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="defaults">Defaults</TabsTrigger>
        </TabsList>

        {/* Appearance */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Palette className="w-4 h-4" />
                Theme & Display
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Theme</Label>
                  <Select value={preferences.theme} onValueChange={(v) => setPreferences({ ...preferences, theme: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="system">System</SelectItem>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Font Size</Label>
                  <Select value={preferences.fontSize} onValueChange={(v) => setPreferences({ ...preferences, fontSize: v })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">Small</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="large">Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <Label className="text-sm">High Contrast Mode</Label>
                  <p className="text-xs text-muted-foreground">Enhanced visibility for better accessibility</p>
                </div>
                <Switch
                  checked={preferences.highContrast}
                  onCheckedChange={(v) => setPreferences({ ...preferences, highContrast: v })}
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <Label className="text-sm">Compact Mode</Label>
                  <p className="text-xs text-muted-foreground">Reduce spacing and padding</p>
                </div>
                <Switch
                  checked={preferences.compactMode}
                  onCheckedChange={(v) => setPreferences({ ...preferences, compactMode: v })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Dashboard */}
        <TabsContent value="dashboard" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <LayoutDashboard className="w-4 h-4" />
                Dashboard Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Default Dashboard View</Label>
                <Select value={preferences.defaultDashboardView} onValueChange={(v) => setPreferences({ ...preferences, defaultDashboardView: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="overview">Overview</SelectItem>
                    <SelectItem value="leads">Leads</SelectItem>
                    <SelectItem value="calls">Calls</SelectItem>
                    <SelectItem value="team">Team</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Default Time Range</Label>
                <Select value={preferences.defaultTimeRange} onValueChange={(v) => setPreferences({ ...preferences, defaultTimeRange: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="14">Last 14 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <Label className="text-sm">Live Updates</Label>
                  <p className="text-xs text-muted-foreground">Real-time data refresh</p>
                </div>
                <Switch
                  checked={preferences.showLiveUpdates}
                  onCheckedChange={(v) => setPreferences({ ...preferences, showLiveUpdates: v })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Notification Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { key: 'emailNotifications', label: 'Email Notifications', desc: 'Receive updates via email' },
                { key: 'smsNotifications', label: 'SMS Notifications', desc: 'Text message alerts' },
                { key: 'callNotifications', label: 'Call Alerts', desc: 'Notifications for new calls' },
                { key: 'taskReminders', label: 'Task Reminders', desc: 'Reminders for pending tasks' },
              ].map(item => (
                <div key={item.key} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                  <div>
                    <Label className="text-sm">{item.label}</Label>
                    <p className="text-xs text-muted-foreground">{item.desc}</p>
                  </div>
                  <Switch
                    checked={preferences[item.key]}
                    onCheckedChange={(v) => setPreferences({ ...preferences, [item.key]: v })}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Defaults */}
        <TabsContent value="defaults" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Default Values
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Default Lead Status</Label>
                <Select value={preferences.defaultLeadStatus} onValueChange={(v) => setPreferences({ ...preferences, defaultLeadStatus: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Default Call Outcome</Label>
                <Select value={preferences.defaultCallOutcome} onValueChange={(v) => setPreferences({ ...preferences, defaultCallOutcome: v })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="other">Other</SelectItem>
                    <SelectItem value="callback_requested">Callback Requested</SelectItem>
                    <SelectItem value="not_interested">Not Interested</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                <div>
                  <Label className="text-sm">Auto-save Forms</Label>
                  <p className="text-xs text-muted-foreground">Automatically save form data</p>
                </div>
                <Switch
                  checked={preferences.autoSaveForms}
                  onCheckedChange={(v) => setPreferences({ ...preferences, autoSaveForms: v })}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Preview badge */}
      <div className="fixed bottom-4 right-4 flex items-center gap-2 p-3 bg-primary text-primary-foreground rounded-lg shadow-lg">
        <CheckCircle2 className="w-4 h-4" />
        <span className="text-sm font-medium">Preview Active</span>
      </div>
    </div>
  );
}