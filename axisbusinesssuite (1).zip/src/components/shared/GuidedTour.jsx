import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { ChevronRight, ChevronLeft, CheckCircle2, Circle, Sparkles, X } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * GuidedTour - Interactive step-by-step guide for complex features
 * Usage: <GuidedTour steps={tourSteps} onComplete={() => {}} />
 */
export function GuidedTour({ steps, onComplete, onSkip, initialStep = 0, autoStart = true }) {
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [isOpen, setIsOpen] = useState(autoStart);

  useEffect(() => {
    if (currentStep >= steps.length && isOpen) {
      setIsOpen(false);
      onComplete?.();
    }
  }, [currentStep, steps.length, isOpen, onComplete]);

  const handleNext = () => setCurrentStep(prev => Math.min(prev + 1, steps.length));
  const handlePrev = () => setCurrentStep(prev => Math.max(prev - 1, 0));
  const handleSkip = () => {
    setIsOpen(false);
    onSkip?.();
  };

  const handleComplete = () => {
    setCurrentStep(steps.length);
    setIsOpen(false);
    onComplete?.();
  };

  if (!isOpen || steps.length === 0) return null;

  const step = steps[currentStep];
  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <DialogTitle>{step.title}</DialogTitle>
            </div>
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleSkip}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <DialogDescription className="sr-only">
            Step {currentStep + 1} of {steps.length}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Progress bar */}
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
              role="progressbar"
              aria-valuenow={progress}
              aria-valuemin={0}
              aria-valuemax={100}
            />
          </div>

          {/* Step indicator */}
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Step {currentStep + 1} of {steps.length}</span>
            <div className="flex gap-1">
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "w-2 h-2 rounded-full transition-all",
                    idx === currentStep ? "bg-primary scale-125" : idx < currentStep ? "bg-primary/50" : "bg-muted"
                  )}
                />
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="py-4">
            <p className="text-sm text-foreground leading-relaxed">{step.content}</p>
            
            {step.image && (
              <div className="mt-4 rounded-lg overflow-hidden border border-border">
                <img src={step.image} alt={step.title} className="w-full h-auto" />
              </div>
            )}

            {step.highlight && (
              <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                <p className="text-xs text-primary font-medium">{step.highlight}</p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <Button
              variant="ghost"
              onClick={handlePrev}
              disabled={currentStep === 0}
              className="gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>

            {currentStep === steps.length - 1 ? (
              <Button onClick={handleComplete} className="gap-2 bg-primary">
                <CheckCircle2 className="w-4 h-4" />
                Complete Tour
              </Button>
            ) : (
              <Button onClick={handleNext} className="gap-2">
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/**
 * FeatureTourTooltip - Small tooltip-style guide for specific UI elements
 */
export function FeatureTourTooltip({ title, content, position = 'bottom', onClose }) {
  const positionClasses = {
    top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 -translate-y-1/2 ml-2',
  };

  return (
    <div className={cn(
      "absolute z-50 bg-popover text-popover-foreground p-3 rounded-lg shadow-lg border border-border max-w-xs",
      positionClasses[position]
    )}
    role="tooltip"
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-sm font-semibold mb-1">{title}</p>
          <p className="text-xs text-muted-foreground">{content}</p>
        </div>
        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={onClose}>
          <X className="w-3 h-3" />
        </Button>
      </div>
      <div className={cn(
        "absolute w-2 h-2 bg-popover border-r border-t border-border transform rotate-45",
        position === 'top' && 'left-1/2 -translate-x-1/2 -bottom-1 border-r-0 border-b-0 border-l border-t',
        position === 'bottom' && 'left-1/2 -translate-x-1/2 -top-1 border-l-0 border-t-0 border-r border-b',
        position === 'left' && 'top-1/2 -translate-y-1/2 -right-1 border-l-0 border-t-0 border-r border-b',
        position === 'right' && 'top-1/2 -translate-y-1/2 -left-1 border-r-0 border-b-0 border-l border-t',
      )} />
    </div>
  );
}

/**
 * useGuidedTour - Hook to manage tour state in localStorage
 */
export function useGuidedTour(tourId, defaultCompleted = false) {
  const [isCompleted, setIsCompleted] = useState(() => {
    const stored = localStorage.getItem(`tour_${tourId}_completed`);
    return stored ? JSON.parse(stored) : defaultCompleted;
  });

  const markComplete = () => {
    localStorage.setItem(`tour_${tourId}_completed`, JSON.stringify(true));
    setIsCompleted(true);
  };

  const reset = () => {
    localStorage.removeItem(`tour_${tourId}_completed`);
    setIsCompleted(false);
  };

  return { isCompleted, markComplete, reset };
}