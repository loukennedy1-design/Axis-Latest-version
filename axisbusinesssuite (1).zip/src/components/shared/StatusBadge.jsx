import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const statusStyles = {
  new: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  contacted: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  qualified: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  appointment_set: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  not_interested: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  do_not_call: 'bg-red-500/10 text-red-600 border-red-500/20',
  invalid: 'bg-red-500/10 text-red-500 border-red-500/20',
  scheduled: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  confirmed: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  completed: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  cancelled: 'bg-red-500/10 text-red-600 border-red-500/20',
  no_show: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  no_answer: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  busy: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  voicemail: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  failed: 'bg-red-500/10 text-red-600 border-red-500/20',
  blocked: 'bg-red-500/10 text-red-600 border-red-500/20',
};

export default function StatusBadge({ status }) {
  const label = (status || 'unknown').replace(/_/g, ' ');
  return (
    <Badge variant="outline" className={cn('capitalize font-medium text-[11px]', statusStyles[status] || 'bg-muted text-muted-foreground')}>
      {label}
    </Badge>
  );
}