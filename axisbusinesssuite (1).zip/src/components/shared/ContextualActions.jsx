import React from 'react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { MoreVertical, Phone, Mail, Calendar, MessageSquare, FileText, Star, UserCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

/**
 * ContextualAction - Single action button with icon and label
 * @param {Object} props
 * @param {Function} props.icon - Lucide icon component
 * @param {string} props.label - Accessible label
 * @param {Function} props.onClick - Click handler
 * @param {string} [props.variant='ghost'] - Button variant
 * @param {string} [props.size='icon'] - Button size
 * @param {string} [props.className] - Additional classes
 * @param {boolean} [props.disabled=false] - Disabled state
 * @param {string} [props.title] - Tooltip title
 */
export function ContextualAction({ icon: Icon, label, onClick, variant = 'ghost', size = 'icon', className, disabled = false, title }) {
  if (!Icon) return null;
  return (
    <Button
      variant={variant}
      size={size}
      onClick={onClick}
      disabled={disabled}
      title={title || label}
      className={cn('gap-1', className)}
      aria-label={label}
    >
      <Icon className="w-4 h-4" />
      {size !== 'icon' && <span className="text-xs">{label}</span>}
    </Button>
  );
}

/**
 * ContextualActionsGroup - Group of action buttons with dropdown overflow
 * Perfect for tables and lists where space is limited
 */
export function ContextualActionsGroup({ actions, primaryActions = 3, variant = 'ghost', size = 'sm' }) {
  const primary = actions.slice(0, primaryActions);
  const secondary = actions.slice(primaryActions);

  return (
    <div className="flex items-center gap-1" role="group" aria-label="Quick actions">
      {primary.map((action, idx) => (
        <ContextualAction
          key={idx}
          icon={action.icon}
          label={action.label}
          onClick={action.onClick}
          variant={action.variant || variant}
          size={size}
          disabled={action.disabled}
          title={action.title || action.label}
          className={action.className}
        />
      ))}
      
      {secondary.length > 0 && (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant={variant} size={size} aria-label="More actions">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            {secondary.map((action, idx) => (
              <DropdownMenuItem
                key={idx}
                onClick={action.onClick}
                disabled={action.disabled}
                className="gap-2"
              >
                <action.icon className="w-4 h-4" />
                <span>{action.label}</span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      )}
    </div>
  );
}

/**
 * EntityActions - Pre-configured actions for common entities
 * Usage: <EntityActions entity={callLog} entityType="call" />
 */
export function EntityActions({ entity, entityType, onAction }) {
  const callActions = [
    { icon: Phone, label: 'Call', onClick: () => onAction?.('call', entity), disabled: !entity?.phone_number },
    { icon: Mail, label: 'Email', onClick: () => onAction?.('email', entity) },
    { icon: MessageSquare, label: 'SMS', onClick: () => onAction?.('sms', entity) },
    { icon: Calendar, label: 'Schedule', onClick: () => onAction?.('schedule', entity) },
    { icon: FileText, label: 'Summary', onClick: () => onAction?.('summary', entity) },
    { icon: Star, label: 'Rate', onClick: () => onAction?.('rate', entity) },
  ];

  const candidateActions = [
    { icon: Phone, label: 'Call', onClick: () => onAction?.('call', entity), disabled: !entity?.phone },
    { icon: Mail, label: 'Email', onClick: () => onAction?.('email', entity), disabled: !entity?.email },
    { icon: Calendar, label: 'Interview', onClick: () => onAction?.('interview', entity) },
    { icon: FileText, label: 'Profile', onClick: () => onAction?.('profile', entity) },
    { icon: UserCheck, label: 'Hire', onClick: () => onAction?.('hire', entity), disabled: entity?.status !== 'interviewed' && entity?.status !== 'offer_sent' },
  ];

  const leadActions = [
    { icon: Phone, label: 'Call', onClick: () => onAction?.('call', entity), disabled: !entity?.phone },
    { icon: Mail, label: 'Email', onClick: () => onAction?.('email', entity), disabled: !entity?.email },
    { icon: MessageSquare, label: 'SMS', onClick: () => onAction?.('sms', entity), disabled: !entity?.phone },
    { icon: Calendar, label: 'Appt', onClick: () => onAction?.('appointment', entity) },
    { icon: Star, label: 'Score', onClick: () => onAction?.('score', entity) },
  ];

  const actionMap = {
    call: callActions,
    candidate: candidateActions,
    lead: leadActions,
  };

  const actions = actionMap[entityType] || [];

  return (
    <ContextualActionsGroup 
      actions={actions} 
      primaryActions={3}
      variant="ghost"
      size="sm"
    />
  );
}