import React from 'react';
import { Loader2 } from 'lucide-react';
import { usePullToRefresh } from '@/hooks/usePullToRefresh';

/**
 * Pull-to-refresh wrapper. Renders a branded spinner that slides down from
 * the top edge when the user pulls, then snaps back with a spring transition.
 *
 * Pass the page's React Query `refetch` as `onRefresh`.
 */
export default function PullToRefresh({ onRefresh, children, className = '' }) {
  const { pullDistance, isRefreshing } = usePullToRefresh({ onRefresh });

  const showSpinner = pullDistance > 0 || isRefreshing;
  const spinnerAreaHeight = isRefreshing ? 44 : Math.min(pullDistance, 44);
  const contentTranslate = isRefreshing ? 44 : pullDistance;

  return (
    <div className={`relative ${className}`}>
      {showSpinner && (
        <div
          className="absolute top-0 left-1/2 -translate-x-1/2 z-40 flex items-start justify-center overflow-hidden"
          style={{
            height: spinnerAreaHeight,
            transition: isRefreshing ? 'none' : 'height 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
          }}
        >
          <Loader2
            className="text-primary animate-spin mt-1"
            style={{ width: 28, height: 28 }}
          />
        </div>
      )}
      <div
        style={{
          transform: `translateY(${contentTranslate}px)`,
          transition: pullDistance > 0 || isRefreshing ? 'none' : 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}
      >
        {children}
      </div>
    </div>
  );
}