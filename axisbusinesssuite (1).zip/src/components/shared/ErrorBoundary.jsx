import React from 'react';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('[ErrorBoundary]', error, errorInfo);

    // Report to Trinity's autonomous incident response system
    try {
      base44.functions.invoke('reportSystemError', {
        error_message: error?.message || String(error),
        error_stack: error?.stack || '',
        error_type: error?.name || 'ReactErrorBoundary',
        source: 'frontend',
        page_url: window.location.href,
        user_agent: navigator.userAgent,
        component_stack: errorInfo?.componentStack || '',
        additional_data: { boundary: this.props.name || 'unknown' },
      }).catch(() => {});
    } catch (_) {
      // Never let the error reporter cause a secondary crash
    }
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback(this.state.error, this.handleReset);
      }
      return (
        <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
          <p className="text-sm text-muted-foreground">Something went wrong loading this section.</p>
          <Button variant="outline" size="sm" onClick={this.handleReset}>
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Try Again
          </Button>
        </div>
      );
    }
    return this.props.children;
  }
}