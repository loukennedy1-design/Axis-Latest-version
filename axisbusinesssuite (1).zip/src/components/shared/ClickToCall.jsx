import React from 'react';
import { Phone } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function ClickToCall({ phone, className, showIcon = true, label }) {
  if (!phone) return <span className="text-muted-foreground text-sm">—</span>;

  const cleaned = phone.replace(/\s|\(|\)|-/g, '');

  const handleCall = (e) => {
    e.stopPropagation();
    toast.success(`Dialing ${phone} via Phone Link…`, { duration: 3000 });
  };

  return (
    <a
      href={`tel:${cleaned}`}
      onClick={handleCall}
      className={cn(
        'inline-flex items-center gap-1.5 font-mono text-sm text-primary hover:text-primary/80 hover:underline underline-offset-2 transition-colors cursor-pointer',
        className
      )}
    >
      {showIcon && <Phone className="w-3 h-3 flex-shrink-0" />}
      {label || phone}
    </a>
  );
}