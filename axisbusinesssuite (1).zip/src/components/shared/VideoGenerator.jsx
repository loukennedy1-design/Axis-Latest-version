import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Loader2, Video, Play, Download } from 'lucide-react';
import { toast } from 'sonner';

/**
 * Shared AI video generator + player.
 * Props:
 *   prompt: detailed video generation prompt
 *   label: short label for the button
 *   aspectRatio: '16:9' (default) or '9:16'
 *   className: optional wrapper class
 *   buttonClassName: optional button class
 *   compact: render small button without inline player (video opens below)
 */
export default function VideoGenerator({ prompt, label = 'Generate Video', aspectRatio = '16:9', className = '', buttonClassName = '', compact = false }) {
  const [loading, setLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState(null);

  const handleGenerate = async () => {
    if (!prompt) { toast.error('No prompt available for video generation'); return; }
    setLoading(true);
    setVideoUrl(null);
    try {
      const res = await base44.integrations.Core.GenerateVideo({ prompt, aspect_ratio: aspectRatio });
      if (res?.url) {
        setVideoUrl(res.url);
        toast.success('Video generated!');
      } else {
        toast.error('Video generation returned no URL');
      }
    } catch (e) {
      toast.error(e.message || 'Video generation failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={className}>
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={loading}
        onClick={handleGenerate}
        className={buttonClassName}
      >
        {loading ? <Loader2 className="w-3 h-3 mr-1.5 animate-spin" /> : <Video className="w-3 h-3 mr-1.5" />}
        {loading ? 'Generating Video...' : label}
      </Button>

      {loading && (
        <div className="mt-2 flex flex-col items-center justify-center border-2 border-dashed border-border rounded-lg bg-muted/20 py-8 gap-2">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
          <p className="text-xs text-muted-foreground text-center max-w-[200px]">
            Generating AI video... This takes about 30-60 seconds.
          </p>
        </div>
      )}

      {videoUrl && !loading && (
        <div className="mt-2">
          <div className="relative rounded-lg overflow-hidden border border-border">
            <video
              src={videoUrl}
              controls
              className={`w-full ${aspectRatio === '9:16' ? 'max-h-[400px] mx-auto' : ''}`}
            >
              <source src={videoUrl} type="video/mp4" />
            </video>
          </div>
          <a href={videoUrl} download target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-1">
            <Download className="w-3 h-3" /> Download Video
          </a>
        </div>
      )}
    </div>
  );
}