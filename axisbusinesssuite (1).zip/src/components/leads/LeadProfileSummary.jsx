import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Phone, Calendar, CheckCircle, XCircle, Clock, MessageSquare } from 'lucide-react';

export default function LeadProfileSummary({ lead }) {
  if (!lead) return null;

  const lastCallTranscript = lead.last_call_transcript || lead.ai_summary;
  const lastCallOutcome = lead.last_call_outcome || lead.call_outcome;
  const lastCallDate = lead.last_call_date;

  const outcomeIcons = {
    appointment_set: <Calendar className="w-4 h-4 text-emerald-500" />,
    callback_requested: <Phone className="w-4 h-4 text-blue-500" />,
    not_interested: <XCircle className="w-4 h-4 text-red-500" />,
    voicemail_left: <MessageSquare className="w-4 h-4 text-amber-500" />,
    no_answer: <Clock className="w-4 h-4 text-gray-500" />,
    other: <MessageSquare className="w-4 h-4 text-gray-500" />,
  };

  const outcomeLabels = {
    appointment_set: 'Appointment Set',
    callback_requested: 'Callback Requested',
    not_interested: 'Not Interested',
    voicemail_left: 'Voicemail Left',
    no_answer: 'No Answer',
    other: 'Other',
  };

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-primary" />
          AI Call Summary
        </CardTitle>
        <CardDescription>Most recent AI call performance</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Last Call Date */}
        {lastCallDate && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Clock className="w-3 h-3" />
            <span>{new Date(lastCallDate).toLocaleDateString()}</span>
          </div>
        )}

        {/* Call Outcome Badge */}
        {lastCallOutcome && (
          <Badge variant="outline" className="flex items-center gap-2 w-fit">
            {outcomeIcons[lastCallOutcome] || outcomeIcons.other}
            <span>{outcomeLabels[lastCallOutcome] || 'Unknown'}</span>
          </Badge>
        )}

        {/* AI Summary / Transcript */}
        {lastCallTranscript ? (
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">AI Summary:</div>
            <ScrollArea className="h-32 rounded-md border border-border bg-muted/30 p-3">
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {lastCallTranscript}
              </p>
            </ScrollArea>
          </div>
        ) : (
          <div className="text-sm text-muted-foreground italic">
            No call transcript available
          </div>
        )}

        {/* Performance Metrics */}
        <div className="pt-2 border-t border-border">
          <div className="grid grid-cols-2 gap-2 text-xs">
            {lead.call_attempts && (
              <div className="flex items-center gap-1.5">
                <Phone className="w-3 h-3 text-muted-foreground" />
                <span className="text-muted-foreground">Attempts:</span>
                <span className="font-semibold">{lead.call_attempts}</span>
              </div>
            )}
            {lead.call_duration && (
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-muted-foreground" />
                <span className="text-muted-foreground">Duration:</span>
                <span className="font-semibold">{Math.round(lead.call_duration / 60)}m</span>
              </div>
            )}
            {lead.ai_score && (
              <div className="flex items-center gap-1.5">
                <CheckCircle className="w-3 h-3 text-emerald-500" />
                <span className="text-muted-foreground">AI Score:</span>
                <span className="font-semibold text-emerald-500">{lead.ai_score}/100</span>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}