import React, { useState, useEffect } from 'react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, TrendingUp, CheckCircle2, X } from 'lucide-react';
import { PLANS } from '@/lib/pricing';
import { toast } from 'sonner';

export default function UsageMonitor({ children }) {
  const { user } = useCurrentUser();
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [exceededLimits, setExceededLimits] = useState(null);

  // Fetch user's usage data
  const { data: usageData } = useQuery({
    queryKey: ['user-usage', user?.email],
    queryFn: async () => {
      if (!user) return null;
      
      const [leads, callLogs, teamMembers] = await Promise.all([
        base44.entities.Lead.filter({ owner: user.email }),
        base44.entities.CallLog.filter({ owner: user.email }),
        base44.entities.UserAddon.filter({ user_email: user.email }),
      ]);

      // Get current month's call count
      const now = new Date();
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthCalls = callLogs.filter(log => new Date(log.created_date) >= monthStart);

      return {
        leadsCount: leads.length,
        callsCount: monthCalls.length,
        usersCount: teamMembers.length + 1, // +1 for the user themselves
      };
    },
    enabled: !!user,
    refetchInterval: 60000, // Refresh every minute
  });

  // Get user's current plan from TrialInvite or Subscription
  const { data: userPlan } = useQuery({
    queryKey: ['user-plan', user?.email],
    queryFn: async () => {
      if (!user) return null;
      
      const trialInvites = await base44.entities.TrialInvite.filter({ email: user.email });
      if (trialInvites.length > 0) {
        const trial = trialInvites[0];
        return {
          plan: PLANS.find(p => p.tier === (trial.plan_tier || 'starter')) || PLANS[0],
          isTrial: true,
          trialEnd: trial.trial_end,
        };
      }
      
      // Fallback to Starter plan
      return { plan: PLANS[0], isTrial: false };
    },
    enabled: !!user,
  });

  useEffect(() => {
    if (!usageData || !userPlan) return;
    // Super admins and admins are exempt from all limits
    if (user?.role === 'admin' || user?.role === 'super_admin') return;
    if (user?.email === 'loukennedy1@gmail.com') return;

    const { leadsCount, callsCount, usersCount } = usageData;
    const { plan } = userPlan;

    const limits = {
      leads: plan.max_leads,
      calls: plan.max_calls,
      users: plan.max_users,
    };

    const exceeded = {};
    if (leadsCount > limits.leads) exceeded.leads = { current: leadsCount, limit: limits.leads };
    if (callsCount > limits.calls) exceeded.calls = { current: callsCount, limit: limits.calls };
    if (usersCount > limits.users) exceeded.users = { current: usersCount, limit: limits.users };

    if (Object.keys(exceeded).length > 0 && !showUpgradeDialog) {
      setExceededLimits(exceeded);
      setShowUpgradeDialog(true);
    }
  }, [usageData, userPlan, showUpgradeDialog]);

  const handleUpgrade = (tier) => {
    setShowUpgradeDialog(false);
    window.location.href = '/pricing';
  };

  const getUsagePercentage = (current, limit) => {
    if (limit === 999999) return 0; // Unlimited
    return Math.min(100, Math.round((current / limit) * 100));
  };

  if (!user) return null;

  return (
    <>
      {children}

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <div className="mx-auto mb-4 w-16 h-16 bg-amber-500/10 rounded-full flex items-center justify-center">
              <AlertTriangle className="w-8 h-8 text-amber-600" />
            </div>
            <DialogTitle className="text-2xl font-bold text-center">
              📈 You've Exceeded Your Plan Limits
            </DialogTitle>
            <DialogDescription className="text-center text-base mt-2">
              Your usage has surpassed the <strong>{userPlan?.plan?.label}</strong> plan limits.
              <br />
              <span className="text-muted-foreground">Upgrade to continue using all features without interruption.</span>
            </DialogDescription>
          </DialogHeader>

          {/* Usage Breakdown */}
          <div className="space-y-4 mt-4">
            {exceededLimits?.leads && (
              <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Leads</span>
                  <Badge variant="destructive" className="text-xs">
                    {exceededLimits.leads.current} / {exceededLimits.leads.limit === 999999 ? '∞' : exceededLimits.leads.limit.toLocaleString()}
                  </Badge>
                </div>
                <Progress value={getUsagePercentage(exceededLimits.leads.current, exceededLimits.leads.limit)} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  You've exceeded your lead limit by {exceededLimits.leads.current - exceededLimits.leads.limit}
                </p>
              </div>
            )}

            {exceededLimits?.calls && (
              <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Monthly Calls</span>
                  <Badge variant="destructive" className="text-xs">
                    {exceededLimits.calls.current} / {exceededLimits.calls.limit === 999999 ? '∞' : exceededLimits.calls.limit.toLocaleString()}
                  </Badge>
                </div>
                <Progress value={getUsagePercentage(exceededLimits.calls.current, exceededLimits.calls.limit)} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  You've exceeded your call limit by {exceededLimits.calls.current - exceededLimits.calls.limit} this month
                </p>
              </div>
            )}

            {exceededLimits?.users && (
              <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">Team Members</span>
                  <Badge variant="destructive" className="text-xs">
                    {exceededLimits.users.current} / {exceededLimits.users.limit.toLocaleString()}
                  </Badge>
                </div>
                <Progress value={getUsagePercentage(exceededLimits.users.current, exceededLimits.users.limit)} className="h-2" />
                <p className="text-xs text-muted-foreground mt-1">
                  You've exceeded your user limit by {exceededLimits.users.current - exceededLimits.users.limit}
                </p>
              </div>
            )}
          </div>

          {/* Upgrade Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-6">
            {PLANS.filter(p => p.tier !== 'starter').map(plan => (
              <div
                key={plan.key}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  plan.highlight ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                }`}
                onClick={() => handleUpgrade(plan.tier)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-bold">{plan.label}</h3>
                  {plan.highlight && <Badge className="bg-primary text-primary-foreground text-xs">Popular</Badge>}
                </div>
                <div className="flex items-baseline gap-1 mb-2">
                  <span className="text-2xl font-bold">${plan.price}</span>
                  <span className="text-xs text-muted-foreground">/mo</span>
                </div>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    <span>{plan.max_leads === 999999 ? 'Unlimited' : plan.max_leads.toLocaleString()} leads</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    <span>{plan.max_calls === 999999 ? 'Unlimited' : plan.max_calls.toLocaleString()} calls/mo</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                    <span>Up to {plan.max_users} users</span>
                  </div>
                </div>
                <Button size="sm" className="w-full mt-3 gap-2">
                  Upgrade to {plan.label} <TrendingUp className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>

          <DialogFooter className="mt-4">
            <Button variant="outline" onClick={() => setShowUpgradeDialog(false)}>
              I'll Upgrade Later
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}