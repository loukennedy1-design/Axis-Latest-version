import React from 'react';
import { BookOpen, Target } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function PlaybooksLibrary({ playbooks }) {
  return (
    <Card className="flex flex-col h-[480px]">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-primary" />
          Playbooks Library
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto pr-2">
        {playbooks.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            No playbooks synthesized yet. Patterns will emerge as the brain accumulates data.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {playbooks.map((pb, idx) => (
              <div key={idx} className="rounded-lg border border-border bg-card/50 p-3 hover:border-primary/30 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <h4 className="text-sm font-semibold text-foreground leading-tight">{pb.name}</h4>
                  <Badge variant="outline" className="text-[9px] flex-shrink-0 bg-primary/10 text-primary border-primary/20">
                    {pb.confidence}%
                  </Badge>
                </div>
                {pb.category && (
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">{pb.category}</p>
                )}
                <div className="space-y-1.5">
                  <div>
                    <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground/70 flex items-center gap-1">
                      <Target className="w-2.5 h-2.5" /> Triggers
                    </p>
                    <div className="flex flex-wrap gap-1 mt-0.5">
                      {pb.trigger_conditions?.map((cond, i) => (
                        <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">{cond}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground/70">Actions</p>
                    <ol className="text-[10px] text-muted-foreground mt-0.5 space-y-0.5">
                      {pb.action_sequence?.map((step, i) => (
                        <li key={i} className="flex gap-1">
                          <span className="text-primary/60 flex-shrink-0">{i + 1}.</span>
                          <span className="leading-tight">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}