import React from 'react';
import { Trophy, TrendingUp, TrendingDown, Minus, Calendar, AlertTriangle } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const THROTTLE_STYLES = {
  priority: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  normal: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  throttled: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  cooldown: 'bg-red-500/20 text-red-400 border-red-500/30',
};

export default function AgentRankings({ rankings }) {
  const sorted = [...rankings].sort((a, b) => b.priority_score - a.priority_score);

  return (
    <Card className="flex flex-col h-[480px]">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Trophy className="w-4 h-4 text-primary" />
          Agent Rankings
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto space-y-2 pr-2">
        {sorted.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No agent data yet.</p>
        ) : (
          sorted.map((agent, idx) => (
            <div key={agent.agent_name} className={`rounded-lg border bg-card/50 p-3 ${(agent.throttle_level === 'throttled' || agent.throttle_level === 'cooldown') ? 'border-amber-500/30' : 'border-border'}`}>
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-xs font-bold text-muted-foreground w-5 flex-shrink-0">#{idx + 1}</span>
                  <span className="text-sm font-medium text-foreground truncate">
                    {agent.agent_name.replace(/_/g, ' ')}
                  </span>
                </div>
                <Badge variant="outline" className={`text-[9px] flex-shrink-0 ${THROTTLE_STYLES[agent.throttle_level] || THROTTLE_STYLES.normal}`}>
                  {agent.throttle_level}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-primary/60 to-primary transition-all duration-500"
                    style={{ width: `${Math.min(agent.priority_score, 100)}%` }}
                  />
                </div>
                <span className="text-xs font-bold text-foreground tabular-nums w-8 text-right">{agent.priority_score}</span>
              </div>
              <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  {agent.success_rate >= 70 ? <TrendingUp className="w-3 h-3 text-emerald-400" /> : agent.success_rate < 40 ? <TrendingDown className="w-3 h-3 text-red-400" /> : <Minus className="w-3 h-3" />}
                  {agent.success_rate}% success
                </span>
                <span>{agent.total_actions} actions</span>
                {agent.appt_conversion_rate !== null && agent.appt_conversion_rate !== undefined && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {agent.appt_conversion_rate}% appt
                  </span>
                )}
              </div>
              {agent.throttle_reason && (
                <div className="flex items-start gap-1.5 mt-1.5 pt-1.5 border-t border-border/50">
                  <AlertTriangle className="w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-[10px] text-amber-400/80 leading-tight">{agent.throttle_reason}</p>
                </div>
              )}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}