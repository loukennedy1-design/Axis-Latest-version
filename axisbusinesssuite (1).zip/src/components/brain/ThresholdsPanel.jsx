import React from 'react';
import { Sliders } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const DEFAULT_THRESHOLDS = {
  auto_execute_confidence_cutoff: 75,
  low_risk_auto_execute: true,
  medium_risk_approval_required: true,
  high_risk_approval_required: true,
  approval_confidence_threshold: 70,
  max_auto_actions_per_hour: 10,
  cooldown_period_minutes: 30,
};

const LABELS = {
  auto_execute_confidence_cutoff: 'Auto-Execute Cutoff',
  low_risk_auto_execute: 'Low Risk Auto-Execute',
  medium_risk_approval_required: 'Medium Risk Approval',
  high_risk_approval_required: 'High Risk Approval',
  approval_confidence_threshold: 'Approval Threshold',
  max_auto_actions_per_hour: 'Max Auto-Actions/hr',
  cooldown_period_minutes: 'Cooldown (min)',
};

export default function ThresholdsPanel({ thresholds }) {
  const keys = Object.keys(DEFAULT_THRESHOLDS);

  return (
    <Card className="flex flex-col h-[480px]">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Sliders className="w-4 h-4 text-primary" />
          Evolved Thresholds
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto pr-2">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-[10px] uppercase tracking-wider text-muted-foreground/70 border-b border-border">
              <th className="text-left font-semibold pb-2">Parameter</th>
              <th className="text-center font-semibold pb-2">Default</th>
              <th className="text-center font-semibold pb-2">Evolved</th>
              <th className="text-right font-semibold pb-2">Δ</th>
            </tr>
          </thead>
          <tbody>
            {keys.map(key => {
              const defVal = DEFAULT_THRESHOLDS[key];
              const curVal = thresholds[key] ?? defVal;
              const isNum = typeof defVal === 'number';
              const delta = isNum ? (curVal - defVal) : 0;
              const changed = delta !== 0;
              return (
                <tr key={key} className="border-b border-border/50">
                  <td className="py-2.5 text-xs text-foreground">{LABELS[key] || key}</td>
                  <td className="py-2.5 text-center text-xs text-muted-foreground">{String(defVal)}</td>
                  <td className="py-2.5 text-center">
                    <span className={`text-xs font-semibold ${changed ? 'text-primary' : 'text-foreground'}`}>{String(curVal)}</span>
                  </td>
                  <td className="py-2.5 text-right">
                    {changed ? (
                      <Badge variant="outline" className={`text-[9px] ${delta > 0 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>
                        {delta > 0 ? '+' : ''}{delta}
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground/40">—</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}