import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Radio, ChevronDown } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const TYPE_COLORS = {
  signal: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  reranking: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  threshold_evolution: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  playbook_synthesis: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
  brain_cycle: 'bg-primary/20 text-primary border-primary/30',
  initialization: 'bg-muted text-muted-foreground border-border',
};

export default function EvolutionFeed({ entries }) {
  const [expanded, setExpanded] = useState(null);
  const recent = entries.slice(0, 30);

  return (
    <Card className="flex flex-col h-[480px]">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Radio className="w-4 h-4 text-primary" />
          Live Evolution Feed
        </CardTitle>
        <Badge variant="outline" className="text-[10px]">{entries.length} events</Badge>
      </CardHeader>
      <CardContent className="flex-1 overflow-y-auto space-y-2 pr-2">
        <AnimatePresence initial={false}>
          {recent.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">No evolution events yet. Brain is initializing...</p>
          ) : (
            recent.map((entry, idx) => {
              const isOpen = expanded === idx;
              let detail = entry.detail;
              try { detail = JSON.parse(entry.detail); } catch (e) { /* keep raw */ }
              return (
                <motion.div
                  key={`${entry.timestamp}-${idx}`}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="rounded-lg border border-border bg-card/50 hover:bg-card transition-colors"
                >
                  <button
                    onClick={() => setExpanded(isOpen ? null : idx)}
                    className="w-full flex items-start gap-3 p-3 text-left"
                  >
                    <Badge variant="outline" className={`text-[9px] flex-shrink-0 ${TYPE_COLORS[entry.type] || TYPE_COLORS.initialization}`}>
                      {entry.type}
                    </Badge>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground truncate">{entry.summary}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {new Date(entry.timestamp).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        {entry.iq_at_time != null && <span className="ml-2 text-primary/70">IQ: {entry.iq_at_time}</span>}
                      </p>
                    </div>
                    <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && typeof detail === 'object' && (
                    <pre className="text-[10px] text-muted-foreground p-3 pt-0 overflow-x-auto whitespace-pre-wrap break-all">
                      {JSON.stringify(detail, null, 2)}
                    </pre>
                  )}
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}