import React, { useState, useEffect, useRef } from 'react';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';
import { Brain, Zap, Activity, BookOpen } from 'lucide-react';

export default function IQGauge({ iqScore, evolutionLog, signalsCount, playbooksCount, lastCycle }) {
  const [displayIQ, setDisplayIQ] = useState(0);
  const prevIQ = useRef(0);

  useEffect(() => {
    if (iqScore === displayIQ) return;
    const start = prevIQ.current;
    const target = iqScore;
    const diff = target - start;
    if (diff === 0) return;
    const steps = 30;
    let step = 0;
    const interval = setInterval(() => {
      step++;
      const progress = step / steps;
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(start + diff * eased);
      setDisplayIQ(current);
      if (step >= steps) {
        setDisplayIQ(target);
        prevIQ.current = target;
        clearInterval(interval);
      }
    }, 25);
    return () => clearInterval(interval);
  }, [iqScore]);

  const sparkData = evolutionLog
    .filter(e => typeof e.iq_at_time === 'number')
    .slice(0, 50)
    .reverse()
    .map((e, i) => ({ idx: i, iq: e.iq_at_time }));

  const lastCycleStr = lastCycle
    ? new Date(lastCycle).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
    : 'Never';

  return (
    <div className="relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-card via-card to-primary/5 p-6 sm:p-8">
      <div className="absolute inset-0 bg-grid-pattern opacity-[0.03]" style={{
        backgroundImage: 'linear-gradient(hsl(0 100% 50% / 0.5) 1px, transparent 1px), linear-gradient(90deg, hsl(0 100% 50% / 0.5) 1px, transparent 1px)',
        backgroundSize: '40px 40px'
      }} />
      <div className="relative flex flex-col lg:flex-row gap-6 items-start lg:items-center justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <div className="relative">
              <Brain className="w-7 h-7 text-primary" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex rounded-full h-3 w-3 bg-primary" />
              </span>
            </div>
            <span className="text-xs font-bold uppercase tracking-widest text-primary animate-pulse">Brain Active</span>
          </div>
          <div className="flex items-baseline gap-3">
            <span className="text-5xl sm:text-7xl font-bold font-poppins tabular-nums bg-gradient-to-br from-foreground to-primary bg-clip-text text-transparent">
              {displayIQ.toLocaleString()}
            </span>
            <span className="text-lg font-semibold text-muted-foreground">IQ</span>
          </div>
          <div className="mt-1 h-16 w-full max-w-xs">
            {sparkData.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={sparkData}>
                  <defs>
                    <linearGradient id="iqGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="hsl(0 100% 50%)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="hsl(0 100% 50%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="iq" stroke="hsl(0 100% 50%)" strokeWidth={2} fill="url(#iqGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-xs text-muted-foreground/50 pt-4">Collecting data for growth chart...</p>
            )}
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 lg:gap-6">
          <Stat icon={Zap} label="Signals" value={signalsCount} />
          <Stat icon={BookOpen} label="Playbooks" value={playbooksCount} />
          <Stat icon={Activity} label="Last Cycle" value={lastCycleStr} small />
        </div>
      </div>
    </div>
  );
}

function Stat({ icon: IconComp, label, value, small }) {
  return (
    <div className="text-center">
      <IconComp className="w-4 h-4 text-muted-foreground mx-auto mb-1" />
      <p className={`font-bold font-poppins ${small ? 'text-[10px]' : 'text-xl'} text-foreground`}>{value}</p>
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</p>
    </div>
  );
}