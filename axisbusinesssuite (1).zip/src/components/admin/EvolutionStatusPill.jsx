import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Activity, Sparkles } from 'lucide-react';

// ── Evolution Status Pill ───────────────────────────────────────────────────
// Shows live status of AXIS AI's autonomous evolution engine:
//   idle (green) | researching (blue) | awaiting_window (amber) | deploying (red pulse) | complete (green)
//
// Polls the latest AIAutomationLog evolution_cycle entry + EvolutionBacklog status
// to determine the current state. Updates every 15 seconds.
// ──────────────────────────────────────────────────────────────────────────────

const STATUS_CONFIG = {
  idle: {
    label: 'Evolution: Idle',
    className: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    dotClass: 'bg-emerald-500',
    pulse: false
  },
  researching: {
    label: 'Evolution: Researching',
    className: 'bg-blue-500/10 border-blue-500/30 text-blue-400',
    dotClass: 'bg-blue-500',
    pulse: false
  },
  awaiting_window: {
    label: 'Evolution: Awaiting Window',
    className: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    dotClass: 'bg-amber-500',
    pulse: false
  },
  deploying: {
    label: 'Evolution: Deploying',
    className: 'bg-red-500/10 border-red-500/30 text-red-400',
    dotClass: 'bg-red-500',
    pulse: true
  },
  complete: {
    label: 'Evolution: Complete',
    className: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    dotClass: 'bg-emerald-500',
    pulse: false
  }
};

export default function EvolutionStatusPill() {
  const [status, setStatus] = useState('idle');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const res = await base44.functions.invoke('trinitySystemCommand', { command: 'evolution_status' });
        if (res.data?.result?.status) {
          setStatus(res.data.result.status);
        }
      } catch (_) {
        // Fallback: check EvolutionBacklog directly
        try {
          const items = await base44.entities.EvolutionBacklog.list('-created_date', 5);
          if (items?.length > 0) {
            const latest = items[0];
            if (latest.status === 'in_progress') setStatus('deploying');
            else if (latest.status === 'awaiting_window') setStatus('awaiting_window');
            else if (latest.status === 'completed') setStatus('complete');
            else setStatus('idle');
          }
        } catch (_) {}
      }
      setLoading(false);
    };

    fetchStatus();
    const interval = setInterval(fetchStatus, 15000);
    return () => clearInterval(interval);
  }, []);

  const config = STATUS_CONFIG[status] || STATUS_CONFIG.idle;

  return (
    <div className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-xs font-medium ${config.className}`}>
      <div className={`w-1.5 h-1.5 rounded-full ${config.dotClass} ${config.pulse ? 'animate-pulse' : ''}`} />
      <Sparkles className="w-3 h-3" />
      <span className="hidden sm:inline">{config.label}</span>
      <span className="sm:hidden">Evo</span>
    </div>
  );
}