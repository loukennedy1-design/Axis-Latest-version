import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Save, Loader2, CheckCircle2, Phone, Calendar, Video, CreditCard, Globe, Plug, ExternalLink, Key, Eye, EyeOff, Shield, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';

export default function ConsoleApiKeysPanel() {
  const qc = useQueryClient();
  const { user } = useCurrentUser();
  const [credentials, setCredentials] = useState({});
  const [recordId, setRecordId] = useState(null);
  const [showSecrets, setShowSecrets] = useState({});
  const [secretStatus, setSecretStatus] = useState({});
  const [saved, setSaved] = useState(false);

  const { data: records = [], isLoading } = useQuery({
    queryKey: ['system-settings-api', user?.email],
    queryFn: () => base44.entities.SystemSettings.filter({ key: `global_${user.email}`, owner: user.email }),
    enabled: !!user?.email,
  });

  const { data: healthData } = useQuery({
    queryKey: ['governance-health'],
    queryFn: async () => {
      const res = await base44.functions.invoke('axisGovernanceCore', { action: 'health_check' });
      return res.data;
    },
    refetchInterval: 60000,
  });

  useEffect(() => {
    if (healthData?.secrets) setSecretStatus(healthData.secrets);
  }, [healthData]);

  useEffect(() => {
    if (records.length > 0) {
      const r = records[0];
      setRecordId(r.id);
      setCredentials({
        twilio_account_sid: r.twilio_account_sid || '',
        twilio_auth_token: r.twilio_auth_token || '',
        twilio_phone_number: r.twilio_phone_number || '',
        calendly_api_key: r.calendly_api_key || '',
        calendly_event_url: r.calendly_event_url || '',
        calendly_event_type_uri: r.calendly_event_type_uri || '',
        zoom_account_id: r.zoom_account_id || '',
        zoom_client_id: r.zoom_client_id || '',
        zoom_client_secret: r.zoom_client_secret || '',
        custom_api_name: r.custom_api_name || '',
        custom_api_endpoint: r.custom_api_endpoint || '',
        custom_api_key: r.custom_api_key || '',
      });
    }
  }, [records]);

  const saveMut = useMutation({
    mutationFn: async () => {
      const payload = { key: `global_${user.email}`, owner: user.email, ...credentials };
      return recordId
        ? base44.entities.SystemSettings.update(recordId, payload)
        : base44.entities.SystemSettings.create(payload);
    },
    onSuccess: (result) => {
      if (!recordId && result?.id) setRecordId(result.id);
      qc.invalidateQueries({ queryKey: ['system-settings-api'] });
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      toast.success('All API credentials saved');
    },
    onError: (e) => toast.error('Save failed: ' + e.message),
  });

  const set = (key, val) => setCredentials(s => ({ ...s, [key]: val }));
  const toggleShow = (key) => setShowSecrets(s => ({ ...s, [key]: !s[key] }));

  const appSecrets = [
    { name: 'SQUARE_API_KEY', label: 'Square API Key', Icon: CreditCard },
    { name: 'SQUARE_LOCATION_ID', label: 'Square Location ID', Icon: CreditCard },
    { name: 'GOOGLE_OAUTH_CLIENT_ID', label: 'Google OAuth Client ID', Icon: Globe },
    { name: 'google_oauth_client_secret', label: 'Google OAuth Secret', Icon: Globe },
    { name: 'APP_URL', label: 'App URL', Icon: Globe },
    { name: 'BILLING_EMAIL', label: 'Billing Email', Icon: CreditCard },
  ];

  if (isLoading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  const renderSecretField = (key, label, placeholder, Icon) => (
    <div key={key}>
      <Label className="flex items-center gap-1.5"><Icon className="w-3.5 h-3.5" />{label}</Label>
      <div className="relative">
        <Input
          type={showSecrets[key] ? 'text' : 'password'}
          value={credentials[key] || ''}
          onChange={e => set(key, e.target.value)}
          placeholder={placeholder}
          className="pr-20"
        />
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          <button type="button" onClick={() => toggleShow(key)} className="p-1 text-muted-foreground hover:text-foreground" title="Show/Hide">
            {showSecrets[key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
          </button>
          {credentials[key] && (
            <button type="button" onClick={() => set(key, '')} className="p-1 text-muted-foreground hover:text-red-400" title="Delete value">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between sticky top-0 z-10 bg-background/80 backdrop-blur py-2">
        <p className="text-sm text-muted-foreground">Update all API credentials in one place — saves to your account settings.</p>
        <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
          {saveMut.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
            : saved ? <><CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />Saved!</>
            : <><Save className="w-4 h-4 mr-2" />Save All Credentials</>}
        </Button>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Key className="w-4 h-4" />Integration Credentials</CardTitle></CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-3">
            <div className="flex items-center gap-2"><Phone className="w-4 h-4 text-blue-500" /><h4 className="text-sm font-semibold">Twilio (Calls & SMS)</h4></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {renderSecretField('twilio_account_sid', 'Account SID', 'ACxxxxxxxxxxxx', Phone)}
              {renderSecretField('twilio_auth_token', 'Auth Token', 'Your token...', Phone)}
              {renderSecretField('twilio_phone_number', 'Phone Number', '+15550001234', Phone)}
            </div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center gap-2"><Calendar className="w-4 h-4 text-emerald-500" /><h4 className="text-sm font-semibold">Calendly</h4></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {renderSecretField('calendly_api_key', 'Personal Access Token', 'eyJhbGci...', Calendar)}
              <div><Label className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />Event URL</Label>
                <Input value={credentials.calendly_event_url || ''} onChange={e => set('calendly_event_url', e.target.value)} placeholder="https://calendly.com/yourname/30min" />
              </div>
              <div className="md:col-span-2"><Label className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />Event Type URI</Label>
                <Input value={credentials.calendly_event_type_uri || ''} onChange={e => set('calendly_event_type_uri', e.target.value)} placeholder="https://api.calendly.com/event_types/..." />
              </div>
            </div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center gap-2"><Video className="w-4 h-4 text-purple-500" /><h4 className="text-sm font-semibold">Zoom</h4></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {renderSecretField('zoom_account_id', 'Account ID', 'Your account ID', Video)}
              {renderSecretField('zoom_client_id', 'Client ID', 'Your client ID', Video)}
              {renderSecretField('zoom_client_secret', 'Client Secret', 'Your secret...', Video)}
            </div>
          </div>
          <Separator />
          <div className="space-y-3">
            <div className="flex items-center gap-2"><Plug className="w-4 h-4 text-amber-500" /><h4 className="text-sm font-semibold">Custom Calling API</h4></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div><Label>API Name</Label><Input value={credentials.custom_api_name || ''} onChange={e => set('custom_api_name', e.target.value)} placeholder="My Calling Service" /></div>
              <div className="md:col-span-2"><Label>Endpoint URL</Label><Input value={credentials.custom_api_endpoint || ''} onChange={e => set('custom_api_endpoint', e.target.value)} placeholder="https://api.example.com/call" /></div>
              {renderSecretField('custom_api_key', 'API Key', 'Your key...', Plug)}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><Shield className="w-4 h-4" />Platform Secrets (App-Level)</CardTitle>
            <Badge variant="outline" className="text-xs text-muted-foreground">Managed in Dashboard → Settings → Secrets</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground mb-4">These secrets power billing and authentication across the entire platform. Update them in your Base44 dashboard under Settings → Environment Variables.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {appSecrets.map(secret => {
              const status = secretStatus[secret.name] || { configured: false };
              const Icon = secret.Icon;
              return (
                <div key={secret.name} className={`flex items-center gap-3 p-3 rounded-lg border ${status.configured ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
                  <Icon className={`w-4 h-4 ${status.configured ? 'text-emerald-500' : 'text-red-500'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-mono font-medium truncate">{secret.label}</p>
                    <p className="text-[10px] text-muted-foreground">{status.configured ? '✓ Configured' : '⚠ Not set'}</p>
                  </div>
                  {status.configured
                    ? <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[10px]">Active</Badge>
                    : <Badge className="bg-red-500/10 text-red-600 border-red-500/30 text-[10px]">Missing</Badge>}
                </div>
              );
            })}
          </div>
          <a href="https://app.base44.com/dashboard/settings" target="_blank" rel="noopener noreferrer" className="inline-block mt-4">
            <Button variant="outline" size="sm"><ExternalLink className="w-3.5 h-3.5 mr-1.5" />Open Dashboard Secrets</Button>
          </a>
        </CardContent>
      </Card>
    </div>
  );
}