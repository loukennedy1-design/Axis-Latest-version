import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Shield, Bot, Crown, Search, RefreshCw, Lock, Activity, AlertTriangle,
  CheckCircle2, XCircle, Clock
} from 'lucide-react';
import { format } from 'date-fns';

const SOURCE_FILTERS = [
  { id: 'all', label: 'All', icon: Activity },
  { id: 'security', label: 'Security & Compliance', icon: Shield },
  { id: 'ai', label: 'AI & Automations', icon: Bot },
  { id: 'admin', label: 'Admin Actions', icon: Crown },
  { id: 'billing', label: 'Billing & Entity', icon: Lock },
];

const SEVERITY_STYLES = {
  info: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  low: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  medium: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  high: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  critical: 'bg-red-500/10 text-red-400 border-red-500/20',
};

const SOURCE_STYLES = {
  security: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  ai: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
  admin: 'bg-primary/10 text-primary border-primary/20',
  billing: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
};

function parseJsonDetails(val) {
  if (!val) return '';
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      try { return JSON.stringify(JSON.parse(trimmed), null, 2); } catch (_) { return val; }
    }
    return val;
  }
  try { return JSON.stringify(val, null, 2); } catch (_) { return String(val); }
}

export default function UnifiedAuditLog({ sessionLog = [] }) {
  const [filter, setFilter] = useState('all');
  const [query, setQuery] = useState('');

  const { data: complianceLogs = [], refetch: refetchCompliance, isFetching: fetchingC } = useQuery({
    queryKey: ['auditComplianceLogs'],
    queryFn: () => base44.entities.ComplianceLog.list('-created_date', 200).catch(() => []),
  });
  const { data: aiLogs = [], refetch: refetchAi, isFetching: fetchingA } = useQuery({
    queryKey: ['auditAiLogs'],
    queryFn: () => base44.entities.AIAutomationLog.list('-created_date', 200).catch(() => []),
  });
  const { data: payments = [], refetch: refetchPay, isFetching: fetchingP } = useQuery({
    queryKey: ['auditPayments'],
    queryFn: () => base44.entities.PaymentTransaction.list('-created_date', 100).catch(() => []),
  });

  const refreshAll = () => { refetchCompliance(); refetchAi(); refetchPay(); };

  const entries = useMemo(() => {
    const merged = [];

    // Security / Compliance logs
    for (const c of complianceLogs) {
      merged.push({
        id: c.id,
        ts: c.created_date,
        source: 'security',
        sourceLabel: 'Security / Compliance',
        category: c.event_type || c.compliance_type || 'security_audit',
        severity: c.severity || (c.event_type === 'security_audit' ? 'medium' : 'info'),
        actor: c.owner || c.action_by || 'system',
        action: (c.event_type || 'event').replace(/_/g, ' '),
        details: c.description || '',
        status: c.status,
      });
    }

    // AI / Automation logs
    for (const a of aiLogs) {
      merged.push({
        id: a.id,
        ts: a.created_date || a.executed_at,
        source: 'ai',
        sourceLabel: 'AI / Automation',
        category: a.automation_type || 'automation',
        severity: a.risk_level || 'low',
        actor: a.owner || a.approved_by || 'trinity',
        action: a.action_taken || a.automation_type || 'automation_run',
        details: a.execution_result || a.error_message || a.governance_checks || '',
        status: a.execution_status,
      });
    }

    // Billing / Entity logs (payment transactions as billing audit trail)
    for (const p of payments) {
      merged.push({
        id: p.id,
        ts: p.created_date || p.transaction_date,
        source: 'billing',
        sourceLabel: 'Billing / Payment',
        category: p.transaction_type || 'payment',
        severity: p.status === 'failed' ? 'high' : p.status === 'refunded' ? 'medium' : 'info',
        actor: p.owner || p.customer_email || 'system',
        action: `${p.status || 'transaction'} · ${p.amount != null ? `$${Number(p.amount).toFixed(2)}` : ''} ${p.gateway ? `(${p.gateway})` : ''}`.trim(),
        details: p.notes || (p.customer_name ? `Customer: ${p.customer_name}` : ''),
        status: p.status,
      });
    }

    // In-session admin actions (transient)
    for (const s of sessionLog) {
      merged.push({
        id: `session-${s.timestamp?.getTime?.() || s.timestamp}`,
        ts: s.timestamp,
        source: 'admin',
        sourceLabel: 'Admin Action',
        category: s.action || 'admin_action',
        severity: 'info',
        actor: s.admin || 'super_admin',
        action: (s.action || '').replace(/_/g, ' '),
        details: s.details || '',
        status: 'executed',
      });
    }

    merged.sort((a, b) => new Date(b.ts || 0) - new Date(a.ts || 0));
    return merged;
  }, [complianceLogs, aiLogs, payments, sessionLog]);

  const filtered = useMemo(() => {
    let list = entries;
    if (filter !== 'all') list = list.filter(e => e.source === filter);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(e =>
        (e.action || '').toLowerCase().includes(q) ||
        (e.details || '').toLowerCase().includes(q) ||
        (e.actor || '').toLowerCase().includes(q) ||
        (e.category || '').toLowerCase().includes(q)
      );
    }
    return list;
  }, [entries, filter, query]);

  const counts = useMemo(() => ({
    all: entries.length,
    security: entries.filter(e => e.source === 'security').length,
    ai: entries.filter(e => e.source === 'ai').length,
    admin: entries.filter(e => e.source === 'admin').length,
    billing: entries.filter(e => e.source === 'billing').length,
  }), [entries]);

  const fetching = fetchingC || fetchingA || fetchingP;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="w-5 h-5 text-primary" />
            Unified Audit Log
            <Badge variant="outline" className="ml-1 text-xs">{entries.length} events</Badge>
          </CardTitle>
          <Button size="sm" variant="outline" onClick={refreshAll} disabled={fetching} className="gap-1.5">
            <RefreshCw className={`w-3.5 h-3.5 ${fetching ? 'animate-spin' : ''}`} /> Refresh
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          Unified trail across security &amp; compliance, AI/automation runs, billing transactions, and admin actions.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Source filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {SOURCE_FILTERS.map(f => {
            const active = filter === f.id;
            return (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${active ? 'bg-primary text-primary-foreground border-primary' : 'border-border bg-muted/30 text-muted-foreground hover:text-foreground'}`}
              >
                <f.icon className="w-3.5 h-3.5" />
                {f.label}
                <span className={`ml-1 px-1.5 rounded-full text-[10px] ${active ? 'bg-primary-foreground/20' : 'bg-muted'}`}>{counts[f.id] ?? 0}</span>
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
          <Input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search actor, action, details…"
            className="pl-9 h-9 text-sm"
          />
        </div>

        {/* Timeline */}
        <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
          {filtered.length === 0 ? (
            <div className="py-10 text-center text-sm text-muted-foreground">
              <Clock className="w-8 h-8 mx-auto mb-2 text-muted-foreground/40" />
              No audit events match the current filter.
            </div>
          ) : filtered.map((e, idx) => (
            <div key={e.id || idx} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/30 hover:bg-muted/50 transition-colors">
              <div className="flex flex-col items-center pt-0.5">
                <div className="w-7 h-7 rounded-full flex items-center justify-center border" style={{}}>
                  {e.source === 'security' && <Shield className="w-3.5 h-3.5 text-amber-400" />}
                  {e.source === 'ai' && <Bot className="w-3.5 h-3.5 text-violet-400" />}
                  {e.source === 'admin' && <Crown className="w-3.5 h-3.5 text-primary" />}
                  {e.source === 'billing' && <Lock className="w-3.5 h-3.5 text-emerald-400" />}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium capitalize">{e.action}</span>
                  <Badge variant="outline" className={`text-[10px] ${SOURCE_STYLES[e.source] || ''}`}>{e.sourceLabel}</Badge>
                  {e.severity && e.severity !== 'info' && (
                    <Badge variant="outline" className={`text-[10px] capitalize ${SEVERITY_STYLES[e.severity] || ''}`}>{e.severity}</Badge>
                  )}
                  {e.status === 'failed' || e.status === 'error' ? (
                    <XCircle className="w-3.5 h-3.5 text-red-400" />
                  ) : (e.status === 'executed' || e.status === 'success' || e.status === 'approved') ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : e.status === 'blocked' ? (
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  ) : null}
                </div>
                {e.details && (
                  <pre className="mt-1.5 text-xs text-muted-foreground whitespace-pre-wrap break-words font-sans max-h-24 overflow-y-auto">
                    {parseJsonDetails(e.details)}
                  </pre>
                )}
                <div className="mt-1.5 flex items-center gap-2 text-[10px] text-muted-foreground">
                  <span className="font-mono">{e.actor}</span>
                  <span>·</span>
                  <span>{e.ts ? format(new Date(e.ts), 'MMM d, yyyy · HH:mm:ss') : '—'}</span>
                  {e.category && (<><span>·</span><span className="capitalize">{e.category.replace(/_/g, ' ')}</span></>)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}