import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save, Loader2, CheckCircle2, Globe, Phone, Bot, Layers, Lock, Zap, Shield } from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { ALL_MODULES, DEFAULT_ENABLED_MODULES } from '@/lib/pricing';

const TIMEZONES = [
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Phoenix', 'America/Los_Angeles',
  'America/Anchorage', 'Pacific/Honolulu', 'America/Toronto', 'America/Vancouver',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo',
  'Australia/Sydney', 'Pacific/Auckland',
];

export default function ConsoleSystemPanel() {
  const qc = useQueryClient();
  const { user } = useCurrentUser();
  const [settings, setSettings] = useState({
    company_name: '', caller_id_number: '', default_timezone: 'America/New_York',
    enable_call_recording: true, enable_voicemail: true,
    bot_max_attempts: 3, bot_call_gap_seconds: 5, bot_require_consent: true, bot_auto_dnc: true,
    bot_voice: 'professional', bot_agent_name: '', bot_personality_style: 'consultative',
  });
  const [enabledModules, setEnabledModules] = useState(DEFAULT_ENABLED_MODULES);
  const [recordId, setRecordId] = useState(null);
  const [saved, setSaved] = useState(false);

  const { data: records = [], isLoading } = useQuery({
    queryKey: ['system-settings-sys', user?.email],
    queryFn: () => base44.entities.SystemSettings.filter({ key: `global_${user.email}`, owner: user.email }),
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (records.length > 0) {
      const r = records[0];
      setRecordId(r.id);
      setSettings({
        company_name: r.company_name || '', caller_id_number: r.caller_id_number || '',
        default_timezone: r.default_timezone || 'America/New_York',
        enable_call_recording: r.enable_call_recording ?? true, enable_voicemail: r.enable_voicemail ?? true,
        bot_max_attempts: r.bot_max_attempts || 3, bot_call_gap_seconds: r.bot_call_gap_seconds || 5,
        bot_require_consent: r.bot_require_consent ?? true, bot_auto_dnc: r.bot_auto_dnc ?? true,
        bot_voice: r.bot_voice || 'professional', bot_agent_name: r.bot_agent_name || '',
        bot_personality_style: r.bot_personality_style || 'consultative',
      });
      if (r.enabled_modules) { try { setEnabledModules(JSON.parse(r.enabled_modules)); } catch {} }
    }
  }, [records]);

  const saveMut = useMutation({
    mutationFn: async () => {
      const payload = { key: `global_${user.email}`, owner: user.email, ...settings, enabled_modules: JSON.stringify(enabledModules) };
      return recordId ? base44.entities.SystemSettings.update(recordId, payload) : base44.entities.SystemSettings.create(payload);
    },
    onSuccess: (result) => {
      if (!recordId && result?.id) setRecordId(result.id);
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      window.dispatchEvent(new Event('axis-sidebar-updated'));
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      toast.success('System settings saved');
    },
    onError: (e) => toast.error('Save failed: ' + e.message),
  });

  const set = (key, val) => setSettings(s => ({ ...s, [key]: val }));

  if (isLoading) return <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-end sticky top-0 z-10 bg-background/80 backdrop-blur py-2">
        <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
          {saveMut.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
            : saved ? <><CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />Saved!</>
            : <><Save className="w-4 h-4 mr-2" />Save System Settings</>}
        </Button>
      </div>

      {/* General */}
      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Globe className="w-4 h-4" />General</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div><Label>Company Name</Label><Input value={settings.company_name} onChange={e => set('company_name', e.target.value)} placeholder="Your Company" /></div>
          <div><Label>Default Timezone</Label>
            <Select value={settings.default_timezone} onValueChange={v => set('default_timezone', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent className="max-h-60">{TIMEZONES.map(tz => <SelectItem key={tz} value={tz}>{tz.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div><Label>Caller ID Number</Label><Input value={settings.caller_id_number} onChange={e => set('caller_id_number', e.target.value)} placeholder="+15550001234" /></div>
          <div><Label>AI Agent Name</Label><Input value={settings.bot_agent_name} onChange={e => set('bot_agent_name', e.target.value)} placeholder="AXIS Assistant" /></div>
        </CardContent>
      </Card>

      {/* Calling */}
      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Phone className="w-4 h-4" />Calling & Compliance</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <div className="flex items-center justify-between p-3 border rounded-lg"><Label className="mb-0">Call Recording</Label><Switch checked={settings.enable_call_recording} onCheckedChange={v => set('enable_call_recording', v)} /></div>
          <div className="flex items-center justify-between p-3 border rounded-lg"><Label className="mb-0">Voicemail Drop</Label><Switch checked={settings.enable_voicemail} onCheckedChange={v => set('enable_voicemail', v)} /></div>
          <div className="flex items-center justify-between p-3 border rounded-lg"><Label className="mb-0 flex items-center gap-2"><Shield className="w-3.5 h-3.5 text-emerald-500" />Require TCPA Consent</Label><Switch checked={settings.bot_require_consent} onCheckedChange={v => set('bot_require_consent', v)} /></div>
          <div className="flex items-center justify-between p-3 border rounded-lg"><Label className="mb-0">Auto-add DNC Requests</Label><Switch checked={settings.bot_auto_dnc} onCheckedChange={v => set('bot_auto_dnc', v)} /></div>
        </CardContent>
      </Card>

      {/* Bot */}
      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><Bot className="w-4 h-4" />AI Bot Config</CardTitle></CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div><Label>Max Call Attempts</Label><Input type="number" value={settings.bot_max_attempts} onChange={e => set('bot_max_attempts', parseInt(e.target.value))} /></div>
          <div><Label>Pause Between Calls (s)</Label><Input type="number" value={settings.bot_call_gap_seconds} onChange={e => set('bot_call_gap_seconds', parseInt(e.target.value))} /></div>
          <div><Label>Voice Style</Label>
            <Select value={settings.bot_voice} onValueChange={v => set('bot_voice', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {['professional', 'friendly', 'energetic', 'calm', 'assertive', 'conversational'].map(v => <SelectItem key={v} value={v} className="capitalize">{v}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-3"><Label>Personality Style</Label>
            <Select value={settings.bot_personality_style} onValueChange={v => set('bot_personality_style', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {['consultative', 'challenger', 'solution_seller', 'relationship_builder', 'direct_closer'].map(v => <SelectItem key={v} value={v} className="capitalize">{v.replace(/_/g, ' ')}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Module Features */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2"><Layers className="w-4 h-4" />Feature Modules</CardTitle>
            <div className="flex gap-2">
              <button className="text-xs text-primary underline" onClick={() => setEnabledModules(ALL_MODULES.map(m => m.id))}>Enable All</button>
              <span className="text-muted-foreground text-xs">·</span>
              <button className="text-xs text-muted-foreground underline" onClick={() => setEnabledModules(DEFAULT_ENABLED_MODULES)}>Reset</button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {ALL_MODULES.map(mod => {
            const isOn = enabledModules.includes(mod.id);
            const isBasic = mod.tier === 'basic';
            return (
              <div key={mod.id} className={`flex items-center justify-between p-2.5 rounded-lg border ${isOn ? 'border-primary/20 bg-primary/5' : 'border-border bg-muted/20'}`}>
                <div className="flex items-center gap-2.5">
                  {isBasic ? <Lock className="w-3.5 h-3.5 text-emerald-500" /> : <Zap className={`w-3.5 h-3.5 ${isOn ? 'text-primary' : 'text-muted-foreground'}`} />}
                  <div>
                    <p className={`text-sm font-medium ${!isOn ? 'text-muted-foreground' : ''}`}>{mod.label}</p>
                    <p className="text-[10px] text-muted-foreground">{mod.desc}</p>
                  </div>
                </div>
                <Switch checked={isOn} onCheckedChange={v => setEnabledModules(prev => v ? [...prev, mod.id] : prev.filter(id => id !== mod.id))} />
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}