import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Mail, Save, Loader2, CheckCircle2, AlertTriangle, Eye, EyeOff, Server, PlugZap } from 'lucide-react';
import { toast } from 'sonner';

export default function SystemEmailConfig() {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    email_address: '',
    password: '',
    display_name: '',
    reply_to: '',
    smtp_host: 'mail.doroyal.com',
    smtp_port: 465,
    imap_host: 'mail.doroyal.com',
    imap_port: 993,
    use_ssl: true,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [testing, setTesting] = useState(false);
  const [hasPassword, setHasPassword] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ['system-email-config'],
    queryFn: async () => {
      const res = await base44.functions.invoke('systemEmailConfig', { action: 'get' });
      return res.data;
    },
  });

  useEffect(() => {
    if (data?.config) {
      const c = data.config;
      setForm(f => ({
        email_address: c.email_address || '',
        password: '',
        display_name: c.display_name || '',
        reply_to: c.reply_to || '',
        smtp_host: c.smtp_host || 'mail.doroyal.com',
        smtp_port: c.smtp_port || 465,
        imap_host: c.imap_host || 'mail.doroyal.com',
        imap_port: c.imap_port || 993,
        use_ssl: c.use_ssl !== false,
      }));
      setHasPassword(!!c.has_password);
    }
  }, [data]);

  const configured = !!data?.configured;

  const handleChange = (field, value) => setForm(f => ({ ...f, [field]: value }));

  const handleTest = async () => {
    if (!form.smtp_host || !form.email_address) {
      toast.error('SMTP host and email address are required to test.');
      return;
    }
    if (!form.password && !hasPassword) {
      toast.error('Enter a password before testing.');
      return;
    }
    setTesting(true);
    try {
      const payload = {
        system_email: true,
        host: form.smtp_host,
        port: Number(form.smtp_port) || 465,
        ssl: form.use_ssl,
        email_address: form.email_address,
      };
      if (form.password) payload.password = form.password;
      const res = await base44.functions.invoke('testSmtpConnection', payload);
      const result = res.data;
      if (result.success) {
        toast.success(result.message || 'SMTP connection verified successfully.');
      } else {
        toast.error(result.error || 'Connection test failed.');
      }
    } catch (err) {
      const msg = err?.response?.data?.error || err?.response?.data?.message || err?.message || 'Connection test failed';
      toast.error(msg);
    } finally {
      setTesting(false);
    }
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = { ...form, action: 'save' };
      if (!form.password && hasPassword) payload.keep_existing_password = true;
      const res = await base44.functions.invoke('systemEmailConfig', payload);
      return res.data;
    },
    onSuccess: () => {
      toast.success('System email configuration saved.');
      qc.invalidateQueries({ queryKey: ['system-email-config'] });
    },
    onError: (err) => {
      toast.error(err?.response?.data?.error || err?.message || 'Failed to save configuration.');
    },
  });

  const handleSave = () => {
    if (!form.email_address) { toast.error('Email address is required.'); return; }
    if (!form.smtp_host) { toast.error('SMTP host is required.'); return; }
    if (!form.password && !hasPassword) { toast.error('Password is required.'); return; }
    saveMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Warning banner when not configured */}
      {!configured && (
        <div className="flex items-start gap-3 rounded-xl border border-yellow-500/30 bg-yellow-500/10 p-4">
          <AlertTriangle className="w-5 h-5 text-yellow-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-yellow-500">System email not configured</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Platform-generated emails (welcome messages, invoices, alerts, HR invites) need a system-level email account to send reliably.
              Configure your cPanel/Roundcube SMTP credentials below.
            </p>
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
                <Server className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle className="flex items-center gap-2">
                  System Email
                  {configured ? (
                    <Badge className="bg-green-500/15 text-green-500 border-green-500/30 hover:bg-green-500/15">
                      <CheckCircle2 className="w-3 h-3 mr-1" />Connected
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-yellow-500 border-yellow-500/30">
                      Not configured
                    </Badge>
                  )}
                </CardTitle>
                <CardDescription className="text-xs mt-0.5">
                  cPanel/Roundcube SMTP credentials that power all platform-generated emails
                </CardDescription>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          {/* Sender Details */}
          <div className="space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sender</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">Email Address</Label>
                <Input
                  type="email"
                  value={form.email_address}
                  onChange={e => handleChange('email_address', e.target.value)}
                  placeholder="noreply@doroyal.com"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Password</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={form.password}
                    onChange={e => handleChange('password', e.target.value)}
                    placeholder={hasPassword ? '•••••••• (saved)' : 'Enter password'}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(s => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Display Name</Label>
                <Input
                  value={form.display_name}
                  onChange={e => handleChange('display_name', e.target.value)}
                  placeholder="Axis Business Suite"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Reply-To (optional)</Label>
                <Input
                  value={form.reply_to}
                  onChange={e => handleChange('reply_to', e.target.value)}
                  placeholder="support@doroyal.com"
                />
              </div>
            </div>
          </div>

          {/* SMTP Server */}
          <div className="space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">SMTP (Outgoing)</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">SMTP Host</Label>
                <Input
                  value={form.smtp_host}
                  onChange={e => handleChange('smtp_host', e.target.value)}
                  placeholder="mail.doroyal.com"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">SMTP Port</Label>
                <Input
                  type="number"
                  value={form.smtp_port}
                  onChange={e => handleChange('smtp_port', e.target.value)}
                  placeholder="465"
                />
              </div>
            </div>
            <div className="flex items-center gap-2 pt-1">
              <Switch checked={form.use_ssl} onCheckedChange={v => handleChange('use_ssl', v)} />
              <Label className="text-xs cursor-pointer" onClick={() => handleChange('use_ssl', !form.use_ssl)}>
                Use SSL/TLS (port 465 = implicit SSL, port 587 = STARTTLS)
              </Label>
            </div>
          </div>

          {/* IMAP Server */}
          <div className="space-y-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">IMAP (Incoming)</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">IMAP Host</Label>
                <Input
                  value={form.imap_host}
                  onChange={e => handleChange('imap_host', e.target.value)}
                  placeholder="mail.doroyal.com"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">IMAP Port</Label>
                <Input
                  type="number"
                  value={form.imap_port}
                  onChange={e => handleChange('imap_port', e.target.value)}
                  placeholder="993"
                />
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col-reverse sm:flex-row gap-2 pt-2 border-t">
            <Button
              variant="outline"
              onClick={handleTest}
              disabled={testing}
              className="sm:w-auto"
            >
              {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <PlugZap className="w-4 h-4" />}
              Test Connection
            </Button>
            <Button
              onClick={handleSave}
              disabled={saveMutation.isPending}
              className="sm:ml-auto"
            >
              {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Configuration
            </Button>
          </div>

          {data?.configured_by && (
            <p className="text-xs text-muted-foreground">
              Last configured by {data.configured_by}
              {data.configured_at ? ` on ${new Date(data.configured_at).toLocaleString()}` : ''}
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}