import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, UserCheck, Inbox, Trash2, Loader2, Users } from 'lucide-react';
import { toast } from 'sonner';

const STATUS_COLORS = {
  new: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  contacted: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  qualified: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  appointment_set: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  not_interested: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
  do_not_call: 'bg-red-500/10 text-red-600 border-red-500/20',
};

export default function LeadAssignmentPanel() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showUnassigned, setShowUnassigned] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [assignDialog, setAssignDialog] = useState(false);
  const [assignRepEmail, setAssignRepEmail] = useState('');
  const qc = useQueryClient();

  const { data: leads = [], isLoading: loadingLeads } = useQuery({
    queryKey: ['admin-leads'],
    queryFn: () => base44.entities.Lead.list('-created_date', 500),
  });

  const { data: reps = [] } = useQuery({
    queryKey: ['admin-reps'],
    queryFn: () => base44.entities.SalesRep.list(),
  });

  const assignMut = useMutation({
    mutationFn: async ({ leadIds, repEmail }) => {
      const updates = leadIds.map(id => ({ id, assigned_to: repEmail }));
      await base44.entities.Lead.bulkUpdate(updates);
    },
    onSuccess: () => {
      toast.success(`Assigned ${selected.size} lead${selected.size > 1 ? 's' : ''} successfully`);
      qc.invalidateQueries({ queryKey: ['admin-leads'] });
      setSelected(new Set());
      setAssignDialog(false);
      setAssignRepEmail('');
    },
    onError: (e) => toast.error('Assignment failed: ' + e.message),
  });

  const deleteMut = useMutation({
    mutationFn: async (leadId) => base44.entities.Lead.delete(leadId),
    onSuccess: () => {
      toast.success('Lead deleted');
      qc.invalidateQueries({ queryKey: ['admin-leads'] });
    },
    onError: (e) => toast.error('Delete failed: ' + e.message),
  });

  const filtered = leads.filter(l => {
    if (showUnassigned && l.assigned_to) return false;
    if (statusFilter !== 'all' && l.status !== statusFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      return `${l.first_name} ${l.last_name} ${l.phone} ${l.company || ''} ${l.email || ''}`.toLowerCase().includes(q);
    }
    return true;
  });

  const unassignedCount = leads.filter(l => !l.assigned_to).length;

  const toggleSelect = (id) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selected.size === filtered.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(filtered.map(l => l.id)));
    }
  };

  const repByEmail = (email) => reps.find(r => r.email === email);

  return (
    <div className="space-y-4">
      {/* Stats + Actions */}
      <div className="flex items-center gap-3 flex-wrap">
        <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/30 gap-1.5"><Users className="w-3.5 h-3.5" />{leads.length} Total Leads</Badge>
        <Badge className="bg-amber-500/10 text-amber-400 border-amber-500/30 gap-1.5"><Inbox className="w-3.5 h-3.5" />{unassignedCount} Unassigned</Badge>
        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 gap-1.5">{reps.length} Reps</Badge>

        {selected.size > 0 && (
          <Button size="sm" className="ml-auto gap-2" onClick={() => setAssignDialog(true)}>
            <UserCheck className="w-4 h-4" /> Assign {selected.size} Selected
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search leads..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[140px] h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="new">New</SelectItem>
            <SelectItem value="contacted">Contacted</SelectItem>
            <SelectItem value="qualified">Qualified</SelectItem>
            <SelectItem value="appointment_set">Appointment Set</SelectItem>
            <SelectItem value="not_interested">Not Interested</SelectItem>
            <SelectItem value="do_not_call">Do Not Call</SelectItem>
          </SelectContent>
        </Select>
        <Button
          size="sm"
          variant={showUnassigned ? "default" : "outline"}
          className="gap-1.5"
          onClick={() => { setShowUnassigned(!showUnassigned); setSelected(new Set()); }}
        >
          <Inbox className="w-3.5 h-3.5" /> Unassigned Only
        </Button>
      </div>

      {/* Select All */}
      {filtered.length > 0 && (
        <div className="flex items-center gap-2">
          <Checkbox checked={selected.size === filtered.length && filtered.length > 0} onCheckedChange={toggleSelectAll} />
          <span className="text-xs text-muted-foreground">
            {selected.size > 0 ? `${selected.size} selected` : 'Select all'}
          </span>
        </div>
      )}

      {/* Lead List */}
      {loadingLeads ? (
        <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : filtered.length === 0 ? (
        <Card className="p-10 text-center border-dashed">
          <p className="text-sm text-muted-foreground">No leads match your filters</p>
        </Card>
      ) : (
        <div className="space-y-1.5">
          {filtered.map(lead => {
            const rep = repByEmail(lead.assigned_to);
            const isSelected = selected.has(lead.id);
            return (
              <Card key={lead.id} className={`p-3 flex items-center gap-3 transition-colors ${isSelected ? 'border-primary/40 bg-primary/5' : 'border-border'}`}>
                <Checkbox checked={isSelected} onCheckedChange={() => toggleSelect(lead.id)} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{lead.first_name} {lead.last_name}</span>
                    <Badge variant="outline" className={`text-[10px] capitalize ${STATUS_COLORS[lead.status] || ''}`}>
                      {lead.status?.replace(/_/g, ' ')}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground">
                    <span className="font-mono">{lead.phone}</span>
                    {lead.company && <span>· {lead.company}</span>}
                    {lead.source && <span>· {lead.source}</span>}
                  </div>
                </div>
                <div className="shrink-0 w-44">
                  {lead.assigned_to ? (
                    <div className="text-right">
                      <p className="text-xs font-medium truncate">{rep?.name || lead.assigned_to}</p>
                      <p className="text-[10px] text-muted-foreground">Assigned</p>
                    </div>
                  ) : (
                    <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/20">
                      Unassigned
                    </Badge>
                  )}
                </div>
                <Select
                  value={lead.assigned_to || ''}
                  onValueChange={(v) => {
                    assignMut.mutate({ leadIds: [lead.id], repEmail: v });
                  }}
                >
                  <SelectTrigger className="w-[140px] h-8 text-xs">
                    <SelectValue placeholder="Assign to..." />
                  </SelectTrigger>
                  <SelectContent>
                    {reps.map(r => (
                      <SelectItem key={r.id} value={r.email}>{r.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                  onClick={() => { if (confirm(`Delete lead ${lead.first_name} ${lead.last_name}?`)) deleteMut.mutate(lead.id); }}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </Card>
            );
          })}
        </div>
      )}

      {/* Bulk Assign Dialog */}
      <Dialog open={assignDialog} onOpenChange={setAssignDialog}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-primary" /> Assign {selected.size} Leads
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Select Rep</label>
              <Select value={assignRepEmail} onValueChange={setAssignRepEmail}>
                <SelectTrigger><SelectValue placeholder="Choose a rep..." /></SelectTrigger>
                <SelectContent>
                  {reps.map(r => (
                    <SelectItem key={r.id} value={r.email}>{r.name} ({r.email})</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              className="w-full gap-2"
              disabled={!assignRepEmail || assignMut.isPending}
              onClick={() => assignMut.mutate({ leadIds: [...selected], repEmail: assignRepEmail })}
            >
              {assignMut.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserCheck className="w-4 h-4" />}
              Confirm Assignment
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}