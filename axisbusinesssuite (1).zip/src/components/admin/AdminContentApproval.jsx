import React, { useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  CheckCircle2, XCircle, Clock, Video, FileText, Loader2, Play, ExternalLink,
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_CONFIG = {
  pending_admin_approval: { label: 'Pending Review', color: 'bg-amber-500/10 text-amber-500 border-amber-500/20', icon: Clock },
  approved: { label: 'Approved', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-red-500/10 text-red-400 border-red-500/20', icon: XCircle },
  not_submitted: { label: 'Not Submitted', color: 'bg-muted text-muted-foreground border-border', icon: FileText },
};

function VideoApprovalCard({ video, onAction }) {
  const [notes, setNotes] = useState('');
  const [acting, setActing] = useState(false);
  const clips = video.video_clips ? safeParse(video.video_clips) : [];

  const handleAction = async (action) => {
    setActing(true);
    await onAction('video', video.id, action, notes);
    setActing(false);
    setNotes('');
  };

  return (
    <Card className="border-amber-500/20">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <Video className="w-4 h-4 text-pink-400 shrink-0" />
            <div>
              <p className="font-semibold text-sm">{video.title}</p>
              <p className="text-xs text-muted-foreground">
                by {video.submitted_by_email || video.owner || '—'} · {video.submitted_at ? format(new Date(video.submitted_at), 'MMM d, h:mm a') : ''}
              </p>
            </div>
          </div>
          <Badge className={STATUS_CONFIG.pending_admin_approval.color}>
            <Clock className="w-3 h-3 mr-1" />Pending
          </Badge>
        </div>

        {clips.length > 0 && (
          <div className="flex gap-2 overflow-x-auto">
            {clips.slice(0, 3).map((url, i) => (
              <video key={i} src={url} className="h-20 rounded-lg border border-border object-cover" controls />
            ))}
            {clips.length > 3 && <span className="text-xs text-muted-foreground self-center">+{clips.length - 3} more</span>}
          </div>
        )}

        {video.topic && <p className="text-xs text-muted-foreground">Topic: {video.topic}</p>}

        <Textarea
          placeholder="Admin feedback (optional)..."
          value={notes}
          onChange={e => setNotes(e.target.value)}
          className="text-xs min-h-[60px]"
        />

        <div className="flex gap-2">
          <Button size="sm" className="flex-1 gap-1 bg-emerald-600 hover:bg-emerald-700 text-white" disabled={acting} onClick={() => handleAction('approve')}>
            {acting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}Approve
          </Button>
          <Button size="sm" variant="outline" className="flex-1 gap-1 border-red-500/30 text-red-400 hover:bg-red-500/10" disabled={acting} onClick={() => handleAction('reject')}>
            <XCircle className="w-3.5 h-3.5" />Reject
          </Button>
          <Button size="sm" variant="ghost" onClick={() => window.open('/video-marketing', '_blank')}>
            <ExternalLink className="w-3.5 h-3.5" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function SocialPostApprovalCard({ post, onAction }) {
  const [notes, setNotes] = useState('');
  const [acting, setActing] = useState(false);

  const handleAction = async (action) => {
    setActing(true);
    await onAction('social_post', post.id, action, notes);
    setActing(false);
    setNotes('');
  };

  return (
    <Card className="border-amber-500/20">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-blue-400 shrink-0" />
            <div>
              <p className="font-semibold text-sm">{post.title || 'Untitled Post'}</p>
              <p className="text-xs text-muted-foreground">
                by {post.submitted_by_email || post.owner || '—'} · {post.submitted_at ? format(new Date(post.submitted_at), 'MMM d, h:mm a') : ''}
              </p>
            </div>
          </div>
          <Badge className={STATUS_CONFIG.pending_admin_approval.color}>
            <Clock className="w-3 h-3 mr-1" />Pending
          </Badge>
        </div>

        {post.image_url && (
          <img src={post.image_url} alt="Post" className="w-full h-32 object-cover rounded-lg border border-border" />
        )}

        <div className="bg-muted/40 rounded-lg p-3">
          <p className="text-sm whitespace-pre-wrap">{post.content?.slice(0, 200)}{post.content?.length > 200 ? '...' : ''}</p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <Badge variant="secondary" className="capitalize">{post.platform}</Badge>
          <Badge variant="outline" className="capitalize">{post.post_type}</Badge>
        </div>

        <Textarea
          placeholder="Admin feedback (optional)..."
          value={notes}
          onChange={e => setNotes(e.target.value)}
          className="text-xs min-h-[60px]"
        />

        <div className="flex gap-2">
          <Button size="sm" className="flex-1 gap-1 bg-emerald-600 hover:bg-emerald-700 text-white" disabled={acting} onClick={() => handleAction('approve')}>
            {acting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}Approve
          </Button>
          <Button size="sm" variant="outline" className="flex-1 gap-1 border-red-500/30 text-red-400 hover:bg-red-500/10" disabled={acting} onClick={() => handleAction('reject')}>
            <XCircle className="w-3.5 h-3.5" />Reject
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function safeParse(str) {
  try { return JSON.parse(str); } catch (_) { return []; }
}

export default function AdminContentApproval() {
  const qc = useQueryClient();
  const [tab, setTab] = useState('pending');

  const { data: pendingVideos = [], isLoading: loadingV } = useQuery({
    queryKey: ['pendingApprovalVideos'],
    queryFn: () => base44.asServiceRole?.entities?.VideoLibrary?.filter?.({ approval_status: 'pending_admin_approval' }, '-submitted_at', 50)
      .catch(() => base44.entities.VideoLibrary.filter({ approval_status: 'pending_admin_approval' }, '-submitted_at', 50)),
    refetchInterval: 15000,
  });

  const { data: pendingPosts = [], isLoading: loadingP } = useQuery({
    queryKey: ['pendingApprovalPosts'],
    queryFn: () => base44.asServiceRole?.entities?.SocialPost?.filter?.({ approval_status: 'pending_admin_approval' }, '-submitted_at', 50)
      .catch(() => base44.entities.SocialPost.filter({ approval_status: 'pending_admin_approval' }, '-submitted_at', 50)),
    refetchInterval: 15000,
  });

  const handleAction = useCallback(async (contentType, contentId, action, notes) => {
    try {
      const res = await base44.functions.invoke('approveRejectContent', {
        content_type: contentType,
        content_id: contentId,
        action,
        notes,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(`Content ${action === 'approve' ? 'approved' : 'rejected'}`);
      qc.invalidateQueries({ queryKey: ['pendingApprovalVideos'] });
      qc.invalidateQueries({ queryKey: ['pendingApprovalPosts'] });
    } catch (e) {
      toast.error(e.message || 'Action failed');
    }
  }, [qc]);

  const pendingCount = pendingVideos.length + pendingPosts.length;

  return (
    <div className="space-y-4">
      <Card className="border-amber-500/20 bg-amber-500/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-500">
            <Clock className="w-5 h-5" />Content Approval Queue
          </CardTitle>
          <p className="text-xs text-muted-foreground">
            All videos and marketing material submitted by users must be approved by an admin before going live.
            You'll receive a bell notification when new content is submitted.
          </p>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <Video className="w-8 h-8 text-pink-400" />
            <div>
              <p className="text-2xl font-bold">{pendingVideos.length}</p>
              <p className="text-xs text-muted-foreground">Videos Pending</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-3">
            <FileText className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-2xl font-bold">{pendingPosts.length}</p>
              <p className="text-xs text-muted-foreground">Posts Pending</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="w-full">
          <TabsTrigger value="pending" className="flex-1 gap-2">
            <Clock className="w-4 h-4" />
            Pending ({pendingCount})
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex-1 gap-2">
            <Video className="w-4 h-4" />All Videos
          </TabsTrigger>
          <TabsTrigger value="posts" className="flex-1 gap-2">
            <FileText className="w-4 h-4" />All Posts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-3 mt-4">
          {loadingV || loadingP ? (
            <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : pendingCount === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-3 opacity-20" />
              <p className="text-sm">No content pending approval — you're all caught up!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingVideos.map(v => (
                <VideoApprovalCard key={v.id} video={v} onAction={handleAction} />
              ))}
              {pendingPosts.map(p => (
                <SocialPostApprovalCard key={p.id} post={p} onAction={handleAction} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="videos" className="space-y-3 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingVideos.map(v => (
              <VideoApprovalCard key={v.id} video={v} onAction={handleAction} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="posts" className="space-y-3 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pendingPosts.map(p => (
              <SocialPostApprovalCard key={p.id} post={p} onAction={handleAction} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}