import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, XCircle, Clock, DollarSign, Users, Building2 } from 'lucide-react';
import { toast } from 'sonner';

export default function ResidualApprovalDashboard() {
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('pending');

  const { data: repCommissions, isLoading: repLoading } = useQuery({
    queryKey: ['repCommissions', activeTab],
    queryFn: async () => {
      const query = activeTab === 'all' ? {} : { status: activeTab };
      return await base44.entities.RepCommission.filter(query, '-approved_at');
    }
  });

  const { data: partnerResiduals, isLoading: partnerLoading } = useQuery({
    queryKey: ['partnerResiduals', activeTab],
    queryFn: async () => {
      const query = activeTab === 'all' ? {} : { status: activeTab };
      return await base44.entities.PartnerResidual.filter(query, '-approved_at');
    }
  });

  const approveCommissionMutation = useMutation({
    mutationFn: async ({ commissionId, type }) => {
      const commission = await base44.entities.RepCommission.get(commissionId);
      await base44.entities.RepCommission.update(commissionId, {
        status: 'approved',
        approved_by: (await base44.auth.me()).email,
        approved_at: new Date().toISOString()
      });
      
      if (commission.rep_email) {
        await base44.functions.invoke('executeAchDeposit', {
          recipient_email: commission.rep_email,
          amount: commission.net_commission,
          description: `Commission Payout - ${commission.period}`
        });
      }
      
      return commission;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['repCommissions']);
      toast.success('Commission approved and ACH queued');
    }
  });

  const approveResidualMutation = useMutation({
    mutationFn: async ({ residualId }) => {
      const residual = await base44.entities.PartnerResidual.get(residualId);
      await base44.entities.PartnerResidual.update(residualId, {
        status: 'approved',
        approved_by: (await base44.auth.me()).email,
        approved_at: new Date().toISOString()
      });
      
      const wlPartner = await base44.entities.WhiteLabel.get(residual.partner_id);
      if (wlPartner?.user_email) {
        await base44.functions.invoke('executeAchDeposit', {
          recipient_email: wlPartner.user_email,
          amount: residual.residual_amount,
          description: `Partner Residual Payout - ${residual.period}`
        });
      }
      
      return residual;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['partnerResiduals']);
      toast.success('Partner residual approved and ACH queued');
    }
  });

  const totalPendingReps = repCommissions?.filter(c => c.status === 'pending_review').reduce((sum, c) => sum + c.net_commission, 0) || 0;
  const totalPendingPartners = partnerResiduals?.filter(p => p.status === 'pending_review').reduce((sum, p) => sum + p.residual_amount, 0) || 0;

  if (repLoading || partnerLoading) {
    return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div></div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Rep Commissions</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPendingReps.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              {repCommissions?.filter(c => c.status === 'pending_review').length || 0} records awaiting approval
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Partner Residuals</CardTitle>
            <Building2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalPendingPartners.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">
              {partnerResiduals?.filter(p => p.status === 'pending_review').length || 0} records awaiting approval
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Pending Payout</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${(totalPendingReps + totalPendingPartners).toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Combined rep and partner payouts</p>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="pending">Pending Review</TabsTrigger>
          <TabsTrigger value="approved">Approved</TabsTrigger>
          <TabsTrigger value="paid">Paid</TabsTrigger>
          <TabsTrigger value="all">All Records</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Rep Commissions</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rep Name</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {repCommissions?.map((commission) => (
                    <TableRow key={commission.id}>
                      <TableCell className="font-medium">{commission.rep_name}</TableCell>
                      <TableCell>{commission.period}</TableCell>
                      <TableCell>
                        <Badge variant={commission.commission_type === 'wl_signup_bonus' ? 'secondary' : 'default'}>
                          {commission.commission_type.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>${commission.net_commission.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge variant={commission.status === 'pending_review' ? 'secondary' : commission.status === 'approved' ? 'default' : 'outline'}>
                          {commission.status.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {commission.status === 'pending_review' && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => approveCommissionMutation.mutate({ commissionId: commission.id, type: 'rep' })}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" /> Approve
                            </Button>
                          </div>
                        )}
                        {commission.status === 'approved' && (
                          <span className="text-xs text-muted-foreground">ACH Pending</span>
                        )}
                        {commission.status === 'paid' && (
                          <span className="text-xs text-muted-foreground">{commission.ach_reference}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {(!repCommissions || repCommissions.length === 0) && (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                        No commission records found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>White-Label Partner Residuals</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Partner Name</TableHead>
                    <TableHead>Period</TableHead>
                    <TableHead>Subscribers</TableHead>
                    <TableHead>Gross Revenue</TableHead>
                    <TableHead>Residual (30%)</TableHead>
                    <TableHead>License Fee</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {partnerResiduals?.map((residual) => (
                    <TableRow key={residual.id}>
                      <TableCell className="font-medium">{residual.partner_name}</TableCell>
                      <TableCell>{residual.period}</TableCell>
                      <TableCell>{residual.total_downstream_subscribers}</TableCell>
                      <TableCell>${residual.gross_subscriber_revenue.toFixed(2)}</TableCell>
                      <TableCell>${residual.residual_amount.toFixed(2)}</TableCell>
                      <TableCell>${residual.license_fee_paid.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge variant={residual.status === 'pending_review' ? 'secondary' : residual.status === 'approved' ? 'default' : 'outline'}>
                          {residual.status.replace('_', ' ')}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {residual.status === 'pending_review' && (
                          <Button
                            size="sm"
                            onClick={() => approveResidualMutation.mutate({ residualId: residual.id })}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" /> Approve
                          </Button>
                        )}
                        {residual.status === 'paid' && (
                          <span className="text-xs text-muted-foreground">{residual.ach_reference}</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                  {(!partnerResiduals || partnerResiduals.length === 0) && (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                        No partner residual records found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}