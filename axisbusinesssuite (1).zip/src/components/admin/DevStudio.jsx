import React, { useState, useCallback } from 'react';
import { invokeDev } from '@/components/devstudio/shared';
import { Badge } from '@/components/ui/badge';
import TrinityChatPanel from '@/components/devstudio/TrinityChatPanel';
import CommandTab from '@/components/devstudio/CommandTab';
import FrontendEditorTab from '@/components/devstudio/FrontendEditorTab';
import BackendEditorTab from '@/components/devstudio/BackendEditorTab';
import EvolutionEngineTab from '@/components/devstudio/EvolutionEngineTab';
import EntityBuilderTab from '@/components/devstudio/EntityBuilderTab';
import ReleaseTab from '@/components/devstudio/ReleaseTab';
import {
  Zap, Monitor, Settings, Dna, Database, Package,
  Code2, Bot, ChevronDown, ChevronUp, X
} from 'lucide-react';

const TABS = [
  { id: 'command', label: 'Command', icon: Zap, color: 'text-violet-400' },
  { id: 'frontend', label: 'Frontend', icon: Monitor, color: 'text-emerald-400' },
  { id: 'backend', label: 'Backend', icon: Settings, color: 'text-emerald-400' },
  { id: 'evolution', label: 'Evolution', icon: Dna, color: 'text-violet-400' },
  { id: 'entity', label: 'Entity Builder', icon: Database, color: 'text-blue-400' },
  { id: 'release', label: 'Release', icon: Package, color: 'text-amber-400' }
];

function useTrinityChat() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = useCallback(async (text) => {
    if (!text.trim()) return;
    setMessages(prev => [...prev, { role: 'user', content: text, timestamp: new Date().toISOString() }]);
    setLoading(true);
    try {
      const res = await invokeDev('dev_studio_plan', { prompt: text });
      if (res.data?.error) throw new Error(res.data.error);
      let plan = res.data?.result?.plan;
      if (typeof plan === 'string') {
        try { plan = JSON.parse(plan); } catch (_) { plan = { steps: [plan], risk_level: 'low', estimated_impact: plan }; }
      }
      if (!plan) plan = { steps: [], risk_level: 'low', estimated_impact: 'No plan generated.' };
      if (typeof plan.steps === 'string') {
        plan.steps = plan.steps.split(/\n|\d+\.\s/).map(s => s.trim()).filter(Boolean);
      }
      if (!Array.isArray(plan.steps)) plan.steps = [];
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: plan.estimated_impact || 'Plan generated — review below.',
        plan,
        timestamp: new Date().toISOString()
      }]);
    } catch (e) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `Error: ${e.message}`,
        error: true,
        timestamp: new Date().toISOString()
      }]);
    }
    setLoading(false);
  }, []);

  const approvePlan = useCallback(async (messageIndex) => {
    const msg = messages[messageIndex];
    if (!msg?.plan) return;
    setMessages(prev => prev.map((m, i) => i === messageIndex ? { ...m, approving: true } : m));
    try {
      const res = await invokeDev('dev_studio_plan_approve', {
        plan_summary: msg.plan.estimated_impact || msg.content.slice(0, 200),
        risk_level: msg.plan.risk_level || 'low',
        plan: msg.plan
      });
      if (res.data?.error) throw new Error(res.data.error);
      setMessages(prev => prev.map((m, i) => i === messageIndex ? { ...m, approved: true, approving: false } : m));
    } catch (e) {
      setMessages(prev => prev.map((m, i) => i === messageIndex ? { ...m, approving: false } : m));
      throw e;
    }
  }, [messages]);

  return { messages, sendMessage, approvePlan, loading };
}

export default function DevStudio({ user }) {
  const [activeTab, setActiveTab] = useState('command');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const chat = useTrinityChat();

  const renderTab = () => {
    switch (activeTab) {
      case 'command': return <CommandTab chat={chat} />;
      case 'frontend': return <FrontendEditorTab chat={chat} />;
      case 'backend': return <BackendEditorTab chat={chat} />;
      case 'evolution': return <EvolutionEngineTab />;
      case 'entity': return <EntityBuilderTab />;
      case 'release': return <ReleaseTab chat={chat} />;
      default: return null;
    }
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center gap-3 rounded-xl border border-zinc-700 bg-zinc-900/60 px-4 py-2.5">
        <div className="w-9 h-9 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center">
          <Code2 className="w-5 h-5 text-emerald-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold flex items-center gap-2">
            Dev Studio
            <Badge variant="outline" className="text-[10px] border-emerald-500/30 text-emerald-400">AUTONOMOUS IDE</Badge>
          </p>
          <p className="text-xs text-muted-foreground truncate">Self-building platform · AXIS AI + OmniCore · Plan-first execution</p>
        </div>
        {/* Floating Trinity toggle */}
        {activeTab !== 'command' && (
          <button
            onClick={() => setDrawerOpen(!drawerOpen)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${drawerOpen ? 'bg-violet-600 text-white' : 'bg-violet-500/10 text-violet-400 hover:bg-violet-500/20 border border-violet-500/30'}`}
          >
            <Bot className="w-3.5 h-3.5" />
            AXIS AI
            {drawerOpen ? <ChevronDown className="w-3 h-3" /> : <ChevronUp className="w-3 h-3" />}
          </button>
        )}
      </div>

      {/* Tab navigation */}
      <div className="flex items-center gap-1 overflow-x-auto no-scrollbar border-b border-border pb-px">
        {TABS.map(tab => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${active ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
            >
              <Icon className={`w-3.5 h-3.5 ${active ? tab.color : ''}`} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div>{renderTab()}</div>

      {/* Floating Trinity drawer (non-Command tabs) */}
      {activeTab !== 'command' && drawerOpen && (
        <div className="fixed bottom-4 right-4 w-[380px] max-w-[calc(100vw-2rem)] h-[500px] max-h-[calc(100vh-6rem)] z-50 shadow-2xl rounded-xl overflow-hidden border border-violet-500/30">
          <div className="flex items-center justify-between px-3 py-2 bg-violet-600 text-white shrink-0">
            <div className="flex items-center gap-2">
              <Bot className="w-4 h-4" />
              <span className="text-sm font-semibold">AXIS AI Command Console</span>
            </div>
            <button onClick={() => setDrawerOpen(false)} className="hover:bg-white/20 rounded p-0.5">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="h-[calc(100%-40px)]">
            <TrinityChatPanel chat={chat} compact />
          </div>
        </div>
      )}
    </div>
  );
}