import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function TrialInviteEditDialog({ invite, open, onOpenChange, onSaved }) {
  const [form, setForm] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (invite) {
      setForm({
        status: invite.status || 'pending',
        plan_key: invite.plan_key || 'solo',
        billing_amount: invite.billing_amount ?? 0,
        billing_cycle: invite.billing_cycle || 'monthly',
        trial_end: invite.trial_end ? invite.trial_end.slice(0, 16) : '',
        trial_duration_days: invite.trial_duration_days ?? 7,
        billing_disabled: invite.billing_disabled ?? false,
        free_trial_override: invite.free_trial_override ?? false,
        notes: invite.notes || '',
        name: invite.name || '',
        email: invite.email || '',
      });
    }
  }, [invite]);

  if (!form) return null;

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        status: form.status,
        plan_key: form.plan_key,
        billing_amount: Number(form.billing_amount) || 0,
        billing_cycle: form.billing_cycle,
        billing_disabled: form.billing_disabled,
        free_trial_override: form.free_trial_override,
        notes: form.notes,
        name: form.name,
      };
      if (form.trial_end) {
        payload.trial_end = new Date(form.trial_end).toISOString();
      }
      if (form.trial_duration_days) {
        payload.trial_duration_days = Number(form.trial_duration_days);
      }
      await base44.entities.TrialInvite.update(invite.id, payload);
      toast.success('Trial invite updated');
      onSaved();
      onOpenChange(false);
    } catch (e) {
      toast.error('Failed to update: ' + e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-card border-border">
        <DialogHeader>
          <DialogTitle>Edit Trial Invite</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label>Name</Label>
            <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label>Email</Label>
            <Input value={form.email} disabled className="opacity-60" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="converted">Converted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Plan</Label>
              <Select value={form.plan_key} onValueChange={v => setForm({ ...form, plan_key: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="solo">Solo</SelectItem>
                  <SelectItem value="growth">Growth</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="enterprise">Enterprise</SelectItem>
                  <SelectItem value="agency">Agency</SelectItem>
                  <SelectItem value="movement">Movement</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Billing Amount ($)</Label>
              <Input type="number" value={form.billing_amount} onChange={e => setForm({ ...form, billing_amount: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Billing Cycle</Label>
              <Select value={form.billing_cycle} onValueChange={v => setForm({ ...form, billing_cycle: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Trial End</Label>
              <Input type="datetime-local" value={form.trial_end} onChange={e => setForm({ ...form, trial_end: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Trial Duration (days)</Label>
              <Input type="number" value={form.trial_duration_days} onChange={e => setForm({ ...form, trial_duration_days: e.target.value })} />
            </div>
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <Label>Billing Disabled</Label>
              <p className="text-xs text-muted-foreground">Admin override — user will not be charged</p>
            </div>
            <Switch checked={form.billing_disabled} onCheckedChange={v => setForm({ ...form, billing_disabled: v })} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <Label>Free Trial Override</Label>
              <p className="text-xs text-muted-foreground">Grant free access without charging</p>
            </div>
            <Switch checked={form.free_trial_override} onCheckedChange={v => setForm({ ...form, free_trial_override: v })} />
          </div>
          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea rows={3} value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? 'Saving…' : 'Save Changes'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}