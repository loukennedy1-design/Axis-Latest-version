import React, { useState, useMemo, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Search, Users, DollarSign, Zap, ShieldCheck, ShieldOff, UserCheck, UserX,
  Send, Mail, Power, ChevronRight, X, Loader2, Sparkles, UserPlus,
  Ban, CheckCircle2
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const SYSTEM_FEATURES = [
  { id: 'call_bot', label: 'AI Call Bot' },
  { id: 'lead_scoring', label: 'Lead Scoring' },
  { id: 'nurture_workflows', label: 'Nurture Workflows' },
  { id: 'coaching', label: 'Coaching Hub' },
  { id: 'lead_generator', label: 'Lead Generator' },
  { id: 'recruitment', label: 'Recruitment Module' },
  { id: 'calendly', label: 'Calendly Integration' },
  { id: 'zoom', label: 'Zoom Scheduling' },
  { id: 'email', label: 'Email Client' },
];

export default function SuperAdminUsersTab({
  users,
  trialInvites,
  currentUser,
  onTrialOpen,
}) {
  const [search, setSearch] = useState('');
  const [selectedUser, setSelectedUser] = useState(null);
  const [userFeatures, setUserFeatures] = useState({});
  const [userBilling, setUserBilling] = useState({});
  const [userBillingLoading, setUserBillingLoading] = useState(false);
  const [userBillingSaving, setUserBillingSaving] = useState(false);
  const [actionLoading, setActionLoading] = useState({});

  const filtered = useMemo(() => {
    if (!search.trim()) return users;
    const q = search.toLowerCase();
    return users.filter(u =>
      `${u.full_name || ''} ${u.email || ''}`.toLowerCase().includes(q)
    );
  }, [users, search]);

  // Load billing state when a user is selected
  useEffect(() => {
    if (!selectedUser) return;
    setUserBillingLoading(true);
    base44.functions.invoke('globalBillingToggle', { action: 'get_user', user_email: selectedUser.email })
      .then(res => {
        if (res.data) {
          setUserBilling(prev => ({ ...prev, [selectedUser.id]: {
            billing_disabled: res.data.billing_disabled === true,
            free_trial: res.data.free_trial === true,
          }}));
        }
      })
      .catch(() => {})
      .finally(() => setUserBillingLoading(false));
  }, [selectedUser]);

  const saveUserBilling = async (userId, userEmail, updates) => {
    setUserBillingSaving(true);
    const current = userBilling[userId] || {};
    const merged = { ...current, ...updates };
    setUserBilling(prev => ({ ...prev, [userId]: merged }));
    try {
      const res = await base44.functions.invoke('globalBillingToggle', {
        action: 'set_user',
        user_email: userEmail,
        billing_disabled: merged.billing_disabled === true,
        free_trial: merged.free_trial === true,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Billing settings saved');
    } catch (e) {
      toast.error('Failed to save billing settings');
    }
    setUserBillingSaving(false);
  };

  const toggleUserFeature = (userId, featureId, enabled) => {
    setUserFeatures(prev => ({ ...prev, [userId]: { ...prev[userId], [featureId]: enabled } }));
    toast.success(`Feature ${enabled ? 'enabled' : 'disabled'}`);
  };

  const runUserAction = async (actionKey, fn) => {
    setActionLoading(prev => ({ ...prev, [actionKey]: true }));
    try {
      await fn();
    } catch (e) {
      toast.error(e.message || 'Action failed');
    } finally {
      setActionLoading(prev => ({ ...prev, [actionKey]: false }));
    }
  };

  const toggleAccount = async (user) => {
    await runUserAction('toggle_' + user.id, async () => {
      await base44.entities.User.update(user.id, { subscription_disabled: !user.subscription_disabled });
      toast.success(`Account ${user.subscription_disabled ? 'enabled' : 'disabled'}`);
    });
  };

  const resendLogin = async (user) => {
    await runUserAction('resend_' + user.id, async () => {
      const res = await base44.functions.invoke('resendPendingLoginInfo', { email: user.email });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(`Login info resent to ${user.email}`);
    });
  };

  const promoteToAdmin = async (user) => {
    await runUserAction('promote_' + user.id, async () => {
      const res = await base44.functions.invoke('trinitySystemCommand', { command: 'promote_to_admin', params: { email: user.email } });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(`${user.email} promoted to admin`);
    });
  };

  const demoteFromAdmin = async (user) => {
    await runUserAction('demote_' + user.id, async () => {
      const res = await base44.functions.invoke('trinitySystemCommand', { command: 'demote_from_admin', params: { email: user.email } });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(`${user.email} demoted from admin`);
    });
  };

  const reactivateAccount = async (user) => {
    await runUserAction('reactivate_' + user.id, async () => {
      const res = await base44.functions.invoke('reactivateUserAccount', { email: user.email });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success(`${user.email} reactivated`);
    });
  };

  const trialBadge = (userEmail) => {
    const trial = trialInvites.find(t => t.email?.toLowerCase() === userEmail?.toLowerCase());
    if (!trial) return null;
    const isExpired = trial.trial_end && new Date(trial.trial_end) < new Date() && trial.status !== 'converted';
    const status = trial.status === 'converted' ? 'converted' : isExpired ? 'expired' : trial.status;
    const config = {
      converted: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      expired: 'bg-red-500/10 text-red-400 border-red-500/30',
      active: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
      pending: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    };
    return (
      <Badge variant="outline" className={`text-[10px] ${config[status] || ''}`}>
        {status}
      </Badge>
    );
  };

  return (
    <div className="space-y-4">
      {/* Free Trial Banner */}
      <Card className="border-violet-500/30 bg-violet-500/5">
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="flex items-center gap-2 text-violet-400">
                <Sparkles className="w-5 h-5" />
                Free Trial Invites
              </CardTitle>
              <p className="text-xs text-muted-foreground mt-1">Invite someone with a full-access trial — billing disabled for the entire period. They'll be prompted to add a credit card after the trial expires.</p>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {[7, 14, 30].map(d => (
                <Button key={d} className="gap-1.5 bg-violet-600 hover:bg-violet-700 text-white" onClick={() => onTrialOpen?.(d)}>
                  <UserPlus className="w-4 h-4" />{d}-Day
                </Button>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-background rounded-lg border text-center">
              <p className="text-xs text-muted-foreground">Trials Sent</p>
              <p className="text-2xl font-bold mt-1 text-violet-400">{trialInvites.filter(t => t.notes?.match(/(\d+)_day_trial/)).length}</p>
            </div>
            <div className="p-3 bg-background rounded-lg border text-center">
              <p className="text-xs text-muted-foreground">Active Trials</p>
              <p className="text-2xl font-bold mt-1 text-emerald-500">{trialInvites.filter(t => t.notes?.match(/(\d+)_day_trial/) && (t.status === 'active' || (t.status === 'pending' && t.trial_end && new Date(t.trial_end) > new Date()))).length}</p>
            </div>
            <div className="p-3 bg-background rounded-lg border text-center">
              <p className="text-xs text-muted-foreground">Expired / Converted</p>
              <p className="text-2xl font-bold mt-1 text-muted-foreground">{trialInvites.filter(t => t.notes?.match(/(\d+)_day_trial/) && (t.status === 'expired' || t.status === 'converted')).length}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Master-Detail Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* User List */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-sm">
                <Users className="w-4 h-4" />All Users ({users.length})
              </CardTitle>
            </div>
            <div className="relative mt-2">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                placeholder="Search users..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="h-8 text-xs pl-8"
              />
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[600px] overflow-y-auto px-3 pb-3 space-y-1.5">
              {filtered.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No users found</p>
              ) : (
                filtered.map(u => {
                  const initials = u.full_name
                    ? u.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
                    : u.email?.[0]?.toUpperCase() || 'U';
                  const isSelected = selectedUser?.id === u.id;
                  return (
                    <div
                      key={u.id}
                      onClick={() => setSelectedUser(u)}
                      className={`flex items-center gap-3 p-2.5 rounded-lg cursor-pointer transition-colors border ${
                        isSelected
                          ? 'bg-primary/10 border-primary/40'
                          : 'bg-muted/30 border-transparent hover:bg-muted/60'
                      }`}
                    >
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary text-xs font-semibold flex items-center justify-center shrink-0">
                        {initials}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate flex items-center gap-1.5">
                          {u.full_name || u.email}
                          {u.role === 'admin' && <ShieldCheck className="w-3 h-3 text-blue-400 shrink-0" />}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {trialBadge(u.email)}
                        {u.subscription_disabled ? (
                          <Badge variant="outline" className="text-[9px] bg-red-500/10 text-red-400 border-red-500/30">Off</Badge>
                        ) : (
                          <Badge variant="outline" className="text-[9px] bg-emerald-500/10 text-emerald-400 border-emerald-500/30">On</Badge>
                        )}
                        <ChevronRight className="w-3.5 h-3.5 text-muted-foreground" />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>

        {/* User Controls Panel */}
        <div className="lg:col-span-3 space-y-4">
          {!selectedUser ? (
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <Users className="w-10 h-10 mx-auto text-muted-foreground mb-3 opacity-50" />
                <p className="text-sm font-medium text-muted-foreground">Select a user to manage their account</p>
                <p className="text-xs text-muted-foreground mt-1">Billing, features, roles, and account access controls will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <>
              {/* User Header */}
              <Card>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-full bg-primary/10 text-primary text-sm font-semibold flex items-center justify-center shrink-0">
                        {(selectedUser.full_name || selectedUser.email || 'U')[0]?.toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <p className="font-semibold truncate">{selectedUser.full_name || 'Unknown'}</p>
                        <p className="text-xs text-muted-foreground truncate">{selectedUser.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className={
                        selectedUser.role === 'admin'
                          ? 'bg-blue-500/10 text-blue-400 border-blue-500/20'
                          : 'bg-muted text-muted-foreground'
                      }>
                        {selectedUser.role || 'user'}
                      </Badge>
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedUser(null)}>
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  {selectedUser.created_date && (
                    <p className="text-[10px] text-muted-foreground mt-2">Joined {format(new Date(selectedUser.created_date), 'MMM d, yyyy')}</p>
                  )}
                </CardContent>
              </Card>

              {/* Billing Controls */}
              <Card className="border-blue-500/30 bg-blue-500/5">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm text-blue-700 dark:text-blue-400">
                    <DollarSign className="w-4 h-4" />Billing Control
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {userBillingLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
                      <Loader2 className="w-4 h-4 animate-spin" />Loading billing state...
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-blue-500/20">
                        <div>
                          <p className="font-semibold text-sm">Disable Billing</p>
                          <p className="text-xs text-muted-foreground mt-0.5">When ON, this user will NOT be charged</p>
                        </div>
                        <Switch
                          checked={userBilling[selectedUser.id]?.billing_disabled === true}
                          disabled={userBillingSaving}
                          onCheckedChange={(checked) => saveUserBilling(selectedUser.id, selectedUser.email, { billing_disabled: checked })}
                        />
                      </div>
                      <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-blue-500/20">
                        <div>
                          <p className="font-semibold text-sm">Free Trial Override</p>
                          <p className="text-xs text-muted-foreground mt-0.5">Grant free access without charging</p>
                        </div>
                        <Switch
                          checked={userBilling[selectedUser.id]?.free_trial === true}
                          disabled={userBillingSaving}
                          onCheckedChange={(checked) => saveUserBilling(selectedUser.id, selectedUser.email, { free_trial: checked })}
                        />
                      </div>
                      <div className="p-2.5 bg-muted rounded-lg text-xs space-y-0.5">
                        <p>• Billing: <span className={`font-semibold ${userBilling[selectedUser.id]?.billing_disabled ? 'text-destructive' : 'text-emerald-500'}`}>{userBilling[selectedUser.id]?.billing_disabled ? 'DISABLED' : 'ACTIVE'}</span></p>
                        <p>• Free Trial: <span className="font-semibold">{userBilling[selectedUser.id]?.free_trial ? 'ENABLED' : 'DISABLED'}</span></p>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Role Management */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <ShieldCheck className="w-4 h-4" />Role & Access Level
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">Current Role: <span className="text-primary">{selectedUser.role || 'user'}</span></p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {selectedUser.role === 'admin' ? 'Admin — can manage users and settings' : 'User — standard access only'}
                      </p>
                    </div>
                    {selectedUser.role === 'admin' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs gap-1.5 border-destructive/30 hover:bg-destructive/10 hover:text-destructive"
                        disabled={actionLoading['demote_' + selectedUser.id]}
                        onClick={() => demoteFromAdmin(selectedUser)}
                      >
                        {actionLoading['demote_' + selectedUser.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <UserX className="w-3 h-3" />}
                        Demote to User
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs gap-1.5 border-emerald-500/30 hover:bg-emerald-500/10 hover:text-emerald-500"
                        disabled={actionLoading['promote_' + selectedUser.id]}
                        onClick={() => promoteToAdmin(selectedUser)}
                      >
                        {actionLoading['promote_' + selectedUser.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <UserCheck className="w-3 h-3" />}
                        Promote to Admin
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Account Actions */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Power className="w-4 h-4" />Account Actions
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">Account Access</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {selectedUser.subscription_disabled ? 'Currently disabled — user cannot log in' : 'Currently active — user can log in'}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant={selectedUser.subscription_disabled ? 'default' : 'destructive'}
                      className="text-xs gap-1.5"
                      disabled={actionLoading['toggle_' + selectedUser.id]}
                      onClick={() => toggleAccount(selectedUser)}
                    >
                      {actionLoading['toggle_' + selectedUser.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : selectedUser.subscription_disabled ? <CheckCircle2 className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                      {selectedUser.subscription_disabled ? 'Enable' : 'Disable'}
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">Resend Login Info</p>
                      <p className="text-xs text-muted-foreground mt-0.5">Email them their access/login details again</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs gap-1.5"
                      disabled={actionLoading['resend_' + selectedUser.id]}
                      onClick={() => resendLogin(selectedUser)}
                    >
                      {actionLoading['resend_' + selectedUser.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <Mail className="w-3 h-3" />}
                      Resend
                    </Button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium">Reactivate Account</p>
                      <p className="text-xs text-muted-foreground mt-0.5">Restore a cancelled or inactive account</p>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-xs gap-1.5 border-emerald-500/30 hover:bg-emerald-500/10 hover:text-emerald-500"
                      disabled={actionLoading['reactivate_' + selectedUser.id]}
                      onClick={() => reactivateAccount(selectedUser)}
                    >
                      {actionLoading['reactivate_' + selectedUser.id] ? <Loader2 className="w-3 h-3 animate-spin" /> : <Power className="w-3 h-3" />}
                      Reactivate
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Feature Access */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-sm">
                    <Zap className="w-4 h-4" />Feature Access
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {SYSTEM_FEATURES.map(feature => {
                      const enabled = userFeatures[selectedUser.id]?.[feature.id] !== false;
                      return (
                        <div key={feature.id} className="flex items-center justify-between p-2.5 bg-muted/50 rounded-lg">
                          <span className="text-xs font-medium">{feature.label}</span>
                          <Switch
                            checked={enabled}
                            onCheckedChange={(checked) => toggleUserFeature(selectedUser.id, feature.id, checked)}
                          />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  );
}