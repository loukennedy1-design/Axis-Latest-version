import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, RefreshCw, Globe, Phone, AlertCircle, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';

const VERDICTS = {
  whitelisted_and_valid: { label: 'Whitelisted & credentials valid', tone: 'success', icon: CheckCircle2 },
  not_whitelisted: { label: 'NOT whitelisted — IP blocked by Elavon', tone: 'danger', icon: XCircle },
  whitelisted_bad_pin: { label: 'Whitelisted — but PIN / API user permissions need reset', tone: 'warn', icon: AlertCircle },
  whitelisted_bad_request: { label: 'Whitelisted — credential / format issue (check Account/User/Terminal ID)', tone: 'warn', icon: AlertCircle },
  network_error: { label: 'Network error reaching Converge', tone: 'warn', icon: AlertCircle },
  unknown: { label: 'Unexpected response', tone: 'warn', icon: AlertCircle },
};

function StatusRow({ result }) {
  if (!result) return null;
  const v = VERDICTS[result.verdict] || VERDICTS.unknown;
  const Icon = v.icon;
  const toneClass = v.tone === 'success' ? 'text-emerald-500'
    : v.tone === 'danger' ? 'text-destructive'
    : 'text-amber-500';
  const rowClass = v.tone === 'success' ? 'border-emerald-500/30 bg-emerald-500/5'
    : v.tone === 'danger' ? 'border-destructive/30 bg-destructive/5'
    : 'border-amber-500/30 bg-amber-500/5';
  return (
    <div className={`rounded-lg border p-3 ${rowClass}`}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Icon className={`w-4 h-4 shrink-0 ${toneClass}`} />
          <span className="font-semibold text-sm capitalize">{result.label}</span>
        </div>
        <Badge variant="outline" className="text-xs">HTTP {result.http_status} · {result.ms}ms</Badge>
      </div>
      <p className={`text-xs mt-1 ${toneClass}`}>{v.label}</p>
      {result.got_token && <p className="text-xs text-emerald-500 mt-0.5">✓ Session token received — charges will go through.</p>}
    </div>
  );
}

export default function ConvergeWhitelistChecker() {
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState(null);

  const runCheck = async () => {
    setChecking(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke('convergeWhitelistCheck', {});
      const data = res?.data || {};
      if (data.error) throw new Error(data.error);
      setResult(data);
      const blocked = data.prod?.verdict === 'not_whitelisted';
      if (blocked) toast.error('Production IP is NOT whitelisted by Elavon');
      else if (data.prod?.got_token) toast.success('Converge production is live — whitelisted & valid');
      else toast.success('Whitelist check complete');
    } catch (e) {
      toast.error('Whitelist check failed: ' + (e.message || 'unknown error'));
    } finally {
      setChecking(false);
    }
  };

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-primary" />
          Converge (Elavon) IP Whitelist Check
        </CardTitle>
        <CardDescription>
          Live-probes the Converge production endpoint to see whether this server's IP is cleared by Elavon for real charges. A <strong>403</strong> means the IP is still blocked; a token or any non-403 status means you're whitelisted.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Button onClick={runCheck} disabled={checking} className="gap-2">
            {checking ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            {checking ? 'Checking…' : 'Re-check Whitelist'}
          </Button>
          {result && !result.configured && (
            <p className="text-xs text-muted-foreground">{result.message}</p>
          )}
        </div>

        {result?.configured && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="rounded-lg border p-3 bg-muted/30">
                <p className="text-xs text-muted-foreground mb-0.5">Server Outbound IP</p>
                <p className="font-mono text-sm flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-primary" />
                  {result.serverIp || 'unavailable'}
                </p>
              </div>
              <div className="rounded-lg border p-3 bg-muted/30">
                <p className="text-xs text-muted-foreground mb-0.5">Converge Account ID</p>
                <p className="font-mono text-sm">{result.accountId}</p>
                <p className="text-[11px] text-muted-foreground">Saved env: {result.savedEnv} · user: {result.userId}</p>
              </div>
            </div>

            <StatusRow result={result.prod} />
            <StatusRow result={result.demo} />

            {result.prod?.verdict === 'not_whitelisted' && (
              <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 space-y-2">
                <p className="text-sm font-semibold text-destructive flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />Action required to go live
                </p>
                <ol className="text-xs text-muted-foreground list-decimal ml-4 space-y-1">
                  <li>Call <strong>Elavon/Converge support: 1-800-377-3962</strong> (option 2, option 2).</li>
                  <li>Give Account ID <strong>{result.accountId}</strong> and ask to add server IP <strong>{result.serverIp || '67.213.121.215'}</strong> to the allowed list.</li>
                  <li>Confirm API user <strong>{result.userId}</strong> has permission to post session-token requests.</li>
                  <li>After Elavon confirms, click <strong>Re-check Whitelist</strong> — a non-403 result means you're cleared.</li>
                </ol>
                <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground pt-1">
                  <Phone className="w-3 h-3" /> If a 401 appears after whitelisting, reset the API user PIN in the Converge dashboard and update Settings → Payments.
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}