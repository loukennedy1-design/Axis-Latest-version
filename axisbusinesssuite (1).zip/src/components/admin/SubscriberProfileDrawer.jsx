import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  User, Mail, Calendar, Shield, CreditCard, Phone, BarChart2,
  ShieldCheck, ShieldOff, Crown, FlaskConical, Clock, FileText,
  CheckCircle2, AlertCircle, MessageSquare, Target, TrendingUp, Zap,
  Trash2, UserX
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { ADD_ONS } from '@/lib/pricing';

export default function SubscriberProfileDrawer({ user, open, onClose }) {
  const qc = useQueryClient();
  const [disableReason, setDisableReason] = useState('');
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteReason, setDeleteReason] = useState('');

  const { data: trialInvites = [] } = useQuery({
    queryKey: ['trialInvites'],
    queryFn: () => base44.entities.TrialInvite.list(),
    enabled: !!user,
  });

  const { data: callLogs = [] } = useQuery({
    queryKey: ['callLogs', user?.email],
    queryFn: () => base44.entities.CallLog.filter({ owner: user?.email }),
    enabled: !!user,
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads', user?.email],
    queryFn: () => base44.entities.Lead.filter({ owner: user?.email }),
    enabled: !!user,
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments', user?.email],
    queryFn: () => base44.entities.Appointment.filter({ owner: user?.email }),
    enabled: !!user,
  });

  const { data: allAddons = [] } = useQuery({
    queryKey: ['userAddons'],
    queryFn: () => base44.entities.UserAddon.list(),
    enabled: !!user,
  });

  const updateUserMut = useMutation({
    mutationFn: (data) => base44.entities.User.update(user.id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['users'] });
      toast.success('User updated');
    },
  });

  const toggleAddonMut = useMutation({
    mutationFn: async ({ addonName, addonPrice, currentEnabled }) => {
      const existing = allAddons.find(a => a.user_email === user.email && a.addon_name === addonName);
      if (existing) {
        return base44.entities.UserAddon.update(existing.id, { enabled: !currentEnabled, enabled_by: 'admin' });
      } else {
        return base44.entities.UserAddon.create({ user_email: user.email, addon_name: addonName, price: addonPrice, enabled: true, enabled_by: 'admin' });
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['userAddons'] });
      toast.success('Add-on updated');
    },
  });

  const handleDeleteUser = async () => {
    try {
      // Delete user's data first
      const userLeads = await base44.entities.Lead.filter({ owner: user.email });
      const userCalls = await base44.entities.CallLog.filter({ owner: user.email });
      const userAppointments = await base44.entities.Appointment.filter({ owner: user.email });
      
      await Promise.all([
        ...userLeads.map(lead => base44.entities.Lead.delete(lead.id)),
        ...userCalls.map(call => base44.entities.CallLog.delete(call.id)),
        ...userAppointments.map(appt => base44.entities.Appointment.delete(appt.id)),
      ]);
      
      // Delete trial invite if exists
      const trialInvite = trialInvites.find(t => t.email === user.email);
      if (trialInvite) {
        await base44.entities.TrialInvite.delete(trialInvite.id);
      }
      
      // Delete user addons
      await Promise.all(userAddons.map(addon => base44.entities.UserAddon.delete(addon.id)));
      
      toast.success(`User ${user.email} removed successfully`);
      setDeleteConfirmOpen(false);
      setDeleteReason('');
      onClose();
    } catch (error) {
      toast.error('Failed to remove user: ' + error.message);
    }
  };

  if (!user) return null;

  const trial = trialInvites.find(t => t.email?.toLowerCase() === user.email?.toLowerCase());
  const userAddons = allAddons.filter(a => a.user_email === user.email && a.enabled);
  const addonTotal = userAddons.reduce((sum, a) => sum + (a.price || 0), 0);

  const totalCalls = callLogs.length;
  const completedCalls = callLogs.filter(c => c.status === 'completed').length;
  const apptSet = callLogs.filter(c => c.outcome === 'appointment_set').length;
  const totalLeads = leads.length;
  const qualifiedLeads = leads.filter(l => l.status === 'qualified').length;
  const totalAppointments = appointments.length;

  const initials = user.full_name
    ? user.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : user.email?.[0]?.toUpperCase() || 'U';

  const trialStatus = trial
    ? (trial.status === 'converted' ? 'converted'
      : new Date(trial.trial_end) < new Date() ? 'expired'
      : 'active')
    : null;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-2xl overflow-y-auto p-0">
        {/* Header */}
        <div className="bg-gradient-to-br from-primary/10 via-card to-purple-500/5 p-6 border-b border-border">
          <SheetHeader className="mb-4">
            <SheetTitle className="sr-only">Subscriber Profile</SheetTitle>
          </SheetHeader>
          <div className="flex items-start gap-4">
            <Avatar className="h-14 w-14 border-2 border-primary/30">
              <AvatarFallback className="bg-primary/20 text-primary text-lg font-bold">{initials}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <h2 className="text-xl font-bold truncate">{user.full_name || 'Unknown'}</h2>
              <p className="text-sm text-muted-foreground flex items-center gap-1 mt-0.5">
                <Mail className="w-3.5 h-3.5" />{user.email}
              </p>
              <div className="flex flex-wrap gap-2 mt-2">
                <Badge variant="outline" className={
                  user.role === 'admin' ? 'bg-purple-500/10 text-purple-400 border-purple-500/30' :
                  'bg-blue-500/10 text-blue-400 border-blue-500/30'
                }>
                  {user.role === 'admin' ? <Shield className="w-3 h-3 mr-1" /> : <User className="w-3 h-3 mr-1" />}
                  {user.role || 'user'}
                </Badge>
                {user.subscription_disabled ? (
                  <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30">
                    <ShieldOff className="w-3 h-3 mr-1" />Disabled
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
                    <ShieldCheck className="w-3 h-3 mr-1" />Active
                  </Badge>
                )}
                {user.billing_bypass && (
                  <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30">
                    <FlaskConical className="w-3 h-3 mr-1" />Beta Free
                  </Badge>
                )}
                {trialStatus && (
                  <Badge variant="outline" className={
                    trialStatus === 'converted' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
                    trialStatus === 'expired' ? 'bg-red-500/10 text-red-400 border-red-500/30' :
                    'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  }>
                    <Clock className="w-3 h-3 mr-1" />Trial: {trialStatus}
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
            <Calendar className="w-3.5 h-3.5" />
            Joined {user.created_date ? format(new Date(user.created_date), 'MMM d, yyyy') : '—'}
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="overview" className="p-4">
          <TabsList className="w-full grid grid-cols-4 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
            <TabsTrigger value="financials">Financials</TabsTrigger>
            <TabsTrigger value="controls">Controls</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard icon={<Phone className="w-4 h-4 text-primary" />} label="Total Calls" value={totalCalls} />
              <StatCard icon={<Target className="w-4 h-4 text-emerald-500" />} label="Total Leads" value={totalLeads} />
              <StatCard icon={<CheckCircle2 className="w-4 h-4 text-blue-400" />} label="Appointments Set" value={apptSet} />
              <StatCard icon={<TrendingUp className="w-4 h-4 text-purple-400" />} label="Qualified Leads" value={qualifiedLeads} />
            </div>

            {trial && (
              <div className="rounded-xl border border-border bg-card p-4 space-y-2">
                <p className="text-sm font-semibold flex items-center gap-2"><Clock className="w-4 h-4 text-primary" />Trial Info</p>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div><span className="text-muted-foreground">Plan: </span>{trial.notes || 'Standard'}</div>
                  <div><span className="text-muted-foreground">Status: </span><span className="capitalize">{trialStatus}</span></div>
                  <div><span className="text-muted-foreground">Started: </span>{trial.trial_start ? format(new Date(trial.trial_start), 'MMM d, yyyy') : '—'}</div>
                  <div><span className="text-muted-foreground">Ends: </span>{trial.trial_end ? format(new Date(trial.trial_end), 'MMM d, yyyy') : '—'}</div>
                  {trial.invited_by && <div className="col-span-2"><span className="text-muted-foreground">Invited by: </span>{trial.invited_by}</div>}
                  {trial.notes && <div className="col-span-2"><span className="text-muted-foreground">Notes: </span>{trial.notes}</div>}
                </div>
              </div>
            )}
          </TabsContent>

          {/* Stats Tab */}
          <TabsContent value="stats" className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard icon={<Phone className="w-4 h-4 text-primary" />} label="Total Calls" value={totalCalls} />
              <StatCard icon={<CheckCircle2 className="w-4 h-4 text-emerald-500" />} label="Completed Calls" value={completedCalls} />
              <StatCard icon={<Target className="w-4 h-4 text-blue-400" />} label="Appointments Set" value={apptSet} />
              <StatCard icon={<BarChart2 className="w-4 h-4 text-purple-400" />} label="Conversion Rate" value={totalCalls > 0 ? `${Math.round((apptSet / totalCalls) * 100)}%` : '—'} />
              <StatCard icon={<User className="w-4 h-4 text-primary" />} label="Total Leads" value={totalLeads} />
              <StatCard icon={<TrendingUp className="w-4 h-4 text-emerald-500" />} label="Qualified Leads" value={qualifiedLeads} />
              <StatCard icon={<Calendar className="w-4 h-4 text-blue-400" />} label="Appointments" value={totalAppointments} />
              <StatCard icon={<MessageSquare className="w-4 h-4 text-purple-400" />} label="Active Add-Ons" value={userAddons.length} />
            </div>
          </TabsContent>

          {/* Financials Tab */}
          <TabsContent value="financials" className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <p className="font-semibold flex items-center gap-2"><CreditCard className="w-4 h-4 text-primary" />Billing Summary</p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Plan</span>
                  <span className="font-medium">{trial?.notes || 'Standard'}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Billing Status</span>
                  {user.billing_bypass ? (
                    <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/30 text-xs">Beta Free</Badge>
                  ) : user.subscription_disabled ? (
                    <Badge variant="outline" className="bg-red-500/10 text-red-400 border-red-500/30 text-xs">Disabled</Badge>
                  ) : (
                    <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 text-xs">Active</Badge>
                  )}
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Active Add-Ons</span>
                  <span className="font-medium">{userAddons.length}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Add-On Revenue/mo</span>
                  <span className="font-semibold text-emerald-400">+${addonTotal}/mo</span>
                </div>
                {user.disabled_reason && (
                  <div className="flex justify-between py-2 border-b border-border">
                    <span className="text-muted-foreground">Disabled Reason</span>
                    <span className="font-medium text-red-400 max-w-[180px] text-right">{user.disabled_reason}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Active Add-Ons */}
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <p className="font-semibold flex items-center gap-2"><Zap className="w-4 h-4 text-primary" />Add-Ons</p>
              <div className="space-y-2">
                {ADD_ONS.map(addon => {
                  const record = allAddons.find(a => a.user_email === user.email && a.addon_name === addon.name);
                  const isEnabled = record?.enabled || false;
                  return (
                    <div key={addon.name} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                      <div>
                        <p className="text-sm font-medium">{addon.name}</p>
                        <p className="text-xs text-muted-foreground">+${addon.price}/mo</p>
                      </div>
                      <Switch
                        checked={isEnabled}
                        onCheckedChange={() => toggleAddonMut.mutate({ addonName: addon.name, addonPrice: addon.price, currentEnabled: isEnabled })}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </TabsContent>

          {/* Controls Tab */}
          <TabsContent value="controls" className="space-y-4">
            {/* Access Control */}
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <p className="font-semibold flex items-center gap-2"><Shield className="w-4 h-4 text-primary" />Access Control</p>

              <div className="flex items-center justify-between py-2">
                <div>
                  <p className="text-sm font-medium">Subscription Access</p>
                  <p className="text-xs text-muted-foreground">Enable or disable platform access</p>
                </div>
                <Switch
                  checked={!user.subscription_disabled}
                  onCheckedChange={(val) => {
                    updateUserMut.mutate({ subscription_disabled: !val });
                    toast.success(val ? 'Access enabled' : 'Access disabled');
                  }}
                />
              </div>

              <div className="flex items-center justify-between py-2 border-t border-border">
                <div>
                  <p className="text-sm font-medium flex items-center gap-1.5">
                    <FlaskConical className="w-3.5 h-3.5 text-amber-500" />Beta / Billing Bypass
                  </p>
                  <p className="text-xs text-muted-foreground">Skip billing checks for this user</p>
                </div>
                <Switch
                  checked={!!user.billing_bypass}
                  onCheckedChange={(val) => {
                    updateUserMut.mutate({ billing_bypass: val });
                    toast.success(val ? 'Beta bypass ON' : 'Beta bypass OFF');
                  }}
                />
              </div>
            </div>

            {/* Role Control */}
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <p className="font-semibold flex items-center gap-2"><Crown className="w-4 h-4 text-primary" />Role Management</p>
              <div className="grid grid-cols-3 gap-2">
                {['user', 'admin', 'super_admin'].map(role => (
                  <Button
                    key={role}
                    size="sm"
                    variant={user.role === role ? 'default' : 'outline'}
                    onClick={() => updateUserMut.mutate({ role })}
                    className="text-xs"
                  >
                    {role === 'super_admin' ? 'Super Admin' : role.charAt(0).toUpperCase() + role.slice(1)}
                  </Button>
                ))}
              </div>
            </div>

            {/* Disable Reason */}
            {user.subscription_disabled && (
              <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4 space-y-2">
                <p className="text-sm font-semibold text-red-400 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />Disable Reason
                </p>
                <div className="flex gap-2">
                  <Input
                    value={disableReason || user.disabled_reason || ''}
                    onChange={e => setDisableReason(e.target.value)}
                    placeholder="Enter reason..."
                    className="text-sm"
                  />
                  <Button size="sm" variant="destructive" onClick={() => updateUserMut.mutate({ disabled_reason: disableReason })}>
                    Save
                  </Button>
                </div>
              </div>
            )}

            {/* Admin Notes */}
            <div className="rounded-xl border border-border bg-card p-4 space-y-2">
              <Label className="flex items-center gap-1.5 text-sm font-semibold">
                <FileText className="w-4 h-4 text-primary" />Admin Notes
              </Label>
              <textarea
                className="w-full rounded-lg bg-muted border border-border p-2 text-sm resize-none min-h-[80px] text-foreground"
                placeholder="Internal notes about this subscriber..."
                defaultValue={user.admin_notes || ''}
                onBlur={e => {
                  if (e.target.value !== (user.admin_notes || '')) {
                    updateUserMut.mutate({ admin_notes: e.target.value });
                  }
                }}
              />
            </div>

            {/* Danger Zone */}
            <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4 space-y-3">
              <p className="font-semibold flex items-center gap-2 text-red-400">
                <UserX className="w-4 h-4" />Danger Zone
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Remove User from System</p>
                  <p className="text-xs text-muted-foreground">Permanently delete user and all associated data</p>
                </div>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => setDeleteConfirmOpen(true)}
                  className="gap-1"
                >
                  <Trash2 className="w-4 h-4" />Remove
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-red-400">
                <Trash2 className="w-5 h-5" />Remove User
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-red-500/5 border border-red-500/20 rounded-lg p-4 space-y-2">
                <p className="text-sm font-semibold text-red-400">⚠️ This action will permanently remove:</p>
                <ul className="text-xs text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>User account: <span className="font-medium text-foreground">{user.email}</span></li>
                  <li>All leads owned by this user</li>
                  <li>All call logs and recordings</li>
                  <li>All appointments</li>
                  <li>All add-on subscriptions</li>
                  <li>Trial subscription record</li>
                </ul>
              </div>
              
              <div>
                <Label>Removal Reason (for audit logs)</Label>
                <Input
                  value={deleteReason}
                  onChange={e => setDeleteReason(e.target.value)}
                  placeholder="e.g., User requested account deletion"
                />
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setDeleteConfirmOpen(false)}>Cancel</Button>
                <Button 
                  variant="destructive" 
                  className="flex-1" 
                  onClick={handleDeleteUser}
                  disabled={!deleteReason}
                >
                  <Trash2 className="w-4 h-4 mr-2" />Remove User
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </SheetContent>
    </Sheet>
  );
}

function StatCard({ icon, label, value }) {
  return (
    <div className="rounded-xl border border-border bg-card p-3 flex items-center gap-3">
      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">{icon}</div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-lg font-bold">{value}</p>
      </div>
    </div>
  );
}