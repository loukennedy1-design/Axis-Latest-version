import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format, formatDistanceToNow } from 'date-fns';
import {
  Inbox, Send, Search, Plus, Mail, MailOpen, Trash2, Reply,
  Circle, ArrowLeft, Paperclip, Star, Filter, Headphones, MessageSquare
} from 'lucide-react';
import { toast } from 'sonner';

const CATEGORY_LABELS = {
  demo_request: 'Demo Request',
  support: 'Support',
  billing: 'Billing',
  technical: 'Technical',
  general: 'General',
};

const CATEGORY_COLORS = {
  demo_request: 'bg-primary/10 text-primary border-primary/30',
  support: 'bg-blue-500/10 text-blue-500 border-blue-500/30',
  billing: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30',
  technical: 'bg-amber-500/10 text-amber-500 border-amber-500/30',
  general: 'bg-muted text-muted-foreground border-border',
};

const PRIORITY_COLORS = {
  high: 'bg-red-500/10 text-red-500 border-red-500/30',
  medium: 'bg-amber-500/10 text-amber-500 border-amber-500/30',
  low: 'bg-muted text-muted-foreground border-border',
};

function parseMessages(msgStr) {
  if (!msgStr) return [];
  try { return JSON.parse(msgStr); } catch { return []; }
}

function Avatar({ name, email, isAdmin }) {
  const initials = (name || email || '?')
    .split(' ')
    .slice(0, 2)
    .map(s => s[0]?.toUpperCase())
    .join('');
  return (
    <div className={`w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
      isAdmin ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
    }`}>
      {initials || '?'}
    </div>
  );
}

export default function SupportHub() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState(null);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [composeOpen, setComposeOpen] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);
  const [mobileShowThread, setMobileShowThread] = useState(false);
  const threadEndRef = useRef(null);

  const { data: conversations = [], isLoading } = useQuery({
    queryKey: ['supportConversations'],
    queryFn: () => base44.entities.SupportConversation.list('-last_message_at', 200),
  });

  const selected = useMemo(
    () => conversations.find(c => c.id === selectedId),
    [conversations, selectedId]
  );

  // Mark as read when opened
  useEffect(() => {
    if (selected && selected.unread_by_admin) {
      base44.entities.SupportConversation.update(selected.id, { unread_by_admin: false })
        .then(() => qc.invalidateQueries({ queryKey: ['supportConversations'] }))
        .catch(() => {});
    }
  }, [selectedId]);

  // Scroll to bottom of thread when messages change
  useEffect(() => {
    if (threadEndRef.current) {
      threadEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [selected?.messages]);

  const filtered = useMemo(() => {
    let result = conversations;
    if (filterStatus !== 'all') {
      result = result.filter(c => c.status === filterStatus);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(c =>
        c.subject?.toLowerCase().includes(q) ||
        c.subscriber_name?.toLowerCase().includes(q) ||
        c.subscriber_email?.toLowerCase().includes(q) ||
        c.last_message_preview?.toLowerCase().includes(q)
      );
    }
    return result;
  }, [conversations, filterStatus, search]);

  const unreadCount = conversations.filter(c => c.unread_by_admin).length;

  const handleSendReply = async () => {
    if (!replyText.trim() || !selected) return;
    setSending(true);
    try {
      const messages = parseMessages(selected.messages);
      messages.push({
        sender: 'admin',
        sender_email: user?.email || 'admin',
        sender_name: user?.full_name || 'AXIS Support',
        body: replyText.trim(),
        timestamp: new Date().toISOString(),
      });
      await base44.entities.SupportConversation.update(selected.id, {
        messages: JSON.stringify(messages),
        last_message_at: new Date().toISOString(),
        last_message_preview: replyText.trim().slice(0, 120),
        last_sender: 'admin',
        status: 'replied',
        unread_by_subscriber: true,
        unread_by_admin: false,
      });
      setReplyText('');
      qc.invalidateQueries({ queryKey: ['supportConversations'] });
      toast.success('Reply sent');
    } catch (e) {
      toast.error('Failed to send reply');
    }
    setSending(false);
  };

  const handleStatusChange = async (convId, newStatus) => {
    try {
      await base44.entities.SupportConversation.update(convId, { status: newStatus });
      qc.invalidateQueries({ queryKey: ['supportConversations'] });
      toast.success(`Marked as ${newStatus}`);
    } catch (e) {
      toast.error('Failed to update status');
    }
  };

  const handleDelete = async (convId) => {
    try {
      await base44.entities.SupportConversation.delete(convId);
      if (selectedId === convId) setSelectedId(null);
      qc.invalidateQueries({ queryKey: ['supportConversations'] });
      toast.success('Conversation deleted');
    } catch (e) {
      toast.error('Failed to delete');
    }
  };

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Headphones className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-bold flex items-center gap-2">
              Support Communication Hub
            </h2>
            <p className="text-xs text-muted-foreground">
              In-system support inbox — all subscriber conversations, no emails sent
            </p>
          </div>
        </div>
        <Button className="gap-2" onClick={() => setComposeOpen(true)}>
          <Plus className="w-4 h-4" /> New Conversation
        </Button>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <Card className="p-3 flex items-center gap-2">
          <Inbox className="w-4 h-4 text-muted-foreground" />
          <div>
            <p className="text-lg font-bold leading-none">{conversations.length}</p>
            <p className="text-xs text-muted-foreground">Total</p>
          </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-primary" />
          <div>
            <p className="text-lg font-bold leading-none">{conversations.filter(c => c.status === 'open').length}</p>
            <p className="text-xs text-muted-foreground">Open</p>
          </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
          <Mail className="w-4 h-4 text-blue-500" />
          <div>
            <p className="text-lg font-bold leading-none">{unreadCount}</p>
            <p className="text-xs text-muted-foreground">Unread</p>
          </div>
        </Card>
        <Card className="p-3 flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-emerald-500" />
          <div>
            <p className="text-lg font-bold leading-none">{conversations.filter(c => c.status === 'replied').length}</p>
            <p className="text-xs text-muted-foreground">Replied</p>
          </div>
        </Card>
      </div>

      {/* Email-like layout */}
      <div className="flex border border-border rounded-xl overflow-hidden h-[600px] bg-card">
        {/* Conversation List (Inbox) */}
        <div className={`flex flex-col w-full md:w-80 lg:w-96 border-r border-border ${mobileShowThread ? 'hidden md:flex' : 'flex'}`}>
          {/* Search + filter */}
          <div className="p-3 border-b border-border space-y-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-8 h-9 text-sm"
              />
            </div>
            <div className="flex gap-1">
              {['all', 'open', 'replied', 'closed'].map(s => (
                <button
                  key={s}
                  onClick={() => setFilterStatus(s)}
                  className={`px-2.5 py-1 rounded-md text-xs font-medium capitalize transition-colors ${
                    filterStatus === s
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground hover:bg-muted/70'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* List */}
          <ScrollArea className="flex-1">
            {isLoading ? (
              <div className="p-4 text-center text-sm text-muted-foreground">Loading...</div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                <Inbox className="w-8 h-8 mx-auto mb-2 opacity-40" />
                No conversations found
              </div>
            ) : (
              <div className="divide-y divide-border">
                {filtered.map(conv => {
                  const msgs = parseMessages(conv.messages);
                  const lastMsg = msgs[msgs.length - 1];
                  const isSelected = conv.id === selectedId;
                  return (
                    <button
                      key={conv.id}
                      onClick={() => {
                        setSelectedId(conv.id);
                        setMobileShowThread(true);
                      }}
                      className={`w-full text-left p-3 hover:bg-muted/40 transition-colors ${isSelected ? 'bg-muted/60' : ''} ${conv.unread_by_admin ? 'font-semibold' : ''}`}
                    >
                      <div className="flex items-start gap-2">
                        <Avatar name={conv.subscriber_name} email={conv.subscriber_email} isAdmin={false} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-sm truncate">{conv.subscriber_name || conv.subscriber_email}</span>
                            {conv.unread_by_admin && <Circle className="w-2 h-2 text-primary shrink-0 fill-primary" />}
                          </div>
                          <p className="text-xs text-muted-foreground truncate">{conv.subject}</p>
                          <p className={`text-xs truncate mt-0.5 ${conv.unread_by_admin ? 'text-foreground' : 'text-muted-foreground'}`}>
                            {conv.last_message_preview || 'No messages yet'}
                          </p>
                          <div className="flex items-center gap-1.5 mt-1">
                            <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${CATEGORY_COLORS[conv.category] || CATEGORY_COLORS.general}`}>
                              {CATEGORY_LABELS[conv.category] || 'General'}
                            </Badge>
                            {conv.status === 'open' && (
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-primary border-primary/30 bg-primary/10">Open</Badge>
                            )}
                            {conv.status === 'closed' && (
                              <Badge variant="outline" className="text-[10px] px-1.5 py-0 text-muted-foreground">Closed</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Thread View */}
        <div className={`flex-1 flex flex-col ${mobileShowThread ? 'flex' : 'hidden md:flex'}`}>
          {!selected ? (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              <div className="text-center">
                <MailOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">Select a conversation to view the thread</p>
              </div>
            </div>
          ) : (
            <>
              {/* Thread header */}
              <div className="p-4 border-b border-border">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 md:hidden"
                        onClick={() => setMobileShowThread(false)}
                      >
                        <ArrowLeft className="w-4 h-4" />
                      </Button>
                      <h3 className="font-bold text-sm truncate">{selected.subject}</h3>
                    </div>
                    <div className="flex items-center gap-2 ml-9 md:ml-0">
                      <Avatar name={selected.subscriber_name} email={selected.subscriber_email} isAdmin={false} />
                      <div>
                        <p className="text-xs font-medium">{selected.subscriber_name || 'Unknown'}</p>
                        <p className="text-xs text-muted-foreground">{selected.subscriber_email}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Select value={selected.status} onValueChange={(v) => handleStatusChange(selected.id, v)}>
                      <SelectTrigger className="h-8 w-28 text-xs">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="replied">Replied</SelectItem>
                        <SelectItem value="closed">Closed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => handleDelete(selected.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1">
                <div className="p-4 space-y-4">
                  {parseMessages(selected.messages).map((msg, i) => {
                    const isAdmin = msg.sender === 'admin';
                    return (
                      <div key={i} className={`flex gap-2.5 ${isAdmin ? 'flex-row-reverse' : 'flex-row'}`}>
                        <Avatar name={msg.sender_name} email={msg.sender_email} isAdmin={isAdmin} />
                        <div className={`flex-1 max-w-[75%] ${isAdmin ? 'items-end' : 'items-start'} flex flex-col`}>
                          <div className={`rounded-xl px-3 py-2 text-sm ${isAdmin ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                            <p className="text-xs font-medium mb-0.5 opacity-80">
                              {msg.sender_name || msg.sender_email}
                            </p>
                            <p className="whitespace-pre-wrap break-words">{msg.body}</p>
                          </div>
                          <p className="text-[10px] text-muted-foreground mt-1 px-1">
                            {msg.timestamp ? format(new Date(msg.timestamp), 'MMM d, h:mm a') : ''}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={threadEndRef} />
                </div>
              </ScrollArea>

              {/* Reply box */}
              <div className="p-3 border-t border-border">
                <div className="flex gap-2">
                  <Textarea
                    placeholder="Type your reply..."
                    value={replyText}
                    onChange={e => setReplyText(e.target.value)}
                    className="min-h-[60px] max-h-[120px] text-sm resize-none"
                    onKeyDown={e => {
                      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                        e.preventDefault();
                        handleSendReply();
                      }
                    }}
                  />
                  <Button
                    className="shrink-0 gap-1.5 self-end"
                    disabled={!replyText.trim() || sending}
                    onClick={handleSendReply}
                  >
                    <Send className="w-4 h-4" />
                    {sending ? '...' : 'Send'}
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">Press Cmd/Ctrl+Enter to send · Replies are stored in-system</p>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Compose Dialog */}
      <ComposeDialog
        open={composeOpen}
        onOpenChange={setComposeOpen}
        user={user}
        onSent={() => qc.invalidateQueries({ queryKey: ['supportConversations'] })}
      />
    </div>
  );
}

function ComposeDialog({ open, onOpenChange, user, onSent }) {
  const [form, setForm] = useState({
    subscriber_email: '',
    subscriber_name: '',
    subject: '',
    category: 'general',
    priority: 'medium',
    body: '',
  });
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    if (!form.subscriber_email || !form.subject || !form.body) {
      toast.error('Email, subject, and message are required');
      return;
    }
    setSending(true);
    try {
      const now = new Date().toISOString();
      const messages = [{
        sender: 'admin',
        sender_email: user?.email || 'admin',
        sender_name: user?.full_name || 'AXIS Support',
        body: form.body,
        timestamp: now,
      }];
      await base44.entities.SupportConversation.create({
        subject: form.subject,
        subscriber_email: form.subscriber_email,
        subscriber_name: form.subscriber_name,
        category: form.category,
        priority: form.priority,
        status: 'open',
        messages: JSON.stringify(messages),
        last_message_at: now,
        last_message_preview: form.body.slice(0, 120),
        last_sender: 'admin',
        unread_by_admin: false,
        unread_by_subscriber: true,
      });
      toast.success('Conversation started');
      setForm({ subscriber_email: '', subscriber_name: '', subject: '', category: 'general', priority: 'medium', body: '' });
      onOpenChange(false);
      onSent();
    } catch (e) {
      toast.error('Failed to start conversation');
    }
    setSending(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-5 h-5" /> New Conversation
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Subscriber Email *</label>
              <Input
                type="email"
                placeholder="john@company.com"
                value={form.subscriber_email}
                onChange={e => setForm({ ...form, subscriber_email: e.target.value })}
                className="mt-1"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Subscriber Name</label>
              <Input
                placeholder="John Smith"
                value={form.subscriber_name}
                onChange={e => setForm({ ...form, subscriber_name: e.target.value })}
                className="mt-1"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Subject *</label>
            <Input
              placeholder="How can we help?"
              value={form.subject}
              onChange={e => setForm({ ...form, subject: e.target.value })}
              className="mt-1"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Category</label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Priority</label>
              <Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground">Message *</label>
            <Textarea
              placeholder="Type your message..."
              value={form.body}
              onChange={e => setForm({ ...form, body: e.target.value })}
              className="mt-1 min-h-[100px]"
            />
          </div>
          <Button
            className="w-full gap-2"
            disabled={!form.subscriber_email || !form.subject || !form.body || sending}
            onClick={handleSend}
          >
            <Send className="w-4 h-4" /> {sending ? 'Sending...' : 'Start Conversation'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}