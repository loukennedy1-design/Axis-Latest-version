import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Phone, Calendar, CheckCircle2, Users, Activity, ChevronRight, Clock } from 'lucide-react';
import { formatDistanceToNow, subDays, isAfter } from 'date-fns';

const sevenDaysAgo = () => subDays(new Date(), 7);

export default function RepActivityOverview() {
  const [selectedRep, setSelectedRep] = useState(null);

  const { data: reps = [], isLoading } = useQuery({
    queryKey: ['admin-reps'],
    queryFn: () => base44.entities.SalesRep.list(),
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['admin-leads'],
    queryFn: () => base44.entities.Lead.list('-created_date', 500),
  });

  const { data: calls = [] } = useQuery({
    queryKey: ['admin-all-calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['admin-all-tasks'],
    queryFn: () => base44.entities.FollowUpTask.list('-created_date', 500),
  });

  const { data: appts = [] } = useQuery({
    queryKey: ['admin-all-appts'],
    queryFn: () => base44.entities.Appointment.list('-created_date', 500),
  });

  // Compute per-rep stats
  const repStats = reps.map(rep => {
    const cutoff = sevenDaysAgo();
    const repLeads = leads.filter(l => l.assigned_to === rep.email);
    const repCalls = calls.filter(c => c.called_by === rep.email);
    const repTasks = tasks.filter(t => t.assigned_to === rep.email);
    const repAppts = appts.filter(a => a.assigned_to === rep.email);

    const calls7d = repCalls.filter(c => c.created_date && isAfter(new Date(c.created_date), cutoff) && c.team_notes !== 'NOTE' && c.team_notes !== 'STATUS_CHANGE').length;
    const appts7d = repAppts.filter(a => a.created_date && isAfter(new Date(a.created_date), cutoff)).length;
    const tasksCompleted7d = repTasks.filter(t => t.status === 'completed' && t.updated_date && isAfter(new Date(t.updated_date), cutoff)).length;

    const allDates = [
      ...repCalls.map(c => c.created_date),
      ...repTasks.map(t => t.updated_date || t.created_date),
      ...repAppts.map(a => a.created_date),
    ].filter(Boolean).map(d => new Date(d));

    const lastActive = allDates.length ? new Date(Math.max(...allDates)) : null;

    return {
      rep,
      leadsAssigned: repLeads.length,
      calls7d,
      appts7d,
      tasksCompleted7d,
      lastActive,
    };
  }).sort((a, b) => (b.lastActive?.getTime() || 0) - (a.lastActive?.getTime() || 0));

  const selectedRepEmail = selectedRep?.rep?.email;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/30 gap-1.5"><Users className="w-3.5 h-3.5" />{reps.length} Reps</Badge>
        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 gap-1.5">{repStats.filter(r => r.lastActive && isAfter(r.lastActive, sevenDaysAgo())).length} Active (7d)</Badge>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8"><Activity className="w-6 h-6 animate-pulse text-muted-foreground" /></div>
      ) : repStats.length === 0 ? (
        <Card className="p-10 text-center border-dashed">
          <Users className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">No sales reps found</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {repStats.map(({ rep, leadsAssigned, calls7d, appts7d, tasksCompleted7d, lastActive }) => (
            <Card
              key={rep.id}
              className="p-3.5 border-border hover:border-primary/30 transition-colors cursor-pointer"
              onClick={() => setSelectedRep({ rep })}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                  {rep.name?.charAt(0) || '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{rep.name}</span>
                    <Badge variant="outline" className="text-[10px] capitalize">{rep.role?.replace(/_/g, ' ')}</Badge>
                    {rep.status === 'active' && <Badge variant="outline" className="text-[10px] bg-emerald-500/10 text-emerald-600 border-emerald-500/20">Active</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{rep.email}</p>
                </div>

                <div className="hidden sm:flex items-center gap-5 shrink-0">
                  <div className="text-center">
                    <p className="text-sm font-bold">{leadsAssigned}</p>
                    <p className="text-[10px] text-muted-foreground">Leads</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-blue-400">{calls7d}</p>
                    <p className="text-[10px] text-muted-foreground">Calls (7d)</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-emerald-400">{appts7d}</p>
                    <p className="text-[10px] text-muted-foreground">Appts (7d)</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-bold text-amber-400">{tasksCompleted7d}</p>
                    <p className="text-[10px] text-muted-foreground">Tasks (7d)</p>
                  </div>
                  <div className="text-center min-w-[80px]">
                    <p className="text-xs font-medium">{lastActive ? formatDistanceToNow(lastActive, { addSuffix: false }) : '—'}</p>
                    <p className="text-[10px] text-muted-foreground">Last active</p>
                  </div>
                </div>

                <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
              </div>

              {/* Mobile stats */}
              <div className="sm:hidden flex items-center justify-around mt-2 pt-2 border-t border-border">
                <div className="text-center"><p className="text-xs font-bold">{leadsAssigned}</p><p className="text-[9px] text-muted-foreground">Leads</p></div>
                <div className="text-center"><p className="text-xs font-bold text-blue-400">{calls7d}</p><p className="text-[9px] text-muted-foreground">Calls</p></div>
                <div className="text-center"><p className="text-xs font-bold text-emerald-400">{appts7d}</p><p className="text-[9px] text-muted-foreground">Appts</p></div>
                <div className="text-center"><p className="text-xs font-bold text-amber-400">{tasksCompleted7d}</p><p className="text-[9px] text-muted-foreground">Tasks</p></div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Rep Activity Detail Drawer */}
      <Sheet open={!!selectedRep} onOpenChange={() => setSelectedRep(null)}>
        <SheetContent side="right" className="w-full sm:max-w-lg overflow-y-auto p-0">
          {selectedRep && (
            <>
              <SheetHeader className="p-5 pb-3 border-b border-border">
                <SheetTitle className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold">
                    {selectedRep.rep.name?.charAt(0) || '?'}
                  </div>
                  <div>
                    <div>{selectedRep.rep.name}</div>
                    <p className="text-xs text-muted-foreground font-normal">{selectedRep.rep.email}</p>
                  </div>
                </SheetTitle>
              </SheetHeader>
              <div className="p-5">
                <div className="grid grid-cols-4 gap-2 mb-4">
                  <div className="rounded-lg bg-muted/40 p-2 text-center">
                    <p className="text-sm font-bold">{selectedRep.leadsAssigned}</p>
                    <p className="text-[10px] text-muted-foreground">Leads</p>
                  </div>
                  <div className="rounded-lg bg-muted/40 p-2 text-center">
                    <p className="text-sm font-bold text-blue-400">{selectedRep.calls7d}</p>
                    <p className="text-[10px] text-muted-foreground">Calls</p>
                  </div>
                  <div className="rounded-lg bg-muted/40 p-2 text-center">
                    <p className="text-sm font-bold text-emerald-400">{selectedRep.appts7d}</p>
                    <p className="text-[10px] text-muted-foreground">Appts</p>
                  </div>
                  <div className="rounded-lg bg-muted/40 p-2 text-center">
                    <p className="text-sm font-bold text-amber-400">{selectedRep.tasksCompleted7d}</p>
                    <p className="text-[10px] text-muted-foreground">Tasks</p>
                  </div>
                </div>

                <AdminRepTimeline repEmail={selectedRepEmail} />
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

function AdminRepTimeline({ repEmail }) {
  const { data: calls = [] } = useQuery({
    queryKey: ['admin-rep-calls', repEmail],
    queryFn: () => base44.entities.CallLog.filter({ called_by: repEmail }),
    enabled: !!repEmail,
  });
  const { data: tasks = [] } = useQuery({
    queryKey: ['admin-rep-tasks', repEmail],
    queryFn: () => base44.entities.FollowUpTask.filter({ assigned_to: repEmail }),
    enabled: !!repEmail,
  });
  const { data: appts = [] } = useQuery({
    queryKey: ['admin-rep-appts', repEmail],
    queryFn: () => base44.entities.Appointment.filter({ assigned_to: repEmail }),
    enabled: !!repEmail,
  });

  const events = [
    ...calls.map(c => ({
      type: c.team_notes === 'NOTE' ? 'note' : c.team_notes === 'STATUS_CHANGE' ? 'status' : 'call',
      date: c.created_date,
      title: c.team_notes === 'NOTE' ? 'Note added' : c.team_notes === 'STATUS_CHANGE' ? 'Status updated' : `Call — ${c.outcome?.replace(/_/g, ' ')}`,
      summary: c.ai_summary || '',
      lead: c.lead_name,
    })),
    ...tasks.map(t => ({
      type: 'task',
      date: t.status === 'completed' ? t.updated_date : t.created_date,
      title: t.status === 'completed' ? `Completed: ${t.task_type?.replace(/_/g, ' ')}` : `Task: ${t.task_type?.replace(/_/g, ' ')}`,
      summary: t.notes || '',
      lead: t.lead_name,
    })),
    ...appts.map(a => ({
      type: 'appointment',
      date: a.created_date,
      title: `Appointment ${a.status}`,
      summary: a.scheduled_date ? `Scheduled: ${new Date(a.scheduled_date).toLocaleString()}` : '',
      lead: a.lead_name,
    })),
  ].filter(e => e.date).sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 30);

  if (events.length === 0) {
    return <p className="text-sm text-muted-foreground text-center py-6">No activity recorded</p>;
  }

  const STYLES = {
    call: 'border-l-blue-500 bg-blue-500/5 text-blue-400',
    note: 'border-l-amber-500 bg-amber-500/5 text-amber-400',
    appointment: 'border-l-emerald-500 bg-emerald-500/5 text-emerald-400',
    task: 'border-l-slate-500 bg-slate-500/5 text-slate-400',
    status: 'border-l-indigo-500 bg-indigo-500/5 text-indigo-400',
  };

  return (
    <div className="space-y-2">
      <h3 className="text-sm font-semibold mb-2 flex items-center gap-2"><Clock className="w-3.5 h-3.5" /> Recent Activity</h3>
      {events.map((e, i) => (
        <div key={i} className={`rounded-lg border-l-2 p-2.5 ${STYLES[e.type] || STYLES.call}`}>
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold">{e.title}</span>
            <span className="text-[10px] text-muted-foreground">{formatDistanceToNow(new Date(e.date), { addSuffix: true })}</span>
          </div>
          {e.summary && <p className="text-xs text-foreground/70 mt-0.5">{e.summary}</p>}
          {e.lead && <p className="text-[10px] text-muted-foreground/70 mt-0.5">Lead: {e.lead}</p>}
        </div>
      ))}
    </div>
  );
}