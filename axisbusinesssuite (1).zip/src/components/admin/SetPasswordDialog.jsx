import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Mail } from 'lucide-react';

export default function SetPasswordDialog({ invite, open, onOpenChange }) {
  const [sending, setSending] = useState(false);

  const handleSend = async () => {
    setSending(true);
    try {
      const res = await base44.functions.invoke('setUserPassword', {
        email: invite.email,
      });
      const data = res.data || res;
      if (data.success) {
        toast.success(data.message, { duration: 8000 });
        onOpenChange(false);
      } else {
        toast.error(data.message || data.error || 'Failed to send password reset');
      }
    } catch (e) {
      toast.error('Failed: ' + e.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-card border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Send Login Setup Email
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <p className="text-sm text-muted-foreground">
            This sends a <span className="font-medium text-foreground">"Set your password"</span> email to{' '}
            <span className="font-medium text-foreground">{invite?.email}</span>.
          </p>
          <p className="text-sm text-muted-foreground">
            The user clicks the link in that email to set their own password. Once set, their email is verified
            and they can log in immediately through the standard AXIS login page.
          </p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleSend} disabled={sending}>
            {sending ? 'Sending…' : 'Send Setup Email'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}