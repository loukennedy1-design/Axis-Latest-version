import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  RefreshCw, ChevronDown, ChevronRight, RotateCcw, Search, Activity,
  TrendingUp, Clock, CheckCircle2, AlertTriangle, XCircle, Target,
  Sparkles, Rocket, Eye, Zap
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const statusConfig = {
  queued: { label: 'Queued', color: 'bg-muted text-muted-foreground', icon: Clock },
  awaiting_window: { label: 'Awaiting Window', color: 'bg-amber-500/10 text-amber-400 border-amber-500/30', icon: Clock },
  in_progress: { label: 'Deploying', color: 'bg-red-500/10 text-red-400 border-red-500/30', icon: Activity },
  completed: { label: 'Completed', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
  skipped: { label: 'Skipped', color: 'bg-muted text-muted-foreground', icon: XCircle },
  flagged_for_review: { label: 'Flagged', color: 'bg-orange-500/10 text-orange-400 border-orange-500/30', icon: AlertTriangle }
};

const riskBadge = (level) => {
  const map = {
    low: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    medium: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    high: 'bg-destructive/10 text-destructive border-destructive/30'
  };
  return map[level] || map.low;
};

function parseJson(str, fallback) {
  try { return JSON.parse(str); } catch (_) { return fallback; }
}

// ── Evolution Cycle Entry (expandable timeline item) ──────────────────────────
function EvolutionCycleEntry({ item }) {
  const [expanded, setExpanded] = useState(false);
  const [rollingBack, setRollingBack] = useState(false);
  const status = statusConfig[item.status] || statusConfig.queued;
  const StatusIcon = status.icon;

  const filesChanged = parseJson(item.files_changed, []);
  const cascadeActions = parseJson(item.cascade_actions, []);
  const competitorRefs = parseJson(item.competitor_references, []);
  const plan = parseJson(item.implementation_plan, {});
  const postSignal = parseJson(item.post_deploy_signal, {});

  const handleRollback = async () => {
    setRollingBack(true);
    try {
      const res = await base44.functions.invoke('trinitySystemCommand', {
        command: 'evolution_rollback',
        params: { backlog_id: item.id, checkpoint_id: item.checkpoint_id }
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Rollback initiated');
    } catch (e) {
      toast.error(e.message || 'Rollback failed');
    }
    setRollingBack(false);
  };

  return (
    <div className="rounded-xl border border-border bg-zinc-900/40 overflow-hidden">
      {/* Header row — always visible */}
      <button onClick={() => setExpanded(!expanded)} className="w-full text-left">
        <div className="flex items-center gap-3 p-4 hover:bg-muted/20 transition-colors">
          {/* Timeline dot */}
          <div className={`w-2 h-2 rounded-full shrink-0 ${
            item.status === 'in_progress' ? 'bg-red-500 animate-pulse' :
            item.status === 'completed' ? 'bg-emerald-500' :
            item.status === 'awaiting_window' ? 'bg-amber-500' :
            item.status === 'flagged_for_review' ? 'bg-orange-500' :
            'bg-muted-foreground'
          }`} />
          {expanded ? <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" /> : <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />}
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate">{item.title}</p>
            <p className="text-xs text-muted-foreground mt-0.5">
              {item.source === 'competitor_research' && '🌐 Competitor Research'}
              {item.source === 'internal_signal' && '📊 Internal Signal'}
              {item.source === 'both' && '🌐📊 Both'}
              {item.actual_deploy_at && ` · Deployed ${format(new Date(item.actual_deploy_at), 'MMM d, HH:mm')}`}
              {!item.actual_deploy_at && item.planned_at && ` · Planned ${format(new Date(item.planned_at), 'MMM d, HH:mm')}`}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {item.detected_activity_level && (
              <Badge variant="outline" className="text-xs">
                Activity: {item.detected_activity_level}
              </Badge>
            )}
            <Badge variant="outline" className="text-xs">
              Impact: {item.impact_score} · Urgency: {item.urgency_score}
            </Badge>
            <Badge className={`text-xs ${status.color}`}>
              <StatusIcon className="w-3 h-3 mr-1" />{status.label}
            </Badge>
            {item.risk_level && (
              <Badge className={`text-xs ${riskBadge(item.risk_level)}`}>{item.risk_level?.toUpperCase()}</Badge>
            )}
          </div>
        </div>
      </button>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t border-border bg-zinc-950/60 space-y-4 p-4">
          {/* Value Justification */}
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5 flex items-center gap-1.5"><Target className="w-3.5 h-3.5" />Subscriber Value</p>
            <p className="text-sm text-foreground/90">{item.subscriber_value_statement || '—'}</p>
          </div>

          {/* Profitability Impact */}
          {item.profitability_impact && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5 flex items-center gap-1.5"><TrendingUp className="w-3.5 h-3.5" />Profitability Impact</p>
              <p className="text-sm text-foreground/90">{item.profitability_impact}</p>
            </div>
          )}

          {/* Competitor References */}
          {competitorRefs.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Competitor References</p>
              <div className="flex flex-wrap gap-1.5">
                {competitorRefs.map((ref, i) => (
                  <Badge key={i} variant="outline" className="text-xs border-blue-500/30 text-blue-300">
                    {ref.platform}: {ref.feature}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Description</p>
            <p className="text-sm text-foreground/80">{item.description}</p>
          </div>

          {/* Implementation Plan */}
          {plan && Object.keys(plan).length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5 flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5" />Implementation Plan</p>
              <div className="rounded-lg border border-border bg-background/50 p-3 space-y-2 text-sm">
                {plan.entities?.length > 0 && (
                  <p><span className="text-muted-foreground">Entities:</span> {plan.entities.join(', ')}</p>
                )}
                {plan.backend_functions?.length > 0 && (
                  <p><span className="text-muted-foreground">Functions:</span> {plan.backend_functions.join(', ')}</p>
                )}
                {plan.ui_components?.length > 0 && (
                  <p><span className="text-muted-foreground">Components:</span> {plan.ui_components.join(', ')}</p>
                )}
                {plan.subscriber_impact && (
                  <p><span className="text-muted-foreground">Projected Impact:</span> {plan.subscriber_impact}</p>
                )}
              </div>
            </div>
          )}

          {/* Deployment Window Details */}
          {item.actual_deploy_at && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="rounded-lg border border-border bg-background/50 p-2.5 text-center">
                <p className="text-xs text-muted-foreground">Deployed At</p>
                <p className="text-sm font-semibold mt-0.5">{format(new Date(item.actual_deploy_at), 'MMM d, HH:mm')}</p>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-2.5 text-center">
                <p className="text-xs text-muted-foreground">Deferrals</p>
                <p className="text-sm font-semibold mt-0.5">{item.deploy_deferrals || 0}</p>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-2.5 text-center">
                <p className="text-xs text-muted-foreground">Activity Level</p>
                <p className="text-sm font-semibold mt-0.5 capitalize">{item.detected_activity_level || '—'}</p>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-2.5 text-center">
                <p className="text-xs text-muted-foreground">Files Changed</p>
                <p className="text-sm font-semibold mt-0.5">{filesChanged.length}</p>
              </div>
            </div>
          )}

          {/* Files Changed */}
          {filesChanged.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Files Changed</p>
              <div className="flex flex-wrap gap-1.5">
                {filesChanged.map((f, i) => (
                  <Badge key={i} variant="outline" className="text-xs font-mono border-emerald-500/30 text-emerald-300">{f}</Badge>
                ))}
              </div>
            </div>
          )}

          {/* Cascade Actions */}
          {cascadeActions.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5">Cascade Actions</p>
              <div className="space-y-1">
                {cascadeActions.map((a, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs">
                    <span className="text-violet-400 mt-0.5">→</span>
                    <span><span className="font-medium text-violet-300">{a.target}:</span> {a.action} — {a.detail?.slice(0, 120)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Post-Deploy Signal */}
          {Object.keys(postSignal).length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase text-muted-foreground mb-1.5 flex items-center gap-1.5"><Eye className="w-3.5 h-3.5" />Post-Deployment Signal</p>
              <div className="rounded-lg border border-border bg-background/50 p-3 text-sm space-y-1">
                <p><span className="text-muted-foreground">Assessment:</span> <span className={postSignal.assessment?.includes('low') ? 'text-orange-400' : 'text-emerald-400'}>{postSignal.assessment || '—'}</span></p>
                <p><span className="text-muted-foreground">Days since deploy:</span> {postSignal.days_since_deploy || '—'}</p>
                <p><span className="text-muted-foreground">Recent calls:</span> {postSignal.recent_calls || 0} · <span className="text-muted-foreground">Recent leads:</span> {postSignal.recent_leads || 0}</p>
              </div>
            </div>
          )}

          {/* Broadcast */}
          {item.broadcast_sent && (
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />Subscriber broadcast sent (in-app + email)
            </div>
          )}

          {/* Rollback */}
          {item.checkpoint_id && item.status === 'completed' && (
            <div className="pt-2 border-t border-border">
              <Button variant="outline" size="sm" className="gap-2 border-destructive/30 hover:bg-destructive/10 hover:text-destructive" disabled={rollingBack} onClick={handleRollback}>
                {rollingBack ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RotateCcw className="w-3.5 h-3.5" />}Rollback to Checkpoint
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main Evolution Log Component ───────────────────────────────────────────────
export default function EvolutionLog({ user }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('trinitySystemCommand', { command: 'evolution_log' });
      if (res.data?.error) throw new Error(res.data.error);
      setItems(res.data?.result?.items || []);
    } catch (e) {
      // Fallback: direct entity query
      try {
        const all = await base44.entities.EvolutionBacklog.list('-created_date', 50);
        setItems(all || []);
      } catch (_) {
        setItems([]);
      }
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const triggerCycle = async () => {
    setTriggering(true);
    try {
      const res = await base44.functions.invoke('trinitySystemCommand', { command: 'evolution_trigger' });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Evolution cycle triggered');
      setTimeout(() => load(), 2000);
    } catch (e) {
      toast.error(e.message || 'Failed to trigger cycle');
    }
    setTriggering(false);
  };

  const filtered = statusFilter === 'all' ? items : items.filter(i => i.status === statusFilter);
  const stats = {
    total: items.length,
    completed: items.filter(i => i.status === 'completed').length,
    queued: items.filter(i => i.status === 'queued').length,
    flagged: items.filter(i => i.status === 'flagged_for_review').length
  };

  return (
    <Card className="border-violet-500/20 bg-zinc-950">
      <CardHeader className="py-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-violet-400" />Evolution Log
              <span className="text-xs text-muted-foreground font-normal">— autonomous feature evolution timeline</span>
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Every cycle: research → value filter → plan → window detect → build → cascade → broadcast → signal check
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={load} disabled={loading}>
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />Refresh
            </Button>
            <Button size="sm" className="gap-1.5 bg-violet-600 hover:bg-violet-700 text-white" onClick={triggerCycle} disabled={triggering}>
              {triggering ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}Trigger Cycle
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        {/* Stats row */}
        <div className="grid grid-cols-4 gap-2">
          <div className="rounded-lg border border-border bg-background/50 p-2.5 text-center">
            <p className="text-lg font-bold">{stats.total}</p>
            <p className="text-xs text-muted-foreground">Total Cycles</p>
          </div>
          <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-2.5 text-center">
            <p className="text-lg font-bold text-emerald-400">{stats.completed}</p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </div>
          <div className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-2.5 text-center">
            <p className="text-lg font-bold text-amber-400">{stats.queued}</p>
            <p className="text-xs text-muted-foreground">Queued</p>
          </div>
          <div className="rounded-lg border border-orange-500/20 bg-orange-500/5 p-2.5 text-center">
            <p className="text-lg font-bold text-orange-400">{stats.flagged}</p>
            <p className="text-xs text-muted-foreground">Flagged</p>
          </div>
        </div>

        {/* Filter pills */}
        <div className="flex flex-wrap gap-1.5">
          {['all', 'queued', 'awaiting_window', 'in_progress', 'completed', 'flagged_for_review'].map(f => (
            <button
              key={f}
              onClick={() => setStatusFilter(f)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition-colors ${
                statusFilter === f ? 'bg-violet-600 text-white' : 'bg-muted/50 text-muted-foreground hover:bg-muted'
              }`}
            >
              {f.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {/* Timeline feed */}
        {loading ? (
          <div className="flex items-center gap-2 text-xs text-muted-foreground py-8 justify-center">
            <RefreshCw className="w-4 h-4 animate-spin" />Loading evolution log...
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12">
            <Sparkles className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No evolution cycles yet.</p>
            <p className="text-xs text-muted-foreground mt-1">Trigger a cycle or wait for the weekly automation to run.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(item => (
              <EvolutionCycleEntry key={item.id} item={item} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}