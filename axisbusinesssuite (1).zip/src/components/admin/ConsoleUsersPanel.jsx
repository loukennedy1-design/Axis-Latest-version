import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, UserPlus, Shield, ShieldCheck, ShieldOff, Crown, Send, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useCurrentUser } from '@/hooks/useCurrentUser';

const PROTECTED_EMAILS = ['loukennedy1@gmail.com', 'kurt.williams@sbcglobal.net'];

export default function ConsoleUsersPanel() {
  const [search, setSearch] = useState('');
  const [inviteOpen, setInviteOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('user');
  const [disableReason, setDisableReason] = useState('');
  const [reasonDialog, setReasonDialog] = useState(null);
  const qc = useQueryClient();
  const { user: currentUser, isAdmin } = useCurrentUser();

  const { data: allUsers = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.User.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['users'] }); toast.success('Updated'); },
    onError: (e) => toast.error(e.message),
  });

  const handleToggleAccess = (u) => {
    if (PROTECTED_EMAILS.includes(u.email?.toLowerCase())) { toast.error('Protected account'); return; }
    if (!u.subscription_disabled) {
      setReasonDialog(u);
      setDisableReason('');
    } else {
      updateMut.mutate({ id: u.id, data: { subscription_disabled: false, disabled_reason: '' } });
    }
  };

  const handleRoleChange = (u, role) => {
    if (PROTECTED_EMAILS.includes(u.email?.toLowerCase())) { toast.error('Protected account'); return; }
    updateMut.mutate({ id: u.id, data: { role } });
  };

  const confirmDisable = () => {
    if (!reasonDialog) return;
    updateMut.mutate({ id: reasonDialog.id, data: { subscription_disabled: true, disabled_reason: disableReason } });
    setReasonDialog(null);
  };

  const handleInvite = async () => {
    try {
      await base44.users.inviteUser(inviteEmail, inviteRole);
      toast.success(`Invite sent to ${inviteEmail}`);
      setInviteOpen(false); setInviteEmail(''); setInviteRole('user');
      qc.invalidateQueries({ queryKey: ['users'] });
    } catch (e) { toast.error('Invite failed: ' + e.message); }
  };

  const filtered = allUsers.filter(u =>
    `${u.full_name || ''} ${u.email || ''}`.toLowerCase().includes(search.toLowerCase())
  );

  const activeCount = allUsers.filter(u => !u.subscription_disabled).length;
  const adminCount = allUsers.filter(u => u.role === 'admin' || u.role === 'super_admin').length;
  const disabledCount = allUsers.filter(u => u.subscription_disabled).length;

  if (!isAdmin) return (
    <div className="flex items-center justify-center min-h-[40vh] text-center">
      <div className="space-y-3"><div className="text-4xl">🔒</div><p className="font-semibold">Admin Access Required</p></div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="flex items-center gap-3 flex-wrap">
        <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/30 gap-1.5"><ShieldCheck className="w-3.5 h-3.5" />{activeCount} Active</Badge>
        <Badge className="bg-purple-500/10 text-purple-400 border-purple-500/30 gap-1.5"><Shield className="w-3.5 h-3.5" />{adminCount} Admins</Badge>
        {disabledCount > 0 && (
          <Badge className="bg-red-500/10 text-red-400 border-red-500/30 gap-1.5"><ShieldOff className="w-3.5 h-3.5" />{disabledCount} Disabled</Badge>
        )}
        <Button size="sm" className="ml-auto gap-2" onClick={() => setInviteOpen(true)}>
          <UserPlus className="w-4 h-4" />Invite User
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search users..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      {/* User List */}
      {isLoading ? (
        <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(u => {
            const initials = u.full_name ? u.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : (u.email?.[0]?.toUpperCase() || 'U');
            const isProtected = PROTECTED_EMAILS.includes(u.email?.toLowerCase());
            return (
              <div key={u.id} className={`bg-card border rounded-xl p-3 flex items-center gap-3 ${u.subscription_disabled ? 'border-red-500/20 bg-red-500/5' : 'border-border'}`}>
                <Avatar className="h-9 w-9 shrink-0">
                  <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">{initials}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-sm">{u.full_name || 'Unknown'}</span>
                    {u.email === currentUser?.email && <Badge variant="outline" className="text-[10px] text-muted-foreground">You</Badge>}
                    {u.role === 'super_admin' && <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-400 border-amber-500/30 gap-1"><Crown className="w-2.5 h-2.5" />super</Badge>}
                    {isProtected && <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-400 border-blue-500/30">protected</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{u.email}</p>
                </div>
                {/* Role selector */}
                <Select value={u.role || 'user'} onValueChange={(v) => handleRoleChange(u, v)} disabled={isProtected}>
                  <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
                {/* Access toggle */}
                <div className="flex items-center gap-2">
                  <Switch checked={!u.subscription_disabled} onCheckedChange={() => handleToggleAccess(u)} disabled={isProtected} />
                  <span className={`text-xs ${u.subscription_disabled ? 'text-red-400' : 'text-emerald-400'}`}>
                    {u.subscription_disabled ? 'Off' : 'On'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Invite Dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Invite User</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Email Address</Label>
              <Input type="email" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="user@company.com" />
            </div>
            <div><Label>Role</Label>
              <Select value={inviteRole} onValueChange={setInviteRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="user">User</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full gap-2" onClick={handleInvite} disabled={!inviteEmail}>
              <Send className="w-4 h-4" />Send Invite
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Disable Reason Dialog */}
      {reasonDialog && (
        <Dialog open={!!reasonDialog} onOpenChange={() => setReasonDialog(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>Disable Access</DialogTitle></DialogHeader>
            <p className="text-sm text-muted-foreground">Disable access for <strong>{reasonDialog.full_name || reasonDialog.email}</strong>?</p>
            <div><Label>Reason (optional)</Label>
              <Input placeholder="Payment failed, plan expired..." value={disableReason} onChange={e => setDisableReason(e.target.value)} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setReasonDialog(null)}>Cancel</Button>
              <Button variant="destructive" onClick={confirmDisable}>Disable</Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}