import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Activity, TrendingUp, TrendingDown, Minus, Server, Database, 
  Users, Phone, Mail, Calendar, DollarSign, AlertCircle, CheckCircle2,
  Clock, Zap, Bot, Target, FileText, Shield, Cpu, HardDrive, Network
} from 'lucide-react';
import { format } from 'date-fns';

export default function SystemHealthMonitor({ 
  users, leads, calls, opportunities, proposals, quotes, contracts,
  accountAgents, employees, candidates, socialPosts, invoices, expenses,
  systemSettings, agentTasks, complianceLogs, dncEntries, trialInvites
}) {
  // Calculate system health metrics
  const calculateHealth = () => {
    const metrics = {
      totalUsers: users?.length || 0,
      activeUsers: users?.filter(u => !u.disabled)?.length || 0,
      totalLeads: leads?.length || 0,
      totalCalls: calls?.length || 0,
      totalOpportunities: opportunities?.length || 0,
      totalProposals: proposals?.length || 0,
      totalQuotes: quotes?.length || 0,
      totalContracts: contracts?.length || 0,
      totalInvoices: invoices?.length || 0,
      totalEmployees: employees?.length || 0,
      totalCandidates: candidates?.length || 0,
      totalSocialPosts: socialPosts?.length || 0,
      totalExpenses: expenses?.length || 0,
      totalAgentTasks: agentTasks?.length || 0,
      activeAgentTasks: agentTasks?.filter(t => t.status === 'active')?.length || 0,
      totalComplianceLogs: complianceLogs?.length || 0,
      totalDncEntries: dncEntries?.length || 0,
      totalSystemSettings: systemSettings?.length || 0,
      totalTrialInvites: trialInvites?.length || 0,
      activeTrialInvites: trialInvites?.filter(t => t.status === 'active')?.length || 0,
    };

    // Calculate health score (0-100)
    let healthScore = 100;
    
    // Check for critical issues
    if (metrics.activeUsers === 0) healthScore -= 20;
    if (metrics.activeAgentTasks === 0 && metrics.totalAgentTasks > 0) healthScore -= 10;
    if (metrics.totalSystemSettings === 0) healthScore -= 15;
    
    // Check data growth (indicates active system)
    if (metrics.totalLeads === 0 && metrics.totalUsers > 0) healthScore -= 10;
    if (metrics.totalCalls === 0 && metrics.totalUsers > 0) healthScore -= 10;
    
    return {
      score: Math.max(0, healthScore),
      status: healthScore >= 80 ? 'healthy' : healthScore >= 60 ? 'warning' : 'critical',
      metrics
    };
  };

  const { score, status, metrics } = calculateHealth();

  const getHealthColor = () => {
    if (status === 'healthy') return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
    if (status === 'warning') return 'text-amber-500 bg-amber-500/10 border-amber-500/20';
    return 'text-destructive bg-destructive/10 border-destructive/20';
  };

  const getHealthIcon = () => {
    if (status === 'healthy') return CheckCircle2;
    if (status === 'warning') return AlertCircle;
    return AlertCircle;
  };

  const HealthIcon = getHealthIcon();

  return (
    <div className="space-y-4">
      {/* Overall System Health */}
      <Card className={`border-2 ${getHealthColor()}`}>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getHealthColor()}`}>
                <HealthIcon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">{score}%</p>
                <p className="text-xs text-muted-foreground">System Health Score</p>
              </div>
            </div>
            <Badge className={`text-sm px-4 py-2 ${getHealthColor()}`}>
              {status === 'healthy' ? '🟢 All Systems Operational' : 
               status === 'warning' ? '🟡 Warning - Attention Needed' : 
               '🔴 Critical - Immediate Action Required'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <HealthMetric 
              icon={Users} 
              label="Users" 
              value={metrics.totalUsers} 
              subvalue={`${metrics.activeUsers} active`}
              trend={metrics.activeUsers > 0 ? 'stable' : 'declining'}
            />
            <HealthMetric 
              icon={Target} 
              label="Leads" 
              value={metrics.totalLeads}
              trend="stable"
            />
            <HealthMetric 
              icon={Phone} 
              label="Calls" 
              value={metrics.totalCalls}
              trend="stable"
            />
            <HealthMetric 
              icon={Bot} 
              label="Agent Tasks" 
              value={metrics.activeAgentTasks}
              subvalue={`${metrics.totalAgentTasks} total`}
              trend={metrics.activeAgentTasks > 0 ? 'stable' : 'declining'}
            />
            <HealthMetric 
              icon={DollarSign} 
              label="Invoices" 
              value={metrics.totalInvoices}
              trend="stable"
            />
            <HealthMetric 
              icon={Shield} 
              label="Compliance" 
              value={metrics.totalComplianceLogs}
              subvalue={`${metrics.totalDncEntries} DNC`}
              trend="stable"
            />
          </div>
        </CardContent>
      </Card>

      {/* Department Health */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* CRM & Sales */}
        <DepartmentHealthCard
          title="CRM & Sales"
          icon={Target}
          metrics={[
            { label: 'Opportunities', value: metrics.totalOpportunities },
            { label: 'Proposals', value: metrics.totalProposals },
            { label: 'Quotes', value: metrics.totalQuotes },
            { label: 'Contracts', value: metrics.totalContracts },
          ]}
          health={metrics.totalOpportunities > 0 ? 'healthy' : 'warning'}
        />

        {/* HR & Recruiting */}
        <DepartmentHealthCard
          title="HR & Recruiting"
          icon={Users}
          metrics={[
            { label: 'Employees', value: metrics.totalEmployees },
            { label: 'Candidates', value: metrics.totalCandidates },
          ]}
          health={metrics.totalEmployees > 0 ? 'healthy' : 'neutral'}
        />

        {/* Marketing */}
        <DepartmentHealthCard
          title="Marketing"
          icon={Mail}
          metrics={[
            { label: 'Social Posts', value: metrics.totalSocialPosts },
          ]}
          health={metrics.totalSocialPosts > 0 ? 'healthy' : 'neutral'}
        />

        {/* Finance */}
        <DepartmentHealthCard
          title="Finance"
          icon={DollarSign}
          metrics={[
            { label: 'Invoices', value: metrics.totalInvoices },
            { label: 'Expenses', value: metrics.totalExpenses },
          ]}
          health={metrics.totalInvoices > 0 ? 'healthy' : 'neutral'}
        />

        {/* AI & Automation */}
        <DepartmentHealthCard
          title="AI & Automation"
          icon={Bot}
          metrics={[
            { label: 'Active Tasks', value: metrics.activeAgentTasks },
            { label: 'Total Tasks', value: metrics.totalAgentTasks },
          ]}
          health={metrics.activeAgentTasks > 0 ? 'healthy' : 'warning'}
        />

        {/* System Infrastructure */}
        <DepartmentHealthCard
          title="Infrastructure"
          icon={Server}
          metrics={[
            { label: 'Settings', value: metrics.totalSystemSettings },
            { label: 'Trial Invites', value: metrics.activeTrialInvites },
          ]}
          health={metrics.totalSystemSettings > 0 ? 'healthy' : 'critical'}
        />
      </div>

      {/* Real-time Activity Feed */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Real-time System Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <ActivityStat 
              icon={Users} 
              label="Total Users" 
              value={metrics.totalUsers}
              color="text-blue-500"
            />
            <ActivityStat 
              icon={Target} 
              label="Total Leads" 
              value={metrics.totalLeads}
              color="text-emerald-500"
            />
            <ActivityStat 
              icon={Phone} 
              label="Total Calls" 
              value={metrics.totalCalls}
              color="text-violet-500"
            />
            <ActivityStat 
              icon={Mail} 
              label="Trial Invites" 
              value={metrics.totalTrialInvites}
              color="text-amber-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* System Resources */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Cpu className="w-5 h-5" />
            System Resources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <ResourceStat 
              icon={Database} 
              label="Database Status" 
              value="Operational"
              status="healthy"
            />
            <ResourceStat 
              icon={Network} 
              label="API Services" 
              value="Running"
              status="healthy"
            />
            <ResourceStat 
              icon={HardDrive} 
              label="Storage" 
              value="Normal"
              status="healthy"
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function HealthMetric({ icon: Icon, label, value, subvalue, trend }) {
  const TrendIcon = trend === 'stable' ? Minus : trend === 'growing' ? TrendingUp : TrendingDown;
  const trendColor = trend === 'stable' ? 'text-muted-foreground' : trend === 'growing' ? 'text-emerald-500' : 'text-destructive';
  
  return (
    <div className="p-3 rounded-lg border bg-muted/30">
      <div className="flex items-center justify-between mb-2">
        <Icon className="w-4 h-4 text-muted-foreground" />
        {TrendIcon && <TrendIcon className={`w-3 h-3 ${trendColor}`} />}
      </div>
      <p className="text-2xl font-bold">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
      {subvalue && <p className="text-xs text-muted-foreground mt-1">{subvalue}</p>}
    </div>
  );
}

function DepartmentHealthCard({ title, icon: Icon, metrics, health }) {
  const healthColors = {
    healthy: 'border-emerald-500/30 bg-emerald-500/5',
    warning: 'border-amber-500/30 bg-amber-500/5',
    critical: 'border-destructive/30 bg-destructive/5',
    neutral: 'border-border bg-muted/20'
  };

  return (
    <Card className={healthColors[health]}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-sm">
          <Icon className="w-4 h-4" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {metrics.map(m => (
            <div key={m.label} className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{m.label}</span>
              <span className="text-sm font-semibold">{m.value}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function ActivityStat({ icon: Icon, label, value, color }) {
  return (
    <div className="p-4 rounded-lg border bg-muted/30">
      <div className="flex items-center gap-3">
        <Icon className={`w-5 h-5 ${color}`} />
        <div>
          <p className="text-2xl font-bold">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </div>
    </div>
  );
}

function ResourceStat({ icon: Icon, label, value, status }) {
  const statusColors = {
    healthy: 'text-emerald-500',
    warning: 'text-amber-500',
    critical: 'text-destructive'
  };

  return (
    <div className="p-4 rounded-lg border bg-muted/30">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Icon className="w-5 h-5 text-muted-foreground" />
          <div>
            <p className="text-sm font-medium">{label}</p>
            <p className={`text-xs font-semibold ${statusColors[status]}`}>{value}</p>
          </div>
        </div>
        <div className={`w-2 h-2 rounded-full ${
          status === 'healthy' ? 'bg-emerald-500' : 
          status === 'warning' ? 'bg-amber-500' : 'bg-destructive'
        }`} />
      </div>
    </div>
  );
}