import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { CreditCard, Zap, AlertTriangle, CheckCircle, XCircle, Loader2, DollarSign } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function BatchChargePanel({ trialInvites }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [charging, setCharging] = useState(false);
  const [results, setResults] = useState(null);
  const qc = useQueryClient();

  const pendingCards = (trialInvites || []).filter(
    (t) => t.payment_status === 'pending_charge' && t.card_vault_token
  );
  const failedCards = (trialInvites || []).filter(
    (t) => t.payment_status === 'charge_failed'
  );
  const chargedCards = (trialInvites || []).filter(
    (t) => t.payment_status === 'charged'
  );

  const totalPendingRevenue = pendingCards.reduce(
    (sum, t) => sum + (t.billing_amount || 0),
    0
  );

  const handleBatchCharge = async () => {
    setCharging(true);
    setResults(null);
    try {
      const res = await base44.functions.invoke('batchChargePendingCards', {});
      const data = res.data || {};
      if (data.error) throw new Error(data.error);
      setResults(data);
      toast.success(
        `Batch complete: ${data.charged} charged, ${data.failed} failed, $${(data.totalCollected || 0).toFixed(2)} collected`
      );
      qc.invalidateQueries({ queryKey: ['trialInvitesSA'] });
      qc.invalidateQueries({ queryKey: ['trialInvites-all'] });
    } catch (err) {
      toast.error(err.message || 'Batch charge failed');
    } finally {
      setCharging(false);
      setConfirmOpen(false);
    }
  };

  return (
    <>
      <Card className="border-amber-500/30 bg-amber-500/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-amber-600">
            <CreditCard className="w-5 h-5" />
            Card Vault — Pending Charges
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">
            Cards collected while Converge IP whitelisting was pending. Click "Charge All Pending Cards"
            to submit all vaulted cards for payment once Converge is live.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3 text-center">
              <p className="text-2xl font-bold text-amber-500">{pendingCards.length}</p>
              <p className="text-xs text-muted-foreground">Pending Charge</p>
            </div>
            <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-3 text-center">
              <p className="text-2xl font-bold text-red-500">{failedCards.length}</p>
              <p className="text-xs text-muted-foreground">Charge Failed</p>
            </div>
            <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/20 p-3 text-center">
              <p className="text-2xl font-bold text-emerald-500">{chargedCards.length}</p>
              <p className="text-xs text-muted-foreground">Successfully Charged</p>
            </div>
          </div>

          {pendingCards.length > 0 && (
            <div className="rounded-lg bg-background border p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Estimated Revenue from Pending Cards</p>
                  <p className="text-xs text-muted-foreground">
                    {pendingCards.length} subscriber{pendingCards.length !== 1 ? 's' : ''} queued for charge
                  </p>
                </div>
                <p className="text-2xl font-bold text-amber-500">
                  ${totalPendingRevenue.toFixed(2)}
                </p>
              </div>
            </div>
          )}

          {pendingCards.length > 0 ? (
            <Button
              onClick={() => setConfirmOpen(true)}
              className="w-full gap-2 bg-amber-500 hover:bg-amber-600 text-white"
              size="lg"
            >
              <Zap className="w-4 h-4" />
              Charge All Pending Cards ({pendingCards.length})
            </Button>
          ) : (
            <div className="text-center py-4 text-sm text-muted-foreground">
              <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-500" />
              No pending cards to charge.
            </div>
          )}

          {/* Pending cards list */}
          {pendingCards.length > 0 && (
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {pendingCards.map((t) => (
                <div key={t.id} className="flex items-center justify-between rounded-md bg-muted/40 px-3 py-2 text-sm">
                  <div>
                    <p className="font-medium">{t.name || t.email}</p>
                    <p className="text-xs text-muted-foreground">{t.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">${(t.billing_amount || 0).toFixed(2)}</p>
                    <p className="text-xs text-muted-foreground">{t.plan_key} · {t.billing_cycle}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Failed charges list */}
          {failedCards.length > 0 && (
            <div className="space-y-1.5 max-h-32 overflow-y-auto">
              <p className="text-xs font-semibold text-red-500">Failed Charges (requires manual follow-up):</p>
              {failedCards.map((t) => (
                <div key={t.id} className="flex items-center justify-between rounded-md bg-red-500/5 border border-red-500/20 px-3 py-2 text-sm">
                  <div>
                    <p className="font-medium">{t.name || t.email}</p>
                    <p className="text-xs text-red-400">{t.charge_error || 'Unknown error'}</p>
                  </div>
                  <p className="font-semibold text-red-500">${(t.billing_amount || 0).toFixed(2)}</p>
                </div>
              ))}
            </div>
          )}

          {/* Results display */}
          {results && (
            <div className="rounded-lg border border-border bg-background p-4 space-y-3">
              <div className="flex items-center gap-2 font-semibold">
                <CheckCircle className="w-5 h-5 text-emerald-500" />
                Batch Charge Results
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div>
                  <p className="text-xl font-bold text-emerald-500">{results.charged}</p>
                  <p className="text-xs text-muted-foreground">Charged</p>
                </div>
                <div>
                  <p className="text-xl font-bold text-red-500">{results.failed}</p>
                  <p className="text-xs text-muted-foreground">Failed</p>
                </div>
                <div>
                  <p className="text-xl font-bold text-primary">${(results.totalCollected || 0).toFixed(2)}</p>
                  <p className="text-xs text-muted-foreground">Collected</p>
                </div>
              </div>
              {results.details && results.details.length > 0 && (
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {results.details.map((d, i) => (
                    <div key={i} className="flex items-center justify-between text-xs px-2 py-1 rounded bg-muted/30">
                      <span className="truncate">{d.name || d.email}</span>
                      {d.status === 'charged' ? (
                        <span className="flex items-center gap-1 text-emerald-500 shrink-0">
                          <CheckCircle className="w-3 h-3" /> ${d.amount.toFixed(2)}
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-red-500 shrink-0" title={d.error}>
                          <XCircle className="w-3 h-3" /> Failed
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-amber-600">
              <AlertTriangle className="w-5 h-5" />
              Charge All Pending Cards?
            </DialogTitle>
            <DialogDescription>
              This will submit {pendingCards.length} vaulted card{pendingCards.length !== 1 ? 's' : ''} to Converge
              for a total of <strong className="text-foreground">${totalPendingRevenue.toFixed(2)}</strong>.
              Each card will be charged its subscription amount. Failed charges will be marked for manual follow-up.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-48 overflow-y-auto rounded-lg border border-border p-3">
            {pendingCards.map((t) => (
              <div key={t.id} className="flex items-center justify-between text-sm">
                <span>{t.name || t.email}</span>
                <span className="font-medium">${(t.billing_amount || 0).toFixed(2)}</span>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmOpen(false)} disabled={charging}>
              Cancel
            </Button>
            <Button
              onClick={handleBatchCharge}
              disabled={charging}
              className="bg-amber-500 hover:bg-amber-600 text-white gap-2"
            >
              {charging ? (
                <><Loader2 className="w-4 h-4 animate-spin" /> Charging...</>
              ) : (
                <><Zap className="w-4 h-4" /> Charge {pendingCards.length} Card{pendingCards.length !== 1 ? 's' : ''}</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}