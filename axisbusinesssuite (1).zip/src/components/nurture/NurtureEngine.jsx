/**
 * NurtureEngine — Background automation layer
 * Call enrollLead(lead, allWorkflows) whenever a lead's status changes.
 * It finds matching active workflows and auto-executes immediate steps.
 */
import { base44 } from '@/api/base44Client';

/**
 * Enroll a lead in any active workflows triggered by their new status,
 * then immediately execute steps with delay_hours === 0.
 */
export async function enrollLead(lead, workflows) {
  if (!lead?.id || !lead?.status) return;
  const matching = workflows.filter(
    w => w.status === 'active' && w.trigger_status === lead.status
  );

  for (const wf of matching) {
    const steps = (() => { try { return JSON.parse(wf.steps || '[]'); } catch { return []; } })();

    // Update enrolled count
    await base44.entities.NurtureWorkflow.update(wf.id, {
      enrolled_count: (wf.enrolled_count || 0) + 1,
    });

    // Execute immediate steps (delay_hours === 0)
    for (const step of steps) {
      if ((step.delay_hours || 0) > 0) continue; // Skip delayed steps (would need scheduled tasks)

      if (step.type === 'task') {
        await base44.functions.invoke('createRecord', { entity: 'FollowUpTask', data: {
          lead_id: lead.id,
          lead_name: `${lead.first_name} ${lead.last_name}`,
          lead_phone: lead.phone,
          task_type: 'call_back',
          priority: 'medium',
          status: 'pending',
          notes: step.message || `Workflow: ${wf.name}`,
          ai_generated: true,
        }});
      } else if (step.type === 'update_status' && step.status) {
        await base44.entities.Lead.update(lead.id, { status: step.status });
      } else if (step.type === 'email' && lead.email) {
        await base44.integrations.Core.SendEmail({
          to: lead.email,
          subject: step.subject || `Follow-up from ${wf.name}`,
          body: step.message || '',
        });
      }
      // 'call', 'sms', 'wait' steps are queued — acknowledged but not auto-executed inline
    }

    // Schedule delayed steps as FollowUpTasks
    for (const step of steps) {
      if ((step.delay_hours || 0) === 0) continue;
      if (!['call', 'email', 'sms', 'task'].includes(step.type)) continue;

      const dueDate = new Date();
      dueDate.setHours(dueDate.getHours() + (step.delay_hours || 24));

      await base44.functions.invoke('createRecord', { entity: 'FollowUpTask', data: {
        lead_id: lead.id,
        lead_name: `${lead.first_name} ${lead.last_name}`,
        lead_phone: lead.phone,
        task_type: step.type === 'call' ? 'call_back' : step.type === 'email' ? 'send_email' : step.type === 'sms' ? 'send_sms' : 'other',
        priority: 'medium',
        status: 'pending',
        due_date: dueDate.toISOString(),
        notes: `[Workflow: ${wf.name}] ${step.message || ''}`.trim(),
        ai_generated: true,
      }});
    }
  }
}

/**
 * Build a rich CRM context block for the AI call script.
 * Pass this into the LLM prompt so the script adapts to the lead.
 */
export function buildCRMContext(lead, callLogs = [], leadScore = null) {
  const priorCalls = callLogs.filter(c => c.lead_id === lead.id);
  const lastCall = priorCalls[0];
  const outcomes = priorCalls.map(c => c.outcome).filter(Boolean);
  const objections = priorCalls
    .filter(c => c.ai_summary)
    .map(c => c.ai_summary)
    .slice(0, 3)
    .join(' | ');

  return `
=== CRM CONTEXT FOR THIS CALL ===
Lead: ${lead.first_name} ${lead.last_name}
Company: ${lead.company || 'Unknown'}
Source: ${lead.source || 'Unknown'}
Status: ${lead.status}
Email: ${lead.email || 'Not on file'}
Notes: ${lead.notes || 'None'}
Consent: ${lead.consent_given ? 'YES — TCPA compliant' : 'Not recorded'}
Call Attempts: ${lead.call_attempts || 0}
${lastCall ? `Last Contact: ${lastCall.created_date && !isNaN(new Date(lastCall.created_date)) ? new Date(lastCall.created_date).toLocaleDateString() : 'Unknown date'} — Outcome: ${lastCall.outcome || lastCall.status}` : 'First Contact: Never been called'}
Prior Outcomes: ${outcomes.length ? outcomes.join(', ') : 'None'}
${objections ? `Prior Call Notes: ${objections}` : ''}
${leadScore ? `Lead Score: ${leadScore.score}/100 (${leadScore.tier?.toUpperCase()}) — ${leadScore.reasoning || ''}` : ''}
${leadScore?.next_action ? `Recommended Action: ${leadScore.next_action}` : ''}
=================================

SCRIPT ADAPTATION INSTRUCTIONS:
- Address ${lead.first_name} by first name
- If they were previously contacted, reference the prior contact naturally
- If prior outcomes show objections, prepare a tailored counter-response
- ${leadScore?.tier === 'hot' ? 'This is a HOT lead — push confidently for immediate appointment' : leadScore?.tier === 'cold' ? 'This is a COLD lead — focus on re-engagement and building interest first' : 'Use standard consultative approach'}
- If they say they are busy, offer a specific callback time
- If they mention a competitor, acknowledge and pivot to unique value
`.trim();
}