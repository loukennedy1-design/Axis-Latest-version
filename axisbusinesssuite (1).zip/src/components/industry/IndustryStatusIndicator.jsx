import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, AlertCircle } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';

export default function IndustryStatusIndicator() {
  const { user } = useCurrentUser();
  
  const { data: settings = [] } = useQuery({
    queryKey: ['system-settings-industry'],
    queryFn: () => base44.entities.SystemSettings.filter({ key: `industry_${user.email}` }),
    initialData: [],
    enabled: !!user,
  });

  if (!settings || settings.length === 0) {
    return (
      <Badge variant="outline" className="gap-1 text-xs border-amber-500/50 text-amber-500">
        <AlertCircle className="w-3 h-3" />
        Configure Industry
      </Badge>
    );
  }

  const industry = settings[0];
  
  return (
    <Badge className="gap-1 text-xs bg-emerald-500/10 text-emerald-500 border-emerald-500/30">
      <CheckCircle2 className="w-3 h-3" />
      {industry.industry || 'Configured'}
    </Badge>
  );
}