import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Building2, Target, Zap, Users, BarChart3, ShieldCheck,
  Settings, Workflow, Brain, CheckCircle2, ArrowRight, RefreshCcw
} from 'lucide-react';

export default function IndustryConfigSummary({ config, settings, onReconfigure }) {
  if (!config || !settings || settings.length === 0) {
    return null;
  }

  const industry = settings[0];
  const modules = config.enabled_modules || [];
  const crmStages = config.crm_stages || [];
  const kpis = config.kpi_targets || {};
  const automations = config.automation_rules || [];
  const aiProfile = config.ai_profile || {};
  const compliance = config.compliance_flags || [];
  const integrations = config.recommended_integrations || [];

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-primary" />
          Industry Configuration: {industry.industry}
          <Badge className="ml-auto bg-emerald-500/10 text-emerald-500 border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Active
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 mb-1">
              <Settings className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Modules</span>
            </div>
            <p className="text-lg font-bold">{modules.length}</p>
          </div>
          <div className="p-3 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 mb-1">
              <Workflow className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">CRM Stages</span>
            </div>
            <p className="text-lg font-bold">{crmStages.length}</p>
          </div>
          <div className="p-3 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Automations</span>
            </div>
            <p className="text-lg font-bold">{automations.length}</p>
          </div>
          <div className="p-3 rounded-lg bg-card border border-border">
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Compliance</span>
            </div>
            <p className="text-lg font-bold">{compliance.length}</p>
          </div>
        </div>

        {/* Configuration Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Modules */}
          <div>
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
              <Settings className="w-3 h-3" />
              Enabled Modules
            </h4>
            <div className="flex flex-wrap gap-1">
              {modules.slice(0, 8).map(m => (
                <Badge key={m} variant="outline" className="text-xs">
                  {m.replace(/_/g, ' ')}
                </Badge>
              ))}
              {modules.length > 8 && (
                <Badge variant="outline" className="text-xs">+{modules.length - 8} more</Badge>
              )}
            </div>
          </div>

          {/* KPIs */}
          <div>
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
              <Target className="w-3 h-3" />
              KPI Targets
            </h4>
            <div className="space-y-1">
              {Object.entries(kpis).slice(0, 4).map(([key, value]) => (
                <div key={key} className="flex justify-between text-xs">
                  <span className="text-muted-foreground">{key.replace(/_/g, ' ')}</span>
                  <span className="font-medium">{value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* AI Profile */}
          <div>
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
              <Brain className="w-3 h-3" />
              AI Configuration
            </h4>
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Personality</span>
                <span className="font-medium capitalize">{aiProfile.personality || industry.ai_personality}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Specialization</span>
                <span className="font-medium">{industry.industry}</span>
              </div>
            </div>
          </div>

          {/* Integrations */}
          <div>
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
              <Users className="w-3 h-3" />
              Recommended Integrations
            </h4>
            <div className="flex flex-wrap gap-1">
              {integrations.slice(0, 4).map(i => (
                <Badge key={i} variant="outline" className="text-xs bg-muted/50">
                  {i}
                </Badge>
              ))}
              {integrations.length === 0 && (
                <span className="text-xs text-muted-foreground">None specified</span>
              )}
            </div>
          </div>
        </div>

        {/* CRM Stages */}
        <div>
          <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
            <Workflow className="w-3 h-3" />
            Sales Pipeline ({crmStages.length} stages)
          </h4>
          <div className="flex flex-wrap gap-2">
            {crmStages.map((stage, i) => (
              <div
                key={stage}
                className="flex items-center gap-2 text-xs px-2 py-1 rounded-md bg-card border border-border"
              >
                <span className="font-medium">{i + 1}.</span>
                <span>{stage}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Automations */}
        {automations.length > 0 && (
          <div>
            <h4 className="text-xs font-semibold mb-2 flex items-center gap-1">
              <Zap className="w-3 h-3" />
              Active Automations
            </h4>
            <div className="space-y-1">
              {automations.slice(0, 3).map((rule, i) => (
                <div key={i} className="text-xs flex items-start gap-2 p-2 rounded-md bg-card border border-border">
                  <Zap className="w-3 h-3 text-primary mt-0.5" />
                  <div>
                    <p className="font-medium">{rule.trigger.replace(/_/g, ' ')}</p>
                    <p className="text-muted-foreground">{rule.action.replace(/_/g, ' ')}</p>
                  </div>
                </div>
              ))}
              {automations.length > 3 && (
                <p className="text-xs text-muted-foreground mt-1">+{automations.length - 3} more automations</p>
              )}
            </div>
          </div>
        )}

        {/* Reconfigure Button */}
        {onReconfigure && (
          <div className="pt-3 border-t border-border">
            <Button
              variant="outline"
              size="sm"
              onClick={onReconfigure}
              className="gap-2 text-xs w-full"
            >
              <RefreshCcw className="w-3 h-3" />
              Reconfigure Industry Settings
            </Button>
          </div>
        )}

        {/* Footer Info */}
        <div className="pt-3 border-t border-border text-xs text-muted-foreground flex items-center justify-between">
          <span>Configured on {new Date(industry.configured_at).toLocaleDateString()}</span>
          <span className="flex items-center gap-1">
            by {industry.configured_by}
            <ArrowRight className="w-3 h-3" />
          </span>
        </div>
      </CardContent>
    </Card>
  );
}