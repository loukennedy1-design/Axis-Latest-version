import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, CheckCircle2, X, Sparkles, Zap } from 'lucide-react';
import { toast } from 'sonner';

export default function DevStudioTaskBacklog() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const items = await base44.entities.AgentTask.filter({ task_type: 'trinity_dev_studio' }, '-created_date', 20).catch(() => []);
      setTasks(items || []);
    } catch (e) { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const approveBuild = async (id) => {
    try {
      await base44.entities.AgentTask.update(id, { status: 'active' });
      toast.success('Task approved for building');
      load();
    } catch (e) { toast.error(e.message); }
  };

  const dismiss = async (id) => {
    try {
      await base44.entities.AgentTask.update(id, { status: 'completed' });
      toast.success('Task dismissed');
      load();
    } catch (e) { toast.error(e.message); }
  };

  const pendingTasks = tasks.filter(t => t.status === 'pending');

  return (
    <div className="rounded-xl border border-border bg-zinc-900/40 p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-violet-400" />
          <span className="text-sm font-semibold">Dev Studio Task Backlog</span>
          {pendingTasks.length > 0 && (
            <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30 text-[9px]">{pendingTasks.length}</Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={load}>
          <RefreshCw className="w-3.5 h-3.5" />
        </Button>
      </div>
      {loading ? (
        <div className="flex items-center gap-2 text-xs text-muted-foreground p-4"><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Loading tasks...</div>
      ) : pendingTasks.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-4">No pending dev studio tasks. Trigger an evolution cycle to discover new features.</p>
      ) : (
        <div className="space-y-2">
          {pendingTasks.map(task => (
            <div key={task.id} className="rounded-lg border border-border/50 bg-zinc-950/40 p-3">
              <div className="flex items-start justify-between gap-2 mb-1">
                <p className="text-sm font-medium">{task.title}</p>
                <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30 text-[9px] py-0 shrink-0">
                  <Zap className="w-2.5 h-2.5 mr-0.5" /> From Evolution
                </Badge>
              </div>
              {task.description && (
                <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{task.description}</p>
              )}
              <div className="flex gap-1">
                <Button size="sm" className="h-6 px-2 text-[10px] gap-1 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={() => approveBuild(task.id)}>
                  <CheckCircle2 className="w-3 h-3" /> Approve Build
                </Button>
                <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px] gap-1" onClick={() => dismiss(task.id)}>
                  <X className="w-3 h-3" /> Dismiss
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}