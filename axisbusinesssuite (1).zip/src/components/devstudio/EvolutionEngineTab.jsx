import React, { useState, useEffect, useCallback, useRef } from 'react';
import { invokeDev, EVOLUTION_STAGES, riskBadgeClass } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  RefreshCw, ArrowUp, Archive, Rocket,
  CheckCircle2, Clock, AlertTriangle, Dna, Activity,
  Search, Filter, FileText, Hammer, GitBranch, Radio, Zap, X, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

const STAGE_ICONS = { Search, Filter, FileText, Clock, Hammer, GitBranch, Radio, Activity };

const STATUS_CONFIG = {
  queued: { color: 'text-muted-foreground', bg: 'bg-muted/30', icon: Clock, label: 'Queued' },
  awaiting_window: { color: 'text-amber-400', bg: 'bg-amber-500/10', icon: Clock, label: 'Awaiting Window' },
  in_progress: { color: 'text-violet-400', bg: 'bg-violet-500/10', icon: RefreshCw, label: 'In Progress' },
  completed: { color: 'text-emerald-400', bg: 'bg-emerald-500/10', icon: CheckCircle2, label: 'Completed' },
  skipped: { color: 'text-muted-foreground', bg: 'bg-muted/20', icon: Archive, label: 'Skipped' },
  flagged_for_review: { color: 'text-destructive', bg: 'bg-destructive/10', icon: AlertTriangle, label: 'Flagged' }
};

// Map latest evolution action to pipeline stage state
function mapActionToStages(action) {
  if (!action) return { completed: [], active: 'research' };
  if (action === 'research_cycle_no_candidates') {
    return { completed: ['research', 'value_filter'], active: null };
  }
  if (action === 'research_cycle_completed') {
    return { completed: ['research', 'value_filter'], active: 'plan' };
  }
  if (action === 'implementation_plan_generated') {
    return { completed: ['research', 'value_filter', 'plan'], active: 'window' };
  }
  if (action === 'deployment_deferred') {
    return { completed: ['research', 'value_filter', 'plan'], active: 'window' };
  }
  if (action === 'feature_deployed') {
    return { completed: ['research', 'value_filter', 'plan', 'window', 'build', 'cascade', 'broadcast'], active: null };
  }
  return { completed: [], active: 'research' };
}

export default function EvolutionEngineTab() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [summary, setSummary] = useState(null);
  const [stageState, setStageState] = useState({ completed: [], active: 'research' });
  const [cycleStartTime, setCycleStartTime] = useState(null);
  const pollRef = useRef(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [backlogRes, summaryRes, statusRes] = await Promise.all([
        invokeDev('evolution_log', {}),
        invokeDev('evolution_summary', {}),
        invokeDev('evolution_status', {})
      ]);
      if (backlogRes.data?.result?.items) setItems(backlogRes.data.result.items);
      if (summaryRes.data?.result?.summary) setSummary(summaryRes.data.result.summary);
      if (statusRes.data?.result) {
        setStageState(mapActionToStages(statusRes.data.result.latest_action));
      }
    } catch (e) { toast.error('Failed to load evolution data'); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  // Poll evolution_status every 4s while triggering
  useEffect(() => {
    if (!triggering) return;
    const poll = async () => {
      try {
        const res = await invokeDev('evolution_status', {});
        const result = res.data?.result;
        if (!result) return;
        setStageState(mapActionToStages(result.latest_action));
        if (result.status === 'idle' || result.status === 'complete') {
          setTriggering(false);
          setCycleStartTime(null);
          toast.success(result.status === 'complete' ? 'Evolution cycle complete' : 'Evolution cycle finished');
          load();
        }
      } catch (e) { /* keep polling */ }
    };
    pollRef.current = setInterval(poll, 4000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [triggering, load]);

  const triggerCycle = async () => {
    setTriggering(true);
    setCycleStartTime(new Date().toISOString());
    setStageState({ completed: [], active: 'research' });
    try {
      const res = await invokeDev('evolution_trigger', {});
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Evolution cycle triggered — pipeline running');
    } catch (e) {
      toast.error(e.message);
      setTriggering(false);
      setCycleStartTime(null);
    }
  };

  const cancelPolling = () => {
    setTriggering(false);
    setCycleStartTime(null);
    toast.info('Polling stopped — cycle may still be running in background');
    load();
  };

  const promote = async (id, newStatus) => {
    try {
      await invokeDev('evolution_promote', { backlog_id: id, status: newStatus });
      toast.success(`Item ${newStatus}`);
      load();
    } catch (e) { toast.error(e.message); }
  };

  const sorted = [...items].sort((a, b) => (b.impact_score + b.urgency_score) - (a.impact_score + a.urgency_score));

  return (
    <div className="space-y-4">
      {/* Pipeline visualization */}
      <div className="rounded-xl border border-violet-500/20 bg-zinc-950/60 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Dna className="w-4 h-4 text-violet-400" />
            <span className="text-sm font-semibold">Evolution Pipeline</span>
            {triggering && (
              <Badge className="gap-1 bg-violet-500/20 text-violet-300 border-violet-500/30 text-[10px]">
                <RefreshCw className="w-2.5 h-2.5 animate-spin" /> Running...
              </Badge>
            )}
          </div>
          <div className="flex gap-1.5">
            {triggering ? (
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={cancelPolling}>
                <X className="w-3.5 h-3.5" /> Stop Polling
              </Button>
            ) : (
              <Button variant="ghost" size="sm" className="gap-1.5 text-xs" onClick={load}>
                <RefreshCw className="w-3.5 h-3.5" /> Refresh
              </Button>
            )}
            <Button className="gap-2 bg-violet-600 hover:bg-violet-700 text-white" size="sm" disabled={triggering} onClick={triggerCycle}>
              {triggering ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
              Trigger Cycle
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-1 overflow-x-auto pb-2">
          {EVOLUTION_STAGES.map((stage, i) => {
            const Icon = STAGE_ICONS[stage.icon] || Activity;
            const isCompleted = stageState.completed.includes(stage.id);
            const isActive = stageState.active === stage.id;
            return (
              <React.Fragment key={stage.id}>
                <div
                  className={`flex flex-col items-center gap-1 px-2 py-2 rounded-lg min-w-[90px] transition-all border ${
                    isCompleted ? 'border-emerald-500/40 bg-emerald-500/10' :
                    isActive ? 'border-violet-500/50 bg-violet-500/15 animate-pulse' :
                    'border-transparent opacity-40'
                  }`}
                >
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    isCompleted ? 'bg-emerald-500/20 text-emerald-400' :
                    isActive ? 'bg-violet-500/30 text-violet-300' :
                    'bg-muted/40 text-muted-foreground'
                  }`}>
                    {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Icon className="w-3.5 h-3.5" />}
                  </div>
                  <span className={`text-[10px] font-medium ${
                    isCompleted ? 'text-emerald-400' :
                    isActive ? 'text-violet-300' :
                    'text-muted-foreground'
                  }`}>{stage.label}</span>
                </div>
                {i < EVOLUTION_STAGES.length - 1 && (
                  <div className={`h-px w-4 shrink-0 ${isCompleted ? 'bg-emerald-500/40' : 'bg-border'}`} />
                )}
              </React.Fragment>
            );
          })}
        </div>
      </div>

      {/* Summary KPIs */}
      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { label: 'Researched', value: summary.items_researched || 0, icon: Search, color: 'text-blue-400' },
            { label: 'Passed Filter', value: summary.items_passed_filter || 0, icon: Filter, color: 'text-emerald-400' },
            { label: 'Deployed', value: summary.items_deployed || 0, icon: Rocket, color: 'text-violet-400' },
            { label: 'Flagged', value: summary.items_flagged || 0, icon: AlertTriangle, color: 'text-amber-400' }
          ].map(s => {
            const Icon = s.icon;
            return (
              <div key={s.label} className="rounded-lg border border-border bg-zinc-900/40 p-3">
                <Icon className={`w-4 h-4 ${s.color} mb-1`} />
                <p className="text-xl font-bold">{s.value}</p>
                <p className="text-[10px] text-muted-foreground">{s.label}</p>
              </div>
            );
          })}
        </div>
      )}

      {/* Backlog cards */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold">Evolution Backlog</h3>
        </div>
        {loading ? (
          <div className="flex items-center gap-2 text-xs text-muted-foreground p-6"><RefreshCw className="w-3.5 h-3.5 animate-spin" /> Loading backlog...</div>
        ) : sorted.length === 0 ? (
          <div className="text-center py-10 border border-dashed border-border rounded-xl">
            <Dna className="w-6 h-6 mx-auto mb-2 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No backlog items yet. Trigger a cycle to research new features.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {sorted.map((item, idx) => {
              const cfg = STATUS_CONFIG[item.status] || STATUS_CONFIG.queued;
              const StatusIcon = cfg.icon;
              const valueScore = (item.impact_score || 0) + (item.urgency_score || 0);
              const isNew = cycleStartTime && item.created_date && new Date(item.created_date) > new Date(cycleStartTime);
              return (
                <div key={item.id} className={`rounded-xl border ${cfg.bg} border-border/50 p-3 ${isNew ? 'ring-1 ring-violet-500/30' : ''}`}>
                  <div className="flex items-start gap-3">
                    <span className="text-lg font-bold text-muted-foreground/40 shrink-0">#{idx + 1}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-sm font-medium truncate">{item.title}</p>
                            {isNew && (
                              <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30 text-[9px] py-0 gap-0.5">
                                <Sparkles className="w-2.5 h-2.5" /> New
                              </Badge>
                            )}
                          </div>
                          {item.subscriber_value_statement && (
                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{item.subscriber_value_statement}</p>
                          )}
                        </div>
                        <Badge variant="outline" className={`shrink-0 text-[9px] ${cfg.color} border-current/30 ${cfg.bg}`}>
                          <StatusIcon className="w-2.5 h-2.5 mr-1" />{cfg.label}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <span className="text-blue-400 font-semibold">{item.impact_score || 0}</span> Impact
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="text-amber-400 font-semibold">{item.urgency_score || 0}</span> Urgency
                        </span>
                        <span className="flex items-center gap-1">
                          <span className="text-violet-400 font-semibold">{valueScore}</span> Total
                        </span>
                        {item.risk_level && (
                          <Badge className={`text-[9px] py-0 ${riskBadgeClass(item.risk_level)}`}>{item.risk_level.toUpperCase()}</Badge>
                        )}
                        {item.source && (
                          <span className="capitalize">{item.source.replace(/_/g, ' ')}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-1 mt-2 ml-8">
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px] gap-1" onClick={() => promote(item.id, 'queued')}>
                      <ArrowUp className="w-3 h-3" /> Queue
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px] gap-1" onClick={() => promote(item.id, 'flagged_for_review')}>
                      <AlertTriangle className="w-3 h-3" /> Flag
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-[10px] gap-1" onClick={() => promote(item.id, 'skipped')}>
                      <Archive className="w-3 h-3" /> Archive
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}