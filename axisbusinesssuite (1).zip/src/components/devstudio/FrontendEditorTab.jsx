import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { invokeDev, isFrontendProtected, KNOWN_FRONTEND_FILES } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Search, FileCode, Lock, RefreshCw, Eye, Rocket,
  Sparkles, Folder, FolderOpen, CheckCircle2, AlertTriangle, XCircle,
  ShieldAlert
} from 'lucide-react';
import { toast } from 'sonner';

export default function FrontendEditorTab({ chat }) {
  const [files, setFiles] = useState({ pages: [], components: [] });
  const [loadingTree, setLoadingTree] = useState(true);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState('');
  const [source, setSource] = useState('');
  const [loadingSrc, setLoadingSrc] = useState(false);
  const [isProtected, setIsProtected] = useState(false);
  const [safetyStatus, setSafetyStatus] = useState(null);
  const [confirmPhrase, setConfirmPhrase] = useState('');
  const [deploying, setDeploying] = useState(false);
  const [deployResult, setDeployResult] = useState(null);

  const loadTree = useCallback(async () => {
    setLoadingTree(true);
    try {
      const res = await invokeDev('list_frontend_files', {});
      const result = res.data?.result;
      // Fallback to curated list if sandbox can't access src/
      if (!result || (result.pages.length === 0 && result.components.length === 0)) {
        setFiles(KNOWN_FRONTEND_FILES);
      } else {
        setFiles(result);
      }
    } catch (e) {
      setFiles(KNOWN_FRONTEND_FILES);
    }
    setLoadingTree(false);
  }, []);

  const checkSafety = useCallback(async () => {
    try {
      const res = await invokeDev('safety_gate_check', {});
      setSafetyStatus(res.data?.result);
    } catch (_) {}
  }, []);

  useEffect(() => { loadTree(); checkSafety(); }, [loadTree, checkSafety]);

  const allFiles = useMemo(() => {
    const pages = files.pages.map(f => ({ path: f, label: f.replace('src/pages/', ''), group: 'Pages' }));
    const comps = files.components.map(f => ({ path: f, label: f.replace('src/components/', ''), group: 'Components' }));
    return [...pages, ...comps];
  }, [files]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return allFiles.filter(f => f.path.toLowerCase().includes(q));
  }, [allFiles, search]);

  const loadFile = async (path) => {
    setSelected(path);
    setSource('');
    setDeployResult(null);
    setConfirmPhrase('');
    setLoadingSrc(true);
    try {
      const res = await invokeDev('read_frontend_file', { file_path: path });
      if (res.data?.error) throw new Error(res.data.error);
      const result = res.data?.result;
      setIsProtected(result?.protected);
      if (result?.source) {
        setSource(result.source);
      } else {
        setSource(`// ${path}\n// Source not available in runtime — draft mode active.\n// You may write new content and deploy.\n\n`);
        toast.info('Runtime source unavailable — draft mode');
      }
    } catch (e) {
      toast.error(e.message);
    }
    setLoadingSrc(false);
  };

  const askTrinity = (action) => {
    if (!selected) return toast.error('Select a file first');
    const prompt = `${action} for the file "${selected}". Current source:\n\n${source.slice(0, 3000)}`;
    chat.sendMessage(prompt);
    toast.success('Sent to Trinity — check the chat panel');
  };

  const deploy = async () => {
    setDeploying(true);
    setDeployResult(null);
    try {
      const res = await invokeDev('deploy_artifact', {
        file_path: selected,
        content: source,
        risk_level: 'medium',
        confirm_phrase: confirmPhrase,
        artifact_type: 'frontend'
      });
      if (res.data?.error) throw new Error(res.data.error);
      setDeployResult({ status: 'success', message: `${selected} deployed successfully.` });
      toast.success('Artifact deployed');
    } catch (e) {
      setDeployResult({ status: 'failed', message: e.message });
      toast.error(e.message);
    }
    setDeploying(false);
  };

  const safetyBlocked = safetyStatus && !safetyStatus.passed;

  return (
    <div className="space-y-3">
      {safetyBlocked && (
        <div className="flex items-start gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/30 rounded-lg px-3 py-2">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Safety Gate Active</p>
            <p className="mt-0.5">{safetyStatus.reasons.join(' ')}</p>
            <p className="mt-1 text-destructive/70">Deploys are blocked until active sessions resolve.</p>
          </div>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-3">
        {/* File tree */}
        <div className="lg:w-72 shrink-0 space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search files..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 text-sm"
            />
          </div>
          <div className="max-h-[400px] overflow-y-auto rounded-lg border border-border bg-zinc-900/40">
            {loadingTree ? (
              <div className="flex items-center gap-2 text-xs text-muted-foreground p-4">
                <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Loading files...
              </div>
            ) : (
              <div className="divide-y divide-border/30">
                {filtered.map(f => {
                  const locked = isFrontendProtected(f.path);
                  const active = selected === f.path;
                  return (
                    <button
                      key={f.path}
                      onClick={() => loadFile(f.path)}
                      className={`w-full flex items-center gap-2 px-3 py-1.5 text-left text-xs transition-colors ${active ? 'bg-emerald-500/15 text-emerald-300' : 'hover:bg-muted/40'}`}
                    >
                      {locked ? <Lock className="w-3 h-3 text-amber-400 shrink-0" /> : <FileCode className="w-3 h-3 text-muted-foreground shrink-0" />}
                      <span className="truncate font-mono">{f.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 min-w-0 space-y-2">
          {selected ? (
            <>
              <div className="rounded-xl border border-emerald-500/30 bg-zinc-950 overflow-hidden">
                <div className="px-3 py-2 border-b border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between">
                  <span className="text-xs font-mono text-emerald-300 flex items-center gap-2">
                    <FileCode className="w-3.5 h-3.5" />{selected}
                  </span>
                  <div className="flex items-center gap-2">
                    {isProtected && <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-400">PROTECTED</Badge>}
                    <span className="text-xs text-muted-foreground">{source.split('\n').length} lines</span>
                  </div>
                </div>
                {loadingSrc ? (
                  <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground">
                    <RefreshCw className="w-4 h-4 animate-spin" /> Loading source...
                  </div>
                ) : (
                  <textarea
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                    readOnly={isProtected}
                    spellCheck={false}
                    className="w-full min-h-[340px] bg-zinc-950 text-emerald-300 font-mono text-xs p-4 outline-none resize-y leading-relaxed"
                  />
                )}
              </div>

              {!isProtected && (
                <>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" className="gap-1.5 border-violet-500/30 hover:bg-violet-500/10" onClick={() => askTrinity('Improve this file')}>
                      <Sparkles className="w-3.5 h-3.5 text-violet-400" /> Improve
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1.5 border-violet-500/30 hover:bg-violet-500/10" onClick={() => askTrinity('Add a feature to this page')}>
                      <Sparkles className="w-3.5 h-3.5 text-violet-400" /> Add Feature
                    </Button>
                    <Button variant="outline" size="sm" className="gap-1.5 border-violet-500/30 hover:bg-violet-500/10" onClick={() => askTrinity('Fix this component')}>
                      <Sparkles className="w-3.5 h-3.5 text-violet-400" /> Fix
                    </Button>
                  </div>

                  {safetyBlocked ? (
                    <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4" /> Safety gate active — deploy blocked
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Input
                          placeholder="Type 'I confirm this change' to enable deploy"
                          value={confirmPhrase}
                          onChange={(e) => setConfirmPhrase(e.target.value)}
                          className="text-sm bg-zinc-900/60"
                        />
                        <Button
                          className="gap-2 bg-primary hover:bg-primary/90 shrink-0"
                          disabled={deploying || confirmPhrase !== 'I confirm this change' || safetyBlocked}
                          onClick={deploy}
                          size="sm"
                        >
                          {deploying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Rocket className="w-3.5 h-3.5" />}
                          Commit & Wire
                        </Button>
                      </div>
                    </div>
                  )}

                  {deployResult && (
                    <div className={`rounded-lg border p-2.5 text-xs flex items-start gap-2 ${deployResult.status === 'success' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400' : 'border-destructive/30 bg-destructive/10 text-destructive'}`}>
                      {deployResult.status === 'success' ? <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 shrink-0" />}
                      {deployResult.message}
                    </div>
                  )}
                </>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-[340px] text-center border border-dashed border-border rounded-xl">
              <FileCode className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm text-muted-foreground">Select a file from the tree to edit</p>
              <p className="text-xs text-muted-foreground/50 mt-1">Protected files (App.jsx, AuthContext, etc.) are read-only</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}