import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { invokeDev, PROTECTED_CORE, ALL_FUNCTIONS, riskBadgeClass } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Search, Code2, Lock, RefreshCw, Eye, Rocket,
  CheckCircle2, AlertTriangle, XCircle, ShieldCheck, FileCode, ShieldAlert, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

export default function BackendEditorTab({ chat }) {
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState('');
  const [source, setSource] = useState('');
  const [loadingSrc, setLoadingSrc] = useState(false);
  const [review, setReview] = useState(null);
  const [reviewing, setReviewing] = useState(false);
  const [riskAck, setRiskAck] = useState(false);
  const [deploying, setDeploying] = useState(false);
  const [deployResult, setDeployResult] = useState(null);
  const [safetyStatus, setSafetyStatus] = useState(null);

  const checkSafety = useCallback(async () => {
    try {
      const res = await invokeDev('safety_gate_check', {});
      setSafetyStatus(res.data?.result);
    } catch (_) {}
  }, []);

  useEffect(() => { checkSafety(); }, [checkSafety]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return ALL_FUNCTIONS.filter(f => f.toLowerCase().includes(q)).sort();
  }, [search]);

  const loadSource = async (fn) => {
    if (PROTECTED_CORE.includes(fn)) return toast.error(`${fn} is a protected core function — read-only.`);
    setSelected(fn);
    setSource('');
    setReview(null);
    setDeployResult(null);
    setRiskAck(false);
    setLoadingSrc(true);
    try {
      const res = await invokeDev('read_function_source', { function_name: fn });
      if (res.data?.error) throw new Error(res.data.error);
      if (res.data?.result?.source) {
        setSource(res.data.result.source);
      } else {
        setSource(`// Source for "${fn}" not readable at runtime (sandboxed deploy).\n// Draft a new implementation below.\n\nDeno.serve(async (req) => {\n  try {\n    // your code here\n    return Response.json({ ok: true });\n  } catch (e) {\n    return Response.json({ error: e.message }, { status: 500 });\n  }\n});\n`);
        toast.info('Runtime source unavailable — draft mode');
      }
    } catch (e) { toast.error(e.message); }
    setLoadingSrc(false);
  };

  const reviewChanges = async () => {
    setReviewing(true);
    setReview(null);
    try {
      const res = await invokeDev('dev_studio_plan', {
        prompt: `Analyze this code change for backend function "${selected}". Summarize what changed, flag conflicts with core system functions, and rate risk.`
      });
      if (res.data?.error) throw new Error(res.data.error);
      setReview(res.data?.result?.plan);
      setRiskAck(false);
      toast.success('Pre-deploy analysis complete');
    } catch (e) { toast.error(e.message); }
    setReviewing(false);
  };

  const deploy = async () => {
    setDeploying(true);
    setDeployResult(null);
    try {
      const res = await invokeDev('deploy_function', {
        function_name: selected,
        updated_code: source,
        risk_level: review?.risk_level || 'medium',
        risk_acknowledged: true
      });
      if (res.data?.error) throw new Error(res.data.error);
      setDeployResult({
        status: res.data?.result?.deployed ? 'success' : 'warning',
        message: res.data?.result?.deployed ? `${selected} deployed successfully.` : `Deploy logged — runtime write unavailable: ${res.data?.result?.error || 'sandbox restriction'}`
      });
      toast.success('Deploy attempted');
    } catch (e) {
      setDeployResult({ status: 'failed', message: e.message });
      toast.error(e.message);
    }
    setDeploying(false);
  };

  const safetyBlocked = safetyStatus && !safetyStatus.passed;

  return (
    <div className="space-y-3">
      {safetyBlocked && (
        <div className="flex items-start gap-2 text-xs text-destructive bg-destructive/10 border border-destructive/30 rounded-lg px-3 py-2">
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Safety Gate Active</p>
            <p className="mt-0.5">{safetyStatus.reasons.join(' ')}</p>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2">
        <Lock className="w-3.5 h-3.5 shrink-0" />
        Protected core functions are locked and cannot be edited.
      </div>

      <div className="flex flex-col lg:flex-row gap-3">
        {/* Function list */}
        <div className="lg:w-72 shrink-0 space-y-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search functions..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 font-mono text-sm" />
          </div>
          <div className="max-h-[400px] overflow-y-auto rounded-lg border border-border bg-zinc-900/40 divide-y divide-border/30">
            {filtered.slice(0, 80).map(fn => {
              const locked = PROTECTED_CORE.includes(fn);
              const active = selected === fn;
              return (
                <button key={fn} disabled={locked} onClick={() => loadSource(fn)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 text-left text-xs font-mono transition-colors ${active ? 'bg-emerald-500/15 text-emerald-300' : 'hover:bg-muted/40'} ${locked ? 'opacity-50 cursor-not-allowed' : ''}`}>
                  <span className="flex items-center gap-2">
                    {locked ? <Lock className="w-3 h-3 text-amber-400" /> : <Code2 className="w-3 h-3 text-muted-foreground" />}
                    {fn}
                  </span>
                  {locked && <Badge variant="outline" className="text-[9px] border-amber-500/30 text-amber-400">PROTECTED</Badge>}
                </button>
              );
            })}
          </div>
        </div>

        {/* Editor */}
        <div className="flex-1 min-w-0 space-y-2">
          {selected ? (
            <>
              <div className="rounded-xl border border-emerald-500/30 bg-zinc-950 overflow-hidden">
                <div className="px-3 py-2 border-b border-emerald-500/20 bg-emerald-500/5 flex items-center justify-between">
                  <span className="text-xs font-mono text-emerald-300 flex items-center gap-2"><FileCode className="w-3.5 h-3.5" />{selected}/entry.ts</span>
                  <span className="text-xs text-muted-foreground">{source.split('\n').length} lines</span>
                </div>
                {loadingSrc ? (
                  <div className="p-6 flex items-center gap-2 text-sm text-muted-foreground"><RefreshCw className="w-4 h-4 animate-spin" /> Loading...</div>
                ) : (
                  <textarea value={source} onChange={(e) => setSource(e.target.value)} spellCheck={false}
                    className="w-full min-h-[340px] bg-zinc-950 text-emerald-300 font-mono text-xs p-4 outline-none resize-y leading-relaxed" />
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" className="gap-1.5 border-emerald-500/30 hover:bg-emerald-500/10" disabled={reviewing || !source} onClick={reviewChanges}>
                  {reviewing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />} Review Changes
                </Button>
                <Button variant="outline" size="sm" className="gap-1.5 border-violet-500/30 hover:bg-violet-500/10" onClick={() => chat.sendMessage(`Improve the backend function "${selected}". Current source:\n\n${source.slice(0, 3000)}`)}>
                  <Sparkles className="w-3.5 h-3.5 text-violet-400" /> Ask Trinity
                </Button>
              </div>

              {review && (
                <div className="rounded-xl border border-emerald-500/30 bg-zinc-900/60 overflow-hidden">
                  <div className="px-3 py-2 border-b border-border bg-emerald-500/5 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm font-semibold">Pre-Deploy Analysis</span>
                    <Badge className={`ml-auto ${riskBadgeClass(review.risk_level)}`}>{(review.risk_level || 'low').toUpperCase()}</Badge>
                  </div>
                  <div className="p-3 space-y-2">
                    {review.steps?.length > 0 && (
                      <ul className="space-y-1 text-sm">
                        {review.steps.map((s, i) => <li key={i} className="flex items-start gap-2"><span className="text-emerald-400 mt-0.5">•</span>{s}</li>)}
                      </ul>
                    )}
                    {review.warnings?.length > 0 && (
                      <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 space-y-1">
                        {review.warnings.map((w, i) => <div key={i} className="flex items-start gap-1.5 text-xs text-amber-400"><AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" />{w}</div>)}
                      </div>
                    )}
                    {(review.risk_level === 'medium' || review.risk_level === 'high') && (
                      <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-amber-500/30 bg-amber-500/5 cursor-pointer">
                        <Checkbox checked={riskAck} onCheckedChange={setRiskAck} className="mt-0.5" />
                        <span className="text-xs text-amber-400">I confirm this {review.risk_level} risk change will not destabilize core functions.</span>
                      </label>
                    )}
                    <Button className="gap-2 bg-primary hover:bg-primary/90" size="sm"
                      disabled={deploying || ((review.risk_level === 'medium' || review.risk_level === 'high') && !riskAck) || safetyBlocked}
                      onClick={deploy}>
                      {deploying ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Rocket className="w-3.5 h-3.5" />} Approve & Deploy
                    </Button>
                  </div>
                </div>
              )}

              {deployResult && (
                <div className={`rounded-lg border p-2.5 text-xs flex items-start gap-2 ${deployResult.status === 'success' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400' : deployResult.status === 'warning' ? 'border-amber-500/30 bg-amber-500/10 text-amber-400' : 'border-destructive/30 bg-destructive/10 text-destructive'}`}>
                  {deployResult.status === 'success' ? <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> : deployResult.status === 'warning' ? <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 shrink-0" />}
                  {deployResult.message}
                </div>
              )}
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-[340px] text-center border border-dashed border-border rounded-xl">
              <Code2 className="w-8 h-8 text-muted-foreground/40 mb-3" />
              <p className="text-sm text-muted-foreground">Select a function to edit</p>
              <p className="text-xs text-muted-foreground/50 mt-1">Protected core functions are locked</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}