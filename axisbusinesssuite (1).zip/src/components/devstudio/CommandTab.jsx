import React from 'react';
import TrinityChatPanel from './TrinityChatPanel';
import ActivityFeed from './ActivityFeed';
import DevStudioTaskBacklog from './DevStudioTaskBacklog';

export default function CommandTab({ chat }) {
  return (
    <div className="space-y-3">
      <div className="flex flex-col lg:flex-row gap-3 h-[calc(100vh-380px)] min-h-[300px]">
        <div className="flex-1 min-w-0">
          <TrinityChatPanel chat={chat} />
        </div>
        <div className="flex-1 min-w-0">
          <ActivityFeed />
        </div>
      </div>
      <DevStudioTaskBacklog />
    </div>
  );
}