import { base44 } from '@/api/base44Client';

export const PROTECTED_CORE = [
  'billingAutomationAgent', 'autoChargeTrialUsers', 'globalBillingToggle',
  'verifyAccessCode', 'secureSecretBroker', 'meetSignaling',
  'onNewSubscriber', 'onPaymentFailed', 'upgradePlan', 'dailySecurityAudit'
];

export const PROTECTED_FRONTEND = [
  'src/App.jsx', 'src/lib/AuthContext', 'src/main.jsx', 'src/index.css',
  'tailwind.config.js', 'src/api/base44Client', 'src/lib/query-client',
  'src/components/ProtectedRoute', 'src/components/UserNotRegisteredError'
];

export const ALL_FUNCTIONS = [
  'accountingEngine','agenticCrm','aiDocumentGeneration','aiGovernanceTrustLayer','aiLifecycleAutomation',
  'aiOperationsCenter','aiRevenueEngine','analyzeCallCoaching','autoChargeTrialUsers','autonomousAgentMatrix',
  'autonomousQuoting','autonomousSecurityMonitor','axisGovernanceCore','billingAutomationAgent',
  'broadcastDeploymentComplete','broadcastPlatformUpdate','bulkImportLeads','calculatePayroll',
  'cancelExpiredPendingInvites','cancelInactiveAccounts','chargebackProtection','clearCallData',
  'configureIndustryAdapter','convergeCheckout','convergeHostedPayment','createAgentTask',
  'createDeploymentCheckpoint','createEngagementObject','createLead','createRecord','createTrialAndCharge',
  'crossDepartmentSync','dailySecurityAudit','dealKnowledgeGraph','deepIntelligenceWorkspace',
  'deleteJobPosting','deleteMeeting','digitalEmployeeFramework','disconnectGoogleCalendar','disconnectOAuth',
  'enterprisePortal','executeAchDeposit','finalizeCandidateDoc','financeOperations','generateCourseContent',
  'generateMarketingBrief','generateSocialContent','generateVideoPresentation','getGoogleCalendarStatus',
  'getOAuthConnections','getTwilioConfig','globalBillingToggle','globalCommandCenter','googleCalendarAuth',
  'googleCalendarCallback','hrAccessControl','hrOperations','hrTalentEngine','indeedEnterpriseEngine',
  'industryMicroAppsGenerator','initializeDefaultModules','inventoryAssetManagement',
  'knowledgeDocumentIntelligence','knownCallerRecognitionEngine','leadGeneration','leadStatusAutomation',
  'legalComplianceWorkspace','llmOrchestration','logOmnichannelInteraction','manageNonPayingAccounts',
  'marketingEngine','meetSignaling','meetingIntelligence','meetingReminders','notifyNewCandidate',
  'notifyUpdateEmail','oauthAuthorize','oauthCallback','omnicoreAIX','omnicoreBrainEngine','onLeadVerified',
  'onNewSubscriber','onPaymentFailed','operationalWorkflowEngine','productionAIOrchestrator',
  'productionFulfillmentManagement','publicCareers','publishScheduledSocialPosts','pushAppointmentToCalendar',
  'quickbooksSync','reactivateUserAccount','resendPendingLoginInfo','residualEngine','runAgentTasks',
  'salesToOperationsWorkflow','saveUserSettings','secretVaultClient','secureSecretBroker','sendAdminAlert',
  'sendChatNotification','sendFollowUpEmail','sendMovementInvite','sendNewSubscriberLoginEmail',
  'sendSlackAlert','sendSms','sendTransactionalEmail','signalToExecutionEngine','socialIntegrationEngine',
  'squareWebhookHandler','syncFacebookLeads','syncGoogleCalendar','syncHREmployeeToSalesRep',
  'syncMeetingToCalendar','testSmtpConnection','trackReferralSignup','trinityDailyOps',
  'trinityExecutiveIntelligence','trinityFeatureResearch','trinitySetupAssistant','trinitySystemCommand',
  'universalIntegrationHub','universalOperationalAI','universalTrackingGateway','upgradePlan','userCredentials',
  'validateCreditCardsOnFile','validatePhase1Deployment','verifyAccessCode','verifyRepPortalAccess',
  'voiceBiometricsEngine','voiceConversationEngine','voiceDeploymentAudit','weeklySystemUpdate','zoomOAuth'
];

export const TIERS = ['solo', 'growth', 'business', 'enterprise', 'agency', 'movement'];
export const MODULES = [
  'call_bot','lead_scoring','nurture_workflows','coaching','lead_generator',
  'recruitment','email','social_media','hr','financial_ops','axis_meet','academy'
];

export const invokeDev = (command, params = {}) =>
  base44.functions.invoke('trinitySystemCommand', { command, params });

export const riskBadgeClass = (level) => {
  const map = {
    low: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    medium: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    high: 'bg-destructive/10 text-destructive border-destructive/30'
  };
  return map[level] || map.low;
};

export const EVOLUTION_STAGES = [
  { id: 'research', label: 'Research', icon: 'Search' },
  { id: 'value_filter', label: 'Value Filter', icon: 'Filter' },
  { id: 'plan', label: 'Plan', icon: 'FileText' },
  { id: 'window', label: 'Window Detection', icon: 'Clock' },
  { id: 'build', label: 'Build', icon: 'Hammer' },
  { id: 'cascade', label: 'Cascade', icon: 'GitBranch' },
  { id: 'broadcast', label: 'Broadcast', icon: 'Radio' },
  { id: 'signal_check', label: 'Signal Check', icon: 'Activity' }
];

export const ACTION_LABELS = {
  plan_generated: 'Generating plan',
  plan_approved_deployed: 'Plan approved',
  read_function_source: 'Reading function',
  read_frontend_file: 'Reading file',
  deploy_function: 'Deploying function',
  deploy_artifact: 'Writing artifact',
  create_entity_schema: 'Creating entity schema',
  module_release_preview: 'Previewing release',
  module_release_confirm: 'Releasing modules',
  evolution_trigger: 'Triggering evolution',
  evolution_rollback: 'Rolling back',
  evolution_promote: 'Promoting item',
  suggest_entity_fields: 'Suggesting fields',
  research_cycle_completed: 'Researching'
};

export const formatTimestamp = (dateStr) => {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

export const isFrontendProtected = (filePath) =>
  PROTECTED_FRONTEND.some(p => filePath.startsWith(p));

// Curated fallback — used when the Deno sandbox can't scan src/ at runtime
export const KNOWN_FRONTEND_FILES = {
  pages: [
    'src/pages/Dashboard.jsx','src/pages/Leads.jsx','src/pages/ImportCSV.jsx','src/pages/CallBot.jsx',
    'src/pages/CallLogs.jsx','src/pages/Appointments.jsx','src/pages/DNCRegistry.jsx','src/pages/Compliance.jsx',
    'src/pages/FollowUpTasks.jsx','src/pages/ImportWizard.jsx','src/pages/UniversalImport.jsx',
    'src/pages/NurtureWorkflows.jsx','src/pages/LeadScoring.jsx','src/pages/CoachingHub.jsx',
    'src/pages/LeadRouting.jsx','src/pages/CallCalendar.jsx','src/pages/ComplianceExport.jsx',
    'src/pages/MyTeam.jsx','src/pages/LeadGenerator.jsx','src/pages/FacebookLeads.jsx',
    'src/pages/SalesTeam.jsx','src/pages/ZoomScheduler.jsx','src/pages/Recruitment.jsx',
    'src/pages/PricingCheckout.jsx','src/pages/CheckoutConfirmation.jsx','src/pages/Email.jsx',
    'src/pages/AEChat.jsx','src/pages/AEOnboarding.jsx','src/pages/TrialSignup.jsx',
    'src/pages/TermsOfService.jsx','src/pages/PrivacyPolicy.jsx','src/pages/SubscriptionManagement.jsx',
    'src/pages/SocialMedia.jsx','src/pages/HumanResources.jsx','src/pages/SmsInbox.jsx',
    'src/pages/LandingPage.jsx','src/pages/MovementSignup.jsx','src/pages/ApiCenter.jsx',
    'src/pages/AgentTasks.jsx','src/pages/UserSettings.jsx','src/pages/DemoMode.jsx',
    'src/pages/Academy.jsx','src/pages/CorporateCommand.jsx','src/pages/FinancialOps.jsx',
    'src/pages/FinanceOverview.jsx','src/pages/SystemTopology.jsx','src/pages/VideoMarketing.jsx',
    'src/pages/OmniChannel.jsx','src/pages/DigitalEmployees.jsx','src/pages/AIAgentsCommand.jsx',
    'src/pages/LLMOrchestration.jsx','src/pages/GovernanceCore.jsx','src/pages/AxisAgenticCRM.jsx',
    'src/pages/AutonomousScheduler.jsx','src/pages/GlobalWorkforce.jsx','src/pages/DocumentIntelligence.jsx',
    'src/pages/ProductionValidation.jsx','src/pages/EngagementHub.jsx','src/pages/DeploymentStatus.jsx',
    'src/pages/IndustryOnboarding.jsx','src/pages/RealtimeDashboards.jsx','src/pages/Settings.jsx',
    'src/pages/RevenueOperations.jsx','src/pages/WorkflowOrchestration.jsx','src/pages/ProductionFulfillment.jsx',
    'src/pages/CrossDepartmentSync.jsx','src/pages/UniversalOperationalAI.jsx','src/pages/IntegrationMarketplace.jsx',
    'src/pages/SystemAuditReport.jsx','src/pages/SetupWizard.jsx','src/pages/QuickIntegrations.jsx',
    'src/pages/AIFeatures.jsx','src/pages/QuoteBuilder.jsx','src/pages/RepPortal.jsx','src/pages/RepLogin.jsx',
    'src/pages/SalesDashboard.jsx','src/pages/SalesCommandCenter.jsx','src/pages/VoiceIntelligence.jsx',
    'src/pages/OmniCoreBrain.jsx','src/pages/SecurityAgent.jsx','src/pages/VideoProductionAgent.jsx',
    'src/pages/AxisMeet.jsx','src/pages/MeetRoom.jsx','src/pages/GuestLobby.jsx','src/pages/Careers.jsx',
    'src/pages/PartnerDashboard.jsx','src/pages/TwilioVerification.jsx','src/pages/SystemStressTest.jsx',
    'src/pages/HrInvite.jsx','src/pages/LiveDemo.jsx','src/pages/Inventory.jsx','src/pages/Logistics.jsx',
    'src/pages/PageBuilder.jsx','src/pages/Storefront.jsx','src/pages/CustomerPortal.jsx',
    'src/pages/PublicLandingPage.jsx','src/pages/SuperAdmin.jsx','src/pages/AdminConsole.jsx'
  ],
  components: [
    'src/components/layout/Sidebar.jsx','src/components/layout/AppLayout.jsx','src/components/layout/TopBar.jsx',
    'src/components/layout/MobileBottomNav.jsx','src/components/layout/navConfig.js',
    'src/components/layout/GlobalSearch.jsx','src/components/layout/DesktopAppDownload.jsx',
    'src/components/admin/DevStudio.jsx','src/components/admin/ConsoleSystemPanel.jsx',
    'src/components/admin/SuperAdminUsersTab.jsx','src/components/admin/ConsoleApiKeysPanel.jsx',
    'src/components/dashboard/StatCard.jsx','src/components/dashboard/TodaySnapshot.jsx',
    'src/components/dashboard/AIStatusPanel.jsx','src/components/dashboard/DrillableKPICard.jsx',
    'src/components/shared/StatusBadge.jsx','src/components/shared/ClickToCall.jsx',
    'src/components/shared/PullToRefresh.jsx','src/components/shared/PersonalizationSettings.jsx',
    'src/components/leads/LeadProfileSummary.jsx','src/components/calls/TranscriptPanel.jsx',
    'src/components/inventory/InventoryItemsPanel.jsx','src/components/inventory/PurchaseOrderPanel.jsx',
    'src/components/finance/PayrollPanel.jsx','src/components/finance/InvoicesPanel.jsx',
    'src/components/finance/ExpensesPanel.jsx','src/components/logistics/ShipmentTrackingPanel.jsx'
  ]
};