import React, { useState, useEffect, useRef, useCallback } from 'react';
import { invokeDev, formatTimestamp, ACTION_LABELS, riskBadgeClass } from './shared';
import { Badge } from '@/components/ui/badge';
import {
  RefreshCw, CheckCircle2, XCircle, Clock, AlertTriangle,
  ChevronDown, ChevronRight, Activity, Radio
} from 'lucide-react';

const statusConfig = {
  executed: { icon: CheckCircle2, color: 'text-emerald-400', label: 'Done' },
  pending: { icon: Clock, color: 'text-amber-400', label: 'Queued' },
  failed: { icon: XCircle, color: 'text-destructive', label: 'Failed' },
  blocked: { icon: AlertTriangle, color: 'text-destructive', label: 'Blocked' }
};

export default function ActivityFeed({ onUnreadChange }) {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [unread, setUnread] = useState(0);
  const [isViewed, setIsViewed] = useState(true);
  const lastCountRef = useRef(0);
  const feedRef = useRef(null);
  const [autoScroll, setAutoScroll] = useState(true);

  const fetchFeed = useCallback(async () => {
    try {
      const res = await invokeDev('activity_feed', {});
      if (res.data?.result?.logs) {
        const newLogs = res.data.result.logs;
        setLogs(newLogs);
        if (newLogs.length > lastCountRef.current && lastCountRef.current > 0) {
          const diff = newLogs.length - lastCountRef.current;
          if (!isViewed) setUnread(prev => prev + diff);
        }
        lastCountRef.current = newLogs.length;
      }
    } catch (_) {}
    setLoading(false);
  }, [isViewed]);

  useEffect(() => {
    fetchFeed();
    const interval = setInterval(fetchFeed, 5000);
    return () => clearInterval(interval);
  }, [fetchFeed]);

  useEffect(() => {
    if (autoScroll && feedRef.current) {
      feedRef.current.scrollTop = 0;
    }
  }, [logs, autoScroll]);

  useEffect(() => {
    if (onUnreadChange) onUnreadChange(unread);
  }, [unread, onUnreadChange]);

  const handleView = () => {
    setIsViewed(true);
    setUnread(0);
  };

  const toggleExpand = (id) => {
    setExpanded(prev => prev === id ? null : id);
  };

  const statusFor = (log) => {
    if (log.execution_status === 'executed') return 'executed';
    if (log.execution_status === 'blocked') return 'blocked';
    if (log.execution_status === 'failed') return 'failed';
    return 'pending';
  };

  const agentName = (log) => {
    if (log.automation_type === 'evolution_cycle') return 'OmniCore';
    return 'AXIS AI';
  };

  const actionLabel = (log) => ACTION_LABELS[log.action_taken] || log.action_taken?.replace(/_/g, ' ') || 'action';

  return (
    <div
      className="flex flex-col h-full bg-zinc-950/80 border border-border rounded-xl overflow-hidden"
      onMouseEnter={handleView}
    >
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Activity className="w-4 h-4 text-emerald-400" />
            {!loading && (
              <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
            )}
          </div>
          <span className="text-sm font-semibold">Live Activity Feed</span>
          {unread > 0 && (
            <Badge className="bg-primary text-primary-foreground text-[10px] px-1.5 py-0 animate-pulse">{unread} new</Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer">
            <input type="checkbox" checked={autoScroll} onChange={(e) => setAutoScroll(e.target.checked)} className="w-3 h-3 accent-emerald-500" />
            Auto-scroll
          </label>
          <button onClick={fetchFeed} className="text-muted-foreground hover:text-foreground">
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      <div ref={feedRef} className="flex-1 overflow-y-auto min-h-0">
        {loading && logs.length === 0 ? (
          <div className="flex items-center gap-2 text-xs text-muted-foreground p-6">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Loading activity...
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-10 text-xs text-muted-foreground">
            <Radio className="w-6 h-6 mx-auto mb-2 opacity-40" />
            No activity yet. Generate a plan or trigger evolution to see live actions.
          </div>
        ) : (
          <div className="divide-y divide-border/30">
            {logs.map((log) => {
              const status = statusFor(log);
              const cfg = statusConfig[status] || statusConfig.pending;
              const StatusIcon = cfg.icon;
              const isExpanded = expanded === log.id;

              return (
                <div key={log.id} className="hover:bg-muted/20 transition-colors">
                  <button
                    onClick={() => toggleExpand(log.id)}
                    className="w-full flex items-start gap-2.5 px-3 py-2 text-left"
                  >
                    <span className="text-[10px] text-muted-foreground font-mono shrink-0 mt-0.5 tabular-nums">
                      {formatTimestamp(log.created_date)}
                    </span>
                    <span className={`shrink-0 mt-0.5 ${cfg.color}`}>
                      <StatusIcon className="w-3.5 h-3.5" />
                    </span>
                    <span className="text-[10px] font-semibold shrink-0 mt-0.5">
                      {agentName(log) === 'OmniCore' ? (
                        <span className="text-violet-400">OmniCore</span>
                      ) : (
                        <span className="text-emerald-400">AXIS AI</span>
                      )}
                    </span>
                    <span className="text-xs text-foreground/90 flex-1 truncate mt-0.5">{actionLabel(log)}</span>
                    <span className="shrink-0 mt-0.5">
                      <Badge variant="outline" className={`text-[9px] py-0 ${riskBadgeClass(log.risk_level)}`}>
                        {(log.risk_level || 'low').toUpperCase()}
                      </Badge>
                    </span>
                    {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" /> : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5" />}
                  </button>
                  {isExpanded && (
                    <div className="px-3 pb-2.5 pl-12 space-y-1">
                      {log.execution_result && (
                        <div>
                          <p className="text-[10px] font-semibold uppercase text-muted-foreground mb-0.5">Result</p>
                          <pre className="text-[10px] font-mono text-foreground/70 bg-zinc-900/60 rounded p-2 overflow-x-auto max-h-32 whitespace-pre-wrap break-all">
                            {(() => {
                              try { return JSON.stringify(JSON.parse(log.execution_result), null, 2); }
                              catch (_) { return log.execution_result; }
                            })()}
                          </pre>
                        </div>
                      )}
                      {log.error_message && (
                        <p className="text-[10px] text-destructive font-mono">Error: {log.error_message}</p>
                      )}
                      {log.governance_checks && (
                        <div className="flex flex-wrap gap-1">
                          {(() => {
                            try { return JSON.parse(log.governance_checks).map((g, i) => (
                              <Badge key={i} variant="outline" className="text-[9px] py-0 border-emerald-500/20 text-emerald-400/70">{g}</Badge>
                            )); }
                            catch (_) { return null; }
                          })()}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}