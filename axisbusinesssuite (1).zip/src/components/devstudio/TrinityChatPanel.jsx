import React, { useState, useRef, useEffect } from 'react';
import { invokeDev, riskBadgeClass } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import {
  Sparkles, Send, RefreshCw, Rocket, AlertTriangle,
  ChevronDown, ChevronRight, ShieldCheck, Bot, User
} from 'lucide-react';
import { toast } from 'sonner';

export default function TrinityChatPanel({ chat, compact }) {
  const [input, setInput] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chat.messages]);

  const send = () => {
    if (!input.trim() || chat.loading) return;
    chat.sendMessage(input.trim());
    setInput('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  const normalizePlan = (plan) => {
    if (!plan) return null;
    if (typeof plan === 'string') {
      try { return JSON.parse(plan); } catch (_) { return { steps: [plan], risk_level: 'low' }; }
    }
    if (typeof plan.steps === 'string') {
      plan = { ...plan, steps: plan.steps.split(/\n|\d+\.\s/).map(s => s.trim()).filter(Boolean) };
    }
    if (!Array.isArray(plan.steps)) plan.steps = [];
    if (!Array.isArray(plan.affected_components)) plan.affected_components = [];
    if (!Array.isArray(plan.warnings)) plan.warnings = [];
    return plan;
  };

  return (
    <div className="flex flex-col h-full bg-zinc-950/80 border border-violet-500/20 rounded-xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 border-b border-violet-500/20 bg-violet-500/5 shrink-0">
        <div className="w-7 h-7 rounded-lg bg-violet-500/15 border border-violet-500/30 flex items-center justify-center">
          <Bot className="w-4 h-4 text-violet-400" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold flex items-center gap-2">
            AXIS AI
            {chat.loading && <RefreshCw className="w-3 h-3 animate-spin text-violet-400" />}
          </p>
          {!compact && <p className="text-[10px] text-muted-foreground">AI Assistant · Plan-first execution</p>}
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto min-h-0 p-3 space-y-3">
        {chat.messages.length === 0 ? (
          <div className="text-center py-8">
            <Sparkles className="w-6 h-6 mx-auto mb-3 text-violet-400/40" />
            <p className="text-sm text-muted-foreground">Describe a feature, change, or improvement.</p>
            <p className="text-xs text-muted-foreground/60 mt-1">AXIS AI will generate a plan for your approval.</p>
            <div className="mt-4 space-y-1.5 max-w-xs mx-auto">
              {['Add a lead re-engagement workflow', 'Create a customer feedback entity', 'Improve the dashboard layout'].map(s => (
                <button key={s} onClick={() => setInput(s)} className="block w-full text-left text-xs text-violet-400/80 hover:text-violet-300 bg-violet-500/5 hover:bg-violet-500/10 border border-violet-500/15 rounded-lg px-3 py-1.5 transition-colors">
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          chat.messages.map((msg, i) => {
            const isUser = msg.role === 'user';
            const plan = !isUser ? normalizePlan(msg.plan) : null;

            return (
              <div key={i} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[90%] ${isUser ? 'items-end' : 'items-start'}`}>
                  <div className="flex items-center gap-1.5 mb-1">
                    {!isUser && <Bot className="w-3 h-3 text-violet-400" />}
                    <span className="text-[10px] text-muted-foreground">{isUser ? 'You' : 'AXIS AI'}</span>
                    {isUser && <User className="w-3 h-3 text-muted-foreground" />}
                  </div>
                  {isUser ? (
                    <div className="bg-violet-600/20 border border-violet-500/30 rounded-xl rounded-tr-sm px-3 py-2 text-sm">
                      {msg.content}
                    </div>
                  ) : msg.error ? (
                    <div className="bg-destructive/10 border border-destructive/30 rounded-xl rounded-tl-sm px-3 py-2 text-sm text-destructive">
                      {msg.content}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {msg.content && (
                        <div className="bg-zinc-900/60 border border-border rounded-xl rounded-tl-sm px-3 py-2 text-sm text-foreground/90">
                          {msg.content}
                        </div>
                      )}
                      {plan && <PlanCard plan={plan} approved={msg.approved} onApprove={() => chat.approvePlan(i)} compact={compact} />}
                      {msg.approved && (
                        <div className="flex items-center gap-1.5 text-xs text-emerald-400 px-1">
                          <ShieldCheck className="w-3 h-3" /> Plan approved — queued for deployment in the next low-traffic window
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      <div className="border-t border-border p-3 shrink-0 space-y-2">
        <Textarea
          placeholder="Describe what you want Trinity to build..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className={`min-h-[44px] max-h-24 resize-none text-sm bg-zinc-900/60 border-violet-500/20 focus-visible:ring-violet-500/30 ${compact ? 'text-xs' : ''}`}
          disabled={chat.loading}
        />
        <Button
          className="w-full gap-2 bg-violet-600 hover:bg-violet-700 text-white"
          disabled={chat.loading || !input.trim()}
          onClick={send}
          size="sm"
        >
          {chat.loading ? <><RefreshCw className="w-3.5 h-3.5 animate-spin" />Thinking...</> : <><Send className="w-3.5 h-3.5" />Send to Trinity</>}
        </Button>
      </div>
    </div>
  );
}

function PlanCard({ plan, approved, onApprove, compact }) {
  const [expanded, setExpanded] = useState(!compact);
  const [approving, setApproving] = useState(false);
  const [confirmText, setConfirmText] = useState('');

  const handleApprove = async () => {
    setApproving(true);
    try {
      await onApprove();
      toast.success('Plan approved — queued for deployment');
    } catch (e) {
      toast.error(e.message || 'Approval failed');
    }
    setApproving(false);
  };

  const needsConfirm = plan.risk_level === 'medium' || plan.risk_level === 'high';
  const confirmReady = !needsConfirm || confirmText === 'I confirm this change';

  return (
    <div className="rounded-xl border border-violet-500/30 bg-zinc-900/60 overflow-hidden">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-2 px-3 py-2 border-b border-violet-500/20 bg-violet-500/5"
      >
        {expanded ? <ChevronDown className="w-3.5 h-3.5 text-violet-400" /> : <ChevronRight className="w-3.5 h-3.5 text-violet-400" />}
        <span className="text-xs font-semibold flex-1 text-left">Implementation Plan</span>
        <Badge className={`text-[9px] py-0 ${riskBadgeClass(plan.risk_level)}`}>{(plan.risk_level || 'low').toUpperCase()}</Badge>
      </button>
      {expanded && (
        <div className="p-3 space-y-2">
          {plan.steps?.length > 0 && (
            <div className="space-y-1">
              {plan.steps.map((s, i) => (
                <div key={i} className="flex items-start gap-2 text-xs">
                  <span className="flex shrink-0 items-center justify-center w-4 h-4 rounded-full bg-violet-500/20 text-violet-400 text-[9px] font-bold mt-0.5">{i + 1}</span>
                  <span className="text-foreground/80">{s}</span>
                </div>
              ))}
            </div>
          )}
          {plan.affected_components?.length > 0 && (
            <div className="pt-1.5 border-t border-border/50">
              <p className="text-[10px] font-semibold uppercase text-muted-foreground mb-1">Components</p>
              <div className="flex flex-wrap gap-1">
                {plan.affected_components.map((c, i) => (
                  <Badge key={i} variant="outline" className="text-[9px] py-0 border-violet-500/30 text-violet-300 font-mono">{c}</Badge>
                ))}
              </div>
            </div>
          )}
          {plan.warnings?.length > 0 && (
            <div className="space-y-0.5 pt-1.5 border-t border-border/50">
              {plan.warnings.map((w, i) => (
                <div key={i} className="flex items-start gap-1.5 text-[10px] text-amber-400">
                  <AlertTriangle className="w-2.5 h-2.5 mt-0.5 shrink-0" />{w}
                </div>
              ))}
            </div>
          )}
          {plan.estimated_impact && (
            <p className="text-[10px] text-muted-foreground pt-1.5 border-t border-border/50">{plan.estimated_impact}</p>
          )}
          {!approved && (
            <>
              {needsConfirm && (
                <Input
                  placeholder="Type 'I confirm this change'"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  className="text-xs h-7 bg-zinc-900/60"
                />
              )}
              <Button
                className="w-full gap-2 bg-primary hover:bg-primary/90"
                size="sm"
                disabled={approving || !confirmReady}
                onClick={handleApprove}
              >
                {approving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Rocket className="w-3.5 h-3.5" />}
                Approve Plan
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
}