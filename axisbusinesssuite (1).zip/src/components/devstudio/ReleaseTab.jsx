import React, { useState } from 'react';
import { invokeDev, TIERS, MODULES, riskBadgeClass } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import {
  Package, Eye, Rocket, RefreshCw, CheckCircle2, XCircle,
  AlertTriangle, Sparkles
} from 'lucide-react';
import { toast } from 'sonner';

export default function ReleaseTab({ chat }) {
  const [targetEmail, setTargetEmail] = useState('');
  const [scope, setScope] = useState('tiers');
  const [config, setConfig] = useState(() => {
    const init = {};
    TIERS.forEach(t => { init[t] = {}; MODULES.forEach(m => { init[t][m] = true; }); });
    return init;
  });
  const [preview, setPreview] = useState(null);
  const [previewing, setPreviewing] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [result, setResult] = useState(null);

  const toggle = (tier, mod) => {
    setConfig(prev => ({ ...prev, [tier]: { ...prev[tier], [mod]: !prev[tier][mod] } }));
    setPreview(null); setResult(null);
  };

  const toggleAllTier = (tier, val) => {
    setConfig(prev => {
      const next = { ...prev[tier] };
      MODULES.forEach(m => { next[m] = val; });
      return { ...prev, [tier]: next };
    });
    setPreview(null); setResult(null);
  };

  const runPreview = async () => {
    setPreviewing(true); setPreview(null); setResult(null);
    try {
      const res = await invokeDev('module_release_preview', {
        module_config: config,
        target_email: scope === 'user' ? targetEmail.trim() : undefined
      });
      if (res.data?.error) throw new Error(res.data.error);
      setPreview(res.data?.result?.preview);
      toast.success('Preview generated');
    } catch (e) { toast.error(e.message); }
    setPreviewing(false);
  };

  const confirmRelease = async () => {
    if (scope === 'user' && !targetEmail.trim()) return toast.error('Enter a target user email');
    setConfirming(true); setResult(null);
    try {
      const res = await invokeDev('module_release_confirm', {
        module_config: config,
        target_email: scope === 'user' ? targetEmail.trim() : undefined,
        risk_level: preview?.risk_level || 'low'
      });
      if (res.data?.error) throw new Error(res.data.error);
      setResult({ status: 'success', message: `Module config released ${scope === 'user' ? `for ${targetEmail}` : 'globally'}.` });
      setPreview(null);
      toast.success('Release confirmed');
    } catch (e) {
      setResult({ status: 'failed', message: e.message });
      toast.error(e.message);
    }
    setConfirming(false);
  };

  const askTrinity = () => {
    chat.sendMessage(`Configure module release: ${JSON.stringify(config)}. ${scope === 'user' ? `Target user: ${targetEmail}` : 'Global across all tiers.'} Suggest optimal module configuration.`);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-2">
        <Package className="w-3.5 h-3.5 shrink-0" />
        Preview every change before releasing. Downstream dependency warnings are surfaced automatically.
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-lg border border-border overflow-hidden">
          <button onClick={() => setScope('tiers')} className={`px-3 py-1.5 text-xs font-medium ${scope === 'tiers' ? 'bg-amber-500/20 text-amber-400' : 'bg-background text-muted-foreground'}`}>By Plan Tier</button>
          <button onClick={() => setScope('user')} className={`px-3 py-1.5 text-xs font-medium ${scope === 'user' ? 'bg-amber-500/20 text-amber-400' : 'bg-background text-muted-foreground'}`}>By User Email</button>
        </div>
        {scope === 'user' && (
          <Input type="email" placeholder="user@company.com" value={targetEmail} onChange={(e) => setTargetEmail(e.target.value)} className="max-w-xs text-sm" />
        )}
        <Button variant="outline" size="sm" className="gap-1.5 border-violet-500/30 hover:bg-violet-500/10 ml-auto" onClick={askTrinity}>
          <Sparkles className="w-3.5 h-3.5 text-violet-400" /> Ask Trinity
        </Button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-amber-500/20 bg-zinc-900/40">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-border bg-amber-500/5">
              <th className="text-left p-2.5 font-semibold text-muted-foreground sticky left-0 bg-amber-500/5">Module</th>
              {TIERS.map(t => (
                <th key={t} className="p-2.5 font-semibold text-center capitalize text-amber-400">
                  {t}
                  <button onClick={() => toggleAllTier(t, !Object.values(config[t]).every(Boolean))} className="block mx-auto mt-1 text-[10px] text-muted-foreground hover:text-foreground">toggle all</button>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {MODULES.map(m => (
              <tr key={m} className="border-b border-border/50 hover:bg-muted/20">
                <td className="p-2.5 font-mono sticky left-0 bg-zinc-900/80">{m}</td>
                {TIERS.map(t => (
                  <td key={t} className="p-2.5 text-center">
                    <Switch checked={config[t][m]} onCheckedChange={() => toggle(t, m)} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Button variant="outline" size="sm" className="gap-2 border-amber-500/30 hover:bg-amber-500/10" disabled={previewing} onClick={runPreview}>
        {previewing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />} Preview Release
      </Button>

      {preview && (
        <div className="rounded-xl border border-amber-500/30 bg-zinc-900/60 overflow-hidden">
          <div className="px-3 py-2 border-b border-border bg-amber-500/5 flex items-center gap-2">
            <Package className="w-4 h-4 text-amber-400" />
            <span className="text-sm font-semibold">Release Summary</span>
            <Badge className={`ml-auto ${riskBadgeClass(preview.risk_level)}`}>{(preview.risk_level || 'low').toUpperCase()}</Badge>
          </div>
          <div className="p-3 space-y-2">
            {preview.changes?.length > 0 && (
              <ul className="space-y-1 text-sm">
                {preview.changes.map((c, i) => <li key={i} className="flex items-start gap-2"><span className="text-amber-400 mt-0.5">•</span>{c}</li>)}
              </ul>
            )}
            {preview.dependency_warnings?.length > 0 && (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-2.5 space-y-1">
                {preview.dependency_warnings.map((w, i) => <div key={i} className="flex items-start gap-1.5 text-xs text-amber-400"><AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" />{w}</div>)}
              </div>
            )}
            <Button className="gap-2 bg-primary hover:bg-primary/90" size="sm" disabled={confirming} onClick={confirmRelease}>
              {confirming ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Rocket className="w-3.5 h-3.5" />} Confirm Release
            </Button>
          </div>
        </div>
      )}

      {result && (
        <div className={`rounded-lg border p-2.5 text-xs flex items-start gap-2 ${result.status === 'success' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400' : 'border-destructive/30 bg-destructive/10 text-destructive'}`}>
          {result.status === 'success' ? <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 shrink-0" />}
          {result.message}
        </div>
      )}
    </div>
  );
}