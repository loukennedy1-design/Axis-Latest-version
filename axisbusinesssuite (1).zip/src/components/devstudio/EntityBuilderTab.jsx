import React, { useState, useCallback, useMemo } from 'react';
import { invokeDev, riskBadgeClass } from './shared';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Plus, Trash2, RefreshCw, Sparkles, Save, Database, ShieldCheck, Eye
} from 'lucide-react';
import { toast } from 'sonner';

const FIELD_TYPES = ['string', 'number', 'boolean', 'date', 'enum'];
const RLS_PRESETS = [
  { id: 'owner_admin', label: 'Owner + Admin', description: 'Only the owner and admins can read/write' },
  { id: 'admin_only', label: 'Admin Only', description: 'Only admins can access all records' },
  { id: 'public_read', label: 'Public Read', description: 'Anyone can read, only owner/admin can write' }
];

const emptyField = { field_name: '', type: 'string', enum_values: '', default_value: '', description: '', required: false };

export default function EntityBuilderTab() {
  const [entityName, setEntityName] = useState('');
  const [description, setDescription] = useState('');
  const [fields, setFields] = useState([{ ...emptyField }]);
  const [rlsPreset, setRlsPreset] = useState('owner_admin');
  const [suggesting, setSuggesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [result, setResult] = useState(null);

  const addField = () => setFields(prev => [...prev, { ...emptyField }]);
  const removeField = (i) => setFields(prev => prev.filter((_, idx) => idx !== i));
  const updateField = (i, key, val) => setFields(prev => prev.map((f, idx) => idx === i ? { ...f, [key]: val } : f));

  const suggestFields = async () => {
    if (!description.trim()) return toast.error('Describe the entity first');
    setSuggesting(true);
    try {
      const res = await invokeDev('suggest_entity_fields', { entity_description: description.trim() });
      if (res.data?.error) throw new Error(res.data.error);
      const suggestion = res.data?.result?.suggestion;
      if (typeof suggestion === 'string') {
        try { JSON.parse(suggestion); } catch (_) {}
      }
      if (suggestion?.suggested_name && !entityName) setEntityName(suggestion.suggested_name);
      if (suggestion?.properties?.length > 0) {
        setFields(suggestion.properties.map(p => ({
          field_name: p.field_name || '',
          type: p.type || 'string',
          enum_values: (p.enum_values || []).join(', '),
          default_value: p.default_value || '',
          description: p.description || '',
          required: p.required || false
        })));
      }
      toast.success('Fields suggested by Trinity');
    } catch (e) { toast.error(e.message); }
    setSuggesting(false);
  };

  const generatedSchema = useMemo(() => {
    const props = {};
    const required = [];
    const validFields = fields.filter(f => f.field_name.trim());
    validFields.forEach(f => {
      const prop = { type: f.type };
      if (f.description) prop.description = f.description;
      if (f.type === 'enum' && f.enum_values.trim()) {
        prop.enum = f.enum_values.split(',').map(v => v.trim()).filter(Boolean);
      }
      if (f.default_value) {
        prop.default = f.type === 'number' ? Number(f.default_value) : f.type === 'boolean' ? f.default_value === 'true' : f.default_value;
      }
      props[f.field_name] = prop;
      if (f.required) required.push(f.field_name);
    });
    props.owner = { type: 'string' };

    let rls = {};
    if (rlsPreset === 'owner_admin') {
      rls = {
        create: { $or: [{ 'data.owner': '{{user.email}}' }, { user_condition: { role: 'admin' } }] },
        read: { $or: [{ 'data.owner': '{{user.email}}' }, { user_condition: { role: 'admin' } }] },
        update: { $or: [{ 'data.owner': '{{user.email}}' }, { user_condition: { role: 'admin' } }] },
        delete: { user_condition: { role: 'admin' } }
      };
    } else if (rlsPreset === 'admin_only') {
      rls = {
        create: { user_condition: { role: 'admin' } },
        read: { user_condition: { role: 'admin' } },
        update: { user_condition: { role: 'admin' } },
        delete: { user_condition: { role: 'admin' } }
      };
    } else if (rlsPreset === 'public_read') {
      rls = {
        create: { $or: [{ 'data.owner': '{{user.email}}' }, { user_condition: { role: 'admin' } }] },
        read: {},
        update: { $or: [{ 'data.owner': '{{user.email}}' }, { user_condition: { role: 'admin' } }] },
        delete: { user_condition: { role: 'admin' } }
      };
    }

    return {
      name: entityName || 'NewEntity',
      type: 'object',
      properties: props,
      required,
      rls
    };
  }, [entityName, fields, rlsPreset]);

  const save = async () => {
    if (!entityName.trim()) return toast.error('Enter an entity name');
    const validFields = fields.filter(f => f.field_name.trim());
    if (validFields.length === 0) return toast.error('Add at least one field');
    setSaving(true);
    setResult(null);
    try {
      const res = await invokeDev('create_entity_schema', {
        entity_name: entityName,
        schema: generatedSchema,
        risk_level: 'medium'
      });
      if (res.data?.error) throw new Error(res.data.error);
      setResult({ status: 'success', message: `Entity "${entityName}" schema logged to audit trail. Use the platform entity editor to create the .jsonc file.` });
      toast.success('Schema logged');
    } catch (e) {
      setResult({ status: 'failed', message: e.message });
      toast.error(e.message);
    }
    setSaving(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-xs text-violet-400 bg-violet-500/10 border border-violet-500/20 rounded-lg px-3 py-2">
        <Database className="w-3.5 h-3.5 shrink-0" />
        Design entity schemas visually. Trinity can suggest fields based on your description.
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Left: Form */}
        <div className="space-y-3">
          <div className="rounded-xl border border-border bg-zinc-900/40 p-3 space-y-3">
            <div>
              <Label className="text-xs">Entity Name</Label>
              <Input value={entityName} onChange={(e) => setEntityName(e.target.value)} placeholder="e.g. CustomerFeedback" className="mt-1 font-mono text-sm" />
            </div>
            <div>
              <Label className="text-xs">Description (for Trinity field suggestions)</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="e.g. A CRM object to track customer feedback with rating, category, and resolution status" className="mt-1 min-h-[50px] text-sm" />
              <Button variant="outline" size="sm" className="mt-1.5 gap-1.5 border-violet-500/30 hover:bg-violet-500/10" disabled={suggesting || !description.trim()} onClick={suggestFields}>
                {suggesting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-violet-400" />} Suggest Fields
              </Button>
            </div>
          </div>

          <div className="rounded-xl border border-border bg-zinc-900/40 p-3 space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs">Properties</Label>
              <Button variant="ghost" size="sm" className="h-6 gap-1 text-xs" onClick={addField}><Plus className="w-3 h-3" /> Add Field</Button>
            </div>
            {fields.map((f, i) => (
              <div key={i} className="rounded-lg border border-border/50 bg-zinc-950/60 p-2.5 space-y-2">
                <div className="flex items-center gap-2">
                  <Input value={f.field_name} onChange={(e) => updateField(i, 'field_name', e.target.value)} placeholder="field_name" className="font-mono text-xs h-7" />
                  <select value={f.type} onChange={(e) => updateField(i, 'type', e.target.value)} className="h-7 rounded-md border border-input bg-transparent text-xs px-2 text-foreground">
                    {FIELD_TYPES.map(t => <option key={t} value={t} className="bg-zinc-900">{t}</option>)}
                  </select>
                  <Button variant="ghost" size="sm" className="h-7 w-7 p-0 shrink-0" onClick={() => removeField(i)}><Trash2 className="w-3 h-3 text-destructive" /></Button>
                </div>
                {f.type === 'enum' && (
                  <Input value={f.enum_values} onChange={(e) => updateField(i, 'enum_values', e.target.value)} placeholder="option1, option2, option3" className="text-xs h-7" />
                )}
                <div className="flex items-center gap-2">
                  <Input value={f.default_value} onChange={(e) => updateField(i, 'default_value', e.target.value)} placeholder="default value" className="text-xs h-7 flex-1" />
                  <label className="flex items-center gap-1 text-[10px] text-muted-foreground shrink-0 cursor-pointer">
                    <input type="checkbox" checked={f.required} onChange={(e) => updateField(i, 'required', e.target.checked)} className="w-3 h-3 accent-violet-500" />
                    required
                  </label>
                </div>
                <Input value={f.description} onChange={(e) => updateField(i, 'description', e.target.value)} placeholder="description" className="text-xs h-7" />
              </div>
            ))}
          </div>

          <div className="rounded-xl border border-border bg-zinc-900/40 p-3">
            <Label className="text-xs mb-2 block">RLS Rules</Label>
            <div className="space-y-1.5">
              {RLS_PRESETS.map(preset => (
                <button key={preset.id} onClick={() => setRlsPreset(preset.id)}
                  className={`w-full text-left p-2 rounded-lg border transition-colors ${rlsPreset === preset.id ? 'border-violet-500/40 bg-violet-500/10' : 'border-border hover:bg-muted/30'}`}>
                  <p className="text-xs font-medium">{preset.label}</p>
                  <p className="text-[10px] text-muted-foreground">{preset.description}</p>
                </button>
              ))}
            </div>
          </div>

          <Button className="w-full gap-2 bg-primary hover:bg-primary/90" disabled={saving || !entityName.trim()} onClick={save}>
            {saving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />} Log Schema for Build
          </Button>

          {result && (
            <div className={`rounded-lg border p-2.5 text-xs flex items-start gap-2 ${result.status === 'success' ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-400' : 'border-destructive/30 bg-destructive/10 text-destructive'}`}>
              <ShieldCheck className="w-4 h-4 mt-0.5 shrink-0" />{result.message}
            </div>
          )}
        </div>

        {/* Right: JSON preview */}
        <div className="rounded-xl border border-emerald-500/30 bg-zinc-950 overflow-hidden">
          <div className="px-3 py-2 border-b border-emerald-500/20 bg-emerald-500/5 flex items-center gap-2">
            <Eye className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-xs font-mono text-emerald-300">{entityName || 'NewEntity'}.jsonc</span>
          </div>
          <pre className="text-xs font-mono text-emerald-300 p-3 overflow-auto max-h-[600px] whitespace-pre">
            {JSON.stringify(generatedSchema, null, 2)}
          </pre>
        </div>
      </div>
    </div>
  );
}