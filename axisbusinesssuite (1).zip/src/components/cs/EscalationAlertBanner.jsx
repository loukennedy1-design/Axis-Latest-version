import React from 'react';
import { AlertCircle, ArrowRight, X } from 'lucide-react';

export default function EscalationAlertBanner({ escalatedCount, onFilterEscalated, onDismiss }) {
  if (escalatedCount === 0) return null;

  return (
    <div className="mx-4 mt-3 rounded-xl border-2 border-red-500/40 bg-red-500/10 px-4 py-3 flex items-center gap-3 animate-pulse">
      <div className="w-8 h-8 rounded-full bg-red-500/20 flex items-center justify-center shrink-0">
        <AlertCircle className="w-4 h-4 text-red-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-red-400">
          {escalatedCount} ticket{escalatedCount > 1 ? 's' : ''} escalated — needs human agent
        </p>
        <p className="text-xs text-muted-foreground truncate">
          AI could not resolve within 2 hours. Click to view and claim.
        </p>
      </div>
      <button
        onClick={onFilterEscalated}
        className="shrink-0 flex items-center gap-1 rounded-lg bg-red-500/20 hover:bg-red-500/30 px-3 py-1.5 text-xs font-medium text-red-400 transition-colors"
      >
        View Queue <ArrowRight className="w-3 h-3" />
      </button>
      <button
        onClick={onDismiss}
        className="shrink-0 p-1 rounded hover:bg-red-500/20 text-muted-foreground transition-colors"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}