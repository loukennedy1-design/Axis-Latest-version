import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bot, User, Headset, Send, CheckCircle2, XCircle, Sparkles, Clock } from 'lucide-react';
import { toast } from 'sonner';

const PRIORITY_STYLES = {
  urgent: 'bg-red-500/20 text-red-400',
  high: 'bg-orange-500/20 text-orange-400',
  medium: 'bg-yellow-500/20 text-yellow-400',
  low: 'bg-blue-500/20 text-blue-400',
};

export default function TicketDetail({ ticket, currentUser, onRefresh }) {
  const [reply, setReply] = useState('');
  const [resolution, setResolution] = useState('');
  const [showResolve, setShowResolve] = useState(false);
  const [acting, setActing] = useState(false);

  if (!ticket) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
        <div className="text-center">
          <Headset className="w-10 h-10 mx-auto mb-2 opacity-40" />
          Select a ticket to view details
        </div>
      </div>
    );
  }

  const messages = (() => {
    try { return JSON.parse(ticket.messages || '[]'); } catch { return []; }
  })();

  const handleClaim = async () => {
    setActing(true);
    try {
      await base44.entities.CSTicket.update(ticket.id, {
        assigned_agent_email: currentUser?.email,
        status: 'agent_assigned',
      });
      toast.success('Ticket claimed');
      onRefresh();
    } catch (e) { toast.error('Failed to claim ticket'); }
    setActing(false);
  };

  const handleRespond = async () => {
    if (!reply.trim()) return;
    setActing(true);
    try {
      const newMsgs = [...messages, {
        sender: 'agent',
        sender_email: currentUser?.email || '',
        body: reply.trim(),
        timestamp: new Date().toISOString(),
      }];
      await base44.entities.CSTicket.update(ticket.id, {
        messages: JSON.stringify(newMsgs),
        status: ticket.status === 'escalated' ? 'agent_assigned' : ticket.status,
        assigned_agent_email: ticket.assigned_agent_email || currentUser?.email,
      });
      setReply('');
      toast.success('Response sent');
      onRefresh();
    } catch (e) { toast.error('Failed to send response'); }
    setActing(false);
  };

  const handleResolve = async () => {
    setActing(true);
    try {
      const newMsgs = [...messages, {
        sender: 'agent',
        sender_email: currentUser?.email || '',
        body: resolution.trim() || 'Ticket resolved.',
        timestamp: new Date().toISOString(),
      }];
      await base44.entities.CSTicket.update(ticket.id, {
        status: 'resolved',
        resolution_notes: resolution.trim(),
        messages: JSON.stringify(newMsgs),
      });
      setResolution('');
      setShowResolve(false);
      toast.success('Ticket resolved');
      onRefresh();
    } catch (e) { toast.error('Failed to resolve ticket'); }
    setActing(false);
  };

  const handleClose = async () => {
    setActing(true);
    try {
      await base44.entities.CSTicket.update(ticket.id, { status: 'closed' });
      toast.success('Ticket closed');
      onRefresh();
    } catch (e) { toast.error('Failed to close ticket'); }
    setActing(false);
  };

  const isAssignedToMe = ticket.assigned_agent_email === currentUser?.email;
  const canAct = ['escalated', 'agent_assigned'].includes(ticket.status);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border shrink-0">
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0">
            <h3 className="font-semibold text-sm leading-tight">{ticket.subject}</h3>
            <p className="text-xs text-muted-foreground font-mono mt-0.5">{ticket.ticket_id}</p>
          </div>
          <Badge variant="outline" className={`shrink-0 ${PRIORITY_STYLES[ticket.priority] || ''}`}>
            {ticket.priority}
          </Badge>
        </div>
        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
          <span>{ticket.customer_name || 'Unknown'}</span>
          <span>·</span>
          <span>{ticket.customer_email}</span>
          <span>·</span>
          <span className="capitalize">{ticket.category?.replace(/_/g, ' ')}</span>
          <span>·</span>
          <span>via {ticket.source?.replace(/_/g, ' ')}</span>
          {ticket.response_time_seconds > 0 && (
            <>
              <span>·</span>
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{ticket.response_time_seconds}s response</span>
            </>
          )}
        </div>
      </div>

      {/* Conversation */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0">
        {/* AI Response Panel */}
        {ticket.ai_response && (
          <div className="rounded-xl border border-purple-500/20 bg-purple-500/5 p-3">
            <div className="flex items-center gap-1.5 mb-1.5 text-xs text-purple-400 font-medium">
              <Sparkles className="w-3.5 h-3.5" />
              AI Response {ticket.handled_by_ai ? '(Auto-resolved)' : '(Suggested)'}
              <span className="ml-auto text-muted-foreground">Confidence: {ticket.ai_confidence}%</span>
            </div>
            <p className="text-sm text-foreground/90 leading-relaxed">{ticket.ai_response}</p>
          </div>
        )}

        {/* Escalation reason */}
        {ticket.escalation_reason && (
          <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-3">
            <p className="text-xs text-red-400 font-medium mb-0.5">Escalation Reason</p>
            <p className="text-sm text-foreground/80">{ticket.escalation_reason}</p>
          </div>
        )}

        {/* Messages */}
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-2 ${msg.sender === 'customer' ? 'justify-start' : 'justify-end'}`}>
            <div className={`max-w-[80%] rounded-xl px-3 py-2 text-sm ${
              msg.sender === 'customer' ? 'bg-muted' :
              msg.sender === 'ai' ? 'bg-purple-500/10 border border-purple-500/20' :
              'bg-primary text-primary-foreground'
            }`}>
              <div className="flex items-center gap-1.5 mb-1 text-[10px] opacity-70">
                {msg.sender === 'customer' ? <User className="w-3 h-3" /> :
                 msg.sender === 'ai' ? <Bot className="w-3 h-3" /> :
                 <Headset className="w-3 h-3" />}
                {msg.sender_email}
              </div>
              <p className="leading-relaxed whitespace-pre-wrap">{msg.body}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Agent Actions */}
      {canAct && (
        <div className="p-3 border-t border-border shrink-0 space-y-2">
          {!isAssignedToMe && ticket.status === 'escalated' && (
            <Button onClick={handleClaim} disabled={acting} size="sm" className="w-full">
              <Headset className="w-4 h-4" /> Claim Ticket
            </Button>
          )}
          {(!showResolve) ? (
            <>
              <div className="flex gap-2">
                <textarea
                  value={reply}
                  onChange={e => setReply(e.target.value)}
                  placeholder="Type your response to the customer..."
                  rows={2}
                  className="flex-1 resize-none bg-muted rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-1 focus:ring-primary"
                />
                <Button onClick={handleRespond} disabled={acting || !reply.trim()} size="icon" className="h-auto">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => setShowResolve(true)} disabled={acting} variant="outline" size="sm" className="flex-1">
                  <CheckCircle2 className="w-4 h-4" /> Resolve
                </Button>
                <Button onClick={handleClose} disabled={acting} variant="ghost" size="sm" className="flex-1 text-muted-foreground">
                  <XCircle className="w-4 h-4" /> Close
                </Button>
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <textarea
                value={resolution}
                onChange={e => setResolution(e.target.value)}
                placeholder="Enter resolution notes..."
                rows={2}
                className="w-full resize-none bg-muted rounded-lg px-3 py-2 text-sm border border-border focus:outline-none focus:ring-1 focus:ring-primary"
                autoFocus
              />
              <div className="flex gap-2">
                <Button onClick={handleResolve} disabled={acting} size="sm" className="flex-1">
                  <CheckCircle2 className="w-4 h-4" /> Confirm Resolution
                </Button>
                <Button onClick={() => setShowResolve(false)} variant="ghost" size="sm">Cancel</Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}