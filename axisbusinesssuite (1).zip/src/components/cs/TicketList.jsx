import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Search } from 'lucide-react';

const STATUS_STYLES = {
  new: 'bg-blue-500/15 text-blue-400 border-blue-500/30',
  ai_triaging: 'bg-purple-500/15 text-purple-400 border-purple-500/30',
  ai_resolved: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
  escalated: 'bg-red-500/15 text-red-400 border-red-500/30',
  agent_assigned: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
  resolved: 'bg-green-500/15 text-green-400 border-green-500/30',
  closed: 'bg-muted text-muted-foreground border-border',
};

const PRIORITY_STYLES = {
  urgent: 'bg-red-500/20 text-red-400',
  high: 'bg-orange-500/20 text-orange-400',
  medium: 'bg-yellow-500/20 text-yellow-400',
  low: 'bg-blue-500/20 text-blue-400',
};

export default function TicketList({ tickets, selectedId, onSelect, search, onSearch, statusFilter, onStatusFilter }) {
  const filtered = tickets.filter(t => {
    const q = search.toLowerCase();
    const matchesSearch = !q ||
      t.subject?.toLowerCase().includes(q) ||
      t.customer_name?.toLowerCase().includes(q) ||
      t.customer_email?.toLowerCase().includes(q) ||
      t.ticket_id?.toLowerCase().includes(q);
    const matchesStatus = !statusFilter || t.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-border space-y-2 shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            value={search}
            onChange={e => onSearch(e.target.value)}
            placeholder="Search tickets..."
            className="w-full pl-9 pr-3 py-2 text-sm bg-muted rounded-lg border border-border focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {[{v:'',l:'All'},{v:'new',l:'New'},{v:'ai_triaging',l:'Triaging'},{v:'ai_resolved',l:'AI Resolved'},{v:'escalated',l:'Escalated'},{v:'agent_assigned',l:'Assigned'},{v:'resolved',l:'Resolved'}].map(opt => (
            <button
              key={opt.v}
              onClick={() => onStatusFilter(opt.v)}
              className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                statusFilter === opt.v
                  ? 'bg-primary text-primary-foreground border-primary'
                  : 'bg-muted text-muted-foreground border-border hover:bg-accent/30'
              }`}
            >
              {opt.l}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto min-h-0">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-sm text-muted-foreground">No tickets found</div>
        ) : (
          filtered.map(ticket => (
            <button
              key={ticket.id}
              onClick={() => onSelect(ticket.id)}
              className={`w-full text-left p-3 border-b border-border hover:bg-accent/20 transition-colors ${
                selectedId === ticket.id ? 'bg-primary/10 border-l-2 border-l-primary' : ''
              }`}
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <span className="text-xs font-mono text-muted-foreground">{ticket.ticket_id}</span>
                <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${STATUS_STYLES[ticket.status] || ''}`}>
                  {ticket.status?.replace(/_/g, ' ')}
                </Badge>
              </div>
              <p className="text-sm font-medium leading-tight mb-1 line-clamp-1">{ticket.subject}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="truncate">{ticket.customer_name || ticket.customer_email}</span>
                {ticket.priority && (
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${PRIORITY_STYLES[ticket.priority] || ''}`}>
                    {ticket.priority}
                  </span>
                )}
                {ticket.category && <span className="text-[10px]">· {ticket.category.replace(/_/g, ' ')}</span>}
              </div>
            </button>
          ))
        )}
      </div>
    </div>
  );
}