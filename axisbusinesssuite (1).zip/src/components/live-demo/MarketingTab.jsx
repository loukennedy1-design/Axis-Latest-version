import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Megaphone, Mail, Send, Eye, MousePointerClick, Heart, Calendar, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip, Cell } from 'recharts';
import StatusBadge from '@/components/shared/StatusBadge';
import AnimatedCounter from './AnimatedCounter';
import { generateMarketingPost } from '@/lib/demoSimulator';
import { format } from 'date-fns';

const platformIcon = (platform) => {
  const map = { facebook: Facebook, instagram: Instagram, linkedin: Linkedin, twitter: Twitter };
  const Icon = map[platform] || Megaphone;
  return <Icon className="w-3.5 h-3.5" />;
};

export default function MarketingTab({ state }) {
  const [posts, setPosts] = useState([]);
  const [stats, setStats] = useState({
    emailsSent: state.emailMessages.length,
    socialPosts: state.socialPosts.length,
    socialReach: state.socialPosts.reduce((a, p) => a + (p.performance_reach || 0), 0),
    totalLikes: state.socialPosts.reduce((a, p) => a + (p.performance_likes || 0), 0),
    totalClicks: state.socialPosts.reduce((a, p) => a + (p.performance_clicks || 0), 0),
    totalLeads: state.socialPosts.reduce((a, p) => a + (p.performance_leads || 0), 0),
  });
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    setPosts(state.socialPosts.slice(0, 8));
    const ticker = setInterval(() => {
      setPosts((prev) => [generateMarketingPost(stateRef.current), ...prev].slice(0, 8));
      setStats((prev) => ({
        ...prev,
        socialReach: prev.socialReach + Math.floor(Math.random() * 200),
        totalLikes: prev.totalLikes + Math.floor(Math.random() * 15),
        totalClicks: prev.totalClicks + Math.floor(Math.random() * 8),
      }));
    }, 5000);
    return () => clearInterval(ticker);
  }, []);

  const engagementRate = stats.socialReach > 0 ? (stats.totalLikes / stats.socialReach) * 100 : 0;
  const clickRate = stats.socialReach > 0 ? (stats.totalClicks / stats.socialReach) * 100 : 0;

  const chartData = [
    { name: 'Reach', value: stats.socialReach, fill: 'hsl(217,91%,60%)' },
    { name: 'Likes', value: stats.totalLikes, fill: 'hsl(262,83%,58%)' },
    { name: 'Clicks', value: stats.totalClicks, fill: 'hsl(162,63%,47%)' },
    { name: 'Leads', value: stats.totalLeads, fill: 'hsl(43,96%,56%)' },
  ];

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-purple-500/5 p-5">
        <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Megaphone className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Social Media AI</h1>
              <p className="text-muted-foreground text-xs">Automated content creation & publishing</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/80 border border-border text-xs font-semibold">
              <span className="text-primary">{stats.socialPosts}</span><span className="text-muted-foreground">posts</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold">
              <span className="text-purple-400">{stats.emailsSent}</span><span className="text-purple-400/70">emails</span>
            </div>
            <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1" /> AI Active
            </Badge>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: Send, label: 'Emails Sent', value: stats.emailsSent, color: 'text-primary', bg: 'bg-primary/10' },
          { icon: Eye, label: 'Social Reach', value: stats.socialReach, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { icon: Heart, label: 'Total Likes', value: stats.totalLikes, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { icon: MousePointerClick, label: 'Total Clicks', value: stats.totalClicks, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
        ].map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${bg}`}>
              <Icon className={`w-4 h-4 ${color}`} />
            </div>
            <div>
              <p className="text-lg font-bold leading-none tabular-nums"><AnimatedCounter value={value} /></p>
              <p className="text-[10px] text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts + Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Performance Chart */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-4">Campaign Performance</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData}>
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px', background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)' }} formatter={(v) => v.toLocaleString('en-US')} />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                {chartData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-3 mt-3 pt-3 border-t border-border">
            <div>
              <div className="text-xs text-muted-foreground">Engagement Rate</div>
              <div className="font-poppins font-bold text-lg text-foreground tabular-nums">{engagementRate.toFixed(1)}%</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Click Rate</div>
              <div className="font-poppins font-bold text-lg text-foreground tabular-nums">{clickRate.toFixed(1)}%</div>
            </div>
          </div>
        </div>

        {/* Content Calendar Feed */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40">
            <Calendar className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-sm">Published Content</h3>
            <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px] ml-auto">AI Generated</Badge>
          </div>
          <div className="divide-y divide-border max-h-[300px] overflow-y-auto no-scrollbar">
            <AnimatePresence initial={false}>
              {posts.map((post) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="px-4 py-3 hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5">
                      {platformIcon(post.platform)}
                      <span className="text-[11px] font-medium capitalize">{post.platform}</span>
                    </div>
                    <StatusBadge status={post.status} />
                  </div>
                  <p className="text-sm text-foreground/90 line-clamp-2">{post.content}</p>
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-0.5"><Heart className="w-2.5 h-2.5" />{post.performance_likes || 0}</span>
                    <span className="flex items-center gap-0.5"><Eye className="w-2.5 h-2.5" />{(post.performance_reach || 0).toLocaleString()}</span>
                    <span className="flex items-center gap-0.5"><MousePointerClick className="w-2.5 h-2.5" />{post.performance_clicks || 0}</span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}