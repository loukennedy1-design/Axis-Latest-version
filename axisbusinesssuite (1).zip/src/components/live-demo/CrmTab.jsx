import React, { useState, useMemo } from 'react';
import { Users, Search, Plus, ShieldCheck, PhoneOff, AlertTriangle, Sparkles, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import StatusBadge from '@/components/shared/StatusBadge';
import { format } from 'date-fns';

export default function CrmTab({ state }) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selected, setSelected] = useState(new Set());

  const { leads } = state;

  const filtered = useMemo(() => leads.filter(l => {
    const matchSearch = `${l.first_name} ${l.last_name} ${l.phone} ${l.email} ${l.company}`.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || l.status === statusFilter;
    return matchSearch && matchStatus;
  }), [leads, search, statusFilter]);

  const consentedCount = leads.filter(l => l.consent_given).length;
  const qualifiedCount = leads.filter(l => l.status === 'qualified' || l.status === 'appointment_set').length;
  const newCount = leads.filter(l => l.status === 'new').length;

  const allSelected = filtered.length > 0 && filtered.every(l => selected.has(l.id));
  const toggleAll = () => {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(filtered.map(l => l.id)));
  };
  const toggleOne = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header — mirrors Leads.jsx */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Leads</h1>
              <p className="text-muted-foreground text-xs">CRM — full contact management</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/80 border border-border text-xs font-semibold">
              <span className="text-primary">{leads.length}</span><span className="text-muted-foreground">total</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold">
              <span className="text-emerald-500">{consentedCount}</span><span className="text-emerald-600/70">consented</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold">
              <span className="text-blue-400">{newCount}</span><span className="text-blue-400/70">new</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold">
              <span className="text-purple-400">{qualifiedCount}</span><span className="text-purple-400/70">hot</span>
            </div>
            <Button className="gap-1.5"><Plus className="w-4 h-4" />Add Lead</Button>
          </div>
        </div>
      </div>

      {/* Search + filter — mirrors Leads.jsx */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search leads..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-40 h-9"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            {['new','contacted','qualified','appointment_set','not_interested','do_not_call'].map(s => (
              <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk Action Toolbar — mirrors Leads.jsx */}
      {selected.size > 0 && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 bg-primary/5 border border-primary/20 rounded-xl">
          <span className="text-sm font-semibold text-primary">{selected.size} selected</span>
          <div className="h-4 w-px bg-border hidden sm:block" />
          <div className="flex flex-wrap items-center gap-2">
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1"><Tag className="w-3 h-3" />Set Status</Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1"><ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />Grant Consent</Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1"><Users className="w-3 h-3" />Assign To</Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1"><PhoneOff className="w-3.5 h-3.5 text-red-500" />Add to DNC</Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1"><Sparkles className="w-3.5 h-3.5 text-primary" />AI Qualify</Button>
          </div>
        </div>
      )}

      {/* Leads Table — mirrors Leads.jsx table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-10"><Checkbox checked={allSelected} onCheckedChange={toggleAll} /></TableHead>
                <TableHead className="min-w-[120px]">Name</TableHead>
                <TableHead className="min-w-[110px]">Phone</TableHead>
                <TableHead className="min-w-[150px]">Email</TableHead>
                <TableHead className="min-w-[100px]">Company</TableHead>
                <TableHead className="min-w-[90px]">Status</TableHead>
                <TableHead className="min-w-[100px]">Source</TableHead>
                <TableHead className="min-w-[70px]">Consent</TableHead>
                <TableHead className="min-w-[60px]">Calls</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.slice(0, 50).map(lead => (
                <TableRow key={lead.id} className={`hover:bg-muted/30 transition-colors ${selected.has(lead.id) ? 'bg-primary/5' : ''}`}>
                  <TableCell><Checkbox checked={selected.has(lead.id)} onCheckedChange={() => toggleOne(lead.id)} /></TableCell>
                  <TableCell className="font-medium">
                    <span className="truncate">{lead.first_name} {lead.last_name}</span>
                  </TableCell>
                  <TableCell className="text-sm">{lead.phone}</TableCell>
                  <TableCell className="text-sm truncate max-w-[150px]">{lead.email}</TableCell>
                  <TableCell className="text-sm truncate max-w-[100px]">{lead.company}</TableCell>
                  <TableCell><StatusBadge status={lead.status} /></TableCell>
                  <TableCell>
                    {lead.source ? (
                      <Badge variant="outline" className="text-[10px] bg-primary/5 border-primary/20">{lead.source}</Badge>
                    ) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell>
                    <span className={lead.consent_given ? 'text-emerald-600 text-xs font-medium whitespace-nowrap' : 'text-red-500 text-xs font-medium whitespace-nowrap'}>
                      {lead.consent_given ? '✓ Yes' : '✗ No'}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm whitespace-nowrap">{lead.call_attempts || 0}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {filtered.length > 50 && (
          <div className="px-4 py-2 border-t border-border text-xs text-muted-foreground text-center">
            Showing 50 of {filtered.length} leads
          </div>
        )}
      </div>
    </div>
  );
}