import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Sparkles, Rocket } from 'lucide-react';
import { INDUSTRIES, TEAM_SIZES } from '@/lib/demoSimulator';

export default function ConfigOverlay({ onLaunch }) {
  const [industry, setIndustry] = useState('real_estate');
  const [teamSize, setTeamSize] = useState('small');
  const [launching, setLaunching] = useState(false);

  const handleLaunch = () => {
    setLaunching(true);
    setTimeout(() => onLaunch(industry, teamSize), 500);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background p-4"
    >
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse" />
      </div>

      <motion.div
        initial={{ scale: 0.92, y: 20, opacity: 0 }}
        animate={{ scale: launching ? 1.02 : 1, y: 0, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 24 }}
        className="relative w-full max-w-lg"
      >
        <div className="rounded-3xl border border-border bg-card/80 backdrop-blur-xl p-8 shadow-2xl">
          <div className="flex items-center gap-2.5 mb-1">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center font-poppins font-bold text-lg text-primary-foreground">A</div>
            <span className="font-poppins font-bold text-xl tracking-tight">AXIS Business Suite</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-6">
            <Sparkles className="w-3 h-3" /> Live Demo Setup
          </div>

          <h2 className="font-poppins font-semibold text-2xl mb-1">Configure your demo</h2>
          <p className="text-sm text-muted-foreground mb-6">Tailor the simulation to your prospect's business.</p>

          <div className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Industry</label>
              <Select value={industry} onValueChange={setIndustry}>
                <SelectTrigger className="h-11 bg-background"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(INDUSTRIES).map(([key, val]) => (
                    <SelectItem key={key} value={key}>{val.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Team Size</label>
              <Select value={teamSize} onValueChange={setTeamSize}>
                <SelectTrigger className="h-11 bg-background"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(TEAM_SIZES).map(([key, val]) => (
                    <SelectItem key={key} value={key}>{val.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button
            onClick={handleLaunch}
            disabled={launching}
            className="w-full h-12 mt-7 text-base font-semibold gap-2"
          >
            {launching ? <><Rocket className="w-4 h-4 animate-pulse" /> Launching…</> : <><Rocket className="w-4 h-4" /> Launch Demo</>}
          </Button>

          <p className="text-[11px] text-muted-foreground text-center mt-4">
            All data is simulated. No real business data is shown.
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}