import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Users, Phone, Calendar, Target, Clock, TrendingUp, ShieldCheck, PhoneOff, Activity, BarChart3, Zap, Brain, CheckCircle2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell, BarChart, Bar, Legend } from 'recharts';
import StatusBadge from '@/components/shared/StatusBadge';
import AnimatedCounter from './AnimatedCounter';
import { format } from 'date-fns';
import { subDays } from 'date-fns';

const COLORS = ['hsl(217,91%,60%)', 'hsl(262,83%,58%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(0,84%,60%)', 'hsl(192,83%,48%)'];

const COLOR_MAP = {
  blue: { bg: 'bg-blue-500/10', icon: 'text-blue-400', border: 'border-blue-500/20' },
  gold: { bg: 'bg-amber-500/10', icon: 'text-amber-400', border: 'border-amber-500/20' },
  green: { bg: 'bg-emerald-500/10', icon: 'text-emerald-400', border: 'border-emerald-500/20' },
  purple: { bg: 'bg-purple-500/10', icon: 'text-purple-400', border: 'border-purple-500/20' },
  red: { bg: 'bg-red-500/10', icon: 'text-red-400', border: 'border-red-500/20' },
};

function KpiCard({ title, value, icon: Icon, color = 'blue', trend, subtext }) {
  const c = COLOR_MAP[color] || COLOR_MAP.blue;
  return (
    <div className={`relative w-full text-left bg-card border rounded-xl p-3 sm:p-4 transition-all duration-200 ${c.border}`}>
      <div className="flex items-start justify-between gap-2">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${c.bg}`}>
          <Icon className={`w-4 h-4 ${c.icon}`} />
        </div>
        {trend !== undefined && (
          <span className={`flex items-center gap-0.5 text-xs font-medium shrink-0 ${trend >= 0 ? 'text-emerald-500' : 'text-red-500'}`}>
            <TrendingUp className="w-3 h-3" />{Math.abs(trend)}%
          </span>
        )}
      </div>
      <div className="mt-2">
        <p className="text-xl sm:text-2xl font-bold tracking-tight tabular-nums">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5 font-medium">{title}</p>
        {subtext && <p className="text-[10px] text-muted-foreground/70 mt-0.5 truncate">{subtext}</p>}
      </div>
    </div>
  );
}

const AGENTS = [
  { name: 'Marketing Engine', color: '#F5C842', icon: TrendingUp, desc: 'Finding prospects 24/7' },
  { name: 'Trinity AI', color: '#A78BFA', icon: Brain, desc: 'Executive oversight' },
  { name: 'Market Intel', color: '#34D399', icon: Activity, desc: 'Competitive scanning' },
  { name: 'Customer Success', color: '#60A5FA', icon: CheckCircle2, desc: 'Subscriber support' },
];

export default function DashboardTab({ state }) {
  const [liveCallCount, setLiveCallCount] = useState(0);

  const { leads, calls, appointments, tasks, timeSeries, pieData, outcomeData, hourlyData, sourceData, totalLeads } = state;

  const appointmentsSet = appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length;
  const totalCalls = calls.length;
  const complianceRate = totalCalls > 0 ? Math.round((calls.filter(c => c.fcc_compliant).length / totalCalls) * 100) : 100;
  const conversionRate = totalCalls > 0 ? Math.round((calls.filter(c => c.outcome === 'appointment_set').length / totalCalls) * 100) : 0;
  const avgCallDuration = calls.filter(c => c.duration_seconds > 0).reduce((a, c, _, arr) => a + c.duration_seconds / arr.length, 0);
  const pendingTasks = tasks.filter(t => t.status === 'pending').length;
  const contactedToday = calls.filter(c => c.created_date?.startsWith(format(new Date(), 'yyyy-MM-dd'))).length;

  // Animate live call count
  useEffect(() => {
    const ticker = setInterval(() => setLiveCallCount(c => c + (Math.random() > 0.6 ? 1 : 0)), 8000);
    return () => clearInterval(ticker);
  }, []);

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Header — mirrors Dashboard.jsx */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Operations Center</h1>
            <p className="text-muted-foreground text-xs">Real-time AI business intelligence</p>
          </div>
        </div>
        <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30 text-xs">
          ✓ {state.industry.label}
        </Badge>
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 whitespace-nowrap">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <span className="text-xs text-emerald-500 font-medium">Live · {format(new Date(), 'h:mm a')}</span>
        </div>
      </div>

      {/* Live call alert */}
      {liveCallCount > 0 && (
        <div className="flex items-center gap-3 p-3 bg-primary/5 border border-primary/20 rounded-xl">
          <Activity className="w-5 h-5 text-primary animate-pulse shrink-0" />
          <p className="text-sm font-medium text-primary">{liveCallCount} new call{liveCallCount > 1 ? 's' : ''} logged this session</p>
          <Badge className="bg-primary/10 text-primary border-primary/20 ml-auto">{liveCallCount} live</Badge>
        </div>
      )}

      {/* KPI grid — mirrors DrillableKPICard */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
        <KpiCard title="Total Leads" value={<AnimatedCounter value={totalLeads} />} icon={Users} color="blue" trend={12} subtext={`${leads.filter(l => l.consent_given).length} consented`} />
        <KpiCard title="Calls Made" value={<AnimatedCounter value={totalCalls} />} icon={Phone} color="gold" trend={8} subtext={`${contactedToday} today`} />
        <KpiCard title="Appointments" value={<AnimatedCounter value={appointmentsSet} />} icon={Calendar} color="green" trend={15} subtext={`${conversionRate}% conversion`} />
        <KpiCard title="Pending Tasks" value={<AnimatedCounter value={pendingTasks} />} icon={Target} color="purple" subtext="follow-ups due" />
        <KpiCard title="FCC Compliance" value={`${complianceRate}%`} icon={ShieldCheck} color="green" />
        <KpiCard title="Avg Call Duration" value={`${Math.floor(avgCallDuration / 60)}m ${Math.round(avgCallDuration % 60)}s`} icon={Clock} color="blue" />
        <KpiCard title="Answered Rate" value={`${totalCalls > 0 ? Math.round((calls.filter(c => c.status === 'completed').length / totalCalls) * 100) : 0}%`} icon={TrendingUp} color="gold" />
        <KpiCard title="DNC Blocks" value={calls.filter(c => c.status === 'blocked').length} icon={PhoneOff} color="red" />
      </div>

      {/* Main charts row — mirrors Dashboard area chart + pie */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-3 sm:p-5">
          <div className="flex items-center justify-between mb-4 gap-2">
            <h3 className="font-semibold text-sm whitespace-nowrap">Call Activity — Last 7 Days</h3>
            <div className="flex items-center gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-primary inline-block" />Total</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-emerald-500 inline-block" />Answered</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-purple-500 inline-block" />Appointments</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={timeSeries}>
              <defs>
                <linearGradient id="gCalls" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gAppts" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(162,63%,47%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(162,63%,47%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px', background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)' }} />
              <Area type="monotone" dataKey="calls" name="Total Calls" stroke="hsl(217,91%,60%)" fill="url(#gCalls)" strokeWidth={2} />
              <Area type="monotone" dataKey="answered" name="Answered" stroke="hsl(262,83%,58%)" fill="none" strokeWidth={2} strokeDasharray="4 2" />
              <Area type="monotone" dataKey="appointments" name="Appointments" stroke="hsl(162,63%,47%)" fill="url(#gAppts)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* AI Status Panel — mirrors AIStatusPanel.jsx */}
        <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-card via-card to-primary/5 p-5">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">AI Agent Status</h3>
                  <p className="text-[10px] text-muted-foreground">All agents operational</p>
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[10px] text-emerald-500 font-semibold">LIVE</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2 mb-4">
              {AGENTS.map(agent => (
                <div key={agent.name} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-background/40 border border-border/50">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${agent.color}20` }}>
                    <agent.icon className="w-3.5 h-3.5" style={{ color: agent.color }} />
                  </div>
                  <div className="min-w-0">
                    <p className="text-[11px] font-semibold truncate">{agent.name}</p>
                    <p className="text-[9px] text-muted-foreground truncate">{agent.desc}</p>
                  </div>
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0 ml-auto animate-pulse" />
                </div>
              ))}
            </div>
            <div className="rounded-xl bg-primary/5 border border-primary/20 p-3">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="w-3.5 h-3.5 text-primary" />
                <span className="text-[11px] font-semibold text-primary">Marketing Engine — 24/7</span>
                <Badge className="ml-auto text-[9px] bg-primary/10 text-primary border-primary/20 px-1.5 py-0">Cycle #{42}</Badge>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="text-center">
                  <p className="text-base font-bold text-primary"><AnimatedCounter value={state.totalLeads * 2} /></p>
                  <p className="text-[9px] text-muted-foreground">Prospects</p>
                </div>
                <div className="text-center">
                  <p className="text-base font-bold text-emerald-500"><AnimatedCounter value={state.socialPosts.length} /></p>
                  <p className="text-[9px] text-muted-foreground">Posts Created</p>
                </div>
                <div className="text-center">
                  <p className="text-base font-bold text-purple-400"><AnimatedCounter value={state.socialPosts.reduce((a, p) => a + (p.performance_reach || 0), 0)} /></p>
                  <p className="text-[9px] text-muted-foreground">Est. Reach</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Second charts row — outcomes, hourly, sources */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-4">Call Outcomes (7d)</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={outcomeData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
              <XAxis type="number" tick={{ fontSize: 10 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={80} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px', background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)' }} />
              <Bar dataKey="value" name="Count" radius={[0, 4, 4, 0]}>
                {outcomeData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-4">Best Calling Hours</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="hour" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px', background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)' }} />
              <Bar dataKey="calls" name="Calls" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-4">Lead Sources</h3>
          <div className="space-y-2.5">
            {sourceData.map((s, i) => (
              <div key={s.name}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="font-medium">{s.name}</span>
                  <span className="text-muted-foreground">{s.value} ({Math.round((s.value / totalLeads) * 100)}%)</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${Math.round((s.value / totalLeads) * 100)}%`, backgroundColor: COLORS[i % COLORS.length] }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row — recent calls + upcoming appointments */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-3">Recent Calls</h3>
          <div className="space-y-2.5">
            {calls.slice(0, 6).map(call => (
              <div key={call.id} className="flex items-center justify-between gap-2 py-2 border-b border-border last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{call.lead_name}</p>
                  <p className="text-xs text-muted-foreground">{call.created_date && !isNaN(new Date(call.created_date)) ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</p>
                </div>
                <div className="flex items-center gap-2">
                  {call.duration_seconds > 0 && <span className="text-xs text-muted-foreground whitespace-nowrap">{Math.floor(call.duration_seconds / 60)}m {call.duration_seconds % 60}s</span>}
                  <StatusBadge status={call.outcome || call.status} />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-3">Upcoming Appointments</h3>
          <div className="space-y-2.5">
            {appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).slice(0, 6).map(apt => (
              <div key={apt.id} className="flex items-center justify-between gap-2 py-2 border-b border-border last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{apt.lead_name}</p>
                  <p className="text-xs text-muted-foreground">{apt.scheduled_date && !isNaN(new Date(apt.scheduled_date)) ? format(new Date(apt.scheduled_date), 'MMM d, h:mm a') : ''}</p>
                </div>
                <StatusBadge status={apt.status} />
              </div>
            ))}
            {appointments.length === 0 && <p className="text-sm text-muted-foreground">No appointments yet</p>}
          </div>
        </div>
      </div>
    </div>
  );
}