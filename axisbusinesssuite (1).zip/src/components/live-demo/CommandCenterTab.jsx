import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, Globe, Cpu, Zap, Brain, Shield, Bot, TrendingUp, CheckCircle2, Radio, Users, Phone, Calendar, DollarSign, Eye } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AnimatedCounter from './AnimatedCounter';

const AGENTS = [
  { name: 'AI Sales Development Rep', color: '#F5C842', icon: Phone, desc: 'Outbound calling 24/7' },
  { name: 'AI Appointment Setter', color: '#A78BFA', icon: Calendar, desc: 'Booking meetings' },
  { name: 'AI Follow-Up Agent', color: '#34D399', icon: CheckCircle2, desc: 'Nurture sequences' },
  { name: 'AI CRM Manager', color: '#60A5FA', icon: Users, desc: 'Pipeline automation' },
  { name: 'AI Marketing Copywriter', color: '#F472B6', icon: TrendingUp, desc: 'Content generation' },
  { name: 'AI Social Media Manager', color: '#22D3EE', icon: Radio, desc: 'Publishing & engagement' },
  { name: 'AI Recruiter', color: '#FB923C', icon: Bot, desc: 'Candidate screening' },
  { name: 'AI Bookkeeper', color: '#4ADE80', icon: DollarSign, desc: 'Financial ops' },
];

export default function CommandCenterTab({ state }) {
  const [activeCalls, setActiveCalls] = useState(Math.round(state.callsPerDay * 0.08));
  const [globeActivity, setGlobeActivity] = useState([]);

  useEffect(() => {
    const ticker = setInterval(() => {
      setActiveCalls((v) => Math.max(0, v + Math.floor(Math.random() * 5) - 2));
      setGlobeActivity((prev) => {
        const points = [...prev];
        for (let i = 0; i < 3; i++) {
          points.push({ id: Math.random().toString(36).slice(2), x: 10 + Math.random() * 80, y: 15 + Math.random() * 70 });
        }
        return points.slice(-15);
      });
    }, 2000);
    return () => clearInterval(ticker);
  }, []);

  const commandMetrics = [
    { label: 'Active AI Calls', value: activeCalls, icon: Phone, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'Leads in Pipeline', value: state.totalLeads, icon: Users, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Appointments (30d)', value: Math.round(state.callsPerDay * 0.12 * 30), icon: Calendar, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'Marketing Reach', value: state.socialPosts.reduce((a, p) => a + (p.performance_reach || 0), 0), icon: Eye, color: 'text-purple-400', bg: 'bg-purple-500/10' },
    { label: 'Team Members', value: state.employees, icon: Bot, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
    { label: 'Monthly Revenue', value: state.monthlyRevenue, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-500/10', prefix: '$' },
    { label: 'Emails Sent', value: state.emailMessages.length, icon: Radio, color: 'text-pink-400', bg: 'bg-pink-500/10' },
    { label: 'Compliance', value: 98, icon: Shield, color: 'text-emerald-400', bg: 'bg-emerald-500/10', suffix: '%' },
  ];

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Globe className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Command Center</h1>
            <p className="text-muted-foreground text-xs">CEO view — all systems operational</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 whitespace-nowrap">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <span className="text-xs text-emerald-500 font-medium">All Systems Live</span>
        </div>
      </div>

      {/* Metric Grid — mirrors Dashboard KPI cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        {commandMetrics.map((metric, idx) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.04 }}
            className="rounded-xl border border-border bg-card p-3"
          >
            <div className="flex items-start justify-between mb-2">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${metric.bg}`}>
                <metric.icon className={`w-3.5 h-3.5 ${metric.color}`} />
              </div>
            </div>
            <p className="text-xl font-bold tracking-tight tabular-nums">
              {metric.prefix}{typeof metric.value === 'number' ? <AnimatedCounter value={metric.value} /> : metric.value}{metric.suffix}
            </p>
            <p className="text-[10px] text-muted-foreground font-medium mt-0.5">{metric.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Globe + AI Workforce */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Globe visualization */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-2 rounded-2xl border border-border bg-card p-4 relative overflow-hidden h-64"
        >
          <div className="flex items-center gap-2 mb-2 relative z-10">
            <Globe className="w-4 h-4 text-primary" />
            <span className="font-semibold text-sm">Global Activity Map</span>
            <span className="ml-auto text-xs text-muted-foreground flex items-center gap-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              Live
            </span>
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-48 h-48 rounded-full bg-gradient-to-br from-primary/10 via-blue-500/5 to-transparent border border-primary/20">
              <div className="absolute inset-2 rounded-full border border-primary/10" />
              <div className="absolute inset-4 rounded-full border border-primary/5" />
              <div className="absolute inset-6 rounded-full border border-primary/5" />
              {globeActivity.map((point) => (
                <motion.div
                  key={point.id}
                  initial={{ scale: 0, opacity: 1 }}
                  animate={{ scale: 3, opacity: 0 }}
                  transition={{ duration: 2 }}
                  className="absolute w-2 h-2 rounded-full bg-primary"
                  style={{ left: `${point.x}%`, top: `${point.y}%` }}
                />
              ))}
              {/* Center pulse */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-primary animate-ping" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-primary" />
            </div>
          </div>
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1"><Activity className="w-3 h-3 text-primary" />{activeCalls} active calls</span>
            <span>{state.industry.label} · {state.team.label}</span>
          </div>
        </motion.div>

        {/* AI Digital Workforce — mirrors AIStatusPanel */}
        <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-card via-card to-primary/5 p-4">
          <div className="absolute -top-8 -right-8 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Cpu className="w-3.5 h-3.5 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">AI Digital Workforce</h3>
                  <p className="text-[9px] text-muted-foreground">All agents operational</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[9px] text-emerald-500 font-semibold">LIVE</span>
              </div>
            </div>
            <div className="space-y-1.5 overflow-y-auto no-scrollbar max-h-[180px]">
              {AGENTS.map((agent, idx) => (
                <motion.div
                  key={agent.name}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="flex items-center gap-2 p-1.5 rounded-lg bg-background/40 border border-border/50"
                >
                  <div className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${agent.color}20` }}>
                    <agent.icon className="w-3 h-3" style={{ color: agent.color }} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] font-semibold truncate">{agent.name}</p>
                    <p className="text-[8px] text-muted-foreground truncate">{agent.desc}</p>
                  </div>
                  <div className="w-1 h-1 rounded-full bg-emerald-500 flex-shrink-0 animate-pulse" />
                </motion.div>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-border">
              <div className="text-center">
                <p className="font-bold text-base text-foreground tabular-nums">{AGENTS.length}</p>
                <p className="text-[9px] text-muted-foreground uppercase">AI Agents</p>
              </div>
              <div className="text-center">
                <p className="font-bold text-base text-primary tabular-nums">{activeCalls}</p>
                <p className="text-[9px] text-muted-foreground uppercase">Live Calls</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}