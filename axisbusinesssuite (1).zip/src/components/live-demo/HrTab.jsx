import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HeartHandshake, Users, Briefcase, FileText, CalendarDays, UserPlus, Building2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import StatusBadge from '@/components/shared/StatusBadge';
import AnimatedCounter from './AnimatedCounter';
import { generateHireEntry } from '@/lib/demoSimulator';
import { format } from 'date-fns';

const DEPARTMENTS = ['Sales', 'Marketing', 'Operations', 'HR', 'Finance', 'Support'];
const DEPT_COLORS = ['text-blue-400 bg-blue-500/10', 'text-purple-400 bg-purple-500/10', 'text-emerald-400 bg-emerald-500/10', 'text-amber-400 bg-amber-500/10', 'text-cyan-400 bg-cyan-500/10', 'text-pink-400 bg-pink-500/10'];

export default function HrTab({ state }) {
  const [hires, setHires] = useState([]);
  const [stats, setStats] = useState({
    employees: state.employeeList.length,
    jobPostings: Math.max(1, Math.round(state.employees * 0.08)),
    applications: Math.round(state.employees * 2.5),
    timeOff: Math.max(0, Math.floor(state.employees / 8)),
  });
  const stateRef = useRef(state);
  stateRef.current = state;

  useEffect(() => {
    // Generate recent hires from existing employees
    const recent = state.employeeList
      .filter(e => e.hire_date && new Date(e.hire_date) > new Date(Date.now() - 30 * 86400000))
      .slice(0, 6);
    setHires(recent.length > 0 ? recent : state.employeeList.slice(0, 4));

    const ticker = setInterval(() => {
      setHires((prev) => [generateHireEntry(stateRef.current), ...prev].slice(0, 7));
      setStats((prev) => ({
        ...prev,
        applications: prev.applications + (Math.random() > 0.4 ? 1 : 0),
      }));
    }, 6000);
    return () => clearInterval(ticker);
  }, []);

  const deptCounts = DEPARTMENTS.map((d, i) => ({
    name: d,
    count: state.employeeList.filter(e => e.department === d).length,
    color: DEPT_COLORS[i],
  }));

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header — mirrors HumanResources.jsx style */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-pink-500/5 p-5">
        <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <HeartHandshake className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">HR Suite</h1>
              <p className="text-muted-foreground text-xs">People operations & workforce management</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/80 border border-border text-xs font-semibold">
              <span className="text-primary">{stats.employees}</span><span className="text-muted-foreground">employees</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold">
              <span className="text-emerald-500">{state.employeeList.filter(e => e.status === 'active').length}</span><span className="text-emerald-600/70">active</span>
            </div>
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Building2 className="w-3 h-3 mr-1" />{state.industry.label}
            </Badge>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: Users, label: 'Team Members', value: stats.employees, color: 'text-blue-400', bg: 'bg-blue-500/10' },
          { icon: Briefcase, label: 'Open Positions', value: stats.jobPostings, color: 'text-purple-400', bg: 'bg-purple-500/10' },
          { icon: FileText, label: 'Applications (7d)', value: stats.applications, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
          { icon: CalendarDays, label: 'Time-Off Pending', value: stats.timeOff, color: 'text-amber-400', bg: 'bg-amber-500/10' },
        ].map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${bg}`}>
              <Icon className={`w-4 h-4 ${color}`} />
            </div>
            <div>
              <p className="text-lg font-bold leading-none tabular-nums"><AnimatedCounter value={value} /></p>
              <p className="text-[10px] text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Department breakdown + Recent Hires */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Department breakdown */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-4">Department Breakdown</h3>
          <div className="space-y-2.5">
            {deptCounts.map((dept, idx) => {
              const maxCount = Math.max(...deptCounts.map((d) => d.count));
              const pct = maxCount > 0 ? (dept.count / maxCount) * 100 : 0;
              return (
                <motion.div key={dept.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: idx * 0.06 }}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs text-muted-foreground">{dept.name}</span>
                    <span className="text-xs font-medium tabular-nums">{dept.count}</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.6, delay: idx * 0.06 }} className="h-full rounded-full bg-primary/70" />
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Employee Directory Preview */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40">
            <Users className="w-4 h-4 text-primary" />
            <h3 className="font-semibold text-sm">Employee Directory</h3>
            <Badge variant="outline" className="ml-auto text-xs">{state.employeeList.length} total</Badge>
          </div>
          <div className="divide-y divide-border max-h-[350px] overflow-y-auto no-scrollbar">
            {state.employeeList.slice(0, 20).map(emp => (
              <div key={emp.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-muted/30 transition-colors">
                <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-primary font-semibold text-xs shrink-0">
                  {emp.first_name[0]}{emp.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{emp.first_name} {emp.last_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{emp.job_title} · {emp.department}</p>
                </div>
                <StatusBadge status={emp.status} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Hires feed */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40">
          <UserPlus className="w-4 h-4 text-emerald-400" />
          <h3 className="font-semibold text-sm">Recent Hires</h3>
          <div className="flex items-center gap-1.5 ml-auto">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-emerald-500 font-medium">LIVE</span>
          </div>
        </div>
        <div className="divide-y divide-border">
          <AnimatePresence initial={false}>
            {hires.map((hire) => (
              <motion.div
                key={hire.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-center gap-3 px-4 py-2.5"
              >
                <div className="w-8 h-8 rounded-full bg-emerald-500/15 flex items-center justify-center text-emerald-400 font-semibold text-xs shrink-0">
                  {hire.first_name[0]}{hire.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{hire.first_name} {hire.last_name}</p>
                  <p className="text-xs text-muted-foreground">{hire.job_title} · {hire.department}</p>
                </div>
                <span className="text-[11px] text-emerald-400 font-medium">Onboarded</span>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}