import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mic, Phone, Calendar, PhoneOff, Zap, Radio, Bot, CheckCircle2, Play } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import StatusBadge from '@/components/shared/StatusBadge';
import AnimatedCounter from './AnimatedCounter';
import { generateCallEntry } from '@/lib/demoSimulator';
import { format } from 'date-fns';

export default function CallBotTab({ state }) {
  const [feed, setFeed] = useState([]);
  const [stats, setStats] = useState({
    called: 0,
    appointments: 0,
    notInterested: 0,
    noAnswer: 0,
  });
  const [batchDialing, setBatchDialing] = useState(true);
  const [batchIndex, setBatchIndex] = useState(0);
  const stateRef = useRef(state);
  stateRef.current = state;

  const eligibleLeads = state.leads.filter(l => l.status !== 'do_not_call' && l.status !== 'invalid' && l.consent_given && (l.call_attempts || 0) < 3);

  const addCall = useCallback(() => {
    const entry = generateCallEntry(stateRef.current);
    setFeed((prev) => [entry, ...prev].slice(0, 12));
    setStats((prev) => {
      const called = prev.called + 1;
      const appointments = prev.appointments + (entry.outcome === 'appointment_set' ? 1 : 0);
      const notInterested = prev.notInterested + (entry.outcome === 'not_interested' ? 1 : 0);
      const noAnswer = prev.noAnswer + (entry.outcome === 'no_answer' ? 1 : 0);
      return { called, appointments, notInterested, noAnswer };
    });
    setBatchIndex(i => i + 1);
  }, []);

  useEffect(() => {
    // Seed initial feed from existing calls
    setFeed(state.calls.slice(0, 8));
    setStats({
      called: state.calls.length,
      appointments: state.calls.filter(c => c.outcome === 'appointment_set').length,
      notInterested: state.calls.filter(c => c.outcome === 'not_interested').length,
      noAnswer: state.calls.filter(c => c.outcome === 'no_answer').length,
    });
    // Continuous live feed
    let timer;
    const schedule = () => {
      const delay = 3000 + Math.random() * 3000;
      timer = setTimeout(() => {
        addCall();
        schedule();
      }, delay);
    };
    schedule();
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="space-y-5 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header — mirrors CallBot.jsx */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-purple-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-primary/20">
              <Mic className="w-5 h-5 text-primary" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight">AXIS AI Voice Engine</h1>
                <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2 py-0.5 animate-pulse">
                  ● LIVE CALL
                </span>
              </div>
              <p className="text-muted-foreground text-xs">Native real-time AI voice — powered by OpenAI Realtime API + Twilio</p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs">
              <Bot className="w-3.5 h-3.5 text-primary" />
              <span className="font-medium text-primary">AXIS Native AI</span>
            </div>
            <Badge className={batchDialing ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 animate-pulse' : 'bg-muted text-muted-foreground'}>
              {batchDialing ? `Batch ${batchIndex}/${eligibleLeads.length}` : `${eligibleLeads.length} ready`}
            </Badge>
          </div>
        </div>
      </div>

      {/* Session Stats — mirrors CallBot.jsx session stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { icon: Phone, label: 'Called', value: stats.called, color: 'text-primary' },
          { icon: Calendar, label: 'Appointments', value: stats.appointments, color: 'text-emerald-600' },
          { icon: PhoneOff, label: 'Not Interested', value: stats.notInterested, color: 'text-amber-600' },
          { icon: Zap, label: 'No Answer', value: stats.noAnswer, color: 'text-slate-500' },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
            <Icon className={`w-4 h-4 ${color}`} />
            <div>
              <p className="text-lg font-bold leading-none tabular-nums"><AnimatedCounter value={value} /></p>
              <p className="text-[10px] text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Live Call Feed — mirrors a Dial Queue / Call Log hybrid */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border bg-muted/40">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-bold">Live AI Call Activity</h2>
            <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px] ml-1">Live Data</Badge>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-emerald-500 font-medium">STREAMING</span>
          </div>
        </div>
        <div className="divide-y divide-border max-h-[400px] overflow-y-auto no-scrollbar">
          <AnimatePresence initial={false}>
            {feed.map((call) => (
              <motion.div
                key={call.id}
                initial={{ opacity: 0, x: -20, height: 0 }}
                animate={{ opacity: 1, x: 0, height: 'auto' }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="flex items-center gap-3 px-4 py-3 hover:bg-muted/30 transition-colors"
              >
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <Phone className="w-3.5 h-3.5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{call.lead_name}</p>
                  <p className="text-xs text-muted-foreground">{call.phone_number} · {call.created_date ? format(new Date(call.created_date), 'h:mm a') : ''}</p>
                </div>
                {call.duration_seconds > 0 && <span className="text-xs text-muted-foreground whitespace-nowrap">{Math.floor(call.duration_seconds / 60)}m {call.duration_seconds % 60}s</span>}
                <StatusBadge status={call.outcome || call.status} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}