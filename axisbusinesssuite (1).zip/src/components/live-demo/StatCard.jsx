import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const colorMap = {
  red: 'from-red-500/20 to-red-500/5 border-red-500/30 text-red-400',
  blue: 'from-blue-500/20 to-blue-500/5 border-blue-500/30 text-blue-400',
  green: 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/30 text-emerald-400',
  purple: 'from-purple-500/20 to-purple-500/5 border-purple-500/30 text-purple-400',
  orange: 'from-orange-500/20 to-orange-500/5 border-orange-500/30 text-orange-400',
  emerald: 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/30 text-emerald-400',
  cyan: 'from-cyan-500/20 to-cyan-500/5 border-cyan-500/30 text-cyan-400',
  pink: 'from-pink-500/20 to-pink-500/5 border-pink-500/30 text-pink-400',
  primary: 'from-primary/20 to-primary/5 border-primary/30 text-primary',
};

export default function StatCard({ label, value, prefix, suffix, icon: Icon, color = 'primary', delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4 }}
      className={cn(
        'relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4',
        colorMap[color] || colorMap.primary
      )}
    >
      <div className="absolute -right-4 -top-4 w-20 h-20 rounded-full bg-current opacity-5 blur-2xl" />
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide truncate">{label}</span>
        {Icon && <Icon className="w-4 h-4 opacity-70" />}
      </div>
      <div className="font-poppins font-bold text-2xl text-foreground tabular-nums">
        {prefix}{typeof value === 'number' ? value.toLocaleString('en-US') : value}{suffix}
      </div>
    </motion.div>
  );
}