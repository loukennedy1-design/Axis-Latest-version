import React, { useState, useEffect } from 'react';
import { Receipt, DollarSign, FileText, Wallet, TrendingUp, TrendingDown } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, CartesianGrid } from 'recharts';
import StatusBadge from '@/components/shared/StatusBadge';
import AnimatedCounter from './AnimatedCounter';
import { format } from 'date-fns';

const MONTHS = ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'];

export default function FinanceTab({ state }) {
  const [revenue, setRevenue] = useState(Math.round(state.monthlyRevenue * 0.18));
  const [expenses, setExpenses] = useState(Math.round(state.monthlyRevenue * 0.42));
  const [payroll, setPayroll] = useState(state.team.hasPayroll ? state.employeeList.reduce((a, e) => a + (e.salary || 0), 0) / 12 : 0);
  const [chartData] = useState(
    state.revenueTrend.map((v, i) => ({ month: MONTHS[i], revenue: v }))
  );

  useEffect(() => {
    const ticker = setInterval(() => {
      setRevenue((v) => v + Math.floor(Math.random() * 800) + 200);
      setExpenses((v) => v + (Math.random() > 0.7 ? Math.floor(Math.random() * 300) : 0));
    }, 3500);
    return () => clearInterval(ticker);
  }, []);

  const netProfit = revenue - expenses;
  const profitMargin = revenue > 0 ? Math.round((netProfit / revenue) * 100) : 0;
  const invoicesPaid = state.invoices.filter(i => i.status === 'paid').length;
  const invoicesPending = state.invoices.filter(i => i.status === 'pending').length;
  const invoicesOverdue = state.invoices.filter(i => i.status === 'overdue').length;

  return (
    <div className="space-y-4 overflow-y-auto no-scrollbar h-full pr-1">
      {/* Hero Header — mirrors FinancialOps.jsx style */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Receipt className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Financial Operations</h1>
              <p className="text-muted-foreground text-xs">Revenue, invoicing, expenses & payroll</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold">
              <TrendingUp className="w-3 h-3 text-emerald-500" />
              <span className="text-emerald-500">{profitMargin}%</span><span className="text-emerald-600/70">margin</span>
            </div>
            <Badge className="bg-primary/10 text-primary border-primary/20">{state.industry.label}</Badge>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: DollarSign, label: 'Revenue (This Month)', value: `$${revenue.toLocaleString('en-US')}`, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
          { icon: FileText, label: 'Invoices Sent', value: state.invoices.length, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
          { icon: TrendingDown, label: 'Expenses Logged', value: `$${expenses.toLocaleString('en-US')}`, color: 'text-amber-400', bg: 'bg-amber-500/10' },
          { icon: Wallet, label: state.team.hasPayroll ? 'Payroll (Monthly)' : 'Owner Draw', value: `$${state.team.hasPayroll ? Math.round(payroll).toLocaleString('en-US') : Math.round(revenue * 0.35).toLocaleString('en-US')}`, color: 'text-purple-400', bg: 'bg-purple-500/10' },
        ].map(({ icon: Icon, label, value, color, bg }) => (
          <div key={label} className="rounded-xl border border-border bg-card p-3 flex items-center gap-2">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${bg}`}>
              <Icon className={`w-4 h-4 ${color}`} />
            </div>
            <div className="min-w-0">
              <p className="text-base font-bold leading-tight tabular-nums truncate">{typeof value === 'number' ? <AnimatedCounter value={value} /> : value}</p>
              <p className="text-[10px] text-muted-foreground">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Revenue Chart + Financial Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-3 sm:p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <h3 className="font-semibold text-sm">Revenue Trend — Last 6 Months</h3>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                contentStyle={{ background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)', borderRadius: '8px', fontSize: '12px' }}
                formatter={(v) => [`$${v.toLocaleString('en-US')}`, 'Revenue']}
              />
              <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                {chartData.map((_, i) => (
                  <Cell key={i} fill={i === chartData.length - 1 ? 'hsl(0 100% 50%)' : 'hsl(0 100% 50% / 0.4)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5">
          <h3 className="font-semibold text-sm mb-3">Financial Summary</h3>
          <div className="space-y-3">
            <FinanceRow label="Gross Revenue" value={`$${revenue.toLocaleString('en-US')}`} positive />
            <FinanceRow label="Total Expenses" value={`$${expenses.toLocaleString('en-US')}`} negative />
            <FinanceRow label="Net Profit" value={`$${netProfit.toLocaleString('en-US')}`} positive />
            <div className="h-px bg-border my-1" />
            <FinanceRow label="Profit Margin" value={`${profitMargin}%`} />
            <FinanceRow label="AR Outstanding" value={`$${Math.round(revenue * 0.18).toLocaleString('en-US')}`} />
            <FinanceRow label="Avg. Invoice" value={`$${Math.round(revenue / Math.max(state.invoices.length, 1)).toLocaleString('en-US')}`} />
          </div>
        </div>
      </div>

      {/* Invoices + Expenses */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40">
            <FileText className="w-4 h-4 text-cyan-400" />
            <h3 className="font-semibold text-sm">Recent Invoices</h3>
            <div className="flex items-center gap-1.5 ml-auto">
              <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px]">{invoicesPaid} paid</Badge>
              <Badge className="bg-amber-500/10 text-amber-500 border-amber-500/20 text-[10px]">{invoicesPending} pending</Badge>
            </div>
          </div>
          <div className="divide-y divide-border max-h-[250px] overflow-y-auto no-scrollbar">
            {state.invoices.slice(0, 8).map(inv => (
              <div key={inv.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{inv.invoice_number}</p>
                  <p className="text-xs text-muted-foreground truncate">{inv.client_name}</p>
                </div>
                <span className="text-sm font-semibold tabular-nums">${inv.amount.toLocaleString('en-US')}</span>
                <StatusBadge status={inv.status} />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-border bg-muted/40">
            <TrendingDown className="w-4 h-4 text-amber-400" />
            <h3 className="font-semibold text-sm">Recent Expenses</h3>
          </div>
          <div className="divide-y divide-border max-h-[250px] overflow-y-auto no-scrollbar">
            {state.expenses.slice(0, 8).map(exp => (
              <div key={exp.id} className="flex items-center justify-between gap-2 px-4 py-2.5">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{exp.description}</p>
                  <p className="text-xs text-muted-foreground">{exp.category}</p>
                </div>
                <span className="text-sm font-semibold tabular-nums text-amber-400">-${exp.amount.toLocaleString('en-US')}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function FinanceRow({ label, value, positive, negative }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-sm font-semibold tabular-nums ${positive ? 'text-emerald-400' : negative ? 'text-amber-400' : 'text-foreground'}`}>{value}</span>
    </div>
  );
}