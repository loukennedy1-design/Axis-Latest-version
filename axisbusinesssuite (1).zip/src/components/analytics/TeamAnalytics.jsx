import React from 'react';
import { KpiCard, SectionHeader } from './AnalyticsOverview';
import { Users, Star, Briefcase, UserCheck, TrendingUp, Award } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, PolarGrid, PolarAngleAxis, Radar
} from 'recharts';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)'];

export default function TeamAnalytics({ salesReps = [], calls = [], appointments = [], leads = [], candidates = [], employees = [] }) {
  const activeReps = salesReps.filter(r => r.status === 'active').length;
  const hired = candidates.filter(c => c.status === 'hired').length;
  const totalAppts = appointments.filter(a => ['scheduled', 'confirmed', 'completed'].includes(a.status)).length;
  const completedAppts = appointments.filter(a => a.status === 'completed').length;

  // Rep performance data
  const repPerf = salesReps.slice(0, 8).map(rep => ({
    name: rep.name?.split(' ')[0] || rep.email?.split('@')[0] || 'Rep',
    calls: calls.filter(c => c.called_by === rep.email).length,
    appts: appointments.filter(a => a.assigned_to === rep.email).length,
    leads: leads.filter(l => l.assigned_to === rep.email).length,
    target_calls: rep.target_calls_per_day || 50,
  }));

  // Recruitment funnel
  const recruitFunnel = [
    { stage: 'New', value: candidates.filter(c => c.status === 'new').length },
    { stage: 'Screening', value: candidates.filter(c => c.status === 'screening').length },
    { stage: 'Interviewed', value: candidates.filter(c => ['interview_scheduled', 'interviewed'].includes(c.status)).length },
    { stage: 'Offer Sent', value: candidates.filter(c => c.status === 'offer_sent').length },
    { stage: 'Hired', value: candidates.filter(c => c.status === 'hired').length },
  ];

  // Appointment status distribution
  const apptStatus = [
    { name: 'Scheduled', value: appointments.filter(a => a.status === 'scheduled').length },
    { name: 'Confirmed', value: appointments.filter(a => a.status === 'confirmed').length },
    { name: 'Completed', value: appointments.filter(a => a.status === 'completed').length },
    { name: 'Cancelled', value: appointments.filter(a => a.status === 'cancelled').length },
    { name: 'No Show', value: appointments.filter(a => a.status === 'no_show').length },
  ].filter(a => a.value > 0);

  // Employee dept breakdown
  const deptBreakdown = Object.entries(
    employees.reduce((acc, e) => { acc[e.department || 'other'] = (acc[e.department || 'other'] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4">
      <SectionHeader title="Team & HR Analytics" subtitle="Sales team, recruitment pipeline, appointments & employees" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard title="Active Reps" value={activeReps} icon={Users} color="primary" subtext={`of ${salesReps.length} total`} />
        <KpiCard title="Appointments" value={totalAppts} icon={UserCheck} color="success" subtext={`${completedAppts} completed`} />
        <KpiCard title="Hired Candidates" value={hired} icon={Award} color="warning" subtext={`of ${candidates.length} pipeline`} />
        <KpiCard title="Employees" value={employees.filter(e => e.status === 'active').length} icon={Briefcase} color="blue" subtext={`${employees.length} total`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Rep Performance */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Rep Performance (Calls vs Leads)</p>
          {repPerf.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={repPerf}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Bar dataKey="calls" name="Calls" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="leads" name="Leads" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="appts" name="Appts" fill="hsl(43,96%,56%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground">No rep data</div>
          )}
        </div>

        {/* Recruitment Funnel */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Recruitment Pipeline</p>
          <div className="space-y-2.5">
            {recruitFunnel.map((stage, i) => (
              <div key={stage.stage}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-muted-foreground">{stage.stage}</span>
                  <span className="font-semibold">{stage.value}</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${candidates.length > 0 ? (stage.value / candidates.length) * 100 : 0}%`,
                      backgroundColor: COLORS[i % COLORS.length]
                    }}
                  />
                </div>
              </div>
            ))}
            {candidates.length === 0 && <p className="text-xs text-muted-foreground text-center py-6">No candidates yet</p>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Appointment Status */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Appointment Status Distribution</p>
          {apptStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={apptStatus}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Bar dataKey="value" radius={[3, 3, 0, 0]}>
                  {apptStatus.map((_, i) => (
                    <Bar key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[160px] flex items-center justify-center text-xs text-muted-foreground">No appointments</div>
          )}
        </div>

        {/* Employee Dept Breakdown */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Employees by Department</p>
          {deptBreakdown.length > 0 ? (
            <div className="space-y-2">
              {deptBreakdown.map((dept, i) => (
                <div key={dept.name}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="capitalize text-muted-foreground">{dept.name}</span>
                    <span className="font-semibold">{dept.value}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${employees.length > 0 ? (dept.value / employees.length) * 100 : 0}%`,
                        backgroundColor: COLORS[i % COLORS.length]
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[140px] flex items-center justify-center text-xs text-muted-foreground">No employee data</div>
          )}

          <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-border text-center">
            <div>
              <p className="text-base font-bold text-emerald-500">{employees.filter(e => e.status === 'active').length}</p>
              <p className="text-[10px] text-muted-foreground">Active</p>
            </div>
            <div>
              <p className="text-base font-bold text-amber-500">{employees.filter(e => e.status === 'on_leave').length}</p>
              <p className="text-[10px] text-muted-foreground">On Leave</p>
            </div>
            <div>
              <p className="text-base font-bold text-red-500">{employees.filter(e => e.status === 'terminated').length}</p>
              <p className="text-[10px] text-muted-foreground">Terminated</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}