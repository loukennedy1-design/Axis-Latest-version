import React from 'react';
import { KpiCard, SectionHeader } from './AnalyticsOverview';
import { Phone, PhoneCall, PhoneOff, Clock, CheckCircle2, Voicemail } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';
import { format, subDays } from 'date-fns';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)', 'hsl(192,83%,48%)'];

export default function CallsAnalytics({ calls = [] }) {
  const total = calls.length;
  const completed = calls.filter(c => c.status === 'completed').length;
  const noAnswer = calls.filter(c => c.status === 'no_answer').length;
  const voicemail = calls.filter(c => c.status === 'voicemail').length;
  const apptSet = calls.filter(c => c.outcome === 'appointment_set').length;
  const avgDur = calls.filter(c => c.duration_seconds > 0).reduce((a, c, _, arr) => a + c.duration_seconds / arr.length, 0);
  const compliant = calls.filter(c => c.fcc_compliant).length;

  // 30-day trend
  const trend = Array.from({ length: 30 }, (_, i) => {
    const d = subDays(new Date(), 29 - i);
    const ds = format(d, 'yyyy-MM-dd');
    return {
      name: i % 5 === 0 ? format(d, 'MMM d') : '',
      total: calls.filter(c => c.created_date?.startsWith(ds)).length,
      answered: calls.filter(c => c.created_date?.startsWith(ds) && c.status === 'completed').length,
      appts: calls.filter(c => c.created_date?.startsWith(ds) && c.outcome === 'appointment_set').length,
    };
  });

  const outcomeData = [
    { name: 'Appt Set', value: apptSet, fill: COLORS[1] },
    { name: 'Callback', value: calls.filter(c => c.outcome === 'callback_requested').length, fill: COLORS[0] },
    { name: 'Not Interested', value: calls.filter(c => c.outcome === 'not_interested').length, fill: COLORS[4] },
    { name: 'Voicemail Left', value: calls.filter(c => c.outcome === 'voicemail_left').length, fill: COLORS[3] },
    { name: 'Wrong Number', value: calls.filter(c => c.outcome === 'wrong_number').length, fill: COLORS[5] },
  ].filter(o => o.value > 0);

  const hourlyData = Array.from({ length: 13 }, (_, i) => {
    const h = i + 8;
    return {
      hour: `${h > 12 ? h - 12 : h}${h >= 12 ? 'pm' : 'am'}`,
      calls: calls.filter(c => c.created_date && new Date(c.created_date).getHours() === h).length,
    };
  });

  const callerBreakdown = Object.entries(
    calls.reduce((acc, c) => { const k = c.called_by || 'bot'; acc[k] = (acc[k] || 0) + 1; return acc; }, {})
  ).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4">
      <SectionHeader title="Call Operations Analytics" subtitle="Complete call performance & compliance tracking" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard title="Total Calls" value={total} icon={Phone} color="primary" subtext={`${completed} answered`} />
        <KpiCard title="Answer Rate" value={`${total > 0 ? Math.round((completed / total) * 100) : 0}%`} icon={PhoneCall} color="success" subtext={`${completed} completed`} />
        <KpiCard title="Appt Conversion" value={`${total > 0 ? Math.round((apptSet / total) * 100) : 0}%`} icon={CheckCircle2} color="warning" subtext={`${apptSet} set`} />
        <KpiCard title="Avg Duration" value={`${Math.floor(avgDur / 60)}m ${Math.round(avgDur % 60)}s`} icon={Clock} color="blue" subtext={`${total > 0 ? Math.round((compliant / total) * 100) : 100}% FCC compliant`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Call Volume — Last 30 Days</p>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={trend}>
              <defs>
                <linearGradient id="lgTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="lgAns" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(162,63%,47%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(162,63%,47%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,13%,18%)" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Area type="monotone" dataKey="total" name="Total" stroke="hsl(217,91%,60%)" fill="url(#lgTotal)" strokeWidth={2} />
              <Area type="monotone" dataKey="answered" name="Answered" stroke="hsl(162,63%,47%)" fill="url(#lgAns)" strokeWidth={2} />
              <Area type="monotone" dataKey="appts" name="Appt Set" stroke="hsl(43,96%,56%)" fill="none" strokeWidth={2} strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Call Outcomes</p>
          {outcomeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={outcomeData} cx="50%" cy="50%" innerRadius={30} outerRadius={58} paddingAngle={3} dataKey="value">
                  {outcomeData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[140px] flex items-center justify-center text-xs text-muted-foreground">No data</div>
          )}
          <div className="flex flex-wrap gap-x-2 gap-y-1 mt-2">
            {outcomeData.map(o => (
              <div key={o.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: o.fill }} />
                {o.name} ({o.value})
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Best Calling Hours</p>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="hour" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ fontSize: '11px' }} />
              <Bar dataKey="calls" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Top Callers</p>
          {callerBreakdown.length > 0 ? (
            <div className="space-y-2.5">
              {callerBreakdown.map((c, i) => (
                <div key={c.name}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="truncate max-w-[160px] text-muted-foreground">{c.name}</span>
                    <span className="font-semibold">{c.value}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(c.value / (callerBreakdown[0]?.value || 1)) * 100}%`, backgroundColor: COLORS[i % COLORS.length] }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[140px] flex items-center justify-center text-xs text-muted-foreground">No data</div>
          )}

          <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t border-border">
            <div className="text-center">
              <p className="text-lg font-bold text-red-500">{noAnswer}</p>
              <p className="text-[10px] text-muted-foreground">No Answer</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-purple-500">{voicemail}</p>
              <p className="text-[10px] text-muted-foreground">Voicemail</p>
            </div>
            <div className="text-center">
              <p className="text-lg font-bold text-amber-500">{calls.filter(c => c.status === 'blocked').length}</p>
              <p className="text-[10px] text-muted-foreground">Blocked</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}