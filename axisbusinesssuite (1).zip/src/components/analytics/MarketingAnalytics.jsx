import React from 'react';
import { KpiCard, SectionHeader } from './AnalyticsOverview';
import { Megaphone, Mail, MessageSquare, Heart, Eye, MousePointer, Target } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)', 'hsl(192,83%,48%)'];

const PLATFORM_COLORS = {
  facebook: '#1877F2',
  instagram: '#E1306C',
  linkedin: '#0A66C2',
  twitter: '#1DA1F2',
  tiktok: '#FF0050',
  all: '#94a3b8',
};

export default function MarketingAnalytics({ socialPosts = [], socialCampaigns = [], emailMessages = [], smsMessages = [] }) {
  const totalPosts = socialPosts.length;
  const publishedPosts = socialPosts.filter(p => p.status === 'published').length;
  const totalReach = socialPosts.reduce((s, p) => s + (p.performance_reach || 0), 0);
  const totalLeadsFromSocial = socialPosts.reduce((s, p) => s + (p.performance_leads || 0), 0);

  // Posts by platform
  const platformBreakdown = Object.entries(
    socialPosts.reduce((acc, p) => { acc[p.platform] = (acc[p.platform] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name, value, fill: PLATFORM_COLORS[name] || '#94a3b8' }));

  // Email stats
  const sentEmails = emailMessages.filter(e => e.direction === 'sent').length;
  const receivedEmails = emailMessages.filter(e => e.direction === 'received').length;

  // SMS stats
  const sentSms = smsMessages.filter(s => s.direction === 'sent').length;
  const deliveredSms = smsMessages.filter(s => s.status === 'delivered').length;

  // Campaign stats
  const activeCampaigns = socialCampaigns.filter(c => c.status === 'active').length;
  const totalBudget = socialCampaigns.reduce((s, c) => s + (c.total_budget || 0), 0);
  const spentBudget = socialCampaigns.reduce((s, c) => s + (c.spent_budget || 0), 0);

  // Post performance (top 6 by reach)
  const topPosts = [...socialPosts]
    .filter(p => (p.performance_reach || 0) > 0)
    .sort((a, b) => (b.performance_reach || 0) - (a.performance_reach || 0))
    .slice(0, 6)
    .map(p => ({
      name: (p.title || p.content || '').slice(0, 18) + '…',
      reach: p.performance_reach || 0,
      likes: p.performance_likes || 0,
      clicks: p.performance_clicks || 0,
    }));

  // Post type breakdown
  const postTypeBreakdown = Object.entries(
    socialPosts.reduce((acc, p) => { acc[p.post_type || 'organic'] = (acc[p.post_type || 'organic'] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4">
      <SectionHeader title="Marketing & Communications" subtitle="Social media, email, SMS & campaign analytics" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard title="Social Posts" value={totalPosts} icon={Megaphone} color="purple" subtext={`${publishedPosts} published`} />
        <KpiCard title="Total Reach" value={totalReach >= 1000 ? `${(totalReach / 1000).toFixed(1)}k` : totalReach} icon={Eye} color="blue" subtext={`${totalLeadsFromSocial} leads generated`} />
        <KpiCard title="Emails Sent" value={sentEmails} icon={Mail} color="primary" subtext={`${receivedEmails} received`} />
        <KpiCard title="SMS Sent" value={sentSms} icon={MessageSquare} color="success" subtext={`${deliveredSms} delivered`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Platform distribution */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Posts by Platform</p>
          {platformBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={platformBreakdown} cx="50%" cy="50%" innerRadius={30} outerRadius={58} paddingAngle={3} dataKey="value">
                  {platformBreakdown.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[140px] flex items-center justify-center text-xs text-muted-foreground">No posts yet</div>
          )}
          <div className="flex flex-wrap gap-x-2 gap-y-1 mt-2">
            {platformBreakdown.map(p => (
              <div key={p.name} className="flex items-center gap-1 text-[10px] text-muted-foreground capitalize">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: p.fill }} />
                {p.name} ({p.value})
              </div>
            ))}
          </div>
        </div>

        {/* Top performing posts */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Top Performing Posts (by Reach)</p>
          {topPosts.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={topPosts}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 9 }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Bar dataKey="reach" name="Reach" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="likes" name="Likes" fill="hsl(0,84%,60%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="clicks" name="Clicks" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[160px] flex items-center justify-center text-xs text-muted-foreground">No performance data yet</div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Campaign Budget */}
        <div className="bg-card border border-border rounded-xl p-4 space-y-3">
          <p className="text-sm font-semibold">Campaigns Overview</p>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <p className="text-xl font-bold text-primary">{activeCampaigns}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Active</p>
            </div>
            <div className="bg-muted/50 rounded-lg p-3 text-center">
              <p className="text-xl font-bold">{socialCampaigns.length}</p>
              <p className="text-[10px] text-muted-foreground mt-0.5">Total</p>
            </div>
          </div>
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-muted-foreground">Budget Spent</span>
              <span className="font-semibold">${spentBudget.toFixed(0)} / ${totalBudget.toFixed(0)}</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full"
                style={{ width: `${totalBudget > 0 ? (spentBudget / totalBudget) * 100 : 0}%` }}
              />
            </div>
          </div>
          <div className="pt-2 border-t border-border space-y-1.5">
            {['active', 'paused', 'completed', 'draft'].map((s, i) => (
              <div key={s} className="flex items-center justify-between text-xs">
                <span className="capitalize text-muted-foreground">{s}</span>
                <span className="font-medium">{socialCampaigns.filter(c => c.status === s).length}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Post type breakdown */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Post Types</p>
          {postTypeBreakdown.length > 0 ? (
            <div className="space-y-2.5">
              {postTypeBreakdown.map((t, i) => (
                <div key={t.name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="capitalize text-muted-foreground">{t.name}</span>
                    <span className="font-semibold">{t.value}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${(t.value / totalPosts) * 100}%`, backgroundColor: COLORS[i % COLORS.length] }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[120px] flex items-center justify-center text-xs text-muted-foreground">No posts</div>
          )}
        </div>

        {/* SMS & Email summary */}
        <div className="bg-card border border-border rounded-xl p-4 space-y-3">
          <p className="text-sm font-semibold">Communications Summary</p>
          <div className="space-y-3">
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-blue-500" />Email</span>
              </div>
              <div className="grid grid-cols-3 gap-1 text-center">
                <div><p className="text-sm font-bold">{sentEmails}</p><p className="text-[9px] text-muted-foreground">Sent</p></div>
                <div><p className="text-sm font-bold">{receivedEmails}</p><p className="text-[9px] text-muted-foreground">Received</p></div>
                <div><p className="text-sm font-bold">{emailMessages.filter(e => e.status === 'draft').length}</p><p className="text-[9px] text-muted-foreground">Drafts</p></div>
              </div>
            </div>
            <div className="p-3 bg-muted/50 rounded-lg">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5 text-emerald-500" />SMS</span>
              </div>
              <div className="grid grid-cols-3 gap-1 text-center">
                <div><p className="text-sm font-bold">{sentSms}</p><p className="text-[9px] text-muted-foreground">Sent</p></div>
                <div><p className="text-sm font-bold">{deliveredSms}</p><p className="text-[9px] text-muted-foreground">Delivered</p></div>
                <div><p className="text-sm font-bold">{smsMessages.filter(s => s.direction === 'received').length}</p><p className="text-[9px] text-muted-foreground">Received</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}