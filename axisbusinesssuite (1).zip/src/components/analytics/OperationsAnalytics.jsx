import React from 'react';
import { KpiCard, SectionHeader } from './AnalyticsOverview';
import { Shield, CheckCircle2, AlertTriangle, Clock, DollarSign, FileText, ListChecks, Activity } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';
import { format, subDays } from 'date-fns';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)'];

export default function OperationsAnalytics({ tasks = [], complianceLogs = [], dncEntries = [], payrollRecords = [], performanceReviews = [], timeOffRequests = [] }) {
  const pendingTasks = tasks.filter(t => t.status === 'pending').length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const overdueTasks = tasks.filter(t => t.status === 'pending' && t.due_date && new Date(t.due_date) < new Date()).length;

  const totalDnc = dncEntries.length;
  const complianceCount = complianceLogs.length;

  const totalPayroll = payrollRecords.filter(p => p.status === 'paid').reduce((s, p) => s + (p.net_pay || 0), 0);
  const pendingPayroll = payrollRecords.filter(p => p.status === 'draft').length;

  // Task priority breakdown
  const taskPriority = [
    { name: 'High', value: tasks.filter(t => t.priority === 'high').length, fill: 'hsl(0,84%,60%)' },
    { name: 'Medium', value: tasks.filter(t => t.priority === 'medium').length, fill: 'hsl(43,96%,56%)' },
    { name: 'Low', value: tasks.filter(t => t.priority === 'low').length, fill: 'hsl(162,63%,47%)' },
  ].filter(t => t.value > 0);

  // Task trend (14 days created)
  const taskTrend = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    const ds = format(d, 'yyyy-MM-dd');
    return {
      name: format(d, 'MMM d'),
      created: tasks.filter(t => t.created_date?.startsWith(ds)).length,
      completed: tasks.filter(t => t.updated_date?.startsWith(ds) && t.status === 'completed').length,
    };
  });

  // Compliance event types
  const complianceTypes = Object.entries(
    complianceLogs.reduce((acc, c) => { const t = c.event_type || 'other'; acc[t] = (acc[t] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value })).slice(0, 6);

  // DNC reason breakdown
  const dncReasons = Object.entries(
    dncEntries.reduce((acc, d) => { acc[d.reason || 'other'] = (acc[d.reason || 'other'] || 0) + 1; return acc; }, {})
  ).map(([name, value], i) => ({ name: name.replace(/_/g, ' '), value, fill: COLORS[i % COLORS.length] }));

  // Payroll by status
  const payrollStatus = [
    { name: 'Paid', value: payrollRecords.filter(p => p.status === 'paid').length },
    { name: 'Processed', value: payrollRecords.filter(p => p.status === 'processed').length },
    { name: 'Draft', value: pendingPayroll },
  ].filter(p => p.value > 0);

  // Time-off breakdown
  const timeOffTypes = Object.entries(
    timeOffRequests.reduce((acc, t) => { acc[t.type || 'other'] = (acc[t.type || 'other'] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name, value }));

  // Review ratings
  const reviewRatings = Object.entries(
    performanceReviews.reduce((acc, r) => { acc[r.overall_rating || 'pending'] = (acc[r.overall_rating || 'pending'] || 0) + 1; return acc; }, {})
  ).map(([name, value], i) => ({ name: name.replace(/_/g, ' '), value, fill: COLORS[i % COLORS.length] }));

  return (
    <div className="space-y-4">
      <SectionHeader title="Operations & Compliance Analytics" subtitle="Tasks, compliance, payroll, HR workflows & DNC" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard title="Pending Tasks" value={pendingTasks} icon={ListChecks} color="warning" subtext={`${overdueTasks} overdue`} />
        <KpiCard title="Tasks Completed" value={completedTasks} icon={CheckCircle2} color="success" subtext={`${tasks.length} total`} />
        <KpiCard title="DNC Entries" value={totalDnc} icon={Shield} color="destructive" subtext="blocked numbers" />
        <KpiCard title="YTD Payroll" value={`$${totalPayroll >= 1000 ? (totalPayroll / 1000).toFixed(1) + 'k' : totalPayroll.toFixed(0)}`} icon={DollarSign} color="primary" subtext={`${pendingPayroll} drafts pending`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Task Trend */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Task Activity — Last 14 Days</p>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={taskTrend}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} angle={-30} textAnchor="end" height={40} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ fontSize: '11px' }} />
              <Bar dataKey="created" name="Created" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
              <Bar dataKey="completed" name="Completed" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Task Priority + DNC */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-sm font-semibold mb-3">Task Priority</p>
            {taskPriority.length > 0 ? (
              <ResponsiveContainer width="100%" height={100}>
                <PieChart>
                  <Pie data={taskPriority} cx="50%" cy="50%" innerRadius={25} outerRadius={45} paddingAngle={3} dataKey="value">
                    {taskPriority.map((e, i) => <Cell key={i} fill={e.fill} />)}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: '10px' }} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[100px] flex items-center justify-center text-xs text-muted-foreground">No tasks</div>
            )}
            <div className="flex flex-col gap-1 mt-2">
              {taskPriority.map(t => (
                <div key={t.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: t.fill }} />
                  {t.name} ({t.value})
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-xl p-4">
            <p className="text-sm font-semibold mb-3">DNC Reasons</p>
            {dncReasons.length > 0 ? (
              <div className="space-y-1.5">
                {dncReasons.map(d => (
                  <div key={d.name} className="flex items-center justify-between text-[10px]">
                    <span className="capitalize text-muted-foreground truncate max-w-[80px]">{d.name}</span>
                    <span className="font-semibold">{d.value}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-[80px] flex items-center justify-center text-xs text-muted-foreground">No DNC</div>
            )}
            <div className="mt-3 pt-2 border-t border-border text-center">
              <p className="text-lg font-bold text-red-500">{totalDnc}</p>
              <p className="text-[10px] text-muted-foreground">Total Blocked</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Payroll status */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Payroll Records</p>
          {payrollStatus.length > 0 ? (
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={payrollStatus} cx="50%" cy="50%" innerRadius={30} outerRadius={50} paddingAngle={3} dataKey="value">
                  {payrollStatus.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[130px] flex items-center justify-center text-xs text-muted-foreground">No payroll data</div>
          )}
          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
            {payrollStatus.map((p, i) => (
              <div key={p.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i] }} />{p.name} ({p.value})
              </div>
            ))}
          </div>
        </div>

        {/* Time-off */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Time-Off Requests</p>
          <div className="grid grid-cols-2 gap-2 mb-3">
            {['pending', 'approved', 'denied', 'cancelled'].map((s, i) => (
              <div key={s} className="bg-muted/50 rounded-lg p-2 text-center">
                <p className="text-sm font-bold" style={{ color: COLORS[i] }}>{timeOffRequests.filter(t => t.status === s).length}</p>
                <p className="text-[10px] text-muted-foreground capitalize">{s}</p>
              </div>
            ))}
          </div>
          <div className="space-y-1.5">
            {timeOffTypes.slice(0, 4).map((t, i) => (
              <div key={t.name} className="flex items-center justify-between text-xs">
                <span className="capitalize text-muted-foreground">{t.name}</span>
                <span className="font-medium">{t.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance reviews */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Performance Reviews</p>
          {reviewRatings.length > 0 ? (
            <div className="space-y-2">
              {reviewRatings.map((r, i) => (
                <div key={r.name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="capitalize text-muted-foreground">{r.name}</span>
                    <span className="font-semibold">{r.value}</span>
                  </div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${performanceReviews.length > 0 ? (r.value / performanceReviews.length) * 100 : 0}%`, backgroundColor: r.fill }} />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="h-[100px] flex items-center justify-center text-xs text-muted-foreground">No reviews yet</div>
          )}
          <div className="mt-3 pt-2 border-t border-border grid grid-cols-2 gap-2 text-center">
            <div>
              <p className="text-base font-bold">{performanceReviews.length}</p>
              <p className="text-[10px] text-muted-foreground">Total Reviews</p>
            </div>
            <div>
              <p className="text-base font-bold text-emerald-500">{performanceReviews.filter(r => ['exceptional', 'exceeds_expectations'].includes(r.overall_rating)).length}</p>
              <p className="text-[10px] text-muted-foreground">High Performers</p>
            </div>
          </div>
        </div>
      </div>

      {/* Compliance log summary */}
      {complianceCount > 0 && (
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3 flex items-center gap-2"><Activity className="w-4 h-4 text-primary" />Compliance Events by Type</p>
          {complianceTypes.length > 0 ? (
            <ResponsiveContainer width="100%" height={140}>
              <BarChart data={complianceTypes}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Bar dataKey="value" fill="hsl(262,83%,58%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : null}
        </div>
      )}
    </div>
  );
}