import React from 'react';
import { KpiCard, SectionHeader } from './AnalyticsOverview';
import { Users, UserCheck, UserX, PhoneCall, Target, Zap } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, Legend
} from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)', 'hsl(192,83%,48%)'];

const STATUS_COLORS = {
  new: '#60a5fa',
  contacted: '#a78bfa',
  qualified: '#34d399',
  appointment_set: '#fbbf24',
  not_interested: '#f87171',
  do_not_call: '#ef4444',
  invalid: '#6b7280',
};

export default function LeadsAnalytics({ leads = [], calls = [] }) {
  const totalLeads = leads.length;
  const consented = leads.filter(l => l.consent_given).length;
  const qualified = leads.filter(l => ['qualified', 'appointment_set'].includes(l.status)).length;
  const dnc = leads.filter(l => l.status === 'do_not_call').length;

  const statusBreakdown = Object.entries(
    leads.reduce((acc, l) => { acc[l.status] = (acc[l.status] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value, fill: STATUS_COLORS[name] || '#94a3b8' }));

  const sourceBreakdown = Object.entries(
    leads.reduce((acc, l) => { const s = l.source || 'Unknown'; acc[s] = (acc[s] || 0) + 1; return acc; }, {})
  ).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, value]) => ({ name, value }));

  // 14-day lead intake trend
  const intakeTrend = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    const dateStr = format(d, 'yyyy-MM-dd');
    return {
      name: format(d, 'MMM d'),
      leads: leads.filter(l => l.created_date?.startsWith(dateStr)).length,
    };
  });

  const conversionFunnel = [
    { stage: 'Total Leads', count: totalLeads },
    { stage: 'Consented', count: consented },
    { stage: 'Contacted', count: leads.filter(l => ['contacted', 'qualified', 'appointment_set'].includes(l.status)).length },
    { stage: 'Qualified', count: qualified },
    { stage: 'Appt Set', count: leads.filter(l => l.status === 'appointment_set').length },
  ];

  return (
    <div className="space-y-4">
      <SectionHeader title="Leads Intelligence" subtitle="Full CRM pipeline analytics" />

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <KpiCard title="Total Leads" value={totalLeads} icon={Users} color="primary" subtext={`${consented} consented`} />
        <KpiCard title="Qualified" value={qualified} icon={UserCheck} color="success" subtext={`${totalLeads > 0 ? Math.round((qualified / totalLeads) * 100) : 0}% of total`} />
        <KpiCard title="DNC Blocked" value={dnc} icon={UserX} color="destructive" subtext="do_not_call status" />
        <KpiCard title="Consent Rate" value={`${totalLeads > 0 ? Math.round((consented / totalLeads) * 100) : 0}%`} icon={Zap} color="warning" subtext={`${consented} of ${totalLeads}`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Intake Trend */}
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Lead Intake — Last 14 Days</p>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={intakeTrend}>
              <defs>
                <linearGradient id="lgLeads" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,13%,18%)" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
              <Area type="monotone" dataKey="leads" stroke="hsl(217,91%,60%)" fill="url(#lgLeads)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Status Pie */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Status Breakdown</p>
          {statusBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={130}>
              <PieChart>
                <Pie data={statusBreakdown} cx="50%" cy="50%" innerRadius={30} outerRadius={55} paddingAngle={3} dataKey="value">
                  {statusBreakdown.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                </Pie>
                <Tooltip contentStyle={{ fontSize: '11px' }} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[130px] flex items-center justify-center text-xs text-muted-foreground">No data</div>
          )}
          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
            {statusBreakdown.map((s) => (
              <div key={s.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: s.fill }} />
                <span className="capitalize">{s.name} ({s.value})</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Funnel */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Conversion Funnel</p>
          <div className="space-y-2">
            {conversionFunnel.map((stage, i) => (
              <div key={stage.stage}>
                <div className="flex items-center justify-between text-xs mb-1">
                  <span className="text-muted-foreground">{stage.stage}</span>
                  <span className="font-semibold">{stage.count}</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{
                      width: `${totalLeads > 0 ? (stage.count / totalLeads) * 100 : 0}%`,
                      backgroundColor: COLORS[i % COLORS.length]
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Source Breakdown */}
        <div className="bg-card border border-border rounded-xl p-4">
          <p className="text-sm font-semibold mb-3">Lead Sources</p>
          {sourceBreakdown.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={sourceBreakdown} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10 }} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={80} />
                <Tooltip contentStyle={{ fontSize: '11px' }} />
                <Bar dataKey="value" fill="hsl(262,83%,58%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[160px] flex items-center justify-center text-xs text-muted-foreground">No data</div>
          )}
        </div>
      </div>
    </div>
  );
}