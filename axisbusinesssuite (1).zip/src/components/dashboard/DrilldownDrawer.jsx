import React, { useState } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { base44 } from '@/api/base44Client';
import { format, subDays } from 'date-fns';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell, LineChart, Line
} from 'recharts';
import {
  TrendingUp, TrendingDown, Minus, Brain, Clock, AlertCircle,
  CheckCircle2, Users, Phone, Calendar, Target, ShieldCheck,
  Sparkles, RefreshCw, FileText, Activity, ChevronRight
} from 'lucide-react';
import StatusBadge from '@/components/shared/StatusBadge';

const COLORS = ['hsl(217,91%,60%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(262,83%,58%)', 'hsl(0,84%,60%)'];

function TrendIndicator({ value }) {
  if (value > 0) return <span className="flex items-center gap-0.5 text-emerald-500 text-xs font-medium"><TrendingUp className="w-3 h-3" />+{value}%</span>;
  if (value < 0) return <span className="flex items-center gap-0.5 text-red-500 text-xs font-medium"><TrendingDown className="w-3 h-3" />{value}%</span>;
  return <span className="flex items-center gap-0.5 text-muted-foreground text-xs"><Minus className="w-3 h-3" />0%</span>;
}

function AIInsightPanel({ metric, value, data }) {
  const [insight, setInsight] = useState(null);
  const [loading, setLoading] = useState(false);

  const generateInsight = async () => {
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert business analyst for the AXIS Business Suite.
Analyze this metric and provide actionable intelligence:

Metric: ${metric}
Current Value: ${value}
Context Data: ${JSON.stringify(data).slice(0, 1000)}

Provide:
1. A 2-sentence executive summary of what this metric means right now
2. The top risk or opportunity you see
3. One specific action to take in the next 24 hours
4. A 30-day forecast direction (up/down/stable) with brief reasoning

Be direct, specific, and data-driven. No fluff.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            risk_or_opportunity: { type: 'string' },
            immediate_action: { type: 'string' },
            forecast: { type: 'string' },
            forecast_direction: { type: 'string', enum: ['up', 'down', 'stable'] }
          }
        }
      });
      setInsight(result);
    } catch (e) {
      setInsight({ summary: 'AI analysis unavailable at this time.', risk_or_opportunity: '', immediate_action: '', forecast: '', forecast_direction: 'stable' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary" />
          <span className="text-sm font-semibold text-primary">AI Intelligence</span>
        </div>
        <Button size="sm" variant="outline" onClick={generateInsight} disabled={loading} className="h-7 text-xs gap-1">
          {loading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          {loading ? 'Analyzing...' : insight ? 'Refresh' : 'Generate Analysis'}
        </Button>
      </div>
      {insight && (
        <div className="space-y-3">
          <p className="text-sm text-foreground/90 leading-relaxed">{insight.summary}</p>
          {insight.risk_or_opportunity && (
            <div className="flex gap-2">
              <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">{insight.risk_or_opportunity}</p>
            </div>
          )}
          {insight.immediate_action && (
            <div className="flex gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground"><span className="font-semibold text-foreground">Action: </span>{insight.immediate_action}</p>
            </div>
          )}
          {insight.forecast && (
            <div className="flex items-center gap-2 pt-1 border-t border-border/50">
              <Activity className="w-3.5 h-3.5 text-primary" />
              <p className="text-xs text-muted-foreground"><span className="font-semibold text-foreground">30-day forecast: </span>{insight.forecast}</p>
              {insight.forecast_direction === 'up' && <TrendingUp className="w-3 h-3 text-emerald-500 ml-auto" />}
              {insight.forecast_direction === 'down' && <TrendingDown className="w-3 h-3 text-red-500 ml-auto" />}
              {insight.forecast_direction === 'stable' && <Minus className="w-3 h-3 text-muted-foreground ml-auto" />}
            </div>
          )}
        </div>
      )}
      {!insight && !loading && (
        <p className="text-xs text-muted-foreground">Click "Generate Analysis" for AI-powered intelligence on this metric.</p>
      )}
    </div>
  );
}

// ──────────────────────────────────────────────
// Individual drilldown views per metric type
// ──────────────────────────────────────────────

function LeadsDrilldown({ leads }) {
  const statusBreakdown = leads.reduce((acc, l) => { acc[l.status] = (acc[l.status] || 0) + 1; return acc; }, {});
  const sourceBreakdown = leads.reduce((acc, l) => { const s = l.source || 'Unknown'; acc[s] = (acc[s] || 0) + 1; return acc; }, {});
  const recentLeads = [...leads].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 10);

  const trendData = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    const ds = format(d, 'yyyy-MM-dd');
    return { name: format(d, 'MMM d'), count: leads.filter(l => l.created_date?.startsWith(ds)).length };
  });

  return (
    <div className="space-y-5">
      <AIInsightPanel metric="Total Leads" value={leads.length} data={{ statusBreakdown, total: leads.length, recentCount: recentLeads.length }} />

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">14-Day Lead Intake Trend</h4>
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={trendData}>
            <defs>
              <linearGradient id="gLeads" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
            <Area type="monotone" dataKey="count" name="Leads" stroke="hsl(217,91%,60%)" fill="url(#gLeads)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">By Status</h4>
          <div className="space-y-1.5">
            {Object.entries(statusBreakdown).map(([status, count]) => (
              <div key={status} className="flex items-center justify-between text-xs py-1 border-b border-border/50 last:border-0">
                <span className="capitalize">{status.replace(/_/g, ' ')}</span>
                <Badge variant="outline" className="text-[10px] h-4">{count}</Badge>
              </div>
            ))}
          </div>
        </div>
        <div>
          <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">By Source</h4>
          <div className="space-y-1.5">
            {Object.entries(sourceBreakdown).slice(0, 6).map(([source, count]) => (
              <div key={source} className="flex items-center justify-between text-xs py-1 border-b border-border/50 last:border-0">
                <span className="capitalize truncate max-w-[80px]">{source}</span>
                <Badge variant="outline" className="text-[10px] h-4">{count}</Badge>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Recent Records</h4>
        <div className="space-y-2">
          {recentLeads.map(lead => (
            <div key={lead.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0 gap-2">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{lead.first_name} {lead.last_name}</p>
                <p className="text-xs text-muted-foreground truncate">{lead.company || lead.phone}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <StatusBadge status={lead.status} />
                <span className="text-[10px] text-muted-foreground">{lead.created_date ? format(new Date(lead.created_date), 'MMM d') : ''}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function CallsDrilldown({ calls }) {
  const recentCalls = [...calls].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 10);
  const outcomeBreakdown = calls.reduce((acc, c) => { const o = c.outcome || c.status || 'unknown'; acc[o] = (acc[o] || 0) + 1; return acc; }, {});
  const avgDuration = calls.filter(c => c.duration_seconds > 0).reduce((a, c, _, arr) => a + c.duration_seconds / arr.length, 0);

  const trendData = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    const ds = format(d, 'yyyy-MM-dd');
    const dayCalls = calls.filter(c => c.created_date?.startsWith(ds));
    return {
      name: format(d, 'MMM d'),
      total: dayCalls.length,
      answered: dayCalls.filter(c => c.status === 'completed').length,
      converted: dayCalls.filter(c => c.outcome === 'appointment_set').length,
    };
  });

  return (
    <div className="space-y-5">
      <AIInsightPanel metric="Total Calls" value={calls.length} data={{ outcomeBreakdown, avgDuration: Math.round(avgDuration), total: calls.length }} />

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-lg font-bold">{calls.filter(c => c.status === 'completed').length}</p>
          <p className="text-[10px] text-muted-foreground">Answered</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-lg font-bold">{calls.filter(c => c.outcome === 'appointment_set').length}</p>
          <p className="text-[10px] text-muted-foreground">Converted</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-lg font-bold">{Math.floor(avgDuration / 60)}m {Math.round(avgDuration % 60)}s</p>
          <p className="text-[10px] text-muted-foreground">Avg Duration</p>
        </div>
      </div>

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">14-Day Call Trend</h4>
        <ResponsiveContainer width="100%" height={140}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
            <Line type="monotone" dataKey="total" name="Total" stroke="hsl(217,91%,60%)" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="answered" name="Answered" stroke="hsl(162,63%,47%)" strokeWidth={2} dot={false} />
            <Line type="monotone" dataKey="converted" name="Converted" stroke="hsl(43,96%,56%)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Recent Calls</h4>
        <div className="space-y-2">
          {recentCalls.map(call => (
            <div key={call.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0 gap-2">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{call.lead_name || call.phone_number}</p>
                <p className="text-xs text-muted-foreground">{call.created_date ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                {call.duration_seconds > 0 && <span className="text-[10px] text-muted-foreground">{Math.floor(call.duration_seconds / 60)}m {call.duration_seconds % 60}s</span>}
                <StatusBadge status={call.outcome || call.status} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AppointmentsDrilldown({ appointments }) {
  const upcoming = appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status));
  const statusBreakdown = appointments.reduce((acc, a) => { acc[a.status] = (acc[a.status] || 0) + 1; return acc; }, {});

  const trendData = Array.from({ length: 14 }, (_, i) => {
    const d = subDays(new Date(), 13 - i);
    const ds = format(d, 'yyyy-MM-dd');
    return { name: format(d, 'MMM d'), count: appointments.filter(a => a.created_date?.startsWith(ds)).length };
  });

  return (
    <div className="space-y-5">
      <AIInsightPanel metric="Appointments" value={upcoming.length} data={{ statusBreakdown, upcomingCount: upcoming.length, totalCount: appointments.length }} />

      <div className="grid grid-cols-2 gap-2">
        {Object.entries(statusBreakdown).map(([status, count]) => (
          <div key={status} className="bg-card border border-border rounded-lg p-3">
            <p className="text-lg font-bold">{count}</p>
            <p className="text-[10px] text-muted-foreground capitalize">{status.replace(/_/g, ' ')}</p>
          </div>
        ))}
      </div>

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">14-Day Trend</h4>
        <ResponsiveContainer width="100%" height={120}>
          <BarChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
            <YAxis tick={{ fontSize: 10 }} />
            <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
            <Bar dataKey="count" name="Appointments" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">Upcoming Appointments</h4>
        <div className="space-y-2">
          {upcoming.slice(0, 8).map(apt => (
            <div key={apt.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0 gap-2">
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{apt.lead_name || 'Unknown'}</p>
                <p className="text-xs text-muted-foreground">{apt.scheduled_date ? format(new Date(apt.scheduled_date), 'MMM d, h:mm a') : 'TBD'}</p>
              </div>
              <StatusBadge status={apt.status} />
            </div>
          ))}
          {upcoming.length === 0 && <p className="text-sm text-muted-foreground">No upcoming appointments</p>}
        </div>
      </div>
    </div>
  );
}

function ComplianceDrilldown({ calls }) {
  const compliant = calls.filter(c => c.fcc_compliant);
  const rate = calls.length > 0 ? Math.round((compliant.length / calls.length) * 100) : 100;
  const issues = calls.filter(c => !c.fcc_compliant);

  return (
    <div className="space-y-5">
      <AIInsightPanel metric="FCC Compliance Rate" value={`${rate}%`} data={{ compliant: compliant.length, issues: issues.length, total: calls.length }} />

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 text-center">
          <p className="text-lg font-bold text-emerald-500">{compliant.length}</p>
          <p className="text-[10px] text-muted-foreground">Compliant</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-center">
          <p className="text-lg font-bold text-red-500">{issues.length}</p>
          <p className="text-[10px] text-muted-foreground">Issues</p>
        </div>
        <div className="bg-card border border-border rounded-lg p-3 text-center">
          <p className="text-lg font-bold">{rate}%</p>
          <p className="text-[10px] text-muted-foreground">Rate</p>
        </div>
      </div>

      {issues.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold text-red-400 uppercase mb-2">Compliance Issues</h4>
          <div className="space-y-2">
            {issues.slice(0, 5).map(call => (
              <div key={call.id} className="flex items-center gap-3 p-2 bg-red-500/5 border border-red-500/20 rounded-lg">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium truncate">{call.lead_name || call.phone_number}</p>
                  <p className="text-[10px] text-muted-foreground">{call.created_date ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function TasksDrilldown({ tasks }) {
  const pending = tasks.filter(t => t.status === 'pending');
  const overdue = tasks.filter(t => t.status === 'pending' && t.due_date && new Date(t.due_date) < new Date());
  const statusBreakdown = tasks.reduce((acc, t) => { acc[t.status] = (acc[t.status] || 0) + 1; return acc; }, {});

  return (
    <div className="space-y-5">
      <AIInsightPanel metric="Pending Follow-Up Tasks" value={pending.length} data={{ pending: pending.length, overdue: overdue.length, total: tasks.length }} />

      <div className="grid grid-cols-2 gap-2">
        {Object.entries(statusBreakdown).map(([s, c]) => (
          <div key={s} className="bg-card border border-border rounded-lg p-3">
            <p className="text-lg font-bold">{c}</p>
            <p className="text-[10px] text-muted-foreground capitalize">{s.replace(/_/g, ' ')}</p>
          </div>
        ))}
      </div>

      {overdue.length > 0 && (
        <div>
          <h4 className="text-xs font-semibold text-red-400 uppercase mb-2">Overdue ({overdue.length})</h4>
          <div className="space-y-1.5">
            {overdue.slice(0, 5).map(task => (
              <div key={task.id} className="flex items-center gap-2 p-2 bg-red-500/5 border border-red-500/20 rounded-lg text-xs">
                <Clock className="w-3.5 h-3.5 text-red-500 shrink-0" />
                <span className="truncate">{task.title || task.description}</span>
                <span className="text-muted-foreground ml-auto shrink-0">{task.due_date ? format(new Date(task.due_date), 'MMM d') : ''}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h4 className="text-xs font-semibold text-muted-foreground uppercase mb-2">All Pending</h4>
        <div className="space-y-2">
          {pending.slice(0, 8).map(task => (
            <div key={task.id} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0 gap-2">
              <p className="text-xs truncate flex-1">{task.title || task.description}</p>
              <span className="text-[10px] text-muted-foreground shrink-0">{task.due_date ? format(new Date(task.due_date), 'MMM d') : 'No due date'}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ──────────────────────────────────────────────
// Main Drawer
// ──────────────────────────────────────────────

const DRILLDOWN_CONFIG = {
  leads: {
    title: 'Lead Intelligence',
    icon: Users,
    color: 'text-blue-500',
    bg: 'bg-blue-500/10',
  },
  calls: {
    title: 'Call Intelligence',
    icon: Phone,
    color: 'text-amber-500',
    bg: 'bg-amber-500/10',
  },
  appointments: {
    title: 'Appointment Intelligence',
    icon: Calendar,
    color: 'text-emerald-500',
    bg: 'bg-emerald-500/10',
  },
  compliance: {
    title: 'Compliance Intelligence',
    icon: ShieldCheck,
    color: 'text-red-500',
    bg: 'bg-red-500/10',
  },
  tasks: {
    title: 'Task Intelligence',
    icon: Target,
    color: 'text-purple-500',
    bg: 'bg-purple-500/10',
  },
};

export default function DrilldownDrawer({ open, onClose, type, data }) {
  const config = DRILLDOWN_CONFIG[type] || {};
  const Icon = config.icon || Sparkles;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:max-w-xl p-0 flex flex-col">
        {/* Header */}
        <SheetHeader className="px-5 py-4 border-b border-border bg-card shrink-0">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${config.bg}`}>
              <Icon className={`w-5 h-5 ${config.color}`} />
            </div>
            <div>
              <SheetTitle className="text-base">{config.title}</SheetTitle>
              <p className="text-xs text-muted-foreground">Live data · AI analysis · Full drill-down</p>
            </div>
            <Badge className="ml-auto bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px]">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1.5 inline-block" />
              Live
            </Badge>
          </div>
        </SheetHeader>

        {/* Scrollable content */}
        <ScrollArea className="flex-1">
          <div className="p-5">
            {type === 'leads' && <LeadsDrilldown leads={data?.leads || []} />}
            {type === 'calls' && <CallsDrilldown calls={data?.calls || []} />}
            {type === 'appointments' && <AppointmentsDrilldown appointments={data?.appointments || []} />}
            {type === 'compliance' && <ComplianceDrilldown calls={data?.calls || []} />}
            {type === 'tasks' && <TasksDrilldown tasks={data?.tasks || []} />}
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}