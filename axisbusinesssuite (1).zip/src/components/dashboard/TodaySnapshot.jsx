import React from 'react';
import { Phone, Calendar, PhoneMissed, CheckCircle } from 'lucide-react';
import { format } from 'date-fns';

const SnapshotItem = ({ icon: Icon, label, value, color = 'text-foreground', bg = 'bg-muted/50' }) => (
  <div className={`flex items-center gap-3 p-3 rounded-xl ${bg} border border-border`}>
    <div className="w-9 h-9 rounded-lg bg-background flex items-center justify-center shrink-0">
      <Icon className={`w-4 h-4 ${color}`} />
    </div>
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={`text-xl font-bold ${color}`}>{value}</p>
    </div>
  </div>
);

export default function TodaySnapshot({ calls, leads }) {
  const today = format(new Date(), 'yyyy-MM-dd');
  const todayCalls = calls.filter(c => c.created_date?.startsWith(today));
  const callsToday = todayCalls.length;
  const answeredToday = todayCalls.filter(c => c.status === 'completed').length;
  const apptSetToday = todayCalls.filter(c => c.outcome === 'appointment_set').length;
  const noAnswerToday = todayCalls.filter(c => c.status === 'no_answer').length;

  const newLeads = leads.filter(l => l.status === 'new').length;
  const contacted = leads.filter(l => l.status === 'contacted').length;
  const qualified = leads.filter(l => l.status === 'qualified').length;
  const apptSet = leads.filter(l => l.status === 'appointment_set').length;
  const notInterested = leads.filter(l => l.status === 'not_interested').length;
  const doNotCall = leads.filter(l => l.status === 'do_not_call').length;

  return (
    <div className="bg-card border border-primary/20 rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
        <h3 className="font-semibold text-sm">Today's Snapshot — {format(new Date(), 'EEEE, MMM d')}</h3>
      </div>

      {/* Today's Call Activity */}
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">📞 Calls Today</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <SnapshotItem icon={Phone} label="Total Calls" value={callsToday} color="text-primary" bg="bg-primary/5" />
        <SnapshotItem icon={CheckCircle} label="Answered" value={answeredToday} color="text-emerald-500" bg="bg-emerald-500/5" />
        <SnapshotItem icon={Calendar} label="Appts Set" value={apptSetToday} color="text-blue-500" bg="bg-blue-500/5" />
        <SnapshotItem icon={PhoneMissed} label="No Answer" value={noAnswerToday} color="text-amber-500" bg="bg-amber-500/5" />
      </div>

      {/* Lead Status Breakdown */}
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">👥 Lead Status Breakdown</p>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {[
          { label: 'New', value: newLeads, color: 'text-blue-400' },
          { label: 'Contacted', value: contacted, color: 'text-purple-400' },
          { label: 'Qualified', value: qualified, color: 'text-emerald-400' },
          { label: 'Appt Set', value: apptSet, color: 'text-primary' },
          { label: 'Not Interested', value: notInterested, color: 'text-orange-400' },
          { label: 'DNC', value: doNotCall, color: 'text-red-400' },
        ].map(item => (
          <div key={item.label} className="text-center p-2.5 bg-muted/50 rounded-lg border border-border">
            <p className={`text-2xl font-bold ${item.color}`}>{item.value}</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}