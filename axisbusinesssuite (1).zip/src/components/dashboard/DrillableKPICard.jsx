import React from 'react';
import { TrendingUp, TrendingDown, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

const COLOR_MAP = {
  blue: { bg: 'bg-blue-500/10', icon: 'text-blue-400', border: 'border-blue-500/20', glow: 'hover:shadow-blue-500/10' },
  gold: { bg: 'bg-amber-500/10', icon: 'text-amber-400', border: 'border-amber-500/20', glow: 'hover:shadow-amber-500/10' },
  green: { bg: 'bg-emerald-500/10', icon: 'text-emerald-400', border: 'border-emerald-500/20', glow: 'hover:shadow-emerald-500/10' },
  purple: { bg: 'bg-purple-500/10', icon: 'text-purple-400', border: 'border-purple-500/20', glow: 'hover:shadow-purple-500/10' },
  red: { bg: 'bg-red-500/10', icon: 'text-red-400', border: 'border-red-500/20', glow: 'hover:shadow-red-500/10' },
};

export default function DrillableKPICard({ title, value, icon: Icon, color = 'blue', trend, subtext, onClick, drilldownType }) {
  const c = COLOR_MAP[color] || COLOR_MAP.blue;

  return (
    <button
      onClick={onClick}
      className={cn(
        "relative w-full text-left bg-card border rounded-xl p-3 sm:p-4 transition-all duration-200 group",
        "hover:shadow-lg hover:-translate-y-0.5 cursor-pointer",
        c.border,
        c.glow
      )}
    >
      {/* Drilldown hint */}
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-center gap-0.5 text-[9px] text-muted-foreground bg-muted rounded px-1.5 py-0.5">
          <span>Drill down</span>
          <ChevronRight className="w-2.5 h-2.5" />
        </div>
      </div>

      <div className="flex items-start justify-between gap-2">
        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center shrink-0", c.bg)}>
          <Icon className={cn("w-4 h-4", c.icon)} />
        </div>
        {trend !== undefined && (
          <span className={cn("flex items-center gap-0.5 text-xs font-medium shrink-0", trend >= 0 ? 'text-emerald-500' : 'text-red-500')}>
            {trend >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {Math.abs(trend)}%
          </span>
        )}
      </div>
      <div className="mt-2">
        <p className="text-xl sm:text-2xl font-bold tracking-tight">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5 font-medium">{title}</p>
        {subtext && <p className="text-[10px] text-muted-foreground/70 mt-0.5 truncate">{subtext}</p>}
      </div>
    </button>
  );
}