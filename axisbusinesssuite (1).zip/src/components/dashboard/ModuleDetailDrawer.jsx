import React from 'react';
import { Link } from 'react-router-dom';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  ArrowRight, LayoutDashboard, Users, Phone, Calendar, ShieldCheck,
  Upload, Settings, CreditCard, PhoneOff, Bot, ListTodo, Sparkles,
  GitBranch, Target, GraduationCap, Building2, Route, CalendarDays, FileDown, UserCog,
  MapPin, BarChart3, Video, Briefcase, Mail, MessageCircle, DollarSign,
  Megaphone, HeartHandshake, MessageSquare, Plug, Brain, Globe, FileText, BookOpen, Receipt, Radio
} from 'lucide-react';

const MODULE_DETAILS = {
  dashboard: {
    icon: LayoutDashboard, label: 'Dashboard', path: '/app',
    color: 'text-blue-500', bg: 'bg-blue-500/10',
    description: 'Central command center with real-time KPIs, live call tracking, team performance, and AI business intelligence.',
    dataFlow: ['Live call data ingested in real-time', 'Lead pipeline updated on every status change', 'Appointment counts refreshed as bookings occur', 'Team metrics pulled from SalesRep records'],
    capabilities: ['8 KPI stat cards', 'Area/bar/pie charts', 'Hourly call heatmap', 'Team & AI status panels', 'Analytics suite with 5 sub-tabs'],
  },
  crm_leads: {
    icon: Users, label: 'Lead CRM', path: '/leads',
    color: 'text-blue-600', bg: 'bg-blue-500/10',
    description: 'Full pipeline management: add, import, score, route, and track every prospect through your custom sales funnel.',
    dataFlow: ['Leads created manually, via CSV import, or AI lead gen', 'Status changes trigger nurture workflows automatically', 'Call outcomes write back to lead records', 'Consent flags enforced by compliance engine'],
    capabilities: ['Kanban pipeline view', 'Bulk CSV import', 'Duplicate detection', 'Consent tracking', 'Source attribution'],
  },
  crm_call_logs: {
    icon: Phone, label: 'Call Logs', path: '/call-logs',
    color: 'text-green-600', bg: 'bg-green-500/10',
    description: 'Complete call history with AI summaries, transcripts, outcome tracking, FCC compliance logging, and coaching analysis.',
    dataFlow: ['Every call logged with full metadata', 'AI transcribes and summarizes each call', 'Coaching scores computed per call', 'FCC flags auto-applied based on consent status'],
    capabilities: ['Call recording playback', 'AI summaries', 'Transcript viewer', 'Bulk analysis', 'Coaching scores'],
  },
  crm_appointments: {
    icon: Calendar, label: 'Appointments', path: '/appointments',
    color: 'text-cyan-600', bg: 'bg-cyan-500/10',
    description: 'Schedule, track, and manage all appointments. Syncs with Google Calendar and Calendly for zero double-booking.',
    dataFlow: ['AI call bot books appointments directly during calls', 'Calendly webhooks sync confirmed slots', 'Google Calendar bi-directional sync', 'Reminders sent via email/SMS'],
    capabilities: ['Calendar view', 'Calendly sync', 'Google Calendar sync', 'Status tracking', 'Reminder automation'],
  },
  crm_tasks: {
    icon: ListTodo, label: 'Follow-Up Tasks', path: '/tasks',
    color: 'text-purple-600', bg: 'bg-purple-500/10',
    description: 'Automated and manual follow-up tasks generated from call outcomes, ensuring no lead falls through the cracks.',
    dataFlow: ['Tasks auto-created when call outcome = callback_requested', 'Nurture workflows push tasks on schedule', 'Task completion updates lead status', 'Overdue tasks escalated to manager'],
    capabilities: ['Task queue', 'Priority sorting', 'Due date tracking', 'Auto-creation from calls', 'Assignment to reps'],
  },
  ai_call_bot: {
    icon: Bot, label: 'AI Call Bot', path: '/call-bot',
    color: 'text-red-500', bg: 'bg-red-500/10',
    description: 'Autonomous AI dialer that calls leads, holds real conversations, handles objections, and books appointments — 24/7.',
    dataFlow: ['Pulls active leads from CRM', 'Places calls via configured service (AI/Twilio/Phone)', 'Transcribes conversation in real-time', 'Writes outcome + transcript back to CallLog', 'Triggers follow-up tasks on hang-up'],
    capabilities: ['Human-like AI voice', 'Objection handling', 'Live appointment booking', 'Consent verification', 'DNC auto-check'],
  },
  lead_generator: {
    icon: MapPin, label: 'AI Lead Generator', path: '/lead-generator',
    color: 'text-orange-600', bg: 'bg-orange-500/10',
    description: 'AI-powered B2B prospect discovery using Google Maps, web scraping, and intent signals to build targeted lead lists.',
    dataFlow: ['User defines industry + location', 'AI searches Google Maps & web sources', 'Prospects scraped with contact info', 'Leads imported directly into CRM pipeline'],
    capabilities: ['Industry + location targeting', 'Google Maps integration', 'Auto-import to CRM', 'Duplicate prevention', 'Source tagging'],
  },
  lead_scoring: {
    icon: Target, label: 'Lead Scoring', path: '/lead-scoring',
    color: 'text-violet-600', bg: 'bg-violet-500/10',
    description: 'ML-powered scoring engine that ranks leads by conversion probability based on engagement, fit, and behavioral signals.',
    dataFlow: ['Analyzes call history, engagement events, and demographics', 'Assigns score 1-100 to each lead', 'Updates score on every new interaction', 'Auto-routes high-score leads to top reps'],
    capabilities: ['AI scoring 0-100', 'Score decay over time', 'Auto-routing integration', 'Score history', 'Tier classification'],
  },
  nurture_workflows: {
    icon: GitBranch, label: 'Nurture Workflows', path: '/nurture',
    color: 'text-emerald-600', bg: 'bg-emerald-500/10',
    description: 'Multi-step automated sequences that follow up via AI calls, emails, and tasks until leads convert or opt-out.',
    dataFlow: ['Workflow triggered by lead status change or manual enrollment', 'Executes steps: call → wait → email → task', 'Tracks open/click/response events', 'Exits lead on conversion or opt-out signal'],
    capabilities: ['Multi-channel steps', 'Conditional branching', 'Exit conditions', 'A/B testing', 'Conversion tracking'],
  },
  coaching_hub: {
    icon: GraduationCap, label: 'Coaching Hub', path: '/coaching',
    color: 'text-amber-600', bg: 'bg-amber-500/10',
    description: 'AI analyzes every call, grades rep performance, identifies patterns, and evolves your winning scripts automatically.',
    dataFlow: ['Call transcript pulled from CallLog', 'AI grades 5 coaching dimensions', 'Score stored on CallLog record', 'Coaching summary pushed to rep profile', 'Script evolution updated with winning phrases'],
    capabilities: ['AI call grading', 'Rep performance trends', 'Objection pattern analysis', 'Script evolution', 'Personalized coaching plans'],
  },
  sales_team: {
    icon: BarChart3, label: 'Sales Team', path: '/sales-team',
    color: 'text-teal-600', bg: 'bg-teal-500/10',
    description: 'Team management with quota tracking, leaderboards, rep performance dashboards, and territory management.',
    dataFlow: ['SalesRep records linked to calls, appointments, leads', 'Daily KPIs computed per rep', 'Quota progress updated in real-time', 'Manager view shows team roll-up metrics'],
    capabilities: ['Rep leaderboard', 'Quota tracking', 'Territory assignment', 'Performance trends', 'Manager override'],
  },
  marketing_social: {
    icon: Megaphone, label: 'Social Media AI', path: '/social-media',
    color: 'text-pink-600', bg: 'bg-pink-500/10',
    description: 'AI generates platform-optimized social posts, manages campaigns, schedules content, and tracks engagement.',
    dataFlow: ['User defines campaign objective & audience', 'AI generates captions, images, hashtags', 'Posts scheduled across platforms', 'Engagement data pulled back via API', 'Lead data linked from ad clicks'],
    capabilities: ['Multi-platform posting', 'AI content generation', 'Campaign management', 'Ad budget tracking', 'Engagement analytics'],
  },
  recruitment: {
    icon: Briefcase, label: 'Recruitment ATS', path: '/recruitment',
    color: 'text-violet-600', bg: 'bg-violet-500/10',
    description: 'Full applicant tracking system with Indeed sourcing, AI candidate scoring, Zoom interviews, and onboarding workflows.',
    dataFlow: ['AI searches Indeed for matching candidates', 'Resume parsed and scored by AI', 'Interview scheduled via Zoom auto-link', 'Offer sent via email from platform', 'Hired candidate creates Employee record'],
    capabilities: ['Indeed AI sourcing', 'Resume parsing', 'AI candidate scoring', 'Zoom interview scheduling', 'Offer letter automation'],
  },
  hr_suite: {
    icon: HeartHandshake, label: 'HR Suite', path: '/hr',
    color: 'text-rose-600', bg: 'bg-rose-500/10',
    description: 'Complete HRIS with employee records, time-off management, payroll tracking, performance reviews, and document storage.',
    dataFlow: ['Employee record created on hire', 'Time-off requests routed to manager', 'Payroll cycles tracked with approval', 'Performance reviews scheduled quarterly', 'Documents stored and e-signed in platform'],
    capabilities: ['Employee directory', 'Time-off management', 'Payroll tracking', 'Performance reviews', 'Document management'],
  },
  comm_email: {
    icon: Mail, label: 'Email Client', path: '/email',
    color: 'text-blue-500', bg: 'bg-blue-500/10',
    description: 'Full email client with AI-drafted outreach, threading, templates, and direct CRM lead linking.',
    dataFlow: ['Compose emails linked to Lead records', 'AI drafts personalized outreach', 'Sent emails logged as engagement events', 'Replies trigger follow-up task creation', 'Open/click tracking updates lead score'],
    capabilities: ['AI email drafting', 'Threading', 'Template library', 'CRM linking', 'Open/click tracking'],
  },
  comm_sms: {
    icon: MessageSquare, label: 'SMS Inbox', path: '/sms',
    color: 'text-green-500', bg: 'bg-green-500/10',
    description: 'Two-way SMS messaging via Twilio with contact linking, conversation threading, and automated responses.',
    dataFlow: ['Outbound SMS sent via Twilio API', 'Inbound replies delivered to inbox', 'Messages linked to Lead/Contact records', 'Opt-out responses auto-add to DNC', 'SMS engagement updates lead score'],
    capabilities: ['Two-way messaging', 'Twilio integration', 'Contact linking', 'Auto opt-out handling', 'Bulk messaging'],
  },
  compliance_dnc: {
    icon: PhoneOff, label: 'DNC Registry', path: '/dnc',
    color: 'text-red-600', bg: 'bg-red-500/10',
    description: 'National and internal DNC registry management with automatic blocking before every call.',
    dataFlow: ['DNC check run before each AI call', 'Internal DNC list maintained in real-time', 'National DNC verified via compliance engine', 'Blocked calls logged with reason', 'Opt-out requests auto-added instantly'],
    capabilities: ['National DNC sync', 'Internal DNC list', 'Auto-block before calls', 'Opt-out automation', 'Compliance audit trail'],
  },
  compliance: {
    icon: ShieldCheck, label: 'Compliance Engine', path: '/compliance',
    color: 'text-orange-600', bg: 'bg-orange-500/10',
    description: 'TCPA/FCC compliance monitoring with consent tracking, call disclosure verification, and audit-ready reporting.',
    dataFlow: ['Consent status checked on every lead before contact', 'Call disclosures verified at call start', 'Compliance events logged to ComplianceLog', 'FCC flag set on CallLog records', 'Audit export generated on demand'],
    capabilities: ['Consent tracking', 'TCPA compliance', 'FCC compliance', 'Audit logs', 'Legal export'],
  },
  finance_ops: {
    icon: Receipt, label: 'Financial Ops', path: '/financial-ops',
    color: 'text-emerald-600', bg: 'bg-emerald-500/10',
    description: 'Invoice management, expense tracking, contractor payroll, and financial reporting for operations teams.',
    dataFlow: ['Invoices created from Order records', 'Expenses logged with receipt uploads', 'Contractor payroll linked to timesheet records', 'P&L report computed from income/expense data'],
    capabilities: ['Invoice management', 'Expense tracking', 'Contractor payroll', 'Financial reporting', 'Receipt storage'],
  },
  academy: {
    icon: GraduationCap, label: 'Academy', path: '/academy',
    color: 'text-blue-600', bg: 'bg-blue-500/10',
    description: 'AI-powered training hub generating custom sales scripts, onboarding content, and performance coaching videos.',
    dataFlow: ['Industry config used to generate training content', 'AI produces custom sales scripts', 'Training videos created for each module', 'Rep progress tracked through courses', 'Coaching recommendations integrated from call data'],
    capabilities: ['AI-generated training', 'Custom sales scripts', 'Video content', 'Progress tracking', 'Industry-specific curriculum'],
  },
  zoom_scheduler: {
    icon: Video, label: 'Zoom Scheduler', path: '/zoom-scheduler',
    color: 'text-blue-400', bg: 'bg-blue-400/10',
    description: 'Automated Zoom meeting creation with join links, calendar invites, and recruitment interview management.',
    dataFlow: ['Meeting created via Zoom API', 'Join link emailed to candidate/prospect', 'Calendar invite sent to host', 'Meeting status tracked in platform', 'Recording linked back to Interview record'],
    capabilities: ['Auto Zoom link generation', 'Email invitations', 'Interview scheduling', 'Recording management', 'Calendar sync'],
  },
};

export default function ModuleDetailDrawer({ moduleId, open, onClose }) {
  const detail = MODULE_DETAILS[moduleId];
  if (!detail) return null;

  const Icon = detail.icon;

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className={`w-12 h-12 rounded-xl ${detail.bg} flex items-center justify-center`}>
              <Icon className={`w-6 h-6 ${detail.color}`} />
            </div>
            <div>
              <SheetTitle className="text-xl">{detail.label}</SheetTitle>
              <Badge variant="outline" className="text-xs mt-1">Module Detail</Badge>
            </div>
          </div>
          <SheetDescription className="text-sm leading-relaxed text-foreground/80 mt-2">
            {detail.description}
          </SheetDescription>
        </SheetHeader>

        {/* Data Flow */}
        <div className="mb-6">
          <h3 className="text-sm font-bold mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-primary inline-block" />
            Data Flow
          </h3>
          <ol className="space-y-2">
            {detail.dataFlow.map((step, i) => (
              <li key={i} className="flex items-start gap-3 text-sm">
                <span className="w-5 h-5 rounded-full bg-primary/10 text-primary text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">{i + 1}</span>
                <span className="text-muted-foreground">{step}</span>
              </li>
            ))}
          </ol>
        </div>

        {/* Capabilities */}
        <div className="mb-8">
          <h3 className="text-sm font-bold mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            Key Capabilities
          </h3>
          <div className="flex flex-wrap gap-2">
            {detail.capabilities.map((cap, i) => (
              <Badge key={i} variant="outline" className="text-xs bg-card">
                {cap}
              </Badge>
            ))}
          </div>
        </div>

        <Button asChild className="w-full gap-2">
          <Link to={detail.path} onClick={onClose}>
            Open {detail.label} <ArrowRight className="w-4 h-4" />
          </Link>
        </Button>
      </SheetContent>
    </Sheet>
  );
}