import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Phone, CheckCircle2, Clock } from 'lucide-react';
import { format, subDays, startOfDay } from 'date-fns';

export default function CallPerformance() {
  const { data: callLogs = [] } = useQuery({
    queryKey: ['callLogs'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });

  const getLast7Days = () => {
    const data = {};
    for (let i = 6; i >= 0; i--) {
      const date = startOfDay(subDays(new Date(), i));
      const key = format(date, 'MMM dd');
      data[key] = { date: key, calls: 0, appointments: 0, answered: 0 };
    }
    return data;
  };

  const dailyStats = getLast7Days();
  callLogs.forEach(log => {
    if (log.created_date) {
      const date = startOfDay(new Date(log.created_date));
      const key = format(date, 'MMM dd');
      if (dailyStats[key]) {
        dailyStats[key].calls += 1;
        if (log.status === 'completed') dailyStats[key].answered += 1;
        if (log.outcome === 'appointment_set') dailyStats[key].appointments += 1;
      }
    }
  });

  const chartData = Object.values(dailyStats);

  const totalCalls = callLogs.length;
  const completedCalls = callLogs.filter(c => c.status === 'completed').length;
  const appointmentsSet = callLogs.filter(c => c.outcome === 'appointment_set').length;
  const avgDuration = callLogs.length > 0 
    ? Math.round(callLogs.reduce((sum, c) => sum + (c.duration_seconds || 0), 0) / callLogs.length)
    : 0;

  const answerRate = totalCalls > 0 ? Math.round((completedCalls / totalCalls) * 100) : 0;
  const appointmentRate = completedCalls > 0 ? Math.round((appointmentsSet / completedCalls) * 100) : 0;

  const outcomeData = [
    { name: 'Appointment Set', value: appointmentsSet, color: '#10b981' },
    { name: 'Not Interested', value: callLogs.filter(c => c.outcome === 'not_interested').length, color: '#ef4444' },
    { name: 'Callback', value: callLogs.filter(c => c.outcome === 'callback_requested').length, color: '#f59e0b' },
    { name: 'Other', value: callLogs.filter(c => !['appointment_set', 'not_interested', 'callback_requested'].includes(c.outcome)).length, color: '#6b7280' },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Calls</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalCalls}</div>
            <p className="text-xs text-muted-foreground mt-1">Last 7 days</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Answer Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{answerRate}%</div>
            <p className="text-xs text-muted-foreground mt-1">{completedCalls} answered</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Appointments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{appointmentsSet}</div>
            <p className="text-xs text-muted-foreground mt-1">{appointmentRate}% conversion</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Avg Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{Math.floor(avgDuration / 60)}</div>
            <p className="text-xs text-muted-foreground mt-1">minutes</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Call Activity (7 Days)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calls" stroke="#3b82f6" name="Total Calls" />
              <Line type="monotone" dataKey="answered" stroke="#10b981" name="Answered" />
              <Line type="monotone" dataKey="appointments" stroke="#f59e0b" name="Appointments" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Call Outcomes</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={outcomeData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                  {outcomeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { label: 'Completed', value: completedCalls, icon: CheckCircle2, color: 'text-emerald-600' },
              { label: 'No Answer', value: callLogs.filter(c => c.status === 'no_answer').length, icon: Clock, color: 'text-amber-600' },
              { label: 'Failed', value: callLogs.filter(c => c.status === 'failed').length, icon: Phone, color: 'text-red-600' },
            ].map(stat => (
              <div key={stat.label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <stat.icon className={`w-4 h-4 ${stat.color}`} />
                  <span className="text-sm font-medium">{stat.label}</span>
                </div>
                <Badge variant="outline">{stat.value}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}