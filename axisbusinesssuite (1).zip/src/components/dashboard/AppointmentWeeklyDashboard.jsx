import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Line, ComposedChart } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, TrendingUp, Calendar, CheckCircle2, BarChart3, Users } from 'lucide-react';
import { format, startOfWeek, isWithinInterval, subWeeks } from 'date-fns';

export default function AppointmentWeeklyDashboard({ appointments = [], targetRate = 50 }) {
  const weeklyData = useMemo(() => {
    return Array.from({ length: 8 }, (_, i) => {
      const weekStart = startOfWeek(subWeeks(new Date(), 7 - i), { weekStartsOn: 1 });
      const weekEnd = new Date(weekStart.getTime() + 6 * 86400000 + 86399999);

      const inWeek = appointments.filter(a => {
        if (!a.scheduled_date) return false;
        const d = new Date(a.scheduled_date);
        return isWithinInterval(d, { start: weekStart, end: weekEnd });
      });

      const set = inWeek.length;
      const completed = inWeek.filter(a => a.status === 'completed').length;
      const closeRate = set > 0 ? Math.round((completed / set) * 100) : 0;

      return {
        week: format(weekStart, 'MMM d'),
        set,
        completed,
        closeRate,
      };
    });
  }, [appointments]);

  const totalSet = weeklyData.reduce((s, w) => s + w.set, 0);
  const totalCompleted = weeklyData.reduce((s, w) => s + w.completed, 0);
  const overallCloseRate = totalSet > 0 ? Math.round((totalCompleted / totalSet) * 100) : 0;
  const thisWeek = weeklyData[weeklyData.length - 1];
  const hittingTarget = thisWeek && thisWeek.closeRate >= targetRate;

  // Team breakdown by assigned_to
  const teamBreakdown = useMemo(() => {
    const map = {};
    appointments.forEach(a => {
      const person = a.assigned_to || a.owner || 'Unassigned';
      if (!map[person]) map[person] = { name: person, set: 0, completed: 0 };
      map[person].set++;
      if (a.status === 'completed') map[person].completed++;
    });
    return Object.values(map).map(t => ({
      ...t,
      rate: t.set > 0 ? Math.round((t.completed / t.set) * 100) : 0,
    })).sort((a, b) => b.set - a.set).slice(0, 6);
  }, [appointments]);

  return (
    <div className="space-y-4">
      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-xl border border-primary/20 bg-gradient-to-br from-primary/10 to-primary/5 p-4">
          <div className="flex items-center gap-2 mb-1">
            <Calendar className="w-4 h-4 text-primary" />
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">This Week Set</p>
          </div>
          <p className="text-2xl font-bold text-primary">{thisWeek?.set || 0}</p>
        </div>
        <div className="rounded-xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 p-4">
          <div className="flex items-center gap-2 mb-1">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">This Week Completed</p>
          </div>
          <p className="text-2xl font-bold text-emerald-500">{thisWeek?.completed || 0}</p>
        </div>
        <div className="rounded-xl border border-blue-500/20 bg-gradient-to-br from-blue-500/10 to-blue-500/5 p-4">
          <div className="flex items-center gap-2 mb-1">
            <Target className="w-4 h-4 text-blue-500" />
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Close Rate (8wk)</p>
          </div>
          <p className="text-2xl font-bold text-blue-500">{overallCloseRate}%</p>
        </div>
        <div className={`rounded-xl border p-4 ${hittingTarget ? 'border-emerald-500/20 bg-gradient-to-br from-emerald-500/10 to-emerald-500/5' : 'border-amber-500/20 bg-gradient-to-br from-amber-500/10 to-amber-500/5'}`}>
          <div className="flex items-center gap-2 mb-1">
            <TrendingUp className={`w-4 h-4 ${hittingTarget ? 'text-emerald-500' : 'text-amber-500'}`} />
            <p className="text-[10px] text-muted-foreground uppercase tracking-wide">vs Target ({targetRate}%)</p>
          </div>
          <p className={`text-lg font-bold ${hittingTarget ? 'text-emerald-500' : 'text-amber-500'}`}>
            {hittingTarget ? '✓ On Track' : 'Below Target'}
          </p>
        </div>
      </div>

      {/* Weekly Chart */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-primary" />
            Appointments: Set vs Completed (Last 8 Weeks)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={280}>
            <ComposedChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="week" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px', background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }} />
              <Legend wrapperStyle={{ fontSize: '11px' }} />
              <Bar dataKey="set" name="Set" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} opacity={0.5} />
              <Bar dataKey="completed" name="Completed" fill="hsl(162,63%,47%)" radius={[4, 4, 0, 0]} />
              <Line dataKey="closeRate" name="Close Rate %" stroke="hsl(217,91%,60%)" strokeWidth={2} dot={{ r: 3 }} />
            </ComposedChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Team Breakdown */}
      {teamBreakdown.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              Team Close Rate Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {teamBreakdown.map((t) => (
                <div key={t.name} className="flex items-center gap-3">
                  <div className="w-28 sm:w-48 truncate text-sm font-medium">{t.name}</div>
                  <div className="flex-1 grid grid-cols-3 gap-2 text-xs">
                    <span className="text-muted-foreground">{t.set} set</span>
                    <span className="text-emerald-500">{t.completed} done</span>
                    <span className={t.rate >= targetRate ? 'text-emerald-500 font-semibold' : 'text-amber-500 font-semibold'}>{t.rate}%</span>
                  </div>
                  <div className="hidden sm:block w-24 h-2 bg-muted rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${t.rate >= targetRate ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${t.rate}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}