import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Trophy, TrendingUp, TrendingDown, Minus, Users, ClipboardList } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

function avg(nums) {
  const n = nums.filter((x) => x > 0);
  if (!n.length) return 0;
  return Math.round(n.reduce((a, b) => a + b, 0) / n.length);
}

export default function AgentPerformanceReport() {
  const { data: calls = [], isLoading } = useQuery({
    queryKey: ['coaching-calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });
  const { data: sessions = [] } = useQuery({
    queryKey: ['coaching-sessions'],
    queryFn: () => base44.entities.CoachingSession.list('-created_date'),
  });

  const reports = useMemo(() => {
    const byAgent = {};
    for (const c of calls) {
      const k = (c.called_by && c.called_by.trim()) || 'AI Bot';
      (byAgent[k] = byAgent[k] || []).push(c);
    }
    const sessByAgent = {};
    for (const s of sessions) {
      const k = (s.agent_name && s.agent_name.trim()) || 'AI Bot';
      (sessByAgent[k] = sessByAgent[k] || []).push(s);
    }
    const keys = new Set([...Object.keys(byAgent), ...Object.keys(sessByAgent)]);
    return [...keys].map((k) => {
      const c = byAgent[k] || [];
      const s = sessByAgent[k] || [];
      const scores = [
        ...c.filter((x) => x.coaching_analyzed && x.coaching_score > 0).map((x) => x.coaching_score),
        ...s.map((x) => x.overall_score || 0),
      ];
      const avgScore = avg(scores);
      const analyzed = c.filter((x) => x.coaching_analyzed).length;
      const appt = c.filter((x) => x.outcome === 'appointment_set').length;
      const apptRate = c.length ? Math.round((appt / c.length) * 100) : 0;
      const sorted = c
        .filter((x) => x.coaching_analyzed && x.coaching_score > 0)
        .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
      let trend = 'stable';
      if (sorted.length >= 4) {
        const mid = Math.floor(sorted.length / 2);
        const older = avg(sorted.slice(0, mid).map((x) => x.coaching_score));
        const newer = avg(sorted.slice(mid).map((x) => x.coaching_score));
        if (newer - older > 3) trend = 'improving';
        else if (older - newer > 3) trend = 'declining';
      }
      return { key: k, name: k, avgScore, analyzed, callsCount: c.length, apptRate, trend };
    }).sort((a, b) => b.avgScore - a.avgScore);
  }, [calls, sessions]);

  const overallAvg = reports.length ? Math.round(reports.reduce((a, r) => a + r.avgScore, 0) / reports.length) : 0;
  const improving = reports.filter((r) => r.trend === 'improving').length;

  const overallSeries = useMemo(() => {
    const all = calls
      .filter((c) => c.coaching_analyzed && c.coaching_score > 0)
      .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    const byDay = {};
    for (const c of all) {
      const key = new Date(c.created_date).toISOString().slice(0, 10);
      (byDay[key] = byDay[key] || []).push(c.coaching_score);
    }
    return Object.entries(byDay).slice(-14).map(([day, scores]) => ({ name: day.slice(5), score: avg(scores) }));
  }, [calls]);

  if (isLoading) {
    return (
      <Card><CardContent className="p-6 flex items-center justify-center">
        <Loader2 className="w-5 h-5 text-primary animate-spin" />
      </CardContent></Card>
    );
  }

  const trendColor = (t) => (t === 'improving' ? 'text-emerald-500' : t === 'declining' ? 'text-red-500' : 'text-muted-foreground');
  const TrendIcon = (t) => (t === 'improving' ? TrendingUp : t === 'declining' ? TrendingDown : Minus);

  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold flex items-center gap-2">
          <ClipboardList className="w-4 h-4 text-primary" /> Agent Performance Report
          <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px] ml-auto">Coaching Engine</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Agents</p>
            <p className="text-lg font-bold flex items-center gap-1"><Users className="w-3.5 h-3.5" />{reports.length}</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Avg Score</p>
            <p className="text-lg font-bold flex items-center gap-1"><Trophy className="w-3.5 h-3.5 text-amber-500" />{overallAvg}/100</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Improving</p>
            <p className="text-lg font-bold text-emerald-500 flex items-center gap-1"><TrendingUp className="w-3.5 h-3.5" />{improving}</p>
          </div>
        </div>

        {overallSeries.length >= 2 && (
          <div>
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5">Coaching Score Trend (last 14 days)</p>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={overallSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 2 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="space-y-2">
          {reports.length === 0 && (
            <p className="text-sm text-muted-foreground">No coaching data yet. Analyze calls in the Coaching Hub to populate this report.</p>
          )}
          {reports.map((r) => {
            const Icon = TrendIcon(r.trend);
            return (
              <div key={r.key} className="flex items-center justify-between gap-2 p-2.5 rounded-lg bg-muted/20 border border-border">
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">{r.name}</p>
                  <p className="text-[10px] text-muted-foreground">{r.analyzed} analyzed · {r.callsCount} calls · {r.apptRate}% appt</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-sm font-bold">{r.avgScore}</span>
                  <span className={`flex items-center gap-1 text-xs font-medium capitalize ${trendColor(r.trend)}`}>
                    <Icon className="w-3.5 h-3.5" />{r.trend}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}