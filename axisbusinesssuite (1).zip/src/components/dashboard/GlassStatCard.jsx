import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

const colorMap = {
  gold: {
    bg: 'from-amber-500/10 to-amber-600/5',
    border: 'border-amber-500/20',
    icon: 'bg-amber-500/20 text-amber-400',
    value: 'text-amber-400',
    glow: 'shadow-amber-500/10',
  },
  blue: {
    bg: 'from-blue-500/10 to-blue-600/5',
    border: 'border-blue-500/20',
    icon: 'bg-blue-500/20 text-blue-400',
    value: 'text-blue-400',
    glow: 'shadow-blue-500/10',
  },
  green: {
    bg: 'from-emerald-500/10 to-emerald-600/5',
    border: 'border-emerald-500/20',
    icon: 'bg-emerald-500/20 text-emerald-400',
    value: 'text-emerald-400',
    glow: 'shadow-emerald-500/10',
  },
  purple: {
    bg: 'from-purple-500/10 to-purple-600/5',
    border: 'border-purple-500/20',
    icon: 'bg-purple-500/20 text-purple-400',
    value: 'text-purple-400',
    glow: 'shadow-purple-500/10',
  },
  red: {
    bg: 'from-red-500/10 to-red-600/5',
    border: 'border-red-500/20',
    icon: 'bg-red-500/20 text-red-400',
    value: 'text-red-400',
    glow: 'shadow-red-500/10',
  },
};

export default function GlassStatCard({ title, value, icon: Icon, color = 'blue', trend, subtext, pulse }) {
  const c = colorMap[color] || colorMap.blue;

  return (
    <div className={cn(
      'relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 shadow-lg transition-all hover:shadow-xl hover:-translate-y-0.5',
      c.bg, c.border, c.glow
    )}>
      {/* Background glow orb */}
      <div className={cn('absolute -top-4 -right-4 w-16 h-16 rounded-full blur-2xl opacity-40', c.icon.split(' ')[0])} />

      <div className="relative flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{title}</p>
          <div className="flex items-end gap-2">
            <p className={cn('text-2xl font-bold leading-none', c.value)}>{value}</p>
            {trend !== undefined && (
              <div className={cn('flex items-center gap-0.5 text-[10px] font-semibold mb-0.5', trend >= 0 ? 'text-emerald-400' : 'text-red-400')}>
                {trend >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {Math.abs(trend)}%
              </div>
            )}
          </div>
          {subtext && <p className="text-[10px] text-muted-foreground mt-1">{subtext}</p>}
        </div>
        <div className={cn('w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0', c.icon)}>
          <Icon className="w-4 h-4" />
          {pulse && <span className="absolute top-0 right-0 w-2 h-2 bg-emerald-500 rounded-full animate-ping" />}
        </div>
      </div>
    </div>
  );
}