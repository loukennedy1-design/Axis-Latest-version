import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Phone, Calendar, Users, TrendingUp, ArrowRight, Target } from 'lucide-react';
import { format } from 'date-fns';

export default function TeamTracker() {
  const { data: reps = [] } = useQuery({ queryKey: ['sales-reps'], queryFn: () => base44.entities.SalesRep.list('-created_date') });
  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 500) });
  const { data: appointments = [] } = useQuery({ queryKey: ['appointments'], queryFn: () => base44.entities.Appointment.list() });
  const { data: leads = [] } = useQuery({ queryKey: ['leads'], queryFn: () => base44.entities.Lead.list('-created_date', 200) });

  if (reps.length === 0) return null;

  const today = format(new Date(), 'yyyy-MM-dd');
  const activeReps = reps.filter(r => r.status === 'active');
  const totalTeamCallsToday = calls.filter(c => c.created_date?.startsWith(today)).length;
  const totalTeamAppts = appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length;
  const totalTeamLeads = leads.length;

  return (
    <div className="bg-card border border-border rounded-xl p-5">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            Full Team Tracking
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">{activeReps.length} active reps · {reps.length} total</p>
        </div>
        <Link to="/sales-team">
          <Button variant="outline" size="sm" className="text-xs gap-1 h-7">
            Sales Hub <ArrowRight className="w-3 h-3" />
          </Button>
        </Link>
      </div>

      {/* Team Totals */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg text-center">
          <p className="text-2xl font-bold text-primary">{totalTeamCallsToday}</p>
          <p className="text-[10px] text-muted-foreground">Calls Today</p>
        </div>
        <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg text-center">
          <p className="text-2xl font-bold text-emerald-500">{totalTeamAppts}</p>
          <p className="text-[10px] text-muted-foreground">Open Appts</p>
        </div>
        <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg text-center">
          <p className="text-2xl font-bold text-blue-500">{totalTeamLeads}</p>
          <p className="text-[10px] text-muted-foreground">Total Leads</p>
        </div>
      </div>

      {/* Rep Rows */}
      <div className="space-y-2">
        {reps.map(rep => {
          const repCallsAll = calls.filter(c => c.called_by === rep.name || c.owner === rep.email);
          const repCallsToday = repCallsAll.filter(c => c.created_date?.startsWith(today)).length;
          const repAppts = appointments.filter(a => a.assigned_to === rep.email && ['scheduled', 'confirmed'].includes(a.status)).length;
          const repLeads = leads.filter(l => l.assigned_to === rep.email).length;
          const dailyTarget = rep.target_calls_per_day || 50;
          const todayPct = Math.min(100, Math.round((repCallsToday / dailyTarget) * 100));
          const steps = rep.onboarding_steps ? (() => { try { return JSON.parse(rep.onboarding_steps); } catch { return {}; } })() : {};
          const completedSteps = Object.values(steps).filter(Boolean).length;
          const certified = steps.first_sale;

          const isActive = rep.status === 'active';

          return (
            <div key={rep.id} className="flex items-center gap-3 p-3 bg-muted/30 border border-border rounded-lg hover:bg-muted/50 transition-colors">
              {/* Avatar */}
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 ${isActive ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                {rep.name?.charAt(0)?.toUpperCase()}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm font-semibold truncate">{rep.name}</p>
                  {certified ? (
                    <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[9px] shrink-0">✅ Certified</Badge>
                  ) : isActive ? (
                    <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/30 text-[9px] shrink-0">🔄 {completedSteps}/8 steps</Badge>
                  ) : (
                    <Badge className="bg-muted text-muted-foreground text-[9px] shrink-0">{rep.status}</Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-0.5"><Phone className="w-2.5 h-2.5" />{repCallsToday} today / {repCallsAll.length} total</span>
                  <span className="flex items-center gap-0.5"><Calendar className="w-2.5 h-2.5" />{repAppts} appts</span>
                  <span className="flex items-center gap-0.5"><Users className="w-2.5 h-2.5" />{repLeads} leads</span>
                </div>
              </div>

              {/* Daily Progress */}
              <div className="w-20 shrink-0 hidden sm:block">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[9px] text-muted-foreground">Daily</span>
                  <span className="text-[9px] font-semibold">{todayPct}%</span>
                </div>
                <Progress value={todayPct} className="h-1.5" />
                <p className="text-[9px] text-muted-foreground text-center mt-0.5">{repCallsToday}/{dailyTarget} calls</p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}