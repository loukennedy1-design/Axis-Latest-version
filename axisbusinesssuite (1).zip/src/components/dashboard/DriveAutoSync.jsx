import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Cloud, Loader2, CheckCircle2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Auto-syncs the current subscriber's call recordings (CallLog.recording_url)
// and session logs (VoiceCallSession transcript/summary) to their own Google Drive
// via the per-user Google Drive OAuth connector. Runs in the subscriber's session
// so the per-user OAuth token is available. Silently no-ops until Drive is connected.
export default function DriveAutoSync() {
  const qc = useQueryClient();
  const [status, setStatus] = useState('idle'); // idle | syncing | done | notconnected
  const [synced, setSynced] = useState(0);
  const [failed, setFailed] = useState(0);

  const { data: calls = [] } = useQuery({
    queryKey: ['calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 200),
  });
  const { data: sessions = [] } = useQuery({
    queryKey: ['voice-call-sessions'],
    queryFn: () => base44.entities.VoiceCallSession.list('-created_date', 200),
  });

  useEffect(() => {
    let cancelled = false;
    async function run() {
      const unsyncedCalls = calls.filter((c) => c.recording_url && !c.drive_file_id);
      const unsyncedSessions = sessions.filter((s) => (s.conversation_transcript || s.call_summary) && !s.drive_file_id);
      if (!unsyncedCalls.length && !unsyncedSessions.length) { setStatus('idle'); return; }
      setStatus('syncing');
      let ok = 0;
      let bad = 0;
      for (const c of unsyncedCalls) {
        if (cancelled) return;
        try {
          const r = await base44.functions.invoke('syncCallRecordingToDrive', { call_id: c.id });
          if (r.data?.success || r.data?.drive_file_id) { ok += 1; qc.invalidateQueries({ queryKey: ['calls'] }); }
          else bad += 1;
        } catch (e) {
          if (String(e?.message || e).includes('not connected')) { setStatus('notconnected'); return; }
          bad += 1;
        }
      }
      for (const s of unsyncedSessions) {
        if (cancelled) return;
        try {
          const r = await base44.functions.invoke('syncCallRecordingToDrive', { session_id: s.id });
          if (r.data?.success || r.data?.drive_file_id) { ok += 1; qc.invalidateQueries({ queryKey: ['voice-call-sessions'] }); }
          else bad += 1;
        } catch (e) {
          if (String(e?.message || e).includes('not connected')) { setStatus('notconnected'); return; }
          bad += 1;
        }
      }
      if (cancelled) return;
      setSynced(ok);
      setFailed(bad);
      setStatus(ok || bad ? 'done' : 'idle');
    }
    run();
    return () => { cancelled = true; };
  }, [calls, sessions, qc]);

  if (status === 'idle' || status === 'notconnected') return null;

  return (
    <div className="flex items-center gap-2 p-2.5 rounded-lg bg-muted/20 border border-border text-xs">
      {status === 'syncing' ? <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" /> : <Cloud className="w-3.5 h-3.5 text-primary" />}
      <span className="text-muted-foreground">
        {status === 'syncing'
          ? 'Syncing call recordings & session logs to Google Drive…'
          : `Synced ${synced} file${synced !== 1 ? 's' : ''} to Google Drive${failed ? ` · ${failed} failed` : ''}`}
      </span>
      {status === 'done' && (
        <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px] ml-auto">
          <CheckCircle2 className="w-3 h-3 mr-1" />Drive
        </Badge>
      )}
    </div>
  );
}