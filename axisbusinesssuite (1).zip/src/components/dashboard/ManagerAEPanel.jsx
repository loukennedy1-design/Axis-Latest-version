import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';
import { Users, Phone, Calendar, TrendingUp, Eye, CheckCircle2, Clock, ArrowRight } from 'lucide-react';

export default function ManagerAEPanel() {
  const { data: reps = [] } = useQuery({
    queryKey: ['sales-reps'],
    queryFn: () => base44.entities.SalesRep.list('-created_date'),
  });
  const { data: calls = [] } = useQuery({
    queryKey: ['calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });
  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => base44.entities.Appointment.list(),
  });
  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list('-created_date', 200),
  });

  if (reps.length === 0) return null;

  const totalRepCalls = reps.reduce((sum, rep) => {
    return sum + calls.filter(c => c.called_by === rep.name || c.owner === rep.email).length;
  }, 0);
  const totalRepAppts = reps.reduce((sum, rep) => {
    return sum + appointments.filter(a => a.assigned_to === rep.email).length;
  }, 0);
  const activeReps = reps.filter(r => r.status === 'active').length;

  return (
    <Card className="border-primary/20 bg-primary/5">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            AE Team Overview ({reps.length} reps)
          </CardTitle>
          <Link to="/ae-onboarding">
            <Button variant="outline" size="sm" className="text-xs gap-1 h-7">
              Full Dashboard <ArrowRight className="w-3 h-3" />
            </Button>
          </Link>
        </div>
        <div className="flex gap-4 text-xs text-muted-foreground mt-1">
          <span className="flex items-center gap-1"><Phone className="w-3 h-3" /><strong>{totalRepCalls}</strong> team calls</span>
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /><strong>{totalRepAppts}</strong> team appts</span>
          <span className="flex items-center gap-1"><Users className="w-3 h-3" /><strong>{activeReps}</strong> active</span>
        </div>
      </CardHeader>
      <CardContent className="space-y-2.5">
        {reps.slice(0, 5).map(rep => {
          const repCalls = calls.filter(c => c.called_by === rep.name || c.owner === rep.email);
          const repAppts = appointments.filter(a => a.assigned_to === rep.email);
          const repLeads = leads.filter(l => l.assigned_to === rep.email);
          const callPct = Math.min(100, Math.round((repCalls.length / ((rep.target_calls_per_day || 50) * 30)) * 100));
          const steps = rep.onboarding_steps ? JSON.parse(rep.onboarding_steps) : {};
          const certified = steps.first_sale;
          const completedSteps = Object.values(steps).filter(Boolean).length;

          return (
            <div key={rep.id} className="flex items-center gap-3 p-2.5 bg-background border border-border rounded-lg">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                {rep.name?.charAt(0)?.toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-sm font-semibold truncate">{rep.name}</p>
                  {certified ? (
                    <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[9px] shrink-0">✅ Active</Badge>
                  ) : (
                    <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/30 text-[9px] shrink-0">🔄 {completedSteps}/8</Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                  <span><Phone className="w-2.5 h-2.5 inline mr-0.5" />{repCalls.length} calls</span>
                  <span><Calendar className="w-2.5 h-2.5 inline mr-0.5" />{repAppts.length} appts</span>
                  <span><Users className="w-2.5 h-2.5 inline mr-0.5" />{repLeads.length} leads</span>
                </div>
              </div>
              <div className="w-16 shrink-0">
                <Progress value={callPct} className="h-1.5" />
                <p className="text-[9px] text-muted-foreground text-center mt-0.5">{callPct}% target</p>
              </div>
            </div>
          );
        })}
        {reps.length > 5 && (
          <Link to="/ae-onboarding" className="block text-center text-xs text-primary hover:underline pt-1">
            View all {reps.length} AEs →
          </Link>
        )}
      </CardContent>
    </Card>
  );
}