import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import StatusBadge from '@/components/shared/StatusBadge';
import { Phone, Calendar, Users, TrendingUp, Target, Clock, CheckCircle2, AlertCircle } from 'lucide-react';
import { format, subDays, startOfDay } from 'date-fns';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar
} from 'recharts';

const ONBOARDING_STEPS = [
  { key: 'contract_signed', label: '1099 Contract Signed' },
  { key: 'account_created', label: 'Platform Account Created' },
  { key: 'product_training', label: 'Product Training' },
  { key: 'script_memorized', label: 'Script Memorized' },
  { key: 'role_play_complete', label: 'Role Play Drills' },
  { key: 'shadow_complete', label: 'Shadow Ride-Along' },
  { key: 'first_solo', label: 'First Solo Session' },
  { key: 'first_sale', label: 'First Sale Closed' },
];

export default function AEDashboard() {
  const { user } = useCurrentUser();

  // Load the AE's SalesRep record (matched by email)
  const { data: allReps = [] } = useQuery({
    queryKey: ['sales-reps'],
    queryFn: () => base44.entities.SalesRep.list(),
  });

  // AE's own data — filtered by their email as owner
  const { data: myCalls = [] } = useQuery({
    queryKey: ['my-calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 200),
  });
  const { data: myAppts = [] } = useQuery({
    queryKey: ['my-appts'],
    queryFn: () => base44.entities.Appointment.list('-created_date', 100),
  });
  const { data: myLeads = [] } = useQuery({
    queryKey: ['my-leads'],
    queryFn: () => base44.entities.Lead.list('-created_date', 200),
  });
  const { data: myTasks = [] } = useQuery({
    queryKey: ['my-tasks'],
    queryFn: () => base44.entities.FollowUpTask.list(),
  });

  // Find this AE's SalesRep profile — match by email
  const repProfile = allReps.find(r => r.email === user?.email);

  const steps = repProfile?.onboarding_steps ? JSON.parse(repProfile.onboarding_steps) : {};
  const completedSteps = ONBOARDING_STEPS.filter(s => steps[s.key]).length;
  const onboardingPct = Math.round((completedSteps / ONBOARDING_STEPS.length) * 100);
  const isCertified = steps.first_sale;

  // KPI calculations
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const callsToday = myCalls.filter(c => c.created_date?.startsWith(todayStr)).length;
  const apptsPending = myAppts.filter(a => ['scheduled', 'confirmed'].includes(a.status)).length;
  const tasksDue = myTasks.filter(t => t.status === 'pending').length;
  const convRate = myCalls.length > 0 ? ((myAppts.length / myCalls.length) * 100).toFixed(1) : '0.0';

  // Target progress
  const callTarget = repProfile?.target_calls_per_day || 50;
  const callPct = Math.min(100, Math.round((callsToday / callTarget) * 100));
  const apptTarget = repProfile?.target_appointments_per_week || 10;

  // 7-day time series
  const timeSeries = Array.from({ length: 7 }, (_, i) => {
    const d = subDays(new Date(), 6 - i);
    const dateStr = format(d, 'yyyy-MM-dd');
    return {
      name: format(d, 'EEE'),
      calls: myCalls.filter(c => c.created_date?.startsWith(dateStr)).length,
      appointments: myAppts.filter(a => a.created_date?.startsWith(dateStr)).length,
    };
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">My Dashboard</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {user?.full_name || user?.email} · {repProfile?.role?.replace(/_/g, ' ') || 'Account Executive'}
            {repProfile?.territory && ` · Territory: ${repProfile.territory}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {isCertified ? (
            <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 gap-1"><CheckCircle2 className="w-3 h-3" />Certified AE</Badge>
          ) : (
            <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/30 gap-1"><Clock className="w-3 h-3" />Onboarding — {onboardingPct}%</Badge>
          )}
        </div>
      </div>

      {/* Onboarding bar (only if not certified) */}
      {!isCertified && (
        <Card className="border-amber-500/30 bg-amber-500/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm font-semibold text-amber-700">Onboarding Progress — {completedSteps}/{ONBOARDING_STEPS.length} Steps</p>
              <span className="text-sm font-bold text-amber-700">{onboardingPct}%</span>
            </div>
            <Progress value={onboardingPct} className="h-2 mb-3" />
            <div className="flex flex-wrap gap-2">
              {ONBOARDING_STEPS.map(step => (
                <div key={step.key} className={`flex items-center gap-1 text-[10px] px-2 py-1 rounded-full border ${steps[step.key] ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-700' : 'bg-muted border-border text-muted-foreground'}`}>
                  <CheckCircle2 className={`w-2.5 h-2.5 ${steps[step.key] ? 'text-emerald-500' : 'text-muted-foreground/30'}`} />
                  {step.label}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Calls Today', value: callsToday, target: `Target: ${callTarget}/day`, icon: Phone, color: 'text-primary', bg: 'bg-primary/10', pct: callPct },
          { label: 'Appointments', value: apptsPending, target: `Target: ${apptTarget}/week`, icon: Calendar, color: 'text-purple-600', bg: 'bg-purple-500/10', pct: null },
          { label: 'Leads Assigned', value: myLeads.length, target: 'Total in pipeline', icon: Users, color: 'text-blue-600', bg: 'bg-blue-500/10', pct: null },
          { label: 'Conv. Rate', value: `${convRate}%`, target: `${myAppts.length} from ${myCalls.length} calls`, icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-500/10', pct: null },
        ].map(({ label, value, target, icon: Icon, color, bg, pct }) => (
          <Card key={label}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-2">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${bg}`}><Icon className={`w-4 h-4 ${color}`} /></div>
                <div>
                  <p className="text-xl font-bold">{value}</p>
                  <p className="text-[10px] text-muted-foreground">{label}</p>
                </div>
              </div>
              {pct !== null && <Progress value={pct} className="h-1.5" />}
              <p className="text-[10px] text-muted-foreground mt-1">{target}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Today's target progress */}
      {repProfile && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { label: 'Daily Call Target', current: callsToday, target: callTarget, unit: 'calls today' },
            { label: 'Weekly Appt Target', current: apptsPending, target: apptTarget, unit: 'this week' },
            { label: 'Monthly Revenue Target', current: 0, target: repProfile.target_revenue_per_month || 10000, unit: `$${(repProfile.target_revenue_per_month || 10000).toLocaleString()} goal`, isDollar: true },
          ].map(item => {
            const pct = item.isDollar ? 0 : Math.min(100, Math.round((item.current / item.target) * 100));
            return (
              <div key={item.label} className="rounded-xl border p-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{item.label}</span>
                  <span className={`font-bold ${pct >= 80 ? 'text-emerald-600' : pct >= 50 ? 'text-amber-600' : 'text-red-500'}`}>{item.isDollar ? 'Track' : `${pct}%`}</span>
                </div>
                {!item.isDollar && <Progress value={pct} className="h-2" />}
                <p className="text-[10px] text-muted-foreground mt-1">{item.isDollar ? item.unit : `${item.current} / ${item.target} ${item.unit}`}</p>
              </div>
            );
          })}
        </div>
      )}

      {/* 7-day activity chart */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">My Activity — Last 7 Days</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={timeSeries}>
              <defs>
                <linearGradient id="aeCalls" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,13%,91%)" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              <Area type="monotone" dataKey="calls" name="Calls" stroke="hsl(217,91%,60%)" fill="url(#aeCalls)" strokeWidth={2} />
              <Area type="monotone" dataKey="appointments" name="Appointments" stroke="hsl(162,63%,47%)" fill="none" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Bottom row: Recent calls + Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm flex items-center gap-2"><Phone className="w-4 h-4" />Recent Calls</CardTitle></CardHeader>
          <CardContent className="space-y-2.5">
            {myCalls.slice(0, 6).map(call => (
              <div key={call.id} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{call.lead_name || call.phone_number}</p>
                  <p className="text-xs text-muted-foreground">{call.created_date ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</p>
                </div>
                <StatusBadge status={call.outcome || call.status} />
              </div>
            ))}
            {myCalls.length === 0 && <p className="text-sm text-muted-foreground">No calls logged yet</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm flex items-center gap-2"><Target className="w-4 h-4" />My Tasks ({tasksDue} pending)</CardTitle></CardHeader>
          <CardContent className="space-y-2.5">
            {myTasks.filter(t => t.status === 'pending').slice(0, 6).map(task => (
              <div key={task.id} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{task.lead_name || 'Unknown Lead'}</p>
                  <p className="text-xs text-muted-foreground capitalize">{task.task_type?.replace(/_/g, ' ')} · {task.priority} priority</p>
                </div>
                <Badge variant="outline" className={task.priority === 'high' ? 'text-red-500 border-red-500/30 text-[10px]' : task.priority === 'medium' ? 'text-amber-600 border-amber-500/30 text-[10px]' : 'text-[10px]'}>
                  {task.due_date ? format(new Date(task.due_date), 'MMM d') : 'No date'}
                </Badge>
              </div>
            ))}
            {tasksDue === 0 && <p className="text-sm text-muted-foreground">No pending tasks</p>}
          </CardContent>
        </Card>
      </div>

      {/* Upcoming appointments */}
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm flex items-center gap-2"><Calendar className="w-4 h-4" />My Upcoming Appointments</CardTitle></CardHeader>
        <CardContent className="space-y-2.5">
          {myAppts.filter(a => ['scheduled', 'confirmed'].includes(a.status)).slice(0, 5).map(apt => (
            <div key={apt.id} className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">{apt.lead_name || 'Unknown'}</p>
                <p className="text-xs text-muted-foreground">{apt.scheduled_date ? format(new Date(apt.scheduled_date), 'MMM d, h:mm a') : '—'}</p>
              </div>
              <StatusBadge status={apt.status} />
            </div>
          ))}
          {apptsPending === 0 && <p className="text-sm text-muted-foreground">No upcoming appointments</p>}
        </CardContent>
      </Card>
    </div>
  );
}