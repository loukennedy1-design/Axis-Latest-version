import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Bot, Zap, Brain, TrendingUp, Activity, CheckCircle2, Clock, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

const AGENTS = [
  { name: 'Marketing Engine', key: 'marketing', color: '#F5C842', icon: TrendingUp, desc: 'Finding prospects 24/7' },
  { name: 'Trinity AI', key: 'trinity', color: '#A78BFA', icon: Brain, desc: 'Executive oversight' },
  { name: 'Market Intel', key: 'market_intel', color: '#34D399', icon: Activity, desc: 'Competitive scanning' },
  { name: 'Customer Success', key: 'customer_success', color: '#60A5FA', icon: CheckCircle2, desc: 'Subscriber support' },
];

export default function AIStatusPanel() {
  const [marketingTask, setMarketingTask] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const tasks = await base44.entities.AgentTask.filter({ task_type: 'report_generation' });
        const mt = tasks.find(t => t.title === 'Marketing Engine Cycle');
        setMarketingTask(mt || null);
      } catch (_) {}
      setLoading(false);
    };
    load();
  }, []);

  const lastRun = marketingTask?.last_run_at ? new Date(marketingTask.last_run_at) : null;
  const cycleCount = marketingTask?.run_count || 0;

  let lastResult = null;
  try {
    lastResult = marketingTask?.last_run_result ? JSON.parse(marketingTask.last_run_result) : null;
  } catch (_) {}

  return (
    <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-card via-card to-primary/5 p-5">
      {/* Subtle glow */}
      <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-primary/20 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-sm">AI Agent Status</h3>
              <p className="text-[10px] text-muted-foreground">All agents operational</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-emerald-500 font-semibold">LIVE</span>
          </div>
        </div>

        {/* Agent grid */}
        <div className="grid grid-cols-2 gap-2 mb-4">
          {AGENTS.map(agent => (
            <div key={agent.key} className="flex items-center gap-2.5 p-2.5 rounded-xl bg-background/40 border border-border/50">
              <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${agent.color}20` }}>
                <agent.icon className="w-3.5 h-3.5" style={{ color: agent.color }} />
              </div>
              <div className="min-w-0">
                <p className="text-[11px] font-semibold truncate">{agent.name}</p>
                <p className="text-[9px] text-muted-foreground truncate">{agent.desc}</p>
              </div>
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 flex-shrink-0 ml-auto animate-pulse" />
            </div>
          ))}
        </div>

        {/* Marketing Engine Stats */}
        {!loading && (
          <div className="rounded-xl bg-primary/5 border border-primary/20 p-3">
            <div className="flex items-center gap-2 mb-2">
              <Bot className="w-3.5 h-3.5 text-primary" />
              <span className="text-[11px] font-semibold text-primary">Marketing Engine — 24/7</span>
              <Badge className="ml-auto text-[9px] bg-primary/10 text-primary border-primary/20 px-1.5 py-0">Cycle #{cycleCount}</Badge>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="text-center">
                <p className="text-base font-bold text-primary">{lastResult?.prospects_identified || 0}</p>
                <p className="text-[9px] text-muted-foreground">Prospects</p>
              </div>
              <div className="text-center">
                <p className="text-base font-bold text-emerald-500">{lastResult?.social_posts_created || 0}</p>
                <p className="text-[9px] text-muted-foreground">Posts Created</p>
              </div>
              <div className="text-center">
                <p className="text-base font-bold text-purple-400">{(lastResult?.estimated_reach || 0).toLocaleString()}</p>
                <p className="text-[9px] text-muted-foreground">Est. Reach</p>
              </div>
            </div>
            {lastRun && (
              <div className="flex items-center gap-1 mt-2 text-[9px] text-muted-foreground">
                <Clock className="w-3 h-3" />
                <span>Last run: {format(lastRun, 'MMM d, h:mm a')}</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}