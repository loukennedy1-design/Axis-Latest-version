import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Package, Truck, ShoppingCart, ArrowUpRight, X } from 'lucide-react';
import { format } from 'date-fns';

const statusColor = (status = '') => {
  switch (status) {
    case 'completed': case 'delivered': return 'bg-emerald-500/10 text-emerald-500 border-emerald-500/30';
    case 'in_progress': case 'in_transit': case 'running': return 'bg-blue-500/10 text-blue-500 border-blue-500/30';
    case 'quality_check': case 'processing': return 'bg-amber-500/10 text-amber-500 border-amber-500/30';
    case 'failed': case 'out_of_stock': return 'bg-red-500/10 text-red-500 border-red-500/30';
    default: return 'bg-muted text-muted-foreground';
  }
};

function DetailModal({ item, type, onClose }) {
  if (!item) return null;

  const fields = (() => {
    if (type === 'production') return [
      { label: 'Ticket #', value: item.ticket_number },
      { label: 'Product', value: item.product_name },
      { label: 'Account', value: item.account_name },
      { label: 'Quantity', value: item.quantity },
      { label: 'Priority', value: item.priority },
      { label: 'Stage', value: item.current_stage },
      { label: 'Due Date', value: item.due_date ? format(new Date(item.due_date), 'MMM d, yyyy') : 'N/A' },
      { label: 'Notes', value: item.notes },
    ];
    if (type === 'order') return [
      { label: 'Order #', value: item.order_number },
      { label: 'Customer', value: item.account_name },
      { label: 'Total', value: item.total ? `$${item.total.toLocaleString()}` : 'N/A' },
      { label: 'Production', value: item.production_status },
      { label: 'Fulfillment', value: item.fulfillment_status },
      { label: 'Onboarding', value: item.onboarding_status },
      { label: 'Created', value: item.created_date ? format(new Date(item.created_date), 'MMM d, yyyy') : 'N/A' },
    ];
    if (type === 'fulfillment') return [
      { label: 'Task #', value: item.task_number },
      { label: 'Account', value: item.account_name },
      { label: 'Type', value: item.task_type },
      { label: 'Carrier', value: item.carrier },
      { label: 'Tracking #', value: item.tracking_number },
      { label: 'Due Date', value: item.due_date ? format(new Date(item.due_date), 'MMM d, yyyy') : 'N/A' },
      { label: 'Notes', value: item.notes },
    ];
    return [];
  })();

  const titles = { production: 'Production Ticket', order: 'Order', fulfillment: 'Fulfillment Task' };

  return (
    <Dialog open={!!item} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {type === 'production' && <Package className="w-4 h-4 text-primary" />}
            {type === 'order' && <ShoppingCart className="w-4 h-4 text-primary" />}
            {type === 'fulfillment' && <Truck className="w-4 h-4 text-primary" />}
            {titles[type]} Details
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">{item.ticket_number || item.order_number || item.task_number}</span>
            <Badge className={statusColor(item.status)}>{(item.status || '').replace(/_/g, ' ')}</Badge>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {fields.filter(f => f.value != null && f.value !== '').map(f => (
              <div key={f.label} className="bg-muted/40 rounded-lg p-2.5">
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{f.label}</p>
                <p className="text-sm font-medium mt-0.5 capitalize">{String(f.value).replace(/_/g, ' ')}</p>
              </div>
            ))}
          </div>
          {type === 'production' && item.progress_percent > 0 && (
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-muted-foreground">Progress</span>
                <span>{item.progress_percent}%</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: `${item.progress_percent}%` }} />
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function OperationsProductionPanel() {
  const [selected, setSelected] = useState(null); // { item, type }

  const { data: productionTickets = [] } = useQuery({
    queryKey: ['production-tickets'],
    queryFn: () => base44.entities.ProductionTicket.list('-created_date', 10),
  });

  const { data: orders = [] } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order ? base44.entities.Order.list('-created_date', 10) : [],
  });

  const { data: fulfillmentTasks = [] } = useQuery({
    queryKey: ['fulfillment-tasks'],
    queryFn: () => base44.entities.FulfillmentTask ? base44.entities.FulfillmentTask.list('-created_date', 10) : [],
  });

  const inProgress = productionTickets.filter(t => t.status === 'in_progress').length;
  const pendingFulfillment = fulfillmentTasks.filter(t => t.status === 'pending').length;
  const openOrders = orders.filter(o => !['completed', 'cancelled'].includes(o.status)).length;

  const sections = [
    {
      title: 'Production Tickets',
      icon: Package,
      items: productionTickets.slice(0, 4),
      type: 'production',
      count: inProgress,
      countLabel: 'in progress',
      href: '/production-fulfillment',
      nameKey: 'ticket_number',
      subKey: 'product_name',
    },
    {
      title: 'Orders',
      icon: ShoppingCart,
      items: orders.slice(0, 4),
      type: 'order',
      count: openOrders,
      countLabel: 'open',
      href: '/workflow-orchestration',
      nameKey: 'order_number',
      subKey: 'account_name',
    },
    {
      title: 'Fulfillment Tasks',
      icon: Truck,
      items: fulfillmentTasks.slice(0, 4),
      type: 'fulfillment',
      count: pendingFulfillment,
      countLabel: 'pending',
      href: '/production-fulfillment',
      nameKey: 'task_number',
      subKey: 'account_name',
    },
  ];

  const hasAnyData = productionTickets.length > 0 || orders.length > 0 || fulfillmentTasks.length > 0;
  if (!hasAnyData) return null;

  return (
    <>
      <Card className="border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Package className="w-4 h-4 text-primary" />
            Operations & Production
            <Badge variant="outline" className="ml-auto text-xs">Click any row for details</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {sections.map(({ title, icon: Icon, items, type, count, countLabel, href, nameKey, subKey }) => (
              <div key={type}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wide">
                    <Icon className="w-3.5 h-3.5" />
                    {title}
                  </div>
                  <div className="flex items-center gap-1.5">
                    {count > 0 && (
                      <Badge className="text-[10px] px-1.5 py-0 bg-primary/10 text-primary border-primary/20">
                        {count} {countLabel}
                      </Badge>
                    )}
                    <a href={href} className="text-[10px] text-muted-foreground hover:text-primary flex items-center gap-0.5 transition-colors">
                      View all <ArrowUpRight className="w-2.5 h-2.5" />
                    </a>
                  </div>
                </div>
                <div className="space-y-1.5">
                  {items.length > 0 ? items.map(item => (
                    <button
                      key={item.id}
                      onClick={() => setSelected({ item, type })}
                      className="w-full text-left p-2.5 rounded-lg border border-border bg-card hover:bg-muted/50 hover:border-primary/30 transition-all group"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium truncate group-hover:text-primary transition-colors">
                            {item[nameKey] || '—'}
                          </p>
                          <p className="text-[10px] text-muted-foreground truncate">{item[subKey] || ''}</p>
                        </div>
                        <Badge className={`${statusColor(item.status)} text-[10px] shrink-0`}>
                          {(item.status || '').replace(/_/g, ' ')}
                        </Badge>
                      </div>
                    </button>
                  )) : (
                    <p className="text-xs text-muted-foreground text-center py-4">No records</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DetailModal
        item={selected?.item}
        type={selected?.type}
        onClose={() => setSelected(null)}
      />
    </>
  );
}