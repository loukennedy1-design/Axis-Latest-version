import React from 'react';
import ProfessionalVideoPlayer from './ProfessionalVideoPlayer';

export default function ModuleVideoPlayer({ module, onVideoComplete }) {
  return (
    <div className="space-y-3">
      <ProfessionalVideoPlayer module={module} onComplete={onVideoComplete} />
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: 'Interactive Chapters', desc: 'Step through each lesson at your own pace' },
          { label: 'Key Takeaways', desc: 'Tap 💡 to reveal core concepts anytime' },
          { label: 'Progress Tracking', desc: 'Resume exactly where you left off' },
        ].map((f, i) => (
          <div key={i} className="rounded-lg border border-border bg-muted/30 p-3 text-center">
            <p className="text-xs font-semibold text-primary mb-1">{f.label}</p>
            <p className="text-[10px] text-muted-foreground">{f.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}