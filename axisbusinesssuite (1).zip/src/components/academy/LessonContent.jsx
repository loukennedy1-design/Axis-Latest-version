import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bot, MessageSquare, Zap, BookOpen } from 'lucide-react';

export function Module3Content() {
  return (
    <div className="space-y-4">
      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center text-xs font-bold text-emerald-500">1</span>
            Three Ways to Add Leads
          </h4>
          <div className="text-sm space-y-2 ml-9 text-muted-foreground">
            <div className="p-3 rounded-lg bg-muted/20 border">
              <strong className="text-emerald-500">Method 1: Manual Entry</strong>
              <p className="mt-1">Leads → New Lead button. Best for: One-off leads from business cards, networking events, or phone inquiries.</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/20 border">
              <strong className="text-emerald-500">Method 2: CSV Import</strong>
              <p className="mt-1">Import Wizard in sidebar. Best for: Bulk uploading existing lead lists (up to 10,000 leads per import). Supports CSV, XLSX formats.</p>
            </div>
            <div className="p-3 rounded-lg bg-muted/20 border">
              <strong className="text-emerald-500">Method 3: AI Lead Generator</strong>
              <p className="mt-1">Lead Generator page. The AI searches Google Maps, web databases, and business directories to find prospects matching your ideal customer profile automatically.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-500/10 flex items-center justify-center text-xs font-bold text-emerald-500">2</span>
            Required vs Optional Fields
          </h4>
          <div className="text-sm space-y-2 ml-9">
            <p><strong>Required (Must Have):</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>First Name:</strong> For personalization in calls</li>
              <li><strong>Phone Number:</strong> E.164 format recommended (+15551234567)</li>
            </ul>
            <p className="mt-2"><strong>Highly Recommended:</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Email:</strong> For follow-up sequences and nurture campaigns</li>
              <li><strong>Company Name:</strong> For B2B targeting and qualification</li>
              <li><strong>Consent Given:</strong> Legal requirement for TCPA compliance</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Module6Content() {
  return (
    <div className="space-y-4">
      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4" />SMS & Email Automation Deep Dive
          </h4>
          <div className="text-sm space-y-2 ml-4 text-muted-foreground">
            <p><strong>Twilio SMS Setup:</strong></p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>Go to Settings → Integrations → Twilio</li>
              <li>Enter your Account SID and Auth Token (from twilio.com/console)</li>
              <li>Add your Twilio phone number in E.164 format (+15551234567)</li>
              <li>Enable webhook for two-way messaging</li>
              <li>Test by sending a message to your number</li>
            </ol>
            <p className="mt-2"><strong>SMS Best Practices:</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Keep messages under 160 characters (avoid splitting)</li>
              <li>Include opt-out: "Reply STOP to unsubscribe"</li>
              <li>Send during business hours only (8AM-8PM local time)</li>
              <li>Use for: appointment reminders, quick follow-ups, time-sensitive info</li>
              <li>Maximum 3 messages before response (to avoid spam complaints)</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4" />Email Templates & Automation
          </h4>
          <div className="text-sm space-y-2 ml-4 text-muted-foreground">
            <p><strong>Email Client Features:</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li>Pre-built templates for common scenarios (follow-up, no-show, nurture)</li>
              <li>Personalization tokens: {`{{first_name}}`}, {`{{company}}`}, {`{{appointment_date}}`}</li>
              <li>Rich text editor with image support</li>
              <li>Track opens, clicks, and replies automatically</li>
              <li>Automated sequences triggered by lead status changes</li>
            </ul>
            <p className="mt-2"><strong>Multi-Channel Nurture Example:</strong></p>
            <div className="p-3 rounded bg-muted/20 border text-xs space-y-1">
              <p><strong>Day 1:</strong> AI call → No answer → Voicemail dropped</p>
              <p><strong>Day 2:</strong> SMS: "Hi {`{{first_name}}`}, tried reaching you about {`{{company}}`}. Quick question - got 2 min?"</p>
              <p><strong>Day 3:</strong> Email: Value proposition + case study</p>
              <p><strong>Day 5:</strong> AI call → Live conversation → Appointment booked</p>
              <p><strong>Day 6:</strong> SMS reminder: "Confirmed for tomorrow at 2pm! See you then."</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function Module7Content() {
  return (
    <div className="space-y-4">
      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4" />Calendly Integration Complete Guide
          </h4>
          <div className="text-sm space-y-2 ml-4 text-muted-foreground">
            <p><strong>Step-by-Step Setup:</strong></p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>Go to Settings → Calendly tab</li>
              <li>Click "Connect with Calendly" (OAuth popup)</li>
              <li>Authorize the application with your Calendly account</li>
              <li>System automatically fetches your Event Types</li>
              <li>Select which event type to use for bookings</li>
              <li>Copy the Event Type URI (looks like: /event_types/ABC123)</li>
              <li>Paste URI in the field and click "Save & Sync"</li>
            </ol>
            <p className="mt-2"><strong>Finding Your Personal Access Token:</strong></p>
            <div className="p-3 rounded bg-amber-500/10 border border-amber-500/20 text-amber-700 text-xs">
              <strong>⚠️ Required for AI Booking:</strong>
              <ol className="list-decimal list-inside mt-1 space-y-1">
                <li>Log into Calendly</li>
                <li>Go to Integrations → API & Webhooks</li>
                <li>Click "Generate New Token"</li>
                <li>Copy the token (starts with "eyJ...")</li>
                <li>Paste in Settings → Calendly → Personal Access Token field</li>
                <li>Click "Fetch My Info" to verify connection</li>
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border">
        <CardContent className="p-4 space-y-3">
          <h4 className="font-semibold text-sm flex items-center gap-2">
            <BookOpen className="w-4 h-4" />How AI Booking Works
          </h4>
          <div className="text-sm space-y-2 ml-4 text-muted-foreground">
            <p><strong>During the Call:</strong></p>
            <ol className="list-decimal list-inside space-y-1 ml-4">
              <li>Lead says "yes" or "that sounds good" to meeting request</li>
              <li>AI asks: "Great! What day works best - tomorrow or later in the week?"</li>
              <li>Lead responds with preference (e.g., "Thursday afternoon")</li>
              <li>AI checks Calendly real-time availability via API</li>
              <li>AI offers 2-3 specific time slots: "I have 2pm, 3:30pm, or 5pm - which works?"</li>
              <li>Lead confirms time</li>
              <li>AI books appointment instantly and sends confirmation email/SMS</li>
              <li>Appointment appears in Appointments page with all details</li>
            </ol>
            <p className="mt-2"><strong>Configuration Options:</strong></p>
            <ul className="list-disc list-inside space-y-1 ml-4">
              <li><strong>Buffer Time:</strong> Gap between meetings (15-30 min recommended)</li>
              <li><strong>Days Ahead:</strong> How far in advance can book (3-7 days typical)</li>
              <li><strong>Prefer Morning/Afternoon:</strong> AI prioritizes your preferred times</li>
              <li><strong>Timezone:</strong> Auto-detects lead's timezone or uses yours</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function AIInstructorCTA({ moduleId }) {
  const summaries = {
    8: "AI Lead Scoring (0-100 algorithms), Nurture Workflows (automated sequences), Call Coaching (AI analysis), AI Agent Tasks (custom automations), Social Media AI (content generation for all platforms)",
    9: "Production & Fulfillment (ticket workflow), Inventory Management (tracking & alerts), Accounting Engine (P&L, balance sheets), Document Intelligence (AI processing), Digital Employees (AI workers for every department)",
    10: "Signal-to-Execution (24h response to high-intent signals), EU AI Act Compliance (transparency & trust), Deal Knowledge Graph (cross-platform context), Industry Micro-Apps (no-code workflows in 2.5 min)"
  };

  return (
    <Card className="border-border bg-muted/20">
      <CardContent className="p-6 space-y-4">
        <div className="text-center">
          <Bot className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <h4 className="font-semibold mb-2">Continue Learning with AI Instructor</h4>
          <p className="text-sm text-muted-foreground mb-4">
            Get personalized walkthroughs, live demos, and Q&A based on your specific business needs.
          </p>
          <div className="flex gap-3 justify-center flex-wrap">
            <Button variant="outline" onClick={() => window.open('/ae-chat', '_blank')}>
              <MessageSquare className="w-4 h-4 mr-2" />Chat with AI Instructor
            </Button>
            <Button onClick={() => window.open('/app', '_blank')}>
              <Zap className="w-4 h-4 mr-2" />Try It in Dashboard
            </Button>
          </div>
        </div>
        
        <div className="pt-4 border-t">
          <h5 className="font-semibold text-sm mb-2">Quick Module Summary:</h5>
          <div className="text-xs text-muted-foreground">
            {summaries[moduleId] || "Advanced features and enterprise capabilities for scaling your business operations."}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Default export for module-specific content
export default function LessonContent({ moduleId }) {
  const ContentComponent = {
    3: Module3Content,
    6: Module6Content,
    7: Module7Content,
  }[moduleId];

  if (!ContentComponent) return null;

  return <ContentComponent />;
}