import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import {
  Play, Pause, SkipForward, SkipBack, Volume2, VolumeX,
  Maximize, Minimize, CheckCircle2, Clock,
  BookOpen, Lightbulb, Star, MonitorPlay, List, Loader2, Mic,
  Upload, Download, Video, X
} from 'lucide-react';

// Chapter data per module id
const MODULE_CHAPTERS = {
  1: [
    { title: 'Welcome to Axis', icon: '🚀', duration: '2:00', keyPoints: ['AI-powered business automation suite', 'Built for sales teams, HR, and operations', 'One platform — every department'] },
    { title: 'The 6 Core Modules', icon: '⚡', duration: '3:00', keyPoints: ['CRM & Lead Management', 'AI Call Bot & Dialer', 'HR, Recruiting & Payroll', 'Social Media AI', 'Financial Operations', 'Compliance & Legal'] },
    { title: 'Navigating the Sidebar', icon: '🧭', duration: '2:00', keyPoints: ['Left sidebar = your main navigation', 'Sections are color-coded by department', 'Collapse sidebar for more screen space'] },
    { title: 'The 30-Minute Setup', icon: '⏱️', duration: '1:00', keyPoints: ['Start with Settings → Company Info', 'Then add your first leads', 'Launch the call bot in under 30 minutes'] },
    { title: 'Your Personal Dashboard', icon: '📊', duration: '4:00', keyPoints: ['KPI cards update in real-time', 'AI Status Panel shows live agent activity', 'Daily snapshot refreshes every morning'] },
  ],
  2: [
    { title: 'Company Info & Timezone', icon: '🏢', duration: '2:00', keyPoints: ['Set company name used in all outreach', 'Timezone affects call windows and scheduling', 'These settings power your AI personality'] },
    { title: 'Call Recording with Disclosure', icon: '🎙️', duration: '3:00', keyPoints: ['Required disclosure: "This call may be recorded"', 'Recordings stored for 90 days', 'Enable coaching analysis on recordings'] },
    { title: 'Bot Behavior Settings', icon: '🤖', duration: '3:00', keyPoints: ['Max attempts: recommended 3', 'Call gap: 5+ seconds between leads', 'Auto-DNC on opt-out requests'] },
    { title: 'Calling Schedule', icon: '📅', duration: '2:00', keyPoints: ['TCPA hours: 8AM–9PM local time', 'Set blackout days for holidays', 'Timezone auto-detection for leads'] },
    { title: 'OAuth Integrations Setup', icon: '🔗', duration: '5:00', keyPoints: ['One-click connect for Google Calendar', 'Calendly auto-booking integration', 'CRM sync with HubSpot & Salesforce'] },
  ],
  3: [
    { title: '3 Ways to Add Leads', icon: '➕', duration: '3:00', keyPoints: ['Manual entry for single leads', 'CSV Import Wizard for bulk uploads', 'AI Lead Generator for auto-prospecting'] },
    { title: 'Import Wizard Walkthrough', icon: '📤', duration: '4:00', keyPoints: ['Map CSV columns to lead fields', 'Duplicate detection built in', 'Consent field required for calling'] },
    { title: 'Required vs Optional Fields', icon: '📋', duration: '2:00', keyPoints: ['Required: First Name + Phone', 'Recommended: Email, Company, Timezone', 'Optional: Source, Score, Assignment'] },
    { title: 'Consent & Compliance', icon: '✅', duration: '3:00', keyPoints: ['Consent must be true before bot calls', 'Consent date is logged automatically', 'Import can bulk-set consent = true'] },
    { title: 'AI Lead Generator', icon: '🔍', duration: '6:00', keyPoints: ['Search by industry, city, company size', 'Scrapes Google Maps & business databases', 'Auto-imports qualified leads into CRM'] },
  ],
  4: [
    { title: 'TCPA Explained', icon: '⚖️', duration: '4:00', keyPoints: ['Telephone Consumer Protection Act (1991)', 'Fines: $500–$1,500 per violation', 'Applies to all automated calling/texting'] },
    { title: 'Consent Types', icon: '📝', duration: '3:00', keyPoints: ['Express written consent = strongest protection', 'Website form opt-ins count as consent', 'Cold calling requires prior relationship or permission'] },
    { title: 'Required Script Elements', icon: '🗣️', duration: '3:00', keyPoints: ['Identify yourself and company', 'State purpose of call', 'Offer opt-out clearly'] },
    { title: 'DNC Registry Management', icon: '🚫', duration: '2:00', keyPoints: ['Upload to DNC Registry in sidebar', 'Auto-add triggered by "stop calling" keyword', 'Export DNC list for compliance audits'] },
    { title: 'Automated Opt-Out Handling', icon: '🔄', duration: '2:00', keyPoints: ['AI detects opt-out language in real-time', 'Instantly adds to DNC and ends call', 'Compliance log entry created automatically'] },
  ],
  5: [
    { title: '6 Calling Modes Compared', icon: '📞', duration: '5:00', keyPoints: ['AI Simulation: Full AI conversation', 'Phone Link: Opens your phone app', 'Twilio: Real calls via cloud telephony', 'Zoom: Video meeting scheduling', 'WhatsApp: Messaging-first outreach', 'Custom API: Your own phone system'] },
    { title: 'Writing High-Converting Scripts', icon: '✍️', duration: '6:00', keyPoints: ['Hook in first 8 seconds', 'Pain → Solution → Proof → CTA structure', 'Use [LEAD_NAME] and [COMPANY] tokens'] },
    { title: 'Bot Personality & Voice', icon: '🎭', duration: '3:00', keyPoints: ['Choose: Professional, Friendly, Energetic, Calm', 'Personality affects word choice and tone', 'Test different styles for your industry'] },
    { title: 'Auto-Dialer Operation', icon: '⚙️', duration: '3:00', keyPoints: ['Start dialer from Call Bot page', 'Leads queue based on status = new', 'Bot cycles through until all leads processed'] },
    { title: 'Call Analytics & Optimization', icon: '📈', duration: '3:00', keyPoints: ['Outcome tracking: appointments, callbacks, no answers', 'AI rewrites script based on top performers', 'Coaching score grades every call 0–100'] },
  ],
  6: [
    { title: 'Twilio SMS Setup', icon: '📱', duration: '3:00', keyPoints: ['Add Twilio credentials in Settings', 'Phone number must be in E.164 format', 'Test with a real number before bulk sending'] },
    { title: 'SMS Inbox: Two-Way Conversations', icon: '💬', duration: '3:00', keyPoints: ['Real-time two-way messaging', 'Conversations grouped by lead', 'AI can draft responses automatically'] },
    { title: 'SMS Compliance Best Practices', icon: '🛡️', duration: '2:00', keyPoints: ['Max 2–3 messages to non-responders', 'Always include opt-out instruction: "Reply STOP"', 'Avoid sending between 9PM–8AM'] },
    { title: 'Email Templates & Automation', icon: '📧', duration: '4:00', keyPoints: ['Create templates with merge fields', 'Schedule follow-up sequences', 'Track opens and clicks per lead'] },
    { title: 'Multi-Channel Nurture Workflows', icon: '🔀', duration: '4:00', keyPoints: ['Combine calls + SMS + email in one flow', 'Trigger on lead status change', 'Day-based delays keep outreach natural'] },
  ],
  7: [
    { title: 'Calendly OAuth Setup', icon: '📅', duration: '3:00', keyPoints: ['Connect via Settings → Calendly tab', 'OAuth flow — no passwords shared', 'Access token auto-refreshes'] },
    { title: 'Personal Access Token Walkthrough', icon: '🔑', duration: '2:00', keyPoints: ['Go to Calendly → Integrations → API', 'Generate and copy token', 'Paste in Settings → Calendly → Token field'] },
    { title: 'Event Types & Availability', icon: '⏰', duration: '3:00', keyPoints: ['Fetch your event types with one click', 'Select which type the bot uses for booking', 'Set buffer minutes between appointments'] },
    { title: 'AI Automatic Booking', icon: '🤖', duration: '2:00', keyPoints: ['Bot detects "yes" / "let\'s meet" intent', 'Fetches next 3 available slots from Calendly', 'Lead chooses time; bot confirms and logs it'] },
    { title: 'Appointment Pipeline Management', icon: '🗓️', duration: '2:00', keyPoints: ['All bookings appear on Appointments page', 'Status: Scheduled → Confirmed → Completed', 'Sync with Google Calendar and Outlook'] },
  ],
  8: [
    { title: 'AI Lead Scoring Algorithms', icon: '🎯', duration: '4:00', keyPoints: ['Score 0–100 based on engagement signals', 'Factors: calls answered, email opens, website visits', 'Auto-prioritize high-score leads for calling'] },
    { title: 'Nurture Workflow Builder', icon: '🔧', duration: '5:00', keyPoints: ['Visual workflow builder with drag-and-drop steps', 'Trigger: lead created, status changed, score threshold', 'Actions: send email, send SMS, assign task, wait N days'] },
    { title: 'Call Coaching with AI', icon: '🏋️', duration: '4:00', keyPoints: ['Every call graded on 4 dimensions', 'Opening strength, objection handling, close attempt, compliance', 'AI recommends specific script improvements'] },
    { title: 'AI Agent Tasks', icon: '⚡', duration: '5:00', keyPoints: ['Create custom autonomous tasks from Agent Tasks page', 'Schedule: once, hourly, daily, or weekly', 'Examples: clean stale leads, generate weekly report, re-engage cold pipeline'] },
    { title: 'Social Media AI Studio', icon: '📱', duration: '4:00', keyPoints: ['Generate posts for 5 platforms simultaneously', 'AI creates industry-specific content with hashtags', 'Schedule for optimal engagement times'] },
  ],
};

const CHAPTER_COLORS = [
  'from-blue-600 to-blue-800',
  'from-purple-600 to-purple-800',
  'from-emerald-600 to-emerald-800',
  'from-rose-600 to-rose-800',
  'from-amber-600 to-amber-800',
];

export default function ProfessionalVideoPlayer({ module, onComplete }) {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Load uploaded video URLs from GlobalAppSettings
  const { data: videoUrls = {} } = useQuery({
    queryKey: ['academy-videos'],
    queryFn: async () => {
      const records = await base44.entities.GlobalAppSettings.filter({ key: 'academy_video_urls' });
      if (records.length > 0) {
        try { return JSON.parse(records[0].value); } catch { return {}; }
      }
      return {};
    },
  });

  const saveVideoUrl = useMutation({
    mutationFn: async (newUrls) => {
      const records = await base44.entities.GlobalAppSettings.filter({ key: 'academy_video_urls' });
      if (records.length > 0) {
        await base44.entities.GlobalAppSettings.update(records[0].id, { value: JSON.stringify(newUrls) });
      } else {
        await base44.entities.GlobalAppSettings.create({ key: 'academy_video_urls', value: JSON.stringify(newUrls) });
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academy-videos'] }),
  });

  const uploadedVideoUrl = videoUrls[module.id];
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin' || user?.email === 'loukennedy1@gmail.com';

  const handleVideoUpload = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const updated = { ...videoUrls, [module.id]: file_url };
      await saveVideoUrl.mutateAsync(updated);
    } catch (e) {
      console.error('Upload failed', e);
    }
    setUploading(false);
  };

  const handleRemoveVideo = async () => {
    const updated = { ...videoUrls };
    delete updated[module.id];
    await saveVideoUrl.mutateAsync(updated);
  };

  // AI interactive player state (always declared — hooks can't be conditional)
  const [activeChapter, setActiveChapter] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [chapterProgress, setChapterProgress] = useState(0);
  const [completedChapters, setCompletedChapters] = useState(new Set());
  const [showChapterList, setShowChapterList] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showKeyPoints, setShowKeyPoints] = useState(false);
  const [chapterAudio, setChapterAudio] = useState({});
  const [loadingAudio, setLoadingAudio] = useState(false);
  const intervalRef = useRef(null);
  const containerRef = useRef(null);
  const audioRef = useRef(null);

  // Parse duration helper (needed before useEffect)
  const parseDuration = (d) => {
    const [m, s] = d.split(':').map(Number);
    return m * 60 + (s || 0);
  };

  const chapters = MODULE_CHAPTERS[module.id] || [];
  const currentChapter = chapters[activeChapter];
  const chapterDurationSecs = currentChapter ? parseDuration(currentChapter.duration) : 60;

  // Timer effect — must be declared before any conditional returns
  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setElapsed(prev => {
          const next = prev + 1;
          const pct = (next / chapterDurationSecs) * 100;
          setChapterProgress(Math.min(pct, 100));
          if (next >= chapterDurationSecs) {
            clearInterval(intervalRef.current);
            setIsPlaying(false);
            setElapsed(0);
            setCompletedChapters(prev2 => new Set([...prev2, activeChapter]));
            setChapterProgress(100);
          }
          return next >= chapterDurationSecs ? 0 : next;
        });
      }, 1000);
    } else {
      clearInterval(intervalRef.current);
    }
    return () => clearInterval(intervalRef.current);
  }, [isPlaying, activeChapter, chapterDurationSecs]);

  // Early returns AFTER all hooks
  if (uploadedVideoUrl) {
    return (
      <div className="rounded-xl overflow-hidden border border-primary/20 bg-black">
        <video
          src={uploadedVideoUrl}
          controls
          className="w-full aspect-video"
          style={{ maxHeight: '400px' }}
        />
        <div className="bg-card border-t border-border px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Video className="w-4 h-4 text-emerald-500" />
            <span>Module {module.id} — {module.title}</span>
          </div>
          <div className="flex items-center gap-2">
            <a href={uploadedVideoUrl} download target="_blank" rel="noopener noreferrer">
              <Button size="sm" variant="outline" className="gap-1.5 text-xs">
                <Download className="w-3.5 h-3.5" />Download
              </Button>
            </a>
            {isAdmin && (
              <>
                <label className="cursor-pointer">
                  <input type="file" accept="video/*" className="hidden"
                    onChange={e => handleVideoUpload(e.target.files?.[0])} />
                  <Button size="sm" variant="outline" className="gap-1.5 text-xs" asChild>
                    <span>
                      {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                      {uploading ? 'Uploading...' : 'Replace Video'}
                    </span>
                  </Button>
                </label>
                <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive text-xs gap-1" onClick={handleRemoveVideo}>
                  <X className="w-3.5 h-3.5" />Remove
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (isAdmin) {
    return (
      <div className="rounded-xl border-2 border-dashed border-primary/30 bg-primary/5 p-8 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto">
          <Video className="w-8 h-8 text-primary/60" />
        </div>
        <div>
          <p className="font-semibold text-sm">No video uploaded for Module {module.id}</p>
          <p className="text-xs text-muted-foreground mt-1">Upload a video file to make this module available to students</p>
        </div>
        <label className="cursor-pointer">
          <input type="file" accept="video/*" className="hidden"
            onChange={e => handleVideoUpload(e.target.files?.[0])} />
          <Button className="gap-2" disabled={uploading} asChild>
            <span>
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {uploading ? 'Uploading Video...' : 'Upload Module Video'}
            </span>
          </Button>
        </label>
        <p className="text-xs text-muted-foreground">Supports MP4, MOV, WebM, AVI</p>
      </div>
    );
  }

  // Non-admin, no video — show the AI interactive player as fallback

  // Generate and cache AI narration for a chapter
  const getChapterAudio = async (idx) => {
    if (chapterAudio[idx]) return chapterAudio[idx];
    const ch = chapters[idx];
    if (!ch) return null;
    setLoadingAudio(true);
    try {
      const narration = `${ch.title}. ${ch.keyPoints.join('. ')}.`;
      const res = await base44.integrations.Core.GenerateSpeech({
        text: narration,
        voice: 'river',
      });
      setChapterAudio(prev => ({ ...prev, [idx]: res.url }));
      setLoadingAudio(false);
      return res.url;
    } catch {
      setLoadingAudio(false);
      return null;
    }
  };

  // Play audio for current chapter
  const playChapterAudio = async (idx) => {
    if (isMuted) return;
    const url = await getChapterAudio(idx);
    if (!url) return;
    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current.play().catch(() => {});
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const selectChapter = (idx) => {
    stopAudio();
    setActiveChapter(idx);
    setChapterProgress(0);
    setElapsed(0);
    setIsPlaying(false);
    setShowChapterList(false);
  };

  const handlePlayPause = () => {
    if (!isPlaying) {
      setIsPlaying(true);
      playChapterAudio(activeChapter);
    } else {
      setIsPlaying(false);
      stopAudio();
    }
  };

  const handleMuteToggle = () => {
    const next = !isMuted;
    setIsMuted(next);
    if (audioRef.current) {
      audioRef.current.muted = next;
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const formatTime = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const totalMinutes = chapters.reduce((acc, c) => acc + parseDuration(c.duration), 0);
  const overallProgress = chapters.length
    ? ((completedChapters.size + (chapterProgress / 100)) / chapters.length) * 100
    : 0;

  const gradientClass = CHAPTER_COLORS[activeChapter % CHAPTER_COLORS.length];

  return (
    <div ref={containerRef} className="rounded-xl overflow-hidden border border-primary/20 bg-black select-none">
      {/* Main Video Area */}
      <div className={`relative aspect-video bg-gradient-to-br ${gradientClass} overflow-hidden`}>

        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10"
          style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '32px 32px' }} />

        {/* Animated glow orbs */}
        <div className="absolute -top-20 -left-20 w-64 h-64 rounded-full bg-white/10 blur-3xl animate-pulse" />
        <div className="absolute -bottom-20 -right-20 w-48 h-48 rounded-full bg-white/10 blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />

        {/* Chapter List Overlay */}
        {showChapterList && (
          <div className="absolute inset-0 bg-black/95 z-20 p-6 overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Module Chapters</h3>
              <Button variant="ghost" size="sm" onClick={() => setShowChapterList(false)} className="text-white hover:bg-white/20">✕</Button>
            </div>
            <div className="space-y-2">
              {chapters.map((ch, idx) => (
                <button key={idx} onClick={() => selectChapter(idx)}
                  className={`w-full text-left p-4 rounded-xl transition-all border ${
                    idx === activeChapter
                      ? 'bg-white/20 border-white/40'
                      : completedChapters.has(idx)
                      ? 'bg-emerald-500/20 border-emerald-500/30 hover:bg-emerald-500/30'
                      : 'bg-white/5 border-white/10 hover:bg-white/15'
                  }`}>
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{ch.icon}</span>
                    <div className="flex-1">
                      <p className="text-white font-semibold text-sm">{ch.title}</p>
                      <p className="text-white/60 text-xs mt-0.5">{ch.duration} · {ch.keyPoints.length} key points</p>
                    </div>
                    {completedChapters.has(idx) && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                    {idx === activeChapter && !completedChapters.has(idx) && (
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse shrink-0" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Key Points Overlay */}
        {showKeyPoints && !showChapterList && (
          <div className="absolute inset-0 bg-black/90 z-20 p-6 flex flex-col justify-center">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-white font-bold text-lg flex items-center gap-2">
                <Lightbulb className="w-5 h-5 text-yellow-400" /> Key Takeaways
              </h3>
              <Button variant="ghost" size="sm" onClick={() => setShowKeyPoints(false)} className="text-white hover:bg-white/20">✕</Button>
            </div>
            <div className="space-y-3 max-w-lg mx-auto w-full">
              {currentChapter?.keyPoints.map((kp, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-white/10 border border-white/20">
                  <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center text-white font-bold text-xs shrink-0 mt-0.5">{i + 1}</div>
                  <p className="text-white text-sm leading-relaxed">{kp}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Main Content — Chapter Display */}
        {!showChapterList && !showKeyPoints && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8">
            {/* Chapter badge */}
            <div className="flex items-center gap-2 mb-6">
              <Badge className="bg-black/40 text-white border-white/20 text-xs backdrop-blur-sm">
                Chapter {activeChapter + 1} of {chapters.length}
              </Badge>
              {completedChapters.has(activeChapter) && (
                <Badge className="bg-emerald-500/80 text-white border-0 text-xs">
                  <CheckCircle2 className="w-3 h-3 mr-1" />Watched
                </Badge>
              )}
            </div>

            {/* Icon */}
            <div className="text-7xl mb-4 drop-shadow-2xl" style={{ filter: 'drop-shadow(0 4px 24px rgba(0,0,0,0.4))' }}>
              {currentChapter?.icon}
            </div>

            {/* Chapter Title */}
            <h2 className="text-white text-2xl font-bold text-center mb-2 drop-shadow-lg">
              {currentChapter?.title}
            </h2>

            {/* Module name */}
            <p className="text-white/70 text-sm text-center mb-6">
              Module {module.id}: {module.title}
            </p>

            {/* Key points preview */}
            {isPlaying && (
              <div className="flex flex-col gap-2 w-full max-w-sm">
                {currentChapter?.keyPoints.map((kp, i) => (
                  <div key={i}
                    className="flex items-center gap-2 text-white/90 text-xs px-3 py-2 rounded-lg bg-black/30 backdrop-blur-sm border border-white/10 transition-all"
                    style={{ animationDelay: `${i * 0.5}s` }}>
                    <div className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                    {kp}
                  </div>
                ))}
              </div>
            )}

            {/* Play button (when paused) */}
            {!isPlaying && (
              <button onClick={handlePlayPause}
                className="mt-4 w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm border-2 border-white/50 flex items-center justify-center hover:scale-110 hover:bg-white/30 transition-all">
                {loadingAudio
                  ? <Loader2 className="w-8 h-8 text-white animate-spin" />
                  : <Play className="w-10 h-10 text-white ml-1" />}
              </button>
            )}

            {/* Chapter progress indicator (circular) when playing */}
            {isPlaying && (
              <div className="mt-6 flex items-center gap-3">
                <div className="relative w-12 h-12">
                  <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
                    <circle cx="24" cy="24" r="20" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="4" />
                    <circle cx="24" cy="24" r="20" fill="none" stroke="white" strokeWidth="4"
                      strokeDasharray={`${2 * Math.PI * 20}`}
                      strokeDashoffset={`${2 * Math.PI * 20 * (1 - chapterProgress / 100)}`}
                      className="transition-all duration-1000" />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Pause className="w-4 h-4 text-white cursor-pointer" onClick={handlePlayPause} />
                  </div>
                </div>
                <span className="text-white/80 text-sm font-mono">
                  {formatTime(elapsed)} / {currentChapter?.duration}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Top bar */}
        <div className="absolute top-0 left-0 right-0 p-3 bg-gradient-to-b from-black/70 to-transparent flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <Badge className="bg-primary/90 text-white text-xs border-0">
              <MonitorPlay className="w-3 h-3 mr-1" />Axis Academy
            </Badge>
            <Badge className="bg-black/50 text-white/80 text-xs border-white/20">
              {Math.floor(totalMinutes / 60) > 0 ? `${Math.floor(totalMinutes / 60)}h ` : ''}{totalMinutes % 60}m total
            </Badge>
          </div>
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => setShowKeyPoints(true)}
              className="w-8 h-8 text-white hover:bg-white/20">
              <Lightbulb className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={handleMuteToggle}
              className="w-8 h-8 text-white hover:bg-white/20">
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleFullscreen}
              className="w-8 h-8 text-white hover:bg-white/20">
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Overall progress bar at bottom of video */}
        <div className="absolute bottom-0 left-0 right-0 z-10">
          <div className="h-1 bg-white/20">
            <div className="h-full bg-primary transition-all duration-1000" style={{ width: `${overallProgress}%` }} />
          </div>
        </div>
      </div>

      {/* Control Bar */}
      <div className="bg-card border-t border-border px-4 py-3">
        {/* Chapter progress bar */}
        <div className="mb-3">
          <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
            <span className="font-medium text-foreground">{currentChapter?.title}</span>
            <span>{formatTime(elapsed)} / {currentChapter?.duration}</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden cursor-pointer" onClick={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const pct = (e.clientX - rect.left) / rect.width;
            setElapsed(Math.floor(pct * chapterDurationSecs));
            setChapterProgress(pct * 100);
          }}>
            <div className="h-full bg-primary rounded-full transition-all duration-300" style={{ width: `${chapterProgress}%` }} />
          </div>
        </div>

        {/* Controls row */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <Button variant="ghost" size="icon" onClick={() => selectChapter(Math.max(0, activeChapter - 1))}
              disabled={activeChapter === 0} className="hover:bg-primary/10">
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button size="icon" onClick={handlePlayPause}
              className="w-10 h-10 bg-primary hover:bg-primary/90">
              {loadingAudio ? <Loader2 className="w-4 h-4 animate-spin" /> : isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => selectChapter(Math.min(chapters.length - 1, activeChapter + 1))}
              disabled={activeChapter === chapters.length - 1} className="hover:bg-primary/10">
              <SkipForward className="w-4 h-4" />
            </Button>
            <span className="text-xs text-muted-foreground ml-2">
              Chapter {activeChapter + 1}/{chapters.length} · {completedChapters.size} watched
            </span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setShowChapterList(true)}
            className="text-xs gap-1 hover:bg-primary/10">
            <List className="w-3.5 h-3.5" />Chapters
          </Button>
        </div>
      </div>

      {/* Chapter Thumbnails Strip */}
      <div className="bg-background border-t border-border p-3">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin">
          {chapters.map((ch, idx) => (
            <button key={idx} onClick={() => selectChapter(idx)}
              className={`flex-shrink-0 flex flex-col items-center gap-1.5 p-2.5 rounded-xl border transition-all w-28 ${
                idx === activeChapter
                  ? 'border-primary/60 bg-primary/10'
                  : completedChapters.has(idx)
                  ? 'border-emerald-500/30 bg-emerald-500/5 hover:bg-emerald-500/10'
                  : 'border-border bg-card hover:bg-muted/50'
              }`}>
              <span className="text-xl">{ch.icon}</span>
              <p className="text-[10px] font-medium text-center leading-tight line-clamp-2">{ch.title}</p>
              <div className="flex items-center gap-1">
                <Clock className="w-2.5 h-2.5 text-muted-foreground" />
                <span className="text-[9px] text-muted-foreground">{ch.duration}</span>
                {completedChapters.has(idx) && <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Hidden audio element for AI narration */}
      <audio ref={audioRef} style={{ display: 'none' }} />

      {/* Loading indicator for audio */}
      {loadingAudio && (
        <div className="bg-background border-t border-border px-4 py-2 flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3 h-3 animate-spin text-primary" />
          <Mic className="w-3 h-3 text-primary" />
          Generating AI narration for this chapter...
        </div>
      )}

      {/* Overall progress */}
      <div className="bg-background border-t border-border px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Star className="w-3.5 h-3.5 text-primary" />
          <span>{completedChapters.size}/{chapters.length} chapters completed</span>
        </div>
        <div className="flex items-center gap-2 flex-1 mx-4">
          <Progress value={overallProgress} className="h-1.5 flex-1" />
          <span className="text-xs font-medium text-primary whitespace-nowrap">{Math.round(overallProgress)}%</span>
        </div>
        {completedChapters.size === chapters.length && (
          <Badge className="bg-emerald-500/20 text-emerald-600 border-emerald-500/30 text-xs">
            <CheckCircle2 className="w-3 h-3 mr-1" />Module Complete
          </Badge>
        )}
      </div>
    </div>
  );
}