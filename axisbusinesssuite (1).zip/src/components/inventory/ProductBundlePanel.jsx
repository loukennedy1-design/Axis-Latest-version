import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Plus, Layers, Trash2, X, Pencil } from 'lucide-react';
import { toast } from 'sonner';

export default function ProductBundlePanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ bundle_name: '', bundle_sku: '', description: '', bundle_price: 0, is_active: true, components: [] });

  const { data: bundles = [] } = useQuery({ queryKey: ['product-bundles'], queryFn: () => base44.entities.ProductBundle.list('-created_date', 100) });
  const { data: items = [] } = useQuery({ queryKey: ['inventory-items-simple'], queryFn: () => base44.entities.InventoryItem.list('-created_date', 200) });

  const save = useMutation({
    mutationFn: (data) => editing
      ? base44.entities.ProductBundle.update(editing.id, { ...data, components: JSON.stringify(data.components) })
      : base44.entities.ProductBundle.create({ ...data, components: JSON.stringify(data.components) }),
    onSuccess: () => { toast.success(editing ? 'Bundle updated' : 'Bundle created'); qc.invalidateQueries(['product-bundles']); setOpen(false); setEditing(null); setForm({ bundle_name: '', bundle_sku: '', description: '', bundle_price: 0, is_active: true, components: [] }); },
  });

  const del = useMutation({ mutationFn: (id) => base44.entities.ProductBundle.delete(id), onSuccess: () => { toast.success('Bundle deleted'); qc.invalidateQueries(['product-bundles']); } });

  const addComponent = (itemId) => {
    const item = items.find(i => i.id === itemId);
    if (!item) return;
    setForm({ ...form, components: [...form.components, { sku: item.sku, item_name: item.item_name, quantity: 1 }] });
  };

  const updateCompQty = (idx, qty) => {
    const comps = [...form.components]; comps[idx].quantity = Math.max(1, Number(qty)); setForm({ ...form, components: comps });
  };

  const removeComp = (idx) => setForm({ ...form, components: form.components.filter((_, i) => i !== idx) });

  const openEdit = (b) => {
    setEditing(b);
    let comps = [];
    try { comps = JSON.parse(b.components || '[]'); } catch (_) {}
    setForm({ bundle_name: b.bundle_name, bundle_sku: b.bundle_sku, description: b.description || '', bundle_price: b.bundle_price || 0, is_active: b.is_active, components: comps });
    setOpen(true);
  };

  const availableItems = items.filter(i => !form.components.find(c => c.sku === i.sku));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Product bundles — components auto-decrement on sale</p>
        <Button size="sm" onClick={() => { setEditing(null); setForm({ bundle_name: '', bundle_sku: '', description: '', bundle_price: 0, is_active: true, components: [] }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" />New Bundle</Button>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        {bundles.map(b => (
          <div key={b.id} className="p-4 rounded-lg border border-border bg-muted/20">
            <div className="flex items-start justify-between mb-2">
              <div>
                <p className="font-semibold text-sm">{b.bundle_name}</p>
                <p className="text-xs font-mono text-muted-foreground">{b.bundle_sku}</p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => openEdit(b)} className="p-1.5 hover:bg-muted rounded"><Pencil className="w-3.5 h-3.5" /></button>
                <button onClick={() => { if (confirm('Delete bundle?')) del.mutate(b.id); }} className="p-1.5 hover:bg-destructive/10 rounded text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
            {b.description && <p className="text-xs text-muted-foreground mb-2">{b.description}</p>}
            <div className="flex items-center justify-between">
              <Badge variant="outline">${(b.bundle_price || 0).toFixed(2)}</Badge>
              <Badge className={b.is_active ? 'bg-emerald-500/10 text-emerald-600' : 'bg-muted text-muted-foreground'}>{b.is_active ? 'Active' : 'Inactive'}</Badge>
            </div>
          </div>
        ))}
        {bundles.length === 0 && <div className="col-span-2 text-center py-12 text-muted-foreground"><Layers className="w-8 h-8 mx-auto mb-2 opacity-40" /><p>No bundles yet</p></div>}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Edit Bundle' : 'New Product Bundle'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Bundle Name *</Label><Input value={form.bundle_name} onChange={e => setForm({ ...form, bundle_name: e.target.value })} /></div>
              <div><Label>Bundle SKU *</Label><Input value={form.bundle_sku} onChange={e => setForm({ ...form, bundle_sku: e.target.value })} /></div>
            </div>
            <div><Label>Description</Label><Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
            <div><Label>Bundle Price</Label><Input type="number" step="0.01" value={form.bundle_price} onChange={e => setForm({ ...form, bundle_price: Number(e.target.value) })} /></div>
            <div className="flex items-center gap-2"><Switch checked={form.is_active} onCheckedChange={v => setForm({ ...form, is_active: v })} /><Label>Active</Label></div>

            <div className="border-t pt-3">
              <Label className="mb-2 block">Bundle Components</Label>
              {form.components.map((c, idx) => (
                <div key={idx} className="flex items-center gap-2 mb-2">
                  <span className="text-sm flex-1">{c.item_name} <span className="text-xs text-muted-foreground font-mono">{c.sku}</span></span>
                  <Input type="number" value={c.quantity} onChange={e => updateCompQty(idx, e.target.value)} className="w-16 h-7" />
                  <button onClick={() => removeComp(idx)} className="p-1 hover:bg-destructive/10 rounded text-destructive"><X className="w-3.5 h-3.5" /></button>
                </div>
              ))}
              {availableItems.length > 0 && (
                <select className="w-full text-sm border border-input rounded-md p-2 bg-transparent" onChange={e => { if (e.target.value) addComponent(e.target.value); e.target.value = ''; }}>
                  <option value="">+ Add component...</option>
                  {availableItems.map(i => <option key={i.id} value={i.id}>{i.item_name} ({i.sku})</option>)}
                </select>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate(form)} disabled={!form.bundle_name || !form.bundle_sku || form.components.length < 2}>{editing ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}