import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Plus, Minus, Trash2, ShoppingCart, CheckCircle2, Store, Package, Receipt } from 'lucide-react';
import { toast } from 'sonner';

export default function ManualSalePanel() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState({ name: '', email: '', phone: '' });
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [recentSales, setRecentSales] = useState([]);

  const { data: items = [] } = useQuery({
    queryKey: ['inventory-items'],
    queryFn: () => base44.entities.InventoryItem.list('-created_date', 200),
  });

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return items.filter(i =>
      i.status !== 'inactive' &&
      i.status !== 'discontinued' &&
      (!q || i.sku?.toLowerCase().includes(q) || i.item_name?.toLowerCase().includes(q))
    );
  }, [items, search]);

  const subtotal = useMemo(() =>
    cart.reduce((sum, c) => sum + (c.unit_price * c.quantity), 0), [cart]);
  const tax = Math.round(subtotal * 0.08 * 100) / 100;
  const total = Math.round((subtotal + tax) * 100) / 100;

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(c => c.item_id === item.id);
      if (existing) {
        return prev.map(c => c.item_id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      }
      return [...prev, {
        item_id: item.id,
        sku: item.sku,
        name: item.item_name,
        unit_price: item.store_price || item.unit_price || 0,
        quantity: 1,
        stock_on_hand: item.quantity_on_hand || 0,
      }];
    });
  };

  const updateQty = (itemId, delta) => {
    setCart(prev => prev.map(c => {
      if (c.item_id !== itemId) return c;
      const newQty = Math.max(1, c.quantity + delta);
      return { ...c, quantity: newQty };
    }));
  };

  const setPrice = (itemId, price) => {
    setCart(prev => prev.map(c => c.item_id === itemId ? { ...c, unit_price: price } : c));
  };

  const removeFromCart = (itemId) => setCart(prev => prev.filter(c => c.item_id !== itemId));

  const completeSale = useMutation({
    mutationFn: () => base44.functions.invoke('manualSale', {
      line_items: cart.map(c => ({ item_id: c.item_id, quantity: c.quantity, unit_price: c.unit_price })),
      customer: customer.email ? customer : null,
      payment_method: paymentMethod,
    }),
    onSuccess: (res) => {
      const data = res.data || res;
      toast.success(`Sale ${data.order_number} completed — $${(data.total || 0).toFixed(2)}`);
      setRecentSales(prev => [data, ...prev].slice(0, 5));
      setCart([]);
      setCustomer({ name: '', email: '', phone: '' });
      qc.invalidateQueries(['inventory-items']);
      qc.invalidateQueries(['inventory-kpis']);
    },
    onError: (err) => toast.error(err.response?.data?.error || err.message || 'Sale failed'),
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* Product Picker */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Package className="w-4 h-4 text-primary" />
            Select Products
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search by SKU or name..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <div className="max-h-[420px] overflow-y-auto space-y-1.5 pr-1">
            {filtered.map(item => {
              const inCart = cart.find(c => c.item_id === item.id);
              const lowStock = (item.quantity_on_hand || 0) <= 0;
              return (
                <button
                  key={item.id}
                  onClick={() => addToCart(item)}
                  disabled={lowStock}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg border text-left transition-colors ${lowStock ? 'border-border/50 opacity-50 cursor-not-allowed' : 'border-border hover:border-primary/40 hover:bg-primary/5'} ${inCart ? 'border-primary/40 bg-primary/5' : ''}`}
                >
                  {item.store_image_url ? (
                    <img src={item.store_image_url} alt="" className="w-10 h-10 rounded object-cover border border-border" />
                  ) : (
                    <div className="w-10 h-10 rounded bg-muted flex items-center justify-center">
                      <Package className="w-4 h-4 text-muted-foreground/50" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{item.item_name}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span className="font-mono">{item.sku}</span>
                      {item.color && <Badge variant="outline" className="text-[9px] px-1 py-0">{item.color}</Badge>}
                      {item.size && <span>{item.size}</span>}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-semibold text-primary">${(item.store_price || 0).toFixed(2)}</p>
                    <p className={`text-[10px] ${lowStock ? 'text-red-500' : 'text-muted-foreground'}`}>
                      {item.quantity_on_hand || 0} in stock
                    </p>
                  </div>
                  {inCart && <CheckCircle2 className="w-4 h-4 text-primary" />}
                </button>
              );
            })}
            {filtered.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                <p className="text-sm">No products found</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Cart + Checkout */}
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <ShoppingCart className="w-4 h-4 text-primary" />
            Current Sale
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Receipt className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-sm">Cart is empty — add products to start a sale</p>
            </div>
          ) : (
            <>
              <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                {cart.map(c => (
                  <div key={c.item_id} className="flex items-center gap-2 p-2 rounded-lg border border-border bg-muted/20">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{c.name}</p>
                      <p className="text-[10px] text-muted-foreground font-mono">{c.sku} · {c.stock_on_hand} in stock</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button onClick={() => updateQty(c.item_id, -1)} className="w-6 h-6 rounded flex items-center justify-center hover:bg-muted"><Minus className="w-3 h-3" /></button>
                      <span className="w-8 text-center text-sm font-medium">{c.quantity}</span>
                      <button onClick={() => updateQty(c.item_id, 1)} className="w-6 h-6 rounded flex items-center justify-center hover:bg-muted"><Plus className="w-3 h-3" /></button>
                    </div>
                    <Input
                      type="number"
                      step="0.01"
                      value={c.unit_price}
                      onChange={e => setPrice(c.item_id, Number(e.target.value))}
                      className="w-20 h-7 text-xs text-right"
                    />
                    <button onClick={() => removeFromCart(c.item_id)} className="p-1 hover:bg-destructive/10 rounded text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                ))}
              </div>

              <div className="border-t border-border pt-3 space-y-1.5 text-sm">
                <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between text-muted-foreground"><span>Tax (8%)</span><span>${tax.toFixed(2)}</span></div>
                <div className="flex justify-between font-bold text-base"><span>Total</span><span className="text-primary">${total.toFixed(2)}</span></div>
              </div>

              <div className="space-y-2 border-t border-border pt-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase">Customer (optional)</p>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Name" value={customer.name} onChange={e => setCustomer({ ...customer, name: e.target.value })} className="h-8 text-sm" />
                  <Input placeholder="Email" value={customer.email} onChange={e => setCustomer({ ...customer, email: e.target.value })} className="h-8 text-sm" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Input placeholder="Phone" value={customer.phone} onChange={e => setCustomer({ ...customer, phone: e.target.value })} className="h-8 text-sm" />
                  <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                    <SelectTrigger className="h-8 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['cash', 'card', 'square', 'converge', 'check', 'other'].map(m => (
                        <SelectItem key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={() => completeSale.mutate()} disabled={completeSale.isPending} className="w-full" size="lg">
                {completeSale.isPending ? <><Store className="w-4 h-4 mr-2 animate-pulse" />Processing...</> : <><CheckCircle2 className="w-4 h-4 mr-2" />Complete Sale — ${total.toFixed(2)}</>}
              </Button>
            </>
          )}

          {recentSales.length > 0 && (
            <div className="border-t border-border pt-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Recent Manual Sales</p>
              <div className="space-y-1.5">
                {recentSales.map((s, i) => (
                  <div key={i} className="flex items-center justify-between text-xs p-2 rounded bg-muted/20">
                    <div>
                      <span className="font-mono font-medium">{s.order_number}</span>
                      {s.points_earned > 0 && <Badge variant="secondary" className="ml-2 text-[9px]">+{s.points_earned} pts</Badge>}
                    </div>
                    <span className="font-semibold text-primary">${(s.total || 0).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="flex items-start gap-2 p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
            <Store className="w-3.5 h-3.5 text-emerald-500 mt-0.5 shrink-0" />
            <p className="text-[11px] text-muted-foreground">
              Manual sales automatically sync with your storefront inventory — stock levels decrement in real-time across both channels.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}