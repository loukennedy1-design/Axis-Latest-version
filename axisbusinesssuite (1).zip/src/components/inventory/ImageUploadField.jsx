import React, { useRef, useState } from 'react';
import { Upload, Link as LinkIcon, X, Image as ImageIcon } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function ImageUploadField({ value, onChange }) {
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [mode, setMode] = useState(value ? 'preview' : 'choose');

  const handleFile = async (file) => {
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be under 5MB');
      return;
    }
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      toast.error('Only JPG, PNG, and WebP are supported');
      return;
    }

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onChange(file_url);
      setMode('preview');
      toast.success('Image uploaded');
    } catch (e) {
      toast.error('Upload failed: ' + e.message);
    }
    setUploading(false);
  };

  const handleUrlSubmit = (url) => {
    if (url) {
      onChange(url);
      setMode('preview');
    }
  };

  if (mode === 'preview' && value) {
    return (
      <div className="space-y-2">
        <div className="relative w-full max-w-xs rounded-lg overflow-hidden border border-border bg-muted/20">
          <img src={value} alt="Preview" className="w-full h-40 object-cover" />
          <button
            onClick={() => { onChange(''); setMode('choose'); }}
            className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <Button variant="outline" size="sm" onClick={() => setMode('choose')}>
          Change Image
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {mode === 'choose' ? (
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setMode('url')} className="flex-1">
            <LinkIcon className="w-3.5 h-3.5 mr-1.5" /> Paste URL
          </Button>
          <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading} className="flex-1">
            <Upload className="w-3.5 h-3.5 mr-1.5" /> {uploading ? 'Uploading...' : 'Upload Image'}
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={e => handleFile(e.target.files?.[0])}
          />
        </div>
      ) : (
        <div className="flex gap-2">
          <Input
            placeholder="https://example.com/image.jpg"
            onKeyDown={e => { if (e.key === 'Enter') handleUrlSubmit(e.target.value); }}
            autoFocus
          />
          <Button size="sm" onClick={e => handleUrlSubmit(e.currentTarget.previousElementSibling.value)}>Save</Button>
          <Button variant="outline" size="sm" onClick={() => setMode('choose')}>Cancel</Button>
        </div>
      )}
      {!value && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <ImageIcon className="w-3 h-3" />
          <span>No image set — URL or file upload</span>
        </div>
      )}
    </div>
  );
}