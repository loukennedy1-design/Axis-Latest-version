import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Pencil, Plus, Trash2, Search, Package, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import ImageUploadField from '@/components/inventory/ImageUploadField';

const empty = { sku: '', item_name: '', category: '', color: '', size: '', variant: '', quantity_on_hand: 0, quantity_reserved: 0, reorder_threshold: 0, unit_cost: 0, store_price: 0, supplier_name: '', location: '', is_bundle: false, storefront_visible: false, store_description: '', store_image_url: '', status: 'active' };

export default function InventoryItemsPanel() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const { data: items = [] } = useQuery({ queryKey: ['inventory-items'], queryFn: () => base44.entities.InventoryItem.list('-created_date', 200) });

  const save = useMutation({
    mutationFn: (data) => editing ? base44.entities.InventoryItem.update(editing.id, data) : base44.entities.InventoryItem.create(data),
    onSuccess: () => { toast.success(editing ? 'Item updated' : 'Item created'); qc.invalidateQueries(['inventory-items']); setOpen(false); setForm(empty); setEditing(null); },
  });

  const del = useMutation({ mutationFn: (id) => base44.entities.InventoryItem.delete(id), onSuccess: () => { toast.success('Item deleted'); qc.invalidateQueries(['inventory-items']); } });

  const filtered = items.filter(i => !search || i.sku?.toLowerCase().includes(search.toLowerCase()) || i.item_name?.toLowerCase().includes(search.toLowerCase()) || i.color?.toLowerCase().includes(search.toLowerCase()) || i.size?.toLowerCase().includes(search.toLowerCase()));

  const openEdit = (item) => { setEditing(item); setForm({ ...empty, ...item }); setOpen(true); };
  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search SKU or name..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Button onClick={openNew} size="sm"><Plus className="w-4 h-4 mr-1" />Add Item</Button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase">
            <tr>
              <th className="text-left p-3">Image</th>
              <th className="text-left p-3">SKU</th>
              <th className="text-left p-3">Name</th>
              <th className="text-left p-3">Color</th>
              <th className="text-left p-3">Size</th>
              <th className="text-right p-3">On Hand</th>
              <th className="text-right p-3">Reserved</th>
              <th className="text-right p-3">Reorder Thresh.</th>
              <th className="text-right p-3">Store Price</th>
              <th className="text-center p-3">Storefront</th>
              <th className="text-center p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(item => {
              const lowStock = (item.quantity_on_hand || 0) <= (item.reorder_threshold || 0);
              return (
                <tr key={item.id} className={`border-t border-border hover:bg-muted/20 ${lowStock ? 'bg-red-500/5' : ''}`}>
                  <td className="p-3">
                    {item.store_image_url ? (
                      <img src={item.store_image_url} alt={item.item_name} className="w-12 h-12 rounded-lg object-cover border border-border" />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                        <Package className="w-4 h-4 text-muted-foreground/50" />
                      </div>
                    )}
                  </td>
                  <td className="p-3 font-mono text-xs">{item.sku}</td>
                  <td className="p-3">{item.item_name}{item.is_bundle && <Badge variant="secondary" className="ml-2 text-[10px]">Bundle</Badge>}</td>
                  <td className="p-3">{item.color ? <Badge variant="outline" className="text-[10px]">{item.color}</Badge> : <span className="text-muted-foreground/40">—</span>}</td>
                  <td className="p-3">{item.size || <span className="text-muted-foreground/40">—</span>}</td>
                  <td className="p-3 text-right">
                    <span className={lowStock ? 'text-red-500 font-bold' : ''}>{item.quantity_on_hand}</span>
                    {lowStock && <AlertTriangle className="inline w-3.5 h-3.5 text-red-500 ml-1" />}
                  </td>
                  <td className="p-3 text-right text-muted-foreground">{item.quantity_reserved || 0}</td>
                  <td className="p-3 text-right text-muted-foreground">{item.reorder_threshold || 0}</td>
                  <td className="p-3 text-right">${(item.store_price || 0).toFixed(2)}</td>
                  <td className="p-3 text-center">{item.storefront_visible ? <Badge className="bg-emerald-500/10 text-emerald-600 text-[10px]">Visible</Badge> : <Badge variant="outline" className="text-[10px]">Hidden</Badge>}</td>
                  <td className="p-3 text-center">
                    <button onClick={() => openEdit(item)} className="p-1.5 hover:bg-muted rounded"><Pencil className="w-3.5 h-3.5" /></button>
                    <button onClick={() => { if (confirm('Delete this item?')) del.mutate(item.id); }} className="p-1.5 hover:bg-destructive/10 rounded text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && <tr><td colSpan={11} className="p-8 text-center text-muted-foreground"><Package className="w-8 h-8 mx-auto mb-2 opacity-40" />No items found</td></tr>}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Edit Item' : 'New Inventory Item'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>SKU *</Label><Input value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} /></div>
            <div><Label>Item Name *</Label><Input value={form.item_name} onChange={e => setForm({ ...form, item_name: e.target.value })} /></div>
            <div><Label>Category</Label><Input value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} /></div>
            <div><Label>Color</Label><Input value={form.color} onChange={e => setForm({ ...form, color: e.target.value })} placeholder="e.g. Red, Blue" /></div>
            <div><Label>Size</Label><Input value={form.size} onChange={e => setForm({ ...form, size: e.target.value })} placeholder="e.g. S, M, L, XL" /></div>
            <div><Label>Variant</Label><Input value={form.variant} onChange={e => setForm({ ...form, variant: e.target.value })} placeholder="Flavor, style, etc." /></div>
            <div><Label>Location</Label><Input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} /></div>
            <div><Label>Qty On Hand</Label><Input type="number" value={form.quantity_on_hand} onChange={e => setForm({ ...form, quantity_on_hand: Number(e.target.value) })} /></div>
            <div><Label>Reorder Threshold</Label><Input type="number" value={form.reorder_threshold} onChange={e => setForm({ ...form, reorder_threshold: Number(e.target.value) })} /></div>
            <div><Label>Unit Cost</Label><Input type="number" step="0.01" value={form.unit_cost} onChange={e => setForm({ ...form, unit_cost: Number(e.target.value) })} /></div>
            <div><Label>Store Price</Label><Input type="number" step="0.01" value={form.store_price} onChange={e => setForm({ ...form, store_price: Number(e.target.value) })} /></div>
            <div className="col-span-2"><Label>Supplier Name</Label><Input value={form.supplier_name} onChange={e => setForm({ ...form, supplier_name: e.target.value })} /></div>
            <div className="col-span-2"><Label>Store Description</Label><Input value={form.store_description} onChange={e => setForm({ ...form, store_description: e.target.value })} /></div>
            <div className="col-span-2">
              <Label>Product Image</Label>
              <div className="mt-1">
                <ImageUploadField value={form.store_image_url || ''} onChange={(url) => setForm({ ...form, store_image_url: url })} />
              </div>
            </div>
            <div className="flex items-center gap-2"><Switch checked={form.is_bundle} onCheckedChange={v => setForm({ ...form, is_bundle: v })} /><Label>Is Bundle</Label></div>
            <div className="flex items-center gap-2"><Switch checked={form.storefront_visible} onCheckedChange={v => setForm({ ...form, storefront_visible: v })} /><Label>Visible on Storefront</Label></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => save.mutate(form)} disabled={!form.sku || !form.item_name}>{editing ? 'Update' : 'Create'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}