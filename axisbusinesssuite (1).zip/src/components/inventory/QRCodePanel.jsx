import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { QrCode, Download, Copy, ExternalLink, Store } from 'lucide-react';
import { toast } from 'sonner';

function slugify(text) {
  if (!text) return '';
  return text.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-');
}

export default function QRCodePanel() {
  const { data: settings } = useQuery({ queryKey: ['system-settings'], queryFn: () => base44.entities.SystemSettings.list('-created_date', 1) });
  const companyName = settings?.[0]?.company_name || '';
  const [slug, setSlug] = useState('');

  useEffect(() => {
    if (companyName && !slug) setSlug(slugify(companyName));
  }, [companyName]);

  const storefrontUrl = slug ? `${window.location.origin}/${slug}` : '';
  const qrImageUrl = storefrontUrl ? `https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(storefrontUrl)}` : '';

  const downloadQR = async () => {
    if (!qrImageUrl) return;
    try {
      const response = await fetch(qrImageUrl);
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${slug}-storefront-qr.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('QR code downloaded as PNG');
    } catch (e) {
      toast.error('Download failed — right-click the image to save instead');
    }
  };

  const copyUrl = () => { navigator.clipboard.writeText(storefrontUrl); toast.success('Storefront URL copied'); };

  return (
    <div className="space-y-6 max-w-2xl">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start gap-2 mb-4">
            <Store className="w-5 h-5 text-primary" />
            <div>
              <h3 className="font-semibold">Public Storefront QR Code</h3>
              <p className="text-sm text-muted-foreground">Customers scan this QR to visit your public storefront</p>
            </div>
          </div>

          <div className="space-y-3">
            <div>
              <Label>Company Name</Label>
              <Input value={companyName} readOnly className="bg-muted/30" />
              <p className="text-xs text-muted-foreground mt-1">Derived from System Settings</p>
            </div>
            <div>
              <Label>Storefront Slug</Label>
              <Input value={slug} onChange={e => setSlug(slugify(e.target.value))} />
              <p className="text-xs text-muted-foreground mt-1">Auto-generated from company name (lowercase, hyphens)</p>
            </div>
            <div>
              <Label>Public Storefront URL</Label>
              <div className="flex gap-2">
                <Input value={storefrontUrl} readOnly className="bg-muted/30 font-mono text-xs" />
                <Button variant="outline" size="icon" onClick={copyUrl}><Copy className="w-4 h-4" /></Button>
              </div>
            </div>
          </div>

          {qrImageUrl && (
            <div className="mt-6 flex flex-col items-center gap-4">
              <div className="p-4 rounded-2xl border-2 border-border bg-white">
                <img src={qrImageUrl} alt="Storefront QR Code" width={250} height={250} className="rounded-lg" />
              </div>
              <div className="flex gap-2">
                <Button onClick={downloadQR}><Download className="w-4 h-4 mr-2" />Download PNG</Button>
                <Button variant="outline" onClick={() => window.open(storefrontUrl, '_blank')}><ExternalLink className="w-4 h-4 mr-2" />Open Storefront</Button>
              </div>
            </div>
          )}

          {!companyName && (
            <div className="mt-4 p-4 rounded-lg bg-amber-500/10 border border-amber-500/20 text-sm text-amber-600">
              <QrCode className="w-4 h-4 inline mr-2" />
              Set your company name in System Settings to generate a QR code.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}