import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Factory, Plus, Loader2, ArrowRight, ArrowLeft, X, Package, Clock, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import ProductionTicketDrawer from '@/components/inventory/ProductionTicketDrawer';

const STAGES = [
  { key: 'po_procurement', label: 'PO / Procurement', icon: Package },
  { key: 'materials_received', label: 'Materials Received', icon: Package },
  { key: 'build_assembly', label: 'Build / Assembly', icon: Factory },
  { key: 'qc', label: 'QC', icon: CheckCircle2 },
  { key: 'packaging', label: 'Packaging', icon: Package },
  { key: 'fulfillment', label: 'Fulfillment', icon: Package },
  { key: 'delivered', label: 'Delivered', icon: CheckCircle2 },
];

const emptyForm = {
  product_name: '', sku: '', quantity: 1, due_date: '',
  supplier_name: '', priority: 'medium', notes: '', bom_raw: ''
};

export default function ProductionPipelinePanel() {
  const qc = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [drawerOpen, setDrawerOpen] = useState(false);

  const { data: tickets = [] } = useQuery({
    queryKey: ['production-tickets-pipeline'],
    queryFn: () => base44.entities.ProductionTicket.list('-created_date', 100)
  });

  const createTicket = useMutation({
    mutationFn: (payload) => base44.functions.invoke('productionFulfillmentManagement', payload),
    onSuccess: () => { toast.success('Production ticket created'); qc.invalidateQueries(['production-tickets-pipeline']); setCreateOpen(false); setForm(emptyForm); },
    onError: (e) => toast.error('Failed: ' + e.message),
  });

  const advanceStage = useMutation({
    mutationFn: ({ ticket_id, direction, reason_note }) =>
      base44.functions.invoke('productionFulfillmentManagement', { action: 'advance_stage', ticket_id, direction, reason_note }),
    onSuccess: () => { toast.success('Stage updated'); qc.invalidateQueries(['production-tickets-pipeline']); },
    onError: (e) => toast.error('Failed: ' + e.message),
  });

  const handleCreate = () => {
    // Parse BOM from raw text: "SKU:Item Name:Qty" per line
    let bomJson = '[]';
    if (form.bom_raw.trim()) {
      const bom = form.bom_raw.trim().split('\n').map(line => {
        const parts = line.split(':');
        return { sku: parts[0]?.trim() || '', item_name: parts[1]?.trim() || '', qty_required: Number(parts[2]?.trim()) || 1 };
      }).filter(b => b.sku);
      bomJson = JSON.stringify(bom);
    }

    createTicket.mutate({
      action: 'create_ticket',
      product_name: form.product_name,
      sku: form.sku,
      quantity: Number(form.quantity) || 1,
      due_date: form.due_date,
      supplier_name: form.supplier_name,
      priority: form.priority,
      notes: form.notes,
      bom_json: bomJson,
    });
  };

  const openTicket = (ticket) => {
    setSelectedTicket(ticket);
    setDrawerOpen(true);
  };

  const priorityColors = {
    low: 'bg-gray-500/10 text-gray-500',
    medium: 'bg-blue-500/10 text-blue-600',
    high: 'bg-amber-500/10 text-amber-600',
    urgent: 'bg-red-500/10 text-red-600',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Factory className="w-4 h-4" /> Production Pipeline
        </h3>
        <Button size="sm" onClick={() => setCreateOpen(true)}>
          <Plus className="w-4 h-4 mr-1" /> New Production Job
        </Button>
      </div>

      {/* Pipeline board */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {tickets.map(ticket => {
          const stageIdx = STAGES.findIndex(s => s.key === (ticket.current_stage || 'po_procurement'));
          return (
            <div
              key={ticket.id}
              className="rounded-xl border border-border bg-card p-4 space-y-3 cursor-pointer hover:border-primary/40 transition-colors"
              onClick={() => openTicket(ticket)}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-sm">{ticket.product_name}</p>
                  <p className="text-xs text-muted-foreground font-mono">{ticket.ticket_number}</p>
                </div>
                <Badge className={`text-[10px] ${priorityColors[ticket.priority] || priorityColors.medium}`}>
                  {ticket.priority}
                </Badge>
              </div>

              {/* Stage stepper */}
              <div className="flex items-center gap-0.5">
                {STAGES.map((stage, idx) => {
                  const isCompleted = idx < stageIdx;
                  const isCurrent = idx === stageIdx;
                  const StageIcon = stage.icon;
                  return (
                    <div key={stage.key} className="flex items-center flex-1 last:flex-none">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-all ${
                          isCompleted ? 'bg-emerald-500/20 text-emerald-500' :
                          isCurrent ? 'bg-blue-500/20 text-blue-400 ring-2 ring-blue-500/30 animate-pulse' :
                          'bg-muted text-muted-foreground/40'
                        }`}
                      >
                        <StageIcon className="w-3 h-3" />
                      </div>
                      {idx < STAGES.length - 1 && (
                        <div className={`h-0.5 flex-1 ${isCompleted ? 'bg-emerald-500/30' : 'bg-muted'}`} />
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">
                  Stage {stageIdx + 1}/7: <span className="font-medium text-foreground">{STAGES[stageIdx]?.label}</span>
                </span>
                <span className="text-muted-foreground">Qty: {ticket.quantity}</span>
              </div>

              {ticket.due_date && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Clock className="w-3 h-3" /> Due {format(new Date(ticket.due_date), 'MMM d')}
                </div>
              )}

              {/* Quick advance button */}
              {ticket.current_stage !== 'delivered' && (
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full h-7 text-xs"
                  onClick={(e) => {
                    e.stopPropagation();
                    advanceStage.mutate({ ticket_id: ticket.id, direction: 'forward' });
                  }}
                  disabled={advanceStage.isLoading}
                >
                  {advanceStage.isLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <ArrowRight className="w-3 h-3 mr-1" />}
                  Advance to {STAGES[stageIdx + 1]?.label}
                </Button>
              )}
            </div>
          );
        })}
        {tickets.length === 0 && (
          <div className="col-span-full p-8 text-center text-muted-foreground border border-dashed rounded-xl">
            <Factory className="w-8 h-8 mx-auto mb-2 opacity-40" />
            No production jobs yet — click "New Production Job" to start
          </div>
        )}
      </div>

      {/* Create dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Production Job</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2"><Label>Product Name *</Label><Input value={form.product_name} onChange={e => setForm({ ...form, product_name: e.target.value })} /></div>
            <div><Label>SKU</Label><Input value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} /></div>
            <div><Label>Quantity</Label><Input type="number" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} /></div>
            <div><Label>Due Date</Label><Input type="date" value={form.due_date} onChange={e => setForm({ ...form, due_date: e.target.value })} /></div>
            <div><Label>Supplier Name</Label><Input value={form.supplier_name} onChange={e => setForm({ ...form, supplier_name: e.target.value })} /></div>
            <div>
              <Label>Priority</Label>
              <Select value={form.priority} onValueChange={v => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label>Bill of Materials (BOM)</Label>
              <Textarea
                placeholder="One per line: SKU:Item Name:Qty&#10;e.g. WIRE-001:Copper Wire:10&#10;SCREW-004:Steel Screws:24"
                value={form.bom_raw}
                onChange={e => setForm({ ...form, bom_raw: e.target.value })}
                className="font-mono text-xs"
                rows={4}
              />
              <p className="text-[10px] text-muted-foreground mt-1">Format: SKU:Item Name:Qty (one per line)</p>
            </div>
            <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={!form.product_name || createTicket.isLoading}>
              {createTicket.isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Create Job'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Ticket detail drawer */}
      {selectedTicket && (
        <ProductionTicketDrawer
          ticket={selectedTicket}
          open={drawerOpen}
          onOpenChange={setDrawerOpen}
          stages={STAGES}
        />
      )}
    </div>
  );
}