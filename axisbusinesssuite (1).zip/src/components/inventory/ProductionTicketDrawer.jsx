import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, ArrowLeft, Loader2, History, Package } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const stageColors = {
  po_procurement: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  materials_received: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/30',
  build_assembly: 'bg-blue-500/10 text-blue-600 border-blue-500/30',
  qc: 'bg-purple-500/10 text-purple-600 border-purple-500/30',
  packaging: 'bg-indigo-500/10 text-indigo-600 border-indigo-500/30',
  fulfillment: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/30',
  delivered: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
};

export default function ProductionTicketDrawer({ ticket, open, onOpenChange, stages }) {
  const qc = useQueryClient();
  const [reasonNote, setReasonNote] = useState('');

  // Fetch stage history
  const { data: historyData } = useQuery({
    queryKey: ['stage-history', ticket.id],
    queryFn: () => base44.entities.ProductionStageLog.filter({ ticket_id: ticket.id }),
    enabled: open && !!ticket.id,
  });

  // Fetch fresh ticket data
  const { data: freshTicket } = useQuery({
    queryKey: ['production-ticket', ticket.id],
    queryFn: () => base44.entities.ProductionTicket.get(ticket.id),
    enabled: open && !!ticket.id,
  });

  const currentTicket = freshTicket || ticket;
  const stageHistory = historyData || [];
  const currentStage = currentTicket.current_stage || 'po_procurement';
  const stageIdx = stages.findIndex(s => s.key === currentStage);

  const advance = useMutation({
    mutationFn: ({ direction }) =>
      base44.functions.invoke('productionFulfillmentManagement', {
        action: 'advance_stage',
        ticket_id: currentTicket.id,
        direction,
        reason_note: reasonNote
      }),
    onSuccess: () => {
      toast.success('Stage updated');
      qc.invalidateQueries(['stage-history', currentTicket.id]);
      qc.invalidateQueries(['production-ticket', currentTicket.id]);
      qc.invalidateQueries(['production-tickets-pipeline']);
      setReasonNote('');
    },
    onError: (e) => toast.error('Failed: ' + e.message),
  });

  // Parse BOM
  let bom = [];
  try { bom = currentTicket.bom_json ? JSON.parse(currentTicket.bom_json) : []; } catch {}

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-xl overflow-y-auto">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            {currentTicket.ticket_number}
          </SheetTitle>
          <p className="text-sm text-muted-foreground">{currentTicket.product_name}</p>
        </SheetHeader>

        <div className="mt-6 space-y-6">
          {/* ── Horizontal Stage Stepper ── */}
          <div>
            <Label className="text-xs uppercase tracking-wide text-muted-foreground">Production Pipeline</Label>
            <div className="mt-3 flex items-center gap-0.5 overflow-x-auto pb-2">
              {stages.map((stage, idx) => {
                const isCompleted = idx < stageIdx;
                const isCurrent = idx === stageIdx;
                const StageIcon = stage.icon;
                return (
                  <div key={stage.key} className="flex items-center shrink-0">
                    <div className="flex flex-col items-center gap-1 w-16">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                          isCompleted ? 'bg-emerald-500/20 text-emerald-500' :
                          isCurrent ? 'bg-blue-500/20 text-blue-400 ring-2 ring-blue-500/40 animate-pulse' :
                          'bg-muted text-muted-foreground/40'
                        }`}
                      >
                        <StageIcon className="w-4 h-4" />
                      </div>
                      <span className={`text-[9px] text-center leading-tight ${isCurrent ? 'font-bold text-foreground' : 'text-muted-foreground'}`}>
                        {stage.label}
                      </span>
                    </div>
                    {idx < stages.length - 1 && (
                      <div className={`w-3 h-0.5 mx-0.5 ${isCompleted ? 'bg-emerald-500/40' : 'bg-muted'}`} />
                    )}
                  </div>
                );
              })}
            </div>
            <div className="mt-2">
              <Badge className={stageColors[currentStage]}>
                Stage {stageIdx + 1} of {stages.length}: {stages[stageIdx]?.label}
              </Badge>
            </div>
          </div>

          {/* ── Ticket Details ── */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-xs text-muted-foreground">Quantity</span><p className="font-medium">{currentTicket.quantity}</p></div>
            <div><span className="text-xs text-muted-foreground">Priority</span><p className="font-medium capitalize">{currentTicket.priority}</p></div>
            <div><span className="text-xs text-muted-foreground">Supplier</span><p className="font-medium">{currentTicket.supplier_name || '—'}</p></div>
            <div><span className="text-xs text-muted-foreground">Due Date</span><p className="font-medium">{currentTicket.due_date ? format(new Date(currentTicket.due_date), 'MMM d, yyyy') : '—'}</p></div>
            <div><span className="text-xs text-muted-foreground">Materials Reserved</span><p className="font-medium">{currentTicket.materials_reserved ? '✅ Yes' : '❌ No'}</p></div>
            <div><span className="text-xs text-muted-foreground">SKU</span><p className="font-mono text-xs">{currentTicket.sku || '—'}</p></div>
          </div>

          {/* ── BOM ── */}
          {bom.length > 0 && (
            <div>
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Bill of Materials</Label>
              <div className="mt-2 rounded-lg border border-border overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-muted/50 text-xs uppercase">
                    <tr>
                      <th className="text-left p-2">SKU</th>
                      <th className="text-left p-2">Item</th>
                      <th className="text-right p-2">Qty Required</th>
                    </tr>
                  </thead>
                  <tbody>
                    {bom.map((b, i) => (
                      <tr key={i} className="border-t border-border">
                        <td className="p-2 font-mono text-xs">{b.sku}</td>
                        <td className="p-2">{b.item_name}</td>
                        <td className="p-2 text-right">{b.qty_required} × {currentTicket.quantity}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── Notes ── */}
          {currentTicket.notes && (
            <div>
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Notes</Label>
              <p className="mt-1 text-sm bg-muted/30 rounded-lg p-3">{currentTicket.notes}</p>
            </div>
          )}

          {/* ── Stage Controls ── */}
          {currentStage !== 'delivered' && (
            <div className="space-y-3 rounded-xl border border-border p-4 bg-card">
              <Label className="text-xs uppercase tracking-wide text-muted-foreground">Advance Stage</Label>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => advance.mutate({ direction: 'forward' })}
                  disabled={advance.isLoading}
                >
                  {advance.isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4 mr-1" />}
                  Advance to {stages[stageIdx + 1]?.label}
                </Button>
                {stageIdx > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => advance.mutate({ direction: 'backward' })}
                    disabled={advance.isLoading}
                  >
                    <ArrowLeft className="w-4 h-4 mr-1" /> Move Back
                  </Button>
                )}
              </div>
              <div>
                <Label className="text-xs">Reason Note (required for backward moves)</Label>
                <Input
                  value={reasonNote}
                  onChange={e => setReasonNote(e.target.value)}
                  placeholder="e.g. QC failed, returning to build stage"
                  className="mt-1"
                />
              </div>
            </div>
          )}

          {/* ── Stage History Log ── */}
          <div>
            <Label className="text-xs uppercase tracking-wide text-muted-foreground flex items-center gap-1">
              <History className="w-3 h-3" /> Stage History
            </Label>
            <div className="mt-2 space-y-2">
              {stageHistory.map((log, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded-lg bg-muted/20 text-xs">
                  <div className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{log.from_stage || 'Created'} → {log.to_stage}</span>
                    </div>
                    {log.reason_note && <p className="text-muted-foreground mt-0.5">{log.reason_note}</p>}
                    <p className="text-muted-foreground mt-0.5">
                      {log.changed_by} · {log.changed_at ? format(new Date(log.changed_at), 'MMM d, h:mm a') : ''}
                    </p>
                  </div>
                </div>
              ))}
              {stageHistory.length === 0 && (
                <p className="text-xs text-muted-foreground">No stage transitions recorded yet.</p>
              )}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}