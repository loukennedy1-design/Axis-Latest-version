import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeftRight, Search } from 'lucide-react';

const typeConfig = {
  receipt: 'bg-emerald-500/10 text-emerald-600',
  shipment: 'bg-blue-500/10 text-blue-600',
  adjustment: 'bg-amber-500/10 text-amber-600',
  transfer: 'bg-purple-500/10 text-purple-600',
  scrap: 'bg-red-500/10 text-red-600',
  return: 'bg-cyan-500/10 text-cyan-600',
};

export default function StockMovementPanel() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const { data: movements = [] } = useQuery({ queryKey: ['stock-movements'], queryFn: () => base44.entities.StockMovement.list('-movement_date', 200) });

  const filtered = movements.filter(m =>
    (!search || m.sku?.toLowerCase().includes(search.toLowerCase()) || m.product_name?.toLowerCase().includes(search.toLowerCase())) &&
    (typeFilter === 'all' || m.movement_type === typeFilter)
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search SKU or product..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="receipt">Receipts</SelectItem>
            <SelectItem value="shipment">Shipments</SelectItem>
            <SelectItem value="adjustment">Adjustments</SelectItem>
            <SelectItem value="transfer">Transfers</SelectItem>
            <SelectItem value="scrap">Scrap</SelectItem>
            <SelectItem value="return">Returns</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase">
            <tr>
              <th className="text-left p-3">Date</th>
              <th className="text-left p-3">SKU</th>
              <th className="text-left p-3">Product</th>
              <th className="text-center p-3">Type</th>
              <th className="text-right p-3">Qty</th>
              <th className="text-right p-3">Before → After</th>
              <th className="text-left p-3">Reason</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.id} className="border-t border-border hover:bg-muted/20">
                <td className="p-3 text-xs text-muted-foreground">{m.movement_date ? new Date(m.movement_date).toLocaleString('en-US', { dateStyle: 'short', timeStyle: 'short' }) : '—'}</td>
                <td className="p-3 font-mono text-xs">{m.sku}</td>
                <td className="p-3">{m.product_name}</td>
                <td className="p-3 text-center"><Badge className={typeConfig[m.movement_type] || 'bg-muted text-muted-foreground'}>{m.movement_type}</Badge></td>
                <td className="p-3 text-right font-semibold">{m.quantity}</td>
                <td className="p-3 text-right text-xs text-muted-foreground">{m.quantity_before} → {m.quantity_after}</td>
                <td className="p-3 text-xs text-muted-foreground max-w-xs truncate">{m.reason || '—'}</td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground"><ArrowLeftRight className="w-8 h-8 mx-auto mb-2 opacity-40" />No movements recorded</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}