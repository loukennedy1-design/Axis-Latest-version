import React, { useState, useRef, useMemo } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Upload, FileSpreadsheet, CheckCircle2, AlertCircle, Loader2, Download, Package, Table, Sparkles, Zap, Clock, Bot } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { toast } from 'sonner';

// ── CSV type definitions with field aliases for auto-detection ──────────────
const CSV_TYPES = [
  {
    id: 'inventory',
    label: 'Inventory Items',
    entity: 'InventoryItem',
    icon: 'Package',
    requiredField: 'item_name',
    aliases: {
      item_name: ['name', 'item_name', 'product_name', 'product', 'item', 'product_family', 'product title', 'title'],
      sku: ['sku', 'item_number', 'product_code', 'item_code', 'part_number', 'sku_number', 'barcode', 'upc', 'gtin', 'ean'],
      category: ['category', 'type', 'item_type', 'product_category', 'level', 'family'],
      color: ['color', 'colour', 'product_color', 'shade', 'tint'],
      size: ['size', 'product_size', 'dimensions', 'dimension'],
      variant: ['variant', 'flavor', 'flavour', 'style', 'material', 'model', 'option'],
      description: ['description', 'sales_description', 'item_description', 'desc', 'pack_info', 'pack info', 'packaging', 'pack size', 'pack_size'],
      unit_cost: ['cost', 'unit_cost', 'purchase_cost', 'cost_price', 'case_price', 'case cost'],
      store_price: ['price', 'store_price', 'unit_price', 'sales_price', 'sales_rate', 'rate', 'display_price', 'display price', 'oos_display', 'nv_display', 'nv display', 'oos display', 'retail_price', 'retail price'],
      quantity_on_hand: ['qty_on_hand', 'quantity_on_hand', 'quantity', 'stock', 'on_hand', 'quantity_available', 'qty', 'count', 'in_stock'],
      reorder_point: ['reorder_point', 'reorder', 'min_stock', 'reorder_threshold', 'min_qty', 'reorder_level'],
      unit_of_measure: ['uom', 'unit_of_measure', 'unit'],
      location: ['location', 'warehouse', 'bin', 'shelf'],
      supplier_name: ['supplier', 'supplier_name', 'vendor', 'vendor_name'],
      store_description: ['store_description', 'marketing_description', 'store_desc'],
      notes: ['notes', 'comments', 'additional_info', 'extra', 'misc', 'flavor', 'variant'],
    },
    defaults: { status: 'active', unit_of_measure: 'each' },
    numericFields: ['quantity_on_hand', 'reorder_point', 'unit_cost', 'store_price'],
    // Only these numeric fields are currency — quantities are plain counts
    currencyFields: ['unit_cost', 'store_price'],
    previewCols: ['sku', 'item_name', 'quantity_on_hand', 'reorder_point', 'unit_cost', 'store_price'],
    templateHeaders: ['SKU', 'Item Name', 'Category', 'Quantity On Hand', 'Reorder Point', 'Unit Cost', 'Store Price', 'Location', 'Supplier Name'],
    templateRow: 'DEMO-001,Demo Product,Electronics,100,20,5.00,12.99,Aisle A,Acme Corp',
  },
  {
    id: 'bundles',
    label: 'Product Bundles',
    entity: 'ProductBundle',
    icon: 'Layers',
    requiredField: 'bundle_name',
    aliases: {
      bundle_name: ['bundle_name', 'name', 'product_name', 'bundle', 'title', 'kit_name'],
      bundle_sku: ['bundle_sku', 'sku', 'bundle_code', 'code', 'kit_sku'],
      description: ['description', 'desc', 'details'],
      bundle_price: ['bundle_price', 'price', 'cost', 'amount', 'sale_price'],
      store_image_url: ['store_image_url', 'image_url', 'image', 'photo', 'picture', 'img'],
    },
    defaults: { is_active: true },
    numericFields: ['bundle_price'],
    currencyFields: ['bundle_price'],
    previewCols: ['bundle_name', 'bundle_sku', 'bundle_price'],
    templateHeaders: ['Bundle Name', 'Bundle SKU', 'Description', 'Bundle Price', 'Image URL'],
    templateRow: 'Starter Kit,BUNDLE-001,Complete starter package,49.99,https://example.com/image.jpg',
  },
  {
    id: 'suppliers',
    label: 'Suppliers / Vendors',
    entity: 'Supplier',
    icon: 'Truck',
    requiredField: 'supplier_name',
    aliases: {
      supplier_name: ['supplier_name', 'vendor_name', 'supplier', 'vendor', 'company', 'name'],
      contact_name: ['contact_name', 'contact', 'attention'],
      phone: ['phone', 'phone_number', 'mobile', 'telephone'],
      email: ['email', 'email_address'],
      website: ['website', 'web', 'url'],
      payment_terms: ['payment_terms', 'terms', 'payment terms'],
      address: ['address', 'street', 'billing_address'],
      notes: ['notes', 'comments', 'description'],
    },
    defaults: { is_active: true, integration_type: 'none', payment_terms: 'Net 30', currency: 'USD' },
    numericFields: [],
    currencyFields: [],
    previewCols: ['supplier_name', 'contact_name', 'phone', 'email'],
    templateHeaders: ['Supplier Name', 'Contact Name', 'Phone', 'Email', 'Website', 'Payment Terms'],
    templateRow: 'Acme Corp,John Smith,555-1234,john@acme.com,https://acme.com,Net 30',
  },
];

function normalizeHeader(h) {
  return String(h || '').toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
}

// Aggressive normalization for fuzzy matching — strips ALL non-alphanumerics
function fuzzyKey(h) {
  return String(h || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

// Strip BOM + detect delimiter (Excel/European exports use ; \t or |)
function detectDelimiter(text) {
  const firstLine = text.split('\n')[0] || '';
  const counts = { ',': 0, ';': 0, '\t': 0, '|': 0 };
  let inQ = false;
  for (const ch of firstLine) {
    if (ch === '"') inQ = !inQ;
    else if (!inQ && ch in counts) counts[ch]++;
  }
  // Pick the delimiter with the most occurrences (must be > 0)
  let best = ',';
  let max = 0;
  for (const [d, c] of Object.entries(counts)) {
    if (c > max) { max = c; best = d; }
  }
  return best;
}

// Check if a single header matches any alias (3-tier: exact, fuzzy, contains)
function headerMatchesAlias(header, aliases) {
  const nh = normalizeHeader(header);
  const fh = fuzzyKey(header);
  const normalizedAliases = aliases.map(normalizeHeader);
  const fuzzyAliases = aliases.map(fuzzyKey);
  // 1. Exact normalized
  if (normalizedAliases.includes(nh)) return true;
  // 2. Fuzzy (all non-alphanumerics stripped)
  if (fuzzyAliases.includes(fh)) return true;
  // 3. Contains (header contains alias or vice versa, min 3 chars to avoid noise)
  return fuzzyAliases.some(fa => (fh.length >= 3 && fa.length >= 3 && (fh.includes(fa) || fa.includes(fh))));
}

// ── Auto-detect CSV type by scoring header overlap with each type's aliases ─
function detectCsvType(csvHeaders) {
  let bestType = CSV_TYPES[0];
  let bestScore = 0;
  const scores = {};

  for (const type of CSV_TYPES) {
    let matchCount = 0;
    for (const [fieldKey, aliases] of Object.entries(type.aliases)) {
      const matched = csvHeaders.some(h => headerMatchesAlias(h, aliases));
      if (matched) matchCount++;
    }
    // Weight: required field match is critical, other matches add confidence
    const requiredAliases = type.aliases[type.requiredField];
    const requiredMatched = csvHeaders.some(h => headerMatchesAlias(h, requiredAliases));
    scores[type.id] = matchCount + (requiredMatched ? 5 : 0);
    if (scores[type.id] > bestScore) {
      bestScore = scores[type.id];
      bestType = type;
    }
  }

  return { type: bestType, scores };
}

function parseCSV(text) {
  // Strip BOM (common in Excel exports)
  const clean = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const delimiter = detectDelimiter(clean);
  const lines = clean.split('\n').filter(l => l.trim());
  if (lines.length < 2) return { headers: [], rows: [], delimiter };
  const parseRow = (line) => {
    const result = []; let cur = ''; let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { if (inQ && line[i + 1] === '"') { cur += '"'; i++; } else inQ = !inQ; }
      else if (ch === delimiter && !inQ) { result.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    result.push(cur.trim());
    return result;
  };
  const headers = parseRow(lines[0]);
  const rows = lines.slice(1).map(line => {
    const vals = parseRow(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = (vals[i] || '').trim(); });
    return obj;
  });
  return { headers, rows, delimiter };
}

function autoMapColumns(csvHeaders, type) {
  const mapping = {};
  Object.entries(type.aliases).forEach(([fieldKey, aliases]) => {
    const idx = csvHeaders.findIndex(h => headerMatchesAlias(h, aliases));
    mapping[fieldKey] = idx >= 0 ? csvHeaders[idx] : '';
  });
  return mapping;
}

function rowToEntity(row, mapping, type, allCsvHeaders = []) {
  const item = { ...type.defaults };
  const mappedCols = new Set(Object.values(mapping).filter(Boolean));

  // Populate mapped fields
  for (const [fieldKey, csvCol] of Object.entries(mapping)) {
    if (!csvCol) continue;
    const rawVal = row[csvCol];
    if (rawVal === undefined || rawVal === '') continue;
    if (type.numericFields.includes(fieldKey)) {
      // Treat N/A, n/a, NA, empty, or dashes as 0
      const cleaned = String(rawVal).trim();
      if (/^(n\/?a|na|-{1,}|\.{1,})$/i.test(cleaned)) {
        item[fieldKey] = 0;
      } else {
        const num = parseFloat(cleaned.replace(/[^0-9.\-]/g, ''));
        item[fieldKey] = isNaN(num) ? 0 : num;
      }
    } else {
      item[fieldKey] = rawVal;
    }
  }

  // Combine ALL unmapped CSV columns into notes so no data is lost
  const unmappedParts = [];
  for (const col of allCsvHeaders) {
    if (mappedCols.has(col)) continue;
    const val = row[col];
    if (val !== undefined && val !== '' && !/^(n\/?a|na|-{1,})$/i.test(String(val).trim())) {
      unmappedParts.push(`${col}: ${val}`);
    }
  }
  if (unmappedParts.length > 0) {
    const existingNotes = item.notes || '';
    item.notes = (existingNotes ? existingNotes + ' | ' : '') + unmappedParts.join(' | ');
  }

  // Build composite item_name from Product Family + Flavor + Level for uniqueness
  if (type.id === 'inventory' && item.item_name) {
    const flavorCol = allCsvHeaders.find(h => /flavor/i.test(h) && !mappedCols.has(h));
    const levelCol = allCsvHeaders.find(h => /^level$/i.test(h) && !mappedCols.has(h));
    const parts = [item.item_name];
    if (flavorCol && row[flavorCol] && !/^(n\/?a|na|-{1,})$/i.test(String(row[flavorCol]).trim())) {
      parts.push(row[flavorCol]);
    }
    if (levelCol && row[levelCol] && !/^(n\/?a|na|-{1,})$/i.test(String(row[levelCol]).trim())) {
      parts.push(row[levelCol]);
    }
    if (parts.length > 1) {
      item.item_name = parts.join(' - ');
    }
  }

  // Auto-generate SKU if missing but name exists (inventory + bundles)
  if (type.id === 'inventory' && !item.sku && item.item_name) {
    item.sku = 'AUTO-' + item.item_name.replace(/[^A-Z0-9]/gi, '').toUpperCase().slice(0, 8) + '-' + Math.floor(Math.random() * 1000);
  }
  if (type.id === 'bundles' && !item.bundle_sku && item.bundle_name) {
    item.bundle_sku = 'BNDL-' + item.bundle_name.replace(/[^A-Z0-9]/gi, '').toUpperCase().slice(0, 8);
  }
  return item;
}

function downloadTemplate(type) {
  const csv = type.templateHeaders.join(',') + '\n' + type.templateRow;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${type.id}_bulk_upload_template.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export default function BulkInventoryUpload() {
  const qc = useQueryClient();
  const [file, setFile] = useState(null);
  const [parsed, setParsed] = useState({ headers: [], rows: [], delimiter: ',' });
  const [mapping, setMapping] = useState({});
  const [detectedType, setDetectedType] = useState(null);
  const [detectionScores, setDetectionScores] = useState({});
  const [selectedTypeId, setSelectedTypeId] = useState('');
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [queued, setQueued] = useState(false);
  const inputRef = useRef(null);

  const activeType = useMemo(() => CSV_TYPES.find(t => t.id === selectedTypeId) || detectedType || CSV_TYPES[0], [selectedTypeId, detectedType]);

  const handleFile = (f) => {
    setFile(f);
    setResults(null);
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      const { headers, rows } = parseCSV(text);
      if (rows.length === 0) {
        toast.error('CSV appears to be empty or has no data rows');
        return;
      }
      const detection = detectCsvType(headers);
      setParsed({ headers, rows });
      setDetectedType(detection.type);
      setDetectionScores(detection.scores);
      setSelectedTypeId(detection.type.id);
      setMapping(autoMapColumns(headers, detection.type));
      toast.success(`Detected: ${detection.type.label} — ${rows.length} rows parsed`);
    };
    reader.readAsText(f);
  };

  const handleTypeChange = (typeId) => {
    const type = CSV_TYPES.find(t => t.id === typeId);
    setSelectedTypeId(typeId);
    setMapping(autoMapColumns(parsed.headers, type));
  };

  const mappedItems = parsed.rows.map(row => rowToEntity(row, mapping, activeType, parsed.headers));
  const validItems = mappedItems.filter(i => i[activeType.requiredField]);
  const invalidCount = mappedItems.length - validItems.length;

  // All entity field keys available for manual mapping
  const allFieldKeys = Object.keys(activeType.aliases);
  // Which CSV columns are currently mapped vs unmapped
  const mappedColsSet = new Set(Object.values(mapping).filter(Boolean));
  const unmappedCols = parsed.headers.filter(h => !mappedColsSet.has(h));

  const handleImportNow = async () => {
    setConfirmOpen(false);
    if (validItems.length === 0) {
      toast.error('No valid items to import');
      return;
    }
    setImporting(true);
    setProgress(0);
    setResults(null);

    const BATCH_SIZE = 100;
    let successCount = 0;
    let failCount = 0;
    const errors = [];

    for (let i = 0; i < validItems.length; i += BATCH_SIZE) {
      const batch = validItems.slice(i, i + BATCH_SIZE);
      try {
        const created = await base44.entities[activeType.entity].bulkCreate(batch);
        successCount += Array.isArray(created) ? created.length : batch.length;
      } catch (err) {
        failCount += batch.length;
        errors.push(`Batch ${Math.floor(i / BATCH_SIZE) + 1}: ${err.message?.slice(0, 100) || 'Unknown error'}`);
      }
      setProgress(Math.round(((i + BATCH_SIZE) / validItems.length) * 100));
    }

    setImporting(false);
    setProgress(100);
    setResults({ success: successCount, failed: failCount, errors: errors.slice(0, 5) });
    qc.invalidateQueries(['inventory-items']);
    qc.invalidateQueries(['inventory-kpis']);
    qc.invalidateQueries(['product-bundles']);
    qc.invalidateQueries(['suppliers']);

    if (failCount === 0) {
      toast.success(`Successfully imported ${successCount} ${activeType.label.toLowerCase()}`);
    } else {
      toast.warning(`Imported ${successCount} items, ${failCount} failed`);
    }
  };

  // Queue for Trinity — creates an AgentTask so Trinity auto-executes the
  // import during her next evolution cycle. Non-system-critical tasks are
  // auto-approved per Trinity's autonomous protocols.
  const handleQueueForTrinity = async () => {
    setConfirmOpen(false);
    try {
      // Store the mapped items in the actions field (capped to avoid oversized records)
      const itemsPayload = validItems.slice(0, 200);
      const hasMore = validItems.length > 200;
      await base44.entities.AgentTask.create({
        title: `Bulk Import: ${validItems.length} ${activeType.label}`,
        description: `Execute bulk import of ${validItems.length} ${activeType.label.toLowerCase()} from uploaded CSV "${file.name}". ` +
          `Entity: ${activeType.entity}.${hasMore ? ` (Note: first 200 items stored; ${validItems.length - 200} additional items in original file.)` : ''}`,
        task_type: 'trinity_dev_studio',
        status: 'pending',
        frequency: 'once',
        priority: 'medium',
        owner: 'system@axis.ai',
        conditions: JSON.stringify({
          action: 'execute_bulk_import',
          entity: activeType.entity,
          item_count: validItems.length,
          source_file: file.name,
          non_critical: true,
          auto_approved: true,
        }),
        actions: JSON.stringify({
          type: 'bulk_create',
          entity: activeType.entity,
          items: itemsPayload,
          has_more: hasMore,
        }),
      });
      setQueued(true);
      toast.success(`Queued for Trinity — ${validItems.length} ${activeType.label.toLowerCase()} will be imported during the next evolution cycle`);
    } catch (err) {
      toast.error(`Failed to queue: ${err.message?.slice(0, 100) || 'Unknown error'}`);
    }
  };

  const reset = () => {
    setFile(null);
    setParsed({ headers: [], rows: [], delimiter: ',' });
    setMapping({});
    setDetectedType(null);
    setDetectionScores({});
    setSelectedTypeId('');
    setResults(null);
    setProgress(0);
    setQueued(false);
    setConfirmOpen(false);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="space-y-4">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Upload className="w-4 h-4 text-primary" />
            Mass Upload
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border">
            <Package className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
            <div className="text-xs text-muted-foreground space-y-1">
              <p>Upload a CSV to bulk-create records. The system <span className="text-primary font-medium">auto-detects</span> the CSV type (Inventory Items, Product Bundles, or Suppliers) based on column headers — you can override the detection below.</p>
              <p>Both <span className="text-emerald-500 font-medium">manual tracking</span> and <span className="text-blue-500 font-medium">autonomous tracking</span> (auto low-stock reorder every 30 min) are active system-wide.</p>
            </div>
          </div>

          {!file && (
            <div
              onClick={() => inputRef.current?.click()}
              className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-colors"
            >
              <FileSpreadsheet className="w-10 h-10 mx-auto mb-3 text-muted-foreground/50" />
              <p className="text-sm font-medium mb-1">Click to upload a CSV file</p>
              <p className="text-xs text-muted-foreground">Inventory items, product bundles, or suppliers — detected automatically</p>
              <input
                ref={inputRef}
                type="file"
                accept=".csv,text/csv"
                className="hidden"
                onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
              />
            </div>
          )}

          {file && (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-3 flex-wrap">
                <div className="flex items-center gap-2 text-sm">
                  <FileSpreadsheet className="w-4 h-4 text-primary" />
                  <span className="font-medium">{file.name}</span>
                  <Badge variant="secondary" className="text-[10px]">{parsed.rows.length} rows</Badge>
                {parsed.delimiter && parsed.delimiter !== ',' && (
                  <Badge variant="outline" className="text-[10px]">delimiter: {parsed.delimiter === '\t' ? 'tab' : parsed.delimiter}</Badge>
                )}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => downloadTemplate(activeType)}>
                    <Download className="w-3.5 h-3.5 mr-1" />Template
                  </Button>
                  <Button variant="ghost" size="sm" onClick={reset}>Clear</Button>
                </div>
              </div>

              {/* Auto-detection result + override */}
              {detectedType && (
                <div className="flex items-center gap-3 p-3 rounded-lg border border-primary/20 bg-primary/5 flex-wrap">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <span className="text-xs text-muted-foreground">Detected type:</span>
                    <Badge className="bg-primary/10 text-primary text-[10px]">{detectedType.label}</Badge>
                  </div>
                  <div className="flex items-center gap-2 ml-auto">
                    <span className="text-xs text-muted-foreground">Override:</span>
                    <Select value={selectedTypeId} onValueChange={handleTypeChange}>
                      <SelectTrigger className="h-7 text-xs w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {CSV_TYPES.map(t => (
                          <SelectItem key={t.id} value={t.id} className="text-xs">
                            {t.label} {detectionScores[t.id] ? `(${detectionScores[t.id]} matches)` : ''}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {parsed.rows.length > 0 && (
                <>
                  {/* Full column mapping panel — shows every CSV column and its target field */}
                  <div className="rounded-lg border border-border overflow-hidden">
                    <div className="flex items-center gap-2 px-3 py-2 bg-muted/50 border-b border-border">
                      <Table className="w-3.5 h-3.5" />
                      <span className="text-xs font-medium">Column Mapping — {parsed.headers.length} columns detected ({unmappedCols.length} auto-combined into notes)</span>
                    </div>
                    <div className="overflow-x-auto max-h-48">
                      <table className="w-full text-xs">
                        <thead className="bg-muted/30 sticky top-0">
                          <tr>
                            <th className="p-2 text-left font-medium">CSV Column</th>
                            <th className="p-2 text-left font-medium">Sample Value</th>
                            <th className="p-2 text-left font-medium">Maps To</th>
                          </tr>
                        </thead>
                        <tbody>
                          {parsed.headers.map(col => {
                            const mappedField = Object.entries(mapping).find(([_, c]) => c === col)?.[0] || '';
                            const sampleVal = parsed.rows[0]?.[col] || '';
                            return (
                              <tr key={col} className="border-t border-border">
                                <td className="p-2 font-medium whitespace-nowrap">{col}</td>
                                <td className="p-2 text-muted-foreground max-w-[160px] truncate" title={sampleVal}>{sampleVal || '—'}</td>
                                <td className="p-2">
                                  <Select
                                    value={mappedField || '__notes__'}
                                    onValueChange={(val) => {
                                      const newMapping = { ...mapping };
                                      // Remove this col from any existing field mapping
                                      for (const [k, v] of Object.entries(newMapping)) {
                                        if (v === col) newMapping[k] = '';
                                      }
                                      if (val && val !== '__notes__') {
                                        newMapping[val] = col;
                                      }
                                      setMapping(newMapping);
                                    }}
                                  >
                                    <SelectTrigger className="h-7 text-xs w-44">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="__notes__" className="text-xs">→ notes (combine)</SelectItem>
                                      {allFieldKeys.map(fk => (
                                        <SelectItem key={fk} value={fk} className="text-xs">
                                          {fk.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="rounded-lg border border-border overflow-hidden">
                    <div className="flex items-center gap-2 px-3 py-2 bg-muted/50 border-b border-border">
                      <Table className="w-3.5 h-3.5" />
                      <span className="text-xs font-medium">Data Preview — first 5 rows (mapped {validItems.length} valid{invalidCount > 0 && `, ${invalidCount} skipped`})</span>
                    </div>
                    <div className="overflow-x-auto max-h-64">
                      <table className="w-full text-xs">
                        <thead className="bg-muted/30 sticky top-0">
                          <tr>
                            {/* Show ALL CSV columns from the file */}
                            {parsed.headers.map(col => (
                              <th key={col} className="p-2 font-medium text-left whitespace-nowrap">
                                {col}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {parsed.rows.slice(0, 5).map((row, idx) => (
                            <tr key={idx} className="border-t border-border">
                              {parsed.headers.map(col => {
                                const val = row[col];
                                const display = val || <span className="text-muted-foreground/40">—</span>;
                                return (
                                  <td key={col} className="p-2 whitespace-nowrap max-w-[180px] truncate" title={val}>
                                    {display}
                                  </td>
                                );
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {importing && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Loader2 className="w-4 h-4 animate-spin text-primary" />
                        <span>Importing {validItems.length} {activeType.label.toLowerCase()}...</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                  )}

                  {results && (
                    <div className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/30">
                      {results.failed === 0 ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 mt-0.5 shrink-0" />
                      ) : (
                        <AlertCircle className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
                      )}
                      <div className="text-sm space-y-1">
                        <p className="font-medium">
                          {results.success} {activeType.label.toLowerCase()} imported successfully{results.failed > 0 && `, ${results.failed} failed`}
                        </p>
                        {results.errors.length > 0 && (
                          <div className="text-xs text-muted-foreground space-y-0.5">
                            {results.errors.map((e, i) => <p key={i}>• {e}</p>)}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {!importing && !results && !queued && (
                    <Button onClick={() => setConfirmOpen(true)} disabled={validItems.length === 0} className="w-full">
                      <Upload className="w-4 h-4 mr-2" />
                      Import {validItems.length} {activeType.label}
                    </Button>
                  )}

                  {queued && (
                    <div className="flex items-start gap-3 p-3 rounded-lg border border-blue-500/30 bg-blue-500/5">
                      <Bot className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                      <div className="text-sm space-y-1">
                        <p className="font-medium text-blue-500">Queued for Trinity AI</p>
                        <p className="text-xs text-muted-foreground">
                          Trinity will auto-execute this {validItems.length}-item import during the next evolution cycle (non-system-critical, auto-approved).
                          You can track progress in Agent Tasks.
                        </p>
                        <Button onClick={reset} variant="outline" size="sm" className="mt-2">Upload Another File</Button>
                      </div>
                    </div>
                  )}

                  {results && (
                    <Button onClick={reset} variant="outline" className="w-full">
                      Upload Another File
                    </Button>
                  )}

                  {/* Confirmation gate — "Do it now" vs "Let Trinity handle it" */}
                  <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
                    <DialogContent className="max-w-md">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                          <Upload className="w-4 h-4 text-primary" />
                          Confirm Bulk Import
                        </DialogTitle>
                        <DialogDescription>
                          You're about to import <strong>{validItems.length} {activeType.label.toLowerCase()}</strong> from "{file.name}".
                          Choose how to proceed:
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-3 py-2">
                        <button
                          onClick={handleImportNow}
                          className="w-full flex items-start gap-3 p-4 rounded-lg border border-primary/30 bg-primary/5 hover:bg-primary/10 transition-colors text-left group"
                        >
                          <Zap className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                          <div>
                            <p className="font-medium text-sm">Import Now</p>
                            <p className="text-xs text-muted-foreground mt-0.5">Execute immediately — creates all {validItems.length} records right now.</p>
                          </div>
                        </button>
                        <button
                          onClick={handleQueueForTrinity}
                          className="w-full flex items-start gap-3 p-4 rounded-lg border border-blue-500/30 bg-blue-500/5 hover:bg-blue-500/10 transition-colors text-left group"
                        >
                          <Bot className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                          <div>
                            <p className="font-medium text-sm">Let Trinity Handle It</p>
                            <p className="text-xs text-muted-foreground mt-0.5">Queue for auto-execution during Trinity's next evolution cycle. Non-system-critical — auto-approved.</p>
                          </div>
                        </button>
                      </div>
                      <DialogFooter>
                        <Button variant="ghost" onClick={() => setConfirmOpen(false)}>Cancel</Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}