import React from 'react';
import { Package, DollarSign, AlertTriangle, ShoppingCart, Factory } from 'lucide-react';

export default function InventoryKPIBar({ items, purchaseOrders, productionTickets, onLowStockClick, onOpenPOsClick }) {
  const totalSkus = items.length;
  const totalStockValue = items.reduce((s, i) => s + (i.quantity_on_hand || 0) * (i.unit_cost || 0), 0);
  const lowStockCount = items.filter(i => (i.quantity_on_hand || 0) <= (i.reorder_threshold || 0) && i.status !== 'discontinued').length;
  const openPOs = purchaseOrders.filter(po => po.status === 'draft' || po.status === 'sent').length;
  const inProductionUnits = productionTickets
    .filter(t => t.current_stage !== 'delivered')
    .reduce((s, t) => s + (t.quantity || 0), 0);

  const chips = [
    { label: 'Total SKUs', value: totalSkus, icon: Package, color: 'text-blue-400', bg: 'bg-blue-500/10', onClick: null },
    { label: 'Stock Value', value: `$${totalStockValue.toLocaleString()}`, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-500/10', onClick: null },
    { label: 'Low Stock', value: lowStockCount, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10', onClick: onLowStockClick, alert: lowStockCount > 0 },
    { label: 'Open POs', value: openPOs, icon: ShoppingCart, color: 'text-amber-400', bg: 'bg-amber-500/10', onClick: onOpenPOsClick },
    { label: 'In Production', value: inProductionUnits, icon: Factory, color: 'text-purple-400', bg: 'bg-purple-500/10', onClick: null },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
      {chips.map((chip, idx) => {
        const Icon = chip.icon;
        const clickable = !!chip.onClick;
        return (
          <div
            key={idx}
            onClick={clickable ? chip.onClick : undefined}
            className={`rounded-xl border bg-card p-3 flex items-center gap-3 transition-all ${clickable ? 'cursor-pointer hover:border-primary/40 hover:bg-accent/5' : ''} ${chip.alert ? 'border-red-500/30 bg-red-500/5' : 'border-border'}`}
          >
            <div className={`w-9 h-9 rounded-lg ${chip.bg} flex items-center justify-center shrink-0`}>
              <Icon className={`w-4 h-4 ${chip.color}`} />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground truncate">{chip.label}</p>
              <p className="text-lg font-bold leading-tight">{chip.value}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}