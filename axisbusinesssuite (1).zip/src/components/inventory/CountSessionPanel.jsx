import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Plus, ClipboardList, CheckCircle2, Lock, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const statusConfig = {
  in_progress: { label: 'In Progress', badge: 'bg-blue-500/10 text-blue-600' },
  completed: { label: 'Completed', badge: 'bg-amber-500/10 text-amber-600' },
  approved: { label: 'Approved', badge: 'bg-emerald-500/10 text-emerald-600' },
  cancelled: { label: 'Cancelled', badge: 'bg-muted text-muted-foreground' },
};

export default function CountSessionPanel() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [countSession, setCountSession] = useState(null);
  const [sessionName, setSessionName] = useState('');

  const { data: sessions = [] } = useQuery({ queryKey: ['count-sessions'], queryFn: () => base44.entities.CountSession.list('-created_date', 50) });

  const create = useMutation({
    mutationFn: async (name) => {
      const items = await base44.entities.InventoryItem.list('-created_date', 200);
      const itemsJson = JSON.stringify(items.map(i => ({ item_id: i.id, sku: i.sku, item_name: i.item_name, system_qty: i.quantity_on_hand || 0, counted_qty: i.quantity_on_hand || 0, variance: 0, reconciled: false })));
      return base44.entities.CountSession.create({ session_name: name, status: 'in_progress', start_date: new Date().toISOString(), items_json: itemsJson, total_items: items.length, total_variances: 0, owner: '' });
    },
    onSuccess: (data) => { toast.success('Count session started'); qc.invalidateQueries(['count-sessions']); setOpen(false); setSessionName(''); setCountSession(data); },
  });

  const updateCounted = (itemId, value) => {
    const items = JSON.parse(countSession.items_json);
    const idx = items.findIndex(i => i.item_id === itemId);
    if (idx >= 0) {
      items[idx].counted_qty = Number(value);
      items[idx].variance = items[idx].counted_qty - items[idx].system_qty;
      items[idx].reconciled = items[idx].variance !== 0;
      setCountSession({ ...countSession, items_json: JSON.stringify(items), total_variances: items.filter(i => i.variance !== 0).length });
    }
  };

  const reconcile = useMutation({
    mutationFn: async () => {
      const items = JSON.parse(countSession.items_json);
      for (const item of items) {
        if (item.variance !== 0) {
          const invItem = await base44.entities.InventoryItem.get(item.item_id);
          if (invItem) {
            await base44.entities.InventoryItem.update(item.item_id, { quantity_on_hand: item.counted_qty });
            await base44.entities.StockMovement.create({
              movement_id: crypto.randomUUID(), sku: item.sku, product_name: item.item_name,
              movement_type: 'adjustment', quantity: Math.abs(item.variance),
              quantity_before: item.system_qty, quantity_after: item.counted_qty,
              reference_type: 'count_session', reference_id: countSession.id,
              movement_date: new Date().toISOString(),
              reason: `Count session: ${countSession.session_name}`, performed_by: 'count_session',
            });
          }
        }
      }
      return base44.entities.CountSession.update(countSession.id, { status: 'completed', end_date: new Date().toISOString() });
    },
    onSuccess: () => { toast.success('Reconciliation committed — inventory updated'); qc.invalidateQueries(['count-sessions']); qc.invalidateQueries(['inventory-items']); setCountSession(null); },
  });

  const approve = useMutation({
    mutationFn: (id) => base44.entities.CountSession.update(id, { status: 'approved', approved_by: '', approved_at: new Date().toISOString() }),
    onSuccess: () => { toast.success('Session approved and locked'); qc.invalidateQueries(['count-sessions']); setCountSession(null); },
  });

  if (countSession) {
    const items = JSON.parse(countSession.items_json);
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold">{countSession.session_name}</h3>
            <p className="text-xs text-muted-foreground">{items.length} items · {countSession.total_variances} variances</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setCountSession(null)}>Back</Button>
            {countSession.status === 'in_progress' && <Button size="sm" onClick={() => reconcile.mutate()}><CheckCircle2 className="w-4 h-4 mr-1" />Reconcile</Button>}
            {countSession.status === 'completed' && <Button size="sm" onClick={() => approve.mutate(countSession.id)}><Lock className="w-4 h-4 mr-1" />Approve & Lock</Button>}
          </div>
        </div>
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase">
              <tr><th className="text-left p-2">SKU</th><th className="text-left p-2">Item</th><th className="text-right p-2">System</th><th className="text-right p-2">Counted</th><th className="text-right p-2">Variance</th></tr>
            </thead>
            <tbody>
              {items.map((item, idx) => (
                <tr key={idx} className="border-t border-border">
                  <td className="p-2 font-mono text-xs">{item.sku}</td>
                  <td className="p-2">{item.item_name}</td>
                  <td className="p-2 text-right text-muted-foreground">{item.system_qty}</td>
                  <td className="p-2 text-right">
                    <Input type="number" value={item.counted_qty} onChange={e => updateCounted(item.item_id, e.target.value)} className="w-20 h-7 ml-auto text-right" disabled={countSession.status !== 'in_progress'} />
                  </td>
                  <td className={`p-2 text-right font-semibold ${item.variance > 0 ? 'text-emerald-500' : item.variance < 0 ? 'text-red-500' : 'text-muted-foreground'}`}>
                    {item.variance > 0 ? `+${item.variance}` : item.variance}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">Physical inventory count sessions</p>
        <Button size="sm" onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" />New Count</Button>
      </div>
      <div className="grid gap-3">
        {sessions.map(s => {
          const cfg = statusConfig[s.status] || statusConfig.in_progress;
          return (
            <div key={s.id} className="flex items-center justify-between p-4 rounded-lg border border-border bg-muted/20 cursor-pointer hover:bg-muted/40" onClick={() => setCountSession(s)}>
              <div>
                <p className="font-semibold text-sm">{s.session_name}</p>
                <p className="text-xs text-muted-foreground">{s.total_items} items · {s.total_variances} variances · {new Date(s.start_date).toLocaleDateString()}</p>
              </div>
              <Badge className={cfg.badge}>{cfg.label}</Badge>
            </div>
          );
        })}
        {sessions.length === 0 && <div className="text-center py-12 text-muted-foreground"><ClipboardList className="w-8 h-8 mx-auto mb-2 opacity-40" /><p>No count sessions yet</p></div>}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Start New Count Session</DialogTitle></DialogHeader>
          <div><Label>Session Name</Label><Input value={sessionName} onChange={e => setSessionName(e.target.value)} placeholder="e.g. Q3 Warehouse Count" /></div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={() => create.mutate(sessionName)} disabled={!sessionName}>Start Count</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}