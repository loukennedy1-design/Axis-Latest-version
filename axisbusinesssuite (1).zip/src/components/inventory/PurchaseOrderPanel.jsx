import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ShoppingCart, Pencil, Check, Package, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const statusColors = {
  draft: 'bg-amber-500/10 text-amber-600 border-amber-500/30',
  sent: 'bg-blue-500/10 text-blue-600 border-blue-500/30',
  received: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30',
  cancelled: 'bg-red-500/10 text-red-600 border-red-500/30',
};

export default function PurchaseOrderPanel() {
  const qc = useQueryClient();
  const [editingQty, setEditingQty] = useState(null);
  const [qtyValue, setQtyValue] = useState('');

  const { data: pos = [] } = useQuery({
    queryKey: ['purchase-orders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date', 200)
  });

  const updatePO = useMutation({
    mutationFn: ({ id, data }) => base44.entities.PurchaseOrder.update(id, data),
    onSuccess: () => { toast.success('PO updated'); qc.invalidateQueries(['purchase-orders']); setEditingQty(null); },
  });

  const receivePO = useMutation({
    mutationFn: (po) => base44.functions.invoke('inventoryAssetManagement', { action: 'receive_po', po_id: po.id }),
    onSuccess: () => { toast.success('PO received — inventory updated'); qc.invalidateQueries(['purchase-orders']); qc.invalidateQueries(['inventory-items']); qc.invalidateQueries(['stock-movements']); },
    onError: (e) => toast.error('Failed: ' + e.message),
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <ShoppingCart className="w-4 h-4" /> Purchase Orders
        </h3>
        <Badge variant="outline">{pos.length} total</Badge>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase">
            <tr>
              <th className="text-left p-3">PO Number</th>
              <th className="text-left p-3">Supplier</th>
              <th className="text-left p-3">Item</th>
              <th className="text-right p-3">Qty</th>
              <th className="text-right p-3">Est. Cost</th>
              <th className="text-center p-3">Status</th>
              <th className="text-center p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {pos.map(po => (
              <tr key={po.id} className="border-t border-border hover:bg-muted/20">
                <td className="p-3 font-mono text-xs">
                  {po.po_number}
                  {po.auto_generated && <Badge className="ml-2 text-[9px] bg-purple-500/10 text-purple-600">Auto</Badge>}
                </td>
                <td className="p-3">{po.supplier_name || '—'}</td>
                <td className="p-3">
                  <div className="font-medium">{po.item_name || '—'}</div>
                  <div className="text-xs text-muted-foreground font-mono">{po.item_sku}</div>
                </td>
                <td className="p-3 text-right">
                  {editingQty === po.id ? (
                    <div className="flex items-center justify-end gap-1">
                      <Input
                        type="number"
                        value={qtyValue}
                        onChange={e => setQtyValue(e.target.value)}
                        className="w-20 h-7 text-xs"
                      />
                      <button
                        onClick={() => {
                          const newQty = Number(qtyValue) || po.qty_ordered;
                          const estTotal = newQty * (po.unit_cost || 0);
                          updatePO.mutate({ id: po.id, data: { qty_ordered: newQty, estimated_total: estTotal } });
                        }}
                        className="p-1 hover:bg-emerald-500/10 rounded text-emerald-600"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => { setEditingQty(po.id); setQtyValue(po.qty_ordered); }}
                      className="inline-flex items-center gap-1 hover:text-primary"
                    >
                      {po.qty_ordered}
                      <Pencil className="w-3 h-3 opacity-50" />
                    </button>
                  )}
                </td>
                <td className="p-3 text-right">${(po.estimated_total || 0).toFixed(2)}</td>
                <td className="p-3 text-center">
                  <Badge className={`text-[10px] ${statusColors[po.status] || statusColors.draft}`}>
                    {po.status}
                  </Badge>
                </td>
                <td className="p-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    {po.status === 'draft' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() => updatePO.mutate({ id: po.id, data: { status: 'sent' } })}
                      >
                        Approve
                      </Button>
                    )}
                    {po.status === 'sent' && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 text-xs"
                        onClick={() => receivePO.mutate(po)}
                        disabled={receivePO.isLoading}
                      >
                        {receivePO.isLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Receive'}
                      </Button>
                    )}
                    {po.status !== 'received' && po.status !== 'cancelled' && (
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-xs text-destructive"
                        onClick={() => updatePO.mutate({ id: po.id, data: { status: 'cancelled' } })}
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {pos.length === 0 && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-muted-foreground">
                  <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                  No purchase orders yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}