import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Phone, Calendar, Users, DollarSign, TrendingUp, Clock, ShieldCheck, Zap, Mic, Video, FileText, CheckCircle, Target } from 'lucide-react';

const EVENT_TEMPLATES = [
  { icon: '📞', text: 'AI Bot called {name} — {outcome}', names: ['Marcus T.', 'Sarah W.', 'David R.', 'Jennifer L.', 'Michael C.', 'Amanda K.', 'Robert P.', 'Lisa M.'], outcomes: ['Appointment Set', 'Callback Requested', 'Voicemail Left', 'Not Interested', 'Qualified Lead'] },
  { icon: '📄', text: 'Invoice #{num} sent to {company} — ${amount}', nums: [1042, 1043, 1044, 1045], companies: ['Acme Corp', 'TechStart Inc', 'Global Solutions', 'Innovation Labs', 'Digital Dynamics'], amounts: [3200, 5400, 2800, 7600, 4100] },
  { icon: '👤', text: 'New candidate applied: {role} — Recruited via {source}', roles: ['Software Engineer', 'Sales Rep', 'Marketing Manager', 'HR Coordinator', 'Product Designer'], sources: ['Indeed', 'LinkedIn', 'Company Website', 'Referral'] },
  { icon: '💰', text: 'Payroll processed for {count} employees — ${amount}', counts: [14, 15, 16, 17, 18], amounts: [48320, 51200, 49800, 52400, 50100] },
  { icon: '🛡️', text: 'TCPA compliance check passed for {count} leads', counts: [23, 45, 67, 89, 34, 56] },
  { icon: '📧', text: 'Email campaign sent: {campaign} — {count} recipients', campaigns: ['Product Launch', 'Monthly Newsletter', 'Special Offer', 'Webinar Invitation'], counts: [1240, 856, 2340, 567] },
  { icon: '🎯', text: 'Lead score updated: {name} — Score {score}', names: ['John D.', 'Emily R.', 'Chris B.', 'Anna M.'], scores: [87, 92, 78, 95, 84] },
  { icon: '📱', text: 'SMS sent to {name} — Appointment reminder', names: ['Kevin P.', 'Diana S.', 'Mark T.', 'Rachel W.'] },
  { icon: '🎬', text: 'Social post published: {platform} — {engagement} engagement', platforms: ['LinkedIn', 'Facebook', 'Instagram', 'Twitter'], engagements: ['High', 'Medium', 'Viral', 'Growing'] },
  { icon: '🤖', text: 'AI Agent completed task: {task}', tasks: ['Data enrichment', 'Lead scoring', 'Follow-up email', 'CRM update', 'Appointment confirmation'] },
  { icon: '💳', text: 'Payment received: ${amount} from {company}', amounts: [2400, 5800, 3600, 7200, 4900], companies: ['Stark Industries', 'Wayne Corp', 'Umbrella LLC', 'Cyberdyne Inc'] },
  { icon: '📊', text: 'Monthly report generated — Revenue up {percent}%', percents: [12, 18, 22, 15, 25, 19] },
  { icon: '🎓', text: 'Training completed: {employee} — {course}', employees: ['Jordan M.', 'Alex T.', 'Sam R.', 'Riley K.'], courses: ['Sales Mastery', 'Compliance 101', 'Product Knowledge', 'Customer Success'] },
  { icon: '📹', text: 'Video meeting completed: {duration} min — {participants} attendees', durations: [32, 45, 28, 51, 38], participants: [4, 6, 8, 5, 7] },
  { icon: '✅', text: 'Task completed: {task} by {rep}', tasks: ['Follow-up call', 'Proposal sent', 'Contract signed', 'Demo scheduled'], reps: ['Jordan M.', 'Alex T.', 'Sam R.', 'Dana P.'] },
];

export default function LiveActivityFeed() {
  const [events, setEvents] = useState([]);
  const [visibleCount, setVisibleCount] = useState(6);

  useEffect(() => {
    // Initial events
    const initial = Array.from({ length: 3 }, (_, i) => generateEvent(i));
    setEvents(initial);

    const interval = setInterval(() => {
      setEvents(prev => {
        const newEvent = generateEvent(prev.length);
        const updated = [newEvent, ...prev];
        return updated.slice(0, 8); // Keep last 8 events
      });
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const generateEvent = (index) => {
    const template = EVENT_TEMPLATES[index % EVENT_TEMPLATES.length];
    let text = template.text;

    Object.keys(template).forEach(key => {
      if (Array.isArray(template[key])) {
        const value = template[key][Math.floor(Math.random() * template[key].length)];
        text = text.replace(`{${key}}`, value);
      }
    });

    return {
      id: Date.now() + index,
      icon: template.icon,
      text,
      timestamp: new Date(),
    };
  };

  const getIconComponent = (emoji) => {
    const iconMap = {
      '📞': Phone,
      '📄': FileText,
      '👤': Users,
      '💰': DollarSign,
      '🛡️': ShieldCheck,
      '📧': Activity,
      '🎯': Target,
      '📱': Activity,
      '🎬': Video,
      '🤖': Zap,
      '💳': DollarSign,
      '📊': TrendingUp,
      '🎓': CheckCircle,
      '📹': Video,
      '✅': CheckCircle,
    };
    const Icon = iconMap[emoji] || Activity;
    return <Icon className="w-4 h-4" />;
  };

  return (
    <Card className="border-l-4 border-l-primary sticky top-4">
      <CardHeader className="pb-3 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-bold">Live Activity Feed</h3>
              <p className="text-xs text-muted-foreground">Real-time system events</p>
            </div>
          </div>
          <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1" />
            Live
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[400px] overflow-y-auto space-y-0.5">
          {events.map((event, idx) => (
            <div
              key={event.id}
              className={`flex items-start gap-3 p-3 hover:bg-muted/30 transition-all ${idx === 0 ? 'animate-in slide-in-from-left duration-500' : ''}`}
            >
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                {getIconComponent(event.icon)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium leading-relaxed">{event.text}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">
                  {event.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}