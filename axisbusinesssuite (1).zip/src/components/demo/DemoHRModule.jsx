import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Briefcase, Calendar, DollarSign, CheckCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const departmentData = [
  { dept: 'Engineering', open: 5, candidates: 23 },
  { dept: 'Sales', open: 3, candidates: 18 },
  { dept: 'Marketing', open: 2, candidates: 12 },
  { dept: 'HR', open: 1, candidates: 8 },
  { dept: 'Operations', open: 1, candidates: 6 },
];

const pipelineData = [
  { stage: 'Applied', count: 87 },
  { stage: 'Screening', count: 45 },
  { stage: 'Interview', count: 23 },
  { stage: 'Offer', count: 8 },
  { stage: 'Hired', count: 5 },
];

export default function DemoHRModule() {
  const [metrics, setMetrics] = useState({
    openRoles: 12,
    activeCandidates: 87,
    interviewsScheduled: 23,
    offersExtended: 8,
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, activeCandidates: m.activeCandidates + (Math.random() > 0.8 ? 1 : 0) })), 12000),
      setInterval(() => setMetrics(m => ({ ...m, interviewsScheduled: m.interviewsScheduled + (Math.random() > 0.85 ? 1 : 0) })), 15000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const departmentData = [
    { dept: 'Engineering', open: 5, candidates: 34 },
    { dept: 'Sales', open: 3, candidates: 21 },
    { dept: 'Marketing', open: 2, candidates: 15 },
    { dept: 'HR', open: 1, candidates: 8 },
    { dept: 'Operations', open: 1, candidates: 9 },
  ];

  const pipelineData = [
    { stage: 'Applied', count: 87 },
    { stage: 'Screening', count: 45 },
    { stage: 'Interview', count: 23 },
    { stage: 'Offer', count: 8 },
    { stage: 'Hired', count: 12 },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
            <Users className="w-4 h-4 text-emerald-600" />
          </div>
          HR & Recruitment
        </h2>
        <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.openRoles}</p>
              <p className="text-xs text-muted-foreground">Open Roles</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.activeCandidates}</p>
              <p className="text-xs text-muted-foreground">Active Candidates</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.interviewsScheduled}</p>
              <p className="text-xs text-muted-foreground">Interviews Scheduled</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.offersExtended}</p>
              <p className="text-xs text-muted-foreground">Offers Extended</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Open Roles by Department</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={departmentData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="dept" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
                <Bar dataKey="open" name="Open Roles" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="candidates" name="Candidates" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Recruitment Pipeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pipelineData.map((stage, i) => (
                <div key={stage.stage}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium">{stage.stage}</span>
                    <span className="text-muted-foreground">{stage.count} candidates</span>
                  </div>
                  <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${(stage.count / 87) * 100}%`, backgroundColor: `hsl(${200 - i * 30},83%,58%)` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}