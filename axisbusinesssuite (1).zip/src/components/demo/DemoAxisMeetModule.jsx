import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Video, Calendar, Users, Clock } from 'lucide-react';

export default function DemoAxisMeetModule() {
  const [metrics, setMetrics] = useState({
    meetingsHeld: 34,
    avgDuration: '42m',
    upcomingMeetings: 8,
    totalAttendees: 156,
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, meetingsHeld: m.meetingsHeld + (Math.random() > 0.8 ? 1 : 0) })), 15000),
      setInterval(() => setMetrics(m => ({ ...m, totalAttendees: m.totalAttendees + (Math.random() > 0.7 ? 1 : 0) })), 12000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const upcomingMeetings = [
    { title: 'Sales Demo - Acme Corp', time: 'Today, 2:00 PM', attendees: 4 },
    { title: 'Team Standup', time: 'Today, 3:30 PM', attendees: 6 },
    { title: 'Client Check-in', time: 'Tomorrow, 10:00 AM', attendees: 3 },
    { title: 'Product Review', time: 'Tomorrow, 1:00 PM', attendees: 5 },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
            <Video className="w-4 h-4 text-cyan-500" />
          </div>
          AXIS Meet
        </h2>
        <Badge variant="outline" className="text-xs bg-cyan-500/10 text-cyan-600 border-cyan-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-cyan-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
              <Video className="w-5 h-5 text-cyan-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.meetingsHeld}</p>
              <p className="text-xs text-muted-foreground">Meetings Held</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.avgDuration}</p>
              <p className="text-xs text-muted-foreground">Avg Duration</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.upcomingMeetings}</p>
              <p className="text-xs text-muted-foreground">Upcoming</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Users className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.totalAttendees}</p>
              <p className="text-xs text-muted-foreground">Total Attendees</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Upcoming Meetings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingMeetings.map((meeting, i) => (
              <div key={i} className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{meeting.title}</p>
                  <p className="text-xs text-muted-foreground">{meeting.time}</p>
                </div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Users className="w-3.5 h-3.5" />
                  <span>{meeting.attendees} attendees</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}