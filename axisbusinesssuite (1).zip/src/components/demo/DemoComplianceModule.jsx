import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, CheckCircle, AlertTriangle, FileCheck, Lock } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function DemoComplianceModule() {
  const [metrics, setMetrics] = useState({
    complianceScore: 99.8,
    dncEntries: 234,
    tcpaAudits: 47,
    securityAlerts: 0,
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, dncEntries: m.dncEntries + (Math.random() > 0.9 ? 1 : 0) })), 18000),
      setInterval(() => setMetrics(m => ({ ...m, tcpaAudits: m.tcpaAudits + (Math.random() > 0.85 ? 1 : 0) })), 20000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const auditData = [
    { category: 'TCPA', passed: 47, total: 47 },
    { category: 'DNC', passed: 23, total: 23 },
    { category: 'Consent', passed: 156, total: 158 },
    { category: 'Recording', passed: 312, total: 312 },
    { category: 'Data Privacy', passed: 89, total: 89 },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
            <Shield className="w-4 h-4 text-purple-500" />
          </div>
          Compliance & Security
        </h2>
        <Badge variant="outline" className="text-xs bg-purple-500/10 text-purple-600 border-purple-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.complianceScore}%</p>
              <p className="text-xs text-muted-foreground">Compliance Score</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <FileCheck className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.dncEntries}</p>
              <p className="text-xs text-muted-foreground">DNC Entries</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.tcpaAudits}</p>
              <p className="text-xs text-muted-foreground">TCPA Audits</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Lock className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.securityAlerts}</p>
              <p className="text-xs text-muted-foreground">Security Alerts</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold">Compliance Audits Passed</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={auditData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="category" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
              <Bar dataKey="passed" name="Passed" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
              <Bar dataKey="total" name="Total" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-3 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
            <div className="flex items-center gap-2 text-xs text-emerald-600">
              <CheckCircle className="w-4 h-4" />
              <span className="font-semibold">All compliance checks passed — No violations detected</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}