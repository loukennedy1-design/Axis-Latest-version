import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, CreditCard, FileText, ArrowUpRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

export default function DemoFinanceModule() {
  const [metrics, setMetrics] = useState({
    mrr: 18400,
    arr: 220800,
    invoicesSent: 47,
    outstandingBalance: 12400,
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, mrr: m.mrr + Math.floor(Math.random() * 100) })), 18000),
      setInterval(() => setMetrics(m => ({ ...m, arr: m.mrr * 12 })), 18000),
      setInterval(() => setMetrics(m => ({ ...m, invoicesSent: m.invoicesSent + (Math.random() > 0.85 ? 1 : 0) })), 15000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const revenueData = Array.from({ length: 12 }, (_, i) => ({
    name: new Date(2026, i, 1).toLocaleString('default', { month: 'short' }),
    revenue: 15000 + i * 1200 + Math.floor(Math.random() * 800),
    expenses: 8000 + i * 400 + Math.floor(Math.random() * 500),
  }));

  const invoiceStatus = [
    { status: 'Paid', count: 32, color: 'hsl(162,63%,47%)' },
    { status: 'Pending', count: 10, color: 'hsl(43,96%,56%)' },
    { status: 'Overdue', count: 5, color: 'hsl(0,84%,60%)' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
            <DollarSign className="w-4 h-4 text-amber-600" />
          </div>
          Finance & Revenue
        </h2>
        <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-600 border-amber-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">${(metrics.mrr / 1000).toFixed(1)}k</p>
              <p className="text-xs text-muted-foreground">MRR</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">${(metrics.arr / 1000).toFixed(0)}k</p>
              <p className="text-xs text-muted-foreground">ARR</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.invoicesSent}</p>
              <p className="text-xs text-muted-foreground">Invoices Sent</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <CreditCard className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">${(metrics.outstandingBalance / 1000).toFixed(1)}k</p>
              <p className="text-xs text-muted-foreground">Outstanding</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Revenue vs Expenses (YTD)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={revenueData}>
                <defs>
                  <linearGradient id="dRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(43,96%,56%)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="hsl(43,96%,56%)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} formatter={v => [`$${v.toLocaleString()}`, '']} />
                <Area type="monotone" dataKey="revenue" name="Revenue" stroke="hsl(43,96%,56%)" fill="url(#dRevenue)" strokeWidth={2} />
                <Area type="monotone" dataKey="expenses" name="Expenses" stroke="hsl(262,83%,58%)" fill="none" strokeWidth={2} strokeDasharray="4 2" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Invoice Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {invoiceStatus.map((item) => (
                <div key={item.status}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium">{item.status}</span>
                    <span className="text-muted-foreground">{item.count} invoices</span>
                  </div>
                  <div className="h-3 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${(item.count / 47) * 100}%`, backgroundColor: item.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-emerald-600">
                  <ArrowUpRight className="w-4 h-4" />
                  <span className="font-semibold">Revenue up 22% vs last month</span>
                </div>
                <span className="text-xs text-emerald-600 font-bold">+$3,240</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}