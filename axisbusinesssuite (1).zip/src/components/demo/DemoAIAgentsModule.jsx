import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, Activity, Workflow, Cpu, TrendingUp, DollarSign } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

export default function DemoAIAgentsModule() {
  const [metrics, setMetrics] = useState({
    tasksRunToday: 847,
    workflowsActive: 23,
    automationSavings: 12400,
    agentTasks: 156,
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, tasksRunToday: m.tasksRunToday + Math.floor(Math.random() * 5) })), 6000),
      setInterval(() => setMetrics(m => ({ ...m, automationSavings: m.automationSavings + Math.floor(Math.random() * 50) })), 8000),
      setInterval(() => setMetrics(m => ({ ...m, agentTasks: m.agentTasks + 1 })), 10000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const agentData = [
    { agent: 'CRM Agent', tasks: 234, efficiency: 94 },
    { agent: 'Billing Agent', tasks: 187, efficiency: 97 },
    { agent: 'Support Agent', tasks: 156, efficiency: 91 },
    { agent: 'HR Agent', tasks: 143, efficiency: 93 },
    { agent: 'Security Agent', tasks: 127, efficiency: 99 },
  ];

  const trendData = Array.from({ length: 12 }, (_, i) => ({
    name: `Day ${i + 1}`,
    tasks: 45 + i * 12 + Math.floor(Math.random() * 20),
    savings: 800 + i * 150 + Math.floor(Math.random() * 100),
  }));

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-violet-500/20 flex items-center justify-center">
            <Zap className="w-4 h-4 text-violet-500" />
          </div>
          AI Agents & Automation
        </h2>
        <Badge variant="outline" className="text-xs bg-violet-500/10 text-violet-600 border-violet-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-violet-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-violet-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center">
              <Zap className="w-5 h-5 text-violet-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.tasksRunToday}</p>
              <p className="text-xs text-muted-foreground">Tasks Run Today</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Workflow className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.workflowsActive}</p>
              <p className="text-xs text-muted-foreground">Workflows Active</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">${(metrics.automationSavings / 1000).toFixed(1)}k</p>
              <p className="text-xs text-muted-foreground">Automation Savings</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Cpu className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.agentTasks}</p>
              <p className="text-xs text-muted-foreground">Agent Tasks</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Agent Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {agentData.map((agent, i) => (
                <div key={agent.agent}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-medium">{agent.agent}</span>
                    <span className="text-muted-foreground">{agent.tasks} tasks · {agent.efficiency}% efficiency</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all" style={{ width: `${agent.efficiency}%`, backgroundColor: `hsl(${260 - i * 20},83%,58%)` }} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Automation Impact (12 Days)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} yAxisId="left" />
                <YAxis tick={{ fontSize: 10 }} yAxisId="right" orientation="right" tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
                <Line yAxisId="left" type="monotone" dataKey="tasks" name="Tasks" stroke="hsl(262,83%,58%)" strokeWidth={2} dot={false} />
                <Line yAxisId="right" type="monotone" dataKey="savings" name="Savings" stroke="hsl(162,63%,47%)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}