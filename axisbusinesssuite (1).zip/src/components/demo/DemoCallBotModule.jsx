import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Phone, Activity, Calendar, Clock, Mic } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function DemoCallBotModule() {
  const [metrics, setMetrics] = useState({
    callsToday: 142,
    answerRate: 68.4,
    appointmentsSet: 28,
    avgDuration: '3m 24s',
  });

  useEffect(() => {
    const intervals = [
      setInterval(() => setMetrics(m => ({ ...m, callsToday: m.callsToday + 1 })), 10000),
      setInterval(() => setMetrics(m => ({ ...m, answerRate: Math.min(75, m.answerRate + 0.1) })), 15000),
      setInterval(() => setMetrics(m => ({ ...m, appointmentsSet: m.appointmentsSet + (Math.random() > 0.7 ? 1 : 0) })), 12000),
    ];
    return () => intervals.forEach(clearInterval);
  }, []);

  const hourlyData = [
    { hour: '8am', calls: 12, answered: 8 },
    { hour: '9am', calls: 24, answered: 17 },
    { hour: '10am', calls: 31, answered: 22 },
    { hour: '11am', calls: 28, answered: 19 },
    { hour: '12pm', calls: 15, answered: 9 },
    { hour: '1pm', calls: 22, answered: 15 },
    { hour: '2pm', calls: 29, answered: 21 },
    { hour: '3pm', calls: 33, answered: 24 },
    { hour: '4pm', calls: 26, answered: 18 },
    { hour: '5pm', calls: 18, answered: 11 },
  ];

  const recentCalls = [
    { lead: 'Marcus Thompson', outcome: 'Appointment Set', duration: '4m 32s', time: '2m ago' },
    { lead: 'Sarah Williams', outcome: 'Callback Requested', duration: '2m 18s', time: '8m ago' },
    { lead: 'David Torres', outcome: 'Voicemail Left', duration: '0m 42s', time: '14m ago' },
    { lead: 'Jennifer Kim', outcome: 'Not Interested', duration: '1m 05s', time: '21m ago' },
    { lead: 'Robert Chen', outcome: 'Appointment Set', duration: '5m 11s', time: '29m ago' },
  ];

  const outcomeColors = {
    'Appointment Set': 'bg-emerald-500/10 text-emerald-600',
    'Callback Requested': 'bg-blue-500/10 text-blue-600',
    'Voicemail Left': 'bg-purple-500/10 text-purple-600',
    'Not Interested': 'bg-red-500/10 text-red-500',
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 flex items-center justify-center">
            <Phone className="w-4 h-4 text-emerald-600" />
          </div>
          AI Call Bot
        </h2>
        <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1" />
          Active
        </Badge>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-emerald-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
              <Phone className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.callsToday}</p>
              <p className="text-xs text-muted-foreground">Calls Today</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.answerRate.toFixed(1)}%</p>
              <p className="text-xs text-muted-foreground">Answer Rate</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-amber-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.appointmentsSet}</p>
              <p className="text-xs text-muted-foreground">Appointments Set</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-purple-500" />
            </div>
            <div>
              <p className="text-2xl font-bold">{metrics.avgDuration}</p>
              <p className="text-xs text-muted-foreground">Avg Duration</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Hourly Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                <XAxis dataKey="hour" tick={{ fontSize: 9 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
                <Bar dataKey="calls" name="Calls" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
                <Bar dataKey="answered" name="Answered" fill="hsl(162,63%,47%)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Mic className="w-4 h-4" />
              Recent Calls
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentCalls.map((call, i) => (
                <div key={i} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{call.lead}</p>
                    <p className="text-xs text-muted-foreground">{call.time}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">{call.duration}</span>
                    <Badge variant="outline" className={`text-[10px] ${outcomeColors[call.outcome] || ''}`}>
                      {call.outcome}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}