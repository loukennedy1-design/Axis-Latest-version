// Pre-configured column mappings for importing CSV data from external systems.
// Each preset defines: source system, label, target AXIS entity, required fields,
// and a mapping from CSV header aliases → AXIS entity field keys.

export const IMPORT_PRESETS = [
  // ── QuickBooks ──────────────────────────────────────────────────────────
  {
    id: 'qb_customers',
    source: 'QuickBooks',
    label: 'Customers',
    icon: 'Users',
    entity_name: 'Lead',
    description: 'Import QuickBooks customer list as leads',
    fieldMapping: {
      first_name: ['first_name', 'firstname', 'first', 'fname', 'customer', 'name', 'customer_name'],
      last_name: ['last_name', 'lastname', 'last', 'lname', 'surname', 'last name'],
      phone: ['phone', 'phone_number', 'phonenumber', 'mobile', 'cell', 'telephone', 'main_phone', 'primary_phone'],
      email: ['email', 'email_address', 'emailaddress', 'e_mail', 'main_email', 'primary_email'],
      company: ['company', 'company_name', 'business', 'organization', 'org', 'customer_company'],
      source: ['source', 'lead_source', 'leadsource'],
      notes: ['notes', 'note', 'comments', 'comment', 'description', 'billing_address', 'address'],
    },
    defaults: { source: 'QuickBooks Import', status: 'new', consent_given: false, call_attempts: 0 },
  },
  {
    id: 'qb_vendors',
    source: 'QuickBooks',
    label: 'Vendors',
    icon: 'Truck',
    entity_name: 'Supplier',
    description: 'Import QuickBooks vendor list as suppliers',
    fieldMapping: {
      supplier_name: ['vendor', 'vendor_name', 'supplier', 'supplier_name', 'company', 'company_name', 'name'],
      contact_name: ['print_on_check_as', 'contact', 'contact_name', 'print on check as'],
      phone: ['phone', 'phone_number', 'phonenumber', 'mobile', 'telephone', 'main_phone'],
      email: ['email', 'email_address', 'emailaddress', 'e_mail', 'primary_email'],
      website: ['website', 'web', 'url'],
      payment_terms: ['terms', 'payment_terms', 'payment terms'],
      tax_id: ['tax_id', 'ein', 'ssn', 'tax_id_no'],
      address: ['address', 'billing_address', 'vendor_address', 'street'],
      notes: ['notes', 'note', 'comments', 'description'],
    },
    defaults: { is_active: true, integration_type: 'none', integration_status: 'not_connected', payment_terms: 'Net 30', currency: 'USD' },
  },
  {
    id: 'qb_employees',
    source: 'QuickBooks',
    label: 'Employees',
    icon: 'UserCheck',
    entity_name: 'Employee',
    description: 'Import QuickBooks employee list',
    fieldMapping: {
      first_name: ['first_name', 'firstname', 'first', 'fname', 'employee', 'name', 'employee_name'],
      last_name: ['last_name', 'lastname', 'last', 'lname', 'surname'],
      phone: ['phone', 'phone_number', 'phonenumber', 'mobile', 'cell', 'telephone', 'home_phone'],
      email: ['email', 'email_address', 'emailaddress', 'e_mail', 'work_email'],
      hire_date: ['hire_date', 'hiredate', 'start_date', 'date_hired', 'hired'],
      job_title: ['job_title', 'title', 'position', 'job'],
      address: ['address', 'home_address', 'street_address'],
      emergency_contact_name: ['emergency_contact', 'ec_name', 'emergency contact'],
      emergency_contact_phone: ['ec_phone', 'emergency_phone', 'emergency contact phone'],
    },
    defaults: { status: 'active', employment_type: 'full_time', department: 'sales', portal_status: 'not_invited', portal_role: 'none' },
  },
  {
    id: 'qb_items',
    source: 'QuickBooks',
    label: 'Products / Services',
    icon: 'Package',
    entity_name: 'InventoryItem',
    description: 'Import QuickBooks product & service list',
    fieldMapping: {
      item_name: ['name', 'item_name', 'product_name', 'product', 'item', 'description', 'item_description'],
      sku: ['sku', 'item_number', 'product_code', 'item_code', 'part_number', 'sku_number'],
      category: ['category', 'type', 'item_type', 'product_category'],
      description: ['description', 'sales_description', 'item_description', 'desc'],
      unit_cost: ['cost', 'unit_cost', 'purchase_cost', 'cost_price'],
      unit_price: ['price', 'unit_price', 'sales_price', 'sales_rate', 'rate'],
      quantity_on_hand: ['qty_on_hand', 'quantity_on_hand', 'quantity', 'stock', 'on_hand', 'quantity_available'],
      reorder_point: ['reorder_point', 'reorder', 'min_stock'],
      unit_of_measure: ['uom', 'unit_of_measure', 'unit'],
    },
    defaults: { status: 'active', unit_of_measure: 'each' },
  },
  {
    id: 'qb_invoices',
    source: 'QuickBooks',
    label: 'Invoices',
    icon: 'FileText',
    entity_name: 'Invoice',
    description: 'Import QuickBooks invoice list',
    fieldMapping: {
      invoice_number: ['invoice_no', 'invoice_number', 'invoice', 'txn_id', 'transaction_id', 'number'],
      client_name: ['customer', 'customer_name', 'client', 'client_name', 'name'],
      client_email: ['customer_email', 'client_email', 'email'],
      total: ['total', 'amount', 'balance', 'invoice_total', 'total_amount'],
      due_date: ['due_date', 'duedate', 'due'],
      paid_date: ['paid_date', 'date_paid', 'paid'],
      notes: ['notes', 'memo', 'message'],
    },
    defaults: { status: 'draft' },
  },
  // ── Salesforce ──────────────────────────────────────────────────────────
  {
    id: 'sf_contacts',
    source: 'Salesforce',
    label: 'Contacts / Leads',
    icon: 'Users',
    entity_name: 'Lead',
    description: 'Import Salesforce contacts or leads as AXIS leads',
    fieldMapping: {
      first_name: ['firstname', 'first_name', 'first', 'fname', 'name'],
      last_name: ['lastname', 'last_name', 'last', 'lname', 'surname'],
      phone: ['phone', 'phone_number', 'mobile', 'mobilephone', 'homephone', 'telephone'],
      email: ['email', 'email_address'],
      company: ['company', 'account_name', 'accountname', 'organization'],
      source: ['leadsource', 'lead_source', 'source'],
      notes: ['description', 'notes', 'comments'],
    },
    defaults: { source: 'Salesforce Import', status: 'new', consent_given: false, call_attempts: 0 },
  },
  // ── HubSpot ─────────────────────────────────────────────────────────────
  {
    id: 'hs_contacts',
    source: 'HubSpot',
    label: 'Contacts',
    icon: 'Users',
    entity_name: 'Lead',
    description: 'Import HubSpot contacts as AXIS leads',
    fieldMapping: {
      first_name: ['firstname', 'first_name', 'first', 'fname', 'name'],
      last_name: ['lastname', 'last_name', 'last', 'lname', 'surname'],
      phone: ['phone', 'phone_number', 'mobilephone', 'mobile', 'work_phone'],
      email: ['email', 'email_address'],
      company: ['company', 'company_name', 'organization'],
      source: ['leadsource', 'source', 'lead_source'],
      notes: ['notes', 'description', 'comments'],
    },
    defaults: { source: 'HubSpot Import', status: 'new', consent_given: false, call_attempts: 0 },
  },
  // ── Generic / Custom CSV ───────────────────────────────────────────────
  {
    id: 'generic_leads',
    source: 'Generic CSV',
    label: 'Leads',
    icon: 'Users',
    entity_name: 'Lead',
    description: 'Import leads from any CSV with flexible column mapping',
    fieldMapping: {
      first_name: ['first_name', 'firstname', 'first', 'fname', 'name', 'fullname', 'full_name'],
      last_name: ['last_name', 'lastname', 'last', 'lname', 'surname'],
      phone: ['phone', 'phone_number', 'phonenumber', 'mobile', 'cell', 'telephone', 'tel'],
      email: ['email', 'email_address', 'emailaddress', 'e_mail', 'mail'],
      company: ['company', 'company_name', 'business', 'organization', 'org', 'account'],
      source: ['source', 'lead_source', 'leadsource', 'origin', 'channel'],
      timezone: ['timezone', 'time_zone', 'tz'],
      notes: ['notes', 'note', 'comments', 'comment', 'description', 'remarks'],
    },
    defaults: { source: 'CSV Import', status: 'new', consent_given: false, call_attempts: 0 },
  },
  {
    id: 'generic_employees',
    source: 'Generic CSV',
    label: 'Employees',
    icon: 'UserCheck',
    entity_name: 'Employee',
    description: 'Import employees from any CSV',
    fieldMapping: {
      first_name: ['first_name', 'firstname', 'first', 'fname', 'name'],
      last_name: ['last_name', 'lastname', 'last', 'lname', 'surname'],
      phone: ['phone', 'phone_number', 'mobile', 'telephone'],
      email: ['email', 'email_address'],
      hire_date: ['hire_date', 'hiredate', 'start_date'],
      job_title: ['job_title', 'title', 'position'],
      department: ['department', 'dept'],
      salary: ['salary', 'annual_salary', 'pay_rate'],
    },
    defaults: { status: 'active', employment_type: 'full_time', portal_status: 'not_invited', portal_role: 'none' },
  },
  {
    id: 'generic_suppliers',
    source: 'Generic CSV',
    label: 'Suppliers / Vendors',
    icon: 'Truck',
    entity_name: 'Supplier',
    description: 'Import suppliers/vendors from any CSV',
    fieldMapping: {
      supplier_name: ['supplier_name', 'vendor_name', 'supplier', 'vendor', 'company', 'name'],
      contact_name: ['contact_name', 'contact', 'attention'],
      phone: ['phone', 'phone_number', 'mobile', 'telephone'],
      email: ['email', 'email_address'],
      website: ['website', 'web', 'url'],
      payment_terms: ['payment_terms', 'terms', 'payment terms'],
      address: ['address', 'street', 'billing_address'],
      notes: ['notes', 'comments', 'description'],
    },
    defaults: { is_active: true, integration_type: 'none', payment_terms: 'Net 30', currency: 'USD' },
  },
  // ── Generic Inventory & Products (bulk upload) ─────────────────────────
  {
    id: 'generic_inventory',
    source: 'Generic CSV',
    label: 'Inventory Items',
    icon: 'Package',
    entity_name: 'InventoryItem',
    description: 'Bulk import current inventory from any CSV (name, SKU, qty, price, reorder point)',
    fieldMapping: {
      item_name: ['name', 'item_name', 'product_name', 'product', 'item', 'description', 'item_description'],
      sku: ['sku', 'item_number', 'product_code', 'item_code', 'part_number', 'sku_number'],
      category: ['category', 'type', 'item_type', 'product_category'],
      description: ['description', 'sales_description', 'item_description', 'desc'],
      unit_cost: ['cost', 'unit_cost', 'purchase_cost', 'cost_price'],
      unit_price: ['price', 'unit_price', 'sales_price', 'sales_rate', 'rate'],
      quantity_on_hand: ['qty_on_hand', 'quantity_on_hand', 'quantity', 'stock', 'on_hand', 'quantity_available'],
      reorder_point: ['reorder_point', 'reorder', 'min_stock'],
      unit_of_measure: ['uom', 'unit_of_measure', 'unit'],
    },
    defaults: { status: 'active', unit_of_measure: 'each' },
  },
  {
    id: 'generic_product_bundles',
    source: 'Generic CSV',
    label: 'Product Bundles',
    icon: 'Package',
    entity_name: 'ProductBundle',
    description: 'Bulk import product bundles / kits from any CSV (name, SKU, price, image)',
    fieldMapping: {
      bundle_name: ['bundle_name', 'name', 'product_name', 'bundle', 'title', 'kit_name'],
      bundle_sku: ['bundle_sku', 'sku', 'bundle_code', 'code', 'kit_sku'],
      description: ['description', 'desc', 'details'],
      bundle_price: ['bundle_price', 'price', 'cost', 'amount', 'sale_price'],
      store_image_url: ['store_image_url', 'image_url', 'image', 'photo', 'picture', 'img'],
      is_active: ['is_active', 'active', 'status'],
    },
    defaults: { is_active: true },
  },
];

// Required fields per entity — rows missing these will be skipped
export const REQUIRED_FIELDS = {
  Lead: ['first_name', 'phone'],
  Employee: ['first_name', 'email'],
  Supplier: ['supplier_name'],
  InventoryItem: ['item_name'],
  ProductBundle: ['bundle_name', 'bundle_sku'],
  Invoice: ['client_name', 'total'],
};

// Human-readable field labels for each entity
export const FIELD_LABELS = {
  Lead: {
    first_name: 'First Name', last_name: 'Last Name', phone: 'Phone', email: 'Email',
    company: 'Company', source: 'Source', timezone: 'Timezone', notes: 'Notes',
  },
  Employee: {
    first_name: 'First Name', last_name: 'Last Name', phone: 'Phone', email: 'Email',
    hire_date: 'Hire Date', job_title: 'Job Title', address: 'Address',
    emergency_contact_name: 'Emergency Contact', emergency_contact_phone: 'Emergency Phone',
  },
  Supplier: {
    supplier_name: 'Supplier Name', contact_name: 'Contact Name', phone: 'Phone', email: 'Email',
    website: 'Website', payment_terms: 'Payment Terms', tax_id: 'Tax ID', address: 'Address', notes: 'Notes',
  },
  InventoryItem: {
    item_name: 'Item Name', sku: 'SKU', category: 'Category', description: 'Description',
    unit_cost: 'Unit Cost', unit_price: 'Unit Price', quantity_on_hand: 'Qty on Hand',
    reorder_point: 'Reorder Point', unit_of_measure: 'UoM',
  },
  ProductBundle: {
    bundle_name: 'Bundle Name', bundle_sku: 'Bundle SKU', description: 'Description',
    bundle_price: 'Bundle Price', store_image_url: 'Image URL', is_active: 'Active',
  },
  Invoice: {
    invoice_number: 'Invoice #', client_name: 'Client Name', client_email: 'Client Email',
    total: 'Total', due_date: 'Due Date', paid_date: 'Paid Date', notes: 'Notes',
  },
};

// Group presets by source for the UI
export const PRESETS_BY_SOURCE = IMPORT_PRESETS.reduce((acc, preset) => {
  if (!acc[preset.source]) acc[preset.source] = [];
  acc[preset.source].push(preset);
  return acc;
}, {});

// Normalized header comparison helper
export function normalizeHeader(h) {
  return String(h || '').toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '');
}

// Auto-detect mapping from CSV headers to entity fields using a preset's fieldMapping
export function autoDetectMapping(csvHeaders, preset) {
  const mapping = {};
  const normalized = csvHeaders.map(normalizeHeader);
  Object.entries(preset.fieldMapping).forEach(([fieldKey, aliases]) => {
    const idx = normalized.findIndex(nh => aliases.some(a => normalizeHeader(a) === nh));
    mapping[fieldKey] = idx >= 0 ? csvHeaders[idx] : '';
  });
  return mapping;
}