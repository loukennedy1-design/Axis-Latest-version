import React from 'react';
import { Progress } from '@/components/ui/progress';

const LABELS = {
  opening: 'Opening',
  objection_handling: 'Objection Handling',
  closing: 'Closing',
  compliance: 'Compliance',
  empathy: 'Empathy',
  clarity: 'Clarity',
  closing_attempt: 'Closing Attempt',
  rapport_building: 'Rapport',
  active_listening: 'Active Listening',
};

const COLORS = {
  opening: '#3b82f6',
  objection_handling: '#8b5cf6',
  closing: '#22c55e',
  compliance: '#f59e0b',
  empathy: '#3b82f6',
  clarity: '#8b5cf6',
  closing_attempt: '#22c55e',
  rapport_building: '#ec4899',
  active_listening: '#06b6d4',
};

// scores: { key: number }
export default function CoachingScoreBreakdown({ scores }) {
  const entries = Object.entries(scores || {}).filter(([, v]) => v > 0);
  if (!entries.length) {
    return <p className="text-xs text-muted-foreground italic">No score breakdown yet — analyze calls to populate.</p>;
  }
  return (
    <div className="space-y-2.5">
      {entries.map(([k, v]) => (
        <div key={k} className="space-y-1">
          <div className="flex justify-between items-center">
            <span className="text-xs text-muted-foreground">{LABELS[k] || k}</span>
            <span className="text-sm font-bold" style={{ color: COLORS[k] || '#888' }}>{v}</span>
          </div>
          <Progress value={v} className="h-1.5" />
        </div>
      ))}
    </div>
  );
}