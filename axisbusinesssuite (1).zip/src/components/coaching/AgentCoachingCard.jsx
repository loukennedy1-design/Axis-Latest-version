import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronUp, TrendingUp, TrendingDown, Minus, Flag, Phone } from 'lucide-react';
import { format } from 'date-fns';
import CoachingScoreBreakdown from '@/components/coaching/CoachingScoreBreakdown';
import CoachingFeedbackList from '@/components/coaching/CoachingFeedbackList';

function GradeCircle({ score }) {
  const grade = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : score >= 60 ? 'D' : 'F';
  const color = score >= 80 ? '#22c55e' : score >= 60 ? '#f59e0b' : '#ef4444';
  return (
    <div className="relative w-14 h-14 flex-shrink-0">
      <svg viewBox="0 0 36 36" className="w-14 h-14 -rotate-90">
        <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(220,13%,91%)" strokeWidth="3" />
        <circle cx="18" cy="18" r="15.9" fill="none" stroke={color} strokeWidth="3"
          strokeDasharray={`${score} 100`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-base font-bold leading-none">{grade}</span>
        <span className="text-[8px] text-muted-foreground">{score}</span>
      </div>
    </div>
  );
}

const TREND_META = {
  improving: { icon: TrendingUp, color: 'text-emerald-500', label: 'Improving' },
  declining: { icon: TrendingDown, color: 'text-red-500', label: 'Declining' },
  stable: { icon: Minus, color: 'text-muted-foreground', label: 'Stable' },
};

export default function AgentCoachingCard({ agent, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  const trend = TREND_META[agent.trend] || TREND_META.stable;
  const TrendIcon = trend.icon;
  const hasBreakdown = agent.breakdown && Object.values(agent.breakdown).some((v) => v > 0);

  return (
    <Card className="overflow-hidden">
      <button
        className="w-full text-left p-4 flex items-center gap-4 hover:bg-muted/30 transition-colors"
        onClick={() => setOpen((o) => !o)}
      >
        <GradeCircle score={agent.avgScore} />
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm truncate">{agent.name}</p>
          <p className="text-xs text-muted-foreground">
            {agent.callsCount} calls · {agent.analyzedCount} analyzed · {agent.apptRate}% appointment rate
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <Badge variant="outline" className={`gap-1 ${trend.color}`}>
            <TrendIcon className="w-3 h-3" /> {trend.label}
          </Badge>
          {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>

      {open && (
        <CardContent className="p-4 pt-0 space-y-5 border-t border-border">
          {/* Scores + flags */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Call Quality Scores</p>
              <CoachingScoreBreakdown scores={hasBreakdown ? agent.breakdown : agent.qualityMetrics} />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                <Flag className="w-3 h-3" />Coaching Flags
              </p>
              {agent.flags.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {agent.flags.map((f) => (
                    <Badge key={f.flag} variant="secondary" className="text-[10px] gap-1">
                      {f.flag.replace(/_/g, ' ')} <span className="text-muted-foreground">×{f.count}</span>
                    </Badge>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground italic">No flags recorded.</p>}
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                <Phone className="w-3 h-3" />Recent Calls
              </p>
              {agent.recentCalls.length ? (
                <div className="space-y-1.5">
                  {agent.recentCalls.map((c, i) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="truncate mr-2">{c.lead}</span>
                      <span className="text-muted-foreground shrink-0">{c.date ? format(new Date(c.date), 'MMM d') : '—'}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-xs text-muted-foreground italic">No calls yet.</p>}
            </div>
          </div>

          {/* Feedback */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div>
              <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider mb-2">Strengths</p>
              <CoachingFeedbackList items={agent.strengths} variant="strength" emptyText="No strengths recorded yet." />
            </div>
            <div>
              <p className="text-xs font-semibold text-red-500 uppercase tracking-wider mb-2">Needs Improvement</p>
              <CoachingFeedbackList items={agent.improvements} variant="improvement" emptyText="No improvement areas recorded yet." />
            </div>
            <div>
              <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-2">Suggested Script Lines</p>
              <CoachingFeedbackList items={agent.scriptSuggestions} variant="script" emptyText="No script suggestions yet." />
            </div>
            <div>
              <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-2">Coaching Recommendations</p>
              <CoachingFeedbackList items={agent.recommendations} variant="recommendation" emptyText="No recommendations yet." />
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
}