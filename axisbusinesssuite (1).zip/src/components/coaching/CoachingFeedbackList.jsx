import React from 'react';
import { Star, Target, Lightbulb, AlertCircle } from 'lucide-react';

const VARIANTS = {
  strength: { icon: Star, color: 'text-emerald-500', label: 'Strengths' },
  improvement: { icon: Target, color: 'text-red-500', label: 'Needs Improvement' },
  script: { icon: Lightbulb, color: 'text-primary', label: 'Suggested Script Lines' },
  recommendation: { icon: AlertCircle, color: 'text-amber-500', label: 'Coaching Recommendations' },
};

// items: string[] ; variant: key of VARIANTS
export default function CoachingFeedbackList({ items, variant, emptyText }) {
  const v = VARIANTS[variant] || VARIANTS.recommendation;
  const Icon = v.icon;
  const list = (items || []).filter(Boolean);
  if (!list.length) {
    return <p className="text-xs text-muted-foreground italic">{emptyText || 'No feedback recorded yet.'}</p>;
  }
  return (
    <div className="space-y-1.5">
      {list.map((text, i) => (
        <div key={i} className="text-xs flex items-start gap-2">
          <Icon className={`w-3 h-3 ${v.color} flex-shrink-0 mt-0.5`} />
          <span className="leading-relaxed">{text}</span>
        </div>
      ))}
    </div>
  );
}