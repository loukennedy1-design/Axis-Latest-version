import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Star, Quote } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

function StarRating({ n, size = 'w-4 h-4' }) {
  return (
    <div className="flex gap-0.5">
      {Array(5).fill(0).map((_, i) => (
        <Star
          key={i}
          className={`${size} ${i < n ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`}
        />
      ))}
    </div>
  );
}

function initials(name) {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] || '') + (parts[1]?.[0] || '')).toUpperCase() || name[0].toUpperCase();
}

export default function UserReviewsSection() {
  const { data: reviews } = useQuery({
    queryKey: ['public-user-reviews'],
    queryFn: () => base44.entities.UserReview.filter({ status: 'approved' }, '-created_date', 12),
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  const list = Array.isArray(reviews) ? reviews : [];
  const avg = list.length ? list.reduce((s, r) => s + (r.rating || 0), 0) / list.length : 0;

  return (
    <section id="reviews" className="px-4 py-16 bg-muted/30">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <Badge className="mb-3">Customer Reviews</Badge>
          <h2 className="text-3xl md:text-4xl font-black mb-2">What Customers Are Saying</h2>
          <p className="text-muted-foreground text-sm">
            Real reviews, submitted directly by AXIS Business Suite customers
          </p>
          {list.length > 0 && (
            <div className="flex items-center justify-center gap-2 mt-3">
              <StarRating n={Math.round(avg)} size="w-5 h-5" />
              <span className="text-sm font-semibold">{avg.toFixed(1)}</span>
              <span className="text-sm text-muted-foreground">· {list.length} review{list.length === 1 ? '' : 's'}</span>
            </div>
          )}
        </div>

        {list.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-border bg-card/50 p-10 text-center space-y-3 max-w-xl mx-auto">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/10 flex items-center justify-center">
              <Quote className="w-7 h-7 text-amber-500" />
            </div>
            <h3 className="font-bold text-lg">Be the first to share your experience</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Reviews from our customers appear here. After 30 days with AXIS, you'll get a prompt inside the app to leave your own review.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {list.map((r) => (
              <Card key={r.id} className="break-inside-avoid">
                <CardContent className="p-5 space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                      {initials(r.author_name)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold truncate">{r.author_name || 'Verified Customer'}</p>
                      <StarRating n={r.rating || 0} />
                    </div>
                  </div>
                  {r.title && <p className="font-semibold text-sm">{r.title}</p>}
                  <p className="text-sm text-muted-foreground leading-relaxed">"{r.body}"</p>
                  {r.industry && (
                    <p className="text-[11px] text-muted-foreground/70 pt-1 border-t border-border/50">
                      {r.industry}
                    </p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}