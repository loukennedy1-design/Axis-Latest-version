const STATS = [
  { value: '500+', label: 'Businesses' },
  { value: '40+', label: 'Modules' },
  { value: '$29/mo', label: 'Starting Price' },
  { value: '7-Day', label: 'Free Trial' },
];

export default function SocialProofStats() {
  return (
    <section className="px-4 py-10">
      <div className="max-w-5xl mx-auto rounded-2xl bg-card border border-border shadow-lg p-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {STATS.map((s) => (
            <div key={s.value}>
              <p className="text-4xl md:text-5xl font-black text-primary tracking-tight">{s.value}</p>
              <p className="text-sm text-muted-foreground mt-1 font-medium uppercase tracking-wider">{s.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}