import React, { useState } from 'react';
import { Star, ExternalLink, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

// Google Places embed for real reviews — no OAuth needed.
// Replace PLACE_ID with your Google Business Place ID to show real reviews.
const GOOGLE_PLACE_ID = ''; // TODO: set your Google Business Place ID here

function StarRating({ n }) {
  return (
    <div className="flex gap-0.5">
      {Array(5).fill(0).map((_, i) => (
        <Star key={i} className={`w-4 h-4 ${i < n ? 'fill-amber-400 text-amber-400' : 'text-muted-foreground/30'}`} />
      ))}
    </div>
  );
}

export default function GoogleReviewsSection() {
  const hasPlaceId = !!GOOGLE_PLACE_ID;

  return (
    <section id="reviews" className="px-4 py-16 bg-muted/30">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <Badge className="mb-3">Verified Reviews</Badge>
          <h2 className="text-3xl md:text-4xl font-black mb-2">What Customers Are Saying</h2>
          <p className="text-muted-foreground text-sm">
            Real reviews from Google Business — verified customers only
          </p>
        </div>

        {hasPlaceId ? (
          // When Place ID is set: embed Google Maps reviews widget
          <div className="rounded-2xl overflow-hidden border border-border shadow-lg">
            <iframe
              title="Google Reviews"
              width="100%"
              height="420"
              style={{ border: 0 }}
              loading="lazy"
              allowFullScreen
              referrerPolicy="no-referrer-when-downgrade"
              src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyD-placeholder&q=place_id:${GOOGLE_PLACE_ID}`}
            />
          </div>
        ) : (
          // Placeholder state — guide the admin to connect their Google Business
          <div className="rounded-2xl border-2 border-dashed border-border bg-card/50 p-10 text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-500/10 flex items-center justify-center">
              <svg viewBox="0 0 24 24" className="w-8 h-8" fill="none">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Connect Your Google Business Reviews</h3>
              <p className="text-muted-foreground text-sm max-w-md mx-auto leading-relaxed">
                Display real verified Google reviews on this page. Add your Google Business <strong>Place ID</strong> in the component to activate live reviews.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => window.open('https://developers.google.com/maps/documentation/places/web-service/place-id', '_blank')}
              >
                <ExternalLink className="w-4 h-4" />
                Find My Place ID
              </Button>
              <Button
                variant="outline"
                className="gap-2"
                onClick={() => window.open('https://business.google.com', '_blank')}
              >
                <ExternalLink className="w-4 h-4" />
                Google Business Profile
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-4">
              Once your Place ID is set in <code className="bg-muted px-1 rounded">components/landing/GoogleReviewsSection.jsx</code>, live Google reviews will appear here automatically.
            </p>

            {/* Sample layout preview */}
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left opacity-40 pointer-events-none select-none">
              {[
                { name: 'J. Anderson', rating: 5, text: 'Incredible platform — replaced 6 tools in one day.' },
                { name: 'M. Rodriguez', rating: 5, text: 'The AI call bot alone pays for the whole subscription.' },
                { name: 'S. Patel', rating: 5, text: 'Onboarding was fast. Support team is phenomenal.' },
              ].map((r) => (
                <Card key={r.name}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">{r.name[0]}</div>
                      <div>
                        <p className="text-xs font-semibold">{r.name}</p>
                        <StarRating n={r.rating} />
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground italic">"{r.text}"</p>
                    <div className="flex items-center gap-1 mt-2">
                      <svg viewBox="0 0 24 24" className="w-3 h-3" fill="none">
                        <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                      </svg>
                      <span className="text-[10px] text-muted-foreground">Google Review · Awaiting live data</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}