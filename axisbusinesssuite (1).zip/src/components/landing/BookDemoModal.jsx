import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Calendar, X } from 'lucide-react';

const FALLBACK_CALENDLY_URL = 'https://calendly.com/axis-business-suite/demo';

export default function BookDemoModal({ calendlyUrl, open, onOpenChange }) {
  const url = calendlyUrl || FALLBACK_CALENDLY_URL;
  const [iframeLoaded, setIframeLoaded] = useState(false);

  const iframeUrl = url.includes('?')
    ? `${url}&embed_domain=${encodeURIComponent(window.location.origin)}`
    : `${url}?embed_domain=${encodeURIComponent(window.location.origin)}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden p-0 sm:p-0">
        <DialogHeader className="p-6 pb-0 sr-only">
          <DialogTitle>Book a Demo</DialogTitle>
          <DialogDescription>Schedule a live walkthrough of Axis Business Suite</DialogDescription>
        </DialogHeader>
        <div className="relative">
          {!iframeLoaded && (
            <div className="flex items-center justify-center h-[500px] text-muted-foreground text-sm">
              <span className="flex items-center gap-2"><Calendar className="w-5 h-5 animate-pulse" /> Loading calendar...</span>
            </div>
          )}
          <iframe
            title="Book a Demo"
            src={iframeUrl}
            width="100%"
            height="600"
            frameBorder="0"
            className={iframeLoaded ? 'w-full' : 'hidden'}
            onLoad={() => setIframeLoaded(true)}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}