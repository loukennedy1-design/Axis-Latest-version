import { useEffect } from 'react';

const META_DESCRIPTION =
  'AI Business Software and AI Sales Automation CRM — Axis Business Suite replaces 8+ tools with one platform. AI call bot, CRM, lead generation, HR, compliance, and social media automation. Start your 7-day free trial from $29/mo.';

export default function SEOHead() {
  useEffect(() => {
    // Meta description
    let meta = document.querySelector('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.setAttribute('name', 'description');
      document.head.appendChild(meta);
    }
    meta.setAttribute('content', META_DESCRIPTION);

    const appName = 'Axis Business Suite';
    const appUrl = window.location.origin;
    const logoUrl =
      'https://media.base44.com/images/public/69ef71210cace64a00bec165/db6b11da8_ChatGPTImageMay8202612_44_40PM.png';

    const FAQS_SCHEMA = [
      {
        '@type': 'Question',
        name: 'Do I need a credit card to start the free trial?',
        acceptedAnswer: { '@type': 'Answer', text: 'Yes — we collect your card securely at signup via Square, but you won\'t be charged for 7 days. Cancel before the trial ends and you\'ll never pay a cent.' },
      },
      {
        '@type': 'Question',
        name: 'Can I cancel anytime?',
        acceptedAnswer: { '@type': 'Answer', text: 'Yes — cancel anytime with no penalty or long-term contracts. Your data is always yours to export.' },
      },
      {
        '@type': 'Question',
        name: 'What\'s the difference between monthly and yearly billing?',
        acceptedAnswer: { '@type': 'Answer', text: 'Yearly billing saves you 15% compared to paying month-to-month. You pay once upfront and save significantly over the year.' },
      },
      {
        '@type': 'Question',
        name: 'Can I upgrade or downgrade my plan?',
        acceptedAnswer: { '@type': 'Answer', text: 'Absolutely. You can switch plans at any time. Upgrades take effect immediately, downgrades apply at your next billing cycle.' },
      },
      {
        '@type': 'Question',
        name: 'Does the AI call bot require any special phone hardware?',
        acceptedAnswer: { '@type': 'Answer', text: 'No. The AI call bot runs 100% in the cloud via your internet browser. No hardware, headsets, or VoIP setup needed.' },
      },
      {
        '@type': 'Question',
        name: 'Is there onboarding support?',
        acceptedAnswer: { '@type': 'Answer', text: 'Yes! All plans come with access to the Learning Hub with step-by-step guides for every feature, plus email support.' },
      },
    ];

    const schemas = [
      {
        '@context': 'https://schema.org',
        '@type': 'Organization',
        name: appName,
        url: appUrl,
        logo: logoUrl,
        contactPoint: { '@type': 'ContactPoint', telephone: '+1-844-AXIS-BIZ', contactType: 'customer service' },
      },
      {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: FAQS_SCHEMA,
      },
      {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        name: appName,
        operationSystem: 'Web',
        applicationCategory: 'BusinessApplication',
        offers: {
          '@type': 'Offer',
          price: '29.00',
          priceCurrency: 'USD',
          description: 'Starting at $29/mo with a 7-day free trial',
        },
        aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.8', ratingCount: '521' },
        featureList: 'AI Call Bot, CRM, Lead Generation, Social Media AI, Video Marketing AI, HR Suite, Recruitment ATS, Email Client, SMS, Zoom Scheduler, Compliance Suite, Financial Ops, API Center',
      },
    ];

    schemas.forEach((schema) => {
      const id = `ld-${schema['@type']}`;
      let el = document.getElementById(id);
      if (!el) {
        el = document.createElement('script');
        el.setAttribute('type', 'application/ld+json');
        el.id = id;
        document.head.appendChild(el);
      }
      el.textContent = JSON.stringify(schema);
    });

    return () => {
      if (meta) meta.remove();
      ['Organization', 'FAQPage', 'SoftwareApplication'].forEach((t) =>
        document.getElementById(`ld-${t}`)?.remove()
      );
    };
  }, []);

  return null;
}