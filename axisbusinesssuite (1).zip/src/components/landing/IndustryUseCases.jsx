import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Home, ShieldCheck, Sun, Users, UserSearch, Banknote, ShoppingCart, HeartPulse, ChevronRight
} from 'lucide-react';

const INDUSTRIES = [
  {
    icon: Home,
    label: 'Real Estate',
    desc: 'AI agents prospect buyers, schedule showings, and follow up with leads 24/7 so your agents stay focused on closings.',
    color: 'text-blue-600', bg: 'bg-blue-500/10',
  },
  {
    icon: ShieldCheck,
    label: 'Insurance',
    desc: 'Automate policy-renewal calls, compliance-record disclosures, and cross-sell campaigns with built-in TCPA regulations.',
    color: 'text-red-500', bg: 'bg-red-500/10',
  },
  {
    icon: Sun,
    label: 'Solar',
    desc: 'Qualify homeowners, book site surveys, and nurture leads through your entire install pipeline automatically.',
    color: 'text-amber-500', bg: 'bg-amber-500/10',
  },
  {
    icon: Users,
    label: 'Agencies',
    desc: 'Manage multi-client campaigns under one CRM—AI handles outreach, reporting, and onboarding for every account.',
    color: 'text-purple-600', bg: 'bg-purple-500/10',
  },
  {
    icon: UserSearch,
    label: 'Recruiting',
    desc: 'AI scores candidates from Indeed, schedules Zoom interviews, and keeps your pipeline moving without manual screening.',
    color: 'text-violet-600', bg: 'bg-violet-500/10',
  },
  {
    icon: Banknote,
    label: 'Finance',
    desc: 'Track invoices, expenses, payroll, and P&L in one place while AI books meetings with high-intent clients.',
    color: 'text-emerald-600', bg: 'bg-emerald-500/10',
  },
  {
    icon: ShoppingCart,
    label: 'E-commerce',
    desc: 'Automate abandoned-cart recovery calls, reorder reminders, and customer-winback campaigns across your store.',
    color: 'text-rose-600', bg: 'bg-rose-500/10',
  },
  {
    icon: HeartPulse,
    label: 'Healthcare',
    desc: 'HIPAA-aware appointment reminders, new-patient intake calls, and compliance-tracking without violating regulations.',
    color: 'text-cyan-600', bg: 'bg-cyan-500/10',
  },
];

export default function IndustryUseCases() {
  return (
    <section id="industries" className="px-4 py-16 bg-card/40">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <Badge className="mb-3">Built for Your Industry</Badge>
          <h2 className="text-3xl md:text-4xl font-black mb-3">
            AI Sales Automation CRM <span className="text-primary">for Every Vertical</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Axis Business Suite adapts to how your industry sells — outbound, compliance, or high-volume. One platform, your rules.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {INDUSTRIES.map(({ icon: Icon, label, desc, color, bg }) => (
            <Card key={label} className="group hover:shadow-lg hover:border-primary/30 transition-all cursor-default">
              <CardContent className="p-5 flex gap-3 sm:flex-col sm:text-left">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bg} shrink-0`}>
                  <Icon className={`w-5 h-5 ${color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-sm mb-1">{label}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}