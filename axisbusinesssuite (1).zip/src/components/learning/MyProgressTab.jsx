import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Clock, Award, AlertCircle, ArrowRight, History } from 'lucide-react';
import ProgressRing from './ProgressRing';
import { DEFAULT_COURSES, ROLE_PATHS, ROLES } from './defaultCourses';

export default function MyProgressTab({ userProgress, selectedRole, onSelectCourse }) {
  const allModules = DEFAULT_COURSES;
  const completedCount = allModules.filter(m => userProgress[m.id]?.completed).length;
  const overallProgress = Math.round((completedCount / allModules.length) * 100);

  const path = ROLE_PATHS[selectedRole] || ROLE_PATHS.business_owner;
  const pathModules = path.modules.map(id => allModules.find(c => c.id === id)).filter(Boolean);
  const completedInPath = pathModules.filter(m => userProgress[m.id]?.completed).length;
  const pathProgress = Math.round((completedInPath / pathModules.length) * 100);

  const totalTimeSpent = Object.values(userProgress).reduce((sum, p) => sum + (p.time_spent_seconds || 0), 0);
  const hoursSpent = Math.floor(totalTimeSpent / 3600);
  const minutesSpent = Math.floor((totalTimeSpent % 3600) / 60);

  const avgScore = Object.values(userProgress).filter(p => p.quiz_score !== undefined).reduce((sum, p, _, arr) => sum + p.quiz_score / arr.length, 0);

  const weakModules = pathModules.filter(m => {
    const p = userProgress[m.id];
    return p && !p.completed;
  });

  const nextModule = pathModules.find(m => !userProgress[m.id]?.completed);

  const timeline = Object.entries(userProgress)
    .filter(([_, p]) => p.completed_at)
    .sort((a, b) => new Date(b[1].completed_at) - new Date(a[1].completed_at));

  return (
    <div className="space-y-5">
      {/* Overview cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <ProgressRing value={overallProgress} size={80} stroke={7} color="hsl(0, 100%, 50%)" label="Overall" />
            <div>
              <p className="text-xs text-muted-foreground">Overall Completion</p>
              <p className="text-2xl font-bold">{completedCount}/{allModules.length}</p>
              <p className="text-xs text-muted-foreground">modules completed</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <ProgressRing value={pathProgress} size={80} stroke={7} color="hsl(162, 63%, 47%)" label="Path" />
            <div>
              <p className="text-xs text-muted-foreground">{ROLES.find(r => r.id === selectedRole)?.label} Path</p>
              <p className="text-2xl font-bold">{completedInPath}/{pathModules.length}</p>
              <p className="text-xs text-muted-foreground">{path.certName}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5 flex items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
              <Clock className="w-8 h-8 text-primary" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Time Spent</p>
              <p className="text-2xl font-bold">{hoursSpent}h {minutesSpent}m</p>
              <p className="text-xs text-muted-foreground">learning time</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quiz scores + weak areas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-5">
            <h3 className="font-bold text-sm flex items-center gap-2 mb-3"><Award className="w-4 h-4 text-primary" /> Quiz Scores</h3>
            <div className="space-y-2">
              {pathModules.map(m => {
                const p = userProgress[m.id];
                const score = p?.quiz_score;
                const passed = p?.completed;
                return (
                  <div key={m.id} className="flex items-center gap-2 text-sm">
                    <m.icon className={`w-4 h-4 ${m.color} shrink-0`} />
                    <span className="flex-1 truncate">{m.title}</span>
                    {score !== undefined ? (
                      <Badge variant="outline" className={passed ? 'text-emerald-500 border-emerald-500/30' : 'text-red-500 border-red-500/30'}>{score}/5</Badge>
                    ) : (
                      <Badge variant="outline" className="text-muted-foreground">—</Badge>
                    )}
                  </div>
                );
              })}
            </div>
            {Object.values(userProgress).filter(p => p.quiz_score !== undefined).length > 0 && (
              <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Average Score</span>
                <span className="text-lg font-bold text-primary">{avgScore.toFixed(1)}/5</span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-5">
            <h3 className="font-bold text-sm flex items-center gap-2 mb-3"><AlertCircle className="w-4 h-4 text-amber-500" /> Recommended Next Steps</h3>
            {nextModule ? (
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-3 mb-3">
                <p className="text-xs text-muted-foreground mb-1">Continue Learning</p>
                <div className="flex items-center gap-2">
                  <nextModule.icon className={`w-5 h-5 ${nextModule.color}`} />
                  <div className="flex-1">
                    <p className="font-semibold text-sm">{nextModule.title}</p>
                    <p className="text-xs text-muted-foreground">{nextModule.duration}</p>
                  </div>
                  <button onClick={() => onSelectCourse(nextModule)} className="text-primary text-xs font-medium flex items-center gap-1">
                    Start <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3 mb-3 text-center">
                <p className="text-sm font-semibold text-emerald-500">Path Complete! 🎉</p>
              </div>
            )}
            <p className="text-xs font-semibold text-muted-foreground mb-2">Incomplete Modules</p>
            <div className="space-y-1.5">
              {weakModules.length === 0 ? (
                <p className="text-xs text-muted-foreground">All modules complete!</p>
              ) : weakModules.map(m => (
                <div key={m.id} className="flex items-center gap-2 text-xs">
                  <m.icon className={`w-3.5 h-3.5 ${m.color}`} />
                  <span className="flex-1 truncate">{m.title}</span>
                  <button onClick={() => onSelectCourse(m)} className="text-primary hover:underline">Start</button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Learning history timeline */}
      <Card>
        <CardContent className="p-5">
          <h3 className="font-bold text-sm flex items-center gap-2 mb-3"><History className="w-4 h-4 text-primary" /> Learning History</h3>
          {timeline.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">No completed modules yet. Start learning to build your history!</p>
          ) : (
            <div className="space-y-2">
              {timeline.map(([modId, p]) => {
                const mod = allModules.find(m => m.id === modId);
                if (!mod) return null;
                return (
                  <div key={modId} className="flex items-center gap-3 p-2 rounded-lg border border-border bg-muted/20">
                    <mod.icon className={`w-4 h-4 ${mod.color} shrink-0`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{mod.title}</p>
                      <p className="text-xs text-muted-foreground">{new Date(p.completed_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                    </div>
                    <Badge variant="outline" className="text-emerald-500 border-emerald-500/30">{p.quiz_score}/5</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}