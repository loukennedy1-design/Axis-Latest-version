import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Award, Download, ShieldCheck, Trophy } from 'lucide-react';
import { DEFAULT_COURSES, ROLE_PATHS, ROLES } from './defaultCourses';

export default function CertificationsTab({ userProgress, selectedRole }) {
  const roles = Object.keys(ROLE_PATHS);
  const earnedCerts = roles.filter(roleId => {
    const path = ROLE_PATHS[roleId];
    return path.modules.every(id => userProgress[id]?.completed);
  }).map(roleId => ({
    roleId,
    roleLabel: ROLES.find(r => r.id === roleId)?.label,
    certName: ROLE_PATHS[roleId].certName,
    verificationId: `AXIS-CERT-${roleId.toUpperCase()}-${Date.now().toString(36).toUpperCase().slice(-6)}`,
    dateEarned: pathEarliestDate(userProgress, ROLE_PATHS[roleId].modules),
  }));

  const inProgress = roles.filter(roleId => {
    const path = ROLE_PATHS[roleId];
    const completed = path.modules.filter(id => userProgress[id]?.completed).length;
    return completed > 0 && completed < path.modules.length;
  }).map(roleId => {
    const path = ROLE_PATHS[roleId];
    const completed = path.modules.filter(id => userProgress[id]?.completed).length;
    return { roleId, roleLabel: ROLES.find(r => r.id === roleId)?.label, certName: path.certName, completed, total: path.modules.length };
  });

  const handlePrint = (cert) => {
    const win = window.open('', '_blank');
    win.document.write(`
      <html><head><title>${cert.certName}</title>
      <style>
        body { font-family: 'Inter', Arial, sans-serif; background: #0a0a0a; color: #fff; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .cert { width: 800px; border: 3px solid hsl(0,100%,50%); border-radius: 20px; padding: 60px; text-align: center; background: linear-gradient(135deg, #1a1a1a, #0a0a0a); }
        h1 { font-size: 36px; color: hsl(0,100%,50%); margin-bottom: 10px; }
        h2 { font-size: 24px; margin-bottom: 30px; }
        .name { font-size: 28px; font-weight: bold; margin: 20px 0; }
        .meta { color: #999; font-size: 14px; margin-top: 30px; }
        .badge { font-size: 64px; }
      </style></head><body>
      <div class="cert">
        <div class="badge">🏆</div>
        <h1>Certificate of Completion</h1>
        <p>This certifies that</p>
        <div class="name">${cert.roleLabel}</div>
        <p>has successfully completed all required modules and is hereby recognized as a</p>
        <h2>${cert.certName}</h2>
        <div class="meta">
          Verification ID: ${cert.verificationId}<br>
          Date Earned: ${new Date(cert.dateEarned).toLocaleDateString()}<br>
          AXIS Business Super Suite Learning Center
        </div>
      </div>
      </body></html>
    `);
    win.document.close();
    setTimeout(() => win.print(), 500);
  };

  return (
    <div className="space-y-5">
      {earnedCerts.length === 0 && inProgress.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Award className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="font-semibold">No certifications yet</p>
            <p className="text-sm text-muted-foreground mt-1">Complete all modules in a learning path to earn a certificate.</p>
          </CardContent>
        </Card>
      )}

      {/* Earned certs */}
      {earnedCerts.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {earnedCerts.map(cert => (
            <Card key={cert.roleId} className="border-primary/30 bg-gradient-to-br from-primary/10 via-card to-purple-500/5">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-primary/20 flex items-center justify-center shrink-0">
                    <Trophy className="w-7 h-7 text-primary" />
                  </div>
                  <div className="flex-1">
                    <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 mb-2"><ShieldCheck className="w-3 h-3 mr-1" /> Earned</Badge>
                    <h3 className="font-bold text-base">{cert.certName}</h3>
                    <p className="text-xs text-muted-foreground mt-1">Earned {new Date(cert.dateEarned).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</p>
                    <p className="text-[10px] text-muted-foreground mt-2 font-mono">ID: {cert.verificationId}</p>
                    <Button size="sm" variant="outline" className="mt-3" onClick={() => handlePrint(cert)}>
                      <Download className="w-3 h-3 mr-1" /> Print / Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* In progress */}
      {inProgress.length > 0 && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">In Progress</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {inProgress.map(cert => (
              <Card key={cert.roleId} className="border-border bg-muted/20">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0">
                      <Award className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1">
                      <p className="font-semibold text-sm">{cert.certName}</p>
                      <p className="text-xs text-muted-foreground">{cert.completed}/{cert.total} modules complete</p>
                    </div>
                    <Badge variant="outline" className="text-amber-500 border-amber-500/30">{Math.round((cert.completed / cert.total) * 100)}%</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function pathEarliestDate(userProgress, moduleIds) {
  const dates = moduleIds.map(id => userProgress[id]?.completed_at).filter(Boolean).sort();
  return dates[0] || new Date().toISOString();
}