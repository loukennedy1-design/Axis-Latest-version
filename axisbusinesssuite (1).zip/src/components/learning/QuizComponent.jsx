import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { PASSING_SCORE } from './defaultCourses';

export default function QuizComponent({ quiz, onPass, onFail, onContinue }) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answered, setAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  const handleRetake = () => {
    setCurrentQ(0);
    setSelected(null);
    setAnswered(false);
    setScore(0);
    setDone(false);
  };

  const handleSelect = (idx) => {
    if (answered) return;
    setSelected(idx);
    setAnswered(true);
    if (idx === quiz[currentQ].answer) setScore(s => s + 1);
  };

  const handleNext = () => {
    if (currentQ + 1 >= quiz.length) {
      setDone(true);
      const finalScore = score;
      if (finalScore >= PASSING_SCORE) onPass(finalScore);
      else onFail(finalScore);
    } else {
      setCurrentQ(q => q + 1);
      setSelected(null);
      setAnswered(false);
    }
  };

  if (done) {
    const passed = score >= PASSING_SCORE;
    return (
      <div className={`rounded-xl p-6 border text-center ${passed ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-red-500/10 border-red-500/20'}`}>
        <div className="text-4xl mb-3">{passed ? '🎉' : '📚'}</div>
        <p className="font-bold text-lg">{passed ? 'Module Passed!' : 'Almost There!'}</p>
        <p className="text-sm text-muted-foreground mt-1">You scored {score} out of {quiz.length}</p>
        {!passed && <p className="text-sm mt-2">Review the lesson and try again — you need {PASSING_SCORE}/5 to pass.</p>}
        {!passed && (
          <Button onClick={handleRetake} className="mt-4" variant="outline">
            Try Again
          </Button>
        )}
        {passed && onContinue && (
          <Button onClick={onContinue} className="mt-4">
            Back to Library →
          </Button>
        )}
      </div>
    );
  }

  const q = quiz[currentQ];
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Question {currentQ + 1} of {quiz.length}</p>
        <Progress value={((currentQ) / quiz.length) * 100} className="w-24 h-2" />
      </div>
      <p className="font-semibold text-sm leading-relaxed">{q.q}</p>
      <div className="space-y-2">
        {q.options.map((opt, idx) => {
          let style = 'border-border bg-card hover:bg-muted/50 cursor-pointer';
          if (answered) {
            if (idx === q.answer) style = 'border-emerald-500 bg-emerald-500/10';
            else if (idx === selected && idx !== q.answer) style = 'border-red-500 bg-red-500/10';
            else style = 'border-border bg-muted/20 opacity-50';
          }
          return (
            <button key={idx} onClick={() => handleSelect(idx)}
              className={`w-full text-left p-3 rounded-lg border text-sm transition-all ${style}`}>
              <span className="font-medium mr-2">{['A', 'B', 'C', 'D'][idx]}.</span>{opt}
            </button>
          );
        })}
      </div>
      {answered && (
        <Button onClick={handleNext} className="w-full">
          {currentQ + 1 >= quiz.length ? 'See Results' : 'Next Question'} →
        </Button>
      )}
    </div>
  );
}