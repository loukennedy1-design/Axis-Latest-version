import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, ArrowLeft, ClipboardCheck, Play, FileText, Download, RefreshCw, AlertTriangle, Loader2, Clock, CheckCircle2 } from 'lucide-react';
import QuizComponent from './QuizComponent';

export default function CourseViewer({ course, aiContent, isOutdated, isAdmin, isGenerating, userProgress, onPassQuiz, onFailQuiz, onRegenerate, onMarkOutdated, onBack }) {
  const [view, setView] = useState('lesson');
  const [showScript, setShowScript] = useState(false);

  const hasVideo = !!(aiContent?.video_url || course.videoUrl);
  const videoUrl = aiContent?.video_url || course.videoUrl;
  const script = aiContent?.script || '';
  const outline = aiContent?.outline;
  const rawQuiz = aiContent?.quiz?.questions || course.quiz;
  const quiz = rawQuiz?.map(item => ({
    q: item.q || item.question,
    options: item.options || [],
    answer: item.answer ?? 0
  }));
  const takeaways = aiContent?.key_takeaways || course.keyTakeaways;
  const quickRef = aiContent?.quick_reference || course.quickReference;

  const isCompleted = userProgress?.completed;

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3 flex-wrap">
        <Button variant="default" size="sm" onClick={onBack} className="gap-1.5 font-semibold shadow-md">
          <ArrowLeft className="w-4 h-4" /> Back to Academy
        </Button>
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-lg ${course.bgColor} flex items-center justify-center`}>
            <course.icon className={`w-4 h-4 ${course.color}`} />
          </div>
          <div>
            <p className="font-bold text-sm">{course.title}</p>
            <p className="text-xs text-muted-foreground">{course.duration} · {course.lessons.length} lessons</p>
          </div>
        </div>
        {isCompleted && <Badge className="ml-auto bg-emerald-500/10 text-emerald-500 border-emerald-500/20">✓ Completed</Badge>}
      </div>

      {/* Outdated banner */}
      {isOutdated && !isGenerating && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-amber-500">Content Outdated — Regenerate?</p>
            <p className="text-xs text-muted-foreground">This feature has been updated. Regenerate the AI content to reflect the latest changes.</p>
          </div>
          <Button size="sm" variant="outline" onClick={onRegenerate} className="border-amber-500/30 text-amber-500 hover:bg-amber-500/10">
            <RefreshCw className="w-3 h-3 mr-1" /> Regenerate
          </Button>
        </div>
      )}

      {/* Regenerating indicator */}
      {isGenerating && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-primary/10 border border-primary/30">
          <Loader2 className="w-5 h-5 text-primary shrink-0 animate-spin" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-primary">Regenerating AI Content...</p>
            <p className="text-xs text-muted-foreground">Generating lesson outline, instructor script, quiz, takeaways, and quick-reference guide.</p>
          </div>
        </div>
      )}

      {/* Admin controls */}
      {isAdmin && !isOutdated && !isGenerating && (
        <div className="flex items-center gap-2 justify-end">
          <Button size="sm" variant="ghost" onClick={onMarkOutdated} className="text-xs">
            <AlertTriangle className="w-3 h-3 mr-1" /> Mark as Outdated
          </Button>
          <Button size="sm" variant="ghost" onClick={onRegenerate} className="text-xs">
            <RefreshCw className="w-3 h-3 mr-1" /> Regenerate Content
          </Button>
        </div>
      )}

      {/* Tab switcher */}
      <div className="flex gap-2">
        {['lesson', 'quiz'].map(v => (
          <Button key={v} variant={view === v ? 'default' : 'outline'} size="sm"
            onClick={() => setView(v)} className="capitalize">
            {v === 'lesson' ? '📖 Lesson' : '📝 Module Test'}
          </Button>
        ))}
      </div>

      {view === 'lesson' && (
        <Card>
          <CardContent className="p-6 space-y-6">
            {/* Video player shell */}
            <div className="relative rounded-xl overflow-hidden border border-border bg-gradient-to-br from-muted via-card to-muted/50 aspect-video group">
              {hasVideo ? (
                <video src={videoUrl} controls className="w-full h-full" />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                    <Play className="w-7 h-7 text-primary" />
                  </div>
                  <Badge className="mb-2 bg-primary/10 text-primary border-primary/20 animate-pulse">
                    <Clock className="w-3 h-3 mr-1" /> Production Queue
                  </Badge>
                  <p className="text-xs text-muted-foreground max-w-xs">Video production pending. Connect a video API (HeyGen, Synthesia) to auto-generate.</p>
                  <Button variant="outline" size="sm" className="mt-3" onClick={() => setShowScript(!showScript)}>
                    <FileText className="w-3 h-3 mr-1" /> {showScript ? 'Hide' : 'Preview'} Script
                  </Button>
                  {showScript && script && (
                    <div className="mt-3 max-h-32 overflow-y-auto text-left text-xs text-muted-foreground bg-background/50 p-3 rounded-lg border border-border max-w-md">
                      {script.slice(0, 500)}...
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Description */}
            <div className={`rounded-xl ${course.bgColor} border border-border p-4`}>
              <p className="font-semibold text-sm">{course.description}</p>
            </div>

            {/* Lesson outline */}
            <div>
              <h3 className="font-bold mb-3">What You'll Learn</h3>
              <div className="space-y-2">
                {(outline?.lessons || course.lessons).map((lesson, i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-border bg-muted/20">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-xs font-bold text-primary shrink-0 mt-0.5">{i + 1}</div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{lesson.title}</p>
                      <p className="text-xs text-muted-foreground">{lesson.duration}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Key takeaways */}
            {takeaways && takeaways.length > 0 && (
              <div>
                <h3 className="font-bold mb-3">Key Takeaways</h3>
                <div className="space-y-2">
                  {takeaways.map((t, i) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span>{t}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick reference download */}
            {quickRef && (
              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-sm flex items-center gap-2"><Download className="w-4 h-4" /> Quick Reference Guide</p>
                    <p className="text-xs text-muted-foreground mt-1">{quickRef}</p>
                  </div>
                </div>
              </div>
            )}

            <Button className="w-full" onClick={() => setView('quiz')}>
              Take Module Test <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </CardContent>
        </Card>
      )}

      {view === 'quiz' && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4" /> Module Test — {course.title}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="bg-muted/30 rounded-lg p-3 text-xs text-muted-foreground mb-4">
              Answer all 5 questions. You need 4 out of 5 to pass.
            </div>
            <QuizComponent
              quiz={quiz}
              onPass={onPassQuiz}
              onFail={onFailQuiz}
              onContinue={onBack}
            />
          </CardContent>
        </Card>
      )}
    </div>
  );
}