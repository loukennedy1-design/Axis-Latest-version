import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Film, Loader2, Download, Clapperboard, Music, User, Palette, Sparkles, FileText, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import VideoGenerator from '@/components/shared/VideoGenerator';

const VIDEO_TYPES = [
  { value: '30_sec_teaser', label: '30-Second Teaser' },
  { value: '60_sec_overview', label: '60-Second Overview' },
  { value: '3_min_explainer', label: '3-Minute Explainer' },
  { value: 'social_clip', label: 'Social Media Clip' },
  { value: 'product_launch', label: 'Product Launch' },
  { value: 'commercial', label: 'Commercial' },
  { value: 'testimonial', label: 'Testimonial Video' },
];

const TONES = [
  { value: 'sales', label: 'Sales' },
  { value: 'educational', label: 'Educational' },
  { value: 'corporate', label: 'Corporate' },
  { value: 'energetic', label: 'Energetic' },
];

export default function MarketingStudioTab() {
  const [topic, setTopic] = useState('');
  const [videoType, setVideoType] = useState('60_sec_overview');
  const [tone, setTone] = useState('sales');
  const [generating, setGenerating] = useState(false);
  const [brief, setBrief] = useState(null);
  const [savedBriefs, setSavedBriefs] = useState([]);

  useEffect(() => {
    loadBriefs();
  }, []);

  const loadBriefs = async () => {
    try {
      const res = await base44.entities.VideoProductionBrief.list('-created_date', 20);
      setSavedBriefs(res || []);
    } catch (e) { /* ignore */ }
  };

  const handleGenerate = async () => {
    if (!topic.trim()) { toast.error('Please enter a topic'); return; }
    setGenerating(true);
    try {
      const res = await base44.functions.invoke('generateMarketingBrief', { topic, video_type: videoType, tone });
      if (res.data?.brief) {
        setBrief(res.data.brief);
        toast.success('Brief generated and saved!');
        loadBriefs();
      } else {
        toast.error('Failed to generate brief');
      }
    } catch (e) {
      toast.error(e.message || 'Generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const handleExport = () => {
    if (!brief) return;
    const text = `VIDEO PRODUCTION BRIEF\n\nTopic: ${topic}\nType: ${VIDEO_TYPES.find(v => v.value === videoType)?.label}\nTone: ${tone}\n\nHOOK:\n${brief.hook}\n\nSCRIPT:\n${brief.script}\n\nSHOT LIST:\n${(brief.shot_list || []).map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\nCALL TO ACTION:\n${brief.cta}\n\nMUSIC MOOD:\n${brief.music_mood}\n\nAVATAR STYLE:\n${brief.avatar_style}\n\nBRANDING NOTES:\n${brief.branding_notes}\n`;
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `brief-${topic.replace(/\s+/g, '-')}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDelete = async (id) => {
    try {
      await base44.entities.VideoProductionBrief.delete(id);
      loadBriefs();
      toast.success('Brief deleted');
    } catch (e) { toast.error('Failed to delete'); }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      {/* Left: Config form */}
      <Card>
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Clapperboard className="w-5 h-5 text-primary" />
            <h3 className="font-bold">Video Configuration</h3>
          </div>

          <div className="space-y-2">
            <Label>Topic / Feature</Label>
            <Input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g. AI Call Bot, Lead Generator, Social Media AI..." />
          </div>

          <div className="space-y-2">
            <Label>Video Type</Label>
            <Select value={videoType} onValueChange={setVideoType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {VIDEO_TYPES.map(v => <SelectItem key={v.value} value={v.value}>{v.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Tone</Label>
            <Select value={tone} onValueChange={setTone}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TONES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <Button className="w-full" onClick={handleGenerate} disabled={generating}>
            {generating ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating Brief...</> : <><Sparkles className="w-4 h-4 mr-2" /> Generate Brief</>}
          </Button>

          {savedBriefs.length > 0 && (
            <div className="pt-3 border-t border-border">
              <p className="text-xs font-semibold text-muted-foreground mb-2">Saved Briefs ({savedBriefs.length})</p>
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {savedBriefs.map(b => (
                  <div key={b.id} className="flex items-center gap-2 p-2 rounded-lg border border-border bg-muted/20 text-xs">
                    <Film className="w-3 h-3 text-muted-foreground shrink-0" />
                    <span className="truncate flex-1">{b.topic}</span>
                    <Badge variant="outline" className="text-[9px]">{b.video_type.replace(/_/g, ' ')}</Badge>
                    <button onClick={() => { setTopic(b.topic); setVideoType(b.video_type); setTone(b.tone); setBrief(JSON.parse(b.brief_json)); }} className="text-primary hover:underline">Load</button>
                    <button onClick={() => handleDelete(b.id)} className="text-destructive hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Right: Brief output */}
      <Card>
        <CardContent className="p-6">
          {brief ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold flex items-center gap-2"><FileText className="w-5 h-5 text-primary" /> Production Brief</h3>
                <div className="flex items-center gap-2">
                  <VideoGenerator
                    prompt={`Create a ${VIDEO_TYPES.find(v => v.value === videoType)?.label || 'marketing'} video with a ${tone} tone. Hook: ${brief.hook}. Script: ${brief.script}. Shot list: ${(brief.shot_list || []).join('. ')}. Call to action: ${brief.cta}. Music mood: ${brief.music_mood}. Avatar style: ${brief.avatar_style}. Branding: ${brief.branding_notes}.`}
                    label="Generate Video"
                    compact
                  />
                  <Button size="sm" variant="outline" onClick={handleExport}><Download className="w-3 h-3 mr-1" /> Export</Button>
                </div>
              </div>

              <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
                <p className="text-xs font-bold uppercase tracking-wider text-primary mb-1">Hook</p>
                <p className="text-sm">{brief.hook}</p>
              </div>

              <div>
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Full Script</p>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed">{brief.script}</p>
              </div>

              {brief.shot_list && brief.shot_list.length > 0 && (
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Shot List</p>
                  <div className="space-y-1">
                    {brief.shot_list.map((s, i) => (
                      <div key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-xs font-bold text-primary shrink-0 mt-0.5">{i + 1}.</span>
                        <span>{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg border border-border bg-muted/20 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1"><Sparkles className="w-3 h-3" /> CTA</p>
                  <p className="text-sm">{brief.cta}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/20 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1"><Music className="w-3 h-3" /> Music Mood</p>
                  <p className="text-sm">{brief.music_mood}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/20 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1"><User className="w-3 h-3" /> Avatar Style</p>
                  <p className="text-sm">{brief.avatar_style}</p>
                </div>
                <div className="rounded-lg border border-border bg-muted/20 p-3">
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1 flex items-center gap-1"><Palette className="w-3 h-3" /> Branding</p>
                  <p className="text-sm">{brief.branding_notes}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full min-h-[300px] text-center">
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-3">
                <Clapperboard className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-sm font-medium text-muted-foreground">No brief generated yet</p>
              <p className="text-xs text-muted-foreground mt-1 max-w-xs">Configure your video settings on the left and click "Generate Brief" to create a production-ready script.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}