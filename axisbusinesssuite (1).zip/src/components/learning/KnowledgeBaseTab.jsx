import React, { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen, FileText, ArrowRight, Sparkles } from 'lucide-react';
import { DEFAULT_COURSES } from './defaultCourses';

export default function KnowledgeBaseTab({ onSelectCourse }) {
  const [query, setQuery] = useState('');
  const [searched, setSearched] = useState(false);

  const allContent = useMemo(() => {
    const items = [];
    DEFAULT_COURSES.forEach(course => {
      items.push({ type: 'course', courseId: course.id, title: course.title, text: course.description, course });
      course.lessons.forEach((lesson, i) => {
        items.push({ type: 'lesson', courseId: course.id, title: lesson.title, text: `${lesson.title} (${lesson.duration}) — from ${course.title}`, course, lessonIndex: i });
      });
      course.quiz.forEach((q, i) => {
        items.push({ type: 'quiz', courseId: course.id, title: q.q, text: q.options.join(' | '), course, quizIndex: i });
      });
      if (course.keyTakeaways) {
        course.keyTakeaways.forEach((t, i) => {
          items.push({ type: 'takeaway', courseId: course.id, title: `Key Takeaway: ${t}`, text: t, course });
        });
      }
      if (course.quickReference) {
        items.push({ type: 'reference', courseId: course.id, title: `${course.title} — Quick Reference`, text: course.quickReference, course });
      }
    });
    return items;
  }, []);

  const results = query.trim()
    ? allContent.filter(item =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.text.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 20)
    : [];

  const suggestions = query.trim().length > 0 && query.trim().length < 3
    ? ['Connect Systems', 'Call Bot', 'Leads', 'Compliance', 'Settings', 'Appointments', 'SMS', 'Payments', 'Email', 'AI Features']
    : [];

  const typeIcons = {
    course: BookOpen,
    lesson: FileText,
    quiz: Search,
    takeaway: Sparkles,
    reference: FileText,
  };

  const typeLabels = {
    course: 'Course',
    lesson: 'Lesson',
    quiz: 'Quiz Q',
    takeaway: 'Takeaway',
    reference: 'Reference',
  };

  return (
    <div className="space-y-4">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          autoFocus
          value={query}
          onChange={(e) => { setQuery(e.target.value); setSearched(true); }}
          placeholder="Search lessons, topics, quiz questions, or ask anything..."
          className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-card text-sm focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20"
        />
      </div>

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-muted-foreground">You might be looking for:</span>
          {suggestions.map(s => (
            <button key={s} onClick={() => setQuery(s)} className="text-xs px-2 py-1 rounded-full border border-primary/20 bg-primary/5 text-primary hover:bg-primary/10 transition-colors">
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Results */}
      {searched && query.trim() && (
        <div>
          <p className="text-xs text-muted-foreground mb-3">{results.length} result{results.length !== 1 ? 's' : ''} for "{query}"</p>
          {results.length === 0 ? (
            <Card><CardContent className="p-8 text-center">
              <Search className="w-10 h-10 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm font-medium">No results found</p>
              <p className="text-xs text-muted-foreground mt-1">Try a different keyword or browse courses directly.</p>
            </CardContent></Card>
          ) : (
            <div className="space-y-2">
              {results.map((r, i) => {
                const Icon = typeIcons[r.type] || FileText;
                return (
                  <button
                    key={i}
                    onClick={() => onSelectCourse(r.course)}
                    className="w-full flex items-start gap-3 p-3 rounded-lg border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left"
                  >
                    <div className={`w-8 h-8 rounded-lg ${r.course.bgColor} flex items-center justify-center shrink-0`}>
                      <Icon className={`w-4 h-4 ${r.course.color}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <Badge variant="outline" className="text-[9px]">{typeLabels[r.type]}</Badge>
                        <span className="text-[10px] text-muted-foreground">{r.course.title}</span>
                      </div>
                      <p className="text-sm font-medium line-clamp-2">{r.title}</p>
                      {r.type !== 'course' && <p className="text-xs text-muted-foreground line-clamp-1 mt-0.5">{r.text}</p>}
                    </div>
                    <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 mt-1" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Default: browse all courses */}
      {!searched && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">Browse by Course</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {DEFAULT_COURSES.map(course => (
              <button key={course.id} onClick={() => onSelectCourse(course)}
                className="flex items-start gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left">
                <div className={`w-10 h-10 rounded-lg ${course.bgColor} flex items-center justify-center shrink-0`}>
                  <course.icon className={`w-5 h-5 ${course.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{course.title}</p>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{course.description}</p>
                  <p className="text-[10px] text-muted-foreground mt-1">{course.lessons.length} lessons · {course.duration}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}