import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { GraduationCap, CheckCircle2, Lock, ChevronRight, Clock, Trophy, Loader2, RotateCcw } from 'lucide-react';
import { DEFAULT_COURSES, ROLES, ROLE_PATHS } from './defaultCourses';
import ProgressRing from './ProgressRing';

export default function TrainingAcademyTab({ selectedRole, onRoleChange, userProgress, aiContentMap, isAdmin, onGenerateCourse, generatingModule, onOpenCourse, onMarkOutdated }) {
  const [showRolePicker, setShowRolePicker] = useState(!selectedRole);

  // If a role arrives after initial mount (e.g. loaded from saved settings),
  // automatically dismiss the role picker so the module grid shows.
  useEffect(() => {
    if (selectedRole) setShowRolePicker(false);
  }, [selectedRole]);

  const path = ROLE_PATHS[selectedRole] || ROLE_PATHS.business_owner;
  const pathModules = path.modules.map(id => DEFAULT_COURSES.find(c => c.id === id)).filter(Boolean);

  const completedInPath = pathModules.filter(m => userProgress[m.id]?.completed).length;
  const pathProgress = Math.round((completedInPath / pathModules.length) * 100);

  if (showRolePicker) {
    return (
      <div className="max-w-2xl mx-auto space-y-5">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
            <GraduationCap className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-xl font-bold">Choose Your Learning Path</h2>
          <p className="text-sm text-muted-foreground mt-1">Select your role to see relevant courses tailored to you.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {ROLES.map(role => (
            <button
              key={role.id}
              onClick={() => { onRoleChange(role.id); setShowRolePicker(false); }}
              className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left"
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <GraduationCap className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm">{role.label}</p>
                <p className="text-xs text-muted-foreground">{ROLE_PATHS[role.id].modules.length} modules</p>
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Path header */}
      <div className="flex items-center justify-between flex-wrap gap-4 p-4 rounded-xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-purple-500/5">
        <div className="flex items-center gap-3">
          <ProgressRing value={pathProgress} size={64} stroke={6} label="Path" />
          <div>
            <p className="font-bold text-sm">{ROLES.find(r => r.id === selectedRole)?.label} Learning Path</p>
            <p className="text-xs text-muted-foreground">{completedInPath}/{pathModules.length} modules · {path.certName}</p>
          </div>
        </div>
        <Button variant="outline" size="sm" onClick={() => setShowRolePicker(true)}>
          <RotateCcw className="w-3 h-3 mr-1" /> Change Role
        </Button>
      </div>

      {/* Module grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {pathModules.map((mod, idx) => {
          const progress = userProgress[mod.id];
          const isComplete = progress?.completed;
          const isLocked = idx > 0 && !userProgress[pathModules[idx - 1]?.id]?.completed && !isComplete;
          const aiContent = aiContentMap[mod.id];
          const isOutdated = aiContent?.is_outdated;
          const isGenerating = generatingModule === mod.id;

          return (
            <div
              key={mod.id}
              onClick={() => !isLocked && !isGenerating && onOpenCourse(mod)}
              className={`rounded-xl border p-5 transition-all ${
                isLocked ? 'border-border bg-muted/30 opacity-60 cursor-not-allowed'
                : isComplete ? 'border-emerald-500/30 bg-emerald-500/5 cursor-pointer hover:border-emerald-500/50'
                : 'border-border bg-card cursor-pointer hover:border-primary/30 hover:bg-primary/5'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`w-11 h-11 rounded-xl ${mod.bgColor} flex items-center justify-center shrink-0`}>
                  {isGenerating ? <Loader2 className="w-5 h-5 text-primary animate-spin" />
                  : isComplete ? <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                  : isLocked ? <Lock className="w-5 h-5 text-muted-foreground" />
                  : <mod.icon className={`w-5 h-5 ${mod.color}`} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs text-muted-foreground font-medium">{mod.duration}</span>
                    {isComplete && progress?.quiz_score !== undefined && (
                      <Badge variant="outline" className="text-[10px] ml-auto text-emerald-500 border-emerald-500/30">{progress.quiz_score}/5 ✓</Badge>
                    )}
                    {isOutdated && <Badge className="text-[10px] ml-auto bg-amber-500/10 text-amber-500 border-amber-500/20">Outdated</Badge>}
                    {aiContent && !isOutdated && <Badge variant="outline" className="text-[10px] ml-auto text-primary border-primary/20">AI</Badge>}
                  </div>
                  <p className="font-semibold text-sm">{mod.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{mod.description}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-xs text-muted-foreground">{mod.lessons.length} lessons</span>
                    {isGenerating && <span className="text-xs text-primary font-medium ml-auto flex items-center gap-1">Generating...</span>}
                    {!isLocked && !isComplete && !isGenerating && (
                      <span className="text-xs text-primary font-medium ml-auto flex items-center gap-1">Start <ChevronRight className="w-3 h-3" /></span>
                    )}
                    {isComplete && (
                      <span className="text-xs text-emerald-500 font-medium ml-auto flex items-center gap-1">Review <ChevronRight className="w-3 h-3" /></span>
                    )}
                  </div>
                </div>
              </div>
              {isAdmin && !isLocked && (
                <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                  <Button size="sm" variant="ghost" className="text-xs h-7" onClick={(e) => { e.stopPropagation(); onGenerateCourse(mod.id, mod.title, selectedRole); }}>
                    {aiContent ? 'Regenerate AI Content' : 'Generate AI Content'}
                  </Button>
                  {aiContent && !isOutdated && (
                    <Button size="sm" variant="ghost" className="text-xs h-7 text-amber-500" onClick={(e) => { e.stopPropagation(); onMarkOutdated(mod.id); }}>
                      Mark Outdated
                    </Button>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {completedInPath === pathModules.length && (
        <Card className="border-primary/30 bg-gradient-to-r from-primary/10 to-purple-500/10">
          <CardContent className="p-6 text-center">
            <Trophy className="w-12 h-12 text-primary mx-auto mb-3" />
            <h2 className="text-xl font-bold">Path Complete!</h2>
            <p className="text-muted-foreground mt-1">You've earned the <strong>{path.certName}</strong> certificate.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}