import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Loader2, CheckCircle2, XCircle, Mail, Lock, Eye, EyeOff,
  Inbox, Send, Shield, X, ChevronDown, ChevronUp, Zap, Star, ArrowRight, ArrowLeft, Sparkles, AlertTriangle
} from 'lucide-react';
import GmailOAuthConnect from './GmailOAuthConnect';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { base44 } from '@/api/base44Client';
import { EMAIL_PROVIDERS } from './emailProviders';
import { mapSmtpError } from '@/lib/smtpErrorMapper';
import { toast } from 'sonner';

// Domain-to-provider map for known SMTP providers (Yahoo, iCloud, AOL, etc.)
// When the user enters an email with one of these domains, we auto-select the
// correct provider preset instead of running DNS auto-discover.
const KNOWN_DOMAIN_MAP = {
  'yahoo.com': 'yahoo',
  'yahoo.co.uk': 'yahoo',
  'yahoo.ca': 'yahoo',
  'yahoo.fr': 'yahoo',
  'yahoo.de': 'yahoo',
  'icloud.com': 'icloud',
  'me.com': 'icloud',
  'mac.com': 'icloud',
  'aol.com': 'aol',
  'zoho.com': 'zoho',
  'protonmail.com': 'protonmail',
  'proton.me': 'protonmail',
  'fastmail.com': 'fastmail',
  'gmx.com': 'gmx',
  'gmx.us': 'gmx',
  'mail.com': 'mail_com',
  'yandex.com': 'yandex',
  'yandex.ru': 'yandex',
  'secureserver.net': 'godaddy',
  'privateemail.com': 'namecheap',
  'emailsrvr.com': 'rackspace',
  'mxroute.com': 'mxroute',
  'awsapps.com': 'amazon_workmail',
};

function detectKnownProvider(email) {
  if (!email) return null;
  const domain = email.split('@')[1]?.toLowerCase().trim();
  if (!domain) return null;
  return KNOWN_DOMAIN_MAP[domain] || null;
}

const STEPS = [
  { num: 1, label: 'Choose Provider' },
  { num: 2, label: 'Enter Credentials' },
  { num: 3, label: 'Verify' },
];

// --- Progress indicator ---
function StepIndicator({ current }) {
  return (
    <div className="flex items-center justify-center gap-1 sm:gap-2 mb-6">
      {STEPS.map((s, i) => (
        <React.Fragment key={s.num}>
          <div className="flex items-center gap-2">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold border-2 transition-all ${
              current > s.num
                ? 'bg-primary border-primary text-primary-foreground'
                : current === s.num
                  ? 'border-primary text-primary'
                  : 'border-border text-muted-foreground'
            }`}>
              {current > s.num
                ? <CheckCircle2 className="w-4 h-4" />
                : s.num}
            </div>
            <span className={`text-[10px] sm:text-xs font-medium hidden sm:inline ${
              current >= s.num ? 'text-foreground' : 'text-muted-foreground'
            }`}>
              {s.label}
            </span>
          </div>
          {i < STEPS.length - 1 && (
            <div className={`h-px w-4 sm:w-12 transition-all ${
              current > s.num ? 'bg-primary' : 'bg-border'
            }`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

// --- Provider selection card ---
function ProviderCard({ icon, name, tagline, selected, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`relative w-full text-left p-4 sm:p-5 rounded-xl border-2 transition-all group ${
        selected
          ? 'border-primary bg-primary/5'
          : 'border-border bg-card hover:border-primary/30 hover:bg-accent/30'
      }`}
    >
      <div className="flex items-start gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
          selected ? 'bg-primary/15 text-primary' : 'bg-muted text-muted-foreground group-hover:text-foreground'
        }`}>
          {icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold">{name}</p>
          <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{tagline}</p>
        </div>
        {selected && (
          <div className="absolute top-3 right-3">
            <CheckCircle2 className="w-4 h-4 text-primary" />
          </div>
        )}
      </div>
    </button>
  );
}

export default function EmailSetupWizard({ onDone }) {
  const { saveAccount, isSaving } = useEmailAccounts();

  const [step, setStep] = useState(1);
  const [providerChoice, setProviderChoice] = useState(null); // 'gmail' | 'outlook' | 'custom'
  // smtpProvider is the actual EMAIL_PROVIDERS key used for SMTP settings.
  // For 'outlook' choice it's always 'outlook'. For 'custom' it starts as 'custom'
  // and changes to a known key (e.g. 'yahoo') when a known domain is detected.
  const [smtpProvider, setSmtpProvider] = useState('custom');
  const [showPassword, setShowPassword] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [autoDiscovering, setAutoDiscovering] = useState(false);
  const [discovered, setDiscovered] = useState(false);
  const [discoveryNote, setDiscoveryNote] = useState('');
  const detectTimeoutRef = useRef(null);

  const [form, setForm] = useState({
    email_address: '',
    email_password: '',
    display_name: '',
    label: '',
    protocol: 'imap',
    incoming_host: '',
    incoming_port: 993,
    incoming_ssl: true,
    outgoing_host: '',
    outgoing_port: 587,
    outgoing_ssl: true,
  });

  // Step 3 verification state
  const [testState, setTestState] = useState(null); // null | 'testing' | 'success' | 'failed'
  const [testMessage, setTestMessage] = useState('');
  const [testFix, setTestFix] = useState('');
  const [setAsDefault, setSetAsDefault] = useState(true);

  // Resolve the current preset from EMAIL_PROVIDERS
  const preset = smtpProvider ? EMAIL_PROVIDERS[smtpProvider] : null;

  // Apply an EMAIL_PROVIDERS preset to the form
  const applyPreset = (providerKey) => {
    const p = EMAIL_PROVIDERS[providerKey];
    if (!p) return;
    setForm(f => ({
      ...f,
      incoming_host: f.protocol === 'pop3' ? p.pop3.host : p.imap.host,
      incoming_port: f.protocol === 'pop3' ? p.pop3.port : p.imap.port,
      incoming_ssl: f.protocol === 'pop3' ? p.pop3.ssl : p.imap.ssl,
      outgoing_host: p.smtp.host,
      outgoing_port: p.smtp.port,
      outgoing_ssl: p.smtp.ssl,
    }));
  };

  const handleProviderSelect = (choice) => {
    setProviderChoice(choice);
    setDiscovered(false);
    setDiscoveryNote('');
    if (choice === 'outlook') {
      setSmtpProvider('outlook');
      applyPreset('outlook');
    } else if (choice === 'custom') {
      setSmtpProvider('custom');
      setForm(f => ({ ...f, incoming_host: '', incoming_port: 993, outgoing_host: '', outgoing_port: 587 }));
      setShowAdvanced(false);
    }
  };

  // Auto-discover mail settings for custom domains via backend DNS/MX lookup
  const autoDiscoverSettings = async (email) => {
    setAutoDiscovering(true);
    setDiscoveryNote('');
    try {
      const res = await base44.functions.invoke('autoDiscoverMailSettings', { email_address: email });
      const data = res?.data || {};

      // Forwarding-only domain warning (Cloudflare, etc.)
      if (data.warning) {
        setDiscoveryNote(data.warning);
        toast.warning(data.warning, { duration: 8000 });
        setShowAdvanced(true);
        setDiscovered(false);
        setAutoDiscovering(false);
        return;
      }

      // autoDiscover may return a known provider key without auto_settings
      // (e.g. it detects yahoo.com from MX records). In that case, look up
      // the preset from EMAIL_PROVIDERS and apply it.
      if (data.success && data.provider && data.provider !== 'custom' && !data.auto_settings) {
        const providerKey = data.provider;
        if (EMAIL_PROVIDERS[providerKey]) {
          setSmtpProvider(providerKey);
          applyPreset(providerKey);
          setDiscovered(true);
          setDiscoveryNote(`Detected: ${EMAIL_PROVIDERS[providerKey].label}`);
          setAutoDiscovering(false);
          return;
        }
      }

      // autoDiscover returned full auto_settings (custom domain with DNS records)
      if (data.success && data.auto_settings) {
        const s = data.auto_settings;
        setSmtpProvider('custom');
        setForm(f => ({
          ...f,
          protocol: s.protocol,
          incoming_host: s.incoming_host,
          incoming_port: s.incoming_port,
          incoming_ssl: s.incoming_ssl,
          outgoing_host: s.outgoing_host,
          outgoing_port: s.outgoing_port,
          outgoing_ssl: s.outgoing_ssl,
        }));
        setDiscovered(true);
        setDiscoveryNote(`Found: ${s.incoming_host || s.outgoing_host}`);
        setShowAdvanced(false);
        setAutoDiscovering(false);
        return;
      }

      // Could not auto-discover — open Advanced so user can fill manually
      setShowAdvanced(true);
      setDiscovered(false);
      setDiscoveryNote(data.message || 'Could not auto-detect — enter server details manually.');
    } catch {
      setShowAdvanced(true);
      setDiscovered(false);
      setDiscoveryNote('Auto-detect failed — enter server details manually.');
    } finally {
      setAutoDiscovering(false);
    }
  };

  const handleEmailChange = (email) => {
    setForm(f => ({ ...f, email_address: email }));
    setDiscovered(false);
    setDiscoveryNote('');

    if (providerChoice === 'custom') {
      // First check if the domain matches a known provider (Yahoo, iCloud, etc.)
      const knownProvider = detectKnownProvider(email);
      if (knownProvider) {
        setSmtpProvider(knownProvider);
        applyPreset(knownProvider);
        setDiscovered(true);
        setDiscoveryNote(`Detected: ${EMAIL_PROVIDERS[knownProvider]?.label}`);
        return;
      }

      // Unknown domain — run DNS/MX auto-discover after debounce
      setSmtpProvider('custom');
      if (detectTimeoutRef.current) clearTimeout(detectTimeoutRef.current);
      if (email.includes('@') && email.split('@')[1]?.includes('.')) {
        detectTimeoutRef.current = setTimeout(() => autoDiscoverSettings(email), 800);
      }
    }
  };

  const canProceedStep2 = () => {
    if (providerChoice === 'gmail') return true; // Gmail handles its own flow
    if (!form.email_address?.trim() || !form.email_password?.trim()) return false;
    if (!form.outgoing_host?.trim()) return false;
    return true;
  };

  // Step 3: run SMTP connection test
  const runTest = async () => {
    setTestState('testing');
    setTestMessage('');
    setTestFix('');
    try {
      const res = await base44.functions.invoke('testSmtpConnection', {
        host: form.outgoing_host.trim(),
        port: Number(form.outgoing_port) || 0,
        ssl: form.outgoing_ssl,
        email_address: form.email_address.trim(),
        password: form.email_password.trim(),
      });
      const data = res?.data || {};
      if (data.success) {
        setTestState('success');
        setTestMessage(data.message || 'Connection successful');
      } else {
        const { message, fix } = mapSmtpError(data.error || data.message || 'Connection failed');
        setTestState('failed');
        setTestMessage(message);
        setTestFix(fix);
      }
    } catch (e) {
      const rawMsg = e?.response?.data?.error || e?.data?.error || e.message;
      const { message, fix } = mapSmtpError(rawMsg);
      setTestState('failed');
      setTestMessage(message);
      setTestFix(fix);
    }
  };

  // Auto-run test when entering Step 3
  const goToStep3 = () => {
    setStep(3);
    setTimeout(() => runTest(), 300);
  };

  // Save the account after successful verification
  const handleFinish = async () => {
    await doSave(false);
  };

  // Skip test & save anyway (for cases where SMTP test is blocked but email works)
  const handleSkipAndSave = async () => {
    await doSave(true);
  };

  const doSave = async (skipVerification) => {
    try {
      const data = {
        label: form.label?.trim() || '',
        provider: smtpProvider || 'custom',
        email_address: form.email_address.trim(),
        display_name: form.display_name?.trim() || '',
        protocol: form.protocol,
        incoming_host: form.incoming_host.trim(),
        incoming_port: Number(form.incoming_port) || 0,
        incoming_ssl: form.incoming_ssl,
        outgoing_host: form.outgoing_host.trim(),
        outgoing_port: Number(form.outgoing_port) || 0,
        outgoing_ssl: form.outgoing_ssl,
        email_password: form.email_password.trim(),
        is_default: setAsDefault,
        is_unverified: skipVerification,
      };
      await saveAccount({ data });
      if (skipVerification) {
        toast.success('Email account saved (unverified)');
      } else {
        toast.success('Email account connected');
      }
      onDone?.();
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
  };

  // Gmail OAuth path — delegate to existing component
  if (step === 2 && providerChoice === 'gmail') {
    return (
      <div>
        <StepIndicator current={2} />
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">Connect Gmail</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Secure one-click Google OAuth — no password needed.</p>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onDone}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <Button variant="ghost" size="sm" className="gap-1.5 mb-4 text-muted-foreground" onClick={() => setStep(1)}>
          <ArrowLeft className="w-3.5 h-3.5" /> Back to providers
        </Button>
        <GmailOAuthConnect onSaved={onDone} onCancel={() => setStep(1)} />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-semibold">Add Email Account</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Set up your email in 3 simple steps.</p>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onDone}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <StepIndicator current={step} />

      {/* --- STEP 1: Choose Provider --- */}
      {step === 1 && (
        <div className="space-y-3">
          <p className="text-xs font-medium text-muted-foreground text-center mb-4">How would you like to connect?</p>
          <div className="grid grid-cols-1 gap-3">
            <ProviderCard
              icon={<Mail className="w-5 h-5" />}
              name="Gmail / Google Workspace"
              tagline="One-click secure OAuth — no password or app password needed."
              selected={providerChoice === 'gmail'}
              onClick={() => handleProviderSelect('gmail')}
            />
            <ProviderCard
              icon={<Inbox className="w-5 h-5" />}
              name="Outlook / Microsoft 365"
              tagline="Standard IMAP/SMTP with an App Password — works with any Microsoft account."
              selected={providerChoice === 'outlook'}
              onClick={() => handleProviderSelect('outlook')}
            />
            <ProviderCard
              icon={<Sparkles className="w-5 h-5" />}
              name="Custom / Other Provider"
              tagline="Yahoo, iCloud, GoDaddy, or any domain — we auto-detect your mail servers."
              selected={providerChoice === 'custom'}
              onClick={() => handleProviderSelect('custom')}
            />
          </div>
          <div className="flex justify-end pt-2">
            <Button
              className="gap-1.5"
              disabled={!providerChoice}
              onClick={() => setStep(2)}
            >
              Next <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* --- STEP 2: Enter Credentials --- */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground -ml-2" onClick={() => setStep(1)}>
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </Button>
            <div className="flex-1" />
            <span className="text-xs font-medium text-muted-foreground">{preset?.label}</span>
          </div>

          {/* Email Address — first for auto-detect on custom */}
          <div>
            <Label className="text-xs mb-1.5 block">Email Address *</Label>
            <div className="relative">
              <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                type="email"
                placeholder="you@example.com"
                value={form.email_address}
                onChange={e => handleEmailChange(e.target.value)}
                className="h-9 text-sm pl-8"
                autoComplete="email"
              />
            </div>
            {autoDiscovering && (
              <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Looking up mail settings...
              </p>
            )}
            {!autoDiscovering && discovered && discoveryNote && (
              <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> {discoveryNote}
              </p>
            )}
            {!autoDiscovering && !discovered && discoveryNote && providerChoice === 'custom' && (
              <p className="text-[10px] text-amber-400 mt-1 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {discoveryNote}
              </p>
            )}
          </div>

          {/* Provider help note */}
          {preset?.note && (
            <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/20 rounded-lg p-3">
              <Shield className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground space-y-1">
                <p>{preset.note}</p>
                {preset.helpUrl && (
                  <a href={preset.helpUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline inline-flex items-center gap-1">
                    View setup guide <ArrowRight className="w-2.5 h-2.5" />
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Password */}
          <div>
            <Label className="text-xs mb-1.5 block">Password / App Password *</Label>
            <div className="relative">
              <Input
                type={showPassword ? 'text' : 'password'}
                placeholder="••••••••"
                value={form.email_password}
                onChange={e => setForm(f => ({ ...f, email_password: e.target.value }))}
                className="h-9 text-sm pr-9"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Display Name + Label */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs mb-1.5 block">Display Name (From)</Label>
              <Input
                placeholder="John Smith"
                value={form.display_name}
                onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Label (optional)</Label>
              <Input
                placeholder="Work, Personal, etc."
                value={form.label}
                onChange={e => setForm(f => ({ ...f, label: e.target.value }))}
                className="h-9 text-sm"
              />
            </div>
          </div>

          {/* Advanced Settings — collapsible */}
          <div className="border border-border rounded-xl overflow-hidden">
            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="w-full flex items-center justify-between px-3 py-2.5 bg-card hover:bg-accent/50 transition-colors"
            >
              <span className="text-xs font-semibold flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                Advanced Settings (Server Details)
              </span>
              {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            {showAdvanced && (
              <div className="p-3 space-y-3">
                {providerChoice !== 'custom' && (
                  <p className="text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2">
                    These are auto-filled for {preset?.label}. Only change if you know your provider uses different servers.
                  </p>
                )}

                {/* Protocol selector */}
                <div>
                  <Label className="text-[10px] mb-1.5 block">Protocol</Label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        const p = preset;
                        const incoming = p?.imap;
                        setForm(f => ({ ...f, protocol: 'imap', incoming_host: incoming?.host || f.incoming_host, incoming_port: incoming?.port || f.incoming_port, incoming_ssl: incoming?.ssl ?? f.incoming_ssl }));
                      }}
                      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${form.protocol === 'imap' ? 'bg-primary/10 border-primary text-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground'}`}
                    >
                      <Inbox className="w-3 h-3" /> IMAP
                    </button>
                    <button
                      onClick={() => {
                        const p = preset;
                        const incoming = p?.pop3;
                        setForm(f => ({ ...f, protocol: 'pop3', incoming_host: incoming?.host || f.incoming_host, incoming_port: incoming?.port || f.incoming_port, incoming_ssl: incoming?.ssl ?? f.incoming_ssl }));
                      }}
                      className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${form.protocol === 'pop3' ? 'bg-primary/10 border-primary text-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground'}`}
                    >
                      <Inbox className="w-3 h-3" /> POP3
                    </button>
                  </div>
                </div>

                {/* Incoming Server */}
                <div className="bg-card border border-border rounded-lg p-2.5 space-y-2">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
                    <Inbox className="w-3 h-3" /> Incoming Mail Server ({form.protocol.toUpperCase()})
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <Label className="text-[10px] mb-1 block">Host</Label>
                      <Input
                        placeholder="imap.example.com"
                        value={form.incoming_host}
                        onChange={e => setForm(f => ({ ...f, incoming_host: e.target.value }))}
                        className="h-7 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <Label className="text-[10px] mb-1 block">Port</Label>
                      <Input
                        type="number"
                        placeholder="993"
                        value={form.incoming_port}
                        onChange={e => setForm(f => ({ ...f, incoming_port: e.target.value }))}
                        className="h-7 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                      <button
                        onClick={() => setForm(f => ({ ...f, incoming_ssl: !f.incoming_ssl }))}
                        className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${form.incoming_ssl ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-muted border-border text-muted-foreground'}`}
                      >
                        <Shield className="w-3 h-3" />
                        {form.incoming_ssl ? 'On' : 'Off'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Outgoing Server */}
                <div className="bg-card border border-border rounded-lg p-2.5 space-y-2">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
                    <Send className="w-3 h-3" /> Outgoing Mail Server (SMTP)
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <div>
                      <Label className="text-[10px] mb-1 block">Host</Label>
                      <Input
                        placeholder="smtp.example.com"
                        value={form.outgoing_host}
                        onChange={e => setForm(f => ({ ...f, outgoing_host: e.target.value }))}
                        className="h-7 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <Label className="text-[10px] mb-1 block">Port</Label>
                      <Input
                        type="number"
                        placeholder="587"
                        value={form.outgoing_port}
                        onChange={e => setForm(f => ({ ...f, outgoing_port: e.target.value }))}
                        className="h-7 text-xs font-mono"
                      />
                    </div>
                    <div>
                      <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                      <button
                        onClick={() => setForm(f => ({ ...f, outgoing_ssl: !f.outgoing_ssl }))}
                        className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${form.outgoing_ssl ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'bg-muted border-border text-muted-foreground'}`}
                      >
                        <Shield className="w-3 h-3" />
                        {form.outgoing_ssl ? 'On' : 'Off'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-1">
            <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground" onClick={() => setStep(1)}>
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </Button>
            <Button className="gap-1.5" disabled={!canProceedStep2()} onClick={goToStep3}>
              Verify Connection <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      )}

      {/* --- STEP 3: Verify & Finish --- */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Button variant="ghost" size="sm" className="gap-1.5 text-muted-foreground -ml-2" onClick={() => setStep(2)} disabled={testState === 'testing'}>
              <ArrowLeft className="w-3.5 h-3.5" /> Back
            </Button>
          </div>

          {/* Verification status */}
          <div className="flex flex-col items-center justify-center py-6 text-center">
            {testState === 'testing' && (
              <>
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mb-3">
                  <Loader2 className="w-7 h-7 text-primary animate-spin" />
                </div>
                <p className="text-sm font-semibold">Verifying connection...</p>
                <p className="text-xs text-muted-foreground mt-1">Testing SMTP settings for {form.email_address}</p>
              </>
            )}

            {testState === 'success' && (
              <>
                <div className="w-14 h-14 rounded-full bg-emerald-500/15 flex items-center justify-center mb-3">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                </div>
                <p className="text-sm font-semibold text-emerald-400">Connection verified!</p>
                <p className="text-xs text-muted-foreground mt-1 max-w-sm">{testMessage}</p>
              </>
            )}

            {testState === 'failed' && (
              <>
                <div className="w-14 h-14 rounded-full bg-destructive/15 flex items-center justify-center mb-3">
                  <XCircle className="w-8 h-8 text-destructive" />
                </div>
                <p className="text-sm font-semibold text-destructive">Connection failed</p>
                {/* Red error card with exact error text + bolded fix suggestion */}
                <div className="mt-2 max-w-sm w-full bg-destructive/10 border border-destructive/30 rounded-lg p-3 text-left space-y-2">
                  <p className="text-xs text-destructive break-words">{testMessage}</p>
                  {testFix && (
                    <p className="text-xs text-destructive font-semibold border-t border-destructive/20 pt-2">
                      {testFix}
                    </p>
                  )}
                </div>
                <div className="flex items-center gap-2 mt-3">
                  <Button variant="outline" size="sm" className="gap-1.5" onClick={runTest} disabled={testState === 'testing'}>
                    <Zap className="w-3.5 h-3.5" /> Retry Test
                  </Button>
                  <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => setStep(2)}>
                    <ArrowLeft className="w-3.5 h-3.5" /> Edit Settings
                  </Button>
                </div>
                {/* Yellow Skip Test & Save Anyway button */}
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-1.5 mt-3 border-amber-500/40 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20 hover:text-amber-300"
                  onClick={handleSkipAndSave}
                  disabled={isSaving}
                >
                  {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <AlertTriangle className="w-3.5 h-3.5" />}
                  Skip Test &amp; Save Anyway
                </Button>
                <p className="text-[10px] text-muted-foreground mt-1 max-w-xs">
                  Use this if your firewall blocks SMTP testing but email still works. The account will be marked as unverified.
                </p>
              </>
            )}
          </div>

          {/* Success summary card */}
          {testState === 'success' && (
            <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
              <div className="rounded-xl border border-border bg-card p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Mail className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{form.email_address}</p>
                    <p className="text-xs text-muted-foreground">{preset?.label} • {(form.protocol || 'imap').toUpperCase()}</p>
                  </div>
                </div>

                {form.display_name && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Display Name</span>
                    <span className="font-medium">{form.display_name}</span>
                  </div>
                )}
                {form.label && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Label</span>
                    <span className="font-medium">{form.label}</span>
                  </div>
                )}

                {/* Set as Default toggle */}
                <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-border">
                  <div className="flex items-center gap-2">
                    <Star className={`w-3.5 h-3.5 ${setAsDefault ? 'text-primary fill-primary' : 'text-muted-foreground'}`} />
                    <span className="text-xs font-medium">Set as default send-from account</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setSetAsDefault(!setAsDefault)}
                    className={`relative w-9 h-5 rounded-full transition-colors ${setAsDefault ? 'bg-primary' : 'bg-muted'}`}
                  >
                    <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${setAsDefault ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </button>
                </label>
              </div>

              <Button className="w-full gap-1.5 h-11" onClick={handleFinish} disabled={isSaving}>
                {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                Finish &amp; Save
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}