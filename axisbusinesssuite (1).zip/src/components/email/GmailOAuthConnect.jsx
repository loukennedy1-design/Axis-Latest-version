import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Loader2, Mail, X, Shield, Zap } from 'lucide-react';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { toast } from 'sonner';

// Simplified Gmail connection — NO per-user OAuth popup required.
// Outgoing mail is routed through the platform's verified shared Gmail connector
// (already authorized at the Base44 platform level). This eliminates the
// "Google hasn't verified this app" warning entirely.
//
// Reply-To is always set to the user's own Gmail address so replies land in
// their inbox — they just send through the shared platform Gmail.
export default function GmailOAuthConnect({ account, onSaved, onCancel }) {
  const { saveAccount, isSaving } = useEmailAccounts();
  const isEdit = !!account;

  const [form, setForm] = useState({
    email_address: account?.email_address || '',
    display_name: account?.display_name || '',
  });

  const handleSave = async () => {
    if (!form.email_address?.trim()) {
      toast.error('Your Gmail address is required');
      return;
    }
    const domain = form.email_address.split('@')[1]?.toLowerCase().trim();
    if (domain && domain !== 'gmail.com' && domain !== 'googlemail.com') {
      toast.error('Please enter a @gmail.com address, or use the manual SMTP tab for other providers');
      return;
    }
    try {
      await saveAccount({
        id: account?.id,
        data: {
          provider: 'gmail_oauth',
          email_address: form.email_address.trim(),
          display_name: form.display_name?.trim() || '',
          label: 'Gmail',
          // No password / host settings needed — sent via platform's verified Gmail connector
        },
      });
      toast.success(isEdit ? 'Gmail account updated' : 'Gmail connected — ready to send');
      onSaved?.();
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Gmail Connection</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Send email through AXIS's verified Gmail — no password needed</p>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex items-start gap-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3">
        <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground">
          <strong className="text-foreground">No OAuth popup, no App Password, no setup.</strong> AXIS sends through its own verified Gmail connection. Replies go straight to your inbox via Reply-To.
        </p>
      </div>

      {account?.email_address && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <p className="text-xs text-emerald-400">Currently connected: {account.email_address}</p>
        </div>
      )}

      <div className="space-y-3">
        <div>
          <Label className="text-xs mb-1.5 block">Your Gmail Address *</Label>
          <div className="relative">
            <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              type="email"
              placeholder="you@gmail.com"
              value={form.email_address}
              onChange={e => setForm(f => ({ ...f, email_address: e.target.value }))}
              className="h-9 text-sm pl-8"
              autoComplete="email"
            />
          </div>
        </div>
        <div>
          <Label className="text-xs mb-1.5 block">Display Name (From)</Label>
          <Input
            placeholder="John Smith"
            value={form.display_name}
            onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
            className="h-9 text-sm"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 pt-1">
        <Button size="sm" className="gap-1.5 h-9 flex-1" onClick={handleSave} disabled={isSaving}>
          {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
          {isEdit ? 'Update' : 'Connect Gmail'}
        </Button>
        <Button variant="ghost" size="sm" className="h-9" onClick={onCancel}>Cancel</Button>
        <p className="text-[10px] text-muted-foreground flex items-center gap-1 ml-auto">
          <Shield className="w-2.5 h-2.5" /> No password stored
        </p>
      </div>
    </div>
  );
}