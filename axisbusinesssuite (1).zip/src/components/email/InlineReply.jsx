import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Send, Reply, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { format } from 'date-fns';

// Inline quick-reply composer pinned to the bottom of an open thread.
// Collapses to a single "Reply to …" bar; expands on click into a textarea
// pre-filled with a quoted copy of the last message, then sends straight into
// the same thread via sendTransactionalEmail.
export default function InlineReply({ threadId, to, subject, latestMessage, onSent }) {
  const [expanded, setExpanded] = useState(false);
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const textareaRef = useRef(null);

  const quote = latestMessage
    ? `\n\nOn ${latestMessage.created_date ? format(new Date(latestMessage.created_date), 'MMM d, yyyy h:mm a') : ''}, ${latestMessage.direction === 'sent' ? latestMessage.to_address : latestMessage.from_address} wrote:\n` +
      (latestMessage.body || '').split('\n').map((l) => `> ${l}`).join('\n')
    : '';

  const expand = () => {
    if (!expanded) {
      setBody(quote);
      setExpanded(true);
      setTimeout(() => textareaRef.current?.focus(), 50);
    }
  };

  const cancel = () => { setExpanded(false); setBody(''); };

  const send = async () => {
    if (!to || !body.trim()) { toast.error('Add a message to send'); return; }
    setSending(true);
    try {
      const res = await base44.functions.invoke('sendTransactionalEmail', {
        to,
        subject: subject?.startsWith('Re:') ? subject : `Re: ${subject}`,
        body,
        thread_id: threadId,
      });
      if (res?.data?.error || res?.data?.smtp_error || (res?.status && res.status >= 400)) {
        const detail = res?.data?.error || res?.data?.message || 'Reply failed';
        toast.error('Failed to send: ' + detail, {
          duration: 8000,
          action: { label: 'Fix in Settings →', onClick: () => window.location.href = '/settings' },
        });
        setSending(false);
        return;
      }
      toast.success('Reply sent');
      setBody('');
      setExpanded(false);
      onSent?.();
    } catch (e) {
      toast.error('Failed to send: ' + (e?.message || 'Unknown error'));
    } finally {
      setSending(false);
    }
  };

  if (!expanded) {
    return (
      <div className="border-t p-3 shrink-0 bg-background">
        <button
          onClick={expand}
          className="w-full flex items-center gap-2 px-3 py-2.5 rounded-lg border bg-card text-sm text-muted-foreground hover:bg-muted/50 hover:border-primary/30 transition-colors text-left"
        >
          <Reply className="w-4 h-4 shrink-0" />
          <span className="truncate">Reply to {to || '…'}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="border-t bg-card shrink-0">
      <div className="p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground truncate">
            To: <span className="text-foreground font-medium">{to}</span>
          </span>
          <button onClick={cancel} className="text-muted-foreground hover:text-foreground shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>
        <Textarea
          ref={textareaRef}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          rows={6}
          placeholder="Write your reply…"
          className="text-sm resize-none"
        />
        <div className="flex justify-end">
          <Button size="sm" onClick={send} disabled={sending} className="gap-2">
            {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Send Reply
          </Button>
        </div>
      </div>
    </div>
  );
}