import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * Opens the user's webmail in a new browser tab and returns the user to the
 * email client. Navigating the app itself to a cross-origin URL doesn't load
 * inside the app frame (it just flickers and loses your place), so we pop a
 * new tab and keep you in AXIS.
 */
export default function WebmailRedirect() {
  const navigate = useNavigate();
  useEffect(() => {
    window.open('https://axisbusinesssuite.com/webmail', '_blank', 'noopener,noreferrer');
    navigate('/email', { replace: true });
  }, [navigate]);
  return (
    <div className="flex items-center justify-center h-screen bg-background text-foreground">
      <div className="text-center space-y-3">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-sm text-muted-foreground">Opening webmail in a new tab…</p>
      </div>
    </div>
  );
}