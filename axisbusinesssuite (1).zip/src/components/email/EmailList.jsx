import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Mail, Send, Inbox } from 'lucide-react';
import { format, isToday, isYesterday } from 'date-fns';
import { cn } from '@/lib/utils';

function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  if (isToday(d)) return format(d, 'h:mm a');
  if (isYesterday(d)) return 'Yesterday';
  return format(d, 'MMM d');
}

export default function EmailList({ threads, selectedThreadId, onSelect, folder }) {
  if (threads.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground gap-2">
        <Inbox className="w-8 h-8 opacity-40" />
        <p className="text-sm">No emails in {folder}</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-border">
      {threads.map((thread) => {
        const latest = thread.messages[thread.messages.length - 1];
        const hasUnread = thread.messages.some(m => m.status === 'unread');
        const isSentOnly = thread.messages.every(m => m.direction === 'sent');
        const isSelected = thread.thread_id === selectedThreadId;

        return (
          <button
            key={thread.thread_id}
            onClick={() => onSelect(thread)}
            className={cn(
              'w-full text-left px-4 py-3 hover:bg-muted/50 transition-colors',
              isSelected && 'bg-primary/5 border-r-2 border-primary'
            )}
          >
            <div className="flex items-start justify-between gap-2 mb-0.5">
              <div className="flex items-center gap-1.5 min-w-0">
                {isSentOnly
                  ? <Send className="w-3 h-3 text-muted-foreground shrink-0" />
                  : <Mail className={cn('w-3 h-3 shrink-0', hasUnread ? 'text-primary' : 'text-muted-foreground')} />
                }
                <p className={cn('text-sm truncate', hasUnread ? 'font-bold' : 'font-medium')}>
                  {isSentOnly ? latest?.to_address : latest?.from_address || latest?.to_address}
                </p>
              </div>
              <span className="text-[10px] text-muted-foreground shrink-0">{formatDate(latest?.created_date)}</span>
            </div>
            <p className={cn('text-xs truncate', hasUnread ? 'text-foreground font-semibold' : 'text-muted-foreground')} style={{ paddingLeft: '1.25rem' }}>
              {latest?.subject}
            </p>
            <p className="text-[11px] text-muted-foreground truncate mt-0.5" style={{ paddingLeft: '1.25rem' }}>
              {latest?.body?.slice(0, 80)}
            </p>
            {thread.messages.length > 1 && (
              <Badge variant="outline" className="text-[9px] mt-1 ml-5">{thread.messages.length}</Badge>
            )}
          </button>
        );
      })}
    </div>
  );
}