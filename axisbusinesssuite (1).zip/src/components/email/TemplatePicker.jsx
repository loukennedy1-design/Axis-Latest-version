import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Loader2, Search, FileText, ChevronRight } from 'lucide-react';

const CATEGORY_LABELS = {
  follow_up: 'Follow-Up',
  appointment: 'Appointment',
  introduction: 'Introduction',
  thank_you: 'Thank You',
  reminder: 'Reminder',
  re_engagement: 'Re-Engagement',
  custom: 'Custom',
};

// Replace template variables with lead data
export function fillTemplate(text, leadData = {}) {
  if (!text) return '';
  return text
    .replace(/\{\{first_name\}\}/gi, leadData.first_name || '')
    .replace(/\{\{last_name\}\}/gi, leadData.last_name || '')
    .replace(/\{\{company\}\}/gi, leadData.company || '')
    .replace(/\{\{lead_name\}\}/gi, [leadData.first_name, leadData.last_name].filter(Boolean).join(' '))
    .replace(/\{\{lead_phone\}\}/gi, leadData.phone || '')
    .replace(/\{\{appointment_date\}\}/gi, leadData.appointment_date || '');
}

export default function TemplatePicker({ open, onClose, onSelect, leadData = {} }) {
  const [search, setSearch] = useState('');

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['emailTemplates'],
    queryFn: () => base44.entities.EmailTemplate.list('-updated_date', 200),
    enabled: open,
  });

  const filtered = templates.filter(t =>
    !search || t.name?.toLowerCase().includes(search.toLowerCase()) ||
    t.subject?.toLowerCase().includes(search.toLowerCase()) ||
    t.body?.toLowerCase().includes(search.toLowerCase())
  );

  const handleSelect = (template) => {
    onSelect({
      subject: fillTemplate(template.subject, leadData),
      body: fillTemplate(template.body, leadData),
      template_id: template.id,
    });
    // Increment usage count (fire and forget)
    base44.entities.EmailTemplate.update(template.id, { usage_count: (template.usage_count || 0) + 1 }).catch(() => {});
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" /> Choose a Template
          </DialogTitle>
        </DialogHeader>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="h-9 pl-8"
            autoFocus
          />
        </div>
        <div className="flex-1 overflow-y-auto space-y-1.5 -mx-1 px-1">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No templates found.</p>
              <p className="text-xs text-muted-foreground mt-1">Create templates in the Templates tab.</p>
            </div>
          ) : (
            filtered.map(t => (
              <button
                key={t.id}
                onClick={() => handleSelect(t)}
                className="w-full text-left bg-card border border-border rounded-lg p-3 hover:border-primary hover:bg-primary/5 transition-all group"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-medium text-sm truncate">{t.name}</span>
                      {t.category && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground">
                          {CATEGORY_LABELS[t.category] || t.category}
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-medium text-foreground/80 truncate">{t.subject || '(no subject)'}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                      {fillTemplate(t.body, leadData)}
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
                </div>
              </button>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}