import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Reply, Mail, Send } from 'lucide-react';
import { format } from 'date-fns';

export default function ThreadView({ messages, onBack, onReply }) {
  if (!messages || messages.length === 0) return null;

  const subject = messages[0]?.subject || '(no subject)';
  const sorted = [...messages].sort((a, b) => new Date(a.created_date) - new Date(b.created_date));

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div className="flex-1 min-w-0">
          <h2 className="font-semibold truncate">{subject}</h2>
          <p className="text-xs text-muted-foreground">{messages.length} message{messages.length !== 1 ? 's' : ''}</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={onReply}>
          <Reply className="w-3.5 h-3.5" />Reply
        </Button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {sorted.map((msg) => (
          <div key={msg.id} className={`rounded-xl border p-4 ${msg.direction === 'sent' ? 'ml-8 bg-primary/5 border-primary/20' : 'mr-8 bg-card'}`}>
            <div className="flex items-start justify-between mb-2 gap-2">
              <div className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${msg.direction === 'sent' ? 'bg-primary/10 text-primary' : 'bg-muted text-muted-foreground'}`}>
                  {msg.direction === 'sent' ? <Send className="w-3 h-3" /> : <Mail className="w-3 h-3" />}
                </div>
                <div>
                  <p className="text-sm font-semibold">{msg.direction === 'sent' ? `Me → ${msg.to_address}` : `From: ${msg.from_address}`}</p>
                  {msg.cc && <p className="text-[10px] text-muted-foreground">CC: {msg.cc}</p>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge variant="outline" className={`text-[10px] ${msg.direction === 'sent' ? 'text-primary border-primary/30' : 'text-muted-foreground'}`}>
                  {msg.direction}
                </Badge>
                <span className="text-[10px] text-muted-foreground">
                  {msg.created_date ? format(new Date(msg.created_date), 'MMM d, h:mm a') : ''}
                </span>
              </div>
            </div>
            <div className="text-sm whitespace-pre-wrap text-foreground/90 leading-relaxed pl-9">
              {msg.body}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}