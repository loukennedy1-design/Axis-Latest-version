import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Send, FileText, Mail } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import TemplatePicker from './TemplatePicker';
const uuidv4 = () => Math.random().toString(36).substring(2) + Date.now().toString(36);

export default function ComposeModal({ open, onClose, onSent, prefill = {}, user, accounts = [], defaultAccountId, systemEmail, systemEmailConfigured }) {
  const [form, setForm] = useState({
    to: prefill.to || '',
    cc: prefill.cc || '',
    subject: prefill.subject || '',
    body: prefill.body || '',
  });
  const [selectedFromId, setSelectedFromId] = useState(defaultAccountId || '');
  const [sending, setSending] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);

  // Reset form + selected sender when the modal opens
  useEffect(() => {
    if (open) {
      setForm({
        to: prefill.to || '',
        cc: prefill.cc || '',
        subject: prefill.subject || '',
        body: prefill.body || '',
      });
      setSelectedFromId(defaultAccountId || '');
    }
  }, [open, prefill, defaultAccountId]);

  const handleSend = async () => {
    if (!form.to || !form.subject || !form.body) {
      toast.error('To, Subject and Body are required');
      return;
    }
    setSending(true);
    try {
      const res = await base44.functions.invoke('sendTransactionalEmail', {
        to: form.to,
        subject: form.subject,
        body: form.body,
        cc: form.cc,
        thread_id: prefill.thread_id || uuidv4(),
        lead_id: prefill.lead_id || '',
        lead_name: prefill.lead_name || '',
        from_account_id: selectedFromId || undefined,
      });

      if (res?.data?.error || res?.data?.smtp_error || (res?.status && res.status >= 400)) {
        const detail = res?.data?.error || res?.data?.message || 'Email delivery failed';
        toast.error('Failed to send: ' + detail, {
          duration: 8000,
          action: {
            label: 'Fix in Settings →',
            onClick: () => window.location.href = '/settings',
          },
        });
        setSending(false);
        return;
      }

      if (res?.data?.warning) {
        toast.warning(res.data.warning);
      }
      toast.success(res?.data?.status === 'sent_via_fallback'
        ? 'Sent via system fallback (your SMTP failed — check Settings → Email)'
        : 'Email sent!');
      onSent?.();
      onClose();
    } catch (e) {
      const detail = e?.response?.data?.error || e?.data?.error || e.message;
      toast.error('Failed to send: ' + detail);
    }
    setSending(false);
  };

  const selectedAccount = accounts.find(a => a.id === selectedFromId);

  const handleTemplateSelect = ({ subject, body }) => {
    setForm(f => ({
      ...f,
      subject: subject || f.subject,
      body: body || f.body,
    }));
    toast.success('Template applied');
  };

  const leadData = {
    first_name: prefill.lead_name?.split(' ')[0] || '',
    last_name: prefill.lead_name?.split(' ').slice(1).join(' ') || '',
    lead_name: prefill.lead_name || '',
    phone: prefill.lead_phone || '',
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>New Email</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {accounts.length > 0 ? (
            <div>
              <Label>From</Label>
              <Select value={selectedFromId} onValueChange={setSelectedFromId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select sender account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map(acc => (
                    <SelectItem key={acc.id} value={acc.id}>
                      {acc.email_address}{acc.is_default ? ' (Default)' : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedAccount?.display_name && (
                <p className="text-xs text-muted-foreground mt-1">Sending as: {selectedAccount.display_name}</p>
              )}
            </div>
          ) : systemEmailConfigured && systemEmail?.email_address ? (
            <div>
              <Label>From</Label>
              <div className="flex items-center gap-2 px-3 py-2 rounded-md border bg-muted/30 text-sm">
                <Mail className="w-3.5 h-3.5 text-primary" />
                <span className="flex-1">{systemEmail.email_address}</span>
                <span className="text-xs text-muted-foreground">System Email</span>
              </div>
              {systemEmail.display_name && (
                <p className="text-xs text-muted-foreground mt-1">Sending as: {systemEmail.display_name}</p>
              )}
            </div>
          ) : null}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>To *</Label>
              <Input value={form.to} onChange={e => setForm({ ...form, to: e.target.value })} placeholder="recipient@example.com" />
            </div>
            <div>
              <Label>CC</Label>
              <Input value={form.cc} onChange={e => setForm({ ...form, cc: e.target.value })} placeholder="cc@example.com" />
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <Label>Subject *</Label>
              <Button
                variant="ghost"
                size="sm"
                className="h-6 gap-1 text-xs"
                onClick={() => setShowTemplates(true)}
              >
                <FileText className="w-3.5 h-3.5" /> Templates
              </Button>
            </div>
            <Input value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })} placeholder="Subject..." />
          </div>
          <div>
            <Label>Body *</Label>
            <Textarea
              value={form.body}
              onChange={e => setForm({ ...form, body: e.target.value })}
              rows={10}
              placeholder="Write your message..."
              className="font-mono text-sm"
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>Cancel</Button>
            <Button onClick={handleSend} disabled={sending} className="gap-2">
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              Send
            </Button>
          </div>
        </div>
        {showTemplates && (
          <TemplatePicker
            open={showTemplates}
            onClose={() => setShowTemplates(false)}
            onSelect={handleTemplateSelect}
            leadData={leadData}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}