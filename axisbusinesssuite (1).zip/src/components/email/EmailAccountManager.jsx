import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Plus, Mail, Star, Pencil, Trash2, Loader2, Zap, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import EmailAccountForm from './EmailAccountForm';
import SmartConnectModal from '@/components/smartconnect/SmartConnectModal';
import { EMAIL_PROVIDERS } from './emailProviders';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function EmailAccountManager() {
  const { accounts, isLoading, isError, error, deleteAccount, setDefault } = useEmailAccounts();
  const [formOpen, setFormOpen] = useState(false);
  const [smartConnectOpen, setSmartConnectOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState(null);
  // Track which account is currently being tested (by id)
  const [testingId, setTestingId] = useState(null);
  const location = useLocation();

  // Detect OAuth callback result query params (?oauth=success or ?oauth=error)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const oauthStatus = params.get('oauth');
    const message = params.get('message');

    if (oauthStatus === 'success') {
      toast.success('Gmail account connected successfully!', { duration: 5000 });
      // Clean up the URL so the toast doesn't re-fire on re-render
      const newUrl = window.location.pathname + window.location.hash;
      window.history.replaceState({}, document.title, newUrl);
    } else if (oauthStatus === 'error') {
      const detail = message ? decodeURIComponent(message) : 'Unknown error';
      toast.error(`Gmail connection failed: ${detail}`, {
        duration: 8000,
        action: {
          label: 'Try Again',
          onClick: () => setSmartConnectOpen(true),
        },
      });
      const newUrl = window.location.pathname + window.location.hash;
      window.history.replaceState({}, document.title, newUrl);
    }
  }, [location.search]);

  const handleAdd = () => {
    setEditingAccount(null);
    setSmartConnectOpen(true);
  };

  const handleEdit = (account) => {
    setEditingAccount(account);
    setFormOpen(true);
  };

  const handleDelete = async (account) => {
    if (!confirm(`Delete ${account.email_address}?`)) return;
    try {
      await deleteAccount(account.id);
      toast.success('Account deleted');
    } catch (e) {
      toast.error('Failed to delete: ' + e.message);
    }
  };

  const handleSetDefault = async (account) => {
    try {
      await setDefault(account.id);
      toast.success(`${account.email_address} set as default`);
    } catch (e) {
      toast.error('Failed to set default: ' + e.message);
    }
  };

  // Test connection for a saved account (without re-entering credentials)
  const handleTestConnection = async (account) => {
    setTestingId(account.id);
    try {
      const res = await base44.functions.invoke('manageEmailAccounts', { action: 'test', id: account.id });
      const data = res?.data || {};
      if (data.success) {
        toast.success(`${account.email_address}: ${data.message || 'Connection successful'}`, { duration: 5000 });
      } else {
        toast.error(`${account.email_address}: ${data.error || 'Connection failed'}`, { duration: 8000 });
      }
    } catch (e) {
      const detail = e?.response?.data?.error || e?.data?.error || e.message;
      toast.error(`Test failed: ${detail}`, { duration: 8000 });
    } finally {
      setTestingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <Card>
        <CardContent className="py-8 flex flex-col items-center gap-3 text-center">
          <ShieldAlert className="w-8 h-8 text-destructive opacity-60" />
          <div>
            <p className="text-sm font-medium">Couldn't load email accounts</p>
            <p className="text-xs text-muted-foreground mt-0.5 break-words max-w-md">{error?.message || 'Unknown error'}</p>
          </div>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.location.reload()}>
            <Loader2 className="w-3.5 h-3.5" /> Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Email Accounts</h3>
          <p className="text-xs text-muted-foreground">Manage your personal email accounts (IMAP/POP3/SMTP). Each account is private to you.</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={handleAdd}>
          <Plus className="w-3.5 h-3.5" /> Add Account
        </Button>
      </div>

      {accounts.length === 0 ? (
        <Card>
          <CardContent className="py-8 flex flex-col items-center gap-3 text-center">
            <Mail className="w-8 h-8 text-muted-foreground opacity-40" />
            <div>
              <p className="text-sm font-medium">No email accounts configured</p>
              <p className="text-xs text-muted-foreground mt-0.5">Add an email account to send and receive emails from AXIS</p>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" className="gap-1.5" onClick={handleAdd}>
                <Plus className="w-3.5 h-3.5" /> Add Your First Account
              </Button>
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.location.reload()}>
                <Loader2 className="w-3.5 h-3.5" /> Refresh
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {accounts.map(account => {
            const preset = EMAIL_PROVIDERS[account.provider];
            const isOAuth = account.provider === 'gmail_oauth' || account.provider === 'outlook_oauth';
            const isUnverified = account.is_unverified === true;
            return (
              <Card key={account.id} className={account.is_default ? 'border-primary/30 bg-primary/5' : ''}>
                <CardContent className="py-3 px-4 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    {isOAuth ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Mail className="w-4 h-4 text-primary" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-medium truncate">{account.email_address}</p>
                      {account.is_default && (
                        <Badge className="bg-primary/10 text-primary border border-primary/20 text-[10px] shrink-0">
                          <Star className="w-2.5 h-2.5 mr-0.5 fill-current" />Default
                        </Badge>
                      )}
                      {isUnverified && (
                        <Badge className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[10px] shrink-0">
                          <ShieldAlert className="w-2.5 h-2.5 mr-0.5" />Unverified
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {preset?.label || account.provider} • {(account.protocol || 'imap').toUpperCase()}
                      {account.label && ` • ${account.label}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {/* Test Connection button — lets users verify at any time without re-entering credentials */}
                    {!isOAuth && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 text-xs gap-1"
                        onClick={() => handleTestConnection(account)}
                        disabled={testingId === account.id}
                      >
                        {testingId === account.id ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Zap className="w-3 h-3" />
                        )}
                        Test
                      </Button>
                    )}
                    {!account.is_default && (
                      <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => handleSetDefault(account)}>
                        Set Default
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => handleEdit(account)}>
                      <Pencil className="w-3.5 h-3.5" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => handleDelete(account)}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={formOpen} onOpenChange={(open) => { if (!open) setFormOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {formOpen && (
            <EmailAccountForm
              account={editingAccount}
              onSaved={() => setFormOpen(false)}
              onCancel={() => setFormOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      <SmartConnectModal
        open={smartConnectOpen}
        onOpenChange={setSmartConnectOpen}
        mode="email"
        onConnected={() => {/* useEmailAccounts invalidates on save */}}
      />
    </div>
  );
}