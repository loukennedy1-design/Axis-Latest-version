import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Mail, Server, Lock, Eye, EyeOff, CheckCircle2, Loader2,
  Inbox, Send, Shield, ChevronDown, ChevronRight, Info, XCircle, Zap
} from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

// Preset IMAP/POP/SMTP settings for all major email providers
export const EMAIL_PROVIDERS = {
  gmail: {
    label: 'Gmail',
    imap: { host: 'imap.gmail.com', port: 993, ssl: true },
    pop3: { host: 'pop.gmail.com', port: 995, ssl: true },
    smtp: { host: 'smtp.gmail.com', port: 587, ssl: true },
    note: 'Requires an App Password (2FA must be enabled). Go to Google Account → Security → App Passwords.',
    helpUrl: 'https://support.google.com/accounts/answer/185833',
  },
  outlook: {
    label: 'Outlook / Hotmail (Microsoft 365)',
    imap: { host: 'outlook.office365.com', port: 993, ssl: true },
    pop3: { host: 'outlook.office365.com', port: 995, ssl: true },
    smtp: { host: 'smtp.office365.com', port: 587, ssl: true },
    note: 'Use your Microsoft 365 email and password. For POP3, enable it in Outlook settings.',
    helpUrl: 'https://support.microsoft.com/en-us/office/pop-imap-and-smtp-settings-8361e398-8af4-4e97-b147-6c6c4ac95313',
  },
  yahoo: {
    label: 'Yahoo Mail',
    imap: { host: 'imap.mail.yahoo.com', port: 993, ssl: true },
    pop3: { host: 'pop.mail.yahoo.com', port: 995, ssl: true },
    smtp: { host: 'smtp.mail.yahoo.com', port: 587, ssl: true },
    note: 'Requires an App Password. Go to Yahoo Account Security → App Passwords.',
    helpUrl: 'https://help.yahoo.com/kb/SLN15241.html',
  },
  icloud: {
    label: 'iCloud / Me.com / Mac.com',
    imap: { host: 'imap.mail.me.com', port: 993, ssl: true },
    pop3: { host: 'pop.mail.me.com', port: 995, ssl: true },
    smtp: { host: 'smtp.mail.me.com', port: 587, ssl: true },
    note: 'Requires an App-Specific Password. Generate at appleid.apple.com → Sign-In & Security → App-Specific Passwords.',
    helpUrl: 'https://support.apple.com/en-us/HT204397',
  },
  aol: {
    label: 'AOL Mail',
    imap: { host: 'imap.aol.com', port: 993, ssl: true },
    pop3: { host: 'pop.aol.com', port: 995, ssl: true },
    smtp: { host: 'smtp.aol.com', port: 587, ssl: true },
    note: 'Requires an App Password. Go to AOL Account Security → App Passwords.',
    helpUrl: 'https://help.aol.com/articles/Create-and-manage-app-passwords',
  },
  zoho: {
    label: 'Zoho Mail',
    imap: { host: 'imap.zoho.com', port: 993, ssl: true },
    pop3: { host: 'pop.zoho.com', port: 995, ssl: true },
    smtp: { host: 'smtp.zoho.com', port: 587, ssl: true },
    note: 'Use your Zoho Mail email and password. IMAP must be enabled in Zoho Mail Settings → IMAP/POP.',
    helpUrl: 'https://www.zoho.com/mail/help/imap-pop3-configuration.html',
  },
  protonmail: {
    label: 'Proton Mail (via Bridge)',
    imap: { host: '127.0.0.1', port: 1143, ssl: false },
    pop3: { host: '127.0.0.1', port: 1110, ssl: false },
    smtp: { host: '127.0.0.1', port: 1025, ssl: false },
    note: 'Requires Proton Mail Bridge desktop app running locally. Use the Bridge credentials shown in the app.',
    helpUrl: 'https://proton.me/mail/bridge',
  },
  fastmail: {
    label: 'Fastmail',
    imap: { host: 'imap.fastmail.com', port: 993, ssl: true },
    pop3: { host: 'pop.fastmail.com', port: 995, ssl: true },
    smtp: { host: 'smtp.fastmail.com', port: 587, ssl: true },
    note: 'Requires an App Password. Go to Fastmail Settings → Passwords & Security → App Passwords.',
    helpUrl: 'https://www.fastmail.help/hc/en-us/articles/1500000280261-IMAP-POP-and-SMTP',
  },
  godaddy: {
    label: 'GoDaddy Workspace',
    imap: { host: 'imap.secureserver.net', port: 993, ssl: true },
    pop3: { host: 'pop.secureserver.net', port: 995, ssl: true },
    smtp: { host: 'smtpout.secureserver.net', port: 587, ssl: true },
    note: 'Use your GoDaddy email address and password. SMTP port 465 (SSL) or 587 (TLS) also supported.',
    helpUrl: 'https://www.godaddy.com/help/set-up-my-email-on-an-app-or-phone-25427',
  },
  namecheap: {
    label: 'Namecheap Private Email',
    imap: { host: 'mail.privateemail.com', port: 993, ssl: true },
    pop3: { host: 'mail.privateemail.com', port: 995, ssl: true },
    smtp: { host: 'mail.privateemail.com', port: 465, ssl: true },
    note: 'Use your Private Email address and password.',
    helpUrl: 'https://www.namecheap.com/support/knowledgebase/article.aspx/10069/2241/email-setup-for-pop-or-imap/',
  },
  rackspace: {
    label: 'Rackspace Email',
    imap: { host: 'secure.emailsrvr.com', port: 993, ssl: true },
    pop3: { host: 'secure.emailsrvr.com', port: 995, ssl: true },
    smtp: { host: 'secure.emailsrvr.com', port: 465, ssl: true },
    note: 'Use your Rackspace email address and password.',
    helpUrl: 'https://docs.rackspace.com/support/how-to/email-setup-guides',
  },
  mxroute: {
    label: 'MXroute',
    imap: { host: 'mail.mxroute.com', port: 993, ssl: true },
    pop3: { host: 'mail.mxroute.com', port: 995, ssl: true },
    smtp: { host: 'mail.mxroute.com', port: 465, ssl: true },
    note: 'Use your MXroute email address and password.',
    helpUrl: 'https://mxroute.com/',
  },
  amazon_workmail: {
    label: 'Amazon WorkMail',
    imap: { host: 'imap.mail.us-east-1.awsapps.com', port: 993, ssl: true },
    pop3: { host: 'pop.mail.us-east-1.awsapps.com', port: 995, ssl: true },
    smtp: { host: 'smtp.mail.us-east-1.awsapps.com', port: 465, ssl: true },
    note: 'Region varies — replace us-east-1 with your AWS region. Use your WorkMail email and password.',
    helpUrl: 'https://docs.aws.amazon.com/workmail/latest/user/using_IMAP_clients.html',
  },
  gmx: {
    label: 'GMX Mail',
    imap: { host: 'imap.gmx.com', port: 993, ssl: true },
    pop3: { host: 'pop.gmx.com', port: 995, ssl: true },
    smtp: { host: 'mail.gmx.com', port: 587, ssl: true },
    note: 'Use your GMX email address and password.',
    helpUrl: 'https://www.gmx.com/mail/imap-pop3/',
  },
  mail_com: {
    label: 'Mail.com',
    imap: { host: 'imap.mail.com', port: 993, ssl: true },
    pop3: { host: 'pop.mail.com', port: 995, ssl: true },
    smtp: { host: 'smtp.mail.com', port: 587, ssl: true },
    note: 'Use your Mail.com email address and password.',
    helpUrl: 'https://www.mail.com/mail/imap-pop3/',
  },
  yandex: {
    label: 'Yandex Mail',
    imap: { host: 'imap.yandex.com', port: 993, ssl: true },
    pop3: { host: 'pop.yandex.com', port: 995, ssl: true },
    smtp: { host: 'smtp.yandex.com', port: 465, ssl: true },
    note: 'Requires an App Password. Go to Yandex → Account → Security → App passwords.',
    helpUrl: 'https://yandex.com/support/mail/mail-clients.html',
  },
  custom: {
    label: 'Custom / Other Provider',
    imap: { host: '', port: 993, ssl: true },
    pop3: { host: '', port: 995, ssl: true },
    smtp: { host: '', port: 587, ssl: true },
    note: 'Enter your provider\'s IMAP/POP3 and SMTP server details manually. Refer to your provider\'s documentation for correct settings.',
    helpUrl: '',
  },
};

export default function EmailProviderSettings() {
  const [expanded, setExpanded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [provider, setProvider] = useState('gmail');
  const [form, setForm] = useState({
    email_address: '',
    email_password: '',
    email_display_name: '',
    email_protocol: 'imap',
    email_incoming_host: '',
    email_incoming_port: 993,
    email_incoming_ssl: true,
    email_outgoing_host: '',
    email_outgoing_port: 587,
    email_outgoing_ssl: true,
    email_signature: '',
  });
  const [isConfigured, setIsConfigured] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null); // { success, message }

  useEffect(() => {
    loadSettings();
  }, []);

  const handleTestConnection = async () => {
    if (!form.email_address?.trim() || !form.email_outgoing_host?.trim()) {
      toast.error('Enter email address and outgoing SMTP host first');
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await base44.functions.invoke('testSmtpConnection', {
        host: form.email_outgoing_host.trim(),
        port: Number(form.email_outgoing_port) || 0,
        ssl: form.email_outgoing_ssl,
        email_address: form.email_address.trim(),
        password: form.email_password?.trim() || '',
      });
      const data = res?.data || {};
      if (data.success) {
        setTestResult({ success: true, message: data.message || 'Connection successful' });
        toast.success('SMTP connection successful');
      } else {
        setTestResult({ success: false, message: data.error || 'Connection failed' });
        toast.error('SMTP connection failed');
      }
    } catch (e) {
      const msg = e?.response?.data?.error || e?.data?.error || e.message;
      setTestResult({ success: false, message: msg });
      toast.error('SMTP connection failed');
    } finally {
      setTesting(false);
    }
  };

  const loadSettings = async () => {
    try {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
      const s = res.data?.settings || {};
      setForm({
        email_address: s.email_address || '',
        email_password: '',
        email_display_name: s.email_display_name || '',
        email_protocol: s.email_protocol || 'imap',
        email_incoming_host: s.email_incoming_host || '',
        email_incoming_port: s.email_incoming_port || 993,
        email_incoming_ssl: s.email_incoming_ssl !== false,
        email_outgoing_host: s.email_outgoing_host || '',
        email_outgoing_port: s.email_outgoing_port || 587,
        email_outgoing_ssl: s.email_outgoing_ssl !== false,
        email_signature: s.email_signature || '',
      });
      setProvider(s.email_provider || 'gmail');
      setIsConfigured(!!s.email_address && !!s.email_incoming_host);
    } catch (e) {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  const applyProviderPreset = (providerKey) => {
    setProvider(providerKey);
    const preset = EMAIL_PROVIDERS[providerKey];
    if (!preset) return;
    const incoming = form.email_protocol === 'pop3' ? preset.pop3 : preset.imap;
    setForm(f => ({
      ...f,
      email_incoming_host: incoming.host,
      email_incoming_port: incoming.port,
      email_incoming_ssl: incoming.ssl,
      email_outgoing_host: preset.smtp.host,
      email_outgoing_port: preset.smtp.port,
      email_outgoing_ssl: preset.smtp.ssl,
    }));
  };

  const switchProtocol = (protocol) => {
    setForm(f => ({ ...f, email_protocol: protocol }));
    const preset = EMAIL_PROVIDERS[provider];
    if (!preset) return;
    const incoming = protocol === 'pop3' ? preset.pop3 : preset.imap;
    setForm(f => ({
      ...f,
      email_protocol: protocol,
      email_incoming_host: incoming.host,
      email_incoming_port: incoming.port,
      email_incoming_ssl: incoming.ssl,
    }));
  };

  const handleSave = async () => {
    if (!form.email_address?.trim()) {
      toast.error('Email address is required');
      return;
    }
    if (!form.email_incoming_host?.trim() || !form.email_outgoing_host?.trim()) {
      toast.error('Incoming and outgoing mail servers are required');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        email_provider: provider,
        email_address: form.email_address.trim(),
        email_protocol: form.email_protocol,
        email_incoming_host: form.email_incoming_host.trim(),
        email_incoming_port: Number(form.email_incoming_port) || 0,
        email_incoming_ssl: form.email_incoming_ssl,
        email_outgoing_host: form.email_outgoing_host.trim(),
        email_outgoing_port: Number(form.email_outgoing_port) || 0,
        email_outgoing_ssl: form.email_outgoing_ssl,
        email_display_name: form.email_display_name?.trim() || '',
        email_signature: form.email_signature?.trim() || '',
      };
      if (form.email_password?.trim()) {
        payload.email_password = form.email_password.trim();
      }
      await base44.functions.invoke('saveUserSettings', { action: 'save', data: payload });
      toast.success('Email provider settings saved');
      setIsConfigured(true);
      setExpanded(false);
    } catch (e) {
      toast.error('Failed to save email settings');
    } finally {
      setSaving(false);
    }
  };

  const preset = EMAIL_PROVIDERS[provider];

  if (loading) {
    return (
      <Card className="border-purple-500/20">
        <CardContent className="py-8 flex items-center justify-center">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`border-purple-500/20 ${isConfigured ? 'bg-emerald-500/5' : 'bg-purple-500/5'}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-500/15 flex items-center justify-center">
              <Server className="w-4 h-4 text-purple-400" />
            </div>
            Email Provider Settings (IMAP / POP3 / SMTP)
          </CardTitle>
          <div className="flex items-center gap-2">
            {isConfigured ? (
              <Badge className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px]">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" />Configured
              </Badge>
            ) : (
              <Badge className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px]">
                Not Set Up
              </Badge>
            )}
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </CardHeader>

      {isConfigured && !expanded && (
        <CardContent className="pt-0 pb-4">
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <Mail className="w-3.5 h-3.5" />
            <span className="font-medium text-foreground">{form.email_address}</span>
            <span>•</span>
            <span>{preset?.label || provider}</span>
            <span>•</span>
            <span className="uppercase">{form.email_protocol}</span>
            <Button variant="outline" size="sm" className="h-6 text-[10px] ml-2" onClick={() => setExpanded(true)}>
              Edit
            </Button>
          </div>
        </CardContent>
      )}

      {expanded && (
        <CardContent className="pt-0 space-y-4">
          {/* Provider selector */}
          <div>
            <Label className="text-xs font-semibold mb-2 block">Email Provider</Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
              {Object.entries(EMAIL_PROVIDERS).map(([key, p]) => (
                <button
                  key={key}
                  onClick={() => applyProviderPreset(key)}
                  className={`px-2.5 py-2 rounded-lg text-xs font-medium border transition-all ${
                    provider === key
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Provider help note */}
          {preset?.note && (
            <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/20 rounded-lg p-3">
              <Info className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground">
                <p>{preset.note}</p>
                {preset.helpUrl && (
                  <a href={preset.helpUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline mt-1 inline-block">
                    View setup guide →
                  </a>
                )}
              </div>
            </div>
          )}

          {/* Account credentials */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs mb-1.5 block">Email Address *</Label>
              <Input
                type="email"
                placeholder="you@example.com"
                value={form.email_address}
                onChange={e => setForm(f => ({ ...f, email_address: e.target.value }))}
                className="h-8 text-xs"
              />
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">
                {form.email_password ? 'Password (enter new to update)' : 'Password / App Password *'}
              </Label>
              <div className="relative">
                <Input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={form.email_password}
                  onChange={e => setForm(f => ({ ...f, email_password: e.target.value }))}
                  className="h-8 text-xs pr-8"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Display Name (From)</Label>
              <Input
                placeholder="John Smith"
                value={form.email_display_name}
                onChange={e => setForm(f => ({ ...f, email_display_name: e.target.value }))}
                className="h-8 text-xs"
              />
            </div>
            <div>
              <Label className="text-xs mb-1.5 block">Protocol</Label>
              <div className="flex gap-2">
                <button
                  onClick={() => switchProtocol('imap')}
                  className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    form.email_protocol === 'imap'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Inbox className="w-3 h-3" /> IMAP
                </button>
                <button
                  onClick={() => switchProtocol('pop3')}
                  className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    form.email_protocol === 'pop3'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Inbox className="w-3 h-3" /> POP3
                </button>
              </div>
            </div>
          </div>

          {/* Incoming mail server */}
          <div className="bg-card border border-border rounded-xl p-3 space-y-2">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
              <Inbox className="w-3 h-3" /> Incoming Mail Server ({form.email_protocol.toUpperCase()})
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="sm:col-span-1">
                <Label className="text-[10px] mb-1 block">Host</Label>
                <Input
                  placeholder="imap.example.com"
                  value={form.email_incoming_host}
                  onChange={e => setForm(f => ({ ...f, email_incoming_host: e.target.value }))}
                  className="h-7 text-xs font-mono"
                />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">Port</Label>
                <Input
                  type="number"
                  placeholder="993"
                  value={form.email_incoming_port}
                  onChange={e => setForm(f => ({ ...f, email_incoming_port: e.target.value }))}
                  className="h-7 text-xs font-mono"
                />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                <button
                  onClick={() => setForm(f => ({ ...f, email_incoming_ssl: !f.email_incoming_ssl }))}
                  className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                    form.email_incoming_ssl
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-muted border-border text-muted-foreground'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  {form.email_incoming_ssl ? 'Enabled' : 'Disabled'}
                </button>
              </div>
            </div>
          </div>

          {/* Outgoing SMTP server */}
          <div className="bg-card border border-border rounded-xl p-3 space-y-2">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
              <Send className="w-3 h-3" /> Outgoing Mail Server (SMTP)
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div className="sm:col-span-1">
                <Label className="text-[10px] mb-1 block">Host</Label>
                <Input
                  placeholder="smtp.example.com"
                  value={form.email_outgoing_host}
                  onChange={e => setForm(f => ({ ...f, email_outgoing_host: e.target.value }))}
                  className="h-7 text-xs font-mono"
                />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">Port</Label>
                <Input
                  type="number"
                  placeholder="587"
                  value={form.email_outgoing_port}
                  onChange={e => setForm(f => ({ ...f, email_outgoing_port: e.target.value }))}
                  className="h-7 text-xs font-mono"
                />
              </div>
              <div>
                <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                <button
                  onClick={() => setForm(f => ({ ...f, email_outgoing_ssl: !f.email_outgoing_ssl }))}
                  className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                    form.email_outgoing_ssl
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                      : 'bg-muted border-border text-muted-foreground'
                  }`}
                >
                  <Shield className="w-3 h-3" />
                  {form.email_outgoing_ssl ? 'Enabled' : 'Disabled'}
                </button>
              </div>
            </div>
          </div>

          {/* Signature */}
          <div>
            <Label className="text-xs mb-1.5 block">Email Signature (optional)</Label>
            <textarea
              placeholder="Sent from AXIS Business Suite..."
              value={form.email_signature}
              onChange={e => setForm(f => ({ ...f, email_signature: e.target.value }))}
              rows={2}
              className="w-full rounded-lg border border-border bg-card text-xs px-3 py-2 focus:outline-none focus:border-primary/50 resize-none"
            />
          </div>

          {/* SMTP test result */}
          {testResult && (
            <div className={`flex items-start gap-2 rounded-lg p-3 text-xs border ${
              testResult.success
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                : 'bg-destructive/10 border-destructive/30 text-destructive'
            }`}>
              {testResult.success
                ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                : <XCircle className="w-4 h-4 shrink-0 mt-0.5" />}
              <div className="flex-1">
                <p className="font-semibold mb-0.5">
                  {testResult.success ? 'Connection successful' : 'Connection failed'}
                </p>
                <p className="opacity-90 break-words">{testResult.message}</p>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-2 pt-1">
            <Button size="sm" className="gap-1.5 h-8" onClick={handleSave} disabled={saving}>
              {saving ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Lock className="w-3.5 h-3.5" />
              )}
              Save Email Settings
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="gap-1.5 h-8"
              onClick={handleTestConnection}
              disabled={testing}
            >
              {testing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Zap className="w-3.5 h-3.5" />
              )}
              Test SMTP Connection
            </Button>
            {isConfigured && (
              <Button variant="outline" size="sm" className="h-8" onClick={() => setExpanded(false)}>
                Cancel
              </Button>
            )}
            <p className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
              <Lock className="w-2.5 h-2.5" /> Credentials encrypted & stored securely
            </p>
          </div>
        </CardContent>
      )}
    </Card>
  );
}