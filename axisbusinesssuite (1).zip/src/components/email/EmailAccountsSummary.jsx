import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Mail, Star, Settings as SettingsIcon, Loader2, Plus, Shield } from 'lucide-react';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { EMAIL_PROVIDERS } from './emailProviders';
import { toast } from 'sonner';

export default function EmailAccountsSummary() {
  const { accounts, isLoading, setDefault } = useEmailAccounts();

  const handleSetDefault = async (account) => {
    try {
      await setDefault(account.id);
      toast.success(`${account.email_address} set as default`);
    } catch (e) {
      toast.error('Failed: ' + e.message);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 flex items-center justify-center">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm flex items-center gap-2">
            <Mail className="w-4 h-4 text-primary" />
            Connected Email Accounts
          </CardTitle>
          <Link to="/settings">
            <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5">
              <SettingsIcon className="w-3 h-3" /> Manage in Settings
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="space-y-2">
        {accounts.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground mb-2">No email accounts connected</p>
            <Link to="/settings">
              <Button size="sm" className="gap-1.5">
                <Plus className="w-3.5 h-3.5" /> Add Account
              </Button>
            </Link>
          </div>
        ) : (
          accounts.map(account => {
            const preset = EMAIL_PROVIDERS[account.provider];
            return (
              <div key={account.id} className="flex items-center gap-3 py-2 px-3 rounded-lg bg-card border border-border">
                <div className="w-4 h-4 shrink-0 flex items-center justify-center">
                  {account.provider === 'gmail_oauth' || account.provider === 'outlook_oauth' ? (
                    <Shield className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Mail className="w-4 h-4 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium truncate">{account.email_address}</p>
                    {account.is_default && (
                      <Star className="w-3 h-3 text-primary fill-primary shrink-0" />
                    )}
                    {(account.provider === 'gmail_oauth' || account.provider === 'outlook_oauth') && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-medium shrink-0">OAuth</span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground truncate">{preset?.label || account.provider}</p>
                </div>
                {!account.is_default && (
                  <Button variant="ghost" size="sm" className="h-7 text-xs shrink-0" onClick={() => handleSetDefault(account)}>
                    Set Default
                  </Button>
                )}
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}