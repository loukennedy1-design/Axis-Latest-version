import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Loader2, Mail, X, Shield, AlertCircle, ChevronDown } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { toast } from 'sonner';

export default function OutlookOAuthConnect({ account, onSaved, onCancel }) {
  const { user } = useCurrentUser();
  const { saveAccount, isSaving } = useEmailAccounts();
  const [checking, setChecking] = useState(true);
  const [outlookEmails, setOutlookEmails] = useState([]);
  const [outlookName, setOutlookName] = useState('');
  const [selectedEmail, setSelectedEmail] = useState('');
  const [error, setError] = useState(null);
  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  const isEdit = !!account;

  useEffect(() => {
    if (!isAdmin) { setChecking(false); return; }
    base44.functions.invoke('outlookSync', { action: 'status' })
      .then((res) => {
        if (res.data?.connected) {
          const emails = res.data.emails || (res.data.email ? [res.data.email] : []);
          setOutlookEmails(emails);
          setOutlookName(res.data.display_name || '');
          setSelectedEmail(account?.email_address || emails[0] || '');
        } else {
          setError('Outlook is not connected. Contact your administrator to connect Microsoft.');
        }
      })
      .catch((e) => setError(e.message || 'Failed to check Outlook connection'))
      .finally(() => setChecking(false));
  }, [isAdmin]);

  const handleSave = async () => {
    if (!selectedEmail) { toast.error('Select an email address first'); return; }
    try {
      await saveAccount({
        id: account?.id,
        data: {
          label: `Outlook (${selectedEmail.split('@')[0]})`,
          provider: 'outlook_oauth',
          email_address: selectedEmail,
          display_name: outlookName || selectedEmail.split('@')[0],
          is_default: false,
        },
      });
      toast.success('Outlook account added');
      onSaved?.();
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
  };

  const handleDisconnect = async () => {
    if (!account) return;
    try {
      await base44.functions.invoke('manageEmailAccounts', { action: 'disconnect_oauth', id: account.id });
      toast.success('Outlook account removed');
      onSaved?.();
    } catch (e) {
      toast.error('Failed to disconnect: ' + (e.message || 'Unknown error'));
    }
  };

  // Non-admin users — direct them to SMTP setup
  if (!isAdmin) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Outlook / Microsoft 365</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Set up your own email account</p>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/20 rounded-lg p-3">
          <AlertCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground space-y-1">
            <p>Outlook OAuth is an admin-only feature. To send and receive emails from your own Outlook account, use the app-password (SMTP) setup:</p>
            <ol className="list-decimal list-inside space-y-0.5 mt-2">
              <li>Go to <a href="https://account.microsoft.com/security" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">Microsoft Account Security</a></li>
              <li>Enable Two-Step Verification if not already on</li>
              <li>Create an App Password under "App passwords"</li>
              <li>Select "Outlook / Hotmail (Microsoft 365)" above and enter that app password</li>
            </ol>
          </div>
        </div>
        <Button variant="outline" className="w-full" onClick={onCancel}>Back to Provider List</Button>
      </div>
    );
  }

  if (checking) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Microsoft / Outlook Connection</h2>
            <p className="text-xs text-muted-foreground mt-0.5">Checking connection status...</p>
          </div>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Microsoft / Outlook Connection</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Admin feature — connected via shared Microsoft OAuth</p>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      {error ? (
        <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-lg p-3">
          <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
          <div className="text-xs text-destructive">{error}</div>
        </div>
      ) : isEdit ? (
        <div className="space-y-4">
          <div className="flex items-center gap-3 p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/30">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{account.email_address}</p>
              <p className="text-xs text-emerald-400 flex items-center gap-1 mt-0.5">
                <Shield className="w-3 h-3" /> Connected via Microsoft OAuth
              </p>
            </div>
          </div>
          <Button variant="destructive" className="w-full gap-1.5" onClick={handleDisconnect} disabled={isSaving}>
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <X className="w-4 h-4" />}
            Disconnect Outlook
          </Button>
        </div>
      ) : outlookEmails.length > 0 ? (
        <div className="space-y-4">
          <div className="flex items-start gap-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg p-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="text-xs text-muted-foreground">
              <p className="text-emerald-400 font-medium mb-1">Microsoft account connected!</p>
              <p>Select which email address you want to send from:</p>
            </div>
          </div>

          {/* Email alias picker */}
          <div>
            <label className="text-xs font-medium mb-1.5 block">From Email Address</label>
            <div className="relative">
              <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <select
                value={selectedEmail}
                onChange={(e) => setSelectedEmail(e.target.value)}
                className="w-full h-9 text-sm pl-8 pr-8 rounded-md border border-border bg-card appearance-none cursor-pointer focus:outline-none focus:border-primary/50"
              >
                {outlookEmails.map((email) => (
                  <option key={email} value={email}>{email}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
            </div>
            {outlookEmails.length > 1 && (
              <p className="text-[10px] text-muted-foreground mt-1">
                {outlookEmails.length} email addresses found on your Microsoft account
              </p>
            )}
          </div>

          <Button className="w-full gap-2 h-11 bg-[#0078D4] hover:bg-[#106EBE] text-white" onClick={handleSave} disabled={isSaving || !selectedEmail}>
            {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
            Add Outlook Account
          </Button>
        </div>
      ) : (
        <div className="flex items-start gap-2 bg-destructive/10 border border-destructive/30 rounded-lg p-3">
          <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
          <div className="text-xs text-destructive">No email addresses found on the connected Microsoft account.</div>
        </div>
      )}
    </div>
  );
}