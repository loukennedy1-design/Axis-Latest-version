import React, { useState, useMemo, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Lock, Eye, EyeOff, CheckCircle2, Loader2,
  Inbox, Send, Shield, Info, XCircle, Zap, X, ChevronDown, ChevronUp, Search, Mail
} from 'lucide-react';
import { EMAIL_PROVIDERS } from './emailProviders';
import GmailOAuthConnect from './GmailOAuthConnect';
import OutlookOAuthConnect from './OutlookOAuthConnect';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { base44 } from '@/api/base44Client';
import { mapSmtpError } from '@/lib/smtpErrorMapper';
import { toast } from 'sonner';

// Auto-detect provider from email domain
const PROVIDER_DOMAIN_MAP = {
  'gmail.com': 'gmail_oauth',
  'googlemail.com': 'gmail_oauth',
  'outlook.com': 'outlook_oauth',
  'hotmail.com': 'outlook_oauth',
  'live.com': 'outlook_oauth',
  'msn.com': 'outlook_oauth',
  'yahoo.com': 'yahoo',
  'yahoo.co.uk': 'yahoo',
  'yahoo.ca': 'yahoo',
  'icloud.com': 'icloud',
  'me.com': 'icloud',
  'mac.com': 'icloud',
  'aol.com': 'aol',
  'zoho.com': 'zoho',
  'protonmail.com': 'protonmail',
  'proton.me': 'protonmail',
  'fastmail.com': 'fastmail',
  'gmx.com': 'gmx',
  'gmx.us': 'gmx',
  'mail.com': 'mail_com',
  'yandex.com': 'yandex',
  'yandex.ru': 'yandex',
  'secureserver.net': 'godaddy',
  'privateemail.com': 'namecheap',
  'emailsrvr.com': 'rackspace',
  'mxroute.com': 'mxroute',
  'awsapps.com': 'amazon_workmail',
};

function detectProviderFromEmail(email) {
  if (!email) return null;
  const domain = email.split('@')[1]?.toLowerCase().trim();
  if (!domain) return null;
  return PROVIDER_DOMAIN_MAP[domain] || null;
}

export default function EmailAccountForm({ account, onSaved, onCancel }) {
  const { saveAccount, isSaving } = useEmailAccounts();
  const isEdit = !!account;

  const [provider, setProvider] = useState(account?.provider || 'gmail');
  const [showPassword, setShowPassword] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(account?.provider === 'custom');
  const [providerSearch, setProviderSearch] = useState('');
  const [form, setForm] = useState({
    label: account?.label || '',
    email_address: account?.email_address || '',
    email_password: '',
    display_name: account?.display_name || '',
    protocol: account?.protocol || 'imap',
    incoming_host: account?.incoming_host || '',
    incoming_port: account?.incoming_port || 993,
    incoming_ssl: account?.incoming_ssl !== false,
    outgoing_host: account?.outgoing_host || '',
    outgoing_port: account?.outgoing_port || 587,
    outgoing_ssl: account?.outgoing_ssl !== false,
    signature: account?.signature || '',
  });
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);
  const detectTimeoutRef = useRef(null);

  const isGmailOAuth = provider === 'gmail_oauth';
  const isOutlookOAuth = provider === 'outlook_oauth';
  const preset = EMAIL_PROVIDERS[provider];
  const isCustom = provider === 'custom';

  // Filter providers by search
  const filteredProviders = useMemo(() => {
    if (!providerSearch.trim()) return Object.entries(EMAIL_PROVIDERS);
    const q = providerSearch.toLowerCase();
    return Object.entries(EMAIL_PROVIDERS).filter(([key, p]) =>
      p.label.toLowerCase().includes(q) || key.includes(q)
    );
  }, [providerSearch]);

  const applyProviderPreset = (key, currentEmail = form.email_address) => {
    setProvider(key);
    setShowAdvanced(key === 'custom');
    const p = EMAIL_PROVIDERS[key];
    if (!p) return;
    const protocol = form.protocol;
    const incoming = protocol === 'pop3' ? p.pop3 : p.imap;
    setForm(f => ({
      ...f,
      incoming_host: incoming.host,
      incoming_port: incoming.port,
      incoming_ssl: incoming.ssl,
      outgoing_host: p.smtp.host,
      outgoing_port: p.smtp.port,
      outgoing_ssl: p.smtp.ssl,
    }));
  };

  const [autoDiscovering, setAutoDiscovering] = useState(false);

  // Detect common SMTP port typos and suggest the correct one
  const smtpPortSuggestion = useMemo(() => {
    const p = Number(form.outgoing_port);
    if (!p) return null;
    const valid = [25, 465, 587, 2525];
    if (valid.includes(p)) return null;
    // Near-miss: 485→465, 467→465, 578→587, 588→587
    if (Math.abs(p - 465) <= 2) return 465;
    if (Math.abs(p - 587) <= 2) return 587;
    if (Math.abs(p - 2525) <= 2) return 2525;
    return null;
  }, [form.outgoing_port]);

  // Auto-detect provider when email changes
  const handleEmailChange = (email) => {
    setForm(f => ({ ...f, email_address: email }));
    
    // First check known provider domains
    const detected = detectProviderFromEmail(email);
    if (detected && detected !== provider) {
      applyProviderPreset(detected, email);
      return;
    }
    
    // For unknown domains, auto-discover via DNS/MX lookup
    // Debounce so we only run when user stops typing
    if (detectTimeoutRef.current) clearTimeout(detectTimeoutRef.current);
    if (email.includes('@') && email.split('@')[1]?.includes('.')) {
      detectTimeoutRef.current = setTimeout(() => autoDiscoverSettings(email), 800);
    }
  };

  // Auto-discover mail settings for custom domains via backend DNS lookup
  const autoDiscoverSettings = async (email) => {
    setAutoDiscovering(true);
    try {
      const res = await base44.functions.invoke('autoDiscoverMailSettings', { email_address: email });
      const data = res?.data || {};
      if (data.warning) {
        toast.warning(data.warning, { duration: 8000 });
      }
      if (data.success && data.auto_settings) {
        const s = data.auto_settings;
        setProvider('custom');
        setShowAdvanced(false);
        setForm(f => ({
          ...f,
          protocol: s.protocol,
          incoming_host: s.incoming_host,
          incoming_port: s.incoming_port,
          incoming_ssl: s.incoming_ssl,
          outgoing_host: s.outgoing_host,
          outgoing_port: s.outgoing_port,
          outgoing_ssl: s.outgoing_ssl,
        }));
      }
    } catch {
      // Silent fail — user can still enter manually
    } finally {
      setAutoDiscovering(false);
    }
  };

  const switchProtocol = (protocol) => {
    const p = EMAIL_PROVIDERS[provider];
    const incoming = protocol === 'pop3' ? p?.pop3 : p?.imap;
    setForm(f => ({
      ...f,
      protocol,
      incoming_host: incoming?.host || f.incoming_host,
      incoming_port: incoming?.port || f.incoming_port,
      incoming_ssl: incoming?.ssl ?? f.incoming_ssl,
    }));
  };

  const handleTest = async () => {
    if (!form.email_address?.trim() || !form.outgoing_host?.trim()) {
      toast.error('Enter your email address first');
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      if (isEdit && !form.email_password?.trim()) {
        const res = await base44.functions.invoke('manageEmailAccounts', { action: 'test', id: account.id });
        const data = res.data || {};
        setTestResult(data.success
          ? { success: true, message: data.message || 'Connection successful' }
          : { success: false, message: data.error || 'Connection failed' });
      } else {
        const res = await base44.functions.invoke('testSmtpConnection', {
          host: form.outgoing_host.trim(),
          port: Number(form.outgoing_port) || 0,
          ssl: form.outgoing_ssl,
          email_address: form.email_address.trim(),
          password: form.email_password?.trim() || '',
        });
        const data = res?.data || {};
        setTestResult(data.success
          ? { success: true, message: data.message || 'Connection successful' }
          : { success: false, message: data.error || 'Connection failed' });
      }
    } catch (e) {
      const msg = e?.response?.data?.error || e?.data?.error || e.message;
      setTestResult({ success: false, message: msg });
    } finally {
      setTesting(false);
    }
  };

  const handleSave = async () => {
    if (!form.email_address?.trim()) {
      toast.error('Email address is required');
      return;
    }
    if (!isCustom) {
      // For known providers, ensure presets are applied
      const p = EMAIL_PROVIDERS[provider];
      if (p) {
        const incoming = form.protocol === 'pop3' ? p.pop3 : p.imap;
        form.incoming_host = incoming.host;
        form.incoming_port = incoming.port;
        form.incoming_ssl = incoming.ssl;
        form.outgoing_host = p.smtp.host;
        form.outgoing_port = p.smtp.port;
        form.outgoing_ssl = p.smtp.ssl;
      }
    }
    if (!form.incoming_host?.trim() || !form.outgoing_host?.trim()) {
      toast.error('Mail server settings are missing. Try selecting your provider again.');
      return;
    }
    if (!isEdit && !form.email_password?.trim()) {
      toast.error('Password is required');
      return;
    }
    try {
      const data = {
        label: form.label?.trim() || '',
        provider,
        email_address: form.email_address.trim(),
        display_name: form.display_name?.trim() || '',
        protocol: form.protocol,
        incoming_host: form.incoming_host.trim(),
        incoming_port: Number(form.incoming_port) || 0,
        incoming_ssl: form.incoming_ssl,
        outgoing_host: form.outgoing_host.trim(),
        outgoing_port: Number(form.outgoing_port) || 0,
        outgoing_ssl: form.outgoing_ssl,
        signature: form.signature?.trim() || '',
      };
      if (form.email_password?.trim()) {
        data.email_password = form.email_password.trim();
      }
      await saveAccount({ id: account?.id, data });
      toast.success(isEdit ? 'Email account updated' : 'Email account added');
      onSaved?.();
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
  };

  if (isGmailOAuth) {
    return <GmailOAuthConnect account={account} onSaved={onSaved} onCancel={onCancel} />;
  }
  if (isOutlookOAuth) {
    return <OutlookOAuthConnect account={account} onSaved={onSaved} onCancel={onCancel} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">{isEdit ? 'Edit Email Account' : 'Add Email Account'}</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Pick your provider, enter your email & password — that's it.</p>
        </div>
        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onCancel}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Email Address — put this FIRST so auto-detect kicks in */}
      <div>
        <Label className="text-xs mb-1.5 block">Email Address *</Label>
        <div className="relative">
          <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            type="email"
            placeholder="you@example.com"
            value={form.email_address}
            onChange={e => handleEmailChange(e.target.value)}
            className="h-9 text-sm pl-8"
            autoComplete="email"
          />
        </div>
        {autoDiscovering && (
          <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
            <Loader2 className="w-3 h-3 animate-spin" /> Looking up mail settings...
          </p>
        )}
        {!autoDiscovering && provider !== 'custom' && form.email_address && detectProviderFromEmail(form.email_address) && (
          <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Detected: {preset?.label}
          </p>
        )}
        {!autoDiscovering && provider === 'custom' && form.incoming_host && form.email_address && !detectProviderFromEmail(form.email_address) && (
          <p className="text-[10px] text-emerald-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" /> Found: {form.incoming_host}
          </p>
        )}
      </div>

      {/* Gmail address detected on manual path — redirect to OAuth */}
      {(() => {
        const emailDomain = form.email_address?.split('@')[1]?.toLowerCase().trim();
        const isGmailAddr = emailDomain === 'gmail.com' || emailDomain === 'googlemail.com';
        if (isGmailAddr && provider !== 'gmail_oauth') {
          return (
            <div className="flex items-start gap-2 bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
              <Mail className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-medium text-blue-400 mb-0.5">Gmail account detected</p>
                <p className="text-xs text-muted-foreground mb-2">
                  Gmail doesn't allow password-based IMAP login — you need an App Password or OAuth. The easiest and most secure way is to connect via Google OAuth (no password needed).
                </p>
                <Button size="sm" className="h-7 text-xs gap-1.5" onClick={() => applyProviderPreset('gmail_oauth')}>
                  <Mail className="w-3 h-3" /> Use Secure Gmail OAuth Instead
                </Button>
              </div>
            </div>
          );
        }
        return null;
      })()}

      {/* Provider Picker with Search */}
      <div>
        <Label className="text-xs font-semibold mb-2 block">Email Provider</Label>
        <div className="relative mb-2">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <Input
            placeholder="Search providers..."
            value={providerSearch}
            onChange={e => setProviderSearch(e.target.value)}
            className="h-8 text-xs pl-8"
          />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-32 overflow-y-auto">
          {filteredProviders.map(([key, p]) => (
            <button
              key={key}
              onClick={() => applyProviderPreset(key)}
              className={`px-2.5 py-2 rounded-lg text-xs font-medium border transition-all ${
                provider === key
                  ? 'bg-primary/10 border-primary text-primary'
                  : 'bg-card border-border text-muted-foreground hover:border-primary/30 hover:text-foreground'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Help note for selected provider */}
      {preset?.note && (
        <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/20 rounded-lg p-3">
          <Info className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs text-muted-foreground">
            <p>{preset.note}</p>
            {preset.helpUrl && (
              <a href={preset.helpUrl} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline mt-1 inline-block">
                View setup guide →
              </a>
            )}
          </div>
        </div>
      )}

      {/* Simple fields: password, display name, label */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="sm:col-span-2">
          <Label className="text-xs mb-1.5 block">
            {isEdit ? 'Password (leave blank to keep current)' : 'Password / App Password *'}
          </Label>
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="••••••••"
              value={form.email_password}
              onChange={e => setForm(f => ({ ...f, email_password: e.target.value }))}
              className="h-9 text-sm pr-9"
              autoComplete="current-password"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>
        <div>
          <Label className="text-xs mb-1.5 block">Display Name (From)</Label>
          <Input
            placeholder="John Smith"
            value={form.display_name}
            onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
            className="h-9 text-sm"
          />
        </div>
        <div>
          <Label className="text-xs mb-1.5 block">Label (optional)</Label>
          <Input
            placeholder="Work, Personal, etc."
            value={form.label}
            onChange={e => setForm(f => ({ ...f, label: e.target.value }))}
            className="h-9 text-sm"
          />
        </div>
      </div>

      {/* Advanced Settings — collapsible, only needed for custom or manual tweaks */}
      <div className="border border-border rounded-xl overflow-hidden">
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="w-full flex items-center justify-between px-3 py-2.5 bg-card hover:bg-accent/50 transition-colors"
        >
          <span className="text-xs font-semibold flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" />
            Advanced Settings (Server Details)
          </span>
          {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {showAdvanced && (
          <div className="p-3 space-y-3">
            {!isCustom && (
              <p className="text-[10px] text-muted-foreground bg-muted/50 rounded-lg p-2">
                These are auto-filled for {preset?.label}. Only change if you know your provider uses different servers.
              </p>
            )}

            {/* Protocol selector */}
            <div>
              <Label className="text-[10px] mb-1.5 block">Protocol</Label>
              <div className="flex gap-2">
                <button
                  onClick={() => switchProtocol('imap')}
                  className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    form.protocol === 'imap'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Inbox className="w-3 h-3" /> IMAP
                </button>
                <button
                  onClick={() => switchProtocol('pop3')}
                  className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${
                    form.protocol === 'pop3'
                      ? 'bg-primary/10 border-primary text-primary'
                      : 'bg-card border-border text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Inbox className="w-3 h-3" /> POP3
                </button>
              </div>
            </div>

            {/* Incoming Server */}
            <div className="bg-card border border-border rounded-lg p-2.5 space-y-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
                <Inbox className="w-3 h-3" /> Incoming Mail Server ({form.protocol.toUpperCase()})
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <Label className="text-[10px] mb-1 block">Host</Label>
                  <Input
                    placeholder="imap.example.com"
                    value={form.incoming_host}
                    onChange={e => setForm(f => ({ ...f, incoming_host: e.target.value }))}
                    className="h-7 text-xs font-mono"
                  />
                </div>
                <div>
                  <Label className="text-[10px] mb-1 block">Port</Label>
                  <Input
                    type="number"
                    placeholder="993"
                    value={form.incoming_port}
                    onChange={e => setForm(f => ({ ...f, incoming_port: e.target.value }))}
                    className="h-7 text-xs font-mono"
                  />
                </div>
                <div>
                  <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                  <button
                    onClick={() => setForm(f => ({ ...f, incoming_ssl: !f.incoming_ssl }))}
                    className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                      form.incoming_ssl
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : 'bg-muted border-border text-muted-foreground'
                    }`}
                  >
                    <Shield className="w-3 h-3" />
                    {form.incoming_ssl ? 'On' : 'Off'}
                  </button>
                </div>
              </div>
            </div>

            {/* Outgoing Server */}
            <div className="bg-card border border-border rounded-lg p-2.5 space-y-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
                <Send className="w-3 h-3" /> Outgoing Mail Server (SMTP)
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <Label className="text-[10px] mb-1 block">Host</Label>
                  <Input
                    placeholder="smtp.example.com"
                    value={form.outgoing_host}
                    onChange={e => setForm(f => ({ ...f, outgoing_host: e.target.value }))}
                    className="h-7 text-xs font-mono"
                  />
                </div>
                <div>
                  <Label className="text-[10px] mb-1 block">Port</Label>
                  <Input
                    type="number"
                    placeholder="587"
                    value={form.outgoing_port}
                    onChange={e => setForm(f => ({ ...f, outgoing_port: e.target.value }))}
                    className={`h-7 text-xs font-mono ${smtpPortSuggestion ? 'border-amber-500/50' : ''}`}
                  />
                  {smtpPortSuggestion && (
                    <button
                      onClick={() => setForm(f => ({ ...f, outgoing_port: smtpPortSuggestion }))}
                      className="text-[10px] text-amber-400 hover:text-amber-300 mt-1 flex items-center gap-1"
                    >
                      <Zap className="w-2.5 h-2.5" /> Use {smtpPortSuggestion} instead?
                    </button>
                  )}
                </div>
                <div>
                  <Label className="text-[10px] mb-1 block">SSL/TLS</Label>
                  <button
                    onClick={() => setForm(f => ({ ...f, outgoing_ssl: !f.outgoing_ssl }))}
                    className={`w-full h-7 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                      form.outgoing_ssl
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : 'bg-muted border-border text-muted-foreground'
                    }`}
                  >
                    <Shield className="w-3 h-3" />
                    {form.outgoing_ssl ? 'On' : 'Off'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Signature — moved below advanced, still accessible */}
      <details className="group">
        <summary className="text-xs font-semibold cursor-pointer text-muted-foreground hover:text-foreground flex items-center gap-1.5 list-none">
          <ChevronDown className="w-3.5 h-3.5 group-open:rotate-180 transition-transform" />
          Email Signature (optional)
        </summary>
        <textarea
          placeholder="Sent from AXIS Business Suite..."
          value={form.signature}
          onChange={e => setForm(f => ({ ...f, signature: e.target.value }))}
          rows={2}
          className="w-full mt-2 rounded-lg border border-border bg-card text-xs px-3 py-2 focus:outline-none focus:border-primary/50 resize-none"
        />
      </details>

      {testResult && (() => {
        const mapped = testResult.success ? null : mapSmtpError(testResult.message, form.email_address);
        return (
          <div className={`flex items-start gap-2 rounded-lg p-3 text-xs border ${
            testResult.success
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
              : 'bg-destructive/10 border-destructive/30 text-destructive'
          }`}>
            {testResult.success
              ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              : <XCircle className="w-4 h-4 shrink-0 mt-0.5" />}
            <div className="flex-1">
              <p className="font-semibold mb-0.5">{testResult.success ? 'Connection successful' : 'Connection failed'}</p>
              <p className="opacity-90 break-words">{testResult.message}</p>
              {mapped?.fix && (
                <p className="font-semibold mt-1 pt-1 border-t border-destructive/20">{mapped.fix}</p>
              )}
            </div>
          </div>
        );
      })()}

      <div className="flex items-center gap-2 pt-1">
        <Button size="sm" className="gap-1.5 h-9 flex-1" onClick={handleSave} disabled={isSaving}>
          {isSaving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Lock className="w-3.5 h-3.5" />}
          {isEdit ? 'Update Account' : 'Save & Connect'}
        </Button>
        <Button variant="outline" size="sm" className="gap-1.5 h-9" onClick={handleTest} disabled={testing}>
          {testing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
          Test
        </Button>
        <Button variant="ghost" size="sm" className="h-9" onClick={onCancel}>Cancel</Button>
        <p className="text-[10px] text-muted-foreground flex items-center gap-1 ml-auto">
          <Lock className="w-2.5 h-2.5" /> Encrypted
        </p>
      </div>
    </div>
  );
}