import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Copy, Loader2, FileText, Search } from 'lucide-react';

const CATEGORY_LABELS = {
  follow_up: 'Follow-Up',
  appointment: 'Appointment',
  introduction: 'Introduction',
  thank_you: 'Thank You',
  reminder: 'Reminder',
  re_engagement: 'Re-Engagement',
  custom: 'Custom',
};

const CATEGORY_COLORS = {
  follow_up: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  appointment: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  introduction: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  thank_you: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  reminder: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  re_engagement: 'bg-pink-500/10 text-pink-400 border-pink-500/20',
  custom: 'bg-muted text-muted-foreground border-border',
};

const VARIABLE_HINTS = [
  { token: '{{first_name}}', label: "Lead's First Name" },
  { token: '{{last_name}}', label: "Lead's Last Name" },
  { token: '{{company}}', label: 'Company' },
  { token: '{{lead_name}}', label: 'Full Name' },
  { token: '{{lead_phone}}', label: 'Phone' },
  { token: '{{appointment_date}}', label: 'Appt Date' },
];

export default function TemplateManager({ onClose }) {
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['emailTemplates'],
    queryFn: () => base44.entities.EmailTemplate.list('-updated_date', 200),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.EmailTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['emailTemplates']);
      toast.success('Template deleted');
    },
    onError: (e) => toast.error('Failed to delete: ' + e.message),
  });

  const duplicateMutation = useMutation({
    mutationFn: (t) => base44.entities.EmailTemplate.create({
      name: t.name + ' (Copy)',
      category: t.category,
      subject: t.subject,
      body: t.body,
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['emailTemplates']);
      toast.success('Template duplicated');
    },
    onError: (e) => toast.error('Failed to duplicate: ' + e.message),
  });

  const filtered = templates.filter(t =>
    !search || t.name?.toLowerCase().includes(search.toLowerCase()) ||
    t.subject?.toLowerCase().includes(search.toLowerCase()) ||
    t.body?.toLowerCase().includes(search.toLowerCase())
  );

  const grouped = filtered.reduce((acc, t) => {
    const cat = t.category || 'custom';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(t);
    return acc;
  }, {});

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <FileText className="w-5 h-5" /> Email Templates
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            Save common follow-up messages. Use variables like{' '}
            <code className="text-primary">{'{{first_name}}'}</code> for auto-personalization.
          </p>
        </div>
        <Button
          size="sm"
          className="gap-1.5"
          onClick={() => { setEditing(null); setShowForm(true); }}
        >
          <Plus className="w-4 h-4" /> New Template
        </Button>
      </div>

      {showForm && (
        <TemplateForm
          template={editing}
          onSave={() => {
            setShowForm(false);
            setEditing(null);
            queryClient.invalidateQueries(['emailTemplates']);
          }}
          onCancel={() => { setShowForm(false); setEditing(null); }}
        />
      )}

      <div className="relative">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <Input
          placeholder="Search templates..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="h-9 pl-8"
        />
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 space-y-2">
          <FileText className="w-10 h-10 text-muted-foreground/30 mx-auto" />
          <p className="text-sm text-muted-foreground">
            {search ? 'No templates match your search.' : 'No templates yet. Create one to speed up your follow-ups.'}
          </p>
          {!search && (
            <Button size="sm" variant="outline" className="gap-1.5" onClick={() => { setEditing(null); setShowForm(true); }}>
              <Plus className="w-4 h-4" /> Create First Template
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {Object.entries(grouped).map(([cat, items]) => (
            <div key={cat}>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                {CATEGORY_LABELS[cat] || cat} ({items.length})
              </p>
              <div className="grid gap-2">
                {items.map(t => (
                  <div
                    key={t.id}
                    className="bg-card border border-border rounded-lg p-3 hover:border-primary/30 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm truncate">{t.name}</span>
                          <span className={`text-[9px] px-1.5 py-0.5 rounded border ${CATEGORY_COLORS[cat] || CATEGORY_COLORS.custom}`}>
                            {CATEGORY_LABELS[cat] || cat}
                          </span>
                          {t.usage_count > 0 && (
                            <span className="text-[9px] text-muted-foreground">Used {t.usage_count}×</span>
                          )}
                        </div>
                        <p className="text-xs font-medium text-foreground/80 truncate">{t.subject || '(no subject)'}</p>
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{t.body}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => { setEditing(t); setShowForm(true); }}
                          title="Edit"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => duplicateMutation.mutate(t)}
                          title="Duplicate"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 hover:text-destructive"
                          onClick={() => { if (confirm(`Delete "${t.name}"?`)) deleteMutation.mutate(t.id); }}
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function TemplateForm({ template, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: template?.name || '',
    category: template?.category || 'follow_up',
    subject: template?.subject || '',
    body: template?.body || '',
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!form.name?.trim() || !form.subject?.trim() || !form.body?.trim()) {
      toast.error('Name, subject, and body are required');
      return;
    }
    setSaving(true);
    try {
      if (template?.id) {
        await base44.entities.EmailTemplate.update(template.id, {
          name: form.name.trim(),
          category: form.category,
          subject: form.subject.trim(),
          body: form.body.trim(),
        });
        toast.success('Template updated');
      } else {
        await base44.entities.EmailTemplate.create({
          name: form.name.trim(),
          category: form.category,
          subject: form.subject.trim(),
          body: form.body.trim(),
        });
        toast.success('Template created');
      }
      onSave?.();
    } catch (e) {
      toast.error('Failed to save: ' + e.message);
    }
    setSaving(false);
  };

  const insertVariable = (token) => {
    setForm(f => ({ ...f, body: f.body + ' ' + token + ' ' }));
  };

  return (
    <Dialog open onOpenChange={onCancel}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{template ? 'Edit Template' : 'New Template'}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Template Name *</Label>
              <Input
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Post-Call Follow-Up"
                className="h-9"
              />
            </div>
            <div>
              <Label className="text-xs">Category</Label>
              <Select value={form.category} onValueChange={v => setForm({ ...form, category: v })}>
                <SelectTrigger className="h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label className="text-xs">Subject Line *</Label>
            <Input
              value={form.subject}
              onChange={e => setForm({ ...form, subject: e.target.value })}
              placeholder="e.g. Following up on our call, {{first_name}}"
              className="h-9"
            />
          </div>
          <div>
            <div className="flex items-center justify-between mb-1">
              <Label className="text-xs">Message Body *</Label>
              <div className="flex items-center gap-1 flex-wrap">
                {VARIABLE_HINTS.map(v => (
                  <button
                    key={v.token}
                    onClick={() => insertVariable(v.token)}
                    className="text-[9px] px-1.5 py-0.5 rounded bg-muted hover:bg-primary/10 hover:text-primary text-muted-foreground transition-colors"
                    title={v.label}
                  >
                    {v.token}
                  </button>
                ))}
              </div>
            </div>
            <Textarea
              value={form.body}
              onChange={e => setForm({ ...form, body: e.target.value })}
              rows={8}
              placeholder="Hi {{first_name}},&#10;&#10;Thanks for taking my call today..."
              className="font-mono text-sm"
            />
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button variant="outline" onClick={onCancel}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="gap-1.5">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {template ? 'Update Template' : 'Save Template'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}