import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Send, Users } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

function makeConvId(emailA, emailB) {
  return [emailA, emailB].sort().join('__');
}

function groupConvId(participantEmails) {
  return 'group__' + [...participantEmails].sort().join('__');
}

export default function ChatWindow({
  otherUser,
  currentUser,
  messages,
  onNewMessage,
  // Group-mode props (optional)
  isGroup = false,
  groupName,
  participants = [], // array of { email, full_name } (all members including current user)
}) {
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const displayName = isGroup ? (groupName || 'Group') : (otherUser?.full_name || otherUser?.email || '');
  const headerSub = isGroup
    ? `${participants.length} members`
    : otherUser?.email;

  const handleSend = async () => {
    const text = body.trim();
    if (!text || sending) return;
    setSending(true);
    try {
      if (isGroup) {
        const memberEmails = participants.map(p => p.email);
        const convId = groupConvId(memberEmails);
        const others = participants.filter(p => p.email !== currentUser.email);
        // Fan-out: one record per other recipient so each member can read their
        // own copy under the existing per-recipient RLS.
        await base44.entities.ChatMessage.bulkCreate(
          others.map(p => ({
            conversation_id: convId,
            sender_email: currentUser.email,
            sender_name: currentUser.full_name || currentUser.email,
            recipient_email: p.email,
            recipient_name: p.full_name || p.email,
            body: text,
            read: false,
            is_group: true,
            participants: JSON.stringify(memberEmails),
            group_name: groupName,
            owner: currentUser.email,
          }))
        );
        toast.success(`Sent to ${groupName || 'group'}`);
      } else {
        const convId = makeConvId(currentUser.email, otherUser.email);
        await base44.entities.ChatMessage.create({
          conversation_id: convId,
          sender_email: currentUser.email,
          sender_name: currentUser.full_name || currentUser.email,
          recipient_email: otherUser.email,
          recipient_name: otherUser.full_name || otherUser.email,
          body: text,
          read: false,
          owner: currentUser.email,
        });
        try {
          await base44.functions.invoke('sendChatNotification', {
            to_email: otherUser.email,
            to_name: otherUser.full_name || otherUser.email,
            from_email: currentUser.email,
            from_name: currentUser.full_name || currentUser.email,
            message: text,
          });
        } catch (err) {
          console.error('Failed to send chat notification:', err);
        }
        toast.success(`Message sent to ${otherUser.full_name || otherUser.email}`);
      }
      setBody('');
      onNewMessage?.();
    } catch (e) {
      console.error('Send failed:', e);
      toast.error('Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-3 border-b flex items-center gap-3 bg-card">
        {isGroup ? (
          <div className="w-8 h-8 rounded-full bg-primary/15 flex items-center justify-center text-primary">
            <Users className="w-4 h-4" />
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-bold">
            {otherUser?.full_name?.[0]?.toUpperCase() || otherUser?.email?.[0]?.toUpperCase() || '?'}
          </div>
        )}
        <div className="min-w-0">
          <p className="text-sm font-semibold truncate">{displayName}</p>
          <p className="text-[11px] text-muted-foreground truncate">{headerSub}</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3">
        {messages.length === 0 && (
          <p className="text-center text-muted-foreground text-sm mt-8">
            Start the conversation{isGroup ? ` in ${groupName || 'this group'}` : ` with ${otherUser?.full_name || otherUser?.email}`}
          </p>
        )}
        {messages.map((msg, i) => {
          const isMe = msg.sender_email === currentUser.email;
          const showDate =
            i === 0 ||
            new Date(msg.created_date).toDateString() !== new Date(messages[i - 1]?.created_date).toDateString();
          // In group chats, show the sender's name above incoming bubbles.
          const showSenderLabel = isGroup && !isMe && (
            i === 0 || messages[i - 1]?.sender_email !== msg.sender_email ||
            new Date(msg.created_date).toDateString() !== new Date(messages[i - 1]?.created_date).toDateString()
          );
          const senderUser = participants.find(p => p.email === msg.sender_email);

          return (
            <React.Fragment key={msg.id}>
              {showDate && (
                <p className="text-center text-[10px] text-muted-foreground my-2">
                  {format(new Date(msg.created_date), 'EEEE, MMM d')}
                </p>
              )}
              {showSenderLabel && (
                <p className="text-[10px] text-muted-foreground ml-1 mb-0.5">
                  {msg.sender_name || senderUser?.full_name || msg.sender_email}
                </p>
              )}
              <div className={cn('flex', isMe ? 'justify-end' : 'justify-start')}>
                <div
                  className={cn(
                    'max-w-[72%] rounded-2xl px-4 py-2 text-sm leading-relaxed',
                    isMe
                      ? 'bg-primary text-primary-foreground rounded-br-sm'
                      : 'bg-muted text-foreground rounded-bl-sm'
                  )}
                >
                  {msg.body}
                  <p className={cn('text-[9px] mt-1 text-right', isMe ? 'text-primary-foreground/60' : 'text-muted-foreground')}>
                    {msg.created_date ? format(new Date(msg.created_date), 'h:mm a') : ''}
                  </p>
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-4 py-3 border-t bg-card flex gap-2 items-end">
        <Textarea
          value={body}
          onChange={e => setBody(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a message... (Enter to send)"
          className="resize-none text-sm"
          rows={2}
        />
        <Button size="icon" onClick={handleSend} disabled={!body.trim() || sending} className="h-10 w-10 shrink-0">
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}