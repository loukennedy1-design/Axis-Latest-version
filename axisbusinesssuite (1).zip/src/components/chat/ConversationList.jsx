import React from 'react';
import { cn } from '@/lib/utils';
import { format, isToday } from 'date-fns';
import { MessageCircle, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

function fmt(d) {
  if (!d) return '';
  const dt = new Date(d);
  return isToday(dt) ? format(dt, 'h:mm a') : format(dt, 'MMM d');
}

export default function ConversationList({ conversations, selectedId, onSelect, currentUserEmail }) {
  if (!conversations.length) {
    return (
      <div className="flex flex-col items-center justify-center h-40 text-muted-foreground gap-2 p-4">
        <MessageCircle className="w-7 h-7 opacity-30" />
        <p className="text-xs text-center">No conversations yet. Select an AE or start a group chat.</p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-border">
      {conversations.map((conv) => {
        const other = conv.other;
        const latest = conv.latest;
        const unread = conv.unreadCount;
        const isSelected = conv.conversation_id === selectedId;
        const isGroup = !!conv.isGroup;
        const title = isGroup ? (conv.groupName || 'Group') : (other?.full_name || other?.name || other?.email);

        return (
          <button
            key={conv.conversation_id}
            onClick={() => onSelect(conv)}
            className={cn(
              'w-full text-left px-4 py-3 hover:bg-muted/50 transition-colors',
              isSelected && 'bg-primary/5 border-r-2 border-r-primary'
            )}
          >
            <div className="flex items-start justify-between gap-2 mb-0.5">
              <div className="flex items-center gap-2 min-w-0">
                {isGroup ? (
                  <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center text-primary shrink-0">
                    <Users className="w-3.5 h-3.5" />
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                    {(other?.full_name || other?.name || other?.email)?.[0]?.toUpperCase() || '?'}
                  </div>
                )}
                <p className={cn('text-sm truncate', unread > 0 ? 'font-bold text-foreground' : 'font-medium text-foreground/80')}>
                  {title}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                {unread > 0 && (
                  <Badge className="bg-primary text-primary-foreground text-[9px] px-1.5 py-0 h-4">{unread}</Badge>
                )}
                <span className="text-[10px] text-muted-foreground">{fmt(latest?.created_date)}</span>
              </div>
            </div>
            <p className={cn('text-xs truncate pl-9', unread > 0 ? 'text-foreground/70' : 'text-muted-foreground')}>
              {latest?.sender_email === currentUserEmail
                ? `You: ${latest?.body || ''}`
                : (isGroup && latest?.sender_name ? `${latest.sender_name.split(' ')[0]}: ` : '') + (latest?.body || '')}
            </p>
          </button>
        );
      })}
    </div>
  );
}