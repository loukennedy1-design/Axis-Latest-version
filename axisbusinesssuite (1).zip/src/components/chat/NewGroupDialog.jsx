import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, X, Check } from 'lucide-react';

export default function NewGroupDialog({ users, currentUserEmail, onClose, onCreate }) {
  const [name, setName] = useState('');
  const [selected, setSelected] = useState([]);
  const [search, setSearch] = useState('');

  const others = useMemo(
    () => users.filter(u => u.email !== currentUserEmail),
    [users, currentUserEmail]
  );

  const filtered = useMemo(
    () => others.filter(u =>
      !search ||
      u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
      u.email?.toLowerCase().includes(search.toLowerCase())
    ),
    [others, search]
  );

  const toggle = (email) => {
    setSelected(prev => prev.includes(email) ? prev.filter(e => e !== email) : [...prev, email]);
  };

  const handleCreate = () => {
    if (selected.length < 2) return;
    onCreate({
      groupName: name.trim() || `${selected.length + 1} members`,
      participants: selected,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md bg-card border border-border rounded-2xl shadow-2xl flex flex-col max-h-[80vh]">
        <div className="flex items-center justify-between px-5 py-4 border-b">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-sm">New Group Chat</h3>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3 border-b">
          <Input
            placeholder="Group name (optional)"
            value={name}
            onChange={e => setName(e.target.value)}
            className="h-9 text-sm"
          />
          {selected.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {selected.map(email => {
                const u = others.find(o => o.email === email);
                return (
                  <span key={email} className="inline-flex items-center gap-1 bg-primary/10 text-primary text-xs px-2 py-1 rounded-full">
                    {u?.full_name || email}
                    <button onClick={() => toggle(email)} className="hover:text-primary/70"><X className="w-3 h-3" /></button>
                  </span>
                );
              })}
            </div>
          )}
          <div className="relative">
            <Input
              placeholder="Search AEs to add..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="h-9 text-sm pl-3"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-border">
          {filtered.map(u => {
            const isSel = selected.includes(u.email);
            return (
              <button
                key={u.email}
                onClick={() => toggle(u.email)}
                className="w-full text-left px-4 py-2.5 hover:bg-muted/50 transition-colors flex items-center gap-2.5"
              >
                <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                  {u.full_name?.[0]?.toUpperCase() || u.email?.[0]?.toUpperCase() || '?'}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium truncate">{u.full_name || u.email}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{u.email}</p>
                </div>
                {isSel && <Check className="w-4 h-4 text-primary shrink-0" />}
              </button>
            );
          })}
          {filtered.length === 0 && (
            <p className="text-xs text-muted-foreground px-4 py-3">No AEs found</p>
          )}
        </div>

        <div className="px-4 py-3 border-t flex justify-end gap-2">
          <Button variant="outline" size="sm" onClick={onClose}>Cancel</Button>
          <Button size="sm" onClick={handleCreate} disabled={selected.length < 2}>
            Create group ({selected.length + 1})
          </Button>
        </div>
      </div>
    </div>
  );
}