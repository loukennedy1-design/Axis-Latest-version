import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useIntegrationHealth } from '@/hooks/useIntegrationHealth';
import { AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';

// Small status dot shown in the sidebar when a critical integration
// (phone or payments) is disconnected or broken. Links to Connections.
export default function IntegrationHealthIndicator({ collapsed }) {
  const health = useIntegrationHealth();
  const [dismissed, setDismissed] = useState(false);

  if (health.loading || dismissed) return null;
  if (!health.criticalBroken.length) return null;

  if (collapsed) {
    return (
      <Link
        to="/settings"
        title={`${health.criticalBroken.length} critical connection(s) need attention`}
        className="mx-auto mb-2 w-7 h-7 rounded-full bg-amber-500/20 border border-amber-500/50 flex items-center justify-center hover:bg-amber-500/30 transition-colors"
      >
        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
      </Link>
    );
  }

  return (
    <Link
      to="/settings"
      onClick={() => setDismissed(true)}
      className={cn(
        "mx-3 mb-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-2.5 py-2",
        "flex items-center gap-2 text-[10px] font-semibold text-amber-300 hover:bg-amber-500/20 transition-colors"
      )}
    >
      <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse shrink-0" />
      <AlertTriangle className="w-3 h-3 shrink-0" />
      <span className="truncate">Connection needs attention</span>
    </Link>
  );
}