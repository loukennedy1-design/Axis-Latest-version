import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Loader2, CheckCircle2, XCircle, ArrowRight, ArrowLeft, SkipForward,
  PartyPopper, X,
} from 'lucide-react';
import { INTEGRATIONS, loadWizardState, saveWizardState, clearWizardState } from '@/lib/integrations';
import { useIntegrationHealth } from '@/hooks/useIntegrationHealth';
import ConnectionDrawer from '@/components/connections/ConnectionDrawer';

// Full-screen, one-step-at-a-time integration wizard.
// Progress persists in localStorage so reopening resumes where you left off.
export default function IntegrationWizard({ open, onClose, onComplete }) {
  const health = useIntegrationHealth(open);
  const [state, setState] = useState(() => loadWizardState());
  const [stepIndex, setStepIndex] = useState(() => loadWizardState().lastStep || 0);
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Persist wizard progress
  useEffect(() => {
    if (!open) return;
    saveWizardState({ ...state, lastStep: stepIndex });
  }, [state, stepIndex, open]);

  const ctx = { oauth: health.oauth, twilioConfig: health.twilioConfig, settings: health.settings };

  // Per-step status: completed/skipped/connected from saved state OR live health
  const stepStatus = (integration) => {
    const saved = state[integration.id];
    const live = integration.status?.(ctx);
    if (live === 'connected') return 'connected';
    if (saved === 'connected') return 'connected';
    if (saved === 'skipped') return 'skipped';
    return 'pending';
  };

  const current = INTEGRATIONS[stepIndex];
  const isLast = stepIndex >= INTEGRATIONS.length - 1;

  const completedCount = INTEGRATIONS.filter(i => {
    const s = stepStatus(i);
    return s === 'connected' || s === 'skipped';
  }).length;

  const allDone = completedCount === INTEGRATIONS.length;

  const markConnected = (id) => {
    setState(s => ({ ...s, [id]: 'connected' }));
    setDrawerOpen(false);
    // auto-advance after a beat
    setTimeout(() => {
      if (!isLast) setStepIndex(i => i + 1);
      else onComplete?.();
    }, 600);
  };

  const handleSkip = () => {
    setState(s => ({ ...s, [current.id]: 'skipped' }));
    if (!isLast) setStepIndex(i => i + 1);
    else onComplete?.();
  };

  const handleNext = () => {
    if (!isLast) setStepIndex(i => i + 1);
    else onComplete?.();
  };

  const handleBack = () => {
    if (stepIndex > 0) setStepIndex(i => i - 1);
  };

  const handleFinish = () => {
    clearWizardState();
    onComplete?.();
  };

  if (!open) return null;

  // Summary screen when all steps visited
  if (allDone && state._finished) {
    return (
      <WizardShell onClose={onClose}>
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="max-w-xl w-full text-center">
            <div className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center mx-auto mb-5">
              <PartyPopper className="w-8 h-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">You’re all set!</h2>
            <p className="text-muted-foreground mb-6 text-sm">
              Here’s a summary of what’s connected. You can manage any of these anytime from <span className="text-primary font-semibold">Settings → Connections</span>.
            </p>
            <div className="grid gap-2 text-left mb-6">
              {INTEGRATIONS.map(i => {
                const st = stepStatus(i);
                const Icon = i.icon;
                return (
                  <div key={i.id} className="flex items-center gap-3 rounded-lg border p-3">
                    <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium flex-1">{i.name}</span>
                    {st === 'connected'
                      ? <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> Connected</span>
                      : <span className="text-xs text-muted-foreground">Skipped</span>}
                  </div>
                );
              })}
            </div>
            <Button onClick={handleFinish} size="lg" className="gap-2 w-full">
              Go to Dashboard <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </WizardShell>
    );
  }

  const status = stepStatus(current);
  const Icon = current.icon;

  return (
    <WizardShell onClose={onClose}>
      {/* Progress bar */}
      <div className="border-b border-border bg-card">
        <div className="max-w-3xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-muted-foreground">
              Step {stepIndex + 1} of {INTEGRATIONS.length}
            </p>
            <p className="text-xs text-muted-foreground">{completedCount} of {INTEGRATIONS.length} done</p>
          </div>
          <div className="h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${(completedCount / INTEGRATIONS.length) * 100}%` }}
            />
          </div>
          {/* Step dots */}
          <div className="flex gap-1.5 mt-3">
            {INTEGRATIONS.map((i, idx) => {
              const st = stepStatus(i);
              return (
                <button
                  key={i.id}
                  onClick={() => setStepIndex(idx)}
                  className={`flex-1 h-7 rounded-md flex items-center justify-center text-[10px] font-semibold transition-all ${
                    idx === stepIndex
                      ? 'bg-primary text-primary-foreground'
                      : st === 'connected'
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : st === 'skipped'
                          ? 'bg-muted text-muted-foreground'
                          : 'bg-muted/50 text-muted-foreground/60 hover:bg-muted'
                  }`}
                  title={i.name}
                >
                  {st === 'connected' ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Step content */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-2xl mx-auto px-6 py-10">
          <div className="text-center mb-8">
            <div className="w-20 h-20 rounded-2xl bg-primary/15 flex items-center justify-center mx-auto mb-5">
              <Icon className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2">{current.name}</h1>
            <p className="text-muted-foreground">{current.tagline}</p>
          </div>

          <Card className="p-6 mb-6 bg-muted/30 border-border">
            <p className="text-sm text-muted-foreground leading-relaxed">{current.why}</p>
          </Card>

          {status === 'connected' ? (
            <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-6 text-center">
              <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-3" />
              <p className="text-lg font-semibold text-emerald-300 mb-1">Connected</p>
              <p className="text-sm text-emerald-200/80 mb-4">{current.name} is working and ready to use.</p>
              <Button variant="outline" size="sm" onClick={() => setDrawerOpen(true)}>
                Manage connection
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <Button size="lg" onClick={() => setDrawerOpen(true)} className="gap-2 w-full max-w-sm">
                {current.category === 'oauth' ? 'Connect' : 'Enter credentials'}
                <ArrowRight className="w-4 h-4" />
              </Button>
              <button
                onClick={handleSkip}
                className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1.5 transition-colors"
              >
                <SkipForward className="w-3.5 h-3.5" /> Skip for now
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Nav footer */}
      <div className="border-t border-border bg-card px-6 py-3 flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={handleBack} disabled={stepIndex === 0} className="gap-1.5">
          <ArrowLeft className="w-4 h-4" /> Back
        </Button>
        <div className="flex gap-2">
          {!isLast && (
            <Button variant="outline" size="sm" onClick={handleNext} className="gap-1.5">
              Next <ArrowRight className="w-4 h-4" />
            </Button>
          )}
          {isLast && (
            <Button size="sm" onClick={() => { setState(s => ({ ...s, _finished: true })); }} className="gap-1.5">
              See summary <ArrowRight className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      <ConnectionDrawer
        integration={current}
        settings={health.settings}
        connected={stepStatus(current) === 'connected'}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        onConnected={() => markConnected(current.id)}
      />
    </WizardShell>
  );
}

function WizardShell({ onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 z-10 w-9 h-9 rounded-lg bg-muted/60 hover:bg-muted flex items-center justify-center transition-colors"
        aria-label="Close wizard"
      >
        <X className="w-5 h-5" />
      </button>
      {children}
    </div>
  );
}