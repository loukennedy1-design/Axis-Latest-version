import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetFooter,
} from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import {
  Loader2, Zap, CheckCircle2, XCircle, Eye, EyeOff, ExternalLink, ShieldCheck,
} from 'lucide-react';

// A single inline error callout, tied to a specific field when possible.
function FieldError({ error }) {
  if (!error) return null;
  return (
    <div className="mt-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
      <div className="flex items-start gap-1.5">
        <XCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-amber-400" />
        <div>
          <p className="font-semibold text-amber-100">Couldn’t connect</p>
          <p className="text-amber-200/90 break-words">{error.message}</p>
          {error.tip && (
            <p className="mt-1 font-semibold text-amber-100">→ {error.tip}</p>
          )}
        </div>
      </div>
    </div>
  );
}

// Saves settings via the existing saveUserSettings backend function.
async function saveSettings(payload) {
  const res = await base44.functions.invoke('saveUserSettings', { action: 'save', data: payload });
  if (res.data?.error) throw new Error(res.data.error);
  return res.data;
}

export default function ConnectionDrawer({ integration, settings, connected, open, onOpenChange, onConnected }) {
  const qc = useQueryClient();
  const [values, setValues] = useState({});
  const [showSecrets, setShowSecrets] = useState({});
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [fieldError, setFieldError] = useState(null);
  const [testResult, setTestResult] = useState(null);

  // Seed form values from loaded settings whenever the integration changes
  useEffect(() => {
    if (!integration) return;
    const seed = {};
    if (integration.fields) {
      for (const f of integration.fields) {
        const v = settings?.[f.key];
        seed[f.key] = v === undefined ? (f.type === 'toggle' ? false : '') : v;
        if (f.type === 'password' && v === '••••••••') seed[f.key] = '••••••••';
        if (f.type === 'toggle' && typeof v !== 'boolean') seed[f.key] = f.key?.endsWith('_ssl') ? true : false;
      }
    }
    setValues(seed);
    setFieldError(null);
    setTestResult(null);
    setShowSecrets({});
  }, [integration, settings]);

  if (!integration) return null;

  const isOAuth = integration.category === 'oauth';
  const Icon = integration.icon;

  const update = (key, val) => {
    setValues(v => ({ ...v, [key]: val }));
    setFieldError(null);
    setTestResult(null);
  };

  // OAuth path: just trigger the connect flow
  const handleOAuthConnect = async () => {
    setSaving(true);
    try {
      await integration.connect();
      // Page will redirect; nothing else to do.
    } catch (e) {
      toast.error('Could not start connection: ' + (e.message || 'unknown error'));
    } finally {
      setSaving(false);
    }
  };

  const handleOAuthDisconnect = async () => {
    setSaving(true);
    try {
      await integration.disconnect();
      toast.success(`${integration.name} disconnected`);
      qc.invalidateQueries({ queryKey: ['integration-health'] });
      onConnected?.();
    } catch (e) {
      toast.error('Disconnect failed: ' + (e.message || 'unknown error'));
    } finally {
      setSaving(false);
    }
  };

  // Manual path: save + test
  const buildPayload = () => {
    const payload = {};
    for (const f of integration.fields) {
      const v = values[f.key];
      if (f.type === 'toggle') payload[f.key] = !!v;
      else payload[f.key] = (v ?? '').trim ? (v ?? '').trim() : v;
    }
    return payload;
  };

  const handleSaveAndTest = async () => {
    setFieldError(null);
    setTestResult(null);
    // 1) Client-side format pre-validation (e.g. Twilio SID/token length)
    if (integration.preValidate) {
      const pre = integration.preValidate(values);
      if (pre) {
        setFieldError({ field: pre.field, message: pre.message });
        return;
      }
    }
    // 2) Persist to SystemSettings
    setSaving(true);
    try {
      await saveSettings(buildPayload());
      qc.invalidateQueries({ queryKey: ['integration-health'] });
      qc.invalidateQueries({ queryKey: ['system-settings'] });
    } catch (e) {
      setFieldError({ message: e.message || 'Could not save your credentials.' });
      setSaving(false);
      return;
    }
    setSaving(false);
    // 3) Hit the real API with the saved credentials
    setTesting(true);
    try {
      const result = await integration.test();
      setTestResult(result);
      if (result.success) {
        qc.invalidateQueries({ queryKey: ['integration-health'] });
        qc.invalidateQueries({ queryKey: ['system-settings'] });
        onConnected?.();
      }
    } catch (e) {
      setTestResult({ success: false, message: e.message || 'Test request failed.' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg overflow-y-auto bg-background border-l-2 border-primary/40">
        <SheetHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
              <Icon className="w-6 h-6 text-primary" />
            </div>
            <div>
              <SheetTitle className="text-lg">{integration.name}</SheetTitle>
              <SheetDescription className="text-xs">{integration.tagline}</SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div className="px-6 py-4 space-y-4">
          {/* Plain-English why */}
          <div className="rounded-lg bg-muted/40 border border-border p-3 text-xs text-muted-foreground leading-relaxed">
            {integration.why}
          </div>

          {isOAuth ? (
            <div className="space-y-4 py-2">
              {connected ? (
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-center">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-emerald-300">Already connected</p>
                  <p className="text-xs text-emerald-200/80 mb-3">Your {integration.name} account is linked.</p>
                  <Button variant="outline" size="sm" onClick={handleOAuthDisconnect} disabled={saving} className="gap-2">
                    {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
                    Disconnect
                  </Button>
                </div>
              ) : (
                <div className="text-center py-4">
                  <p className="text-xs text-muted-foreground mb-4">
                    One click — no keys to copy or paste. You’ll approve access in a popup, then come right back.
                  </p>
                  <Button size="lg" onClick={handleOAuthConnect} disabled={saving} className="gap-2 w-full">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <ExternalLink className="w-4 h-4" />}
                    {integration.oauthLabel || 'Connect'}
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {integration.fields.map(f => {
                const errFor = fieldError?.field === f.key ? fieldError : null;
                return (
                  <div key={f.key} className="space-y-1.5">
                    <Label className="flex items-center gap-1.5 text-xs">
                      {f.label}
                      {f.required && <span className="text-primary">*</span>}
                    </Label>
                    {f.type === 'toggle' ? (
                      <div className="flex items-center gap-2">
                        <Switch checked={!!values[f.key]} onCheckedChange={(v) => update(f.key, v)} />
                        <span className="text-xs text-muted-foreground">{values[f.key] ? 'On' : 'Off'}</span>
                      </div>
                    ) : f.type === 'select' ? (
                      <Select value={values[f.key] || f.options?.[0]?.value} onValueChange={(v) => update(f.key, v)}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {f.options?.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="relative">
                        <Input
                          type={f.type === 'password' && !showSecrets[f.key] ? 'password' : 'text'}
                          value={values[f.key] || ''}
                          onChange={(e) => update(f.key, e.target.value)}
                          placeholder={f.placeholder}
                          className={errFor ? 'border-amber-500/60' : ''}
                        />
                        {f.type === 'password' && (
                          <button
                            type="button"
                            onClick={() => setShowSecrets(s => ({ ...s, [f.key]: !s[f.key] }))}
                            className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                          >
                            {showSecrets[f.key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </button>
                        )}
                      </div>
                    )}
                    {f.hint && !errFor && (
                      <p className="text-[11px] text-muted-foreground leading-snug">{f.hint}</p>
                    )}
                    <FieldError error={errFor || (fieldError && !fieldError.field ? fieldError : null)} />
                  </div>
                );
              })}

              {/* Global (non-field) error */}
              {fieldError && !fieldError.field && (
                <FieldError error={fieldError} />
              )}

              {/* Test result */}
              {testResult && (
                <div className={`flex items-start gap-2 rounded-lg p-3 text-xs border ${
                  testResult.success
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-amber-500/10 border-amber-500/40 text-amber-200'
                }`}>
                  {testResult.success
                    ? <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
                    : <XCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />}
                  <div>
                    <p className="font-semibold mb-0.5">{testResult.success ? 'Connection successful' : 'Connection failed'}</p>
                    <p className="opacity-90 break-words">{testResult.message}</p>
                    {!testResult.success && (
                      <p className="mt-1 font-semibold">→ Fix the field above, then test again.</p>
                    )}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 pt-1">
                <Button size="sm" onClick={handleSaveAndTest} disabled={saving || testing} className="gap-1.5">
                  {saving || testing
                    ? <Loader2 className="w-4 h-4 animate-spin" />
                    : <Zap className="w-4 h-4" />}
                  {testing ? 'Testing…' : 'Save & Test Connection'}
                </Button>
                <p className="text-[10px] text-muted-foreground flex items-center gap-1 ml-auto">
                  <ShieldCheck className="w-3 h-3 text-primary" /> Encrypted & stored securely
                </p>
              </div>
            </div>
          )}
        </div>

        <SheetFooter className="px-6 pb-6">
          <p className="text-[11px] text-muted-foreground text-center w-full">
            Need help? Every field has a hint below it with exactly where to find the value.
          </p>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  );
}