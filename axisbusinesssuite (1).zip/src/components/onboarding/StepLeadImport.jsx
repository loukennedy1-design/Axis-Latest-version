import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, Loader2, Upload, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

export default function StepLeadImport({ leadsImported, setLeadsImported }) {
  const [uploading, setUploading] = useState(false);
  const [manual, setManual] = useState({ first_name: '', last_name: '', phone: '', email: '', company: '' });
  const [adding, setAdding] = useState(false);
  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const reader = new FileReader();
      const text = await new Promise((res, rej) => { reader.onload = () => res(reader.result); reader.onerror = () => rej(); reader.readAsText(file); });
      const rows = text.split('\n').map(r => r.trim()).filter(Boolean);
      if (rows.length < 2) { toast.error('CSV must have a header row and at least one lead.'); return; }
      const headers = rows[0].split(',').map(h => h.trim().toLowerCase());
      const leads = rows.slice(1).map(row => {
        const vals = row.split(',').map(v => v.trim());
        const map = {};
        headers.forEach((h, i) => { if (['first_name', 'last_name', 'phone', 'email', 'company'].includes(h)) map[h] = vals[i] || ''; });
        return map;
      }).filter(l => l.phone || l.email);
      if (leads.length === 0) { toast.error('No valid leads found in the CSV.'); return; }
      const res = await base44.functions.invoke('bulkImportLeads', { leads, consent_given: true });
      setLeadsImported(p => p + (res.data.imported || leads.length));
      toast.success(`${res.data.imported || leads.length} leads imported!`);
    } catch (err) {
      toast.error('Import failed: ' + (err.message || ''));
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };
  const addManual = async () => {
    if (!manual.first_name && !manual.last_name && !manual.phone && !manual.email) return;
    setAdding(true);
    try {
      await base44.functions.invoke('bulkImportLeads', { leads: [manual], consent_given: true });
      setLeadsImported(p => p + 1);
      setManual({ first_name: '', last_name: '', phone: '', email: '', company: '' });
      toast.success('Lead added!');
    } catch (err) {
      toast.error('Failed: ' + (err.message || ''));
    } finally {
      setAdding(false);
    }
  };
  return (
    <div className="space-y-5">
      {leadsImported > 0 && (
        <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
          <p className="text-sm font-medium text-emerald-600">{leadsImported} lead{leadsImported > 1 ? 's' : ''} imported successfully!</p>
        </div>
      )}
      <Tabs defaultValue="csv">
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="csv">Upload CSV</TabsTrigger>
          <TabsTrigger value="manual">Add Manually</TabsTrigger>
        </TabsList>
        <TabsContent value="csv">
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">Upload a CSV with columns: first_name, last_name, phone, email, company.</p>
            <label className="cursor-pointer inline-block">
              <div className="border-2 border-dashed border-border hover:border-primary/50 rounded-xl p-8 text-center transition-colors">
                <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm font-medium">{uploading ? 'Uploading...' : 'Click to select CSV'}</p>
                <p className="text-xs text-muted-foreground mt-1">.csv files only</p>
              </div>
              <input type="file" accept=".csv" onChange={handleUpload} className="hidden" disabled={uploading} />
            </label>
          </div>
        </TabsContent>
        <TabsContent value="manual">
          <div className="grid grid-cols-2 gap-3">
            {['first_name', 'last_name', 'phone', 'email', 'company'].map((f, i) => (
              <div key={f} className={i >= 2 && i <= 3 ? '' : 'col-span-2'}>
                <Label className="text-xs font-medium capitalize">{f.replace(/_/g, ' ')}</Label>
                <Input value={manual[f]} onChange={e => setManual(s => ({ ...s, [f]: e.target.value }))} placeholder={`e.g. ${['John', 'Doe', '+15551234567', 'john@co.com', 'Acme'][i]}`} className="mt-0.5" />
              </div>
            ))}
          </div>
          <Button size="sm" onClick={addManual} disabled={adding} className="w-full mt-3 gap-2">
            {adding ? <Loader2 className="w-4 h-4 animate-spin" /> : <UserPlus className="w-4 h-4" />}
            {adding ? 'Adding...' : 'Add Lead'}
          </Button>
        </TabsContent>
      </Tabs>
      <div className="flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~1 min</Badge>
      </div>
    </div>
  );
}