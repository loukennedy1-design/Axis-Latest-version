import React, { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { LayoutDashboard, GraduationCap, Upload } from 'lucide-react';
import confetti from 'canvas-confetti';

export default function StepLaunch() {
  useEffect(() => {
    const end = Date.now() + 1500;
    const interval = setInterval(() => {
      if (Date.now() > end) { clearInterval(interval); return; }
      confetti({ particleCount: 4, spread: 80, origin: { y: 0.6 }, colors: ['#FF0000', '#CC0000', '#FF3333'] });
    }, 50);
    return () => clearInterval(interval);
  }, []);
  return (
    <div className="text-center space-y-7 py-8">
      <div className="text-5xl">🚀</div>
      <div className="space-y-2">
        <h1 className="text-3xl font-bold font-display">Your Platform is Live!</h1>
        <p className="text-muted-foreground">AXIS is fully configured and ready to grow your business.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-xl mx-auto">
        {[
          { icon: LayoutDashboard, label: 'Go to Dashboard', path: '/app', desc: 'Start working' },
          { icon: GraduationCap, label: 'Start Learning Academy', path: '/academy', desc: 'Master AXIS' },
          { icon: Upload, label: 'Import More Leads', path: '/import-wizard', desc: 'Grow your list' },
        ].map((tile, i) => (
          <a key={i} href={tile.path} className="block rounded-xl border border-border p-4 hover:border-primary/40 hover:bg-primary/5 transition-all text-center">
            <div className="w-10 h-10 mx-auto rounded-lg bg-primary/10 flex items-center justify-center mb-2">
              <tile.icon className="w-5 h-5 text-primary" />
            </div>
            <p className="text-sm font-semibold">{tile.label}</p>
            <p className="text-xs text-muted-foreground mt-1">{tile.desc}</p>
          </a>
        ))}
      </div>
      <Button size="lg" className="gap-2 text-base px-8" asChild>
        <a href="/app">Go to Dashboard <LayoutDashboard className="w-4 h-4" /></a>
      </Button>
    </div>
  );
}