import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';

const ALERT_TRIGGERS = [
  { key: 'alert_new_appointment', label: 'New appointment booked' },
  { key: 'alert_call_completed', label: 'Call completed' },
  { key: 'alert_lead_status_change', label: 'Lead status changed' },
  { key: 'alert_payment_received', label: 'Payment received' },
];

export default function StepNotifications({ form, updateField, user }) {
  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <div className="flex items-center justify-between p-3 rounded-lg border border-border">
          <div>
            <p className="text-sm font-medium">Email Notifications</p>
            <p className="text-xs text-muted-foreground">Receive updates via email</p>
          </div>
          <Switch checked={form.email_notifications ?? true} onCheckedChange={v => updateField('email_notifications', v)} />
        </div>
        <div className="flex items-center justify-between p-3 rounded-lg border border-border">
          <div>
            <p className="text-sm font-medium">SMS Notifications</p>
            <p className="text-xs text-muted-foreground">Receive updates via SMS</p>
          </div>
          <Switch checked={form.sms_notifications ?? false} onCheckedChange={v => updateField('sms_notifications', v)} />
        </div>
        <div>
          <Label className="text-sm font-semibold">Notification Email Address</Label>
          <Input value={form.notification_email ?? user?.email ?? ''} onChange={e => updateField('notification_email', e.target.value)} className="mt-1" />
        </div>
      </div>
      <div>
        <Label className="text-sm font-semibold mb-2 block">Alert Triggers</Label>
        <div className="space-y-2">
          {ALERT_TRIGGERS.map(at => (
            <label key={at.key} className="flex items-center gap-3 p-2 rounded-lg border border-border cursor-pointer hover:bg-muted/30 transition-colors">
              <input type="checkbox" className="accent-primary w-4 h-4" checked={form[at.key] ?? true} onChange={e => updateField(at.key, e.target.checked)} />
              <span className="text-sm">{at.label}</span>
            </label>
          ))}
        </div>
      </div>
      <div className="flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~30 sec</Badge>
      </div>
    </div>
  );
}