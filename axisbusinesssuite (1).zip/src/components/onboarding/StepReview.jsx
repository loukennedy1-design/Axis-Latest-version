import React from 'react';
import { Badge } from '@/components/ui/badge';
import { INDUSTRIES } from './StepIndustry';

function Section({ title, editIndex, onEdit, children }) {
  return (
    <div className="p-3 rounded-lg border border-border">
      <div className="flex items-center justify-between mb-2">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</p>
        <button type="button" onClick={() => onEdit(editIndex)} className="text-xs text-primary hover:underline">Edit</button>
      </div>
      {children}
    </div>
  );
}

export default function StepReview({ form, invites, leadsImported, onEdit }) {
  const industry = INDUSTRIES.find(i => i.value === form.industry);
  return (
    <div className="space-y-4">
      <Section title="Business Profile" editIndex={1} onEdit={onEdit}>
        <p className="text-sm">{form.company_name || <span className="text-muted-foreground italic">Not set</span>}</p>
        {form.website && <p className="text-xs text-muted-foreground">{form.website}</p>}
        <p className="text-xs text-muted-foreground">{form.company_size} employees</p>
      </Section>
      <Section title="Industry & Use Case" editIndex={2} onEdit={onEdit}>
        <p className="text-sm">{industry?.icon} {industry?.label || form.industry}</p>
        {form.primary_use_case && <p className="text-xs text-muted-foreground mt-1">{form.primary_use_case}</p>}
      </Section>
      <Section title="AI Call Bot" editIndex={3} onEdit={onEdit}>
        {form.bot_agent_name ? (
          <><p className="text-sm">Bot: <span className="font-semibold text-primary">{form.bot_agent_name}</span></p><p className="text-xs text-muted-foreground">Voice: {form.bot_voice} · Personality: {form.bot_personality_style}</p></>
        ) : (
          <p className="text-sm text-muted-foreground italic">Will use default settings</p>
        )}
      </Section>
      <Section title="Integrations" editIndex={4} onEdit={onEdit}>
        <div className="flex flex-wrap gap-1.5">
          <Badge variant={form.twilio_account_sid ? 'default' : 'outline'} className={form.twilio_account_sid ? 'bg-emerald-600' : 'text-muted-foreground'}>
            Twilio
          </Badge>
          {['zoom_account_id'].map(k =>
            <Badge key={k} variant={form[k] ? 'default' : 'outline'} className={form[k] ? 'bg-primary' : 'text-muted-foreground'}>
              {form[k] ? 'Zoom' : 'Zoom'}
            </Badge>
          )}
          <Badge variant={form.google_calendar_connected ? 'default' : 'outline'} className={form.google_calendar_connected ? 'bg-primary' : 'text-muted-foreground'}>
            {form.google_calendar_connected ? 'Google Calendar' : 'Google Calendar'}
          </Badge>
        </div>
      </Section>
      <Section title="Team Members" editIndex={6} onEdit={onEdit}>
        <p className="text-sm">{invites.length > 0 ? `${invites.length} invite${invites.length > 1 ? 's' : ''} sent` : (<span className="text-muted-foreground italic">Skipped</span>)}</p>
      </Section>
      <Section title="Leads Imported" editIndex={7} onEdit={onEdit}>
        <p className="text-sm">{leadsImported > 0 ? `${leadsImported} lead${leadsImported > 1 ? 's' : ''} imported` : (<span className="text-muted-foreground italic">Skipped</span>)}</p>
      </Section>
    </div>
  );
}