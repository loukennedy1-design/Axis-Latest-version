import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CheckCircle2, Eye, EyeOff, Loader2, Plug } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

function IntegrationCard({ name, icon, color, required, fields, formValues, onValuesChange, onSave }) {
  const [expanded, setExpanded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showSecrets, setShowSecrets] = useState({});
  const connected = required
    ? fields.every(f => (formValues[f.key] || '').trim())
    : fields.some(f => (formValues[f.key] || '').trim());
  const handleSave = async () => {
    setSaving(true);
    try {
      if (onSave) await onSave(formValues);
      setExpanded(false);
    } finally {
      setSaving(false);
    }
  };
  const toggle = (k) => setShowSecrets(s => ({ ...s, [k]: !s[k] }));
  return (
    <div className="rounded-xl border border-border overflow-hidden transition-all hover:shadow-sm hover:border-primary/20">
      <div className={`h-1 w-full ${color}`} />
      <div className="p-4">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-lg">{icon}</span>
            <span className="text-sm font-semibold">{name}</span>
            {required && <span className="text-xs text-primary">Required</span>}
          </div>
          <Badge variant={connected ? 'default' : 'outline'} className={connected ? 'bg-emerald-600' : 'text-muted-foreground'}>
            {connected ? <><CheckCircle2 className="w-3 h-3 mr-1" /> Connected</> : 'Not Connected'}
          </Badge>
        </div>
        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="text-xs text-muted-foreground hover:text-primary transition-colors"
        >
          {expanded ? 'Close' : 'Configure'}
        </button>
        {expanded && (
          <div className="space-y-3 mt-3 pt-3 border-t border-border">
            {fields.map(f => (
              <div key={f.key}>
                <Label className="text-xs font-medium">{f.label}</Label>
                {f.secret ? (
                  <div className="relative mt-1">
                    <Input
                      type={showSecrets[f.key] ? 'text' : 'password'}
                      value={formValues[f.key] || ''}
                      onChange={e => onValuesChange(f.key, e.target.value)}
                      placeholder={f.placeholder}
                      className="pr-9"
                    />
                    <button type="button" onClick={() => toggle(f.key)} className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {showSecrets[f.key] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                ) : (
                  <Input value={formValues[f.key] || ''} onChange={e => onValuesChange(f.key, e.target.value)} placeholder={f.placeholder} className="mt-1" />
                )}
              </div>
            ))}
            <Button size="sm" onClick={handleSave} disabled={saving} className="w-full gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plug className="w-4 h-4" />}
              {saving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function StepIntegrations({ form, updateField, user }) {
  const [local, setLocal] = useState({});
  const reset = (keys) => keys.filter(k => local[k]).forEach(k => setLocal(s => ({ ...s, [k]: undefined })));

  const cards = [
    {
      name: 'Twilio', icon: '📞', color: 'bg-red-600', required: true,
      fields: [
        { key: 'twilio_account_sid', label: 'Account SID', placeholder: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', secret: true },
        { key: 'twilio_auth_token', label: 'Auth Token', placeholder: 'xxxxxxxxxxxxxxxx', secret: true },
        { key: 'twilio_phone_number', label: 'Phone Number', placeholder: '+15551234567', secret: false },
      ],
      formValues: { ...local, twilio_account_sid: local.twilio_account_sid ?? form.twilio_account_sid ?? '', twilio_auth_token: local.twilio_auth_token ?? form.twilio_auth_token ?? '', twilio_phone_number: local.twilio_phone_number ?? form.twilio_phone_number ?? '' },
      onValuesChange: (k, v) => setLocal(s => ({ ...s, [k]: v })),
      onSave: async (vals) => {
        await updateField('twilio_account_sid', vals.twilio_account_sid);
        await updateField('twilio_auth_token', vals.twilio_auth_token);
        await updateField('twilio_phone_number', vals.twilio_phone_number);
        reset(['twilio_account_sid', 'twilio_auth_token', 'twilio_phone_number']);
        toast.success('Twilio saved!');
      },
    },
    {
      name: 'Zoom', icon: '🎥', color: 'bg-blue-600', required: false,
      fields: [
        { key: 'zoom_account_id', label: 'Account ID', placeholder: 'xxxxxxxxxx' },
        { key: 'zoom_client_id', label: 'Client ID', placeholder: 'xxxxxxxxxx', secret: true },
        { key: 'zoom_client_secret', label: 'Client Secret', placeholder: 'xxxxxxxxxx', secret: true },
      ],
      formValues: { ...local, zoom_account_id: local.zoom_account_id ?? form.zoom_account_id ?? '', zoom_client_id: local.zoom_client_id ?? form.zoom_client_id ?? '', zoom_client_secret: local.zoom_client_secret ?? form.zoom_client_secret ?? '' },
      onValuesChange: (k, v) => setLocal(s => ({ ...s, [k]: v })),
      onSave: async (vals) => {
        await updateField('zoom_account_id', vals.zoom_account_id);
        await updateField('zoom_client_id', vals.zoom_client_id);
        await updateField('zoom_client_secret', vals.zoom_client_secret);
        reset(['zoom_account_id', 'zoom_client_id', 'zoom_client_secret']);
        toast.success('Zoom saved!');
      },
    },
    {
      name: 'Google Calendar', icon: '📆', color: 'bg-emerald-600', required: false,
      fields: [{ key: '_gcal', label: '', placeholder: '' }],
      formValues: {},
      onValuesChange: () => {},
      render: () => (
        <Button size="sm" onClick={() => window.open('', '_blank')} className="w-full mt-3">
          Connect Google Calendar
        </Button>
      ),
    },
  ];
  return (
    <div className="space-y-3">
      <p className="text-sm text-muted-foreground">Twilio is required. Zoom and Google Calendar are optional.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {cards.filter(c => c.name !== 'Google Calendar').map((c, i) => (
          <IntegrationCard key={i} {...c} />
        ))}
        <div className="rounded-xl border border-border overflow-hidden">
          <div className="h-1 w-full bg-emerald-600" />
          <div className="p-4">
            <div className="flex items-center justify-between mb-1">
              <span className="flex items-center gap-2"><span className="text-lg">📆</span><span className="text-sm font-semibold">Google Calendar</span></span>
              <Badge variant={form.google_calendar_connected ? 'default' : 'outline'} className={form.google_calendar_connected ? 'bg-emerald-600' : 'text-muted-foreground'}>
                {form.google_calendar_connected ? <><CheckCircle2 className="w-3 h-3 mr-1" /> Connected</> : 'Not Connected'}
              </Badge>
            </div>
            <Button size="sm" className="w-full mt-3" onClick={() => {
              base44.functions.invoke('googleCalendarAuth', { redirect: '/industry-onboarding' }).then(res => {
                const url = res.data.authorization_url;
                if (url) window.open(url, '_blank');
              });
            }}>
              Connect Google Calendar
            </Button>
          </div>
        </div>
      </div>
      <div className="flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~3 min</Badge>
      </div>
    </div>
  );
}