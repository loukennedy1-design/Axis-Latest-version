import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { UserPlus, X, Users } from 'lucide-react';

const ROLES = ['Admin', 'Sales Rep', 'Manager', 'View Only'];

export default function StepTeamMembers({ invites, setInvites }) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('Sales Rep');
  const addInvite = () => {
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return;
    if (invites.find(i => i.email === email.trim().toLowerCase())) return;
    setInvites(p => [...p, { email: email.trim().toLowerCase(), role: role.toLowerCase().replace(/ /g, '_') }]);
    setEmail('');
  };
  const removeInvite = (idx) => setInvites(p => p.filter((_, i) => i !== idx));
  return (
    <div className="space-y-5">
      <div className="space-y-3">
        <div>
          <Label className="text-sm font-semibold">Email Address</Label>
          <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="colleague@company.com" className="mt-1" onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); addInvite(); }}} />
        </div>
        <div className="flex gap-2">
          <Select value={role} onValueChange={setRole} className="flex-1">
            <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {ROLES.map(r => <SelectItem key={r} value={r}>{r}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button onClick={addInvite} disabled={!email.trim()} className="gap-2">
            <UserPlus className="w-4 h-4" /> Add
          </Button>
        </div>
      </div>
      {invites.length > 0 && (
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Pending Invites ({invites.length})</p>
          {invites.map((i, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 rounded-lg border border-border">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm">{i.email}</span>
                <Badge variant="outline" className="text-xs">{i.role}</Badge>
              </div>
              <button type="button" onClick={() => removeInvite(idx)} className="text-muted-foreground hover:text-destructive transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
      <div className="flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~30 sec</Badge>
      </div>
    </div>
  );
}

export const MEMBER_ROLES = ROLES;