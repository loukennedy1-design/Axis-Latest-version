import React from 'react';
import { CheckCircle2, Circle, Lock } from 'lucide-react';

const STEPS = [
  'Welcome',
  'Business Profile',
  'Industry & Use Case',
  'AI Call Bot',
  'Integrations',
  'Notifications',
  'Team Members',
  'First Lead',
  'Review & Confirm',
  'Launch',
];

export default function StepProgress({ currentStep, onStepClick }) {
  return (
    <div className="space-y-1">
      {STEPS.map((label, i) => {
        const isDone = i < currentStep;
        const isCurrent = i === currentStep;
        const canClick = isDone && onStepClick;
        return (
          <div
            key={i}
            className={`flex items-center gap-2 py-1 transition-all ${isCurrent ? 'opacity-100' : isDone ? 'opacity-80' : 'opacity-40'} ${canClick ? 'cursor-pointer hover:opacity-100 hover:translate-x-0.5' : ''}`}
            onClick={canClick ? () => onStepClick(i) : undefined}
          >
            {isDone ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
            ) : (
              <Circle className={`w-4 h-4 shrink-0 ${isCurrent ? 'fill-primary text-primary' : 'text-muted-foreground'}`} />
            )}
            <span className={`text-xs truncate ${isCurrent ? 'font-semibold text-primary' : isDone ? 'text-foreground' : 'text-muted-foreground'}`}>
              {label}
            </span>
            {canClick && (
              <span className="text-[9px] text-primary ml-auto opacity-0 group-hover:opacity-100">Edit</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export { STEPS };