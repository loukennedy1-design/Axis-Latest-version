import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Package } from 'lucide-react';

export default function StepBusinessProfile({ form, updateField }) {
  return (
    <div className="space-y-5">
      <div>
        <Label className="text-sm font-semibold">Company Name <span className="text-primary">*</span></Label>
        <Input
          value={form.company_name}
          onChange={e => updateField('company_name', e.target.value)}
          placeholder="Acme Corporation"
          className="mt-1"
        />
      </div>
      <div className="flex items-center justify-between gap-3 p-3 rounded-lg border border-border bg-muted/20">
        <div className="flex items-center gap-2">
          <Package className="w-4 h-4 text-primary" />
          <div>
            <Label className="text-sm font-semibold cursor-pointer">We sell physical or digital products</Label>
            <p className="text-xs text-muted-foreground">Enables Point of Sale, inventory sync & storefront</p>
          </div>
        </div>
        <Switch checked={!!form.sells_products} onCheckedChange={v => updateField('sells_products', v)} />
      </div>
      <div>
        <Label className="text-sm font-semibold">Website</Label>
        <Input
          value={form.website}
          onChange={e => updateField('website', e.target.value)}
          placeholder="https://example.com"
          className="mt-1"
        />
      </div>
      <div>
        <Label className="text-sm font-semibold">Company Size</Label>
        <Select value={form.company_size} onValueChange={v => updateField('company_size', v)}>
          <SelectTrigger className="mt-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {['1-10', '11-50', '51-200', '201-500', '500+'].map(s => (
              <SelectItem key={s} value={s}>{s} employees</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="pt-2 flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~1 min</Badge>
      </div>
    </div>
  );
}