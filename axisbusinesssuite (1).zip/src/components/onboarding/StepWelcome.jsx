import React from 'react';
import { Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import StepProgress from './StepProgress';

export default function StepWelcome({ onNext }) {
  return (
    <div className="text-center space-y-8 py-8">
      <div className="mx-auto w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center animate-pulse">
        <Rocket className="w-10 h-10 text-primary" />
      </div>
      <div className="space-y-4 max-w-lg mx-auto">
        <h1 className="text-4xl font-bold font-display tracking-tight">Welcome to AXIS</h1>
        <p className="text-muted-foreground text-lg leading-relaxed">
          You're just <span className="text-primary font-semibold">~10 minutes</span> away from launching your fully operational platform.
        </p>
      </div>
      <div className="max-w-xs mx-auto border border-border rounded-xl bg-muted/20 p-4 text-left">
        <p className="text-xs text-muted-foreground font-medium mb-2 uppercase tracking-wider">Your launch roadmap</p>
        <StepProgress currentStep={0} />
      </div>
      <p className="text-xs text-muted-foreground">
        You'll set up your business profile, AI call bot, integrations, and more.
      </p>
      <Button size="lg" className="gap-2 text-base px-12" onClick={onNext}>
        Let's Get Started <Rocket className="w-4 h-4" />
      </Button>
    </div>
  );
}