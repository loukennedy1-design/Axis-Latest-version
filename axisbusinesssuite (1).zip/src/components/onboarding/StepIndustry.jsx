import React from 'react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { INDUSTRIES } from '@/lib/industries';

export { INDUSTRIES };

// Values that are concrete industries (everything except the "Other" catch-all).
const LISTED = INDUSTRIES.filter(i => i.value !== 'other');

export default function StepIndustry({ form, updateField }) {
  // The platform stores any string as the industry, so a previously-saved
  // custom/legacy value is preserved: the dropdown shows "Other / Custom"
  // and the raw value is surfaced in the custom field for editing.
  const isListed = LISTED.some(i => i.value === form.industry);
  const selectValue = !form.industry ? '' : isListed ? form.industry : 'other';
  const showCustom = !!form.industry && !isListed;
  const customValue = isListed ? '' : (form.industry === 'other' ? '' : form.industry);

  const handleSelect = (val) => {
    if (val === 'other') {
      // Keep any existing custom text; just flag that we're in custom mode.
      if (!form.industry || isListed) updateField('industry', 'other');
    } else {
      updateField('industry', val);
    }
  };

  const handleCustom = (e) => {
    // Store the custom industry directly so the system records the real value.
    updateField('industry', e.target.value);
  };

  return (
    <div className="space-y-5">
      <p className="text-sm text-muted-foreground">Select the industry that best fits your business.</p>
      <div className="space-y-2">
        <Label className="text-sm font-semibold">Industry</Label>
        <Select value={selectValue} onValueChange={handleSelect}>
          <SelectTrigger className="h-11"><SelectValue placeholder="Choose an industry..." /></SelectTrigger>
          <SelectContent className="max-h-72">
            {INDUSTRIES.map(ind => (
              <SelectItem key={ind.value} value={ind.value}>
                <span className="mr-2">{ind.icon}</span>{ind.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {showCustom && (
        <div className="space-y-2">
          <Label className="text-sm font-semibold">Your industry</Label>
          <Input
            value={customValue}
            onChange={handleCustom}
            placeholder="e.g. Cannabis Dispensary, Drone Photography, Crypto Mining..."
          />
          <p className="text-[11px] text-muted-foreground">AXIS adapts to any industry — type yours in and we'll configure accordingly.</p>
        </div>
      )}

      <div>
        <Label className="text-sm font-semibold">What will you use AXIS for?</Label>
        <Textarea
          value={form.primary_use_case}
          onChange={e => updateField('primary_use_case', e.target.value)}
          placeholder="e.g., outbound sales, customer support, recruiting, operations management..."
          className="mt-1 h-20"
        />
      </div>
      <div className="flex justify-center pt-1">
        <Badge variant="outline" className="text-muted-foreground">~1 min</Badge>
      </div>
    </div>
  );
}