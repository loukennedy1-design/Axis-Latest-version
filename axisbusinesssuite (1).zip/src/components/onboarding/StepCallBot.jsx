import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

const VOICES = ['Professional', 'Friendly', 'Energetic', 'Calm', 'Assertive', 'Conversational'];
const PERSONALITIES = ['Consultative', 'Challenger', 'Direct Closer', 'Relationship Builder', 'Solution Seller'];
const SPEEDS = ['Slow', 'Normal', 'Fast'];
const TIMEZONES = [
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
  'America/Anchorage', 'Pacific/Honolulu', 'America/Phoenix', 'America/Toronto',
  'Europe/London', 'Europe/Berlin', 'Australia/Sydney', 'Asia/Shanghai',
];

export default function StepCallBot({ form, updateField }) {
  const hh24 = v => v.padStart(2, '0');
  return (
    <div className="space-y-4">
      <div>
        <Label className="text-sm font-semibold">Bot Name</Label>
        <Input value={form.bot_agent_name} onChange={e => updateField('bot_agent_name', e.target.value)} placeholder="e.g. Alex" className="mt-1" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label className="text-sm font-semibold">Bot Voice</Label>
          <Select value={form.bot_voice} onValueChange={v => updateField('bot_voice', v)}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {VOICES.map(v => <SelectItem key={v} value={v.toLowerCase()}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-sm font-semibold">AI Personality</Label>
          <Select value={form.bot_personality_style} onValueChange={v => updateField('bot_personality_style', v)}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {PERSONALITIES.map(p => <SelectItem key={p} value={p.toLowerCase().replace(/ /g, '_')}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label className="text-sm font-semibold">Talking Speed</Label>
        <Select value={form.bot_talking_speed} onValueChange={v => updateField('bot_talking_speed', v)}>
          <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
          <SelectContent>
            {SPEEDS.map(s => <SelectItem key={s} value={s.toLowerCase()}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div>
          <Label className="text-sm font-semibold">Start Hour</Label>
          <Input type="time" value={form.calling_start_hour || ''} onChange={e => updateField('calling_start_hour', e.target.value)} className="mt-1" />
        </div>
        <div>
          <Label className="text-sm font-semibold">End Hour</Label>
          <Input type="time" value={form.calling_end_hour || ''} onChange={e => updateField('calling_end_hour', e.target.value)} className="mt-1" />
        </div>
        <div>
          <Label className="text-sm font-semibold">Timezone</Label>
          <Select value={form.calling_timezone || 'America/New_York'} onValueChange={v => updateField('calling_timezone', v)}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {TIMEZONES.map(t => <SelectItem key={t} value={t}>{t.split('/')[1]}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label className="text-sm font-semibold">Opening Call Script</Label>
        <Textarea value={form.bot_script} onChange={e => updateField('bot_script', e.target.value)} placeholder="e.g., Hi {{name}}, this is Alex from Acme Corp. I'm calling about..." className="mt-1 h-20" />
      </div>
      <div className="flex justify-center">
        <Badge variant="outline" className="text-muted-foreground">~2 min</Badge>
      </div>
    </div>
  );
}