import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Fingerprint, Plus, Search, Ban, RotateCcw, Mic, ShieldCheck, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

export default function BiometricManagementTab() {
  const [voiceprints, setVoiceprints] = useState([]);
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showEnrollForm, setShowEnrollForm] = useState(false);
  const [enrolling, setEnrolling] = useState(false);
  const [enrollForm, setEnrollForm] = useState({ contact_id: '', contact_name: '', transcript: '', consent_given: false });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [prints, leadList] = await Promise.all([
        base44.entities.VoiceBiometric.filter({}, '-enrollment_date', 100),
        base44.entities.Lead.filter({}, '-updated_date', 50)
      ]);
      setVoiceprints(prints);
      setLeads(leadList);
    } catch (err) {
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEnroll = async () => {
    if (!enrollForm.contact_id) {
      toast.error('Please select a contact');
      return;
    }
    if (!enrollForm.transcript.trim()) {
      toast.error('Please enter a voice sample transcript');
      return;
    }
    setEnrolling(true);
    try {
      const lead = leads.find(l => l.id === enrollForm.contact_id);
      const res = await base44.functions.invoke('voiceBiometricsEngine', {
        action: 'enroll',
        payload: {
          contact_id: enrollForm.contact_id,
          lead_id: enrollForm.contact_id,
          contact_name: `${lead?.first_name || ''} ${lead?.last_name || ''}`.trim(),
          contact_email: lead?.email || '',
          transcript: enrollForm.transcript,
          consent_given: enrollForm.consent_given
        }
      });
      if (res.data?.success) {
        toast.success('Voiceprint enrolled successfully');
        setEnrollForm({ contact_id: '', contact_name: '', transcript: '', consent_given: false });
        setShowEnrollForm(false);
        fetchData();
      } else {
        toast.error(res.data?.error || 'Enrollment failed');
      }
    } catch (err) {
      toast.error('Enrollment error');
    } finally {
      setEnrolling(false);
    }
  };

  const handleRevoke = async (id, reason) => {
    try {
      await base44.functions.invoke('voiceBiometricsEngine', {
        action: 'revoke',
        payload: { biometric_id: id, reason: reason || 'Manual revocation' }
      });
      toast.success('Voiceprint revoked');
      fetchData();
    } catch (err) {
      toast.error('Revocation failed');
    }
  };

  const handleReactivate = async (id) => {
    try {
      await base44.functions.invoke('voiceBiometricsEngine', {
        action: 'reactivate',
        payload: { biometric_id: id }
      });
      toast.success('Voiceprint reactivated');
      fetchData();
    } catch (err) {
      toast.error('Reactivation failed');
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Permanently delete this voiceprint? This cannot be undone.')) return;
    try {
      await base44.entities.VoiceBiometric.delete(id);
      toast.success('Voiceprint deleted');
      fetchData();
    } catch (err) {
      toast.error('Delete failed');
    }
  };

  const filtered = voiceprints.filter(v =>
    !search ||
    v.contact_name?.toLowerCase().includes(search.toLowerCase()) ||
    v.contact_email?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <Fingerprint className="w-5 h-5 text-primary" />
          <h3 className="font-semibold">Voice Biometric Management</h3>
          <Badge variant="secondary" className="text-xs">{voiceprints.length} Enrolled</Badge>
        </div>
        <Button onClick={() => setShowEnrollForm(!showEnrollForm)} className="bg-primary hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-1" /> Enroll New Voiceprint
        </Button>
      </div>

      {/* Enrollment Form */}
      {showEnrollForm && (
        <Card className="border-primary/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Mic className="w-4 h-4 text-primary" /> Voice Biometric Enrollment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <Label className="text-xs">Select Contact</Label>
              <select
                className="w-full mt-1 bg-secondary border border-border rounded-md px-3 py-2 text-sm"
                value={enrollForm.contact_id}
                onChange={(e) => setEnrollForm({ ...enrollForm, contact_id: e.target.value })}
              >
                <option value="">-- Select a lead/contact --</option>
                {leads.map(lead => (
                  <option key={lead.id} value={lead.id}>
                    {lead.first_name} {lead.last_name} {lead.email ? `(${lead.email})` : ''}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label className="text-xs">Voice Sample Transcript (natural speech)</Label>
              <Textarea
                className="mt-1"
                rows={3}
                placeholder="Paste or type the caller's natural speech sample for voiceprint extraction..."
                value={enrollForm.transcript}
                onChange={(e) => setEnrollForm({ ...enrollForm, transcript: e.target.value })}
              />
              <p className="text-xs text-muted-foreground mt-1">Raw audio is never stored — only encrypted feature vectors are persisted.</p>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={enrollForm.consent_given}
                onChange={(e) => setEnrollForm({ ...enrollForm, consent_given: e.target.checked })}
                className="rounded"
              />
              Caller has given explicit consent for voice biometric enrollment
            </label>
            <div className="flex gap-2">
              <Button onClick={handleEnroll} disabled={enrolling} className="bg-primary hover:bg-primary/90">
                {enrolling ? 'Enrolling...' : 'Enroll Voiceprint'}
              </Button>
              <Button onClick={() => setShowEnrollForm(false)} variant="outline">Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder="Search voiceprints by name or email..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Voiceprint List */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Fingerprint className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No voiceprints enrolled yet. Click "Enroll New Voiceprint" to get started.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((vp) => (
            <Card key={vp.id} className={!vp.is_active ? 'opacity-60' : ''}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${vp.is_active ? 'bg-primary/10' : 'bg-red-500/10'}`}>
                      <Fingerprint className={`w-5 h-5 ${vp.is_active ? 'text-primary' : 'text-red-500'}`} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{vp.contact_name || 'Unknown'}</p>
                      <p className="text-xs text-muted-foreground">{vp.contact_email || 'No email'}</p>
                    </div>
                  </div>
                  <Badge variant={vp.is_active ? 'default' : 'destructive'} className="text-xs">
                    {vp.is_active ? 'Active' : 'Revoked'}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs mt-3">
                  <div>
                    <span className="text-muted-foreground">Baseline:</span> <span className="font-mono">{vp.confidence_baseline?.toFixed(1)}%</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Verifications:</span> <span className="font-mono">{vp.verification_count || 0}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Consent:</span> <Badge variant={vp.consent_given ? 'default' : 'destructive'} className="text-xs">{vp.consent_given ? 'Yes' : 'No'}</Badge>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Version:</span> <span className="font-mono">{vp.voiceprint_version}</span>
                  </div>
                </div>
                {vp.enrollment_date && (
                  <p className="text-xs text-muted-foreground mt-2">Enrolled: {new Date(vp.enrollment_date).toLocaleDateString()}</p>
                )}
                {vp.revoked_at && (
                  <p className="text-xs text-red-400 mt-1">Revoked: {new Date(vp.revoked_at).toLocaleDateString()} — {vp.revoked_reason}</p>
                )}
                <div className="flex gap-1 mt-3">
                  {vp.is_active ? (
                    <Button onClick={() => handleRevoke(vp.id, prompt('Reason for revocation?') || 'Manual')} variant="outline" size="sm" className="text-xs flex-1">
                      <Ban className="w-3 h-3 mr-1" /> Revoke
                    </Button>
                  ) : (
                    <Button onClick={() => handleReactivate(vp.id)} variant="outline" size="sm" className="text-xs flex-1">
                      <RotateCcw className="w-3 h-3 mr-1" /> Reactivate
                    </Button>
                  )}
                  <Button onClick={() => handleDelete(vp.id)} variant="ghost" size="sm" className="text-xs text-red-400 hover:text-red-300">
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}