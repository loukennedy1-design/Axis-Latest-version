import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, TrendingUp, TrendingDown, Clock, Users, AlertTriangle, Smile, Gauge, Brain, Target } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area, BarChart, Bar } from 'recharts';

export default function AnalyticsDashboardTab() {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [trendData, setTrendData] = useState([]);
  const [recentCalls, setRecentCalls] = useState([]);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const sessions = await base44.entities.VoiceCallSession.filter({}, '-created_date', 50);
      setRecentCalls(sessions);

      const total = sessions.length;
      const identified = sessions.filter(s => s.caller_identified).length;
      const recognitionRate = total > 0 ? Math.round((identified / total) * 100) : 0;
      const avgConfidence = total > 0 ? Math.round(sessions.reduce((sum, s) => sum + (s.confidence_score || 0), 0) / total) : 0;
      const avgSentiment = total > 0 ? Math.round(sessions.reduce((sum, s) => sum + (s.sentiment_score || 0), 0) / total) : 0;
      const avgHumanization = total > 0 ? Math.round(sessions.reduce((sum, s) => sum + (s.humanization_score || 0), 0) / total) : 0;
      const avgIdTime = total > 0 ? Math.round(sessions.reduce((sum, s) => sum + (s.identification_time_ms || 0), 0) / total) : 0;
      const avgDuration = total > 0 ? Math.round(sessions.reduce((sum, s) => sum + (s.duration_seconds || 0), 0) / total) : 0;
      const fraudAlerts = sessions.filter(s => s.fraud_flag).length;
      const verificationTriggers = sessions.filter(s => s.secondary_verification_triggered).length;
      const workflowsCompleted = sessions.filter(s => s.workflow_completed).length;
      const appointmentsSet = sessions.filter(s => s.call_outcome === 'appointment_set').length;

      setMetrics({
        total_calls: total,
        recognition_rate: recognitionRate,
        avg_confidence: avgConfidence,
        avg_sentiment: avgSentiment,
        avg_humanization: avgHumanization,
        avg_identification_ms: avgIdTime,
        avg_duration: avgDuration,
        fraud_alerts: fraudAlerts,
        verification_triggers: verificationTriggers,
        workflow_completion: total > 0 ? Math.round((workflowsCompleted / total) * 100) : 0,
        appointments_set: appointmentsSet,
        unknown_callers: total - identified,
      });

      // Build trend data from last 14 sessions (chronological)
      const chronological = [...sessions].reverse();
      setTrendData(chronological.map((s, i) => ({
        call: `#${i + 1}`,
        confidence: s.confidence_score || 0,
        sentiment: s.sentiment_score || 0,
        humanization: s.humanization_score || 0,
        duration: s.duration_seconds || 0,
      })));
    } catch (err) {
      console.error('Analytics error:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!metrics || metrics.total_calls === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Activity className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">No voice call data yet. Start a call from the Live Command tab to see analytics here.</p>
        </CardContent>
      </Card>
    );
  }

  const statCards = [
    { label: 'Recognition Accuracy', value: `${metrics.recognition_rate}%`, icon: Target, color: 'text-green-400' },
    { label: 'Avg Confidence', value: `${metrics.avg_confidence}%`, icon: Gauge, color: 'text-blue-400' },
    { label: 'Human-likeness', value: `${metrics.avg_humanization}%`, icon: Brain, color: 'text-purple-400' },
    { label: 'Avg Sentiment', value: `${metrics.avg_sentiment}%`, icon: Smile, color: 'text-amber-400' },
    { label: 'Avg ID Time', value: `${(metrics.avg_identification_ms / 1000).toFixed(1)}s`, icon: Clock, color: 'text-cyan-400' },
    { label: 'Avg Duration', value: `${Math.floor(metrics.avg_duration / 60)}m ${metrics.avg_duration % 60}s`, icon: Clock, color: 'text-indigo-400' },
    { label: 'Unknown Callers', value: metrics.unknown_callers, icon: Users, color: 'text-orange-400' },
    { label: 'Verification Triggers', value: metrics.verification_triggers, icon: AlertTriangle, color: 'text-yellow-400' },
    { label: 'Fraud Alerts', value: metrics.fraud_alerts, icon: AlertTriangle, color: 'text-red-400' },
    { label: 'Workflow Completion', value: `${metrics.workflow_completion}%`, icon: TrendingUp, color: 'text-green-400' },
    { label: 'Appointments Set', value: metrics.appointments_set, icon: Target, color: 'text-primary' },
    { label: 'Total Calls', value: metrics.total_calls, icon: Activity, color: 'text-muted-foreground' },
  ];

  return (
    <div className="space-y-4">
      {/* Stat Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {statCards.map((stat, i) => (
          <Card key={i} className="bg-card/50">
            <CardContent className="p-3">
              <div className="flex items-center justify-between mb-1">
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </div>
              <p className="text-xl font-bold">{stat.value}</p>
              <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Trend Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Confidence & Sentiment Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="call" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} domain={[0, 100]} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="confidence" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="sentiment" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="humanization" stroke="#a855f7" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Call Duration Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={trendData}>
                <defs>
                  <linearGradient id="durGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="call" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={11} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: '8px', fontSize: '12px' }} />
                <Area type="monotone" dataKey="duration" stroke="hsl(var(--primary))" strokeWidth={2} fill="url(#durGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Calls Table */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Recent Voice Call Sessions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="pb-2 pr-3">Caller</th>
                  <th className="pb-2 pr-3">Direction</th>
                  <th className="pb-2 pr-3">Identified</th>
                  <th className="pb-2 pr-3">Confidence</th>
                  <th className="pb-2 pr-3">Sentiment</th>
                  <th className="pb-2 pr-3">Outcome</th>
                  <th className="pb-2 pr-3">Duration</th>
                  <th className="pb-2">Fraud</th>
                </tr>
              </thead>
              <tbody>
                {recentCalls.slice(0, 15).map((call) => (
                  <tr key={call.id} className="border-b border-border/50 hover:bg-secondary/30">
                    <td className="py-2 pr-3 font-medium">{call.caller_name || 'Unknown'}</td>
                    <td className="py-2 pr-3"><Badge variant="secondary" className="text-xs">{call.call_direction}</Badge></td>
                    <td className="py-2 pr-3">{call.caller_identified ? '✅' : '❌'}</td>
                    <td className="py-2 pr-3 font-mono text-xs">{call.confidence_score || 0}%</td>
                    <td className="py-2 pr-3 font-mono text-xs">{call.sentiment_score || 0}%</td>
                    <td className="py-2 pr-3"><Badge variant="outline" className="text-xs">{call.call_outcome}</Badge></td>
                    <td className="py-2 pr-3 font-mono text-xs">{call.duration_seconds || 0}s</td>
                    <td className="py-2">{call.fraud_flag ? <AlertTriangle className="w-4 h-4 text-red-500" /> : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}