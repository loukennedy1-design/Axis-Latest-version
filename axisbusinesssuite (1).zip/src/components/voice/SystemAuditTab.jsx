import React, { useEffect, useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShieldCheck, RefreshCw, AlertTriangle, CheckCircle2, XCircle, Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function SystemAuditTab() {
  const [auditData, setAuditData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const logEndRef = useRef(null);

  useEffect(() => {
    fetchAudit();
    const interval = setInterval(() => {
      if (autoRefresh && !running) fetchAudit();
    }, 15000);
    return () => clearInterval(interval);
  }, [autoRefresh, running]);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [auditData?.recent_logs]);

  const fetchAudit = async () => {
    try {
      const res = await base44.functions.invoke('voiceDeploymentAudit', { action: 'get_latest' });
      setAuditData(res.data);
    } catch (err) {
      console.error('Audit fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const runAudit = async () => {
    setRunning(true);
    try {
      const res = await base44.functions.invoke('voiceDeploymentAudit', { action: 'run_full_audit' });
      setAuditData(res.data);
      toast.success('Self-audit completed — all subsystems re-tested');
    } catch (err) {
      toast.error('Audit run failed');
    } finally {
      setRunning(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const overall = auditData?.overall_readiness_score || 0;
  const overallColor = overall >= 90 ? 'text-green-400' : overall >= 70 ? 'text-amber-400' : 'text-red-400';
  const overallBg = overall >= 90 ? 'from-green-500/20 to-green-500/5 border-green-500/30' : overall >= 70 ? 'from-amber-500/20 to-amber-500/5 border-amber-500/30' : 'from-red-500/20 to-red-500/5 border-red-500/30';

  return (
    <div className="space-y-4">
      {/* Informational Banner */}
      <div className="flex items-center gap-2 text-xs text-muted-foreground bg-secondary/30 rounded-lg px-3 py-2">
        <Info className="w-3.5 h-3.5 flex-shrink-0" />
        <span>Deployment Certification Audit runs continuously and is <strong>informational only</strong> — the platform remains fully accessible regardless of audit scores.</span>
      </div>

      {/* Overall Readiness + Controls */}
      <Card className={cn('bg-gradient-to-br border-2', overallBg)}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-6">
              {/* Readiness Ring */}
              <div className="relative w-28 h-28 flex-shrink-0">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="42" fill="none" stroke="hsl(var(--secondary))" strokeWidth="8" />
                  <circle
                    cx="50" cy="50" r="42" fill="none"
                    stroke={overall >= 90 ? '#22c55e' : overall >= 70 ? '#f59e0b' : '#ef4444'}
                    strokeWidth="8" strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 42}`}
                    strokeDashoffset={`${2 * Math.PI * 42 * (1 - overall / 100)}`}
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className={cn('text-3xl font-bold', overallColor)}>{overall}</span>
                  <span className="text-xs text-muted-foreground">Readiness</span>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck className={cn('w-5 h-5', overallColor)} />
                  <h3 className="text-lg font-bold">Platform Readiness Score</h3>
                </div>
                <p className="text-sm text-muted-foreground mb-2">Continuous deployment certification — 14 subsystems monitored</p>
                <div className="flex gap-4 text-sm">
                  <span className="text-green-400">✅ {auditData?.passed || 0} Passed</span>
                  <span className="text-amber-400">⚠️ {auditData?.warnings || 0} Warnings</span>
                  <span className="text-red-400">❌ {auditData?.failed || 0} Failed</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Button onClick={runAudit} disabled={running} className="bg-primary hover:bg-primary/90">
                <RefreshCw className={cn('w-4 h-4 mr-2', running && 'animate-spin')} />
                {running ? 'Running Audit...' : 'Run Full Audit Now'}
              </Button>
              <Button
                onClick={() => setAutoRefresh(!autoRefresh)}
                variant="outline"
                size="sm"
                className="text-xs"
              >
                {autoRefresh ? 'Pause Auto-Refresh' : 'Resume Auto-Refresh'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Subsystem Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {auditData?.subsystems?.map((sub) => {
          const score = sub.score || 0;
          const color = score >= 90 ? 'text-green-400' : score >= 70 ? 'text-amber-400' : 'text-red-400';
          const ringColor = score >= 90 ? '#22c55e' : score >= 70 ? '#f59e0b' : '#ef4444';
          const borderColor = score >= 90 ? 'border-green-500/20' : score >= 70 ? 'border-amber-500/20' : 'border-red-500/20';

          return (
            <Card key={sub.id} className={cn('relative overflow-hidden', borderColor)}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{sub.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{sub.description}</p>
                  </div>
                  {score >= 90 ? <CheckCircle2 className="w-4 h-4 text-green-400 flex-shrink-0" /> :
                   score >= 70 ? <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" /> :
                   <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />}
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative w-12 h-12 flex-shrink-0">
                    <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                      <circle cx="18" cy="18" r="15" fill="none" stroke="hsl(var(--secondary))" strokeWidth="3" />
                      <circle
                        cx="18" cy="18" r="15" fill="none"
                        stroke={ringColor} strokeWidth="3" strokeLinecap="round"
                        strokeDasharray={`${2 * Math.PI * 15}`}
                        strokeDashoffset={`${2 * Math.PI * 15 * (1 - score / 100)}`}
                        className="transition-all duration-700"
                      />
                    </svg>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className={cn('text-sm font-bold', color)}>{score}</span>
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <Badge variant={score >= 90 ? 'default' : score >= 70 ? 'secondary' : 'destructive'} className="text-xs">
                      {sub.status}
                    </Badge>
                    {sub.remediation_attempted && (
                      <p className="text-xs text-amber-400 mt-1 line-clamp-2">🔧 Remediated</p>
                    )}
                    {sub.error_detail && (
                      <p className="text-xs text-red-400 mt-1 line-clamp-2">{sub.error_detail}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Live Audit Log */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <RefreshCw className={cn('w-4 h-4 text-primary', autoRefresh && 'animate-spin')} />
            Live Audit Log
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 overflow-y-auto space-y-1.5 font-mono text-xs pr-2">
            {(!auditData?.recent_logs || auditData.recent_logs.length === 0) && (
              <p className="text-muted-foreground text-center py-8">No audit logs yet. Run an audit to generate entries.</p>
            )}
            {auditData?.recent_logs?.map((log, i) => (
              <div key={i} className="flex items-start gap-2 py-1 border-b border-border/30">
                <span className="text-muted-foreground flex-shrink-0">{new Date(log.tested_at).toLocaleTimeString()}</span>
                <span className={cn(
                  'flex-shrink-0',
                  log.score >= 90 ? 'text-green-400' : log.score >= 70 ? 'text-amber-400' : 'text-red-400'
                )}>[{log.score}]</span>
                <span className="text-muted-foreground flex-shrink-0">{log.subsystem}:</span>
                <span className="truncate">{log.test_name} — {log.status}</span>
                {log.remediation_attempted && <span className="text-amber-400 flex-shrink-0">🔧</span>}
              </div>
            ))}
            <div ref={logEndRef} />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}