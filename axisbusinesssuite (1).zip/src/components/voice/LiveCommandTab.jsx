import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Phone, PhoneOff, UserCheck, AlertTriangle, Zap, Activity, Volume2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export default function LiveCommandTab() {
  const [callActive, setCallActive] = useState(false);
  const [callDirection, setCallDirection] = useState('inbound');
  const [transcript, setTranscript] = useState([]);
  const [callerInfo, setCallerInfo] = useState(null);
  const [kcirStatus, setKcirStatus] = useState('idle');
  const [sentiment, setSentiment] = useState(null);
  const [crmContext, setCrmContext] = useState(null);
  const [workflowStatus, setWorkflowStatus] = useState('idle');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [voiceSupported, setVoiceSupported] = useState(false);

  const recognitionRef = useRef(null);
  const transcriptEndRef = useRef(null);
  const durationTimerRef = useRef(null);

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const synth = window.speechSynthesis;
    setVoiceSupported(!!SR && !!synth);

    if (SR) {
      const recognition = new SR();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onresult = (event) => {
        let finalText = '';
        let interimText = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) finalText += transcript;
          else interimText += transcript;
        }
        if (finalText) {
          setTranscript(prev => [...prev, { role: 'caller', text: finalText, timestamp: new Date().toISOString() }]);
          handleCallerInput(finalText);
        }
      };

      recognition.onerror = (event) => {
        if (event.error !== 'no-speech' && event.error !== 'aborted') {
          toast.error(`Speech recognition error: ${event.error}`);
        }
      };

      recognition.onend = () => {
        if (callActive && isListening) {
          try { recognition.start(); } catch(e) {}
        }
      };

      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    };
  }, []);

  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcript]);

  useEffect(() => {
    if (callActive) {
      durationTimerRef.current = setInterval(() => setCallDuration(d => d + 1), 1000);
    } else {
      clearInterval(durationTimerRef.current);
      setCallDuration(0);
    }
    return () => clearInterval(durationTimerRef.current);
  }, [callActive]);

  const speakResponse = useCallback((text) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(true);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  }, []);

  const handleCallerInput = useCallback(async (text) => {
    // Run conversation engine to generate AI response
    try {
      const fullTranscript = [...transcript, { role: 'caller', text }].map(m => `${m.role}: ${m.text}`).join('\n');
      const res = await base44.functions.invoke('voiceConversationEngine', {
        action: 'conduct_conversation',
        payload: {
          transcript: fullTranscript,
          caller_context: crmContext,
          voice: 'professional',
          personality: 'consultative',
          talking_speed: 'normal',
          objection_style: 'acknowledge_pivot',
          empathy: 'medium'
        }
      });

      const aiResponse = res.data?.ai_response;
      if (aiResponse) {
        setTranscript(prev => [...prev, { role: 'ai', text: aiResponse, timestamp: new Date().toISOString() }]);
        setSentiment({
          emotion: res.data?.detected_emotion,
          intent: res.data?.detected_intent,
          urgency: res.data?.detected_urgency_level,
          objection: res.data?.objection_detected,
          objectionType: res.data?.objection_type,
        });
        if (res.data?.next_action === 'finalize') {
          setWorkflowStatus('completing');
        }
        speakResponse(aiResponse);
      }
    } catch (err) {
      console.error('Conversation engine error:', err);
    }
  }, [transcript, crmContext, speakResponse]);

  const startCall = async (direction) => {
    setCallDirection(direction);
    setCallActive(true);
    setKcirStatus('listening');
    setTranscript([]);
    setCallerInfo(null);
    setCrmContext(null);
    setSentiment(null);
    setWorkflowStatus('idle');

    // Start listening
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
        setIsListening(true);
      } catch(e) {}
    }

    // Simulate KCIR: after caller speaks a phrase, run voice biometrics
    toast.info(`${direction === 'inbound' ? 'Inbound' : 'Outbound'} call connected — KCIR listening for voice sample...`);

    // For outbound, try to pre-load contact if we have a number
    if (direction === 'outbound') {
      setKcirStatus('pre_loading');
      // Wait for first speech input to trigger KCIR
    }
  };

  const runKCIR = async (sampleText) => {
    setKcirStatus('analyzing');
    try {
      const verifyRes = await base44.functions.invoke('voiceBiometricsEngine', {
        action: 'verify',
        payload: { transcript: sampleText, threshold: 75 }
      });

      if (verifyRes.data?.identified) {
        setKcirStatus('identified');
        setCallerInfo({
          name: verifyRes.data.contact_name,
          contact_id: verifyRes.data.contact_id,
          lead_id: verifyRes.data.lead_id,
          confidence: verifyRes.data.confidence_score,
          fraud_flag: verifyRes.data.fraud_flag
        });

        // Load full CRM context
        const ctxRes = await base44.functions.invoke('knownCallerRecognitionEngine', {
          contact_id: verifyRes.data.contact_id,
          lead_id: verifyRes.data.lead_id
        });

        if (ctxRes.data?.identified) {
          setCrmContext(ctxRes.data.context);
          setKcirStatus('context_loaded');

          // Speak greeting
          const greeting = ctxRes.data.greeting?.greeting;
          if (greeting) {
            setTranscript(prev => [...prev, { role: 'ai', text: greeting, timestamp: new Date().toISOString(), isGreeting: true }]);
            speakResponse(greeting);
          }
        }
      } else {
        setKcirStatus('unknown');
        setCallerInfo({ name: 'Unknown Caller', confidence: verifyRes.data?.confidence_score || 0 });
        // Trigger secondary verification
        const greeting = "Hello, thanks for calling AXIS. I'm your AI assistant. Could you please verify your identity — what's the email or phone number associated with your account?";
        setTranscript(prev => [...prev, { role: 'ai', text: greeting, timestamp: new Date().toISOString(), isGreeting: true }]);
        speakResponse(greeting);
      }
    } catch (err) {
      toast.error('KCIR engine error');
      setKcirStatus('error');
    }
  };

  // Auto-trigger KCIR on first caller speech
  useEffect(() => {
    if (callActive && kcirStatus === 'listening' && transcript.filter(m => m.role === 'caller').length === 1) {
      const firstSpeech = transcript.find(m => m.role === 'caller');
      if (firstSpeech) runKCIR(firstSpeech.text);
    }
    if (callActive && kcirStatus === 'pre_loading' && transcript.filter(m => m.role === 'caller').length >= 1) {
      runKCIR(transcript.find(m => m.role === 'caller').text);
    }
  }, [transcript, callActive, kcirStatus]);

  const endCall = async () => {
    setCallActive(false);
    setIsListening(false);
    if (recognitionRef.current) recognitionRef.current.stop();
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setWorkflowStatus('syncing');

    // Analyze sentiment
    const fullTranscript = transcript.map(m => `${m.role}: ${m.text}`).join('\n');
    let callOutcome = 'completed';
    if (sentiment?.objection) callOutcome = 'not_interested';
    if (sentiment?.urgency === 'high') callOutcome = 'callback_requested';

    try {
      // Create voice call session record
      const session = await base44.entities.VoiceCallSession.create({
        session_id: `VCS-${Date.now()}`,
        call_direction: callDirection,
        phone_number: callerInfo?.phone || '',
        caller_identified: kcirStatus === 'identified' || kcirStatus === 'context_loaded',
        contact_id: callerInfo?.contact_id || '',
        lead_id: callerInfo?.lead_id || '',
        caller_name: callerInfo?.name || 'Unknown',
        confidence_score: callerInfo?.confidence || 0,
        secondary_verification_triggered: kcirStatus === 'unknown',
        greeting_used: transcript.find(m => m.isGreeting)?.text || '',
        conversation_transcript: fullTranscript,
        call_summary: sentiment ? `${sentiment.emotion} - ${sentiment.intent}` : '',
        sentiment_score: 75,
        humanization_score: 80,
        workflow_completed: true,
        crm_synced: false,
        call_outcome: callOutcome,
        fraud_flag: callerInfo?.fraud_flag || false,
        duration_seconds: callDuration,
        status: 'completed',
        started_at: new Date(Date.now() - callDuration * 1000).toISOString(),
        ended_at: new Date().toISOString()
      });

      // Finalize — sync to CRM
      await base44.functions.invoke('voiceConversationEngine', {
        action: 'finalize_call',
        payload: { session: { ...session, id: session.id } }
      });

      setWorkflowStatus('completed');
      toast.success('Call completed and synced to CRM');
    } catch (err) {
      toast.error('Error finalizing call');
      setWorkflowStatus('error');
    }
  };

  const formatDuration = (s) => `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;

  return (
    <div className="space-y-4">
      {/* Call Controls */}
      {!callActive ? (
        <Card className="border-primary/30 bg-gradient-to-br from-card to-card/50">
          <CardContent className="p-8">
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center">
                <Phone className="w-10 h-10 text-primary" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Voice Intelligence Standby</h3>
                <p className="text-sm text-muted-foreground mt-1">Start an inbound or outbound call to engage the AI Voice Intelligence Platform</p>
              </div>
              <div className="flex gap-3">
                <Button onClick={() => startCall('inbound')} className="bg-primary hover:bg-primary/90">
                  <Phone className="w-4 h-4 mr-2" /> Simulate Inbound Call
                </Button>
                <Button onClick={() => startCall('outbound')} variant="outline" className="border-primary/40">
                  <Phone className="w-4 h-4 mr-2" /> Start Outbound Call
                </Button>
              </div>
              {!voiceSupported && (
                <Badge variant="destructive" className="text-xs">
                  <AlertTriangle className="w-3 h-3 mr-1" /> Web Speech API not detected in this browser
                </Badge>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Active Call Header */}
          <Card className="border-primary/30 bg-gradient-to-r from-primary/5 to-transparent">
            <CardContent className="p-4">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                      <Phone className="w-6 h-6 text-primary" />
                    </div>
                    <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-green-500 border-2 border-card animate-pulse" />
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{callDirection === 'inbound' ? 'Inbound Call' : 'Outbound Call'} — Active</p>
                    <p className="text-xs text-muted-foreground font-mono">{formatDuration(callDuration)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={isListening ? 'default' : 'secondary'} className="text-xs">
                    <Mic className={cn('w-3 h-3 mr-1', isListening && 'animate-pulse')} /> {isListening ? 'Listening' : 'Muted'}
                  </Badge>
                  {isSpeaking && (
                    <Badge variant="default" className="text-xs bg-amber-500">
                      <Volume2 className="w-3 h-3 mr-1 animate-pulse" /> Speaking
                    </Badge>
                  )}
                  <Button onClick={endCall} variant="destructive" size="sm">
                    <PhoneOff className="w-4 h-4 mr-1" /> End Call
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Caller Identity + KCIR */}
            <Card className="lg:col-span-1">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-primary" /> Caller Identity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <KCIRStatusBadge status={kcirStatus} />
                {callerInfo && (
                  <div className="space-y-2">
                    <div className="p-3 rounded-lg bg-secondary/50">
                      <p className="font-semibold text-sm">{callerInfo.name}</p>
                      {callerInfo.confidence > 0 && (
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex-1 h-1.5 bg-secondary rounded-full overflow-hidden">
                            <div className={cn('h-full rounded-full', callerInfo.confidence >= 90 ? 'bg-green-500' : callerInfo.confidence >= 70 ? 'bg-amber-500' : 'bg-red-500')} style={{ width: `${callerInfo.confidence}%` }} />
                          </div>
                          <span className="text-xs font-mono text-muted-foreground">{callerInfo.confidence}%</span>
                        </div>
                      )}
                    </div>
                    {callerInfo.fraud_flag && (
                      <Badge variant="destructive" className="text-xs w-full justify-center">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Fraud Alert
                      </Badge>
                    )}
                  </div>
                )}
                {sentiment && (
                  <div className="space-y-1.5 pt-2 border-t border-border">
                    <p className="text-xs font-semibold text-muted-foreground">Live Sentiment</p>
                    <div className="flex flex-wrap gap-1.5">
                      <Badge variant="secondary" className="text-xs">Emotion: {sentiment.emotion}</Badge>
                      <Badge variant="secondary" className="text-xs">Intent: {sentiment.intent}</Badge>
                      <Badge variant={sentiment.urgency === 'high' ? 'destructive' : 'secondary'} className="text-xs">Urgency: {sentiment.urgency}</Badge>
                      {sentiment.objection && <Badge variant="destructive" className="text-xs">Objection: {sentiment.objectionType}</Badge>}
                    </div>
                  </div>
                )}
                {workflowStatus !== 'idle' && (
                  <div className="pt-2 border-t border-border">
                    <Badge variant={workflowStatus === 'completed' ? 'default' : 'secondary'} className="text-xs w-full justify-center">
                      <Activity className="w-3 h-3 mr-1" /> Workflow: {workflowStatus}
                    </Badge>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Transcript */}
            <Card className="lg:col-span-2">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Mic className="w-4 h-4 text-primary" /> Live Transcript
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-96 overflow-y-auto space-y-3 pr-2">
                  {transcript.length === 0 && (
                    <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                      {isListening ? 'Listening for caller speech...' : 'Waiting for call to start...'}
                    </div>
                  )}
                  {transcript.map((msg, i) => (
                    <div key={i} className={cn('flex', msg.role === 'caller' ? 'justify-end' : 'justify-start')}>
                      <div className={cn(
                        'max-w-[80%] rounded-lg px-3 py-2 text-sm',
                        msg.role === 'caller'
                          ? 'bg-primary text-primary-foreground'
                          : msg.isGreeting ? 'bg-amber-500/20 border border-amber-500/30' : 'bg-secondary'
                      )}>
                        <p className="text-xs opacity-60 mb-0.5">{msg.role === 'caller' ? 'Caller' : 'AI Assistant'}{msg.isGreeting && ' • Greeting'}</p>
                        <p>{msg.text}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={transcriptEndRef} />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* CRM Context Panel */}
          {crmContext && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Zap className="w-4 h-4 text-primary" /> CRM Context Loaded
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                  <div><span className="text-muted-foreground text-xs">Status:</span> <Badge variant="secondary" className="text-xs">{crmContext.lead?.status}</Badge></div>
                  <div><span className="text-muted-foreground text-xs">Company:</span> {crmContext.lead?.company || 'N/A'}</div>
                  <div><span className="text-muted-foreground text-xs">Appointments:</span> {crmContext.appointments?.length || 0}</div>
                  <div><span className="text-muted-foreground text-xs">Tasks:</span> {crmContext.tasks?.length || 0}</div>
                  <div><span className="text-muted-foreground text-xs">Past Calls:</span> {crmContext.recent_calls?.length || 0}</div>
                  <div><span className="text-muted-foreground text-xs">Messages:</span> {crmContext.messages?.length || 0}</div>
                  <div><span className="text-muted-foreground text-xs">Consent:</span> <Badge variant={crmContext.lead?.consent_given ? 'default' : 'destructive'} className="text-xs">{crmContext.lead?.consent_given ? 'Yes' : 'No'}</Badge></div>
                  <div><span className="text-muted-foreground text-xs">Call Attempts:</span> {crmContext.lead?.call_attempts || 0}</div>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

function KCIRStatusBadge({ status }) {
  const config = {
    idle: { label: 'Idle', color: 'bg-secondary text-muted-foreground' },
    listening: { label: 'Listening for Voice Sample', color: 'bg-blue-500/20 text-blue-400' },
    pre_loading: { label: 'Pre-loading Contact', color: 'bg-blue-500/20 text-blue-400' },
    analyzing: { label: 'Analyzing Voiceprint...', color: 'bg-amber-500/20 text-amber-400' },
    identified: { label: 'Caller Identified', color: 'bg-green-500/20 text-green-400' },
    context_loaded: { label: 'Full Context Loaded', color: 'bg-green-500/20 text-green-400' },
    unknown: { label: 'Unknown Caller — Verification Needed', color: 'bg-amber-500/20 text-amber-400' },
    error: { label: 'Engine Error', color: 'bg-red-500/20 text-red-400' },
  };
  const c = config[status] || config.idle;
  return <Badge className={cn('text-xs w-full justify-center', c.color)}>{c.label}</Badge>;
}