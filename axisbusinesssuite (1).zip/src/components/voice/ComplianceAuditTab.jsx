import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollText, Search, ShieldAlert, FileCheck } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ComplianceAuditTab() {
  const [auditLogs, setAuditLogs] = useState([]);
  const [complianceLogs, setComplianceLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState('audit');

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const [audit, compliance] = await Promise.all([
        base44.entities.VoiceAuditLog.filter({}, '-tested_at', 100),
        base44.entities.ComplianceLog.filter({}, '-created_date', 100)
      ]);
      setAuditLogs(audit);
      setComplianceLogs(compliance);
    } catch (err) {
      console.error('Fetch error:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredAudit = auditLogs.filter(l =>
    !search ||
    l.subsystem?.toLowerCase().includes(search.toLowerCase()) ||
    l.test_name?.toLowerCase().includes(search.toLowerCase())
  );

  const filteredCompliance = complianceLogs.filter(l =>
    !search ||
    l.description?.toLowerCase().includes(search.toLowerCase()) ||
    l.event_type?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Tab Switcher */}
      <div className="flex gap-2">
        <button
          onClick={() => setActiveTab('audit')}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors',
            activeTab === 'audit' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
          )}
        >
          <ScrollText className="w-4 h-4" /> Audit Logs ({auditLogs.length})
        </button>
        <button
          onClick={() => setActiveTab('compliance')}
          className={cn(
            'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors',
            activeTab === 'compliance' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
          )}
        >
          <ShieldAlert className="w-4 h-4" /> Compliance Logs ({complianceLogs.length})
        </button>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          className="pl-9"
          placeholder={activeTab === 'audit' ? 'Search audit logs...' : 'Search compliance logs...'}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Audit Logs */}
      {activeTab === 'audit' && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Voice Intelligence Audit Trail</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
              {filteredAudit.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No audit logs found.</p>
              ) : (
                filteredAudit.map((log, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-border/50 text-sm">
                    <div className={cn(
                      'w-2 h-2 rounded-full mt-2 flex-shrink-0',
                      log.score >= 90 ? 'bg-green-500' : log.score >= 70 ? 'bg-amber-500' : 'bg-red-500'
                    )} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-xs">{log.subsystem}</span>
                        <Badge variant={log.status === 'pass' ? 'default' : log.status === 'warning' ? 'secondary' : 'destructive'} className="text-xs">
                          {log.score}
                        </Badge>
                        {log.remediation_attempted && <Badge variant="outline" className="text-xs">🔧 Remediated</Badge>}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{log.test_name}</p>
                      {log.error_detail && <p className="text-xs text-red-400 mt-0.5">{log.error_detail}</p>}
                      {log.remediation_result && <p className="text-xs text-amber-400 mt-0.5">{log.remediation_result}</p>}
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0 font-mono">
                      {new Date(log.tested_at).toLocaleString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Compliance Logs */}
      {activeTab === 'compliance' && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Compliance & Consent Audit Trail</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-[600px] overflow-y-auto pr-2">
              {filteredCompliance.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No compliance logs found.</p>
              ) : (
                filteredCompliance.map((log, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-border/50 text-sm">
                    <div className={cn(
                      'w-2 h-2 rounded-full mt-2 flex-shrink-0',
                      log.severity === 'critical' ? 'bg-red-500' :
                      log.severity === 'high' ? 'bg-orange-500' :
                      log.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                    )} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge variant="outline" className="text-xs">{log.event_type}</Badge>
                        <Badge variant={log.severity === 'critical' || log.severity === 'high' ? 'destructive' : 'secondary'} className="text-xs">
                          {log.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{log.description}</p>
                      {log.phone_number && <p className="text-xs text-muted-foreground mt-0.5">📞 {log.phone_number}</p>}
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0 font-mono">
                      {new Date(log.created_date).toLocaleString()}
                    </span>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}