import React from 'react';
import { Package, DollarSign, AlertTriangle, ShoppingCart, Factory, Truck, MapPin, CheckCircle2, Clock } from 'lucide-react';

export default function OpsKpiBar({ items, purchaseOrders, productionTickets, shipments, orders }) {
  const stockValue = items.reduce((s, i) => s + (i.quantity_on_hand || 0) * (i.unit_cost || 0), 0);
  const lowStock = items.filter(i => (i.quantity_on_hand || 0) <= (i.reorder_threshold || 0) && i.status !== 'discontinued').length;
  const openPOs = purchaseOrders.filter(po => po.status === 'draft' || po.status === 'sent').length;
  const inProduction = productionTickets.filter(t => t.current_stage !== 'delivered').reduce((s, t) => s + (t.quantity || 0), 0);
  const inTransit = shipments.filter(s => s.status === 'in_transit' || s.status === 'out_for_delivery').length;
  const fulfilledThisMonth = shipments.filter(s => {
    if (s.status !== 'delivered' || !s.actual_delivery) return false;
    const d = new Date(s.actual_delivery);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }).length;
  const onTimeRate = (() => {
    const delivered = shipments.filter(s => s.status === 'delivered' && s.estimated_delivery && s.actual_delivery);
    if (delivered.length === 0) return 0;
    const onTime = delivered.filter(s => new Date(s.actual_delivery) <= new Date(s.estimated_delivery)).length;
    return Math.round((onTime / delivered.length) * 100);
  })();
  const fulfillmentBacklog = orders.filter(o => o.status !== 'delivered' && o.status !== 'completed' && o.status !== 'cancelled').length;

  const chips = [
    { label: 'Stock Value', value: `$${stockValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`, icon: DollarSign, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'Low Stock', value: lowStock, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10', alert: lowStock > 0 },
    { label: 'Open POs', value: openPOs, icon: ShoppingCart, color: 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'In Production', value: inProduction, icon: Factory, color: 'text-purple-400', bg: 'bg-purple-500/10' },
    { label: 'In Transit', value: inTransit, icon: Truck, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Delivered (Mo)', value: fulfilledThisMonth, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'On-Time Rate', value: `${onTimeRate}%`, icon: Clock, color: onTimeRate >= 90 ? 'text-emerald-400' : 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'Fulfillment Backlog', value: fulfillmentBacklog, icon: MapPin, color: fulfillmentBacklog > 0 ? 'text-orange-400' : 'text-emerald-400', bg: 'bg-orange-500/10' },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {chips.map((chip, idx) => {
        const Icon = chip.icon;
        return (
          <div
            key={idx}
            className={`rounded-xl border bg-card p-3 flex items-center gap-3 ${chip.alert ? 'border-red-500/30 bg-red-500/5' : 'border-border'}`}
          >
            <div className={`w-9 h-9 rounded-lg ${chip.bg} flex items-center justify-center shrink-0`}>
              <Icon className={`w-4 h-4 ${chip.color}`} />
            </div>
            <div className="min-w-0">
              <p className="text-[10px] uppercase tracking-wide text-muted-foreground truncate">{chip.label}</p>
              <p className="text-lg font-bold leading-tight">{chip.value}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}