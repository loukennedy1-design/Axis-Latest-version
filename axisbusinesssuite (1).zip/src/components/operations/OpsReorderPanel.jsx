import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Loader2, Zap, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function OpsReorderPanel({ items, purchaseOrders }) {
  const qc = useQueryClient();
  const [running, setRunning] = useState(false);

  const openPOSkus = new Set(
    (purchaseOrders || [])
      .filter(po => po.status === 'draft' || po.status === 'sent')
      .map(po => po.item_sku)
      .filter(Boolean)
  );

  const candidates = (items || [])
    .filter(i => (i.quantity_on_hand || 0) <= (i.reorder_threshold || 0) && i.status !== 'discontinued' && !openPOSkus.has(i.sku))
    .map(i => {
      const isZero = (i.quantity_on_hand || 0) === 0;
      const suggestedQty = isZero ? (i.reorder_point || 1) : Math.max((i.reorder_point || 0) - (i.quantity_on_hand || 0), 1);
      return {
        ...i,
        is_zero: isZero,
        suggested_qty: suggestedQty,
        suggested_cost: suggestedQty * (i.unit_cost || 0)
      };
    })
    .sort((a, b) => Number(b.is_zero) - Number(a.is_zero) || a.suggested_cost - b.suggested_cost);

  const totalSpend = candidates.reduce((s, c) => s + c.suggested_cost, 0);
  const zeroCount = candidates.filter(c => c.is_zero).length;

  const handleAutoReorder = async () => {
    setRunning(true);
    try {
      const res = await base44.functions.invoke('operationsReorderEngine', { dry_run: false });
      const data = res.data || res;
      const parts = [];
      if (data.placed_count) parts.push(`${data.placed_count} PO(s) auto-placed`);
      if (data.tickets_created) parts.push(`${data.tickets_created} production ticket(s) opened`);
      if (data.drafted_count) parts.push(`${data.drafted_count} draft PO(s)`);
      toast.success(parts.length ? parts.join(' · ') : 'No reorder candidates');
      qc.invalidateQueries({ queryKey: ['purchase-orders'] });
      qc.invalidateQueries({ queryKey: ['production-tickets'] });
    } catch (e) {
      toast.error('Auto-reorder failed: ' + (e.message || 'Unknown error'));
    } finally {
      setRunning(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-sm flex items-center gap-2"><ShoppingCart className="w-4 h-4 text-amber-400" /> Low-Stock Auto-Reorder</CardTitle>
        <Button size="sm" onClick={handleAutoReorder} disabled={running || candidates.length === 0} className="gap-1.5">
          {running ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
          {running ? 'Drafting…' : `Auto-Reorder ${candidates.length}`}
        </Button>
      </CardHeader>
      <CardContent>
        {candidates.length === 0 ? (
          <div className="flex items-center justify-center h-24 text-sm text-muted-foreground border border-dashed border-border rounded-xl">
            All stock levels are healthy — no reorder candidates.
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-3 text-xs text-muted-foreground flex-wrap">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>{candidates.length} items at/below reorder threshold{zeroCount > 0 && <> · <span className="text-red-400 font-semibold">{zeroCount} at 0 stock (auto-place + production)</span></>}. Suggested PO spend: <span className="text-amber-400 font-semibold">${totalSpend.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span></span>
            </div>
            <div className="rounded-xl border border-border overflow-hidden">
              <div className="grid grid-cols-12 gap-2 px-3 py-2 bg-muted/50 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                <div className="col-span-4">Item</div>
                <div className="col-span-2">On Hand</div>
                <div className="col-span-2">Threshold</div>
                <div className="col-span-2 text-right">Suggested Qty</div>
                <div className="col-span-2 text-right">Est. Cost</div>
              </div>
              {candidates.slice(0, 8).map(c => (
                <div key={c.id} className="grid grid-cols-12 gap-2 px-3 py-2.5 text-sm border-t border-border items-center">
                  <div className="col-span-4 min-w-0">
                    <p className="font-medium truncate">{c.item_name}</p>
                    <p className="text-[11px] text-muted-foreground truncate">{c.sku}</p>
                  </div>
                  <div className="col-span-2"><Badge variant={c.is_zero ? 'destructive' : 'secondary'} className="text-[10px]">{c.quantity_on_hand || 0}{c.is_zero ? ' · PLACE' : ''}</Badge></div>
                  <div className="col-span-2 text-muted-foreground text-xs">{c.reorder_threshold || 0}</div>
                  <div className="col-span-2 text-right font-semibold">{c.suggested_qty}</div>
                  <div className="col-span-2 text-right text-muted-foreground text-xs">${c.suggested_cost.toLocaleString(undefined, { maximumFractionDigits: 0 })}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}