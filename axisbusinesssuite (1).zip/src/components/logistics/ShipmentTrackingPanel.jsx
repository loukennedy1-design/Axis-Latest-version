import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Loader2, Truck, MapPin, Clock, CheckCircle2, RefreshCw, Package, Navigation } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_ICONS = {
  pending: Clock, label_created: Package, picked_up: Package, in_transit: Truck, out_for_delivery: Navigation, delivered: CheckCircle2, failed: RefreshCw, returned: RefreshCw, cancelled: Clock
};

const STATUS_COLORS = {
  pending: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  label_created: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  picked_up: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  in_transit: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  out_for_delivery: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  delivered: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  failed: 'bg-red-500/10 text-red-400 border-red-500/20',
  returned: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  cancelled: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
};

export default function ShipmentTrackingPanel() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [tracking, setTracking] = useState(null);
  const [refreshing, setRefreshing] = useState(null);

  const { data: shipments = [], isLoading } = useQuery({
    queryKey: ['shipments-tracking'],
    queryFn: () => base44.entities.Shipment.filter({ status: { $ne: 'delivered' } }).catch(() => base44.entities.Shipment.list('-created_date', 100))
  });

  const handleTrack = async (shipment) => {
    setRefreshing(shipment.id);
    try {
      const res = await base44.functions.invoke('shippingOperations', {
        action: 'track_shipment',
        shipment_id: shipment.id,
        tracking_number: shipment.tracking_number,
        carrier: shipment.carrier
      });
      if (res.data?.error) throw new Error(res.data.error);
      setTracking(res.data);
      qc.invalidateQueries({ queryKey: ['shipments-tracking'] });
      toast.success(`Tracking updated — ${res.data.status}`);
    } catch (e) { toast.error(e.message); } finally { setRefreshing(null); }
  };

  const handleManualTrack = async () => {
    if (!search) { toast.error('Enter a tracking number'); return; }
    setRefreshing('manual');
    try {
      const res = await base44.functions.invoke('shippingOperations', {
        action: 'track_shipment',
        tracking_number: search,
        carrier: 'UPS'
      });
      if (res.data?.error) throw new Error(res.data.error);
      setTracking(res.data);
      toast.success(`Tracking retrieved — ${res.data.status}`);
    } catch (e) { toast.error(e.message); } finally { setRefreshing(null); }
  };

  const history = tracking?.history ? (typeof tracking.history === 'string' ? JSON.parse(tracking.history) : tracking.history) : [];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-sm">Shipment Tracking</h3>
        <p className="text-xs text-muted-foreground">Track shipments across all carriers — live tracking via connected aggregators or enter a tracking number manually</p>
      </div>

      {/* Manual tracking search */}
      <Card>
        <CardContent className="p-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Enter any tracking number..." className="pl-8" onKeyDown={e => e.key === 'Enter' && handleManualTrack()} />
            </div>
            <Button onClick={handleManualTrack} disabled={refreshing === 'manual'} className="gap-1.5">
              {refreshing === 'manual' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}Track
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tracking result */}
      {tracking && (
        <Card className="border-primary/30">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center"><Truck className="w-5 h-5 text-primary" /></div>
              <div className="flex-1">
                <p className="font-semibold text-sm">{tracking.carrier} — {tracking.tracking_number}</p>
                <Badge className={`mt-0.5 ${STATUS_COLORS[tracking.status?.toLowerCase()] || STATUS_COLORS.in_transit}`}>{tracking.status?.replace(/_/g, ' ')}</Badge>
                {tracking.source === 'live' && <Badge className="ml-1 bg-emerald-500/10 text-emerald-400 text-[9px]">LIVE</Badge>}
              </div>
            </div>
            {history.length > 0 && (
              <div className="space-y-2 pl-2">
                {history.slice().reverse().map((h, i) => {
                  const Icon = STATUS_ICONS[h.status?.toLowerCase()] || Clock;
                  return (
                    <div key={i} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center ${i === history.length - 1 ? 'bg-primary/20' : 'bg-muted'}`}>
                          <Icon className={`w-3 h-3 ${i === history.length - 1 ? 'text-primary' : 'text-muted-foreground'}`} />
                        </div>
                        {i < history.length - 1 && <div className="w-px h-6 bg-border" />}
                      </div>
                      <div className="flex-1 pb-2">
                        <p className="text-sm font-medium">{h.description || h.status?.replace(/_/g, ' ')}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          {h.location && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{h.location}</span>}
                          {h.timestamp && <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" />{format(new Date(h.timestamp), 'MMM d, h:mm a')}</span>}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Active shipments list */}
      <div className="pt-2">
        <p className="text-xs font-medium text-muted-foreground mb-2">Active Shipments ({shipments.length})</p>
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : shipments.length === 0 ? (
          <Card className="border-dashed"><CardContent className="p-8 text-center text-sm text-muted-foreground">No active shipments to track</CardContent></Card>
        ) : (
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {shipments.filter(s => s.tracking_number).map(s => {
              const Icon = STATUS_ICONS[s.status] || Clock;
              return (
                <div key={s.id} className="flex items-center gap-3 p-3 bg-card border border-border rounded-xl">
                  <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0"><Icon className="w-4 h-4 text-primary" /></div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{s.shipment_number} · {s.carrier}</p>
                    <p className="text-xs text-muted-foreground truncate">{s.recipient_name || s.account_name} — {s.tracking_number}</p>
                  </div>
                  <Badge className={`text-[10px] ${STATUS_COLORS[s.status] || ''}`}>{s.status.replace(/_/g, ' ')}</Badge>
                  <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={refreshing === s.id} onClick={() => handleTrack(s)}>
                    {refreshing === s.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}Refresh
                  </Button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}