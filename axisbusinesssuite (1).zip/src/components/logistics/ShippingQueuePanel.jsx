import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Package, Plus, Loader2, Search, Download, Truck, MapPin, FileText, Layers } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const STATUS_COLORS = {
  pending: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
  label_created: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  picked_up: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  in_transit: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  out_for_delivery: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
  delivered: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  failed: 'bg-red-500/10 text-red-400 border-red-500/20',
  returned: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  cancelled: 'bg-slate-500/10 text-slate-500 border-slate-500/20',
};

export default function ShippingQueuePanel() {
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [createOpen, setCreateOpen] = useState(false);
  const [selected, setSelected] = useState(new Set());
  const [labelResult, setLabelResult] = useState(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    name: '', email: '', phone: '', company: '', address_line1: '', address_line2: '', city: '', state: '', postal_code: '', country: 'US',
    weight: 2, dimensions: '12x10x8', package_type: 'box', service_type: 'ground', carrier: 'UPS', signature_required: false, integration_id: '', order_id: '', production_ticket_id: ''
  });

  const { data: shipments = [], isLoading } = useQuery({
    queryKey: ['shipments'],
    queryFn: () => base44.entities.Shipment.list('-created_date', 200)
  });

  const { data: integrations = [] } = useQuery({
    queryKey: ['shipping-integrations'],
    queryFn: () => base44.functions.invoke('shippingOperations', { action: 'list_integrations' }).then(r => r.data?.integrations || [])
  });

  const { data: orders = [] } = useQuery({
    queryKey: ['orders-fulfillment'],
    queryFn: () => base44.entities.Order.filter({ status: 'fulfillment' }).catch(() => [])
  });

  const filtered = shipments.filter(s => {
    const matchSearch = !search || (s.shipment_number || '').toLowerCase().includes(search.toLowerCase()) || (s.recipient_name || '').toLowerCase().includes(search.toLowerCase()) || (s.tracking_number || '').toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || s.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const createLabel = async () => {
    if (!form.name || !form.address_line1 || !form.weight) { toast.error('Name, address line 1, and weight are required'); return; }
    setCreating(true);
    try {
      const res = await base44.functions.invoke('shippingOperations', {
        action: 'create_label',
        recipient: {
          name: form.name, email: form.email, phone: form.phone, company: form.company,
          address_line1: form.address_line1, address_line2: form.address_line2,
          city: form.city, state: form.state, postal_code: form.postal_code, country: form.country || 'US'
        },
        weight: parseFloat(form.weight),
        dimensions: form.dimensions,
        package_type: form.package_type,
        service_type: form.service_type,
        carrier: form.carrier,
        integration_id: form.integration_id || null,
        signature_required: form.signature_required,
        order_id: form.order_id,
        production_ticket_id: form.production_ticket_id
      });
      if (res.data?.error) throw new Error(res.data.error);
      setLabelResult(res.data);
      qc.invalidateQueries({ queryKey: ['shipments'] });
      toast.success(`Label created — ${res.data.tracking_number}`);
    } catch (e) { toast.error(e.message); } finally { setCreating(false); }
  };

  const batchLabels = async () => {
    if (selected.size === 0) { toast.error('Select shipments first'); return; }
    setCreating(true);
    try {
      const res = await base44.functions.invoke('shippingOperations', {
        action: 'batch_labels',
        shipment_ids: Array.from(selected),
        integration_id: form.integration_id || null,
        service_type: form.service_type
      });
      if (res.data?.error) throw new Error(res.data.error);
      qc.invalidateQueries({ queryKey: ['shipments'] });
      toast.success(`Batch ${res.data.batch_id}: ${res.data.processed} labels created, ${res.data.failed} failed`);
      setSelected(new Set());
    } catch (e) { toast.error(e.message); } finally { setCreating(false); }
  };

  const toggleSelect = (id) => {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-sm">Shipping Queue & Label Generation</h3>
          <p className="text-xs text-muted-foreground">Create labels, manage shipments, and batch-process fulfillment</p>
        </div>
        <div className="flex gap-2">
          {selected.size > 0 && <Button size="sm" variant="outline" className="gap-1.5" onClick={batchLabels} disabled={creating}>{creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Layers className="w-4 h-4" />}Batch Labels ({selected.size})</Button>}
          <Button size="sm" className="gap-1.5" onClick={() => { setLabelResult(null); setCreateOpen(true); }}><Plus className="w-4 h-4" />New Shipment</Button>
        </div>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by shipment #, recipient, or tracking #" className="pl-8" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="label_created">Label Created</SelectItem>
            <SelectItem value="picked_up">Picked Up</SelectItem>
            <SelectItem value="in_transit">In Transit</SelectItem>
            <SelectItem value="out_for_delivery">Out for Delivery</SelectItem>
            <SelectItem value="delivered">Delivered</SelectItem>
            <SelectItem value="failed">Failed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : filtered.length === 0 ? (
        <Card className="border-dashed"><CardContent className="p-10 text-center"><Package className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-40" /><p className="text-sm font-medium mb-1">No shipments found</p><p className="text-xs text-muted-foreground">Create a new shipment to get started</p></CardContent></Card>
      ) : (
        <div className="space-y-2 max-h-[600px] overflow-y-auto">
          {filtered.map(s => (
            <div key={s.id} className={`flex items-center gap-3 p-3 bg-card border rounded-xl ${selected.has(s.id) ? 'border-primary ring-1 ring-primary/20' : 'border-border'}`}>
              <Checkbox checked={selected.has(s.id)} onCheckedChange={() => toggleSelect(s.id)} />
              <div className="w-8 h-8 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0"><Truck className="w-4 h-4 text-primary" /></div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-sm truncate">{s.shipment_number}</p>
                  <Badge className={`text-[10px] ${STATUS_COLORS[s.status] || ''}`}>{s.status.replace(/_/g, ' ')}</Badge>
                </div>
                <p className="text-xs text-muted-foreground truncate">{s.recipient_name || s.account_name} · {s.carrier} {s.service_type}</p>
                <p className="text-[11px] text-muted-foreground truncate">{s.shipping_address || `${s.city}, ${s.state} ${s.postal_code}`}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <p className="text-sm font-bold text-emerald-400">${(s.shipping_cost || 0).toFixed(2)}</p>
                <p className="text-[10px] text-muted-foreground">{s.weight} {s.weight_unit}</p>
              </div>
              {s.label_url && <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => window.open(s.label_url, '_blank')}><Download className="w-3 h-3" />Label</Button>}
              {s.tracking_number && <span className="text-[10px] font-mono text-muted-foreground">{s.tracking_number.slice(0, 12)}…</span>}
            </div>
          ))}
        </div>
      )}

      {/* Create Shipment Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Package className="w-5 h-5 text-primary" />New Shipment & Label</DialogTitle></DialogHeader>
          {labelResult ? (
            <div className="space-y-4">
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-center">
                <Package className="w-8 h-8 mx-auto mb-2 text-emerald-400" />
                <p className="font-semibold text-emerald-400">Label Created Successfully!</p>
                <p className="text-sm text-muted-foreground mt-1">Tracking: <span className="font-mono">{labelResult.tracking_number}</span></p>
                <p className="text-xs text-muted-foreground">Carrier: {labelResult.shipment?.carrier} · {labelResult.shipment?.service_type} · ${labelResult.shipment?.shipping_cost?.toFixed(2)}</p>
              </div>
              {labelResult.label_url && <Button className="w-full gap-2" onClick={() => window.open(labelResult.label_url, '_blank')}><Download className="w-4 h-4" />Download Shipping Label (PDF)</Button>}
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => { setLabelResult(null); }}>Create Another</Button>
                <Button variant="outline" className="flex-1" onClick={() => setCreateOpen(false)}>Done</Button>
              </div>
            </div>
          ) : (
            <>
              <div className="space-y-3">
                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Recipient</div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Name *</Label><Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
                  <div><Label className="text-xs">Company</Label><Input value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Email</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
                  <div><Label className="text-xs">Phone</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
                </div>
                <div><Label className="text-xs">Address Line 1 *</Label><Input value={form.address_line1} onChange={e => setForm({ ...form, address_line1: e.target.value })} /></div>
                <div><Label className="text-xs">Address Line 2</Label><Input value={form.address_line2} onChange={e => setForm({ ...form, address_line2: e.target.value })} /></div>
                <div className="grid grid-cols-4 gap-2">
                  <div><Label className="text-xs">City</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
                  <div><Label className="text-xs">State</Label><Input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} /></div>
                  <div><Label className="text-xs">ZIP</Label><Input value={form.postal_code} onChange={e => setForm({ ...form, postal_code: e.target.value })} /></div>
                  <div><Label className="text-xs">Country</Label><Input value={form.country} onChange={e => setForm({ ...form, country: e.target.value })} /></div>
                </div>

                <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide pt-2">Package & Service</div>
                <div className="grid grid-cols-3 gap-3">
                  <div><Label className="text-xs">Weight (lbs) *</Label><Input type="number" step="0.1" value={form.weight} onChange={e => setForm({ ...form, weight: e.target.value })} /></div>
                  <div><Label className="text-xs">Dimensions (in)</Label><Input value={form.dimensions} onChange={e => setForm({ ...form, dimensions: e.target.value })} placeholder="LxWxH" /></div>
                  <div>
                    <Label className="text-xs">Package Type</Label>
                    <Select value={form.package_type} onValueChange={v => setForm({ ...form, package_type: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="box">Box</SelectItem><SelectItem value="envelope">Envelope</SelectItem>
                        <SelectItem value="padded_flat_rate">Padded Flat Rate</SelectItem><SelectItem value="tube">Tube</SelectItem>
                        <SelectItem value="pallet">Pallet</SelectItem><SelectItem value="custom">Custom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label className="text-xs">Carrier</Label>
                    <Select value={form.carrier} onValueChange={v => setForm({ ...form, carrier: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="UPS">UPS</SelectItem><SelectItem value="FedEx">FedEx</SelectItem><SelectItem value="USPS">USPS</SelectItem><SelectItem value="DHL">DHL</SelectItem><SelectItem value="Other">Other</SelectItem></SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-xs">Service Level</Label>
                    <Select value={form.service_type} onValueChange={v => setForm({ ...form, service_type: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ground">Ground</SelectItem><SelectItem value="express">Express (2-Day)</SelectItem>
                        <SelectItem value="overnight">Overnight</SelectItem><SelectItem value="economy">Economy</SelectItem>
                        <SelectItem value="priority">Priority</SelectItem><SelectItem value="same_day">Same Day</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label className="text-xs">Shipping Connection (optional — enables live labels)</Label>
                  <Select value={form.integration_id} onValueChange={v => setForm({ ...form, integration_id: v === 'none' ? '' : v })}>
                    <SelectTrigger><SelectValue placeholder="Manual label (no live API)" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Manual (generate tracking # only)</SelectItem>
                      {integrations.map(i => <SelectItem key={i.id} value={i.id}>{i.integration_name} ({i.provider_name})</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label className="text-xs">Order ID (optional)</Label><Input value={form.order_id} onChange={e => setForm({ ...form, order_id: e.target.value })} /></div>
                  <div><Label className="text-xs">Production Ticket ID (optional)</Label><Input value={form.production_ticket_id} onChange={e => setForm({ ...form, production_ticket_id: e.target.value })} /></div>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox checked={form.signature_required} onCheckedChange={v => setForm({ ...form, signature_required: v })} id="sig" />
                  <Label htmlFor="sig" className="text-xs cursor-pointer">Signature required on delivery</Label>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
                <Button onClick={createLabel} disabled={creating} className="gap-1.5">{creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}Create Label</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}