import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, Loader2, Truck, Clock, DollarSign, Package, MapPin, Zap, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';

export default function RateShopperPanel({ onLabelCreate }) {
  const [form, setForm] = useState({
    from_address: '', to_address: '', weight: 2, dimensions: '12x10x8', package_type: 'box', city: '', state: '', postal_code: ''
  });
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState(null);

  const { data: carriers } = useQuery({
    queryKey: ['shipping-carriers'],
    queryFn: () => base44.functions.invoke('shippingOperations', { action: 'list_carriers' }).then(r => r.data)
  });

  const handleRateShop = async () => {
    if (!form.to_address || !form.weight) { toast.error('Destination address and weight are required'); return; }
    setLoading(true);
    try {
      const fullAddress = `${form.to_address}${form.city ? ', ' + form.city : ''}${form.state ? ', ' + form.state : ''} ${form.postal_code}`;
      const res = await base44.functions.invoke('shippingOperations', {
        action: 'rate_shop',
        from_address: form.from_address || '123 Main St, New York, NY 10001',
        to_address: fullAddress,
        weight: parseFloat(form.weight),
        dimensions: form.dimensions,
        package_type: form.package_type,
        use_all_active: true
      });
      if (res.data?.error) throw new Error(res.data.error);
      setResults(res.data?.rates || []);
      toast.success(`${res.data?.count || 0} rates found across all carriers`);
    } catch (e) { toast.error(e.message); } finally { setLoading(false); }
  };

  const handleSelect = (rate) => {
    setSelected(rate.id);
    if (onLabelCreate) onLabelCreate({ ...form, rate });
  };

  const cheapest = results ? Math.min(...results.map(r => r.rate)) : 0;
  const fastest = results && results.length > 0 ? Math.min(...results.map(r => r.estimated_days || 999)) : 0;

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-sm">Rate Shopper — Compare Across All Carriers</h3>
        <p className="text-xs text-muted-foreground">Enter shipment details to compare rates, transit times, and delivery estimates from all connected carriers</p>
      </div>

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label className="text-xs">From Address</Label><Input value={form.from_address} onChange={e => setForm({ ...form, from_address: e.target.value })} placeholder="Origin street address" /></div>
            <div className="grid grid-cols-3 gap-1">
              <div><Label className="text-xs">City</Label><Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
              <div><Label className="text-xs">State</Label><Input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} /></div>
              <div><Label className="text-xs">ZIP</Label><Input value={form.postal_code} onChange={e => setForm({ ...form, postal_code: e.target.value })} /></div>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-3">
            <div><Label className="text-xs">Weight (lbs)</Label><Input type="number" step="0.1" value={form.weight} onChange={e => setForm({ ...form, weight: e.target.value })} /></div>
            <div><Label className="text-xs">Dimensions (in)</Label><Input value={form.dimensions} onChange={e => setForm({ ...form, dimensions: e.target.value })} placeholder="LxWxH" /></div>
            <div>
              <Label className="text-xs">Package Type</Label>
              <Select value={form.package_type} onValueChange={v => setForm({ ...form, package_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {(carriers?.packages || []).map(p => <SelectItem key={p.type} value={p.type}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end"><Button className="w-full gap-1.5" onClick={handleRateShop} disabled={loading}>{loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}Compare Rates</Button></div>
          </div>
        </CardContent>
      </Card>

      {results && results.length > 0 && (
        <>
          <div className="flex gap-2">
            <Badge className="bg-emerald-500/10 text-emerald-400 gap-1"><TrendingDown className="w-3 h-3" />Cheapest: ${cheapest.toFixed(2)}</Badge>
            <Badge className="bg-blue-500/10 text-blue-400 gap-1"><Zap className="w-3 h-3" />Fastest: {fastest} day(s)</Badge>
            <Badge variant="outline" className="gap-1"><Truck className="w-3 h-3" />{results.length} quotes</Badge>
          </div>

          <div className="space-y-2">
            {results.map(r => (
              <Card key={r.id} className={selected === r.id ? 'border-primary ring-1 ring-primary/30' : 'border-border'}>
                <CardContent className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0">
                      <Truck className="w-4 h-4 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm">{r.carrier_name}</p>
                        <span className="text-xs text-muted-foreground">{r.service_name}</span>
                        {r.source === 'shippo_live' || r.source === 'easypost_live'
                          ? <Badge className="bg-emerald-500/10 text-emerald-400 text-[9px]">LIVE</Badge>
                          : r.source === 'simulated' || r.source === 'connected_simulated'
                            ? <Badge variant="outline" className="text-[9px] text-muted-foreground">Estimate</Badge>
                            : null
                        }
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                        <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" />{r.estimated_days} day(s)</span>
                        {r.estimated_delivery_date && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />ETA {r.estimated_delivery_date}</span>}
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-emerald-400">${r.rate.toFixed(2)}</p>
                      <p className="text-[10px] text-muted-foreground">{r.currency}</p>
                    </div>
                    <Button size="sm" variant={selected === r.id ? 'default' : 'outline'} className="h-7 text-xs gap-1" onClick={() => handleSelect(r)}>
                      {selected === r.id ? 'Selected' : 'Select'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}

      {results && results.length === 0 && (
        <Card className="border-dashed"><CardContent className="p-10 text-center text-sm text-muted-foreground">No rates returned. Check your carrier connections or try different parameters.</CardContent></Card>
      )}
    </div>
  );
}