import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Truck, Plus, Settings2, CheckCircle2, XCircle, Loader2, Zap, KeyRound, Building2, Globe } from 'lucide-react';
import { toast } from 'sonner';

const CARRIERS = [
  { code: 'ups', name: 'UPS', type: 'carrier_direct', desc: 'United Parcel Service — domestic & international' },
  { code: 'fedex', name: 'FedEx', type: 'carrier_direct', desc: 'FedEx Express & Ground — worldwide shipping' },
  { code: 'usps', name: 'USPS', type: 'carrier_direct', desc: 'US Postal Service — economy & priority mail' },
  { code: 'dhl', name: 'DHL Express', type: 'carrier_direct', desc: 'DHL — international express shipping' },
  { code: 'shippo', name: 'Shippo', type: 'aggregator', desc: 'Multi-carrier API — UPS, FedEx, USPS, DHL in one' },
  { code: 'easypost', name: 'EasyPost', type: 'aggregator', desc: 'Multi-carrier API — 100+ carriers via one integration' },
  { code: 'shipstation', name: 'ShipStation', type: 'aggregator', desc: 'Shipping automation platform — multi-carrier & marketplace sync' },
  { code: 'shipwire', name: 'ShipWire', type: 'aggregator', desc: '3PL fulfillment & warehousing network' },
  { code: 'other', name: 'Custom / Other', type: 'carrier_direct', desc: 'Connect any carrier via custom API endpoint' },
];

export default function CarrierConnectionsPanel() {
  const qc = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [testing, setTesting] = useState(null);
  const [form, setForm] = useState({});

  const { data: integrations = [], isLoading } = useQuery({
    queryKey: ['shipping-integrations'],
    queryFn: () => base44.functions.invoke('shippingOperations', { action: 'list_integrations' }).then(r => r.data?.integrations || [])
  });

  const saveMutation = useMutation({
    mutationFn: (data) => base44.functions.invoke('shippingOperations', { action: 'save_integration', ...data }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['shipping-integrations'] }); toast.success('Integration saved'); setDialogOpen(false); },
    onError: (e) => toast.error(e.message)
  });

  const testMutation = useMutation({
    mutationFn: (id) => base44.functions.invoke('shippingOperations', { action: 'test_integration', integration_id: id }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ['shipping-integrations'] });
      if (r.data?.verified) toast.success(r.data?.message || 'Connection verified');
      else toast.error(r.data?.message || 'Verification failed');
    },
    onError: (e) => toast.error(e.message)
  });

  const openNew = () => { setEditing(null); setForm({ integration_type: 'carrier_direct', test_mode: true, is_active: true }); setDialogOpen(true); };
  const openEdit = (integ) => { setEditing(integ); setForm({ ...integ }); setDialogOpen(true); };

  const handleSave = () => {
    if (!form.integration_name || !form.carrier_code) { toast.error('Name and carrier are required'); return; }
    saveMutation.mutate({ ...form, id: editing?.id });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold text-sm">Carrier & Shipping Software Connections</h3>
          <p className="text-xs text-muted-foreground">Connect directly to carriers (UPS, FedEx, USPS, DHL) or 3rd-party aggregators (Shippo, EasyPost, ShipStation)</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={openNew}><Plus className="w-4 h-4" />Add Connection</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : integrations.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="p-10 text-center">
            <Truck className="w-10 h-10 mx-auto mb-3 text-muted-foreground opacity-40" />
            <p className="text-sm font-medium mb-1">No shipping connections yet</p>
            <p className="text-xs text-muted-foreground mb-4">Connect a carrier or aggregator to start shipping, rate shopping, and tracking</p>
            <Button size="sm" className="gap-1.5" onClick={openNew}><Plus className="w-4 h-4" />Add Your First Connection</Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {integrations.map(integ => {
            const carrierInfo = CARRIERS.find(c => c.code === integ.carrier_code) || {};
            return (
              <Card key={integ.id} className="border-border">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center flex-shrink-0">
                      {integ.integration_type === 'aggregator' ? <Globe className="w-5 h-5 text-primary" /> : <Truck className="w-5 h-5 text-primary" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm truncate">{integ.integration_name}</p>
                        {integ.is_verified
                          ? <Badge className="bg-emerald-500/10 text-emerald-400 text-[10px] gap-0.5"><CheckCircle2 className="w-3 h-3" />Verified</Badge>
                          : <Badge className="bg-amber-500/10 text-amber-400 text-[10px] gap-0.5"><XCircle className="w-3 h-3" />Unverified</Badge>
                        }
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{integ.provider_name} · {integ.integration_type === 'aggregator' ? 'Aggregator' : 'Direct API'}</p>
                      {integ.test_mode && <Badge variant="outline" className="mt-1 text-[10px] text-amber-400 border-amber-500/30">Test Mode</Badge>}
                      {integ.account_number && <p className="text-[11px] text-muted-foreground mt-1">Account: {integ.account_number}</p>}
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="outline" className="h-7 text-xs gap-1" disabled={testMutation.isPending && testing === integ.id} onClick={() => { setTesting(integ.id); testMutation.mutate(integ.id); }}>
                          {testMutation.isPending && testing === integ.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}Test
                        </Button>
                        <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => openEdit(integ)}><Settings2 className="w-3 h-3" />Edit</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Available carriers quick-add */}
      <div className="pt-2">
        <p className="text-xs font-medium text-muted-foreground mb-2">Available Carriers & Aggregators</p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {CARRIERS.map(c => (
            <button key={c.code} onClick={() => { setEditing(null); setForm({ carrier_code: c.code, provider_name: c.name, integration_type: c.type, integration_name: c.name, test_mode: true, is_active: true }); setDialogOpen(true); }}
              className="flex items-center gap-2 p-2.5 rounded-lg border border-border hover:border-primary/40 hover:bg-primary/5 transition-colors text-left">
              {c.type === 'aggregator' ? <Globe className="w-4 h-4 text-primary flex-shrink-0" /> : <Truck className="w-4 h-4 text-primary flex-shrink-0" />}
              <div className="min-w-0">
                <p className="text-xs font-medium truncate">{c.name}</p>
                <p className="text-[10px] text-muted-foreground truncate">{c.type === 'aggregator' ? 'Aggregator' : 'Direct'}</p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {form.integration_type === 'aggregator' ? <Globe className="w-5 h-5 text-primary" /> : <Truck className="w-5 h-5 text-primary" />}
              {editing ? 'Edit Connection' : 'New Shipping Connection'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-xs">Connection Name *</Label><Input value={form.integration_name || ''} onChange={e => setForm({ ...form, integration_name: e.target.value })} placeholder="e.g. UPS Production" /></div>

            <div>
              <Label className="text-xs">Carrier / Provider</Label>
              <Select value={form.carrier_code || ''} onValueChange={v => { const c = CARRIERS.find(x => x.code === v); setForm({ ...form, carrier_code: v, provider_name: c?.name || '', integration_type: c?.type || 'carrier_direct' }); }}>
                <SelectTrigger><SelectValue placeholder="Select carrier" /></SelectTrigger>
                <SelectContent>{CARRIERS.map(c => <SelectItem key={c.code} value={c.code}>{c.name} ({c.type === 'aggregator' ? 'Aggregator' : 'Direct'})</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">API Key / Account #</Label><Input value={form.api_key || ''} onChange={e => setForm({ ...form, api_key: e.target.value })} placeholder="API key or account number" /></div>
              <div><Label className="text-xs">API Secret / Password</Label><Input type="password" value={form.api_secret || ''} onChange={e => setForm({ ...form, api_secret: e.target.value })} placeholder="Secret key" /></div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">Account Number</Label><Input value={form.account_number || ''} onChange={e => setForm({ ...form, account_number: e.target.value })} placeholder="Carrier account #" /></div>
              <div><Label className="text-xs">Meter Number (FedEx)</Label><Input value={form.meter_number || ''} onChange={e => setForm({ ...form, meter_number: e.target.value })} placeholder="Optional" /></div>
            </div>

            <div><Label className="text-xs">Default Origin Address</Label><Input value={form.default_origin_address || ''} onChange={e => setForm({ ...form, default_origin_address: e.target.value })} placeholder="Ship-from street address" /></div>

            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">Origin Contact Name</Label><Input value={form.default_origin_name || ''} onChange={e => setForm({ ...form, default_origin_name: e.target.value })} /></div>
              <div><Label className="text-xs">Origin Phone</Label><Input value={form.default_origin_phone || ''} onChange={e => setForm({ ...form, default_origin_phone: e.target.value })} /></div>
            </div>

            <div><Label className="text-xs">Custom API Base URL (optional)</Label><Input value={form.api_base_url || ''} onChange={e => setForm({ ...form, api_base_url: e.target.value })} placeholder="Override default API endpoint" /></div>

            <div className="flex items-center justify-between gap-4 pt-1">
              <div className="flex items-center gap-2"><Switch checked={form.test_mode !== false} onCheckedChange={v => setForm({ ...form, test_mode: v })} /><Label className="text-xs">Test / Sandbox Mode</Label></div>
              <div className="flex items-center gap-2"><Switch checked={form.is_active !== false} onCheckedChange={v => setForm({ ...form, is_active: v })} /><Label className="text-xs">Active</Label></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saveMutation.isPending} className="gap-1.5">
              {saveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <KeyRound className="w-4 h-4" />}
              {editing ? 'Update Connection' : 'Save Connection'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}