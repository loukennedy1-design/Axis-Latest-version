import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Truck, Package, CheckCircle2, AlertTriangle, DollarSign, TrendingUp, Loader2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

const CARRIER_COLORS = { UPS: '#8b5cf6', FedEx: '#f59e0b', USPS: '#3b82f6', DHL: '#ef4444', Other: '#64748b' };
const STATUS_COLORS_PIE = { delivered: '#10b981', in_transit: '#a855f7', out_for_delivery: '#06b6d4', label_created: '#3b82f6', failed: '#ef4444', picked_up: '#f59e0b', returned: '#f97316', pending: '#64748b', cancelled: '#475569' };

export default function ShippingAnalyticsPanel() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['shipping-analytics'],
    queryFn: () => base44.functions.invoke('shippingOperations', { action: 'analytics' }).then(r => r.data)
  });

  if (isLoading || !analytics) {
    return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  const { summary = {}, byCarrier = {}, byStatus = {}, byService = {}, dailyTrend = {} } = analytics;
  const carrierData = Object.entries(byCarrier).map(([name, count]) => ({ name, count, fill: CARRIER_COLORS[name] || '#64748b' }));
  const statusData = Object.entries(byStatus).map(([name, value]) => ({ name, value, fill: STATUS_COLORS_PIE[name] || '#64748b' }));
  const serviceData = Object.entries(byService).map(([name, count]) => ({ name, count }));
  const trendData = Object.entries(dailyTrend).map(([date, count]) => ({ date: date.slice(5), count }));

  const stats = [
    { label: 'Total Shipments', value: summary.totalShipments || 0, icon: Package, color: 'text-blue-400', bg: 'bg-blue-500/10' },
    { label: 'Delivered', value: summary.delivered || 0, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'In Transit', value: summary.inTransit || 0, icon: Truck, color: 'text-purple-400', bg: 'bg-purple-500/10' },
    { label: 'Failed/Returned', value: summary.failed || 0, icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/10' },
    { label: 'Total Cost', value: `$${(summary.totalCost || 0).toLocaleString(undefined, { maximumFractionDigits: 2 })}`, icon: DollarSign, color: 'text-amber-400', bg: 'bg-amber-500/10' },
    { label: 'Avg Cost/Ship', value: `$${(summary.avgCost || 0).toFixed(2)}`, icon: TrendingUp, color: 'text-cyan-400', bg: 'bg-cyan-500/10' },
    { label: 'Delivery Rate', value: `${((summary.deliveryRate || 0) * 100).toFixed(1)}%`, icon: CheckCircle2, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
    { label: 'Active Carriers', value: carrierData.length, icon: Truck, color: 'text-primary', bg: 'bg-primary/10' },
  ];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold text-sm">Shipping Analytics & Performance</h3>
        <p className="text-xs text-muted-foreground">Overview of shipping volume, costs, carrier distribution, and delivery performance</p>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {stats.map(s => (
          <Card key={s.label}>
            <CardContent className="p-3">
              <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-2`}>
                <s.icon className={`w-4 h-4 ${s.color}`} />
              </div>
              <p className="text-xl font-bold">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Carrier Distribution */}
        <Card>
          <CardContent className="p-4">
            <p className="text-sm font-semibold mb-3">Shipments by Carrier</p>
            {carrierData.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={carrierData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 15%)" />
                  <XAxis dataKey="name" tick={{ fill: 'hsl(0 0% 50%)', fontSize: 11 }} />
                  <YAxis tick={{ fill: 'hsl(0 0% 50%)', fontSize: 11 }} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card>
          <CardContent className="p-4">
            <p className="text-sm font-semibold mb-3">Delivery Status Breakdown</p>
            {statusData.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({ name, value }) => `${name.replace(/_/g, ' ')}: ${value}`} labelLine={false} style={{ fontSize: 10 }}>
                    {statusData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Shipping Trend */}
        <Card>
          <CardContent className="p-4">
            <p className="text-sm font-semibold mb-3">Shipping Volume (Last 30 Days)</p>
            {trendData.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No data</div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(0 0% 15%)" />
                  <XAxis dataKey="date" tick={{ fill: 'hsl(0 0% 50%)', fontSize: 10 }} />
                  <YAxis tick={{ fill: 'hsl(0 0% 50%)', fontSize: 11 }} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: 'hsl(0 0% 8%)', border: '1px solid hsl(0 0% 15%)', borderRadius: 8, fontSize: 12 }} />
                  <Line type="monotone" dataKey="count" stroke="hsl(0 100% 50%)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        {/* Service Level Distribution */}
        <Card>
          <CardContent className="p-4">
            <p className="text-sm font-semibold mb-3">Service Level Usage</p>
            {serviceData.length === 0 ? (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">No data</div>
            ) : (
              <div className="space-y-2 pt-2">
                {serviceData.map(s => {
                  const max = Math.max(...serviceData.map(x => x.count));
                  return (
                    <div key={s.name}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="capitalize">{s.name}</span>
                        <span className="text-muted-foreground">{s.count}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(s.count / max) * 100}%` }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}