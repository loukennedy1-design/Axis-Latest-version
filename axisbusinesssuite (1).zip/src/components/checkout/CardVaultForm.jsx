import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, CreditCard, Loader2, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function CardVaultForm({ email, fullName, planLabel, amount, isYearly, vaultToken, onSuccess }) {
  const [cardholderName, setCardholderName] = useState(fullName || '');
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('US');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const formatCardNumber = (val) => {
    const digits = val.replace(/\D/g, '').slice(0, 19);
    return digits.replace(/(.{4})/g, '$1 ').trim();
  };

  const formatExpiry = (val) => {
    const digits = val.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 3) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    return digits;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!cardholderName.trim() || !cardNumber.trim() || !expiry.trim() || !cvv.trim() || !addressLine1.trim() || !city.trim() || !state.trim() || !zip.trim()) {
      toast.error('Please fill in all required fields.');
      return;
    }
    setLoading(true);
    try {
      const res = await base44.functions.invoke('storeCardVault', {
        email,
        vaultToken,
        cardholderName: cardholderName.trim(),
        cardNumber: cardNumber.replace(/\s/g, ''),
        expiry,
        cvv,
        addressLine1: addressLine1.trim(),
        addressLine2: addressLine2.trim(),
        city: city.trim(),
        state: state.trim(),
        zip: zip.trim(),
        country,
      });
      if (res.data?.success) {
        setDone(true);
        toast.success('Card saved successfully!');
        onSuccess?.();
      } else {
        toast.error(res.data?.error || 'Failed to save card.');
      }
    } catch (err) {
      toast.error(err.message || 'Failed to save card.');
    } finally {
      setLoading(false);
    }
  };

  if (done) {
    return (
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-8 text-center space-y-3">
        <CheckCircle className="w-12 h-12 text-emerald-500 mx-auto" />
        <h3 className="text-lg font-bold">Card Saved Successfully</h3>
        <p className="text-sm text-muted-foreground max-w-sm mx-auto">
          Your card has been encrypted and stored securely. You will be charged{' '}
          <span className="font-semibold text-foreground">${amount}{isYearly ? '/yr' : '/mo'}</span> for your{' '}
          <span className="font-semibold text-foreground">{planLabel}</span> plan automatically once payment processing is live.
          No further action is needed — we'll email you a receipt when the charge goes through.
        </p>
        <p className="text-xs text-muted-foreground pt-2">You can now close this page and log in to your account.</p>
        <a href="/app" className="inline-block mt-2">
          <Button variant="outline">Go to Dashboard →</Button>
        </a>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-6 space-y-5">
      <div className="flex items-center gap-2">
        <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
          <CreditCard className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-bold text-base">Enter Your Card Details</h3>
          <p className="text-xs text-muted-foreground">
            {planLabel} plan — ${amount}{isYearly ? '/yr' : '/mo'} · Charged when processing is live
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label className="text-xs">Cardholder Name *</Label>
          <Input
            type="text"
            value={cardholderName}
            onChange={(e) => setCardholderName(e.target.value)}
            placeholder="Jane Smith"
            required
            className="mt-1"
          />
        </div>

        <div>
          <Label className="text-xs">Card Number *</Label>
          <Input
            type="text"
            inputMode="numeric"
            value={cardNumber}
            onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
            placeholder="4242 4242 4242 4242"
            required
            className="mt-1 font-mono"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">Expiry (MM/YY) *</Label>
            <Input
              type="text"
              inputMode="numeric"
              value={expiry}
              onChange={(e) => setExpiry(formatExpiry(e.target.value))}
              placeholder="12/27"
              required
              className="mt-1 font-mono"
            />
          </div>
          <div>
            <Label className="text-xs">CVV *</Label>
            <Input
              type="password"
              inputMode="numeric"
              value={cvv}
              onChange={(e) => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))}
              placeholder="•••"
              required
              className="mt-1 font-mono"
            />
          </div>
        </div>

        <div className="pt-2 border-t border-border/50">
          <p className="text-xs font-semibold text-muted-foreground mb-3">Billing Address</p>
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Address Line 1 *</Label>
              <Input
                type="text"
                value={addressLine1}
                onChange={(e) => setAddressLine1(e.target.value)}
                placeholder="123 Main St"
                required
                className="mt-1"
              />
            </div>
            <div>
              <Label className="text-xs">Address Line 2</Label>
              <Input
                type="text"
                value={addressLine2}
                onChange={(e) => setAddressLine2(e.target.value)}
                placeholder="Apt, Suite, etc. (optional)"
                className="mt-1"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">City *</Label>
                <Input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="New York"
                  required
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs">State *</Label>
                <Input
                  type="text"
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  placeholder="NY"
                  required
                  className="mt-1"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">ZIP Code *</Label>
                <Input
                  type="text"
                  value={zip}
                  onChange={(e) => setZip(e.target.value.replace(/[^0-9\-]/g, '').slice(0, 10))}
                  placeholder="10001"
                  required
                  className="mt-1"
                />
              </div>
              <div>
                <Label className="text-xs">Country</Label>
                <Input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
          </div>
        </div>

        <Button type="submit" size="lg" className="w-full gap-2" disabled={loading}>
          {loading ? (
            <><Loader2 className="w-4 h-4 animate-spin" /> Encrypting & Saving...</>
          ) : (
            <><Lock className="w-4 h-4" /> Save Card Securely</>
          )}
        </Button>

        <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
          <Lock className="w-3 h-3" />
          <span>Your card details are encrypted (AES-256) and stored securely</span>
        </div>
      </form>
    </div>
  );
}