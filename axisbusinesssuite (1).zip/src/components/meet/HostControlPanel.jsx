import React, { useEffect, useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  UserCheck, UserX, DoorOpen, LogOut, Plus, Trash2, Lock, LockOpen,
  DoorClosed, Users, ArrowLeftRight, Mic,
} from 'lucide-react';
import { toast } from 'sonner';

export default function HostControlPanel({ open, onOpenChange, meetingId, roomName, onEndMeeting }) {
  const [pending, setPending] = useState([]);
  const [active, setActive] = useState([]);
  const [breakoutRooms, setBreakoutRooms] = useState([]);
  const [lobbyEnabled, setLobbyEnabled] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [newRoom, setNewRoom] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    if (!meetingId || !roomName) return;
    try {
      const res = await base44.functions.invoke('meetSignaling', { action: 'get_controls', meeting_id: meetingId, room: roomName });
      if (res.data?.error) return;
      setPending(res.data.pending || []);
      setActive(res.data.active || []);
      setBreakoutRooms(res.data.breakout_rooms || []);
      setLobbyEnabled(!!res.data.lobby_enabled);
      setIsLocked(!!res.data.is_locked);
    } catch (e) { /* ignore */ }
  }, [meetingId, roomName]);

  useEffect(() => {
    if (!open) return;
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, [open, load]);

  const ctrl = async (targetPeer, command, extra = {}) => {
    setBusy(true);
    try {
      const res = await base44.functions.invoke('meetSignaling', {
        action: 'host_control', meeting_id: meetingId, room: roomName,
        target_peer: targetPeer, command, ...extra,
      });
      if (res.data?.error) toast.error(res.data.error);
      else toast.success(command.replace(/_/g, ' ') + ' ✓');
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const saveSettings = async (patch) => {
    setBusy(true);
    try {
      const res = await base44.functions.invoke('meetSignaling', {
        action: 'update_meeting_settings', meeting_id: meetingId, room: roomName, ...patch,
      });
      if (res.data?.error) toast.error(res.data.error);
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const addBreakout = () => {
    if (!newRoom.trim()) return;
    const id = newRoom.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'room';
    if (breakoutRooms.find(r => r.id === id)) { toast.error('Breakout room already exists'); return; }
    const rooms = [...breakoutRooms, { id, name: newRoom.trim() }];
    setBreakoutRooms(rooms);
    setNewRoom('');
    saveSettings({ breakout_rooms: rooms });
  };

  const removeBreakout = (id) => {
    const rooms = breakoutRooms.filter(r => r.id !== id);
    setBreakoutRooms(rooms);
    saveSettings({ breakout_rooms: rooms });
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full sm:max-w-lg">
        <SheetHeader>
          <SheetTitle>Host &amp; Admin Controls</SheetTitle>
          <SheetDescription>Waiting room, breakout rooms &amp; participant management</SheetDescription>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-6rem)] mt-4">
          <div className="space-y-5 pr-1">
            {/* Meeting-level controls */}
            <div>
              <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Meeting</h4>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant={lobbyEnabled ? 'default' : 'outline'} className="gap-1.5" disabled={busy} onClick={() => saveSettings({ lobby_enabled: !lobbyEnabled })}>
                  <DoorClosed className="w-3.5 h-3.5" /> {lobbyEnabled ? 'Waiting Room On' : 'Waiting Room Off'}
                </Button>
                <Button size="sm" variant={isLocked ? 'destructive' : 'outline'} className="gap-1.5" disabled={busy} onClick={() => saveSettings({ is_locked: !isLocked })}>
                  {isLocked ? <Lock className="w-3.5 h-3.5" /> : <LockOpen className="w-3.5 h-3.5" />} {isLocked ? 'Locked' : 'Lock Meeting'}
                </Button>
                <Button size="sm" variant="destructive" className="gap-1.5" disabled={busy} onClick={onEndMeeting}>
                  <LogOut className="w-3.5 h-3.5" /> End Meeting
                </Button>
              </div>
            </div>

            {/* Waiting room */}
            <div>
              <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2 flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5" /> Waiting Room
                {pending.length > 0 && <Badge className="ml-1">{pending.length}</Badge>}
              </h4>
              {pending.length === 0 ? (
                <p className="text-xs text-muted-foreground">No one is waiting.</p>
              ) : (
                <div className="space-y-2">
                  {pending.map(p => (
                    <div key={p.peer_id} className="flex items-center justify-between gap-2 p-2 rounded-lg border border-border bg-card">
                      <span className="text-sm truncate">{p.display_name}</span>
                      <div className="flex gap-1.5">
                        <Button size="sm" className="h-7 gap-1" disabled={busy} onClick={() => ctrl(p.peer_id, 'admit')}><UserCheck className="w-3.5 h-3.5" />Admit</Button>
                        <Button size="sm" variant="outline" className="h-7 gap-1" disabled={busy} onClick={() => ctrl(p.peer_id, 'deny')}><UserX className="w-3.5 h-3.5" />Deny</Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Breakout rooms */}
            <div>
              <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Breakout Rooms</h4>
              <div className="flex gap-2 mb-2">
                <Input value={newRoom} onChange={e => setNewRoom(e.target.value)} placeholder="New breakout room name" onKeyDown={e => e.key === 'Enter' && addBreakout()} />
                <Button size="sm" onClick={addBreakout} disabled={busy || !newRoom.trim()} className="gap-1"><Plus className="w-3.5 h-3.5" />Add</Button>
              </div>
              {breakoutRooms.length === 0 ? (
                <p className="text-xs text-muted-foreground">No breakout rooms yet. Create one, then assign participants below.</p>
              ) : (
                <div className="space-y-2">
                  {breakoutRooms.map(r => (
                    <div key={r.id} className="p-2 rounded-lg border border-border bg-card">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium flex items-center gap-1.5"><DoorOpen className="w-3.5 h-3.5 text-primary" />{r.name}</span>
                        <Button size="sm" variant="ghost" className="h-7" disabled={busy} onClick={() => removeBreakout(r.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Participants */}
            <div>
              <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Participants ({active.length})</h4>
              {active.length === 0 ? (
                <p className="text-xs text-muted-foreground">No admitted participants yet.</p>
              ) : (
                <div className="space-y-2">
                  {active.map(p => (
                    <div key={p.peer_id} className="p-2 rounded-lg border border-border bg-card">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <span className="text-sm truncate block">{p.display_name}</span>
                          {p.breakout_room && <Badge variant="secondary" className="text-[9px] h-4 mt-0.5">In: {p.breakout_room}</Badge>}
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" className="h-7" disabled={busy} onClick={() => ctrl(p.peer_id, 'mute')} title="Request mute"><Mic className="w-3.5 h-3.5" /></Button>
                          <Button size="sm" variant="ghost" className="h-7" disabled={busy} onClick={() => ctrl(p.peer_id, 'recall')} title="Recall to main room"><ArrowLeftRight className="w-3.5 h-3.5" /></Button>
                          <Button size="sm" variant="ghost" className="h-7 text-destructive" disabled={busy} onClick={() => ctrl(p.peer_id, 'kick')} title="Remove"><UserX className="w-3.5 h-3.5" /></Button>
                        </div>
                      </div>
                      {breakoutRooms.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          {breakoutRooms.map(r => (
                            <button key={r.id} disabled={busy} onClick={() => ctrl(p.peer_id, 'assign_breakout', { breakout_name: r.id })}
                              className={`text-[10px] px-1.5 py-0.5 rounded border ${p.breakout_room === r.id ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-muted'}`}>
                              {r.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}