import React, { useEffect, useRef } from 'react';

// Renders a single remote peer's media stream in a video tile.
export default function RemoteVideo({ stream, displayName }) {
  const ref = useRef(null);

  useEffect(() => {
    if (ref.current && stream) {
      ref.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className="relative rounded-xl overflow-hidden bg-black border border-border aspect-video">
      <video ref={ref} autoPlay playsInline className="w-full h-full object-cover" />
      <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-0.5 rounded text-[10px] text-white truncate max-w-[80%]">
        {displayName || 'Guest'}
      </div>
    </div>
  );
}