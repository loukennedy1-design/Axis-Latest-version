import React, { useEffect, useRef, useState } from 'react';
import { base44 } from '@/api/base44Client';
import RemoteVideo from '@/components/meet/RemoteVideo';
import { Mic, MicOff, Video as VideoIcon, VideoOff, PhoneOff, Users, AlertTriangle, Loader2, MessageSquare, DoorOpen, ShieldAlert, RotateCcw, Sparkles } from 'lucide-react';
import ChatPanel from '@/components/meet/ChatPanel';
import DeviceSelector from '@/components/meet/DeviceSelector';
import VirtualBackgroundProcessor from '@/components/meet/VirtualBackgroundProcessor';

// AXIS Meet — native WebRTC video conferencing (mesh topology).
// Signaling & presence are relayed through `meetSignaling`, which also powers
// the waiting room (lobby_status) and breakout rooms (active room switching).
//
// Glare-free: the peer with the lexicographically smaller peer_id initiates the
// offer. Local media is acquired once and kept across breakout-room switches.

export default function WebRtcMeet({ roomName, meetingId, displayName, isHost, onMeetingEnded }) {
  const localVideoRef = useRef(null);
  const localStreamRef = useRef(null);
  const bgProcessorRef = useRef(null);
  const selectedCameraRef = useRef('');
  const selectedMicRef = useRef('');
  const bgEffectRef = useRef('none');
  const peerIdRef = useRef('p_' + Math.random().toString(36).slice(2) + Date.now().toString(36));
  const peersRef = useRef(new Map());
  const participantsRef = useRef(new Map());
  const processedRef = useRef(new Set());
  const lastPollRef = useRef(new Date(Date.now() - 30000).toISOString());
  const pollTimerRef = useRef(null);

  const [mediaReady, setMediaReady] = useState(false);
  const [activeRoom, setActiveRoom] = useState(roomName);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const [localMuted, setLocalMuted] = useState(false);
  const [localVideoOn, setLocalVideoOn] = useState(false);
  const [remoteFeeds, setRemoteFeeds] = useState([]);
  const [participantCount, setParticipantCount] = useState(0);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatOpen, setChatOpen] = useState(false);
  const [waiting, setWaiting] = useState(false);
  const [removed, setRemoved] = useState(null);
  const [breakoutLabel, setBreakoutLabel] = useState('');
  const [bgOpen, setBgOpen] = useState(false);
  const [bgEffect, setBgEffect] = useState('none'); // 'none' | 'blur' | 'color'
  const [bgColor, setBgColor] = useState('#1a1a2e');

  // Classify the real getUserMedia failure by its error name so the message
  // matches the actual cause (permission denied vs. no device vs. in-use vs.
  // unsupported), instead of guessing from the Permissions API.
  const explainMediaError = (err) => {
    const name = (err && err.name) || 'Error';
    switch (name) {
      case 'NotAllowedError':
      case 'SecurityError':
        return 'Camera/mic permission was denied. Click the 🔒 lock (or ⚙️ tune) icon in the address bar → Site settings → set Camera & Microphone to "Allow" → reload, then click Retry.';
      case 'NotFoundError':
      case 'DevicesNotFoundError':
        return 'No camera or microphone was detected on this device. Connect one and click Retry.';
      case 'NotReadableError':
      case 'TrackStartError':
        return 'Your camera/mic is being used by another app (Zoom, Teams, browser tab, etc.). Close it and click Retry.';
      case 'OverconstrainedError':
        return 'No device matches the requested camera/mic settings. Click Retry, or try a different device.';
      case 'NotSupportedError':
        return 'This browser does not support camera/mic capture here. Try the latest Chrome, Edge, or Firefox.';
      default:
        return `Could not start camera/mic (${name}). Click Retry, or check your device and browser permissions.`;
    }
  };

  // Detect whether the current browsing context is actually permitted to
  // capture camera/mic. Inside a cross-origin embedded iframe (the builder
  // preview, a third-party host, etc.) the parent page's Permissions Policy
  // usually omits "camera" and "microphone", so getUserMedia() is silently
  // blocked WITHOUT ever showing the browser prompt — the #1 reason the
  // camera "won't start" in the meeting. When this returns false we steer the
  // user to open the meeting in its own tab, where the prompt can appear.
  const mediaAllowedHere = () => {
    try {
      const fp = document.featurePolicy || document.policy;
      if (fp && typeof fp.allowsFeature === 'function') {
        // Both must be allowed for a normal camera+mic join.
        return fp.allowsFeature('camera') && fp.allowsFeature('microphone');
      }
    } catch (_) { /* ignore */ }
    // We can't tell — assume allowed (top-level context) so we still try.
    return true;
  };

  // Fully release any existing camera/mic stream so the device is free for a
  // fresh request. Without this, a stale track can keep the camera "in use"
  // and cause every subsequent getUserMedia call to fail with NotReadableError.
  const stopAllTracks = () => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((t) => { try { t.stop(); } catch (e) {} });
      localStreamRef.current = null;
    }
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
  };

  const requestMedia = async () => {
    setError(null);
    // Always release the previous stream before requesting a new one — a
    // leftover track is the most common cause of a "stuck" camera.
    stopAllTracks();

    // The meeting itself (signaling, remote streams, chat) never depends on
    // the local camera/mic. So on ANY media failure we still JOIN — the user
    // can always see/hear others and chat, and retry camera/mic from inside the
    // call once the browser block is cleared. No permission state can lock the
    // user out of the meeting.
    if (typeof window !== 'undefined' && !window.isSecureContext) {
      joinWithoutMedia();
      setError('Camera & mic need a secure (HTTPS) connection — you joined without them but can still see, hear, and chat. Open the site via https://… to enable your camera/mic.');
      return;
    }
    if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      joinWithoutMedia();
      setError('This browser doesn’t support camera/mic capture — you joined without them but can still see, hear, and chat.');
      return;
    }

    const applyStream = (stream, withVideo) => {
      localStreamRef.current = stream;
      setLocalVideoOn(withVideo);
      setReady(true);
      setMediaReady(true);
      // Wait for React to paint the <video> element, then attach the
      // stream and explicitly start playback. The ref is null until the
      // element mounts, so we can't set srcObject synchronously here.
      requestAnimationFrame(() => {
        const v = localVideoRef.current;
        if (v && localStreamRef.current) {
          v.srcObject = localStreamRef.current;
          v.play().catch(() => {});
        }
      });
    };
    try {
      const videoConstraints = selectedCameraRef.current
        ? { deviceId: { exact: selectedCameraRef.current } }
        : { facingMode: 'user' };
      const audioConstraints = selectedMicRef.current
        ? { deviceId: { exact: selectedMicRef.current } }
        : true;
      const stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraints, audio: audioConstraints });
      // Virtual background is optional — if the processor throws on a browser
      // without canvas/ML support, keep the raw camera stream instead of losing
      // the camera entirely (which previously fell back to audio-only).
      try { await applyBackgroundEffect(stream); } catch (_) { /* keep raw stream */ }
      applyStream(stream, true);
    } catch (e) {
      // Audio-only fallback for permission-style failures.
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        applyStream(stream, false);
        setError((e && e.name === 'NotAllowedError' ? 'Camera permission was denied — joined with audio only. ' : '') + explainMediaError(e));
      } catch (e2) {
        // Camera AND mic unavailable (denied / blocked / no device). Still join
        // so the user can see/hear others and chat; they can retry camera/mic
        // from inside the meeting once the block is cleared.
        joinWithoutMedia();
        setError(explainMediaError(e2 && e2.name ? e2 : e) + ' You joined without camera/mic — you can still see, hear, and chat. Use the camera button once you clear the permission block.');
      }
    }
  };

  // Hard reset: tear down everything, flip back to the pre-join screen, and
  // let the user click "Enable" again for a completely fresh permission prompt.
  const resetCameraMic = () => {
    stopAllTracks();
    setReady(false);
    setMediaReady(false);
    setLocalMuted(false);
    setLocalVideoOn(false);
    setError(null);
  };

  // Audio-only join: browsers grant mic access far more readily than camera,
  // and it works in contexts where the camera prompt is silently blocked
  // (e.g. embedded preview frames). The user can start the camera separately
  // from inside the meeting once they're already connected.
  const joinAudioOnly = async () => {
    setError(null);
    stopAllTracks();
    if (typeof window !== 'undefined' && !window.isSecureContext) {
      setError('Microphone requires a secure (HTTPS) connection. Open the site via its HTTPS URL (https://…).');
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      joinWithoutMedia();
      return;
    }
    try {
      const audioConstraints = selectedMicRef.current
        ? { deviceId: { exact: selectedMicRef.current } }
        : true;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: audioConstraints });
      localStreamRef.current = stream;
      if (localVideoRef.current) localVideoRef.current.srcObject = stream;
      setLocalVideoOn(false);
      setLocalMuted(false);
      setReady(true);
      setMediaReady(true);
    } catch (e) {
      joinWithoutMedia();
      setError(explainMediaError(e) + " You joined with no media — you can still see/hear others and use chat. Try the camera/mic button once you've cleared the permission block.");
    }
  };

  // Start the camera independently, after already joining (audio-only or no
  // media). Acquires a fresh video track, attaches it to the local stream, and
  // adds it to every existing peer connection so remote participants see it.
  const startCamera = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('This browser does not support camera access. Try the latest Chrome, Edge, or Firefox.');
      return;
    }
    setError(null);
    try {
      const videoConstraints = selectedCameraRef.current
        ? { deviceId: { exact: selectedCameraRef.current } }
        : { facingMode: 'user' };
      const camStream = await navigator.mediaDevices.getUserMedia({ video: videoConstraints });
      const videoTrack = camStream.getVideoTracks()[0];
      if (!videoTrack) throw new Error('No video track returned');

      let stream = localStreamRef.current;
      if (!stream) {
        stream = new MediaStream();
        localStreamRef.current = stream;
      }
      stream.getVideoTracks().forEach((t) => { t.stop(); stream.removeTrack(t); });
      stream.addTrack(videoTrack);

      peersRef.current.forEach(({ pc }) => {
        try {
          const senders = pc.getSenders().filter((s) => s.track && s.track.kind === 'video');
          if (senders.length) senders.forEach((s) => s.replaceTrack(videoTrack));
          else pc.addTrack(videoTrack, stream);
        } catch (e) { /* ignore */ }
      });

      setLocalVideoOn(true);
      setMediaReady(true);

      // Directly attach the stream to the <video> element after React paints
      // it. The useEffect can race with the ref assignment; this guarantees
      // the srcObject is set and playback starts.
      requestAnimationFrame(() => {
        const v = localVideoRef.current;
        if (v && localStreamRef.current) {
          v.srcObject = localStreamRef.current;
          v.play().catch(() => {});
        }
      });
    } catch (e) {
      // Don't kick the user out of the meeting on camera failure — show
      // an inline error so they stay connected with audio/chat.
      setError(explainMediaError(e) + ' You are still in the meeting with audio — try the Reset button or open in a new tab.');
    }
  };

  const sendChat = async (text) => {
    setChatMessages((prev) => [...prev, { sender: 'You', text, self: true }]);
    try {
      await base44.functions.invoke('meetSignaling', {
        action: 'send_chat', meeting_id: meetingId, room: activeRoom, from_peer: peerIdRef.current, text,
      });
    } catch (e) { /* ignore */ }
  };

  // Do NOT auto-request camera/mic on mount. Browsers frequently auto-block a
  // non-user-gesture media request (instant NotAllowedError, no prompt). The
  // pre-join button calls requestMedia() from a real click, which reliably
  // surfaces the permission prompt and lets the user allow it.
  useEffect(() => {
    return () => {
      if (localStreamRef.current) localStreamRef.current.getTracks().forEach((t) => t.stop());
      if (bgProcessorRef.current) bgProcessorRef.current.stop();
    };
  }, []);

  // Attach the local stream to the <video> element and start playback.
  // Re-runs when ready/localVideoOn flip so the ref is available.
  useEffect(() => {
    if (ready && localVideoRef.current && localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
      localVideoRef.current.play().catch(() => {});
    }
  }, [ready, localVideoOn]);

  // Signaling + peer mesh, re-runs when the active room changes (breakout switch).
  useEffect(() => {
    if (!mediaReady) return;
    let disposed = false;
    setRemoteFeeds([]);
    setParticipantCount(0);
    peersRef.current.forEach((d) => { try { d.pc.close(); } catch (e) {} });
    peersRef.current.clear();
    participantsRef.current.clear();
    processedRef.current.clear();
    lastPollRef.current = new Date(Date.now() - 30000).toISOString();

    const sendSignal = async (toPeer, type, payload) => {
      try {
        await base44.functions.invoke('meetSignaling', {
          action: 'signal', meeting_id: meetingId, room: activeRoom, from_peer: peerIdRef.current, to_peer: toPeer, type, payload,
        });
      } catch (e) { /* ignore */ }
    };

    const createPeerConnection = (peerId) => {
      const pc = new RTCPeerConnection({
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.google.com:19302' },
        ],
      });
      const remoteStream = new MediaStream();
      pc.ontrack = (e) => {
        if (e.streams && e.streams[0]) e.streams[0].getTracks().forEach((t) => remoteStream.addTrack(t));
        else remoteStream.addTrack(e.track);
        setRemoteFeeds((prev) => {
          if (prev.find((f) => f.peerId === peerId)) return prev;
          return [...prev, { peerId, stream: remoteStream, name: participantsRef.current.get(peerId) || 'Guest' }];
        });
      };
      pc.onicecandidate = (e) => {
        if (e.candidate) sendSignal(peerId, 'ice', JSON.stringify(e.candidate));
      };
      if (localStreamRef.current) localStreamRef.current.getTracks().forEach((track) => pc.addTrack(track, localStreamRef.current));
      // Renegotiate automatically when a new track (e.g. camera started
      // mid-call) is added to this peer connection, so the remote side sees it.
      pc.onnegotiationneeded = async () => {
        try {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sendSignal(peerId, 'offer', JSON.stringify(offer));
        } catch (e) { /* ignore */ }
      };
      peersRef.current.set(peerId, { pc, remoteStream });
      return pc;
    };

    const initiateOffer = async (peerId) => {
      let pc = peersRef.current.get(peerId)?.pc;
      if (!pc) pc = createPeerConnection(peerId);
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await sendSignal(peerId, 'offer', JSON.stringify(offer));
      } catch (e) { /* ignore */ }
    };

    const handleParticipants = (list) => {
      setParticipantCount(list.length);
      const myPeerId = peerIdRef.current;
      list.forEach((p) => {
        participantsRef.current.set(p.peer_id, p.display_name);
        if (!peersRef.current.has(p.peer_id)) {
          if (myPeerId < p.peer_id) initiateOffer(p.peer_id);
          else createPeerConnection(p.peer_id);
        }
      });
      const presentIds = new Set(list.map((p) => p.peer_id));
      peersRef.current.forEach((data, peerId) => {
        if (!presentIds.has(peerId)) {
          try { data.pc.close(); } catch (e) {}
          peersRef.current.delete(peerId);
          participantsRef.current.delete(peerId);
          setRemoteFeeds((prev) => prev.filter((f) => f.peerId !== peerId));
        }
      });
    };

    const handleSignals = (signals) => {
      signals.forEach((sig) => {
        if (processedRef.current.has(sig.id)) return;
        processedRef.current.add(sig.id);
        const { from_peer, type, payload } = sig;
        let pc = peersRef.current.get(from_peer)?.pc;
        if (type === 'offer') {
          if (!pc) pc = createPeerConnection(from_peer);
          pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(payload)))
            .then(() => pc.createAnswer())
            .then((a) => pc.setLocalDescription(a))
            .then(() => sendSignal(from_peer, 'answer', JSON.stringify(pc.localDescription)))
            .catch(() => {});
        } else if (type === 'answer') {
          if (pc) pc.setRemoteDescription(new RTCSessionDescription(JSON.parse(payload))).catch(() => {});
        } else if (type === 'ice') {
          if (pc) { try { pc.addIceCandidate(new RTCIceCandidate(JSON.parse(payload))); } catch (e) {} }
        } else if (type === 'chat') {
          try {
            const d = JSON.parse(payload);
            setChatMessages((prev) => [...prev, { sender: d.sender || 'Guest', text: d.text || '', self: false }]);
          } catch (e) {}
        } else if (type === 'force_mute') {
          if (localStreamRef.current) {
            localStreamRef.current.getAudioTracks().forEach((t) => (t.enabled = false));
            setLocalMuted(true);
          }
        } else if (type === 'kicked') {
          try { const d = payload ? JSON.parse(payload) : {}; setRemoved({ reason: d.reason || 'removed' }); }
          catch (e) { setRemoved({ reason: 'removed' }); }
        } else if (type === 'breakout') {
          try { const d = JSON.parse(payload); if (d.room) { setBreakoutLabel(d.room); setActiveRoom(`${roomName}__${d.room}`); } } catch (e) {}
        } else if (type === 'recall') {
          setBreakoutLabel('');
          setActiveRoom(roomName);
        }
      });
    };

    const setup = async () => {
      let joinRes;
      try {
        joinRes = await base44.functions.invoke('meetSignaling', {
          action: 'join', meeting_id: meetingId, room: activeRoom, peer_id: peerIdRef.current,
          display_name: displayName || 'Guest', is_guest: !isHost,
        });
      } catch (e) { /* ignore */ }
      if (joinRes?.data?.error === 'Meeting is locked') { setRemoved({ reason: 'locked' }); return; }
      const myLobby = joinRes?.data?.lobby_status;
      setWaiting(!isHost && myLobby === 'pending');

      pollTimerRef.current = setInterval(async () => {
        const t = new Date().toISOString();
        try {
          const res = await base44.functions.invoke('meetSignaling', {
            action: 'poll', meeting_id: meetingId, room: activeRoom, peer_id: peerIdRef.current, since: lastPollRef.current,
          });
          const selfLobby = res.data?.lobby_status;
          if (!isHost && selfLobby === 'pending') { setWaiting(true); lastPollRef.current = t; return; }
          if (!isHost && selfLobby === 'denied') { setRemoved({ reason: 'denied' }); return; }
          setWaiting(false);
          if (res.data?.participants) handleParticipants(res.data.participants);
          if (res.data?.signals) handleSignals(res.data.signals);
          lastPollRef.current = t;
        } catch (e) { /* ignore */ }
      }, 2000);
    };
    setup();

    return () => {
      disposed = true;
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
      base44.functions.invoke('meetSignaling', { action: 'leave', meeting_id: meetingId, room: activeRoom, peer_id: peerIdRef.current }).catch(() => {});
      peersRef.current.forEach((d) => { try { d.pc.close(); } catch (e) {} });
      peersRef.current.clear();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeRoom, mediaReady]);

  // Redirect after being removed / denied / locked out.
  useEffect(() => {
    if (!removed) return;
    const t = setTimeout(() => { if (onMeetingEnded) onMeetingEnded(); else window.location.href = '/'; }, 2500);
    return () => clearTimeout(t);
  }, [removed]);

  const toggleMute = () => {
    if (!localStreamRef.current) return;
    const tracks = localStreamRef.current.getAudioTracks();
    tracks.forEach((t) => (t.enabled = !t.enabled));
    setLocalMuted(!tracks[0]?.enabled);
  };

  const toggleVideo = () => {
    if (!localStreamRef.current || !localStreamRef.current.getVideoTracks().length) {
      // No video track yet — start the camera (and renegotiate with peers).
      startCamera();
      return;
    }
    const tracks = localStreamRef.current.getVideoTracks();
    tracks.forEach((t) => (t.enabled = !t.enabled));
    setLocalVideoOn(!!tracks[0]?.enabled);
  };

  // Switch camera device mid-call: re-acquire the video track with the new
  // deviceId and replace it in the local stream + all peer connections.
  const handleCameraChange = async (deviceId) => {
    selectedCameraRef.current = deviceId;
    if (!localStreamRef.current || !navigator.mediaDevices?.getUserMedia) return;
    try {
      const camStream = await navigator.mediaDevices.getUserMedia({ video: { deviceId: { exact: deviceId } } });
      let videoTrack = camStream.getVideoTracks()[0];

      // Apply virtual background if active
      if (bgEffectRef.current !== 'none' && bgProcessorRef.current) {
        const processed = await bgProcessorRef.current.process(videoTrack, bgEffectRef.current, bgColor);
        if (processed && processed !== videoTrack) videoTrack = processed;
      }

      const oldVideoTracks = localStreamRef.current.getVideoTracks();
      oldVideoTracks.forEach(t => { t.stop(); localStreamRef.current.removeTrack(t); });
      localStreamRef.current.addTrack(videoTrack);

      peersRef.current.forEach(({ pc }) => {
        const senders = pc.getSenders().filter(s => s.track && s.track.kind === 'video');
        if (senders.length) senders.forEach(s => s.replaceTrack(videoTrack));
        else pc.addTrack(videoTrack, localStreamRef.current);
      });

      requestAnimationFrame(() => {
        const v = localVideoRef.current;
        if (v && localStreamRef.current) { v.srcObject = localStreamRef.current; v.play().catch(() => {}); }
      });
    } catch (e) { setError(explainMediaError(e)); }
  };

  // Switch microphone device mid-call.
  const handleMicChange = async (deviceId) => {
    selectedMicRef.current = deviceId;
    if (!localStreamRef.current || !navigator.mediaDevices?.getUserMedia) return;
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: { exact: deviceId } } });
      const audioTrack = micStream.getAudioTracks()[0];

      const oldAudioTracks = localStreamRef.current.getAudioTracks();
      oldAudioTracks.forEach(t => { t.stop(); localStreamRef.current.removeTrack(t); });
      localStreamRef.current.addTrack(audioTrack);

      peersRef.current.forEach(({ pc }) => {
        const senders = pc.getSenders().filter(s => s.track && s.track.kind === 'audio');
        if (senders.length) senders.forEach(s => s.replaceTrack(audioTrack));
        else pc.addTrack(audioTrack, localStreamRef.current);
      });
    } catch (e) { setError(explainMediaError(e)); }
  };

  // Apply or change the virtual background effect.
  const applyBackgroundEffect = async (stream) => {
    const videoTrack = stream.getVideoTracks()[0];
    if (!videoTrack) return;

    if (bgEffectRef.current === 'none') {
      if (bgProcessorRef.current) { bgProcessorRef.current.stop(); bgProcessorRef.current = null; }
      return;
    }

    if (!bgProcessorRef.current) bgProcessorRef.current = new VirtualBackgroundProcessor();
    const processed = await bgProcessorRef.current.process(videoTrack, bgEffectRef.current, bgColor);
    if (processed && processed !== videoTrack) {
      // Replace the track in the local stream
      stream.removeTrack(videoTrack);
      stream.addTrack(processed);
      // Replace in peer connections
      peersRef.current.forEach(({ pc }) => {
        const senders = pc.getSenders().filter(s => s.track && s.track.kind === 'video');
        if (senders.length) senders.forEach(s => s.replaceTrack(processed));
        else pc.addTrack(processed, stream);
      });
    }
  };

  const handleBgChange = async (effect, color) => {
    setBgEffect(effect);
    bgEffectRef.current = effect;
    if (color) setBgColor(color);
    if (localStreamRef.current) {
      // Need to re-acquire the raw video track, then re-apply
      const hasVideo = localStreamRef.current.getVideoTracks().length > 0;
      if (hasVideo) {
        // Stop existing processor
        if (bgProcessorRef.current) { bgProcessorRef.current.stop(); bgProcessorRef.current = null; }
        // Get a fresh raw track from camera
        const videoConstraints = selectedCameraRef.current
          ? { deviceId: { exact: selectedCameraRef.current } }
          : { facingMode: 'user' };
        const camStream = await navigator.mediaDevices.getUserMedia({ video: videoConstraints });
        const rawTrack = camStream.getVideoTracks()[0];
        // Remove old video tracks
        localStreamRef.current.getVideoTracks().forEach(t => { t.stop(); localStreamRef.current.removeTrack(t); });
        localStreamRef.current.addTrack(rawTrack);
        // Apply effect
        await applyBackgroundEffect(localStreamRef.current);
        // Reattach
        requestAnimationFrame(() => {
          const v = localVideoRef.current;
          if (v && localStreamRef.current) { v.srcObject = localStreamRef.current; v.play().catch(() => {}); }
        });
      }
    }
  };

  const handleLeave = () => {
    if (onMeetingEnded) onMeetingEnded();
    else window.location.href = '/';
  };

  // Graceful fallback: enter the meeting even if camera/mic are blocked in the
  // browser. The user can still see/hear others and use chat, and can enable
  // media later from the in-meeting controls after resetting permissions.
  const joinWithoutMedia = () => {
    setError(null);
    localStreamRef.current = null;
    setLocalVideoOn(false);
    setLocalMuted(true);
    setReady(true);
    setMediaReady(true);
  };

  // If we're already in the meeting and hit a camera error (e.g. mid-call
  // camera start), show the error as an inline banner instead of kicking
  // the user out of the meeting entirely.
  if (error && !ready) {
    let inIframe = false;
    try { inIframe = typeof window !== 'undefined' && window.self !== window.top; } catch (_) { inIframe = true; }
    return (
      <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center bg-black text-center p-6 gap-3">
        <AlertTriangle className="w-10 h-10 text-amber-400" />
        <p className="text-sm text-white max-w-md">{error}</p>
        <p className="text-xs text-white/60 max-w-md">
          {inIframe
            ? "The embedded app preview can’t show the camera/mic permission prompt. Open the meeting in its own browser tab to enable camera and microphone."
            : "If the prompt isn’t appearing, your browser is blocking camera/mic for this site. Open the meeting in a fresh tab (or allow Camera & Microphone via the lock icon in the address bar) to re-trigger the prompt."}
        </p>
        <div className="flex gap-2 mt-1 flex-wrap justify-center">
          <button onClick={() => window.open(window.location.href, '_blank', 'noopener')} className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90">
            Open in new tab
          </button>
          <button onClick={requestMedia} className="px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted">
            Retry
          </button>
          <button onClick={() => window.location.reload()} className="px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted">
            Reload page
          </button>
          <button onClick={resetCameraMic} className="px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted">
            Reset camera &amp; mic
          </button>
          <button onClick={joinWithoutMedia} className="px-4 py-2 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted">
            Join without camera/mic
          </button>
        </div>
      </div>
    );
  }

  if (removed) {
    const msg = removed.reason === 'denied'
      ? 'You were not admitted to the meeting.'
      : removed.reason === 'locked'
        ? 'This meeting is locked.'
        : 'You were removed from the meeting.';
    return (
      <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center bg-black text-center p-6 gap-3">
        <ShieldAlert className="w-10 h-10 text-destructive" />
        <p className="text-sm text-white max-w-md">{msg}</p>
        <p className="text-xs text-white/60">Redirecting…</p>
      </div>
    );
  }

  if (!ready) {
    let inIframe = false;
    try { inIframe = typeof window !== 'undefined' && window.self !== window.top; } catch (_) { inIframe = true; }
    const cameraBlocked = !mediaAllowedHere();
    const blockedFromIframe = inIframe && cameraBlocked;
    return (
      <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center bg-black text-center p-6 gap-4">
        <VideoIcon className="w-12 h-12 text-primary" />
        <div>
          <h3 className="text-lg font-semibold text-white">Ready to join?</h3>
          <p className="text-sm text-white/70 max-w-md mt-1">
            {blockedFromIframe
              ? "This meeting is embedded in a frame that blocks camera access. Open it in its own browser tab to allow the camera & mic prompt."
              : "Join with your camera and microphone — your browser will ask for permission."}
          </p>
        </div>

        {blockedFromIframe && (
          <div className="max-w-md w-full rounded-lg border border-amber-500/40 bg-amber-500/10 px-4 py-3 text-left text-xs text-amber-200 flex gap-2">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>The embedded preview can’t show the camera permission prompt. Open the meeting in a normal browser tab, then click “Allow” when the browser asks.</span>
          </div>
        )}

        {blockedFromIframe ? (
          <button
            onClick={() => window.open(window.location.href, '_blank', 'noopener,noreferrer')}
            className="px-6 py-3 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90"
          >
            Open in new tab to use camera
          </button>
        ) : (
          <button onClick={requestMedia} className="px-6 py-3 rounded-lg bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90">
            Join with Camera &amp; Mic
          </button>
        )}

        {!blockedFromIframe && (
          <button onClick={joinAudioOnly} className="px-6 py-2.5 rounded-lg border border-border text-foreground text-sm font-medium hover:bg-muted">
            Join with audio only
          </button>
        )}

        {inIframe && !blockedFromIframe && (
          <p className="text-xs text-white/50 max-w-md">
            If the camera prompt doesn’t appear, the embedded preview may be blocking it.{' '}
            <button onClick={() => window.open(window.location.href, '_blank', 'noopener')} className="underline text-primary">Open in a new tab</button>.
          </p>
        )}
        <button onClick={joinWithoutMedia} className="text-xs text-white/50 underline hover:text-white/70">
          Join without camera/mic
        </button>
      </div>
    );
  }

  if (waiting) {
    return (
      <div className="w-full h-full min-h-[400px] flex flex-col items-center justify-center bg-black text-center p-6 gap-3">
        <DoorOpen className="w-10 h-10 text-primary animate-pulse" />
        <p className="text-sm text-white">Waiting for the host to admit you…</p>
        <p className="text-xs text-white/60">You'll join automatically once admitted.</p>
      </div>
    );
  }

  const tiles = [
    <div key="local" className="relative rounded-xl overflow-hidden bg-black border border-border aspect-video">
      <video
        ref={localVideoRef}
        autoPlay
        muted
        playsInline
        onLoadedMetadata={(e) => e.target.play().catch(() => {})}
        className={`w-full h-full object-cover scale-x-[-1] ${localVideoOn ? '' : 'opacity-0'}`}
      />
      {!localVideoOn && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted">
          <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold text-lg">
            {(displayName || 'You').slice(0, 2).toUpperCase()}
          </div>
        </div>
      )}
      <div className="absolute bottom-2 left-2 bg-black/60 px-2 py-0.5 rounded text-[10px] text-white">You</div>
    </div>,
    ...remoteFeeds.map((f) => (
      <RemoteVideo key={f.peerId} stream={f.stream} displayName={f.name} />
    )),
  ];

  return (
    <div className="w-full h-full flex flex-col bg-black rounded-xl overflow-hidden relative">
      {/* Inline camera/mic error — doesn't kick user out of the meeting */}
      {error && ready && (
        <div className="flex items-center gap-2 px-4 py-2 bg-amber-500/15 border-b border-amber-500/30 text-amber-300 text-xs">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span className="flex-1 truncate">{error}</span>
          <button onClick={() => setError(null)} className="shrink-0 font-semibold hover:text-amber-100">Dismiss</button>
          <button onClick={startCamera} className="shrink-0 font-semibold hover:text-amber-100">Retry Camera</button>
        </div>
      )}
      {breakoutLabel && (
        <div className="absolute top-2 left-2 z-20 bg-primary text-primary-foreground text-[11px] px-2 py-1 rounded flex items-center gap-1.5">
          <DoorOpen className="w-3 h-3" />Breakout: {breakoutLabel}
        </div>
      )}
      <div className="flex-1 min-h-0 p-3 overflow-auto">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 content-center">
          {tiles}
        </div>
      </div>

      {chatOpen && (
        <div className="absolute top-2 right-2 bottom-16 w-64 sm:w-72 z-20">
          <ChatPanel messages={chatMessages} onSend={sendChat} onClose={() => setChatOpen(false)} />
        </div>
      )}

      <div className="flex items-center justify-center gap-3 px-4 py-3 bg-background/90 border-t border-border">
        <span className="text-[11px] text-muted-foreground mr-2 hidden sm:flex items-center gap-1">
          <Users className="w-3 h-3" /> {participantCount + 1} in meeting
        </span>
        <button
          onClick={toggleMute}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${localMuted ? 'bg-destructive text-white' : 'bg-secondary text-foreground hover:bg-secondary/70'}`}
          title={localMuted ? 'Unmute' : 'Mute'}
        >
          {localMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>
        <button
          onClick={toggleVideo}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${!localVideoOn ? 'bg-destructive text-white' : 'bg-secondary text-foreground hover:bg-secondary/70'}`}
          title={localVideoOn ? 'Turn off camera' : (localStreamRef.current?.getVideoTracks().length ? 'Turn on camera' : 'Start camera (request permission)')}
        >
          {localVideoOn ? <VideoIcon className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
        </button>
        {/* Virtual Background */}
        <div className="relative">
          <button
            onClick={() => setBgOpen(!bgOpen)}
            className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors ${bgEffect !== 'none' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground hover:bg-secondary/70'}`}
            title="Virtual background"
          >
            <Sparkles className="w-5 h-5" />
          </button>
          {bgOpen && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 w-56 bg-popover border border-border rounded-xl shadow-2xl z-30 overflow-hidden">
              <div className="px-4 py-2.5 border-b border-border">
                <span className="text-xs font-semibold">Background Effect</span>
              </div>
              <div className="p-2 space-y-1">
                <button
                  onClick={() => { handleBgChange('none'); setBgOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors ${bgEffect === 'none' ? 'bg-primary/15 text-primary' : 'hover:bg-muted'}`}
                >
                  <div className="w-5 h-5 rounded border border-border bg-background" />
                  None
                </button>
                <button
                  onClick={() => { handleBgChange('blur'); setBgOpen(false); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors ${bgEffect === 'blur' ? 'bg-primary/15 text-primary' : 'hover:bg-muted'}`}
                >
                  <div className="w-5 h-5 rounded border border-border bg-gradient-to-br from-muted to-muted/50" />
                  Soft Focus Blur
                </button>
                <button
                  onClick={() => { handleBgChange('color', bgColor); }}
                  className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs transition-colors ${bgEffect === 'color' ? 'bg-primary/15 text-primary' : 'hover:bg-muted'}`}
                >
                  <div className="w-5 h-5 rounded border border-border" style={{ backgroundColor: bgColor }} />
                  Solid Color
                </button>
                {bgEffect === 'color' && (
                  <div className="flex gap-1.5 px-3 py-1">
                    {['#1a1a2e', '#16213e', '#0f3460', '#2d3436', '#2d4059', '#1B1B1B'].map(c => (
                      <button
                        key={c}
                        onClick={() => handleBgChange('color', c)}
                        className={`w-6 h-6 rounded-full border-2 ${bgColor === c ? 'border-primary' : 'border-transparent'}`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Device Selector */}
        <DeviceSelector
          onCameraChange={handleCameraChange}
          onMicChange={handleMicChange}
        />

        <button
          onClick={resetCameraMic}
          className="w-11 h-11 rounded-full bg-secondary text-foreground hover:bg-secondary/70 flex items-center justify-center transition-colors"
          title="Reset camera & mic (re-request permissions)"
        >
          <RotateCcw className="w-5 h-5" />
        </button>
        <button
          onClick={() => setChatOpen(o => !o)}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-colors relative ${chatOpen ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground hover:bg-secondary/70'}`}
          title="Chat"
        >
          <MessageSquare className="w-5 h-5" />
          {chatMessages.length > 0 && !chatOpen && (
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-primary" />
          )}
        </button>
        <button
          onClick={handleLeave}
          className="w-11 h-11 rounded-full bg-destructive text-white flex items-center justify-center hover:bg-destructive/90 transition-colors"
          title="Leave meeting"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}