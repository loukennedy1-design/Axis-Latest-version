import React, { useState, useEffect } from 'react';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Calendar, Clock, Users, Mail, Link2, Video, Loader2, Send, Copy, Check, CalendarRange, Sparkles, Repeat } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const WEEKDAYS = [
  { idx: 1, label: 'Mon' }, { idx: 2, label: 'Tue' }, { idx: 3, label: 'Wed' },
  { idx: 4, label: 'Thu' }, { idx: 5, label: 'Fri' }, { idx: 6, label: 'Sat' }, { idx: 0, label: 'Sun' },
];

export default function ScheduleMeetingDialog({ open, onOpenChange, prefill }) {
  const { user } = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [meetingLink, setMeetingLink] = useState('');
  const [windowMode, setWindowMode] = useState(false); // false = specific, true = window
  const [copied, setCopied] = useState(false);
  const [occurrences, setOccurrences] = useState([]);
  const [form, setForm] = useState({
    title: '',
    department: 'sales',
    scheduled_at: '',
    duration_minutes: 30,
    linked_record_type: 'none',
    linked_record_id: '',
    guest_name: '',
    guest_email: '',
    selected_user_ids: [],
    send_invite: true,
    // ── window scheduling ──
    window_start_date: '',
    window_end_date: '',
    working_days: [1, 2, 3, 4, 5],
    day_start: '09:00',
    day_end: '17:00',
    generated_slots: [],
    // ── recurring ──
    recurrence_enabled: false,
    recurrence_type: 'weekly',
    recurrence_count: 8,
    recurrence_end_date: '',
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list(),
    enabled: open,
  });

  // Filter users to same subscriber account (super_admin sees all)
  const subscriberEmail = user?.account_owner_email || user?.email;
  const isSuperAdmin = user?.role === 'super_admin';
  const scopedUsers = isSuperAdmin
    ? allUsers
    : allUsers.filter(u => u.account_owner_email === subscriberEmail || u.email === subscriberEmail);

  useEffect(() => {
    if (open && prefill) {
      setForm(f => ({ ...f, ...prefill }));
    } else if (open) {
      setForm({
        title: '', department: 'sales', scheduled_at: '', duration_minutes: 30,
        linked_record_type: 'none', linked_record_id: '', guest_name: '', guest_email: '',
        selected_user_ids: [], send_invite: true,
        window_start_date: '', window_end_date: '', working_days: [1, 2, 3, 4, 5],
        day_start: '09:00', day_end: '17:00', generated_slots: [],
        recurrence_enabled: false, recurrence_type: 'weekly', recurrence_count: 8, recurrence_end_date: '',
      });
      setMeetingLink(''); setCopied(false); setWindowMode(false); setOccurrences([]);
    }
  }, [open, prefill]);

  // Generate available slots from the host's availability window (Zoom-style).
  const generateSlots = () => {
    if (!form.window_start_date || !form.window_end_date) { toast.error('Pick a start and end date for your window'); return; }
    if (!form.day_start || !form.day_end) { toast.error('Set your daily available hours'); return; }
    if (form.working_days.length === 0) { toast.error('Select at least one working day'); return; }
    const [sh, sm] = form.day_start.split(':').map(Number);
    const [eh, em] = form.day_end.split(':').map(Number);
    if (sh * 60 + sm >= eh * 60 + em) { toast.error('Daily end time must be after start time'); return; }
    const dur = form.duration_minutes || 30;
    const slots = [];
    const cur = new Date(form.window_start_date + 'T00:00:00');
    const end = new Date(form.window_end_date + 'T00:00:00');
    if (end < cur) { toast.error('End date must be after start date'); return; }
    while (cur <= end) {
      if (form.working_days.includes(cur.getDay())) {
        const dayStart = new Date(cur); dayStart.setHours(sh, sm, 0, 0);
        const dayEnd = new Date(cur); dayEnd.setHours(eh, em, 0, 0);
        const t = new Date(dayStart);
        while (t.getTime() + dur * 60000 <= dayEnd.getTime()) {
          slots.push(new Date(t).toISOString());
          t.setMinutes(t.getMinutes() + dur);
        }
      }
      cur.setDate(cur.getDate() + 1);
    }
    if (slots.length === 0) { toast.error('No slots in that range — check your working days and hours'); return; }
    if (slots.length > 60) {
      setForm({ ...form, generated_slots: slots.slice(0, 60) });
      toast.success(`${slots.length} slots available — showing the first 60`);
    } else {
      setForm({ ...form, generated_slots: slots });
      toast.success(`${slots.length} available slots generated`);
    }
  };

  const toggleDay = (idx) => {
    setForm(f => ({
      ...f,
      working_days: f.working_days.includes(idx)
        ? f.working_days.filter(d => d !== idx)
        : [...f.working_days, idx].sort(),
    }));
  };

  const handleCreate = async () => {
    if (!form.title.trim()) { toast.error('Enter a meeting title'); return; }
    if (windowMode) {
      if (form.generated_slots.length === 0) { toast.error('Generate available slots first'); return; }
    } else {
      if (!form.scheduled_at) { toast.error('Select a date & time'); return; }
    }
    setLoading(true);
    try {
      const payload = {
        action: 'create_meeting',
        title: form.title,
        department: form.department,
        duration_minutes: form.duration_minutes,
        linked_record_id: form.linked_record_id,
        linked_record_type: form.linked_record_type,
        guest_name: form.guest_name,
      };
      if (windowMode) {
        payload.scheduling_mode = 'window';
        payload.availability_window = JSON.stringify({
          start_date: form.window_start_date,
          end_date: form.window_end_date,
          working_days: form.working_days,
          day_start: form.day_start,
          day_end: form.day_end,
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        });
        payload.proposed_slots = JSON.stringify(form.generated_slots);
        payload.slot_duration_minutes = form.duration_minutes;
        payload.guest_email = form.send_invite && form.guest_email ? form.guest_email : '';
      } else {
        payload.scheduled_at = new Date(form.scheduled_at).toISOString();
        payload.scheduling_mode = 'specific';
        payload.guest_email = form.send_invite && form.guest_email ? form.guest_email : '';
        if (form.recurrence_enabled) {
          payload.recurrence_type = form.recurrence_type;
          payload.recurrence_count = Math.min(Math.max(form.recurrence_count || 2, 2), 24);
          payload.recurrence_end_date = form.recurrence_end_date ? new Date(form.recurrence_end_date + 'T23:59:59').toISOString() : '';
        }
      }

      const selectedUsers = scopedUsers.filter(u => form.selected_user_ids.includes(u.id));
      const allInvitees = [
        ...(form.send_invite && form.guest_email ? [form.guest_email] : []),
        ...selectedUsers.map(u => u.email),
      ].filter(Boolean);
      payload.invite_emails = allInvitees;

      const res = await base44.functions.invoke('meetingIntelligence', payload);
      if (res.data?.error) throw new Error(res.data.error);
      qc.invalidateQueries({ queryKey: ['internal-meetings'] });

      setMeetingLink(res.data.guest_join_url);
      setOccurrences(res.data.recurring && res.data.occurrence_count > 1 ? (res.data.occurrences || []) : []);

      if (!windowMode && allInvitees.length > 0) {
        try {
          await base44.functions.invoke('syncMeetingToCalendar', {
            meeting_id: res.data.meeting.meeting_id,
            invite_emails: allInvitees,
          });
          toast.success(res.data.recurring ? `Recurring series created — ${res.data.occurrence_count} sessions, invites sent to ${allInvitees.length} attendee(s)` : `Meeting scheduled — invites sent to ${allInvitees.length} attendee(s)`);
        } catch (e) {
          toast.success('Meeting scheduled — calendar sync pending');
        }
      } else if (windowMode) {
        toast.success(form.guest_email
          ? `Availability sent — ${form.generated_slots.length} time options emailed to ${form.guest_email}`
          : 'Meeting created — share the link so your guest can pick a time');
      } else {
        toast.success(res.data.recurring ? `Recurring series created — ${res.data.occurrence_count} sessions` : 'Meeting scheduled');
      }

      // For a recurring series, stay on the dialog so the host can copy each
      // occurrence link; only auto-join for single one-off meetings.
      if (!windowMode && !(res.data.recurring && res.data.occurrence_count > 1)) {
        navigate(`/meet/room/${res.data.meeting.meeting_id}`);
      }
    } catch (e) {
      toast.error(e.message || 'Failed to schedule meeting');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />Schedule AXIS Meet
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Meeting Title *</Label>
            <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. Sales Demo with Acme Corp" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Department</Label>
              <Select value={form.department} onValueChange={v => setForm({ ...form, department: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="hr">HR</SelectItem>
                  <SelectItem value="recruitment">Recruitment</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Duration</Label>
              <Select value={String(form.duration_minutes)} onValueChange={v => setForm({ ...form, duration_minutes: parseInt(v), generated_slots: [] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['15', '30', '45', '60', '90'].map(d => <SelectItem key={d} value={d}>{d} min</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* ── Scheduling mode toggle ── */}
          <div>
            <Label className="mb-1.5 block">Scheduling</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setWindowMode(false)}
                className={`flex items-center gap-2 rounded-lg border p-3 text-left transition-colors ${!windowMode ? 'border-primary bg-primary/10' : 'border-border bg-muted/30 hover:bg-muted/50'}`}
              >
                <Calendar className="w-4 h-4 text-primary" />
                <div>
                  <p className="text-sm font-semibold">Specific date</p>
                  <p className="text-[10px] text-muted-foreground">Pick one firm time</p>
                </div>
              </button>
              <button
                type="button"
                onClick={() => setWindowMode(true)}
                className={`flex items-center gap-2 rounded-lg border p-3 text-left transition-colors ${windowMode ? 'border-primary bg-primary/10' : 'border-border bg-muted/30 hover:bg-muted/50'}`}
              >
                <CalendarRange className="w-4 h-4 text-primary" />
                <div>
                  <p className="text-sm font-semibold">Availability window</p>
                  <p className="text-[10px] text-muted-foreground">Offer times, they pick</p>
                </div>
              </button>
            </div>
          </div>

          {/* ── Specific mode: single date/time ── */}
          {!windowMode && (
            <div className="space-y-3">
              <div>
                <Label>Date & Time *</Label>
                <Input type="datetime-local" value={form.scheduled_at} onChange={e => setForm({ ...form, scheduled_at: e.target.value })} />
              </div>
              <div className="rounded-lg border border-border p-3 space-y-3">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="checkbox" checked={form.recurrence_enabled} onChange={e => setForm({ ...form, recurrence_enabled: e.target.checked })} className="rounded border-muted-foreground accent-primary" />
                  <Repeat className="w-4 h-4 text-primary" />
                  <span className="font-medium">Recurring meeting</span>
                </label>
                {form.recurrence_enabled && (
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <Label className="text-xs">Repeat</Label>
                      <Select value={form.recurrence_type} onValueChange={v => setForm({ ...form, recurrence_type: v })}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Biweekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-xs">Occurrences</Label>
                      <Input type="number" min={2} max={24} value={form.recurrence_count} onChange={e => setForm({ ...form, recurrence_count: Math.min(Math.max(parseInt(e.target.value) || 2, 2), 24) })} />
                    </div>
                    <div>
                      <Label className="text-xs">End by (opt.)</Label>
                      <Input type="date" value={form.recurrence_end_date} onChange={e => setForm({ ...form, recurrence_end_date: e.target.value })} />
                    </div>
                  </div>
                )}
                {form.recurrence_enabled && (
                  <p className="text-[10px] text-muted-foreground">Creates up to 24 separate sessions (max), each with its own join link. All appear in your Upcoming list.</p>
                )}
              </div>
            </div>
          )}

          {/* ── Window mode: availability builder ── */}
          {windowMode && (
            <div className="space-y-4 rounded-xl border border-border bg-muted/20 p-4">
              <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                Offer a range of dates. AXIS generates time slots from your working hours — your guest picks the one that works, just like Zoom.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Window start *</Label>
                  <Input type="date" value={form.window_start_date} onChange={e => setForm({ ...form, window_start_date: e.target.value, generated_slots: [] })} />
                </div>
                <div>
                  <Label className="text-xs">Window end *</Label>
                  <Input type="date" value={form.window_end_date} onChange={e => setForm({ ...form, window_end_date: e.target.value, generated_slots: [] })} />
                </div>
              </div>
              <div>
                <Label className="text-xs mb-1.5 block">Working days</Label>
                <div className="flex flex-wrap gap-1.5">
                  {WEEKDAYS.map(d => (
                    <button
                      key={d.idx}
                      type="button"
                      onClick={() => toggleDay(d.idx)}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${form.working_days.includes(d.idx) ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border text-muted-foreground hover:bg-muted'}`}
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">Daily start</Label>
                  <Input type="time" value={form.day_start} onChange={e => setForm({ ...form, day_start: e.target.value, generated_slots: [] })} />
                </div>
                <div>
                  <Label className="text-xs">Daily end</Label>
                  <Input type="time" value={form.day_end} onChange={e => setForm({ ...form, day_end: e.target.value, generated_slots: [] })} />
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={generateSlots} className="w-full gap-1.5">
                <Clock className="w-3.5 h-3.5" />Generate available slots
              </Button>
              {form.generated_slots.length > 0 && (
                <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-emerald-400">{form.generated_slots.length} slots ready</p>
                    <Badge variant="outline" className="text-[10px] text-emerald-400 border-emerald-500/30">{form.duration_minutes} min each</Badge>
                  </div>
                  <div className="max-h-32 overflow-y-auto space-y-1 pr-1">
                    {form.generated_slots.slice(0, 24).map((s, i) => (
                      <div key={i} className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-emerald-500" />
                        {format(new Date(s), 'EEE, MMM d · h:mm a')}
                      </div>
                    ))}
                    {form.generated_slots.length > 24 && <p className="text-[10px] text-muted-foreground pt-1">+{form.generated_slots.length - 24} more…</p>}
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-2">The guest will see these and pick one from the join link.</p>
                </div>
              )}
            </div>
          )}

          {/* ── Internal users (scoped to your account) ── */}
          <div>
            <Label className="flex items-center gap-2"><Users className="w-4 h-4" />Invite Internal Users</Label>
            <div className="border rounded-lg p-3 max-h-40 overflow-y-auto mt-2 bg-muted/30">
              {scopedUsers.length === 0 ? (
                <p className="text-sm text-muted-foreground">No team members found</p>
              ) : (
                scopedUsers.filter(u => u.email !== user.email).map(u => (
                  <label key={u.id} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 p-2 rounded transition-colors">
                    <input
                      type="checkbox"
                      checked={form.selected_user_ids.includes(u.id)}
                      onChange={e => setForm(f => ({
                        ...f,
                        selected_user_ids: e.target.checked
                          ? [...f.selected_user_ids, u.id]
                          : f.selected_user_ids.filter(id => id !== u.id),
                      }))}
                      className="rounded border-muted-foreground accent-primary"
                    />
                    <span className="font-medium">{u.full_name || u.email}</span>
                    <span className="text-xs text-muted-foreground ml-auto">({u.email})</span>
                  </label>
                ))
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Internal users get calendar invites once a time is confirmed.</p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Guest Name</Label>
              <Input value={form.guest_name} onChange={e => setForm({ ...form, guest_name: e.target.value })} placeholder="Optional" />
            </div>
            <div>
              <Label>Guest Email</Label>
              <Input value={form.guest_email} onChange={e => setForm({ ...form, guest_email: e.target.value })} placeholder="Optional" />
            </div>
          </div>

          {occurrences.length > 1 && (
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <Label className="flex items-center gap-2 text-primary"><Repeat className="w-4 h-4" />Recurring Series — {occurrences.length} sessions</Label>
              <div className="max-h-32 overflow-y-auto space-y-1 mt-2 pr-1">
                {occurrences.map((o, i) => (
                  <div key={o.meeting_id} className="text-[11px] text-muted-foreground flex items-center justify-between gap-2">
                    <span>#{i + 1} · {format(new Date(o.scheduled_at), 'EEE, MMM d · h:mm a')}</span>
                    <button onClick={() => { navigator.clipboard.writeText(o.guest_join_url); toast.success('Link copied'); }} className="text-primary hover:underline shrink-0">Copy</button>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-2">Each session has its own join link and appears in your Upcoming list.</p>
            </div>
          )}

          {meetingLink && (
            <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <Label className="flex items-center gap-2 text-primary"><Link2 className="w-4 h-4" />Meeting Join Link</Label>
              <div className="flex items-center gap-2 mt-2">
                <Input value={meetingLink} readOnly className="text-xs bg-background" />
                <Button size="sm" variant="outline" onClick={() => { navigator.clipboard.writeText(meetingLink); setCopied(true); setTimeout(() => setCopied(false), 2000); }}>
                  {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {windowMode ? 'Share this link — your guest will pick a time, then enter the waiting room.' : 'Share this link with anyone outside your team'}
              </p>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={loading} className="gap-1.5">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {windowMode ? 'Send Availability' : 'Schedule Meeting'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}