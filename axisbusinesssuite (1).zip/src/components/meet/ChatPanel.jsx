import React, { useState, useRef, useEffect } from 'react';
import { Send, X } from 'lucide-react';

export default function ChatPanel({ messages, onSend, onClose }) {
  const [text, setText] = useState('');
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = () => {
    if (!text.trim()) return;
    onSend(text.trim());
    setText('');
  };

  return (
    <div className="flex flex-col h-full bg-card rounded-xl border border-border overflow-hidden">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-border">
        <span className="font-semibold text-sm">Meeting Chat</span>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2 min-h-0">
        {messages.length === 0 ? (
          <p className="text-xs text-muted-foreground text-center mt-8">No messages yet. Say hello!</p>
        ) : (
          messages.map((m, i) => (
            <div key={i} className={`flex flex-col ${m.self ? 'items-end' : 'items-start'}`}>
              <span className="text-[10px] text-muted-foreground mb-0.5">{m.sender}</span>
              <div className={`max-w-[85%] px-3 py-1.5 rounded-lg text-xs break-words ${m.self ? 'bg-primary text-primary-foreground' : 'bg-muted text-foreground'}`}>
                {m.text}
              </div>
            </div>
          ))
        )}
      </div>
      <div className="p-2.5 border-t border-border flex gap-2">
        <input
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder="Type a message..."
          className="flex-1 bg-background border border-border rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:ring-1 focus:ring-ring"
        />
        <button
          onClick={handleSend}
          className="bg-primary text-primary-foreground rounded-lg px-3 py-1.5 flex items-center justify-center hover:bg-primary/90 transition-colors"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}