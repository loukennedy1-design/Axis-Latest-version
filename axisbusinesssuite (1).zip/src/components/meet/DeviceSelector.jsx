import React, { useState, useEffect, useRef } from 'react';
import { Mic, Video, ChevronDown, RefreshCw, Check } from 'lucide-react';

/**
 * DeviceSelector — enumerates cameras and microphones, lets the user
 * pick which device to use, and calls onDeviceChange with the selected
 * deviceId so the parent can re-acquire the stream.
 */
export default function DeviceSelector({ onCameraChange, onMicChange, className = '' }) {
  const [cameras, setCameras] = useState([]);
  const [mics, setMics] = useState([]);
  const [selectedCamera, setSelectedCamera] = useState('');
  const [selectedMic, setSelectedMic] = useState('');
  const [open, setOpen] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const ref = useRef(null);

  const enumerate = async () => {
    setRefreshing(true);
    try {
      // Must request permission first to get device labels
      if (!navigator.mediaDevices?.enumerateDevices) return;
      const devices = await navigator.mediaDevices.enumerateDevices();
      setCameras(devices.filter(d => d.kind === 'videoinput'));
      setMics(devices.filter(d => d.kind === 'audioinput'));

      // Auto-select first device if nothing chosen
      if (!selectedCamera && devices.find(d => d.kind === 'videoinput')) {
        setSelectedCamera(devices.find(d => d.kind === 'videoinput').deviceId);
      }
      if (!selectedMic && devices.find(d => d.kind === 'audioinput')) {
        setSelectedMic(devices.find(d => d.kind === 'audioinput').deviceId);
      }
    } catch (e) { /* ignore */ }
    setRefreshing(false);
  };

  useEffect(() => {
    enumerate();
    // Re-enumerate when devices change (plug/unplug)
    navigator.mediaDevices?.addEventListener?.('devicechange', enumerate);
    return () => navigator.mediaDevices?.removeEventListener?.('devicechange', enumerate);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const pickCamera = (deviceId) => {
    setSelectedCamera(deviceId);
    onCameraChange?.(deviceId);
    setOpen(false);
  };

  const pickMic = (deviceId) => {
    setSelectedMic(deviceId);
    onMicChange?.(deviceId);
    setOpen(false);
  };

  const label = (device, fallback) => device?.label || fallback;

  return (
    <div ref={ref} className={`relative ${className}`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-11 h-11 rounded-full bg-secondary text-foreground hover:bg-secondary/70 flex items-center justify-center transition-colors"
        title="Device settings"
      >
        {open ? <ChevronDown className="w-5 h-5 rotate-180" /> : <ChevronDown className="w-5 h-5" />}
      </button>

      {open && (
        <div className="absolute bottom-14 right-0 w-72 bg-popover border border-border rounded-xl shadow-2xl z-30 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <span className="text-sm font-semibold">Device Settings</span>
            <button onClick={enumerate} className="text-muted-foreground hover:text-foreground" title="Refresh devices">
              <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {/* Microphone */}
          <div className="px-4 py-3 border-b border-border">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
              <Mic className="w-3 h-3" />Microphone
            </p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {mics.length === 0 ? (
                <p className="text-xs text-muted-foreground py-1">No microphones found</p>
              ) : mics.map((mic, i) => (
                <button
                  key={mic.deviceId || i}
                  onClick={() => pickMic(mic.deviceId)}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-left transition-colors ${selectedMic === mic.deviceId ? 'bg-primary/15 text-primary' : 'hover:bg-muted'}`}
                >
                  <span className="flex-1 truncate">{label(mic, `Microphone ${i + 1}`)}</span>
                  {selectedMic === mic.deviceId && <Check className="w-3 h-3 shrink-0" />}
                </button>
              ))}
            </div>
          </div>

          {/* Camera */}
          <div className="px-4 py-3">
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1.5">
              <Video className="w-3 h-3" />Camera
            </p>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {cameras.length === 0 ? (
                <p className="text-xs text-muted-foreground py-1">No cameras found</p>
              ) : cameras.map((cam, i) => (
                <button
                  key={cam.deviceId || i}
                  onClick={() => pickCamera(cam.deviceId)}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs text-left transition-colors ${selectedCamera === cam.deviceId ? 'bg-primary/15 text-primary' : 'hover:bg-muted'}`}
                >
                  <span className="flex-1 truncate">{label(cam, `Camera ${i + 1}`)}</span>
                  {selectedCamera === cam.deviceId && <Check className="w-3 h-3 shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}