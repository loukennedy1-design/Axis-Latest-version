import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Mail, Copy, Check, Link2 } from 'lucide-react';

export default function InviteDialog({ meeting, open, onOpenChange }) {
  const [copied, setCopied] = useState(false);

  if (!meeting) return null;

  const inviteLink = meeting.guest_join_url || '';

  const copyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-primary" />Invite to Meeting
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
            <Label className="flex items-center gap-2 text-primary">
              <Link2 className="w-4 h-4" />
              Guest Join Link
            </Label>
            <div className="flex items-center gap-2 mt-2">
              <Input value={inviteLink} readOnly className="text-xs bg-background" />
              <Button size="sm" variant="outline" onClick={copyLink}>
                {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copied!' : 'Copy'}
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Share this link with guests — they'll enter the waiting room when they join</p>
          </div>

          <div className="flex justify-end pt-2">
            <Button onClick={() => onOpenChange(false)}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}