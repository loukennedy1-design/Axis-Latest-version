import React, { useState, useEffect } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Video, Loader2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function EditMeetingDialog({ meeting, open, onOpenChange }) {
  const qc = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: '',
    department: 'sales',
    scheduled_at: '',
    duration_minutes: 30,
  });

  useEffect(() => {
    if (meeting && open) {
      setForm({
        title: meeting.title || '',
        department: meeting.department || 'sales',
        scheduled_at: meeting.scheduled_at
          ? format(new Date(meeting.scheduled_at), "yyyy-MM-dd'T'HH:mm")
          : '',
        duration_minutes: meeting.duration_minutes || 30,
      });
    }
  }, [meeting, open]);

  const handleSave = async () => {
    if (!form.title.trim()) { toast.error('Enter a meeting title'); return; }
    if (!form.scheduled_at) { toast.error('Select a date & time'); return; }
    setLoading(true);
    try {
      const res = await base44.functions.invoke('meetingIntelligence', {
        action: 'update_meeting',
        meeting_id: meeting.meeting_id,
        title: form.title,
        department: form.department,
        scheduled_at: new Date(form.scheduled_at).toISOString(),
        duration_minutes: form.duration_minutes,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Meeting updated');
      qc.invalidateQueries({ queryKey: ['internal-meetings'] });
      qc.invalidateQueries({ queryKey: ['internal-meeting', meeting.meeting_id] });
      onOpenChange(false);
    } catch (e) {
      toast.error(e.message || 'Failed to update meeting');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-primary" />Edit Meeting
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label>Meeting Title *</Label>
            <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Meeting title" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Department</Label>
              <Select value={form.department} onValueChange={v => setForm({ ...form, department: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="hr">HR</SelectItem>
                  <SelectItem value="recruitment">Recruitment</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Duration</Label>
              <Select value={String(form.duration_minutes)} onValueChange={v => setForm({ ...form, duration_minutes: parseInt(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['15', '30', '45', '60', '90'].map(d => <SelectItem key={d} value={d}>{d} min</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Date & Time *</Label>
            <Input type="datetime-local" value={form.scheduled_at} onChange={e => setForm({ ...form, scheduled_at: e.target.value })} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={loading} className="gap-1.5">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Changes
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}