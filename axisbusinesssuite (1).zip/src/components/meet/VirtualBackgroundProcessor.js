/**
 * VirtualBackgroundProcessor — canvas-based video track processor.
 *
 * Applies a blur or solid-color background to a video stream by:
 * 1. Drawing the video frame to an offscreen canvas
 * 2. Applying the selected effect (blur, color overlay, or none)
 * 3. Capturing the canvas as a new MediaStream track
 *
 * Returns the processed track for use in peer connections.
 *
 * Note: True person segmentation requires an ML model. This processor
 * applies a full-frame blur or color wash effect — not background-only.
 * For true background removal, a segmentation model (MediaPipe) would
 * need to be loaded, which is beyond the current package set.
 */
export default class VirtualBackgroundProcessor {
  constructor() {
    this.canvas = null;
    this.ctx = null;
    this.video = null;
    this.animationId = null;
    this.active = false;
    this.effect = 'none'; // 'none' | 'blur' | 'color'
    this.color = '#1a1a2e';
  }

  /**
   * Process a video track and return a new track with the effect applied.
   * @param {MediaStreamTrack} videoTrack - the original camera track
   * @param {string} effect - 'none' | 'blur' | 'color'
   * @param {string} color - hex color for 'color' effect
   * @returns {MediaStreamTrack} - the processed track (or original if 'none')
   */
  async process(videoTrack, effect, color) {
    this.stop();
    this.effect = effect;
    this.color = color || '#1a1a2e';

    if (effect === 'none' || !videoTrack) {
      return videoTrack;
    }

    // Set up elements
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d');
    this.video = document.createElement('video');
    this.video.srcObject = new MediaStream([videoTrack]);
    this.video.muted = true;
    this.video.playsInline = true;

    await new Promise((resolve) => {
      this.video.onloadedmetadata = () => {
        this.canvas.width = this.video.videoWidth || 640;
        this.canvas.height = this.video.videoHeight || 480;
        this.video.play().then(resolve).catch(resolve);
      };
    });

    this.active = true;
    this.draw();

    const processedStream = this.canvas.captureStream(30);
    return processedStream.getVideoTracks()[0];
  }

  draw() {
    if (!this.active || !this.ctx || !this.video) return;

    const w = this.canvas.width;
    const h = this.canvas.height;

    if (this.effect === 'blur') {
      // Draw blurred frame, then sharp frame on top with slight transparency
      // for a "soft focus" cinematic effect
      this.ctx.filter = 'blur(12px) brightness(0.9)';
      this.ctx.drawImage(this.video, 0, 0, w, h);
      this.ctx.filter = 'blur(3px)';
      this.ctx.globalAlpha = 0.7;
      this.ctx.drawImage(this.video, 0, 0, w, h);
      this.ctx.filter = 'none';
      this.ctx.globalAlpha = 1;
    } else if (this.effect === 'color') {
      // Solid color background with the video overlaid
      this.ctx.fillStyle = this.color;
      this.ctx.fillRect(0, 0, w, h);
      this.ctx.globalAlpha = 0.85;
      this.ctx.drawImage(this.video, 0, 0, w, h);
      this.ctx.globalAlpha = 1;
    } else {
      // No effect — passthrough
      this.ctx.drawImage(this.video, 0, 0, w, h);
    }

    this.animationId = requestAnimationFrame(() => this.draw());
  }

  stop() {
    this.active = false;
    if (this.animationId) cancelAnimationFrame(this.animationId);
    this.animationId = null;
    if (this.video) {
      try { this.video.pause(); } catch (e) {}
      this.video.srcObject = null;
      this.video = null;
    }
    this.canvas = null;
    this.ctx = null;
  }
}