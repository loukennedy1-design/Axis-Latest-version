import React from 'react';
import { Sparkles, ListChecks, Gavel, CheckCircle2 } from 'lucide-react';

export default function MeetingBreakdown({ meeting }) {
  let breakdown = null;
  if (meeting?.ai_summary) {
    try {
      breakdown = JSON.parse(meeting.ai_summary);
    } catch (_) {
      // Plain text summary — render as-is
    }
  }

  if (!breakdown) {
    return (
      <div className="space-y-2">
        <div className="flex items-center gap-1.5 mb-1.5">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
          <p className="text-xs font-semibold text-primary">AI Summary</p>
        </div>
        <p className="text-xs text-muted-foreground whitespace-pre-wrap line-clamp-4">{meeting?.ai_summary || 'No summary generated'}</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {breakdown.summary && (
        <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
          <div className="flex items-center gap-1.5 mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <p className="text-xs font-semibold text-primary">Summary</p>
          </div>
          <p className="text-xs text-muted-foreground line-clamp-3">{breakdown.summary}</p>
        </div>
      )}
      {Array.isArray(breakdown.key_topics) && breakdown.key_topics.length > 0 && (
        <div>
          <p className="text-xs font-semibold mb-1.5 flex items-center gap-1.5">
            <ListChecks className="w-3.5 h-3.5 text-blue-500" />Key Topics
          </p>
          <ul className="space-y-1">
            {breakdown.key_topics.slice(0, 5).map((t, i) => (
              <li key={i} className="text-xs text-muted-foreground flex gap-1.5">
                <span className="text-blue-500 shrink-0">•</span>{t}
              </li>
            ))}
          </ul>
        </div>
      )}
      {Array.isArray(breakdown.decisions) && breakdown.decisions.length > 0 && (
        <div>
          <p className="text-xs font-semibold mb-1.5 flex items-center gap-1.5">
            <Gavel className="w-3.5 h-3.5 text-purple-500" />Decisions
          </p>
          <ul className="space-y-1">
            {breakdown.decisions.slice(0, 4).map((d, i) => (
              <li key={i} className="text-xs text-muted-foreground flex gap-1.5">
                <span className="text-purple-500 shrink-0">•</span>{d}
              </li>
            ))}
          </ul>
        </div>
      )}
      {Array.isArray(breakdown.action_items) && breakdown.action_items.length > 0 && (
        <div>
          <p className="text-xs font-semibold mb-1.5 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />Action Items
          </p>
          <div className="space-y-1.5">
            {breakdown.action_items.slice(0, 5).map((item, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium shrink-0 ${
                  item.priority === 'high' ? 'bg-red-500/10 text-red-500' :
                  item.priority === 'medium' ? 'bg-amber-500/10 text-amber-500' :
                  'bg-blue-500/10 text-blue-500'
                }`}>{item.priority || 'medium'}</span>
                <span className="text-muted-foreground flex-1 line-clamp-2">{item.description}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}