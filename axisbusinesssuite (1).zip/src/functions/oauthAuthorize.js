import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

/**
 * OAuth Authorization URL Generator
 * Returns authorization URLs for OAuth integrations
 * 
 * This function is called from the frontend to get an OAuth authorization URL.
 * The user is then redirected to authorize the integration.
 */
// deno-lint-ignore no-undef
// eslint-disable-next-line no-undef
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { integration_type } = body;

    if (!integration_type) {
      return Response.json({ error: 'integration_type is required' }, { status: 400 });
    }

    // For app-user connectors, we need to generate a connection URL
    // The user will be redirected to authorize their personal account
    // Base44 handles the OAuth flow and stores the connection
    
    // Get the list of registered workspace connectors for this integration
    // For now, we'll return a placeholder URL that the frontend can use
    // In production, this would call Base44's connector registration API
    
    const authUrl = `/oauth/connect/${integration_type}?user=${encodeURIComponent(user.email)}`;

    return Response.json({ 
      authorization_url: authUrl,
      integration_type: integration_type,
      message: 'Redirect user to authorization_url to complete OAuth connection'
    });
  } catch (error) {
    console.error('OAuth authorization error:', error);
    return Response.json({ 
      error: error.message || 'Failed to initiate OAuth connection'
    }, { status: 500 });
  }
});