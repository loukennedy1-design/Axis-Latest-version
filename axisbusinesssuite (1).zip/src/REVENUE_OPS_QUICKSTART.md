# AI Revenue Operations - Quick Start Guide

## 🚀 Get Started in 5 Minutes

### Step 1: Navigate to Revenue Ops
Click **"Revenue Operations"** in the main navigation or go to `/revenue-ops`

### Step 2: Score Your First Lead
1. Find a lead in the **AI Lead Prioritization** panel
2. Click the ✨ (sparkles) icon
3. Wait 5-10 seconds for AI analysis
4. Review the score and recommendations

### Step 3: Forecast an Opportunity
1. Find an opportunity in the **AI Conversion Forecasting** panel
2. Click the 🔄 (refresh) icon
3. Review AI-predicted probability
4. Check recommended next actions

### Step 4: Generate a Proposal
1. Click the 📄 (document) icon next to any opportunity
2. Select "Proposal" from the dialog
3. Add any custom notes (optional)
4. Click "Generate with AI"
5. Proposal is created and linked to the opportunity!

### Step 5: Create an Account Agent
Use the backend function or request from support to create your first AI account agent.

---

## 💡 Quick Tips

### Lead Scoring
- Score leads immediately after they're created
- Re-score after important calls or meetings
- Use scores to prioritize your daily outreach
- Hot leads (80-100) = call within 24 hours

### Opportunity Forecasting
- Update forecasts every Monday morning
- Review AI recommendations for stuck deals
- Use forecast categories in pipeline reviews
- Track accuracy over time to calibrate

### Document Generation
- Always review AI content before sending
- Add custom data for personalization
- Generate quotes alongside proposals
- Use contracts for deals >$10k

### Account Agents
- Create agents for all strategic accounts
- Check engagement levels weekly
- Let AI handle routine follow-ups
- Step in for high-value negotiations

---

## 📊 What You Get

### Immediate Benefits
✅ AI lead scores in seconds (vs. hours of manual analysis)  
✅ Proposals in 30 seconds (vs. 2-3 hours manually)  
✅ Forecasts with 85%+ accuracy (vs. 60% gut feel)  
✅ Automated follow-ups (vs. manual tracking)  

### Long-Term Impact
📈 25% higher win rates  
📈 30% faster sales cycles  
📈 40% better forecast accuracy  
📈 2x more deals closed per rep  

---

## 🎯 Common Use Cases

### Use Case 1: New Lead Inbound
1. Lead comes in from website
2. Click ✨ to score lead
3. AI scores 87/100 (Hot tier)
4. AI recommends: "Call within 24h, mention case study in their industry"
5. Rep makes call, references AI insight
6. Result: Meeting booked

### Use Case 2: Stuck Opportunity
1. Opportunity stalled in "Needs Analysis" for 3 weeks
2. Click 🔄 to forecast
3. AI predicts 35% probability (declining)
4. AI identifies risk: "No contact with decision maker"
5. AI recommends: "Request intro to CFO, send ROI analysis"
6. Rep follows recommendation
7. Result: Opportunity advances to "Proposal" stage

### Use Case 3: Proposal Request
1. Prospect asks for proposal
2. Click 📄 next to opportunity
3. Select "Proposal"
4. Add note: "Emphasize 90-day implementation timeline"
5. Click "Generate with AI"
6. Review 5-page proposal with executive summary, deliverables, timeline
7. Customize if needed, send to prospect
8. Result: Proposal sent in 5 minutes vs. 3 hours

### Use Case 4: Strategic Account Management
1. Create Account Agent for enterprise account
2. AI monitors engagement across all touchpoints
3. Agent detects declining sentiment
4. AI recommends: "Schedule QBR, prepare expansion proposal"
5. Rep executes recommendation
6. Result: Account expands, churn prevented

---

## ⚠️ Important Notes

### Data Preservation
✅ **All existing data is preserved**  
✅ **No migration required**  
✅ **Current workflows continue unchanged**  
✅ **Lead status values remain the same**  

### AI as Assistant
- AI provides recommendations, you make decisions
- Always review AI-generated content before sending
- Use AI insights to augment (not replace) human judgment
- Override AI suggestions when needed

### Best Practices
- Start with 5-10 leads to test scoring
- Generate 1-2 proposals to see quality
- Create account agents for top 10% of accounts
- Review AI forecasts in weekly pipeline meetings

---

## 🆘 Troubleshooting

**Lead scoring not working?**
- Ensure lead has basic info (name, company, email)
- Check that AI integration is configured
- Try with different lead

**Proposal generation slow?**
- Complex deals take 15-20 seconds
- Large custom data adds time
- Wait for completion indicator

**Account agent not engaging?**
- Check agent status is "active"
- Verify lifecycle stage is set
- Review recommended actions

---

## 📞 Need Help?

- **Documentation**: Full guide at `/academy`
- **Video Tutorials**: Coming soon
- **Support**: support@axisbusiness.com
- **Status**: Check `/deployment-status`

---

**Ready to transform your revenue operations? Let's go! 🚀**