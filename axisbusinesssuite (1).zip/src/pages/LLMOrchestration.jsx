import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import {
  Brain, Zap, Globe, Shield, Target, BarChart3, Loader2,
  CheckCircle2, AlertCircle, Clock, RefreshCw, Sparkles, Code
} from 'lucide-react';
import { toast } from 'sonner';

const MODELS = [
  { id: 'automatic', label: 'Automatic', desc: 'AXIS auto-selects the best model for your task', badge: 'Default', badgeColor: 'bg-primary/10 text-primary border-primary/20' },
  { id: 'gpt_5_mini', label: 'GPT-5 Mini', desc: 'Fast, cost-effective for most tasks', badge: 'Fast', badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
  { id: 'gpt_5_5', label: 'GPT-5.5', desc: 'OpenAI flagship — complex reasoning & analysis', badge: 'Powerful', badgeColor: 'bg-green-500/10 text-green-400 border-green-500/20' },
  { id: 'claude_sonnet_4_6', label: 'Claude Sonnet 4.6', desc: 'Superior reasoning and nuanced writing', badge: 'Smart', badgeColor: 'bg-violet-500/10 text-violet-400 border-violet-500/20' },
  { id: 'claude_opus_4_7', label: 'Claude Opus 4.7', desc: 'Most capable Claude — complex multi-step tasks', badge: 'Elite', badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20' },
  { id: 'gemini_3_flash', label: 'Gemini 3 Flash + Web', desc: 'Real-time internet access for live data queries', badge: 'Live Data', badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/20' },
  { id: 'gemini_3_1_pro', label: 'Gemini 3.1 Pro + Web', desc: 'Advanced Gemini with extended web grounding', badge: 'Pro+Web', badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/20' },
];

const TASK_TEMPLATES = [
  { label: 'CRM Intelligence', prompt: 'Analyze our lead pipeline and provide a strategic summary with recommendations for improving conversion rates. Focus on the most actionable insights.', model: 'claude_sonnet_4_6', icon: Target },
  { label: 'Compliance Review', prompt: 'Review TCPA and FCC compliance requirements for AI-powered outbound calling systems in 2026. Provide a checklist of mandatory requirements.', model: 'gemini_3_flash', icon: Shield },
  { label: 'Market Research', prompt: 'Research the top AI sales automation platforms in 2026. Compare their features, pricing, and target markets versus our AXIS Business Suite.', model: 'gemini_3_flash', icon: BarChart3 },
  { label: 'Script Generation', prompt: 'Generate 3 high-converting AI call bot opening scripts for a B2B sales automation platform targeting small business owners. Include objection handling.', model: 'claude_sonnet_4_6', icon: Code },
  { label: 'Feature Research', prompt: 'What are the most requested features in AI-powered CRM and sales platforms in 2026? What should we prioritize building next?', model: 'gemini_3_flash', icon: Sparkles },
  { label: 'Quick Summary', prompt: 'Summarize the key performance indicators every sales team should track daily, weekly, and monthly. Keep it concise and actionable.', model: 'automatic', icon: Zap },
];

export default function LLMOrchestration() {
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState('automatic');
  const [useInternet, setUseInternet] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [elapsed, setElapsed] = useState(null);
  const [history, setHistory] = useState([]);

  const run = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setResult(null);
    const start = Date.now();
    try {
      const canUseInternet = useInternet && (model === 'automatic' || model === 'gemini_3_flash' || model === 'gemini_3_1_pro');
      const params = {
        prompt,
        add_context_from_internet: canUseInternet,
        model: model !== 'automatic' ? model : undefined,
      };
      const res = await base44.integrations.Core.InvokeLLM(params);
      const ms = Date.now() - start;
      setElapsed(ms);
      setResult(typeof res === 'string' ? res : JSON.stringify(res, null, 2));
      setHistory(prev => [{ prompt: prompt.slice(0, 80), model, ms, timestamp: new Date() }, ...prev].slice(0, 10));
      toast.success(`Response received in ${(ms / 1000).toFixed(1)}s`);
    } catch (e) {
      setResult(`Error: ${e.message}`);
      toast.error('LLM call failed');
    }
    setLoading(false);
  };

  const loadTemplate = (tmpl) => {
    setPrompt(tmpl.prompt);
    setModel(tmpl.model);
    setUseInternet(tmpl.model === 'gemini_3_flash');
  };

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-violet-500/20 bg-gradient-to-br from-violet-500/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <Brain className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">LLM Orchestration Engine</h1>
              <p className="text-muted-foreground text-xs">Intelligent multi-model routing · Context-aware AI · Real-time web grounding</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {MODELS.map(m => (
              <Badge key={m.id} className={`text-[10px] ${m.badgeColor}`}>{m.label.split(' ').slice(0, 2).join(' ')}</Badge>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left: Config */}
        <div className="space-y-4">
          {/* Model Selection */}
          <Card>
            <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Brain className="w-4 h-4 text-muted-foreground" />Model Selection</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              {MODELS.map(m => (
                <button
                  key={m.id}
                  onClick={() => {
                    setModel(m.id);
                    if (m.id !== 'gemini_3_flash' && m.id !== 'gemini_3_1_pro' && m.id !== 'automatic') setUseInternet(false);
                  }}
                  className={`w-full flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${model === m.id ? 'border-primary/40 bg-primary/5' : 'border-border bg-muted/20 hover:bg-muted/40'}`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-xs font-semibold">{m.label}</p>
                      <Badge className={`text-[9px] px-1.5 py-0 ${m.badgeColor}`}>{m.badge}</Badge>
                    </div>
                    <p className="text-[10px] text-muted-foreground">{m.desc}</p>
                  </div>
                  {model === m.id && <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />}
                </button>
              ))}

              {/* Internet toggle */}
              <div className={`flex items-center justify-between p-3 rounded-xl border transition-all ${(model === 'automatic' || model === 'gemini_3_flash' || model === 'gemini_3_1_pro') ? 'border-blue-500/30 bg-blue-500/5 cursor-pointer' : 'border-border bg-muted/10 opacity-40 cursor-not-allowed'}`}
                onClick={() => (model === 'automatic' || model === 'gemini_3_flash' || model === 'gemini_3_1_pro') && setUseInternet(!useInternet)}>
                <div className="flex items-center gap-2">
                  <Globe className="w-4 h-4 text-blue-400" />
                  <div>
                    <p className="text-xs font-semibold">Web Search</p>
                    <p className="text-[10px] text-muted-foreground">Live internet grounding</p>
                  </div>
                </div>
                <div className={`w-9 h-5 rounded-full transition-all ${useInternet ? 'bg-blue-500' : 'bg-muted'}`}>
                  <div className={`w-4 h-4 m-0.5 bg-white rounded-full shadow transition-transform ${useInternet ? 'translate-x-4' : ''}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Task Templates */}
          <Card>
            <CardHeader><CardTitle className="text-sm">Quick Templates</CardTitle></CardHeader>
            <CardContent className="space-y-1.5">
              {TASK_TEMPLATES.map((t) => (
                <button
                  key={t.label}
                  onClick={() => loadTemplate(t)}
                  className="w-full flex items-center gap-2.5 p-2.5 rounded-lg border border-border bg-muted/20 hover:bg-muted/40 text-left transition-all"
                >
                  <t.icon className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <p className="text-xs font-medium">{t.label}</p>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* History */}
          {history.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-xs text-muted-foreground uppercase tracking-wider">Recent Queries</CardTitle></CardHeader>
              <CardContent className="space-y-1.5 max-h-48 overflow-y-auto">
                {history.map((h, i) => (
                  <div key={i} className="p-2 rounded-lg bg-muted/30 border border-border/50">
                    <p className="text-[10px] font-medium truncate">{h.prompt}...</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[9px] text-muted-foreground">{h.model}</span>
                      <span className="text-[9px] text-muted-foreground ml-auto">{(h.ms / 1000).toFixed(1)}s</span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right: Prompt + Output */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Sparkles className="w-4 h-4 text-muted-foreground" />Prompt</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                placeholder="Enter your prompt... or select a template from the left panel."
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                rows={6}
                className="text-sm font-mono resize-none"
              />
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Badge variant="outline" className="text-[10px]">{MODELS.find(m => m.id === model)?.label}</Badge>
                  {useInternet && <Badge className="text-[10px] bg-blue-500/10 text-blue-400 border-blue-500/20"><Globe className="w-2.5 h-2.5 mr-1" />Web</Badge>}
                </div>
                <Button
                  disabled={!prompt.trim() || loading}
                  onClick={run}
                  className="gap-2"
                >
                  {loading ? <><Loader2 className="w-4 h-4 animate-spin" />Processing...</> : <><Zap className="w-4 h-4" />Run</>}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Output */}
          {loading && (
            <div className="rounded-2xl border border-primary/20 bg-primary/5 p-10 text-center">
              <Loader2 className="w-8 h-8 mx-auto mb-3 text-primary animate-spin" />
              <p className="text-sm font-medium">AI is processing your request...</p>
              <p className="text-xs text-muted-foreground mt-1">Model: {MODELS.find(m => m.id === model)?.label}</p>
            </div>
          )}

          {result && !loading && (
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />Output
                  {elapsed && <Badge variant="outline" className="ml-auto text-[10px]"><Clock className="w-2.5 h-2.5 mr-1" />{(elapsed / 1000).toFixed(1)}s</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="rounded-xl bg-muted/30 border border-border p-4 text-sm leading-relaxed whitespace-pre-wrap max-h-[500px] overflow-y-auto font-mono text-xs">
                  {result}
                </div>
                <div className="flex gap-2 mt-3">
                  <Button size="sm" variant="outline" className="text-xs h-7"
                    onClick={() => { navigator.clipboard.writeText(result); toast.success('Copied!'); }}>
                    Copy
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs h-7" onClick={() => setResult(null)}>Clear</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {!result && !loading && (
            <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">
              <Brain className="w-10 h-10 mx-auto mb-3 opacity-30" />
              <p className="text-sm">Select a model, write a prompt, and hit Run</p>
              <p className="text-xs mt-1">Or choose a Quick Template from the left panel</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}