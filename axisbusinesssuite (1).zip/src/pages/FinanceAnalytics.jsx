import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, ReferenceLine } from 'recharts';
import { DollarSign, Clock, TrendingDown, AlertTriangle, ArrowLeft, Loader2, Receipt, Wallet } from 'lucide-react';
import { format, subDays, addDays, differenceInCalendarDays, startOfMonth, isWithinInterval } from 'date-fns';

const currency = (n) => `$${(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
const GATEWAY_COLORS = ['#34D399', '#60A5FA', '#A78BFA', '#F5C842', '#F87171'];
const AGING_COLORS = ['#34D399', '#F5C842', '#FB923C', '#F87171', '#991B1B'];

export default function FinanceAnalytics() {
  const { data: invoices = [], isLoading: invL } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list('-created_date', 500)
  });
  const { data: expenses = [], isLoading: expL } = useQuery({
    queryKey: ['expenses'],
    queryFn: () => base44.entities.Expense.list('-created_date', 500)
  });
  const { data: payroll = [], isLoading: payL } = useQuery({
    queryKey: ['payroll', 'analytics'],
    queryFn: () => base44.entities.PayrollRecord.list('-created_date', 500)
  });
  const { data: payments = [], isLoading: paymT } = useQuery({
    queryKey: ['payment-txns', 'analytics'],
    queryFn: () => base44.entities.PaymentTransaction.list('-created_date', 500)
  });

  const loading = invL || expL || payL || paymT;
  const now = new Date();

  // AR Aging — outstanding (sent/overdue, unpaid) invoices bucketed by days past due
  const arAging = useMemo(() => {
    const buckets = [
      { label: 'Current', min: -Infinity, max: 0, value: 0, count: 0 },
      { label: '1-30', min: 1, max: 30, value: 0, count: 0 },
      { label: '31-60', min: 31, max: 60, value: 0, count: 0 },
      { label: '61-90', min: 61, max: 90, value: 0, count: 0 },
      { label: '90+', min: 91, max: Infinity, value: 0, count: 0 }
    ];
    const outstanding = invoices.filter(i => i.status === 'sent' || i.status === 'overdue');
    outstanding.forEach(inv => {
      const due = inv.due_date ? new Date(inv.due_date) : null;
      const daysPast = due ? differenceInCalendarDays(now, due) : 0;
      const total = inv.total || 0;
      const b = buckets.find(bk => daysPast >= bk.min && daysPast <= bk.max) || buckets[0];
      b.value += total;
      b.count += 1;
    });
    return buckets;
  }, [invoices]);

  const totalAR = arAging.reduce((s, b) => s + b.value, 0);
  const overdueAR = arAging.slice(1).reduce((s, b) => s + b.value, 0);

  // DSO = (AR / total billed in period) * days in period — simplified 90-day
  const dso = useMemo(() => {
    const billed90 = invoices
      .filter(i => i.created_date && differenceInCalendarDays(now, new Date(i.created_date)) <= 90)
      .reduce((s, i) => s + (i.total || 0), 0);
    if (billed90 === 0) return 0;
    return Math.round((totalAR / billed90) * 90);
  }, [invoices, totalAR]);

  // Collection rate = paid / total billed (all time)
  const collectionRate = useMemo(() => {
    const totalBilled = invoices.reduce((s, i) => s + (i.total || 0), 0);
    const paid = invoices.filter(i => i.status === 'paid').reduce((s, i) => s + (i.total || 0), 0);
    return totalBilled > 0 ? Math.round((paid / totalBilled) * 100) : 0;
  }, [invoices]);

  // Cash-flow forecast — next 90 days: projected inflows (unpaid invoices by due_date) vs outflows (pending expenses by date + upcoming payroll)
  const forecast = useMemo(() => {
    const horizon = [30, 60, 90];
    return horizon.map(days => {
      const end = addDays(now, days);
      const inflows = invoices
        .filter(i => (i.status === 'sent' || i.status === 'overdue') && i.due_date && new Date(i.due_date) <= end)
        .reduce((s, i) => s + (i.total || 0), 0);
      const expOut = expenses
        .filter(e => e.status === 'pending' && e.date && new Date(e.date) <= end)
        .reduce((s, e) => s + (e.amount || 0), 0);
      const payOut = payroll
        .filter(p => (p.status === 'draft' || p.status === 'approved') && p.pay_date && new Date(p.pay_date) <= end)
        .reduce((s, p) => s + (p.net_pay || 0), 0);
      return { horizon: `${days}d`, inflows, outflows: expOut + payOut, net: inflows - expOut - payOut };
    });
  }, [invoices, expenses, payroll]);

  // Top overdue clients
  const topOverdue = useMemo(() => {
    const map = {};
    invoices.filter(i => i.status === 'overdue' || (i.status === 'sent' && i.due_date && new Date(i.due_date) < now))
      .forEach(i => { const k = i.client_name || 'Unknown'; map[k] = (map[k] || 0) + (i.total || 0); });
    return Object.entries(map).map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount).slice(0, 6);
  }, [invoices]);

  // Payments by gateway
  const byGateway = useMemo(() => {
    const map = {};
    payments.filter(p => p.status === 'completed' && p.transaction_type === 'payment')
      .forEach(p => { const g = p.gateway || 'other'; map[g] = (map[g] || 0) + (p.amount || 0); });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [payments]);

  // Monthly cash collected (last 6 months from completed payments)
  const cashTrend = useMemo(() => {
    return Array.from({ length: 6 }, (_, i) => {
      const m = subDays(now, (5 - i) * 30);
      const s = startOfMonth(m), e = new Date(m.getFullYear(), m.getMonth() + 1, 0);
      const collected = payments.filter(p => {
        if (p.status !== 'completed' || !p.transaction_date) return false;
        try { return isWithinInterval(new Date(p.transaction_date), { start: s, end: e }); } catch { return false; }
      }).reduce((s2, p) => s2 + (p.amount || 0), 0);
      return { month: format(m, 'MMM'), collected };
    });
  }, [payments]);

  if (loading) {
    return <div className="flex items-center justify-center h-[60vh]"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;
  }

  const kpis = [
    { label: 'Total AR Outstanding', value: currency(totalAR), icon: DollarSign, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
    { label: 'Overdue AR', value: currency(overdueAR), icon: AlertTriangle, color: overdueAR > 0 ? 'text-red-400' : 'text-emerald-400', bg: 'from-red-500/10 to-red-600/5', border: 'border-red-500/20' },
    { label: 'Avg DSO (days)', value: dso, icon: Clock, color: 'text-amber-400', bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20' },
    { label: 'Collection Rate', value: `${collectionRate}%`, icon: TrendingDown, color: collectionRate >= 80 ? 'text-emerald-400' : 'text-amber-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
  ];

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center"><Wallet className="w-5 h-5 text-emerald-400" /></div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Finance Analytics</h1>
              <p className="text-muted-foreground text-xs">AR aging · Cash-flow forecast · Collection performance · Payment gateways</p>
            </div>
          </div>
          <Link to="/finance-overview" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Finance Overview
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {kpis.map(k => (
          <div key={k.label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 shadow-lg ${k.bg} ${k.border}`}>
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{k.label}</p>
            <p className={`text-2xl font-bold ${k.color}`}>{k.value}</p>
            <k.icon className={`absolute bottom-3 right-3 w-5 h-5 opacity-20 ${k.color}`} />
          </div>
        ))}
      </div>

      {/* AR Aging */}
      <Card>
        <CardHeader><CardTitle className="text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-400" /> Accounts Receivable Aging</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={arAging}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" />
              <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="value" name="Outstanding" radius={[4, 4, 0, 0]}>
                {arAging.map((_, i) => <Cell key={i} fill={AGING_COLORS[i % AGING_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-5 gap-2 mt-3">
            {arAging.map((b, i) => (
              <div key={b.label} className="text-center">
                <div className="w-2.5 h-2.5 rounded-full mx-auto mb-1" style={{ background: AGING_COLORS[i] }} />
                <p className="text-[10px] text-muted-foreground uppercase">{b.label}</p>
                <p className="text-xs font-semibold">{currency(b.value)}</p>
                <p className="text-[10px] text-muted-foreground">{b.count} inv</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Cash-flow forecast + trend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Wallet className="w-4 h-4 text-emerald-400" /> 90-Day Cash-Flow Forecast</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={forecast}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="horizon" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" />
                <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Bar dataKey="inflows" name="Projected Inflows" fill="#34D399" radius={[4, 4, 0, 0]} />
                <Bar dataKey="outflows" name="Projected Outflows" fill="#F87171" radius={[4, 4, 0, 0]} />
                <ReferenceLine y={0} stroke="hsl(var(--border))" />
              </BarChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-3 gap-2 mt-3">
              {forecast.map(f => (
                <div key={f.horizon} className="rounded-lg border border-border bg-muted/30 p-2 text-center">
                  <p className="text-[10px] text-muted-foreground uppercase">{f.horizon} Net</p>
                  <p className={`text-sm font-bold ${f.net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{currency(f.net)}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Cash Collected (6 mo)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={cashTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" />
                <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="collected" stroke="#34D399" strokeWidth={2.5} dot={{ r: 3 }} name="Collected" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Top overdue + gateway */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Receipt className="w-4 h-4 text-red-400" /> Top Overdue Clients</CardTitle></CardHeader>
          <CardContent>
            {topOverdue.length === 0 ? (
              <div className="flex items-center justify-center h-[220px] text-sm text-muted-foreground">No overdue invoices 🎉</div>
            ) : (
              <div className="space-y-2">
                {topOverdue.map(c => (
                  <div key={c.name} className="flex items-center gap-3">
                    <span className="text-sm flex-1 truncate">{c.name}</span>
                    <Badge variant="destructive" className="text-[10px]">{currency(c.amount)}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Payments by Gateway</CardTitle></CardHeader>
          <CardContent>
            {byGateway.length === 0 ? (
              <div className="flex items-center justify-center h-[220px] text-sm text-muted-foreground">No completed payments yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={byGateway} cx="50%" cy="50%" outerRadius={80} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                    {byGateway.map((_, i) => <Cell key={i} fill={GATEWAY_COLORS[i % GATEWAY_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}