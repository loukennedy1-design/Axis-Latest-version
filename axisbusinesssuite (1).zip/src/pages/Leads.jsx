import React, { useState, useEffect } from 'react';
import { enrollLead } from '@/components/nurture/NurtureEngine';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import StatusBadge from '@/components/shared/StatusBadge';
import ClickToCall from '@/components/shared/ClickToCall';
import LeadProfileSummary from '@/components/leads/LeadProfileSummary';
import { Plus, Search, Trash2, Pencil, XSquare, ShieldCheck, PhoneOff, Tag, Sparkles, Loader2, AlertTriangle, Copy, Users, Eye } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import PullToRefresh from '@/components/shared/PullToRefresh';

const emptyLead = { first_name: '', last_name: '', phone: '', email: '', company: '', status: 'new', source: '', notes: '', consent_given: false, consent_status: 'unknown', timezone: 'America/New_York', assigned_to: '' };

export default function Leads() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editLead, setEditLead] = useState(null);
  const [form, setForm] = useState(emptyLead);
  const [selected, setSelected] = useState(new Set());
  const [qualifyingId, setQualifyingId] = useState(null);
  const [bulkQualifying, setBulkQualifying] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [leadToDelete, setLeadToDelete] = useState(null);
  const [viewLead, setViewLead] = useState(null);
  const qc = useQueryClient();
  const { user, dataOwnerEmail } = useCurrentUser();

  const { data: leads = [], isLoading, refetch } = useQuery({ 
    queryKey: ['leads', user?.email], 
    queryFn: async () => {
      if (!user?.email) return [];
      try {
        return await base44.entities.Lead.list('-created_date');
      } catch (err) {
        console.error('Failed to load leads:', err);
        return [];
      }
    },
    enabled: !!user?.email,
  });
  const { data: workflows = [] } = useQuery({ queryKey: ['workflows'], queryFn: () => base44.entities.NurtureWorkflow.list() });
  const { data: salesReps = [] } = useQuery({
    queryKey: ['sales-reps', user?.email],
    queryFn: () => base44.entities.SalesRep.filter({ status: 'active' }),
    enabled: !!user?.email,
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createLead', data);
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['leads'] }); setDialogOpen(false); toast.success('Lead created'); },
    onError: (err) => toast.error(`Failed to create lead: ${err?.message || 'Unknown error'}`)
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['leads'] }); setDialogOpen(false); toast.success('Lead updated'); }
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Lead.delete(id),
    onSuccess: () => { 
      qc.invalidateQueries({ queryKey: ['leads'] }); 
      toast.success('Lead deleted');
      setDeleteDialogOpen(false);
      setLeadToDelete(null);
    },
    onError: (err) => {
      toast.error(`Failed to delete lead: ${err?.message || 'Unknown error'}`);
      setDeleteDialogOpen(false);
      setLeadToDelete(null);
    }
  });

  const handleSave = () => {
    if (editLead) {
      updateMut.mutate({ id: editLead.id, data: form });
      // Auto-enroll if status changed
      if (form.status !== editLead.status) {
        enrollLead({ ...form, id: editLead.id }, workflows).catch(() => {});
      }
    } else {
      if (!user?.email) {
        toast.error('User session not ready — please wait a moment and try again.');
        return;
      }
      if (duplicates.length > 0) {
        toast.error('Duplicate lead detected — phone or email already exists.');
        return;
      }
      const ownerEmail = dataOwnerEmail || user.email;
      if (!ownerEmail) {
        toast.error('User session not ready — please refresh the page and try again.');
        return;
      }
      createMut.mutate({ ...form, owner: ownerEmail.toLowerCase().trim(), consent_given: form.consent_status === 'given', consent_status: form.consent_status || 'unknown', consent_date: form.consent_status === 'given' ? new Date().toISOString() : undefined });
    }
  };

  const openEdit = (lead) => { setEditLead(lead); setForm(lead); setDialogOpen(true); };
  const openNew = () => { setEditLead(null); setForm(emptyLead); setDialogOpen(true); };
  const confirmDelete = (lead) => { setLeadToDelete(lead); setDeleteDialogOpen(true); };

  // Duplicate detection: find leads with same phone or email (excluding current lead being edited)
  const normalizePhone = (p) => p?.replace(/\D/g, '') || '';
  const findDuplicates = (phone, email) => {
    return leads.filter(l => {
      if (editLead && l.id === editLead.id) return false;
      const samePhone = phone && normalizePhone(l.phone) === normalizePhone(phone) && normalizePhone(phone).length >= 7;
      const sameEmail = email && email.trim() && l.email?.trim().toLowerCase() === email.trim().toLowerCase();
      return samePhone || sameEmail;
    });
  };
  const duplicates = (dialogOpen && !editLead) ? findDuplicates(form.phone, form.email) : [];

  const qualifyLead = async (lead) => {
    setQualifyingId(lead.id);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert sales qualification AI. Analyze this lead and determine their quality score and recommended next action.

Lead info:
- Name: ${lead.first_name} ${lead.last_name}
- Company: ${lead.company || 'Unknown'}
- Email: ${lead.email || 'None'}
- Source: ${lead.source || 'Unknown'}
- Call attempts: ${lead.call_attempts || 0}
- Current status: ${lead.status}
- Notes: ${lead.notes || 'None'}
- Consent given: ${lead.consent_given ? 'Yes' : 'No'}

Score from 1-10 and recommend next steps.`,
      response_json_schema: {
        type: "object",
        properties: {
          score: { type: "number", description: "1-10 qualification score" },
          tier: { type: "string", enum: ["hot", "warm", "cold"] },
          reasoning: { type: "string" },
          recommended_status: { type: "string", enum: ["new", "contacted", "qualified", "not_interested"] },
          next_action: { type: "string" },
          notes: { type: "string" }
        }
      }
    });

    const qualNote = `[AI Qualified ${new Date().toLocaleDateString()}] Score: ${result.score}/10 (${result.tier.toUpperCase()}) — ${result.reasoning} | Next: ${result.next_action}`;
    await base44.entities.Lead.update(lead.id, {
      status: result.recommended_status,
      notes: lead.notes ? `${lead.notes}\n${qualNote}` : qualNote,
    });

    // Auto-enroll into nurture workflows if status changed
    if (result.recommended_status !== lead.status) {
      enrollLead({ ...lead, status: result.recommended_status }, workflows).catch(() => {});
    }

    qc.invalidateQueries({ queryKey: ['leads'] });
    setQualifyingId(null);
    toast.success(`${lead.first_name} qualified: ${result.tier.toUpperCase()} lead (${result.score}/10)`);
  };

  // Pre-compute duplicates across ALL leads (before de-duplication) for table display
  const duplicateIds = new Set();
  const phoneMap = {};
  const emailMap = {};
  leads.forEach(l => {
    const p = normalizePhone(l.phone);
    if (p.length >= 7) {
      if (phoneMap[p]) { duplicateIds.add(l.id); duplicateIds.add(phoneMap[p]); }
      else phoneMap[p] = l.id;
    }
    const e = l.email?.trim().toLowerCase();
    if (e) {
      if (emailMap[e]) { duplicateIds.add(l.id); duplicateIds.add(emailMap[e]); }
      else emailMap[e] = l.id;
    }
  });

  // Ensure all leads have owner field set (fix for legacy leads) — batch update for efficiency
  React.useEffect(() => {
    if (leads.length > 0 && user?.email) {
      const ownerEmail = (dataOwnerEmail || user.email).toLowerCase().trim();
      const needsUpdate = leads.filter(lead => !lead.owner || lead.owner.toLowerCase().trim() !== ownerEmail);
      if (needsUpdate.length > 0 && needsUpdate.length <= 500) {
        // Batch update using updateMany for efficiency
        base44.entities.Lead.updateMany(
          { id: { $in: needsUpdate.map(l => l.id) } },
          { $set: { owner: ownerEmail } }
        ).catch(() => {});
      }
    }
  }, [leads.length, user?.email, dataOwnerEmail]);

  // De-duplicate leads list: show only the first occurrence of each phone/email pair
  const seenPhones = new Set();
  const seenEmails = new Set();
  const deduped = leads.filter(l => {
    const p = normalizePhone(l.phone);
    const e = l.email?.trim().toLowerCase();
    if (p.length >= 7 && seenPhones.has(p)) return false;
    if (e && seenEmails.has(e)) return false;
    if (p.length >= 7) seenPhones.add(p);
    if (e) seenEmails.add(e);
    return true;
  });

  const filtered = deduped.filter(l => {
    const matchSearch = `${l.first_name} ${l.last_name} ${l.phone} ${l.email} ${l.company}`.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || l.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const allSelected = filtered.length > 0 && filtered.every(l => selected.has(l.id));
  const toggleAll = () => {
    if (allSelected) setSelected(new Set());
    else setSelected(new Set(filtered.map(l => l.id)));
  };
  const toggleOne = (id) => {
    const s = new Set(selected);
    s.has(id) ? s.delete(id) : s.add(id);
    setSelected(s);
  };

  // Bulk actions
  const bulkUpdateStatus = async (status) => {
    await Promise.all([...selected].map(id => base44.entities.Lead.update(id, { status })));
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`${selected.size} leads updated to "${status.replace(/_/g,' ')}"`);
    setSelected(new Set());
  };
  const bulkGrantConsent = async () => {
    await Promise.all([...selected].map(id => base44.entities.Lead.update(id, { consent_given: true, consent_status: 'given', consent_date: new Date().toISOString() })));
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`Consent granted for ${selected.size} leads`);
    setSelected(new Set());
  };
  const bulkAddDNC = async () => {
    const selectedLeads = leads.filter(l => selected.has(l.id));
    await Promise.all(selectedLeads.map(l => Promise.all([
      base44.functions.invoke('createRecord', { entity: 'DNCEntry', data: { phone_number: l.phone, reason: 'internal_policy', added_date: new Date().toISOString(), owner: user?.email } }),
      base44.functions.invoke('createRecord', { entity: 'ComplianceLog', data: { event_type: 'dnc_added', description: `${l.first_name} ${l.last_name} added to DNC via bulk action`, lead_id: l.id, phone_number: l.phone, action_by: user?.email || 'manual', owner: user?.email } }),
    ])));
    await Promise.all([...selected].map(id => base44.entities.Lead.update(id, { status: 'do_not_call' })));
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`${selected.size} leads added to DNC`);
    setSelected(new Set());
  };
  const bulkDelete = async () => {
    await Promise.all([...selected].map(id => base44.entities.Lead.delete(id)));
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`${selected.size} leads deleted`);
    setSelected(new Set());
  };

  const assignLead = async (leadId, assignedTo, leadName) => {
    try {
      await base44.entities.Lead.update(leadId, { assigned_to: assignedTo });
      qc.invalidateQueries({ queryKey: ['leads'] });
      toast.success(`${leadName} ${assignedTo ? 'assigned' : 'unassigned'}`);
    } catch (err) {
      toast.error(`Failed to assign: ${err?.message || 'Unknown error'}`);
    }
  };

  const bulkAssign = async (assignedTo) => {
    await Promise.all([...selected].map(id => base44.entities.Lead.update(id, { assigned_to: assignedTo })));
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`${selected.size} leads ${assignedTo ? 'assigned' : 'unassigned'}`);
    setSelected(new Set());
  };

  const bulkQualify = async () => {
    const selectedLeads = leads.filter(l => selected.has(l.id));
    if (!selectedLeads.length) return;
    setBulkQualifying(true);
    let count = 0;
    for (const lead of selectedLeads) {
      await qualifyLead(lead);
      count++;
    }
    setBulkQualifying(false);
    setSelected(new Set());
    toast.success(`AI qualified ${count} leads`);
  };

  const consentedCount = leads.filter(l => l.consent_given).length;
  const qualifiedCount = leads.filter(l => l.status === 'qualified' || l.status === 'appointment_set').length;
  const newCount = leads.filter(l => l.status === 'new').length;

  return (
    <PullToRefresh onRefresh={refetch}>
    <div className="space-y-4">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-6 -right-6 w-32 h-32 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Leads</h1>
              <p className="text-muted-foreground text-xs">CRM — full contact management</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {/* KPI pills */}
            <div className="flex items-center gap-2 flex-wrap">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-background/80 border border-border text-xs font-semibold">
                <span className="text-primary">{leads.length}</span><span className="text-muted-foreground">total</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold">
                <span className="text-emerald-500">{consentedCount}</span><span className="text-emerald-600/70">consented</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold">
                <span className="text-blue-400">{newCount}</span><span className="text-blue-400/70">new</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold">
                <span className="text-purple-400">{qualifiedCount}</span><span className="text-purple-400/70">hot</span>
              </div>
              {duplicateIds.size > 0 && (
                <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold">
                  <AlertTriangle className="w-3 h-3 text-amber-500" />
                  <span className="text-amber-500">{duplicateIds.size} dupes</span>
                </div>
              )}
            </div>
            <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" />Add Lead</Button>
          </div>
        </div>
      </div>
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{editLead ? 'Edit Lead' : 'New Lead'}</DialogTitle></DialogHeader>
            
            {/* Show AI Call Summary for existing leads */}
            {editLead && (
              <div className="mb-4">
                <LeadProfileSummary lead={editLead} />
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-4">
              <div><Label>First Name *</Label><Input value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} /></div>
              <div><Label>Last Name</Label><Input value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} /></div>
              <div><Label>Phone *</Label><Input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
              <div><Label>Email</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
              <div><Label>Company</Label><Input value={form.company} onChange={e => setForm({ ...form, company: e.target.value })} /></div>
              <div><Label>Source</Label><Input value={form.source} onChange={e => setForm({ ...form, source: e.target.value })} /></div>
              <div><Label>Status</Label>
                <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['new','contacted','qualified','appointment_set','not_interested','do_not_call','invalid'].map(s => (
                      <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Timezone</Label><Input value={form.timezone} onChange={e => setForm({ ...form, timezone: e.target.value })} /></div>
              <div><Label>Assign To</Label>
                <Select value={form.assigned_to || ''} onValueChange={v => setForm({ ...form, assigned_to: v === '_unassigned' ? '' : v })}>
                  <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_unassigned">Unassigned</SelectItem>
                    {salesReps.map(rep => (
                      <SelectItem key={rep.id} value={rep.email}>{rep.name} ({rep.email})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} /></div>
              <div className="col-span-2 space-y-2">
                <Label>Consent Status (FCC/TCPA)</Label>
                <div className="flex gap-2">
                  <button type="button" onClick={() => setForm({ ...form, consent_status: 'given', consent_given: true, consent_date: new Date().toISOString() })}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${form.consent_status === 'given' ? 'bg-emerald-500/20 border-emerald-500 text-emerald-500' : 'border-border bg-muted/20 hover:bg-muted/40'}`}>
                    Consent Given
                  </button>
                  <button type="button" onClick={() => setForm({ ...form, consent_status: 'not_given', consent_given: false })}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${form.consent_status === 'not_given' ? 'bg-red-500/20 border-red-500 text-red-500' : 'border-border bg-muted/20 hover:bg-muted/40'}`}>
                    No Consent
                  </button>
                  <button type="button" onClick={() => setForm({ ...form, consent_status: 'unknown', consent_given: false })}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition-all ${(!form.consent_status || form.consent_status === 'unknown') ? 'bg-amber-500/20 border-amber-500 text-amber-500' : 'border-border bg-muted/20 hover:bg-muted/40'}`}>
                    Unknown
                  </button>
                </div>
                {(!form.consent_status || form.consent_status === 'unknown') && (
                  <p className="text-[11px] text-amber-500/80">The AI bot will call or email this lead to obtain consent before dialing.</p>
                )}
              </div>
            </div>
            {!editLead && duplicates.length > 0 && (
              <div className="col-span-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 space-y-2">
                <div className="flex items-center gap-2 text-amber-700 font-semibold text-sm">
                  <AlertTriangle className="w-4 h-4" />
                  Duplicate detected — {duplicates.length} existing lead{duplicates.length > 1 ? 's' : ''} match this phone or email
                </div>
                {duplicates.slice(0, 3).map(d => (
                  <div key={d.id} className="text-xs text-amber-800 flex items-center gap-2 pl-6">
                    <Copy className="w-3 h-3" />
                    <strong>{d.first_name} {d.last_name}</strong> · {d.phone} · {d.email || '—'} · <StatusBadge status={d.status} />
                  </div>
                ))}
              </div>
            )}
            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={!form.first_name || !form.phone}>
                {editLead ? 'Update' : 'Create'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>

      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search leads..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 h-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-40 h-9"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Status</SelectItem>
            {['new','contacted','qualified','appointment_set','not_interested','do_not_call'].map(s => (
              <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Bulk Action Toolbar */}
      {selected.size > 0 && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 p-3 bg-primary/5 border border-primary/20 rounded-xl">
          <span className="text-sm font-semibold text-primary">{selected.size} selected</span>
          <div className="h-4 w-px bg-border hidden sm:block" />
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <Select onValueChange={bulkUpdateStatus}>
              <SelectTrigger className="w-full sm:w-36 h-9 text-xs"><Tag className="w-3 h-3 mr-1" /><SelectValue placeholder="Set Status" /></SelectTrigger>
              <SelectContent>
                {['new','contacted','qualified','appointment_set','not_interested'].map(s => (
                  <SelectItem key={s} value={s} className="text-xs">{s.replace(/_/g, ' ')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1 flex-1 sm:flex-none" onClick={bulkGrantConsent}>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />Grant Consent
            </Button>
            <Select onValueChange={bulkAssign}>
              <SelectTrigger className="w-full sm:w-36 h-9 text-xs"><Users className="w-3 h-3 mr-1" /><SelectValue placeholder="Assign To" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="_unassign" className="text-xs">Unassign</SelectItem>
                {salesReps.map(rep => (
                  <SelectItem key={rep.id} value={rep.email} className="text-xs">{rep.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1 flex-1 sm:flex-none" onClick={bulkAddDNC}>
              <PhoneOff className="w-3.5 h-3.5 text-red-500" />Add to DNC
            </Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1 flex-1 sm:flex-none" onClick={bulkQualify} disabled={bulkQualifying}>
              {bulkQualifying ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Qualifying...</> : <><Sparkles className="w-3.5 h-3.5 text-primary" />AI Qualify</>}
            </Button>
            <Button size="sm" variant="outline" className="h-9 text-xs gap-1 flex-1 sm:flex-none text-destructive hover:text-destructive" onClick={bulkDelete}>
              <Trash2 className="w-3.5 h-3.5" />Delete
            </Button>
            <Button size="sm" variant="ghost" className="h-9 text-xs gap-1 sm:ml-auto" onClick={() => setSelected(new Set())}>
              <XSquare className="w-3.5 h-3.5" />Clear
            </Button>
          </div>
        </div>
      )}

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-10">
                  <Checkbox checked={allSelected} onCheckedChange={toggleAll} />
                </TableHead>
                <TableHead className="min-w-[120px]">Name</TableHead>
                <TableHead className="min-w-[110px]">Phone</TableHead>
                <TableHead className="min-w-[150px]">Email</TableHead>
                <TableHead className="min-w-[100px]">Company</TableHead>
                <TableHead className="min-w-[90px]">Status</TableHead>
                <TableHead className="min-w-[100px]">Source</TableHead>
                <TableHead className="min-w-[70px]">Consent</TableHead>
                <TableHead className="min-w-[100px]">Assigned To</TableHead>
                <TableHead className="min-w-[60px]">Calls</TableHead>
                <TableHead className="w-20">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={11} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
              ) : filtered.length === 0 ? (
                <TableRow><TableCell colSpan={11} className="text-center py-8">
                  <div className="flex flex-col items-center gap-2">
                    <Users className="w-12 h-12 text-muted-foreground/50" />
                    <p className="text-muted-foreground">
                      {leads.length === 0 
                        ? user?.email 
                          ? `No leads found for ${user.email}`
                          : 'Loading user session...'
                        : 'No leads match your search filters'}
                    </p>
                    {leads.length === 0 && user?.email && (
                      <Button onClick={openNew} variant="outline" className="mt-2">
                        <Plus className="w-4 h-4 mr-2" />Create Your First Lead
                      </Button>
                    )}
                  </div>
                </TableCell></TableRow>
              ) : filtered.map(lead => (
                <TableRow key={lead.id} className={`hover:bg-muted/30 transition-colors ${selected.has(lead.id) ? 'bg-primary/5' : ''}`}>
                  <TableCell><Checkbox checked={selected.has(lead.id)} onCheckedChange={() => toggleOne(lead.id)} /></TableCell>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="truncate">{lead.first_name} {lead.last_name}</span>
                      {duplicateIds.has(lead.id) && (
                        <span title="Duplicate phone or email detected" className="inline-flex items-center gap-1 text-[10px] font-semibold text-amber-700 bg-amber-500/10 border border-amber-500/20 rounded px-1.5 py-0.5 shrink-0">
                          <Copy className="w-2.5 h-2.5" />DUP
                        </span>
                      )}
                    </div>
                  </TableCell>
                  <TableCell><ClickToCall phone={lead.phone} /></TableCell>
                  <TableCell className="text-sm truncate max-w-[150px]">{lead.email}</TableCell>
                  <TableCell className="text-sm truncate max-w-[100px]">{lead.company}</TableCell>
                  <TableCell><StatusBadge status={lead.status} /></TableCell>
                  <TableCell className="text-xs truncate max-w-[100px]" title={lead.source || '—'}>
                    {lead.source ? (
                      <Badge variant="outline" className="text-[10px] bg-primary/5 border-primary/20">
                        {lead.source.length > 25 ? lead.source.substring(0, 25) + '...' : lead.source}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <span className={`text-xs font-medium whitespace-nowrap ${lead.consent_status === 'given' ? 'text-emerald-500' : lead.consent_status === 'not_given' ? 'text-red-500' : 'text-amber-500'}`}>
                      {lead.consent_status === 'given' ? '✓ Given' : lead.consent_status === 'not_given' ? '✗ None' : '? Unknown'}
                    </span>
                  </TableCell>
                  <TableCell className="max-w-[140px]">
                    <Select
                      value={lead.assigned_to || '_unassigned'}
                      onValueChange={(v) => assignLead(lead.id, v === '_unassigned' ? '' : v, `${lead.first_name} ${lead.last_name}`)}
                    >
                      <SelectTrigger className="h-7 text-xs w-full">
                        <SelectValue placeholder="Unassigned" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="_unassigned" className="text-xs">Unassigned</SelectItem>
                        {salesReps.map(rep => (
                          <SelectItem key={rep.id} value={rep.email} className="text-xs">{rep.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-sm whitespace-nowrap">{lead.call_attempts || 0}</TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" title="View Lead" onClick={() => setViewLead(lead)}><Eye className="w-3.5 h-3.5" /></Button>
                      <Button variant="ghost" size="icon" title="AI Qualify" disabled={qualifyingId === lead.id} onClick={() => qualifyLead(lead)}>
                        {qualifyingId === lead.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-primary" />}
                      </Button>
                      <Button variant="ghost" size="icon" title="Edit Lead" onClick={() => openEdit(lead)}><Pencil className="w-3.5 h-3.5" /></Button>
                      <Button variant="ghost" size="icon" title="Delete Lead" onClick={() => confirmDelete(lead)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* View Lead Dialog — full read-only lead profile */}
      <Dialog open={!!viewLead} onOpenChange={(open) => !open && setViewLead(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Eye className="w-4 h-4 text-primary" />Lead Profile</DialogTitle>
            <DialogDescription>Full read-only view of this lead's information.</DialogDescription>
          </DialogHeader>
          {viewLead && (
            <div className="space-y-4">
              <LeadProfileSummary lead={viewLead} />
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><span className="text-muted-foreground text-xs">First Name</span><p className="font-medium">{viewLead.first_name || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Last Name</span><p className="font-medium">{viewLead.last_name || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Phone</span><p className="font-medium"><ClickToCall phone={viewLead.phone} /></p></div>
                <div><span className="text-muted-foreground text-xs">Email</span><p className="font-medium truncate" title={viewLead.email}>{viewLead.email || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Company</span><p className="font-medium">{viewLead.company || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Source</span><p className="font-medium">{viewLead.source || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Status</span><p><StatusBadge status={viewLead.status} /></p></div>
                <div><span className="text-muted-foreground text-xs">Consent</span>
                  <p className={`text-xs font-medium ${viewLead.consent_status === 'given' ? 'text-emerald-500' : viewLead.consent_status === 'not_given' ? 'text-red-500' : 'text-amber-500'}`}>
                    {viewLead.consent_status === 'given' ? '✓ Given' : viewLead.consent_status === 'not_given' ? '✗ None' : '? Unknown'}
                  </p>
                </div>
                <div><span className="text-muted-foreground text-xs">Timezone</span><p className="font-medium">{viewLead.timezone || '—'}</p></div>
                <div><span className="text-muted-foreground text-xs">Assigned To</span><p className="font-medium truncate" title={viewLead.assigned_to}>{viewLead.assigned_to || 'Unassigned'}</p></div>
                <div><span className="text-muted-foreground text-xs">Call Attempts</span><p className="font-medium">{viewLead.call_attempts || 0}</p></div>
                <div><span className="text-muted-foreground text-xs">Last Called</span><p className="font-medium">{viewLead.last_called ? format(new Date(viewLead.last_called), 'MMM d, yyyy h:mm a') : 'Never'}</p></div>
              </div>
              {viewLead.notes && (
                <div>
                  <span className="text-muted-foreground text-xs">Notes</span>
                  <div className="mt-1 p-3 rounded-lg bg-muted/30 border border-border text-sm whitespace-pre-wrap max-h-48 overflow-y-auto">{viewLead.notes}</div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewLead(null)}>Close</Button>
            <Button onClick={() => { const lead = viewLead; setViewLead(null); openEdit(lead); }}><Pencil className="w-3.5 h-3.5 mr-1" />Edit Lead</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Lead</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete <strong>{leadToDelete?.first_name} {leadToDelete?.last_name}</strong>?
              <br /><br />
              This action cannot be undone and will permanently remove all call logs, appointments, and associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => {
                if (leadToDelete?.id) {
                  deleteMut.mutate(leadToDelete.id);
                }
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
    </PullToRefresh>
  );
}