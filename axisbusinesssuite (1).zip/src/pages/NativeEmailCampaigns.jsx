import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mail, Plus, Send, Sparkles, Clock, Users, Eye, MousePointerClick, AlertCircle, Trash2, Edit } from 'lucide-react';
import { toast } from 'sonner';

export default function NativeEmailCampaigns() {
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [audiencePreview, setAudiencePreview] = useState(null);
  const [formData, setFormData] = useState({
    campaign_name: '', subject_line: '', preheader_text: '',
    body_html: '', body_text: '', audience_filter: '',
    from_name: '', reply_to: '',
  });

  const loadCampaigns = async () => {
    setLoading(true);
    try {
      const list = await base44.entities.EmailCampaign.list('-created_date', 50);
      setCampaigns(list);
    } catch (e) {
      toast.error('Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadCampaigns(); }, []);

  const handleAiGenerate = async () => {
    if (!formData.campaign_name) {
      toast.error('Enter a campaign name/topic first');
      return;
    }
    setAiGenerating(true);
    try {
      const resp = await base44.functions.invoke('emailCampaignEngine', {
        action: 'ai_generate',
        payload: {
          topic: formData.campaign_name,
          audience_description: formData.audience_filter,
          tone: 'professional',
          goal: 'drive engagement and conversions',
        },
      });
      const content = resp.data.content;
      setFormData(prev => ({
        ...prev,
        subject_line: content.subject_line || prev.subject_line,
        preheader_text: content.preheader_text || prev.preheader_text,
        body_html: content.body_html || prev.body_html,
        body_text: content.body_text || prev.body_text,
      }));
      toast.success('AI content generated');
    } catch (e) {
      toast.error('AI generation failed');
    } finally {
      setAiGenerating(false);
    }
  };

  const handlePreviewAudience = async () => {
    try {
      const resp = await base44.functions.invoke('emailCampaignEngine', {
        action: 'preview_audience',
        payload: { audience_filter: formData.audience_filter },
      });
      setAudiencePreview(resp.data);
    } catch (e) {
      toast.error('Failed to preview audience');
    }
  };

  const handleSave = async () => {
    if (!formData.campaign_name || !formData.subject_line) {
      toast.error('Campaign name and subject line are required');
      return;
    }
    try {
      if (editing) {
        await base44.entities.EmailCampaign.update(editing.id, formData);
        toast.success('Campaign updated');
      } else {
        await base44.functions.invoke('emailCampaignEngine', {
          action: 'create_campaign', payload: formData,
        });
        toast.success('Campaign created');
      }
      setShowModal(false);
      setEditing(null);
      setFormData({ campaign_name: '', subject_line: '', preheader_text: '', body_html: '', body_text: '', audience_filter: '', from_name: '', reply_to: '' });
      setAudiencePreview(null);
      loadCampaigns();
    } catch (e) {
      toast.error('Failed to save campaign');
    }
  };

  const handleSend = async (campaign) => {
    if (!confirm(`Send "${campaign.campaign_name}" to all matching recipients?`)) return;
    setSending(true);
    try {
      const resp = await base44.functions.invoke('emailCampaignEngine', {
        action: 'send_campaign', payload: { campaign_id: campaign.id },
      });
      toast.success(`Sent ${resp.data.sent} emails (${resp.data.bounced} bounced)`);
      loadCampaigns();
    } catch (e) {
      toast.error('Failed to send campaign');
    } finally {
      setSending(false);
    }
  };

  const handleEdit = (campaign) => {
    setEditing(campaign);
    setFormData({
      campaign_name: campaign.campaign_name || '',
      subject_line: campaign.subject_line || '',
      preheader_text: campaign.preheader_text || '',
      body_html: campaign.body_html || '',
      body_text: campaign.body_text || '',
      audience_filter: campaign.audience_filter || '',
      from_name: campaign.from_name || '',
      reply_to: campaign.reply_to || '',
    });
    setShowModal(true);
  };

  const handleDelete = async (id) => {
    try {
      await base44.entities.EmailCampaign.delete(id);
      toast.success('Campaign deleted');
      loadCampaigns();
    } catch (e) {
      toast.error('Delete failed');
    }
  };

  const statusColors = {
    draft: 'bg-gray-500/20 text-gray-400',
    scheduled: 'bg-blue-500/20 text-blue-400',
    sending: 'bg-yellow-500/20 text-yellow-400',
    sent: 'bg-green-500/20 text-green-400',
    paused: 'bg-orange-500/20 text-orange-400',
    cancelled: 'bg-red-500/20 text-red-400',
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Mail className="w-6 h-6 text-primary" />
            Email Campaigns
          </h1>
          <p className="text-sm text-muted-foreground">Native campaign builder — no Mailchimp needed</p>
        </div>
        <Button onClick={() => { setEditing(null); setFormData({ campaign_name: '', subject_line: '', preheader_text: '', body_html: '', body_text: '', audience_filter: '', from_name: '', reply_to: '' }); setAudiencePreview(null); setShowModal(true); }}>
          <Plus className="w-4 h-4 mr-1" /> New Campaign
        </Button>
      </div>

      {/* Campaign List */}
      <div className="grid gap-4">
        {loading ? (
          <p className="text-sm text-muted-foreground">Loading...</p>
        ) : campaigns.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Mail className="w-12 h-12 text-muted-foreground mx-auto mb-2 opacity-50" />
              <p className="text-muted-foreground">No campaigns yet</p>
              <p className="text-xs text-muted-foreground mt-1">Create your first email campaign to get started</p>
            </CardContent>
          </Card>
        ) : (
          campaigns.map(c => (
            <Card key={c.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between flex-wrap gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold truncate">{c.campaign_name}</h3>
                      <Badge className={statusColors[c.status] || statusColors.draft}>{c.status}</Badge>
                      {c.ai_generated && <Badge variant="outline"><Sparkles className="w-3 h-3 mr-1" />AI</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{c.subject_line}</p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      {c.sent_count > 0 && (
                        <>
                          <span className="flex items-center gap-1"><Send className="w-3 h-3" />{c.sent_count} sent</span>
                          <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{c.open_count} opens</span>
                          <span className="flex items-center gap-1"><MousePointerClick className="w-3 h-3" />{c.click_count} clicks</span>
                        </>
                      )}
                      {c.sent_at && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(c.sent_at).toLocaleDateString()}</span>}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {c.status === 'draft' && (
                      <Button size="sm" onClick={() => handleSend(c)} disabled={sending}>
                        <Send className="w-3 h-3 mr-1" /> Send
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(c)}><Edit className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDelete(c.id)}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Campaign Editor Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Campaign' : 'New Campaign'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Label>Campaign Name / Topic</Label>
                <Input value={formData.campaign_name} onChange={e => setFormData({ ...formData, campaign_name: e.target.value })} placeholder="e.g. Summer Promo" />
              </div>
              <Button variant="outline" onClick={handleAiGenerate} disabled={aiGenerating} className="mt-6">
                <Sparkles className="w-4 h-4 mr-1" /> {aiGenerating ? 'Generating...' : 'AI Write'}
              </Button>
            </div>
            <div>
              <Label>Subject Line</Label>
              <Input value={formData.subject_line} onChange={e => setFormData({ ...formData, subject_line: e.target.value })} placeholder="Max 60 characters" maxLength={60} />
            </div>
            <div>
              <Label>Preheader Text</Label>
              <Input value={formData.preheader_text} onChange={e => setFormData({ ...formData, preheader_text: e.target.value })} placeholder="Preview text in inbox" />
            </div>
            <div>
              <Label>Email Body (HTML)</Label>
              <Textarea value={formData.body_html} onChange={e => setFormData({ ...formData, body_html: e.target.value })} rows={8} placeholder="<h1>Hello {{first_name}}</h1><p>...</p>" className="font-mono text-xs" />
            </div>
            <div>
              <Label>Plain Text Fallback</Label>
              <Textarea value={formData.body_text} onChange={e => setFormData({ ...formData, body_text: e.target.value })} rows={4} />
            </div>
            <div>
              <Label>Audience Filter (JSON)</Label>
              <Textarea value={formData.audience_filter} onChange={e => setFormData({ ...formData, audience_filter: e.target.value })} rows={2} placeholder='{"status": "new", "consent_given": true}' className="font-mono text-xs" />
              <Button variant="link" size="sm" onClick={handlePreviewAudience} className="mt-1 p-0 h-auto">
                <Users className="w-3 h-3 mr-1" /> Preview Audience
              </Button>
              {audiencePreview && (
                <p className="text-xs text-muted-foreground mt-1">
                  {audiencePreview.recipient_count} recipients match
                </p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>From Name</Label>
                <Input value={formData.from_name} onChange={e => setFormData({ ...formData, from_name: e.target.value })} placeholder="Your Name" />
              </div>
              <div>
                <Label>Reply-To</Label>
                <Input value={formData.reply_to} onChange={e => setFormData({ ...formData, reply_to: e.target.value })} placeholder="you@example.com" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editing ? 'Update' : 'Create'} Campaign</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}