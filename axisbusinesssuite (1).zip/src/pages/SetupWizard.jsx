import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle2, Circle, ExternalLink, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import WhiteGloveSetupTiers from '@/components/setup/WhiteGloveSetupTiers';

const INTEGRATION_CATEGORIES = [
  {
    label: '📞 Phone & Calling',
    color: 'text-blue-400',
    integrations: [
      { id: 'twilio', name: 'Twilio', desc: 'AI call bot & SMS — required for outbound calling', required: true, setupUrl: 'https://console.twilio.com', steps: ['Go to twilio.com and create a free account', 'Buy a phone number ($1/mo)', 'Copy your Account SID and Auth Token', 'Paste them in Settings → Integrations'] },
      { id: 'zoom', name: 'Zoom', desc: 'Video meetings & interview scheduling', required: false, setupUrl: 'https://zoom.us/oauth', steps: ['Sign in to zoom.us', 'Go to Marketplace → Build App', 'Create an OAuth app', 'Copy Client ID and Secret into Settings'] },
    ]
  },
  {
    label: '📅 Scheduling',
    color: 'text-emerald-400',
    integrations: [
      { id: 'google_calendar', name: 'Google Calendar', desc: 'Sync all appointments automatically', required: false, setupUrl: null, steps: ['Go to Settings → Integrations in this app', 'Click "Connect Google Calendar"', 'Sign in with your Google account', 'Allow the requested permissions'] },
    ]
  },
  {
    label: '📣 Marketing & Social',
    color: 'text-pink-400',
    integrations: [
      { id: 'facebook', name: 'Facebook / Meta', desc: 'Lead ads & social media posting', required: false, setupUrl: 'https://business.facebook.com', steps: ['Create a Facebook Business account', 'Set up a Business Manager', 'Connect your Facebook Page', 'Generate a long-lived access token and paste in Settings → Social Media'] },
      { id: 'instagram', name: 'Instagram', desc: 'Auto-post content & stories', required: false, setupUrl: 'https://business.facebook.com', steps: ['Connect your Instagram Business account to Facebook Business Manager', 'Then connect Facebook in this app — Instagram comes automatically'] },
    ]
  },
  {
    label: '💰 Finance & Payments',
    color: 'text-yellow-400',
    integrations: [
      { id: 'stripe', name: 'Stripe', desc: 'Accept payments & subscriptions', required: false, setupUrl: 'https://dashboard.stripe.com', steps: ['Go to stripe.com and create an account', 'Verify your identity and bank account', 'Go to Developers → API Keys', 'Copy your Secret Key and paste in Settings → Finance'] },
      { id: 'quickbooks', name: 'QuickBooks', desc: 'Sync invoices & expenses automatically', required: false, setupUrl: 'https://quickbooks.intuit.com', steps: ['Log in to QuickBooks Online', 'Go to Apps → Find Apps → search "Axis"', 'Connect and authorize the integration', 'All invoices will auto-sync'] },
    ]
  },
  {
    label: '👥 HR & Recruiting',
    color: 'text-violet-400',
    integrations: [
      { id: 'indeed', name: 'Indeed', desc: 'Auto-source candidates from Indeed job posts', required: false, setupUrl: 'https://employers.indeed.com', steps: ['Create an Indeed Employer account', 'Post a job listing', 'The AI will automatically search and import matching candidates'] },
      { id: 'bamboohr', name: 'BambooHR', desc: 'Sync employee records & HR data', required: false, setupUrl: 'https://www.bamboohr.com', steps: ['Log into BambooHR', 'Go to API Keys under your profile', 'Generate an API key', 'Enter it in Settings → HR Integrations'] },
    ]
  },
  {
    label: '📊 CRM & Sales Tools',
    color: 'text-orange-400',
    integrations: [
      { id: 'hubspot', name: 'HubSpot', desc: 'Bi-directional CRM sync', required: false, setupUrl: 'https://app.hubspot.com', steps: ['In HubSpot, go to Settings → Integrations → API Key', 'Generate a private app token', 'Paste it in Settings → CRM Integrations', 'Axis will sync leads both ways automatically'] },
      { id: 'salesforce', name: 'Salesforce', desc: 'Enterprise CRM sync', required: false, setupUrl: 'https://login.salesforce.com', steps: ['Log in to Salesforce', 'Go to Setup → API → Connected Apps', 'Create a Connected App', 'Copy credentials into Settings → CRM Integrations'] },
    ]
  },
];

export default function SetupWizard() {
  const [expanded, setExpanded] = useState(null);
  const [completed, setCompleted] = useState({});

  const totalRequired = INTEGRATION_CATEGORIES.flatMap(c => c.integrations).filter(i => i.required).length;
  const completedRequired = INTEGRATION_CATEGORIES.flatMap(c => c.integrations).filter(i => i.required && completed[i.id]).length;

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div>
        <Badge className="mb-2">Setup Wizard</Badge>
        <h1 className="text-3xl font-black">Connect Your Business Systems</h1>
        <p className="text-muted-foreground mt-1">Follow these step-by-step guides — no tech skills needed. Each integration unlocks more automation.</p>
      </div>

      {/* Progress bar */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-4 flex items-center gap-4">
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-semibold">Required integrations</span>
              <span className="text-sm text-primary font-bold">{completedRequired}/{totalRequired} done</span>
            </div>
            <div className="h-2 bg-muted rounded-full overflow-hidden">
              <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${(completedRequired / totalRequired) * 100}%` }} />
            </div>
          </div>
          {completedRequired === totalRequired && (
            <Badge className="bg-emerald-500 text-white">🎉 Ready to Launch!</Badge>
          )}
        </CardContent>
      </Card>

      {/* White Glove Setup Tiers */}
      <WhiteGloveSetupTiers />

      {/* Integration categories */}
      {INTEGRATION_CATEGORIES.map(cat => (
        <div key={cat.label}>
          <h2 className={`text-lg font-bold mb-3 ${cat.color}`}>{cat.label}</h2>
          <div className="space-y-3">
            {cat.integrations.map(integration => (
              <Card key={integration.id} className={`transition-all ${completed[integration.id] ? 'border-emerald-500/40 bg-emerald-500/5' : 'hover:border-border/60'}`}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <button onClick={() => setCompleted(prev => ({ ...prev, [integration.id]: !prev[integration.id] }))} className="shrink-0">
                      {completed[integration.id]
                        ? <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                        : <Circle className="w-6 h-6 text-muted-foreground" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{integration.name}</span>
                        {integration.required && <Badge className="bg-primary/10 text-primary border-primary/30 text-xs">Required</Badge>}
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{integration.desc}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="shrink-0 text-xs" onClick={() => setExpanded(expanded === integration.id ? null : integration.id)}>
                      {expanded === integration.id ? 'Hide steps' : 'How to connect'}
                    </Button>
                  </div>

                  {expanded === integration.id && (
                    <div className="mt-4 ml-9 space-y-2">
                      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Step-by-step instructions:</p>
                      {integration.steps.map((step, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm">
                          <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center shrink-0 mt-0.5 font-bold">{i + 1}</span>
                          <span className="text-muted-foreground">{step}</span>
                        </div>
                      ))}
                      {integration.setupUrl && (
                        <a href={integration.setupUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-2">
                          <ExternalLink className="w-3 h-3" /> Open {integration.name} →
                        </a>
                      )}
                      {!integration.setupUrl && (
                        <Link to="/settings" className="inline-flex items-center gap-1 text-xs text-primary hover:underline mt-2">
                          Go to Settings to connect →
                        </Link>
                      )}
                      <button
                        className="mt-3 text-xs text-emerald-500 hover:underline flex items-center gap-1"
                        onClick={() => { setCompleted(prev => ({ ...prev, [integration.id]: true })); setExpanded(null); }}
                      >
                        <CheckCircle2 className="w-3 h-3" /> Mark as connected
                      </button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}

      {/* Next step */}
      <Card className="border-primary/30 bg-primary/5">
        <CardContent className="p-5 text-center space-y-3">
          <p className="font-bold text-lg">🚀 All set? Let's go.</p>
          <p className="text-sm text-muted-foreground">Once your integrations are connected, the AI will automatically start syncing data, generating leads, and running your business.</p>
          <Button asChild className="gap-2">
            <Link to="/app">Go to Dashboard <ArrowRight className="w-4 h-4" /></Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}