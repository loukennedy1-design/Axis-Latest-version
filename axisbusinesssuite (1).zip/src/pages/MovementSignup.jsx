import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Check, Shield, Zap, Lock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const MOVEMENT_FEATURES = [
  'AI Call Bot (auto-dialer)',
  'Lead CRM & Management',
  'AI Lead Scoring & Routing',
  'Nurture Workflows',
  'Coaching Hub (AI Call Analysis)',
  'Sales Team Management',
  'Calendly Scheduling',
  'Zoom Integration',
  'Recruitment Module',
  'AI Lead Generator',
  'Social Media AI',
  'HR Suite',
  'Email Outreach',
  'Unlimited Leads & Calls',
];

export default function MovementSignup() {
  const [step, setStep] = useState('access'); // 'access' | 'signup'
  const [accessCode, setAccessCode] = useState('');
  const [form, setForm] = useState({ name: '', email: '' });
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [billingCycle, setBillingCycle] = useState('monthly');

  const verifyCode = async () => {
    if (!accessCode.trim()) return;
    setVerifying(true);
    const res = await base44.functions.invoke('verifyAccessCode', { type: 'movement_code', code: accessCode });
    setVerifying(false);
    if (res.data?.valid) {
      setStep('signup');
    } else {
      toast.error('Invalid access code. This plan is by invitation only.');
    }
  };

  const MOVEMENT_MONTHLY = 29.99;

  const handleSubmit = async () => {
    if (!form.name || !form.email) return toast.error('Please fill in all fields.');
    setLoading(true);
    const planPrice = billingCycle === 'yearly'
      ? Math.round(MOVEMENT_MONTHLY * 12 * 0.85 * 100) / 100
      : MOVEMENT_MONTHLY;

    const res = await base44.functions.invoke('createTrialAndCharge', {
      email: form.email,
      fullName: form.name,
      planKey: 'movement',
      planPrice,
      isYearly: billingCycle === 'yearly',
      discount: 0,
    });
    setLoading(false);
    if (res.data?.checkoutUrl) {
      window.location.href = res.data.checkoutUrl;
    } else {
      toast.error(res.data?.error || 'Something went wrong. Please try again.');
    }
  };

  if (step === 'access') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-4">
        <Card className="w-full max-w-md border-2 border-primary/40 bg-card shadow-2xl shadow-primary/10">
          <CardHeader className="text-center pb-4">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
              <Lock className="w-7 h-7 text-primary" />
            </div>
            <CardTitle className="text-2xl font-black">Private Access</CardTitle>
            <p className="text-muted-foreground text-sm mt-1">This plan is exclusive to The Movement members. Enter your access code to continue.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Access Code</Label>
              <Input
                placeholder="Enter your access code..."
                value={accessCode}
                onChange={e => setAccessCode(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && verifyCode()}
                className="mt-1 text-center tracking-widest font-mono uppercase"
              />
            </div>
            <Button className="w-full" onClick={verifyCode} disabled={verifying}>
                {verifying ? 'Verifying...' : 'Verify & Continue'}
            </Button>
            <p className="text-center text-xs text-muted-foreground">Don't have an access code? Contact your Movement coordinator.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const monthlyPrice = 29.99;
  const yearlyPrice = Math.round(monthlyPrice * 12 * 0.85 * 100) / 100;
  const monthlyEquiv = Math.round(monthlyPrice * 0.85 * 100) / 100;

  return (
    <div className="min-h-screen bg-background px-4 py-12">
      <div className="max-w-2xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <Badge className="bg-primary/10 text-primary border-primary/30 px-4 py-1.5 text-sm font-semibold">
            🔒 The Movement — Exclusive Plan
          </Badge>
          <h1 className="text-4xl font-black tracking-tight">Full Access. One Price.</h1>
          <p className="text-muted-foreground">Everything in the Business plan — exclusively for Movement members at a special rate.</p>
        </div>

        {/* Pricing Card */}
        <Card className="border-2 border-primary/50 bg-primary/5 shadow-xl shadow-primary/10">
          <CardContent className="p-8">
            {/* Billing Toggle */}
            <div className="flex items-center justify-center mb-6">
              <div className="flex items-center gap-2 bg-muted rounded-xl p-1">
                <button
                  onClick={() => setBillingCycle('monthly')}
                  className={`px-5 py-2 rounded-lg font-medium text-sm transition-all ${billingCycle === 'monthly' ? 'bg-background shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                >Monthly</button>
                <button
                  onClick={() => setBillingCycle('yearly')}
                  className={`px-5 py-2 rounded-lg font-medium text-sm transition-all ${billingCycle === 'yearly' ? 'bg-background shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
                >
                  Yearly <span className="ml-1.5 text-[10px] bg-emerald-500 text-white rounded-full px-1.5 py-0.5 font-bold">SAVE 15%</span>
                </button>
              </div>
            </div>

            {/* Price Display */}
            <div className="text-center mb-2">
              <div className="flex items-center justify-center gap-3 mb-1">
                <span className="text-lg text-muted-foreground line-through">$149/mo</span>
                <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-xs font-bold">MEMBER DISCOUNT</Badge>
              </div>
              {billingCycle === 'monthly' ? (
                <div>
                  <span className="text-6xl font-black text-primary">$29.99</span>
                  <span className="text-muted-foreground text-lg">/mo</span>
                  <p className="text-sm text-emerald-600 font-semibold mt-1">You save $119/month vs. standard pricing</p>
                </div>
              ) : (
                <div>
                  <span className="text-6xl font-black text-primary">${yearlyPrice}</span>
                  <span className="text-muted-foreground text-lg">/yr</span>
                  <p className="text-sm text-emerald-600 font-semibold mt-1">${monthlyEquiv}/mo equivalent · save an extra 15%</p>
                </div>
              )}
            </div>

            <p className="text-center text-xs text-muted-foreground mb-6">7-day free trial · Card saved securely · $0 charged today · Cancel anytime</p>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-8 p-4 bg-background/60 rounded-xl border border-border">
              <p className="col-span-full text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-1">Everything Included:</p>
              {MOVEMENT_FEATURES.map(f => (
                <div key={f} className="flex items-center gap-2 text-sm">
                  <Check className="w-3.5 h-3.5 text-primary shrink-0" />{f}
                </div>
              ))}
            </div>

            {/* Signup Form */}
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>Full Name</Label>
                  <Input className="mt-1" placeholder="John Smith" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
                </div>
                <div>
                  <Label>Email Address</Label>
                  <Input className="mt-1" type="email" placeholder="john@company.com" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
                </div>
              </div>
              <Button className="w-full h-12 text-base font-bold gap-2" onClick={handleSubmit} disabled={loading}>
                <Zap className="w-4 h-4" />
                {loading ? 'Processing...' : `Start Free Trial — $${billingCycle === 'yearly' ? yearlyPrice + '/yr' : '29.99/mo'} after`}
              </Button>
              <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                <Shield className="w-3.5 h-3.5" /> Secured by Square · No card stored until trial ends
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}