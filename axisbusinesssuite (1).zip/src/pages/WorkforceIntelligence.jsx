import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { HeartHandshake, Loader2, RefreshCw, AlertTriangle, TrendingUp, Award } from 'lucide-react';

const TREND_COLORS = { improving: 'text-emerald-400', stable: 'text-muted-foreground', declining: 'text-red-400', unknown: 'text-muted-foreground' };

export default function WorkforceIntelligence() {
  const [profiles, setProfiles] = useState([]);
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('workforceIntelligenceEngine', { action: 'get_overview' });
      setProfiles(res.data?.profiles || []);
      setOverview(res.data?.overview);
    } catch { setProfiles([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      await base44.functions.invoke('workforceIntelligenceEngine', { action: 'analyze_all' });
      await fetchAll();
    } finally { setAnalyzing(false); }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <HeartHandshake className="w-6 h-6 text-primary" />
            Workforce Intelligence
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Full employee lifecycle analytics — burnout risk, productivity trends, training recommendations, promotion candidates, and retention probability.
          </p>
        </div>
        <Button onClick={handleAnalyze} disabled={analyzing}>
          {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {analyzing ? 'Analyzing...' : 'Analyze Workforce'}
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Profiles" value={overview?.total_profiles ?? '—'} />
        <StatCard label="Burnout Risk" value={overview?.burnout_risk_count ?? 0} color="text-red-400" icon={AlertTriangle} />
        <StatCard label="Promotion Ready" value={overview?.promotion_candidates ?? 0} color="text-amber-400" icon={Award} />
        <StatCard label="Avg Retention" value={`${overview?.avg_retention ?? 0}%`} color="text-emerald-400" icon={TrendingUp} />
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : profiles.length ? (
        <div className="grid md:grid-cols-2 gap-4">
          {profiles.map(p => {
            let training = [];
            try { training = JSON.parse(p.training_recommendations || '[]'); } catch { /* ignore */ }
            return (
              <Card key={p.id}>
                <CardContent className="pt-5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold">{p.employee_name}</h3>
                      {p.employee_email && <p className="text-xs text-muted-foreground">{p.employee_email}</p>}
                      <span className="text-xs text-muted-foreground capitalize">{p.lifecycle_stage}</span>
                    </div>
                    {p.promotion_candidate && <Award className="w-5 h-5 text-amber-400" />}
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    <Score label="Burnout Risk" value={p.burnout_risk || 0} invert />
                    <Score label="Retention" value={p.retention_probability || 0} />
                  </div>
                  <div className="mt-3 flex items-center gap-2 text-xs">
                    <span className="text-muted-foreground">Productivity:</span>
                    <span className={`capitalize ${TREND_COLORS[p.productivity_trend]}`}>{p.productivity_trend}</span>
                  </div>
                  {p.performance_summary && <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{p.performance_summary}</p>}
                  {training.length > 0 && (
                    <div className="mt-2">
                      <p className="text-xs text-muted-foreground uppercase mb-1">Training Recommendations</p>
                      <div className="flex flex-wrap gap-1">
                        {training.map((t, i) => <span key={i} className="text-xs px-2 py-0.5 rounded bg-muted">{t}</span>)}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card><CardContent className="py-12 text-center"><HeartHandshake className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No workforce profiles yet. Click "Analyze Workforce" to build intelligence profiles.</p></CardContent></Card>
      )}
    </div>
  );
}

function StatCard({ label, value, color, icon: Icon }) {
  return (
    <Card><CardContent className="pt-5">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        {Icon && <Icon className="w-4 h-4 text-primary/60" />}
      </div>
      <p className={`text-2xl font-bold font-poppins mt-1 ${color || ''}`}>{value ?? '—'}</p>
    </CardContent></Card>
  );
}

function Score({ label, value, invert }) {
  const pct = Math.min(100, value || 0);
  const color = invert
    ? pct < 30 ? 'text-emerald-400' : pct < 70 ? 'text-amber-400' : 'text-red-400'
    : pct < 30 ? 'text-red-400' : pct < 70 ? 'text-amber-400' : 'text-emerald-400';
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <div className="flex items-center gap-1.5 mt-0.5">
        <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
          <div className={`h-full ${color.replace('text-', 'bg-')}`} style={{ width: `${pct}%` }} />
        </div>
        <span className={`text-xs font-bold ${color}`}>{pct}</span>
      </div>
    </div>
  );
}