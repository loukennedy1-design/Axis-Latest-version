import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Plus, Clock, MapPin, Trash2, Edit, ChevronLeft, ChevronRight, Video } from 'lucide-react';
import { toast } from 'sonner';

export default function NativeCalendar() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [view, setView] = useState('month');
  const [showEventModal, setShowEventModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [formData, setFormData] = useState({
    title: '', description: '', start_time: '', end_time: '',
    event_type: 'meeting', location: '', meeting_url: '',
    reminder_minutes: 15, all_day: false,
  });

  const loadEvents = useCallback(async () => {
    setLoading(true);
    try {
      const start = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
      const end = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0, 23, 59, 59);
      const resp = await base44.functions.invoke('calendarEngine', {
        action: 'list_events',
        payload: { start_date: start.toISOString(), end_date: end.toISOString() },
      });
      setEvents(resp.data.events || []);
    } catch (e) {
      toast.error('Failed to load events');
    } finally {
      setLoading(false);
    }
  }, [currentDate]);

  useEffect(() => { loadEvents(); }, [loadEvents]);

  const handleSave = async () => {
    if (!formData.title || !formData.start_time) {
      toast.error('Title and start time are required');
      return;
    }
    try {
      const payload = {
        ...formData,
        start_time: new Date(formData.start_time).toISOString(),
        end_time: formData.end_time ? new Date(formData.end_time).toISOString() : new Date(new Date(formData.start_time).getTime() + 30 * 60 * 1000).toISOString(),
      };
      if (editingEvent) {
        await base44.functions.invoke('calendarEngine', {
          action: 'update_event', payload: { event_id: editingEvent.id, updates: payload },
        });
        toast.success('Event updated');
      } else {
        await base44.functions.invoke('calendarEngine', { action: 'create_event', payload });
        toast.success('Event created');
      }
      setShowEventModal(false);
      setEditingEvent(null);
      setFormData({ title: '', description: '', start_time: '', end_time: '', event_type: 'meeting', location: '', meeting_url: '', reminder_minutes: 15, all_day: false });
      loadEvents();
    } catch (e) {
      toast.error('Failed to save event');
    }
  };

  const handleDelete = async (eventId) => {
    try {
      await base44.functions.invoke('calendarEngine', { action: 'delete_event', payload: { event_id: eventId } });
      toast.success('Event deleted');
      loadEvents();
    } catch (e) {
      toast.error('Failed to delete event');
    }
  };

  const openEdit = (event) => {
    setEditingEvent(event);
    setFormData({
      title: event.title || '',
      description: event.description || '',
      start_time: event.start_time ? new Date(event.start_time).toISOString().slice(0, 16) : '',
      end_time: event.end_time ? new Date(event.end_time).toISOString().slice(0, 16) : '',
      event_type: event.event_type || 'meeting',
      location: event.location || '',
      meeting_url: event.meeting_url || '',
      reminder_minutes: event.reminder_minutes ?? 15,
      all_day: event.all_day || false,
    });
    setShowEventModal(true);
  };

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  const today = () => setCurrentDate(new Date());

  // Calendar grid
  const monthStart = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const monthEnd = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  const startDay = monthStart.getDay();
  const daysInMonth = monthEnd.getDate();
  const days = [];
  for (let i = 0; i < startDay; i++) days.push(null);
  for (let d = 1; d <= daysInMonth; d++) days.push(new Date(currentDate.getFullYear(), currentDate.getMonth(), d));

  const getEventsForDay = (date) => {
    if (!date) return [];
    return events.filter(e => {
      const eDate = new Date(e.start_time);
      return eDate.toDateString() === date.toDateString();
    });
  };

  const eventTypeColors = {
    meeting: 'bg-blue-500/20 text-blue-400',
    call: 'bg-green-500/20 text-green-400',
    appointment: 'bg-purple-500/20 text-purple-400',
    task: 'bg-orange-500/20 text-orange-400',
    reminder: 'bg-yellow-500/20 text-yellow-400',
    blocker: 'bg-red-500/20 text-red-400',
    personal: 'bg-pink-500/20 text-pink-400',
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Calendar className="w-6 h-6 text-primary" />
            AXIS Calendar
          </h1>
          <p className="text-sm text-muted-foreground">Native calendar — no external sync required</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={prevMonth}><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="outline" onClick={today}>Today</Button>
          <Button variant="outline" size="icon" onClick={nextMonth}><ChevronRight className="w-4 h-4" /></Button>
          <Button onClick={() => { setEditingEvent(null); setFormData({ title: '', description: '', start_time: '', end_time: '', event_type: 'meeting', location: '', meeting_url: '', reminder_minutes: 15, all_day: false }); setShowEventModal(true); }}>
            <Plus className="w-4 h-4 mr-1" /> New Event
          </Button>
        </div>
      </div>

      <div className="text-center">
        <h2 className="text-xl font-semibold">
          {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
        </h2>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
              <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {days.map((date, i) => {
              const dayEvents = getEventsForDay(date);
              const isToday = date && date.toDateString() === new Date().toDateString();
              return (
                <div
                  key={i}
                  className={`min-h-[80px] md:min-h-[100px] border border-border rounded-lg p-1 ${date ? 'cursor-pointer hover:bg-accent/50' : ''} ${isToday ? 'bg-primary/10 border-primary' : ''}`}
                  onClick={() => {
                    if (!date) return;
                    const timeStr = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 9, 0).toISOString().slice(0, 16);
                    setEditingEvent(null);
                    setFormData({ ...formData, start_time: timeStr });
                    setShowEventModal(true);
                  }}
                >
                  {date && (
                    <>
                      <div className="text-xs font-medium mb-1">{date.getDate()}</div>
                      <div className="space-y-1">
                        {dayEvents.slice(0, 3).map(e => (
                          <div key={e.id} className={`text-xs px-1 py-0.5 rounded truncate ${eventTypeColors[e.event_type] || eventTypeColors.meeting}`}
                               onClick={(ev) => { ev.stopPropagation(); openEdit(e); }}>
                            {e.title}
                          </div>
                        ))}
                        {dayEvents.length > 3 && (
                          <div className="text-xs text-muted-foreground">+{dayEvents.length - 3} more</div>
                        )}
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Events List */}
      <Card>
        <CardHeader><CardTitle className="text-lg">Upcoming Events</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {loading ? (
            <p className="text-sm text-muted-foreground">Loading...</p>
          ) : events.filter(e => new Date(e.start_time) >= new Date()).length === 0 ? (
            <p className="text-sm text-muted-foreground">No upcoming events</p>
          ) : (
            events.filter(e => new Date(e.start_time) >= new Date()).sort((a, b) => new Date(a.start_time) - new Date(b.start_time)).slice(0, 10).map(e => (
              <div key={e.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-accent/30">
                <div className="flex items-center gap-3 min-w-0">
                  <div className={`w-2 h-10 rounded-full ${eventTypeColors[e.event_type]?.split(' ')[0] || 'bg-primary/20'}`} />
                  <div className="min-w-0">
                    <p className="font-medium truncate">{e.title}</p>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{new Date(e.start_time).toLocaleString()}</span>
                      {e.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{e.location}</span>}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {e.meeting_url && (
                    <a href={e.meeting_url} target="_blank" rel="noopener noreferrer">
                      <Button variant="ghost" size="icon"><Video className="w-4 h-4" /></Button>
                    </a>
                  )}
                  <Button variant="ghost" size="icon" onClick={() => openEdit(e)}><Edit className="w-4 h-4" /></Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(e.id)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Event Modal */}
      <Dialog open={showEventModal} onOpenChange={setShowEventModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingEvent ? 'Edit Event' : 'New Event'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Title</Label>
              <Input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="Event title" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Start</Label>
                <Input type="datetime-local" value={formData.start_time} onChange={e => setFormData({ ...formData, start_time: e.target.value })} />
              </div>
              <div>
                <Label>End</Label>
                <Input type="datetime-local" value={formData.end_time} onChange={e => setFormData({ ...formData, end_time: e.target.value })} />
              </div>
            </div>
            <div>
              <Label>Type</Label>
              <Select value={formData.event_type} onValueChange={v => setFormData({ ...formData, event_type: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="meeting">Meeting</SelectItem>
                  <SelectItem value="call">Call</SelectItem>
                  <SelectItem value="appointment">Appointment</SelectItem>
                  <SelectItem value="task">Task</SelectItem>
                  <SelectItem value="reminder">Reminder</SelectItem>
                  <SelectItem value="blocker">Blocker</SelectItem>
                  <SelectItem value="personal">Personal</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Location</Label>
              <Input value={formData.location} onChange={e => setFormData({ ...formData, location: e.target.value })} placeholder="Office, address, or phone" />
            </div>
            <div>
              <Label>Meeting URL</Label>
              <Input value={formData.meeting_url} onChange={e => setFormData({ ...formData, meeting_url: e.target.value })} placeholder="https://meet.axis.app/..." />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={3} />
            </div>
            <div>
              <Label>Reminder (minutes before)</Label>
              <Select value={String(formData.reminder_minutes)} onValueChange={v => setFormData({ ...formData, reminder_minutes: parseInt(v) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 minutes</SelectItem>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="1440">1 day</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEventModal(false)}>Cancel</Button>
            <Button onClick={handleSave}>{editingEvent ? 'Update' : 'Create'} Event</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}