import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Video, Plus, Calendar, Clock, Copy, Users, VideoIcon, Sparkles, Link2, Mail, Zap, History, Trash2, UserPlus, Phone, Edit3 } from 'lucide-react';
import { toast } from 'sonner';
import { format, isPast } from 'date-fns';
import ScheduleMeetingDialog from '@/components/meet/ScheduleMeetingDialog';
import EditMeetingDialog from '@/components/meet/EditMeetingDialog';
import InviteDialog from '@/components/meet/InviteDialog';
import MeetingBreakdown from '@/components/meet/MeetingBreakdown';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

export default function AxisMeet() {
  const { user } = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [instantLoading, setInstantLoading] = useState(false);
  const [callDialogOpen, setCallDialogOpen] = useState(false);
  const [editMeeting, setEditMeeting] = useState(null);
  const [inviteMeeting, setInviteMeeting] = useState(null);

  const { data: meetings = [], isLoading } = useQuery({
    queryKey: ['internal-meetings'],
    queryFn: () => base44.entities.InternalMeeting.list('-scheduled_at', 100),
  });

  const { data: teamMembers = [] } = useQuery({
    queryKey: ['team-members'],
    queryFn: () => base44.entities.User.list(),
  });

  const isAdmin = user?.role === 'admin' || user?.role === 'super_admin';
  // Scope the Call Team list to the current subscriber's team only (not every
  // subscriber in the system). Sub-users carry account_owner_email pointing at
  // their admin; admins match their own email. Super-admins see everyone.
  const subscriberEmail = user?.account_owner_email || user?.email;
  const isSuperAdmin = user?.role === 'super_admin';
  const callTeamMembers = isSuperAdmin
    ? teamMembers
    : teamMembers.filter(m => !subscriberEmail || m.email === subscriberEmail || m.account_owner_email === subscriberEmail || m.email === user?.email);

  const upcoming = meetings.filter(m =>
    (m.status === 'scheduled' || m.status === 'active') &&
    m.scheduled_at && !isPast(new Date(m.scheduled_at)) || m.status === 'active'
  ).sort((a, b) => {
    // Earliest scheduled time first (the next meeting at the top). Meetings
    // without a confirmed time (e.g. unselected window slots) sink to the bottom.
    const at = a.scheduled_at ? new Date(a.scheduled_at).getTime() : Infinity;
    const bt = b.scheduled_at ? new Date(b.scheduled_at).getTime() : Infinity;
    return at - bt;
  });
  const past = meetings.filter(m => m.status === 'completed' || (m.scheduled_at && isPast(new Date(m.scheduled_at)) && m.status !== 'active'));

  const startInstantMeeting = async () => {
    setInstantLoading(true);
    try {
      const res = await base44.functions.invoke('meetingIntelligence', {
        action: 'create_meeting',
        title: `Instant Meeting — ${format(new Date(), 'MMM d, h:mm a')}`,
        department: 'sales',
        scheduled_at: new Date().toISOString(),
        duration_minutes: 30,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Instant meeting started');
      qc.invalidateQueries({ queryKey: ['internal-meetings'] });
      navigate(`/meet/room/${res.data.meeting.meeting_id}`);
    } catch (e) {
      toast.error(e.message || 'Failed to start meeting');
    } finally {
      setInstantLoading(false);
    }
  };

  const copyLink = (url) => {
    navigator.clipboard.writeText(url);
    toast.success('Link copied to clipboard');
  };

  const joinMeeting = (meeting) => {
    navigate(`/meet/room/${meeting.meeting_id}`);
  };

  const deleteMeeting = async (meeting) => {
    if (!confirm(`Delete meeting "${meeting.title}"? This cannot be undone.`)) return;
    try {
      const res = await base44.functions.invoke('deleteMeeting', { meeting_id: meeting.meeting_id });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Meeting deleted');
      qc.invalidateQueries({ queryKey: ['internal-meetings'] });
    } catch (e) {
      toast.error(e.message || 'Failed to delete meeting');
    }
  };

  const inviteUser = (meeting) => {
    setInviteMeeting(meeting);
  };

  const callTeamMember = (member) => {
    if (member.phone) {
      window.location.href = `tel:${member.phone.replace(/\s|\(|\)|-/g, '')}`;
      toast.success(`Calling ${member.full_name || member.email}...`);
      setCallDialogOpen(false);
    } else {
      toast.error(`${member.full_name || member.email} has no phone number on file`);
    }
  };

  const stats = [
    { label: 'Upcoming', value: upcoming.length, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
    { label: 'Completed', value: past.length, color: 'text-emerald-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
    { label: 'Active Now', value: meetings.filter(m => m.status === 'active').length, color: 'text-primary', bg: 'from-primary/10 to-primary/5', border: 'border-primary/20' },
  ];

  const DEPT_COLORS = {
    sales: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    hr: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    recruitment: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    admin: 'bg-primary/10 text-primary border-primary/20',
  };

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Video className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">AXIS Meet</h1>
              <p className="text-muted-foreground text-xs">Internal video conferencing · No Zoom required</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setCallDialogOpen(true)}>
              <Phone className="w-4 h-4" />Call Team
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setScheduleOpen(true)}>
              <Calendar className="w-4 h-4" />Schedule
            </Button>
            <Button size="sm" className="gap-1.5 bg-primary hover:bg-primary/90" onClick={startInstantMeeting} disabled={instantLoading}>
              {instantLoading ? <Sparkles className="w-4 h-4 animate-pulse" /> : <Zap className="w-4 h-4" />}
              Start Instant Meeting
            </Button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {stats.map((s) => (
          <div key={s.label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 ${s.bg} ${s.border}`}>
            <p className={`text-2xl font-bold leading-none ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-muted-foreground capitalize mt-1.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Upcoming Meetings */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-primary" />
          <h2 className="font-semibold text-sm">Upcoming Meetings</h2>
        </div>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Loading...</div>
        ) : upcoming.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-12 text-center">
              <VideoIcon className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
              <p className="font-medium mb-1">No upcoming meetings</p>
              <p className="text-sm text-muted-foreground mb-4">Schedule a meeting or start an instant one</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {upcoming.map((m) => (
              <Card key={m.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4 flex items-center justify-between gap-3 flex-wrap">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                      <Video className="w-5 h-5 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium truncate">{m.title}</p>
                        <Badge variant="outline" className={`text-[10px] capitalize ${DEPT_COLORS[m.department]}`}>{m.department}</Badge>
                        {m.status === 'active' && <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px]">LIVE</Badge>}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1 flex-wrap">
                        {m.scheduled_at && (
                          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{format(new Date(m.scheduled_at), 'MMM d, h:mm a')}</span>
                        )}
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{m.duration_minutes}min</span>
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" />{m.host_name || 'You'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Button variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={() => copyLink(m.guest_join_url)}>
                      <Copy className="w-3 h-3" />Copy Link
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={() => inviteUser(m)}>
                      <UserPlus className="w-3 h-3" />Invite
                    </Button>
                    <Button variant="outline" size="sm" className="h-8 text-xs gap-1" onClick={() => setEditMeeting(m)}>
                      <Edit3 className="w-3 h-3" />Edit
                    </Button>
                    <Button size="sm" className="h-8 text-xs gap-1 bg-primary hover:bg-primary/90" onClick={() => joinMeeting(m)}>
                      <Video className="w-3 h-3" />Join
                    </Button>
                    <Button variant="destructive" size="sm" className="h-8 text-xs" onClick={() => deleteMeeting(m)}>
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Past Meetings with AI Summaries */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-muted-foreground" />
          <h2 className="font-semibold text-sm">Past Meetings</h2>
        </div>
        {past.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              No past meetings yet. AI summaries will appear here after meetings end.
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {past.slice(0, 10).map((m) => (
              <Card key={m.id} className="opacity-90">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <p className="font-medium">{m.title}</p>
                        <Badge variant="outline" className={`text-[10px] capitalize ${DEPT_COLORS[m.department]}`}>{m.department}</Badge>
                        {m.status === 'completed' && <Badge className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 text-[10px]">Completed</Badge>}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2 flex-wrap">
                        {m.ended_at && <span>{format(new Date(m.ended_at), 'MMM d, h:mm a')}</span>}
                        <span className="flex items-center gap-1"><Users className="w-3 h-3" />{(() => { try { return JSON.parse(m.attendees || '[]').length; } catch { return 0; } })()} attendees</span>
                      </div>
                      {m.ai_summary ? (
                        <div className="mt-2 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                          <MeetingBreakdown meeting={m} />
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground italic">No AI summary generated</p>
                      )}
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Button variant="ghost" size="sm" className="h-8 text-xs" onClick={() => joinMeeting(m)}>
                        View
                      </Button>
                      <Button variant="destructive" size="sm" className="h-8 text-xs" onClick={() => deleteMeeting(m)}>
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <ScheduleMeetingDialog open={scheduleOpen} onOpenChange={setScheduleOpen} />
      <EditMeetingDialog meeting={editMeeting} open={!!editMeeting} onOpenChange={(v) => !v && setEditMeeting(null)} />
      <InviteDialog meeting={inviteMeeting} open={!!inviteMeeting} onOpenChange={(v) => !v && setInviteMeeting(null)} />

      {/* Call Team Dialog */}
      <Dialog open={callDialogOpen} onOpenChange={setCallDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-primary" />
              Call Team Member
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[60vh]">
            <div className="space-y-2">
              {callTeamMembers.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-8">No team members found</p>
              ) : (
                callTeamMembers.map((member) => (
                  <Card key={member.id} className="hover:bg-muted/50 transition-colors">
                    <CardContent className="p-3 flex items-center justify-between">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar className="w-9 h-9">
                          <AvatarFallback className="text-xs bg-primary/10 text-primary">
                            {(member.full_name || member.email).charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">{member.full_name || member.email}</p>
                          <p className="text-xs text-muted-foreground truncate">{member.email}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 gap-1.5 shrink-0 whitespace-nowrap"
                        onClick={() => callTeamMember(member)}
                        disabled={!member.phone}
                      >
                        <Phone className="w-3.5 h-3.5" />
                        {member.phone ? 'Call' : 'No Phone'}
                      </Button>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  );
}