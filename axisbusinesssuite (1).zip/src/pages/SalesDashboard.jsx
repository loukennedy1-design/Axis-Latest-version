import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { format, startOfDay, subDays } from 'date-fns';
import { Users, Phone, Calendar, Target, TrendingUp, Clock, ChevronRight, Search, Filter, DollarSign, Activity, CheckCircle2, AlertCircle, PhoneCall } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import StatusBadge from '@/components/shared/StatusBadge';
import { cn } from '@/lib/utils';

const STATUS_COLOR = {
  new: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  contacted: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  qualified: 'bg-green-500/10 text-green-400 border-green-500/20',
  appointment_set: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  not_interested: 'bg-red-500/10 text-red-400 border-red-500/20',
};

function KPI({ label, value, sub, icon: Icon, color }) {
  const colors = {
    blue: 'text-blue-400 bg-blue-500/10',
    green: 'text-green-400 bg-green-500/10',
    purple: 'text-purple-400 bg-purple-500/10',
    gold: 'text-yellow-400 bg-yellow-500/10',
    red: 'text-red-400 bg-red-500/10',
  };
  return (
    <Card className="border-border">
      <CardContent className="p-4 flex items-center gap-3">
        <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center shrink-0', colors[color] || colors.blue)}>
          <Icon className="w-5 h-5" />
        </div>
        <div>
          <p className="text-2xl font-bold leading-none">{value}</p>
          <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
          {sub && <p className="text-[10px] text-muted-foreground/70 mt-0.5">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

export default function SalesDashboard() {
  const { user, isAdmin } = useCurrentUser();
  const qc = useQueryClient();
  const [leadSearch, setLeadSearch] = useState('');
  const [leadFilter, setLeadFilter] = useState('all');
  const [callFilter, setCallFilter] = useState('all');

  const today = format(new Date(), 'yyyy-MM-dd');
  const cutoff7 = startOfDay(subDays(new Date(), 6));

  const { data: leads = [] } = useQuery({
    queryKey: ['sd-leads'],
    queryFn: () => base44.entities.Lead.list('-created_date', 200),
    refetchInterval: 30000,
  });
  const { data: appointments = [] } = useQuery({
    queryKey: ['sd-appointments'],
    queryFn: () => base44.entities.Appointment.list('-scheduled_date', 100),
    refetchInterval: 30000,
  });
  const { data: calls = [] } = useQuery({
    queryKey: ['sd-calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 200),
    refetchInterval: 15000,
  });
  const { data: salesReps = [] } = useQuery({
    queryKey: ['sd-reps'],
    queryFn: () => base44.entities.SalesRep.list(),
    enabled: isAdmin,
  });
  const { data: tasks = [] } = useQuery({
    queryKey: ['sd-tasks'],
    queryFn: () => base44.entities.FollowUpTask.filter({ status: 'pending' }),
    refetchInterval: 60000,
  });

  // Real-time
  React.useEffect(() => {
    const u1 = base44.entities.Lead.subscribe(() => qc.invalidateQueries({ queryKey: ['sd-leads'] }));
    const u2 = base44.entities.CallLog.subscribe(() => qc.invalidateQueries({ queryKey: ['sd-calls'] }));
    const u3 = base44.entities.Appointment.subscribe(() => qc.invalidateQueries({ queryKey: ['sd-appointments'] }));
    return () => { u1(); u2(); u3(); };
  }, [qc]);

  // KPIs
  const activeLeads = leads.filter(l => !['not_interested', 'do_not_call', 'invalid'].includes(l.status));
  const pendingAppts = appointments.filter(a => ['scheduled', 'confirmed'].includes(a.status));
  const todayCalls = calls.filter(c => c.created_date?.startsWith(today));
  const weekCalls = calls.filter(c => c.created_date && new Date(c.created_date) >= cutoff7);
  const apptSetThisWeek = weekCalls.filter(c => c.outcome === 'appointment_set').length;
  const convRate = weekCalls.length > 0 ? Math.round((apptSetThisWeek / weekCalls.length) * 100) : 0;

  // Filtered leads
  const filteredLeads = leads.filter(l => {
    const matchSearch = !leadSearch ||
      `${l.first_name} ${l.last_name}`.toLowerCase().includes(leadSearch.toLowerCase()) ||
      l.phone?.includes(leadSearch) ||
      l.email?.toLowerCase().includes(leadSearch.toLowerCase());
    const matchFilter = leadFilter === 'all' || l.status === leadFilter;
    return matchSearch && matchFilter;
  });

  // Filtered calls
  const filteredCalls = calls.filter(c => {
    if (callFilter === 'today') return c.created_date?.startsWith(today);
    if (callFilter === 'week') return c.created_date && new Date(c.created_date) >= cutoff7;
    return true;
  }).slice(0, 25);

  // Upcoming appointments (next 7 days, sorted)
  const upcomingAppts = appointments
    .filter(a => ['scheduled', 'confirmed'].includes(a.status) && a.scheduled_date)
    .sort((a, b) => new Date(a.scheduled_date) - new Date(b.scheduled_date))
    .slice(0, 15);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Sales Dashboard</h1>
          <p className="text-muted-foreground text-sm">Active leads · Pending appointments · Recent call activity</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs text-emerald-400 font-medium">Live</span>
          </div>
          <Button variant="outline" size="sm" onClick={() => {
            qc.invalidateQueries({ queryKey: ['sd-leads'] });
            qc.invalidateQueries({ queryKey: ['sd-calls'] });
            qc.invalidateQueries({ queryKey: ['sd-appointments'] });
          }}>
            <Activity className="w-3.5 h-3.5 mr-1.5" />Refresh
          </Button>
        </div>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KPI label="Active Leads" value={activeLeads.length} sub={`${leads.filter(l => l.status === 'new').length} new`} icon={Users} color="blue" />
        <KPI label="Pending Appts" value={pendingAppts.length} sub="scheduled/confirmed" icon={Calendar} color="purple" />
        <KPI label="Calls Today" value={todayCalls.length} sub={`${weekCalls.length} this week`} icon={Phone} color="gold" />
        <KPI label="Conv. Rate" value={`${convRate}%`} sub="appts / calls (7d)" icon={TrendingUp} color="green" />
        <KPI label="Pending Tasks" value={tasks.length} sub="follow-ups due" icon={Target} color="red" />
        <KPI label="Sales Reps" value={salesReps.filter(r => r.status === 'active').length} sub="active" icon={Activity} color="blue" />
      </div>

      {/* Main 3-column grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* ── Active Leads ── */}
        <div className="lg:col-span-1 flex flex-col gap-3">
          <Card className="border-border flex flex-col h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-400" />
                Active Leads
                <Badge variant="outline" className="ml-auto text-xs">{activeLeads.length}</Badge>
              </CardTitle>
              <div className="flex gap-2 mt-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
                  <Input
                    value={leadSearch}
                    onChange={e => setLeadSearch(e.target.value)}
                    placeholder="Search leads..."
                    className="pl-7 h-8 text-xs"
                  />
                </div>
                <Select value={leadFilter} onValueChange={setLeadFilter}>
                  <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="qualified">Qualified</SelectItem>
                    <SelectItem value="appointment_set">Appt Set</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto max-h-[520px]">
              {filteredLeads.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-8">No leads found</p>
              ) : (
                <div className="divide-y divide-border">
                  {filteredLeads.slice(0, 30).map(lead => (
                    <div key={lead.id} className="px-4 py-2.5 hover:bg-muted/30 transition-colors">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{lead.first_name} {lead.last_name}</p>
                          <p className="text-[10px] text-muted-foreground truncate">{lead.phone}</p>
                        </div>
                        <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full border font-medium whitespace-nowrap', STATUS_COLOR[lead.status] || 'bg-muted text-muted-foreground border-border')}>
                          {lead.status?.replace(/_/g, ' ')}
                        </span>
                      </div>
                      {lead.assigned_to && (
                        <p className="text-[10px] text-muted-foreground mt-0.5">→ {lead.assigned_to}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Pending Appointments ── */}
        <div className="lg:col-span-1 flex flex-col gap-3">
          <Card className="border-border flex flex-col h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <Calendar className="w-4 h-4 text-purple-400" />
                Pending Appointments
                <Badge variant="outline" className="ml-auto text-xs">{pendingAppts.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto max-h-[520px]">
              {upcomingAppts.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                  <Calendar className="w-8 h-8 opacity-20" />
                  <p className="text-xs">No upcoming appointments</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {upcomingAppts.map(appt => {
                    const apptDate = new Date(appt.scheduled_date);
                    const isToday = appt.scheduled_date?.startsWith(today);
                    return (
                      <div key={appt.id} className={cn('px-4 py-3 hover:bg-muted/30 transition-colors', isToday && 'border-l-2 border-l-primary')}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <p className="text-sm font-medium truncate">{appt.lead_name || 'Unknown Lead'}</p>
                            <p className="text-[11px] text-muted-foreground mt-0.5">
                              {format(apptDate, 'EEE, MMM d')} at {format(apptDate, 'h:mm a')}
                            </p>
                            {appt.assigned_to && (
                              <p className="text-[10px] text-muted-foreground/70 mt-0.5">Rep: {appt.assigned_to}</p>
                            )}
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <StatusBadge status={appt.status} />
                            {isToday && <span className="text-[9px] text-primary font-semibold">TODAY</span>}
                          </div>
                        </div>
                        {appt.notes && (
                          <p className="text-[10px] text-muted-foreground mt-1 truncate italic">{appt.notes}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* ── Recent Call Logs ── */}
        <div className="lg:col-span-1 flex flex-col gap-3">
          <Card className="border-border flex flex-col h-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <PhoneCall className="w-4 h-4 text-yellow-400" />
                Recent Call Logs
                <Select value={callFilter} onValueChange={setCallFilter}>
                  <SelectTrigger className="w-20 h-6 text-[10px] ml-auto border-none bg-muted/50"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                  </SelectContent>
                </Select>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex-1 overflow-y-auto max-h-[520px]">
              {filteredCalls.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-muted-foreground gap-2">
                  <Phone className="w-8 h-8 opacity-20" />
                  <p className="text-xs">No calls found</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {filteredCalls.map(call => {
                    const isAppt = call.outcome === 'appointment_set';
                    const isBad = ['not_interested', 'do_not_call'].includes(call.outcome);
                    return (
                      <div key={call.id} className="px-4 py-2.5 hover:bg-muted/30 transition-colors">
                        <div className="flex items-center justify-between gap-2">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              {isAppt && <CheckCircle2 className="w-3 h-3 text-green-400 shrink-0" />}
                              {isBad && <AlertCircle className="w-3 h-3 text-red-400 shrink-0" />}
                              <p className="text-sm font-medium truncate">{call.lead_name || call.phone_number}</p>
                            </div>
                            <p className="text-[10px] text-muted-foreground">
                              {call.created_date ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}
                              {call.duration_seconds > 0 && ` · ${Math.floor(call.duration_seconds / 60)}m${call.duration_seconds % 60}s`}
                            </p>
                          </div>
                          <StatusBadge status={call.outcome || call.status} />
                        </div>
                        {call.called_by && (
                          <p className="text-[10px] text-muted-foreground/60 mt-0.5">by {call.called_by}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom: Sales Rep Performance */}
      {isAdmin && salesReps.length > 0 && (
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-green-400" />
              Sales Rep Performance
              <Badge variant="outline" className="ml-auto text-xs">{salesReps.filter(r => r.status === 'active').length} active reps</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border">
              {salesReps.filter(r => r.status === 'active').map(rep => {
                const repCalls = calls.filter(c =>
                  c.called_by === rep.email ||
                  c.owner === rep.email
                );
                const repAppts = appointments.filter(a => a.assigned_to === rep.email);
                const repLeads = leads.filter(l => l.assigned_to === rep.email);
                const weekRepCalls = repCalls.filter(c => c.created_date && new Date(c.created_date) >= cutoff7);
                const repConv = weekRepCalls.length > 0 ? Math.round((weekRepCalls.filter(c => c.outcome === 'appointment_set').length / weekRepCalls.length) * 100) : 0;

                return (
                  <div key={rep.id} className="px-4 py-3 flex items-center gap-4 hover:bg-muted/20">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary text-xs font-bold shrink-0">
                      {rep.name?.[0]?.toUpperCase() || '?'}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{rep.name}</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{rep.role} · {rep.territory || 'No territory'}</p>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="text-center">
                        <p className="font-semibold text-foreground">{repLeads.length}</p>
                        <p className="text-[10px]">Leads</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-foreground">{weekRepCalls.length}</p>
                        <p className="text-[10px]">Calls/wk</p>
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-foreground">{repAppts.filter(a => ['scheduled','confirmed'].includes(a.status)).length}</p>
                        <p className="text-[10px]">Appts</p>
                      </div>
                      <div className="text-center">
                        <p className={cn('font-semibold', repConv >= 20 ? 'text-green-400' : repConv >= 10 ? 'text-yellow-400' : 'text-foreground')}>{repConv}%</p>
                        <p className="text-[10px]">Conv</p>
                      </div>
                    </div>
                    <StatusBadge status={rep.status} />
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}