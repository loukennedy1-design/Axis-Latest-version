import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle2, Clock, AlertTriangle, Plus, Bot, Pencil, Trash2, Phone, Mail, Calendar, User, Search } from 'lucide-react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { format, isPast, isToday } from 'date-fns';
import { toast } from 'sonner';
import ClickToCall from '@/components/shared/ClickToCall';
import PullToRefresh from '@/components/shared/PullToRefresh';

const TASK_ICONS = {
  call_back: Phone,
  send_email: Mail,
  schedule_appointment: Calendar,
  review_lead: User,
  send_sms: Phone,
  other: CheckCircle2,
};

const PRIORITY_STYLES = {
  high: 'bg-red-500/10 text-red-600 border-red-500/20',
  medium: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  low: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
};

const emptyTask = { lead_id: '', lead_name: '', lead_phone: '', task_type: 'call_back', priority: 'medium', status: 'pending', due_date: '', notes: '' };

export default function FollowUpTasks() {
  const { user } = useCurrentUser();
  const [tab, setTab] = useState('pending');
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [form, setForm] = useState(emptyTask);
  const qc = useQueryClient();

  const { data: tasks = [], isLoading, refetch } = useQuery({
    queryKey: ['followup-tasks'],
    queryFn: () => base44.entities.FollowUpTask.list('-created_date'),
  });
  const { data: leads = [] } = useQuery({ queryKey: ['leads'], queryFn: () => base44.entities.Lead.list() });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'FollowUpTask', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['followup-tasks'] }); setDialogOpen(false); toast.success('Task created'); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.FollowUpTask.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['followup-tasks'] }); setDialogOpen(false); toast.success('Task updated'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.FollowUpTask.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['followup-tasks'] }); toast.success('Task deleted'); },
  });

  const markComplete = (task) => updateMut.mutate({ id: task.id, data: { ...task, status: 'completed' } });

  const openNew = () => { setEditTask(null); setForm(emptyTask); setDialogOpen(true); };
  const openEdit = (t) => { setEditTask(t); setForm(t); setDialogOpen(true); };

  const handleSave = () => {
    if (editTask) updateMut.mutate({ id: editTask.id, data: form });
    else createMut.mutate({ ...form, owner: user?.email });
  };

  const handleLeadSelect = (leadId) => {
    const lead = leads.find(l => l.id === leadId);
    if (lead) setForm(f => ({ ...f, lead_id: leadId, lead_name: `${lead.first_name} ${lead.last_name}`, lead_phone: lead.phone }));
  };

  const filtered = tasks.filter(t => {
    const matchTab = tab === 'all' || t.status === tab;
    const matchSearch = search === '' || `${t.lead_name} ${t.notes}`.toLowerCase().includes(search.toLowerCase());
    return matchTab && matchSearch;
  });

  const overdue = tasks.filter(t => t.status === 'pending' && t.due_date && !isNaN(new Date(t.due_date)) && isPast(new Date(t.due_date)) && !isToday(new Date(t.due_date)));
  const dueToday = tasks.filter(t => t.status === 'pending' && t.due_date && !isNaN(new Date(t.due_date)) && isToday(new Date(t.due_date)));
  const aiGenerated = tasks.filter(t => t.ai_generated && t.status === 'pending');

  const getDueBadge = (task) => {
    if (!task.due_date || task.status !== 'pending' || isNaN(new Date(task.due_date))) return null;
    if (isPast(new Date(task.due_date)) && !isToday(new Date(task.due_date)))
      return <Badge className="bg-red-500/10 text-red-600 border-red-500/20 text-[10px]">Overdue</Badge>;
    if (isToday(new Date(task.due_date)))
      return <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20 text-[10px]">Due Today</Badge>;
    return null;
  };

  const pendingCount = tasks.filter(t => t.status === 'pending').length;
  const completedCount = tasks.filter(t => t.status === 'completed').length;

  return (
    <PullToRefresh onRefresh={refetch}>
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-red-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Follow-Up Tasks</h1>
              <p className="text-muted-foreground text-xs">{pendingCount} pending · AI-generated action items</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {overdue.length > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold text-red-400">
                <AlertTriangle className="w-3.5 h-3.5" />{overdue.length} overdue
              </div>
            )}
            {dueToday.length > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
                <Clock className="w-3.5 h-3.5" />{dueToday.length} due today
              </div>
            )}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />{completedCount} done
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Bot className="w-3.5 h-3.5" />{aiGenerated.length} AI tasks
            </div>
            <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" />New Task</Button>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search tasks..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending">Pending ({tasks.filter(t => t.status === 'pending').length})</TabsTrigger>
          <TabsTrigger value="in_progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {isLoading ? (
            <div className="text-center py-12 text-muted-foreground">Loading...</div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No tasks found</div>
          ) : (
            <div className="space-y-2">
              {filtered.map(task => {
                const Icon = TASK_ICONS[task.task_type] || CheckCircle2;
                return (
                  <div key={task.id} className={`flex items-center gap-4 p-4 rounded-xl border transition-colors hover:bg-muted/20 ${task.status === 'completed' ? 'opacity-60' : ''} ${task.ai_generated ? 'border-primary/20 bg-primary/5' : 'border-border bg-card'}`}>
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${task.ai_generated ? 'bg-primary/10' : 'bg-muted'}`}>
                      {task.ai_generated ? <Bot className="w-4 h-4 text-primary" /> : <Icon className="w-4 h-4 text-muted-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-medium text-sm">{task.lead_name || 'Unknown Lead'}</p>
                        <Badge variant="outline" className="capitalize text-[10px]">{task.task_type.replace(/_/g, ' ')}</Badge>
                        <Badge variant="outline" className={`${PRIORITY_STYLES[task.priority]} text-[10px]`}>{task.priority}</Badge>
                        {task.ai_generated && <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px]"><Bot className="w-2.5 h-2.5 mr-1" />AI</Badge>}
                        {getDueBadge(task)}
                      </div>
                      {task.notes && <p className="text-xs text-muted-foreground mt-0.5 truncate">{task.notes}</p>}
                      <div className="flex items-center gap-3 mt-1">
                        {task.lead_phone && <ClickToCall phone={task.lead_phone} showIcon className="text-[11px]" />}
                        {task.due_date && !isNaN(new Date(task.due_date)) && <span className="text-[11px] text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" />{format(new Date(task.due_date), 'MMM d, h:mm a')}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {task.status !== 'completed' && (
                        <Button size="sm" variant="outline" className="h-7 text-xs gap-1 text-emerald-600 border-emerald-500/20 hover:bg-emerald-500/10" onClick={() => markComplete(task)}>
                          <CheckCircle2 className="w-3 h-3" />Done
                        </Button>
                      )}
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(task)}><Pencil className="w-3 h-3" /></Button>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMut.mutate(task.id)}><Trash2 className="w-3 h-3 text-destructive" /></Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editTask ? 'Edit Task' : 'New Follow-Up Task'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Lead</Label>
              <Select value={form.lead_id} onValueChange={handleLeadSelect}>
                <SelectTrigger><SelectValue placeholder="Select a lead..." /></SelectTrigger>
                <SelectContent>
                  {leads.map(l => <SelectItem key={l.id} value={l.id}>{l.first_name} {l.last_name} — {l.phone}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Task Type</Label>
                <Select value={form.task_type} onValueChange={v => setForm(f => ({ ...f, task_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['call_back','send_email','send_sms','schedule_appointment','review_lead','other'].map(t => (
                      <SelectItem key={t} value={t}>{t.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Priority</Label>
                <Select value={form.priority} onValueChange={v => setForm(f => ({ ...f, priority: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Due Date & Time</Label>
              <Input type="datetime-local" value={form.due_date ? format(new Date(form.due_date), "yyyy-MM-dd'T'HH:mm") : ''} onChange={e => { if (e.target.value) setForm(f => ({ ...f, due_date: new Date(e.target.value).toISOString() })); }} />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea value={form.notes || ''} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} rows={3} />
            </div>
            <div className="flex gap-2 pt-1">
              <Button variant="outline" className="flex-1" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button className="flex-1" onClick={handleSave} disabled={!form.lead_id}>{editTask ? 'Update' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
    </PullToRefresh>
  );
}