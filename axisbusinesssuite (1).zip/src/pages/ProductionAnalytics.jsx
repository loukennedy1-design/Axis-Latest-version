import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend, LineChart, Line } from 'recharts';
import { Factory, Wrench, CheckCircle2, Clock, AlertTriangle, TrendingUp, ArrowLeft, Loader2, Gauge } from 'lucide-react';
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval, differenceInCalendarDays } from 'date-fns';

const currency = (n) => `$${(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
const STAGE_ORDER = ['po_procurement', 'materials_received', 'build_assembly', 'qc', 'packaging', 'fulfillment', 'delivered'];
const STAGE_LABELS = { po_procurement: 'PO', materials_received: 'Materials', build_assembly: 'Build', qc: 'QC', packaging: 'Packaging', fulfillment: 'Fulfill', delivered: 'Delivered' };
const STAGE_COLORS = ['#94A3B8', '#60A5FA', '#A78BFA', '#F5C842', '#FB923C', '#38BDF8', '#34D399'];
const STATUS_COLORS = { backlog: '#94A3B8', waiting_materials: '#F5C842', queued: '#60A5FA', in_progress: '#A78BFA', quality_check: '#FB923C', completed: '#34D399', on_hold: '#F87171', cancelled: '#64748B' };
const PRIORITY_COLORS = { low: '#94A3B8', medium: '#60A5FA', high: '#FB923C', urgent: '#F87171' };

export default function ProductionAnalytics() {
  const { data: tickets = [], isLoading: tL } = useQuery({ queryKey: ['production-tickets', 'analytics'], queryFn: () => base44.entities.ProductionTicket.list('-created_date', 500) });
  const { data: fulfillment = [], isLoading: fL } = useQuery({ queryKey: ['fulfillment-tasks', 'analytics'], queryFn: () => base44.entities.FulfillmentTask.list('-created_date', 500) });

  const loading = tL || fL;
  const now = new Date();

  const wip = tickets.filter(t => ['in_progress', 'quality_check', 'queued', 'waiting_materials'].includes(t.status)).length;
  const completed = tickets.filter(t => t.status === 'completed');
  const onHold = tickets.filter(t => t.status === 'on_hold').length;
  const backlog = tickets.filter(t => t.status === 'backlog').length;

  // Throughput (completed per month, 6 mo)
  const throughput = useMemo(() => Array.from({ length: 6 }, (_, i) => {
    const m = subMonths(now, 5 - i);
    const s = startOfMonth(m), e = endOfMonth(m);
    const count = completed.filter(t => {
      const d = t.completed_at || t.updated_date;
      if (!d) return false;
      try { return isWithinInterval(new Date(d), { start: s, end: e }); } catch { return false; }
    }).length;
    return { month: format(m, 'MMM'), completed: count };
  }), [completed]);

  // Avg cycle time (days from started_at to completed_at)
  const avgCycle = useMemo(() => {
    const withDates = completed.filter(t => t.started_at && t.completed_at);
    if (withDates.length === 0) return 0;
    const days = withDates.reduce((s, t) => s + differenceInCalendarDays(new Date(t.completed_at), new Date(t.started_at)), 0);
    return Math.round((days / withDates.length) * 10) / 10;
  }, [completed]);

  // On-time completion (completed_at <= due_date or estimated_completion)
  const onTimeRate = useMemo(() => {
    const withDue = completed.filter(t => t.completed_at && (t.due_date || t.estimated_completion));
    if (withDue.length === 0) return 0;
    const onTime = withDue.filter(t => new Date(t.completed_at) <= new Date(t.due_date || t.estimated_completion)).length;
    return Math.round((onTime / withDue.length) * 100);
  }, [completed]);

  // Pipeline by stage (count of tickets currently in each stage)
  const pipeline = useMemo(() => STAGE_ORDER.map((stage, i) => ({
    stage: STAGE_LABELS[stage],
    count: tickets.filter(t => t.current_stage === stage).length,
    color: STAGE_COLORS[i]
  })), [tickets]);

  // Bottleneck = stage with most tickets (excluding delivered)
  const bottleneck = useMemo(() => {
    const active = pipeline.filter(p => p.stage !== 'Delivered');
    return active.sort((a, b) => b.count - a.count)[0];
  }, [pipeline]);

  // Status distribution
  const statusDist = useMemo(() => {
    const map = {};
    tickets.forEach(t => { const st = t.status || 'backlog'; map[st] = (map[st] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [tickets]);

  // Priority distribution
  const priorityDist = useMemo(() => {
    const map = {};
    tickets.forEach(t => { const p = t.priority || 'medium'; map[p] = (map[p] || 0) + 1; });
    return ['low', 'medium', 'high', 'urgent'].filter(p => map[p]).map(p => ({ name: p, value: map[p] }));
  }, [tickets]);

  // Top products in production (by revenue)
  const topProducts = useMemo(() => {
    const map = {};
    tickets.forEach(t => { const p = t.product_name || 'Unknown'; map[p] = (map[p] || 0) + (t.total_revenue || 0); });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6);
  }, [tickets]);

  // Fulfillment task status
  const fulfillStatus = useMemo(() => {
    const map = {};
    fulfillment.forEach(f => { const s = f.status || 'pending'; map[s] = (map[s] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [fulfillment]);

  if (loading) return <div className="flex items-center justify-center h-[60vh]"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  const kpis = [
    { label: 'WIP Tickets', value: wip, icon: Wrench, color: 'text-amber-400', bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20' },
    { label: 'Completed', value: completed.length, icon: CheckCircle2, color: 'text-emerald-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
    { label: 'Backlog', value: backlog, icon: Factory, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
    { label: 'On Hold', value: onHold, icon: AlertTriangle, color: onHold ? 'text-red-400' : 'text-emerald-400', bg: 'from-red-500/10 to-red-600/5', border: 'border-red-500/20' },
    { label: 'Avg Cycle Time', value: `${avgCycle}d`, icon: Clock, color: 'text-purple-400', bg: 'from-purple-500/10 to-purple-600/5', border: 'border-purple-500/20' },
    { label: 'On-Time Rate', value: `${onTimeRate}%`, icon: TrendingUp, color: onTimeRate >= 90 ? 'text-emerald-400' : onTimeRate >= 70 ? 'text-amber-400' : 'text-red-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
  ];

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-2xl border border-orange-500/20 bg-gradient-to-br from-orange-500/8 via-card to-amber-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-44 h-44 bg-orange-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-500/20 flex items-center justify-center"><Factory className="w-5 h-5 text-orange-400" /></div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Production Analytics</h1>
              <p className="text-muted-foreground text-xs">Throughput · Cycle time · Pipeline stages · Bottlenecks · On-time completion · Top products</p>
            </div>
          </div>
          <Link to="/production-fulfillment" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Production
          </Link>
        </div>
      </div>

      {bottleneck && bottleneck.count > 0 && (
        <div className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 flex items-center gap-2 text-sm">
          <Gauge className="w-4 h-4 text-amber-400 shrink-0" />
          <span className="text-muted-foreground">Bottleneck detected: <span className="font-semibold text-amber-400">{bottleneck.stage}</span> stage has {bottleneck.count} tickets — the most of any active stage.</span>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map(k => (
          <div key={k.label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 shadow-lg ${k.bg} ${k.border}`}>
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{k.label}</p>
            <p className={`text-2xl font-bold ${k.color}`}>{k.value}</p>
            <k.icon className={`absolute bottom-3 right-3 w-5 h-5 opacity-20 ${k.color}`} />
          </div>
        ))}
      </div>

      {/* Throughput + pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-400" /> Throughput (completed / mo)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={throughput}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="completed" stroke="#34D399" strokeWidth={2.5} dot={{ r: 3 }} name="Completed" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Pipeline by Stage</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={pipeline}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="stage" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="count" name="Tickets" radius={[4, 4, 0, 0]}>
                  {pipeline.map((p, i) => <Cell key={i} fill={p.color} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Status + priority + fulfillment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm">Ticket Status</CardTitle></CardHeader>
          <CardContent>
            {statusDist.length === 0 ? (
              <div className="flex items-center justify-center h-[200px] text-sm text-muted-foreground">No tickets yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={statusDist} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 9 }} width={110} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="value" name="Tickets" radius={[0, 4, 4, 0]}>
                    {statusDist.map((s, i) => <Cell key={i} fill={STATUS_COLORS[s.name] || '#60A5FA'} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Priority Mix</CardTitle></CardHeader>
          <CardContent>
            {priorityDist.length === 0 ? (
              <div className="flex items-center justify-center h-[200px] text-sm text-muted-foreground">No tickets yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={priorityDist} cx="50%" cy="50%" outerRadius={75} dataKey="value" nameKey="name" label={({ name, value }) => `${name}: ${value}`} labelLine={false} fontSize={10}>
                    {priorityDist.map((p, i) => <Cell key={i} fill={PRIORITY_COLORS[p.name] || '#60A5FA'} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Fulfillment Tasks</CardTitle></CardHeader>
          <CardContent>
            {fulfillStatus.length === 0 ? (
              <div className="flex items-center justify-center h-[200px] text-sm text-muted-foreground">No fulfillment tasks</div>
            ) : (
              <div className="space-y-2 pt-2">
                {fulfillStatus.map(f => (
                  <div key={f.name} className="flex items-center gap-2">
                    <span className="text-sm capitalize flex-1">{f.name.replace(/_/g, ' ')}</span>
                    <Badge variant="secondary" className="text-[10px]">{f.value}</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top products by revenue */}
      <Card>
        <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Factory className="w-4 h-4 text-orange-400" /> Top Products in Production (by revenue)</CardTitle></CardHeader>
        <CardContent>
          {topProducts.length === 0 ? (
            <div className="flex items-center justify-center h-[180px] text-sm text-muted-foreground">No production revenue yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={topProducts} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} stroke="hsl(var(--muted-foreground))" />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={140} stroke="hsl(var(--muted-foreground))" />
                <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="value" name="Revenue" fill="#FB923C" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}