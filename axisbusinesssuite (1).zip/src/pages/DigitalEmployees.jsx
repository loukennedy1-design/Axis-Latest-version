import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bot, Brain, Workflow, TrendingUp, Users, 
  Loader2, CheckCircle2, AlertCircle, Clock, Play,
  Plus, Search, BarChart3, Zap, MessageSquare, FileText,
  Activity, Target, Award, Calendar, HardDrive
} from 'lucide-react';
import { toast } from 'sonner';

export default function DigitalEmployees() {
  const qc = useQueryClient();
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [creatingEmployee, setCreatingEmployee] = useState(false);
  const [employeeForm, setEmployeeForm] = useState({
    name: '',
    role: 'sales_ai',
    department: '',
    personality: { tone: 'professional', style: 'consultative', empathy_level: 'high' },
    specializations: []
  });
  const [actionContext, setActionContext] = useState('{}');
  const [summaryResult, setSummaryResult] = useState(null);
  const [systemAnalytics, setSystemAnalytics] = useState(null);

  // Fetch employees
  const { data: employees = [], refetch: refetchEmployees } = useQuery({ 
    queryKey: ['digital-employees'], 
    queryFn: async () => {
      const res = await base44.functions.invoke('digitalEmployeeFramework', { action: 'list_employees' });
      return res.data.employees || [];
    }
  });

  // Fetch active workflows
  const { data: workflows = [] } = useQuery({ 
    queryKey: ['active-workflows'], 
    queryFn: async () => {
      const res = await base44.functions.invoke('digitalEmployeeFramework', { 
        action: 'list_workflows',
        status: 'active'
      });
      return res.data.workflows || [];
    }
  });

  // Create employee
  const createEmployee = useMutation({
    mutationFn: async (data) => {
      setCreatingEmployee(true);
      const res = await base44.functions.invoke('digitalEmployeeFramework', {
        action: 'create_employee',
        employee_name: data.name,
        role: data.role,
        department: data.department || data.role.replace('_ai', ''),
        personality: data.personality,
        specializations: data.specializations
      });
      setCreatingEmployee(false);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['digital-employees'] });
      toast.success('Digital employee created');
      setEmployeeForm({ name: '', role: 'sales_ai', department: '', personality: { tone: 'professional', style: 'consultative', empathy_level: 'high' }, specializations: [] });
    },
    onError: (err) => {
      setCreatingEmployee(false);
      toast.error('Failed to create: ' + err.message);
    }
  });

  // Execute AI action
  const executeAction = useMutation({
    mutationFn: async ({ employee_id, workflow_id, action_type, context }) => {
      const res = await base44.functions.invoke('digitalEmployeeFramework', {
        action: 'execute_ai_action',
        employee_id,
        workflow_id,
        action_type,
        context
      });
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['active-workflows'] });
      toast.success(`AI action executed: ${data.decision.action_taken}`);
      if (data.decision.requires_human) {
        toast.warning('Human intervention required');
      }
    },
    onError: (err) => {
      toast.error('Action failed: ' + err.message);
    }
  });

  // Generate summary
  const generateSummary = useMutation({
    mutationFn: async ({ employee_id, workflow_id, summary_type }) => {
      const res = await base44.functions.invoke('digitalEmployeeFramework', {
        action: 'generate_summary',
        employee_id,
        workflow_id,
        summary_type
      });
      return res.data;
    },
    onSuccess: (data) => {
      setSummaryResult(data.summary);
      toast.success('Summary generated');
    },
    onError: (err) => {
      toast.error('Failed: ' + err.message);
    }
  });

  // Get system analytics
  const loadSystemAnalytics = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke('digitalEmployeeFramework', {
        action: 'get_system_analytics',
        days: 30
      });
      return res.data;
    },
    onSuccess: (data) => {
      setSystemAnalytics(data.analytics);
      toast.success('Analytics loaded');
    }
  });

  const handleCreateEmployee = (e) => {
    e.preventDefault();
    createEmployee.mutate(employeeForm);
  };

  const handleExecuteAction = () => {
    if (selectedEmployee && selectedWorkflow) {
      try {
        const context = JSON.parse(actionContext);
        executeAction.mutate({
          employee_id: selectedEmployee.employee_id,
          workflow_id: selectedWorkflow.workflow_id,
          action_type: 'autonomous_decision',
          context
        });
      } catch (err) {
        toast.error('Invalid JSON context');
      }
    }
  };

  const handleGenerateSummary = (type = 'comprehensive') => {
    if (selectedEmployee && selectedWorkflow) {
      generateSummary.mutate({
        employee_id: selectedEmployee.employee_id,
        workflow_id: selectedWorkflow.workflow_id,
        summary_type: type
      });
    }
  };

  const getRoleIcon = (role) => {
    switch(role) {
      case 'sales_ai': return <Target className="w-4 h-4" />;
      case 'support_ai': return <MessageSquare className="w-4 h-4" />;
      case 'recruiting_ai': return <Users className="w-4 h-4" />;
      case 'scheduling_ai': return <Calendar className="w-4 h-4" />;
      case 'retention_ai': return <Activity className="w-4 h-4" />;
      case 'accounting_ai': return <BarChart3 className="w-4 h-4" />;
      case 'operations_ai': return <Workflow className="w-4 h-4" />;
      case 'logistics_ai': return <Zap className="w-4 h-4" />;
      default: return <Bot className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30';
      case 'inactive': return 'bg-muted text-muted-foreground';
      case 'training': return 'bg-amber-500/10 text-amber-600 border-amber-500/30';
      case 'maintenance': return 'bg-orange-500/10 text-orange-600 border-orange-500/30';
      default: return 'bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Digital Employee Framework</h1>
            <p className="text-muted-foreground">AI workforce with persistent memory & workflow ownership</p>
          </div>
        </div>
        <Button onClick={() => loadSystemAnalytics.mutate()}>
          <BarChart3 className="w-4 h-4 mr-2" />
          System Analytics
        </Button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Employees</p>
                <p className="text-2xl font-bold">{employees.length}</p>
              </div>
              <Users className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Workflows</p>
                <p className="text-2xl font-bold">{workflows.length}</p>
              </div>
              <Workflow className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-2xl font-bold text-emerald-600">
                  {systemAnalytics?.overall_success_rate || 0}%
                </p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-emerald-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Automation Rate</p>
                <p className="text-2xl font-bold text-primary">
                  {systemAnalytics?.automation_rate || 0}%
                </p>
              </div>
              <Zap className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Memories Stored</p>
                <p className="text-2xl font-bold">{systemAnalytics?.total_memories || 0}</p>
              </div>
              <HardDrive className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="employees" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted p-1 w-full">
          <TabsTrigger value="employees" className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            <span>Employees</span>
          </TabsTrigger>
          <TabsTrigger value="workflows" className="flex items-center gap-2">
            <Workflow className="w-4 h-4" />
            <span>Workflows</span>
          </TabsTrigger>
          <TabsTrigger value="create" className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            <span>Create Employee</span>
          </TabsTrigger>
          <TabsTrigger value="execute" className="flex items-center gap-2">
            <Play className="w-4 h-4" />
            <span>Execute Action</span>
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            <span>Analytics</span>
          </TabsTrigger>
        </TabsList>

        {/* Employees Tab */}
        <TabsContent value="employees" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {employees.map(emp => (
              <Card 
                key={emp.id} 
                className={`cursor-pointer transition-all hover:shadow-lg ${selectedEmployee?.id === emp.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelectedEmployee(emp)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        {getRoleIcon(emp.role)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{emp.employee_name}</CardTitle>
                        <p className="text-xs text-muted-foreground">{emp.role.replace('_', ' ')}</p>
                      </div>
                    </div>
                    <Badge className={getStatusColor(emp.status)}>
                      {emp.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Workflows:</span>
                      <span className="font-medium">{emp.recent_workflows || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Success Rate:</span>
                      <span className="font-medium text-emerald-600">{emp.success_rate || 0}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Interactions:</span>
                      <span className="font-medium">{emp.total_interactions || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Last Active:</span>
                      <span className="font-medium">
                        {emp.last_active_at ? new Date(emp.last_active_at).toLocaleDateString() : 'Never'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {employees.length === 0 && (
              <div className="col-span-full py-12 text-center text-muted-foreground">
                <Bot className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>No digital employees yet. Create your first AI employee!</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Workflows Tab */}
        <TabsContent value="workflows" className="space-y-4">
          <div className="space-y-3">
            {workflows.slice(0, 20).map(wf => (
              <Card 
                key={wf.id}
                className={`cursor-pointer transition-all ${selectedWorkflow?.id === wf.id ? 'ring-2 ring-primary' : ''}`}
                onClick={() => setSelectedWorkflow(wf)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold">{wf.workflow_name}</p>
                        <Badge variant="outline" className="text-xs">{wf.workflow_type.replace('_', ' ')}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Assigned to: {wf.assigned_employee_name} • {wf.context_entity_type} ({wf.context_entity_id})
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={
                        wf.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' :
                        wf.status === 'in_progress' ? 'bg-blue-500/10 text-blue-600' :
                        wf.status === 'waiting_on_customer' ? 'bg-amber-500/10 text-amber-600' :
                        'bg-muted'
                      }>
                        {wf.status.replace('_', ' ')}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {wf.progress_percent}%
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Started: {new Date(wf.started_at).toLocaleDateString()}</span>
                    </div>
                    {wf.sla_deadline && (
                      <div className={`flex items-center gap-1 ${wf.sla_status === 'breached' ? 'text-red-600' : wf.sla_status === 'at_risk' ? 'text-amber-600' : ''}`}>
                        <AlertCircle className="w-3 h-3" />
                        <span>SLA: {wf.sla_status}</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
            {workflows.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">No active workflows</p>
            )}
          </div>
        </TabsContent>

        {/* Create Employee Tab */}
        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Plus className="w-5 h-5" />
                Create Digital Employee
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateEmployee} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-1">Employee Name</label>
                    <Input
                      placeholder="e.g., Sarah - Sales Assistant"
                      value={employeeForm.name}
                      onChange={(e) => setEmployeeForm({...employeeForm, name: e.target.value})}
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-1">Role</label>
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                      value={employeeForm.role}
                      onChange={(e) => setEmployeeForm({...employeeForm, role: e.target.value})}
                    >
                      <option value="sales_ai">Sales AI</option>
                      <option value="support_ai">Support AI</option>
                      <option value="recruiting_ai">Recruiting AI</option>
                      <option value="scheduling_ai">Scheduling AI</option>
                      <option value="retention_ai">Retention AI</option>
                      <option value="accounting_ai">Accounting AI</option>
                      <option value="operations_ai">Operations AI</option>
                      <option value="logistics_ai">Logistics AI</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-1">Department</label>
                    <Input
                      placeholder="e.g., Sales, Customer Support"
                      value={employeeForm.department}
                      onChange={(e) => setEmployeeForm({...employeeForm, department: e.target.value})}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-1">Tone</label>
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                      value={employeeForm.personality.tone}
                      onChange={(e) => setEmployeeForm({...employeeForm, personality: {...employeeForm.personality, tone: e.target.value}})}
                    >
                      <option value="professional">Professional</option>
                      <option value="friendly">Friendly</option>
                      <option value="casual">Casual</option>
                      <option value="formal">Formal</option>
                    </select>
                  </div>
                </div>

                <Button type="submit" disabled={creatingEmployee || !employeeForm.name}>
                  {creatingEmployee ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                  Create Employee
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Execute Action Tab */}
        <TabsContent value="execute" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                Execute AI Action
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-1">Select Employee</label>
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                      value={selectedEmployee?.id || ''}
                      onChange={(e) => {
                        const emp = employees.find(emp => emp.id === e.target.value);
                        setSelectedEmployee(emp);
                      }}
                    >
                      <option value="">Select an employee...</option>
                      {employees.map(emp => (
                        <option key={emp.id} value={emp.id}>{emp.employee_name} ({emp.role})</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-1">Select Workflow</label>
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                      value={selectedWorkflow?.id || ''}
                      onChange={(e) => {
                        const wf = workflows.find(wf => wf.id === e.target.value);
                        setSelectedWorkflow(wf);
                      }}
                    >
                      <option value="">Select a workflow...</option>
                      {workflows.map(wf => (
                        <option key={wf.id} value={wf.id}>{wf.workflow_name} ({wf.status})</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium mb-1">Context (JSON)</label>
                  <Textarea
                    placeholder='{"customer_inquiry": "Pricing question", "urgency": "high"}'
                    value={actionContext}
                    onChange={(e) => setActionContext(e.target.value)}
                    className="min-h-[150px]"
                  />
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={handleExecuteAction} 
                    disabled={!selectedEmployee || !selectedWorkflow}
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Execute Action
                  </Button>

                  <Button 
                    variant="outline"
                    onClick={() => handleGenerateSummary('comprehensive')}
                    disabled={!selectedEmployee || !selectedWorkflow}
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    Generate Summary
                  </Button>
                </div>

                {summaryResult && (
                  <div className="p-4 rounded-lg border bg-muted space-y-3">
                    <h3 className="font-semibold">AI Summary</h3>
                    <p className="text-sm">{summaryResult.overview}</p>
                    
                    {summaryResult.key_events?.length > 0 && (
                      <div>
                        <p className="text-sm font-semibold mb-1">Key Events:</p>
                        <ul className="text-sm list-disc list-inside space-y-1">
                          {summaryResult.key_events.map((event, i) => (
                            <li key={i}>{event}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {summaryResult.next_steps?.length > 0 && (
                      <div>
                        <p className="text-sm font-semibold mb-1">Next Steps:</p>
                        <ul className="text-sm list-disc list-inside space-y-1">
                          {summaryResult.next_steps.map((step, i) => (
                            <li key={i}>{step}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {summaryResult.recommendations?.length > 0 && (
                      <div>
                        <p className="text-sm font-semibold mb-1">Recommendations:</p>
                        <ul className="text-sm list-disc list-inside space-y-1">
                          {summaryResult.recommendations.map((rec, i) => (
                            <li key={i}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-4">
          {systemAnalytics ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>System Overview (Last 30 Days)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="text-sm text-muted-foreground">Total Workflows</p>
                      <p className="text-2xl font-bold">{systemAnalytics.total_workflows}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="text-sm text-muted-foreground">Completed</p>
                      <p className="text-2xl font-bold text-emerald-600">{systemAnalytics.completed_workflows}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="text-sm text-muted-foreground">Success Rate</p>
                      <p className="text-2xl font-bold text-emerald-600">{systemAnalytics.overall_success_rate}%</p>
                    </div>
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="text-sm text-muted-foreground">Automation Rate</p>
                      <p className="text-2xl font-bold text-primary">{systemAnalytics.automation_rate}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Workflows by Type</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(systemAnalytics.workflows_by_type || {}).map(([type, count]) => (
                      <div key={type} className="flex items-center justify-between">
                        <span className="text-sm">{type.replace('_', ' ')}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Employees by Role</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {Object.entries(systemAnalytics.employees_by_role || {}).map(([role, count]) => (
                      <div key={role} className="flex items-center justify-between">
                        <span className="text-sm">{role.replace('_', ' ')}</span>
                        <Badge variant="outline">{count}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          ) : (
            <Card>
              <CardContent className="py-12 text-center">
                <BarChart3 className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Click "System Analytics" button to view insights</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}