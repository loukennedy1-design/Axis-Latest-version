import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ChevronLeft, ChevronRight, Calendar, Phone, Clock, Users, Plus, Pencil, Trash2, X, Save, Loader2 } from 'lucide-react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, addMonths, subMonths, isSameMonth, isSameDay } from 'date-fns';
import StatusBadge from '@/components/shared/StatusBadge';
import ClickToCall from '@/components/shared/ClickToCall';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { toast } from 'sonner';

const VIEW_MODES = ['month', 'week', 'day'];

function EventDot({ type }) {
  const colors = { call: 'bg-primary', appointment: 'bg-emerald-500', task: 'bg-amber-500' };
  return <span className={`inline-block w-1.5 h-1.5 rounded-full ${colors[type] || 'bg-muted-foreground'}`} />;
}

function ApptForm({ form, setForm, onSave, onCancel, saving }) {
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  return (
    <div className="p-3 rounded-lg border border-emerald-500/30 bg-emerald-500/5 space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div><Label className="text-xs">Lead Name</Label><Input className="h-8 text-sm mt-1" value={form.lead_name || ''} onChange={e => set('lead_name', e.target.value)} placeholder="Full name" /></div>
        <div><Label className="text-xs">Phone</Label><Input className="h-8 text-sm mt-1" value={form.lead_phone || ''} onChange={e => set('lead_phone', e.target.value)} placeholder="+1..." /></div>
        <div><Label className="text-xs">Email</Label><Input className="h-8 text-sm mt-1" value={form.lead_email || ''} onChange={e => set('lead_email', e.target.value)} placeholder="email@..." /></div>
        <div><Label className="text-xs">Duration (min)</Label><Input type="number" className="h-8 text-sm mt-1" value={form.duration_minutes || 30} onChange={e => set('duration_minutes', parseInt(e.target.value))} /></div>
        <div><Label className="text-xs">Date & Time</Label><Input type="datetime-local" className="h-8 text-sm mt-1" value={form.scheduled_date || ''} onChange={e => set('scheduled_date', e.target.value)} /></div>
        <div>
          <Label className="text-xs">Status</Label>
          <Select value={form.status || 'scheduled'} onValueChange={v => set('status', v)}>
            <SelectTrigger className="h-8 text-sm mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>{APPT_STATUSES.map(s => <SelectItem key={s} value={s} className="capitalize">{s.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="col-span-2"><Label className="text-xs">Notes</Label><Input className="h-8 text-sm mt-1" value={form.notes || ''} onChange={e => set('notes', e.target.value)} placeholder="Optional notes..." /></div>
      </div>
      <div className="flex gap-2 justify-end">
        <Button size="sm" variant="ghost" className="h-7" onClick={onCancel}><X className="w-3 h-3 mr-1" />Cancel</Button>
        <Button size="sm" className="h-7 bg-emerald-600 hover:bg-emerald-700" onClick={onSave} disabled={saving}>
          {saving ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Save className="w-3 h-3 mr-1" />}Save
        </Button>
      </div>
    </div>
  );
}

function TaskForm({ form, setForm, onSave, onCancel, saving }) {
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  return (
    <div className="p-3 rounded-lg border border-amber-500/30 bg-amber-500/5 space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <div><Label className="text-xs">Lead Name</Label><Input className="h-8 text-sm mt-1" value={form.lead_name || ''} onChange={e => set('lead_name', e.target.value)} placeholder="Full name" /></div>
        <div><Label className="text-xs">Phone</Label><Input className="h-8 text-sm mt-1" value={form.lead_phone || ''} onChange={e => set('lead_phone', e.target.value)} placeholder="+1..." /></div>
        <div>
          <Label className="text-xs">Task Type</Label>
          <Select value={form.task_type || 'call_back'} onValueChange={v => set('task_type', v)}>
            <SelectTrigger className="h-8 text-sm mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>{TASK_TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t.replace(/_/g, ' ')}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Priority</Label>
          <Select value={form.priority || 'medium'} onValueChange={v => set('priority', v)}>
            <SelectTrigger className="h-8 text-sm mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>{TASK_PRIORITIES.map(p => <SelectItem key={p} value={p} className="capitalize">{p}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="col-span-2"><Label className="text-xs">Due Date & Time</Label><Input type="datetime-local" className="h-8 text-sm mt-1" value={form.due_date || ''} onChange={e => set('due_date', e.target.value)} /></div>
        <div className="col-span-2"><Label className="text-xs">Notes</Label><Input className="h-8 text-sm mt-1" value={form.notes || ''} onChange={e => set('notes', e.target.value)} placeholder="Optional notes..." /></div>
      </div>
      <div className="flex gap-2 justify-end">
        <Button size="sm" variant="ghost" className="h-7" onClick={onCancel}><X className="w-3 h-3 mr-1" />Cancel</Button>
        <Button size="sm" className="h-7 bg-amber-600 hover:bg-amber-700" onClick={onSave} disabled={saving}>
          {saving ? <Loader2 className="w-3 h-3 mr-1 animate-spin" /> : <Save className="w-3 h-3 mr-1" />}Save
        </Button>
      </div>
    </div>
  );
}

const APPT_STATUSES = ['scheduled', 'confirmed', 'completed', 'cancelled', 'no_show'];
const TASK_TYPES = ['call_back', 'send_email', 'send_sms', 'schedule_appointment', 'review_lead', 'other'];
const TASK_PRIORITIES = ['high', 'medium', 'low'];

const emptyAppt = (date) => ({
  lead_name: '', lead_phone: '', lead_email: '',
  scheduled_date: format(date, "yyyy-MM-dd'T'09:00"),
  duration_minutes: 30, status: 'scheduled', notes: '',
});
const emptyTask = (date) => ({
  lead_name: '', lead_phone: '', task_type: 'call_back',
  priority: 'medium', due_date: format(date, "yyyy-MM-dd'T'09:00"), notes: '',
});

export default function CallCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('month');
  const [selectedDay, setSelectedDay] = useState(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [editingAppt, setEditingAppt] = useState(null); // null | 'new' | appointment object
  const [editingTask, setEditingTask] = useState(null); // null | 'new' | task object
  const [apptForm, setApptForm] = useState({});
  const [taskForm, setTaskForm] = useState({});
  const [saving, setSaving] = useState(false);

  const { user } = useCurrentUser();
  const qc = useQueryClient();

  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 500) });
  const { data: appointments = [] } = useQuery({ queryKey: ['appointments'], queryFn: () => base44.entities.Appointment.list('-scheduled_date', 200) });
  const { data: tasks = [] } = useQuery({ queryKey: ['followup-tasks'], queryFn: () => base44.entities.FollowUpTask.list() });

  const getEventsForDay = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    const dayCalls = calls.filter(c => c.created_date?.startsWith(dateStr));
    const dayAppts = appointments.filter(a => a.scheduled_date?.startsWith(dateStr));
    const dayTasks = tasks.filter(t => t.due_date?.startsWith(dateStr));
    return { calls: dayCalls, appointments: dayAppts, tasks: dayTasks };
  };

  const openDayDetail = (date) => {
    setSelectedDay(date);
    setDetailOpen(true);
    setEditingAppt(null);
    setEditingTask(null);
  };

  const startNewAppt = () => {
    setApptForm(emptyAppt(selectedDay));
    setEditingAppt('new');
    setEditingTask(null);
  };

  const startEditAppt = (appt) => {
    setApptForm({ ...appt, scheduled_date: appt.scheduled_date ? appt.scheduled_date.slice(0, 16) : '' });
    setEditingAppt(appt);
    setEditingTask(null);
  };

  const startNewTask = () => {
    setTaskForm(emptyTask(selectedDay));
    setEditingTask('new');
    setEditingAppt(null);
  };

  const startEditTask = (task) => {
    setTaskForm({ ...task, due_date: task.due_date ? task.due_date.slice(0, 16) : '' });
    setEditingTask(task);
    setEditingAppt(null);
  };

  const saveAppt = async () => {
    setSaving(true);
    const payload = { ...apptForm, owner: user?.email };
    if (editingAppt === 'new') {
      await base44.entities.Appointment.create(payload);
      toast.success('Appointment added');
    } else {
      await base44.entities.Appointment.update(editingAppt.id, payload);
      toast.success('Appointment updated');
    }
    qc.invalidateQueries({ queryKey: ['appointments'] });
    setEditingAppt(null);
    setSaving(false);
  };

  const deleteAppt = async (appt) => {
    await base44.entities.Appointment.delete(appt.id);
    qc.invalidateQueries({ queryKey: ['appointments'] });
    toast.success('Appointment deleted');
  };

  const saveTask = async () => {
    setSaving(true);
    const payload = { ...taskForm, owner: user?.email };
    if (editingTask === 'new') {
      await base44.entities.FollowUpTask.create(payload);
      toast.success('Task added');
    } else {
      await base44.entities.FollowUpTask.update(editingTask.id, payload);
      toast.success('Task updated');
    }
    qc.invalidateQueries({ queryKey: ['followup-tasks'] });
    setEditingTask(null);
    setSaving(false);
  };

  const deleteTask = async (task) => {
    await base44.entities.FollowUpTask.delete(task.id);
    qc.invalidateQueries({ queryKey: ['followup-tasks'] });
    toast.success('Task deleted');
  };

  // Month view grid
  const renderMonthGrid = () => {
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const gridStart = startOfWeek(monthStart);
    const gridEnd = endOfWeek(monthEnd);
    const days = [];
    let day = gridStart;
    while (day <= gridEnd) { days.push(day); day = addDays(day, 1); }

    return (
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {/* Day headers */}
        <div className="grid grid-cols-7 bg-muted/50">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
            <div key={d} className="text-center text-xs font-semibold text-muted-foreground py-2">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 divide-x divide-y divide-border">
          {days.map((day, i) => {
            const { calls: dc, appointments: da, tasks: dt } = getEventsForDay(day);
            const isToday = isSameDay(day, new Date());
            const isCurrentMonth = isSameMonth(day, currentDate);
            const total = dc.length + da.length + dt.length;
            return (
              <div
                key={i}
                className={`min-h-[90px] p-2 cursor-pointer hover:bg-muted/30 transition-colors ${!isCurrentMonth ? 'opacity-40' : ''} ${isToday ? 'bg-primary/5' : ''}`}
                onClick={() => openDayDetail(day)}
              >
                <div className={`text-xs font-semibold mb-1.5 w-6 h-6 flex items-center justify-center rounded-full ${isToday ? 'bg-primary text-white' : 'text-foreground'}`}>
                  {format(day, 'd')}
                </div>
                <div className="space-y-0.5">
                  {dc.length > 0 && (
                    <div className="flex items-center gap-1 text-[10px] bg-primary/10 text-primary rounded px-1 py-0.5">
                      <EventDot type="call" />
                      {dc.length} call{dc.length > 1 ? 's' : ''}
                    </div>
                  )}
                  {da.length > 0 && (
                    <div className="flex items-center gap-1 text-[10px] bg-emerald-500/10 text-emerald-700 rounded px-1 py-0.5">
                      <EventDot type="appointment" />
                      {da.length} appt{da.length > 1 ? 's' : ''}
                    </div>
                  )}
                  {dt.length > 0 && (
                    <div className="flex items-center gap-1 text-[10px] bg-amber-500/10 text-amber-700 rounded px-1 py-0.5">
                      <EventDot type="task" />
                      {dt.length} task{dt.length > 1 ? 's' : ''}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Week view
  const renderWeekGrid = () => {
    const weekStart = startOfWeek(currentDate);
    const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
    const hours = Array.from({ length: 13 }, (_, i) => i + 8); // 8am-8pm

    return (
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="grid grid-cols-8 bg-muted/50 border-b border-border">
          <div className="py-2" />
          {days.map(d => (
            <div key={d} className={`text-center py-2 ${isSameDay(d, new Date()) ? 'text-primary font-bold' : ''}`}>
              <div className="text-xs text-muted-foreground">{format(d, 'EEE')}</div>
              <div className="text-sm font-semibold">{format(d, 'd')}</div>
            </div>
          ))}
        </div>
        <div className="overflow-y-auto max-h-[500px]">
          {hours.map(h => (
            <div key={h} className="grid grid-cols-8 border-b border-border min-h-[52px]">
              <div className="text-[10px] text-muted-foreground p-1.5 text-right pr-2 pt-2">{h > 12 ? h - 12 : h}{h >= 12 ? 'pm' : 'am'}</div>
              {days.map(d => {
                const dateStr = format(d, 'yyyy-MM-dd');
                const hourCalls = calls.filter(c => c.created_date?.startsWith(dateStr) && new Date(c.created_date).getHours() === h);
                const hourAppts = appointments.filter(a => a.scheduled_date?.startsWith(dateStr) && new Date(a.scheduled_date).getHours() === h);
                return (
                  <div key={d} className={`border-l border-border p-1 ${isSameDay(d, new Date()) ? 'bg-primary/3' : ''}`}>
                    {hourCalls.map(c => (
                      <div key={c.id} className="text-[9px] bg-primary/10 text-primary rounded px-1 mb-0.5 truncate">{c.lead_name || c.phone_number}</div>
                    ))}
                    {hourAppts.map(a => (
                      <div key={a.id} className="text-[9px] bg-emerald-500/10 text-emerald-700 rounded px-1 mb-0.5 truncate">{a.lead_name}</div>
                    ))}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Day view
  const renderDayView = () => {
    const { calls: dc, appointments: da, tasks: dt } = getEventsForDay(currentDate);
    const hours = Array.from({ length: 13 }, (_, i) => i + 8);
    return (
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="p-4 border-b border-border bg-muted/30">
          <h3 className="font-semibold">{format(currentDate, 'EEEE, MMMM d, yyyy')}</h3>
          <div className="flex gap-4 text-xs text-muted-foreground mt-1">
            <span>{dc.length} calls</span><span>{da.length} appointments</span><span>{dt.length} tasks</span>
          </div>
        </div>
        <div className="overflow-y-auto max-h-[500px]">
          {hours.map(h => {
            const dateStr = format(currentDate, 'yyyy-MM-dd');
            const hourCalls = dc.filter(c => new Date(c.created_date).getHours() === h);
            const hourAppts = da.filter(a => new Date(a.scheduled_date).getHours() === h);
            return (
              <div key={h} className="flex border-b border-border min-h-[56px]">
                <div className="w-16 text-xs text-muted-foreground p-2 text-right pt-3 flex-shrink-0">{h > 12 ? h - 12 : h}{h >= 12 ? 'pm' : 'am'}</div>
                <div className="flex-1 border-l border-border p-2 space-y-1">
                  {hourCalls.map(c => (
                    <div key={c.id} className="flex items-center gap-2 bg-primary/10 rounded-lg px-3 py-1.5">
                      <Phone className="w-3 h-3 text-primary flex-shrink-0" />
                      <span className="text-xs font-medium">{c.lead_name || c.phone_number}</span>
                      <StatusBadge status={c.outcome || c.status} />
                      <span className="text-[10px] text-muted-foreground ml-auto">{c.duration_seconds > 0 ? `${Math.floor(c.duration_seconds / 60)}m` : ''}</span>
                    </div>
                  ))}
                  {hourAppts.map(a => (
                    <div key={a.id} className="flex items-center gap-2 bg-emerald-500/10 rounded-lg px-3 py-1.5">
                      <Calendar className="w-3 h-3 text-emerald-600 flex-shrink-0" />
                      <span className="text-xs font-medium">{a.lead_name}</span>
                      <StatusBadge status={a.status} />
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  const navigate = (dir) => {
    if (viewMode === 'month') setCurrentDate(dir > 0 ? addMonths(currentDate, 1) : subMonths(currentDate, 1));
    else if (viewMode === 'week') setCurrentDate(addDays(currentDate, dir * 7));
    else setCurrentDate(addDays(currentDate, dir));
  };

  const headerLabel = viewMode === 'month'
    ? format(currentDate, 'MMMM yyyy')
    : viewMode === 'week'
    ? `${format(startOfWeek(currentDate), 'MMM d')} – ${format(endOfWeek(currentDate), 'MMM d, yyyy')}`
    : format(currentDate, 'EEEE, MMM d, yyyy');

  // Summary stats
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const monthCalls = calls.filter(c => c.created_date && new Date(c.created_date) >= monthStart && new Date(c.created_date) <= monthEnd);
  const monthAppts = appointments.filter(a => a.scheduled_date && new Date(a.scheduled_date) >= monthStart && new Date(a.scheduled_date) <= monthEnd);

  const selectedDayEvents = selectedDay ? getEventsForDay(selectedDay) : null;

  const answerRate = monthCalls.length > 0 ? Math.round(monthCalls.filter(c => c.status === 'completed').length / monthCalls.length * 100) : 0;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Calendar className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Call Calendar</h1>
              <p className="text-muted-foreground text-xs">Visualize calls, appointments & tasks over time</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Phone className="w-3.5 h-3.5" />{monthCalls.length} calls
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <Calendar className="w-3.5 h-3.5" />{monthAppts.length} appts
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
              <Clock className="w-3.5 h-3.5" />{answerRate}% answer rate
            </div>
            <Select value={viewMode} onValueChange={setViewMode}>
              <SelectTrigger className="w-28 h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="month">Month</SelectItem>
                <SelectItem value="week">Week</SelectItem>
                <SelectItem value="day">Day</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Calendar navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}><ChevronLeft className="w-4 h-4" /></Button>
          <Button variant="outline" size="icon" onClick={() => navigate(1)}><ChevronRight className="w-4 h-4" /></Button>
          <Button variant="ghost" size="sm" onClick={() => setCurrentDate(new Date())}>Today</Button>
        </div>
        <h2 className="text-lg font-semibold">{headerLabel}</h2>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><EventDot type="call" /> Calls</span>
          <span className="flex items-center gap-1"><EventDot type="appointment" /> Appointments</span>
          <span className="flex items-center gap-1"><EventDot type="task" /> Tasks</span>
        </div>
      </div>

      {viewMode === 'month' && renderMonthGrid()}
      {viewMode === 'week' && renderWeekGrid()}
      {viewMode === 'day' && renderDayView()}

      {/* Day detail dialog */}
      <Dialog open={detailOpen} onOpenChange={(o) => { setDetailOpen(o); if (!o) { setEditingAppt(null); setEditingTask(null); } }}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedDay ? format(selectedDay, 'EEEE, MMMM d, yyyy') : ''}</DialogTitle>
          </DialogHeader>
          {selectedDayEvents && (
            <div className="space-y-5">

              {/* Calls (read-only) */}
              {selectedDayEvents.calls.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-primary mb-2 flex items-center gap-1">
                    <Phone className="w-3.5 h-3.5" /> Calls ({selectedDayEvents.calls.length})
                  </h4>
                  <div className="space-y-2">
                    {selectedDayEvents.calls.map(c => (
                      <div key={c.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/40">
                        <div>
                          <p className="text-sm font-medium">{c.lead_name || c.phone_number}</p>
                          <ClickToCall phone={c.phone_number} showIcon className="text-xs" />
                        </div>
                        <div className="flex items-center gap-2">
                          {c.duration_seconds > 0 && <span className="text-xs text-muted-foreground">{Math.floor(c.duration_seconds / 60)}m {c.duration_seconds % 60}s</span>}
                          <StatusBadge status={c.outcome || c.status} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Appointments */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-emerald-600 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" /> Appointments ({selectedDayEvents.appointments.length})
                  </h4>
                  {editingAppt === null && (
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={startNewAppt}>
                      <Plus className="w-3 h-3" />Add
                    </Button>
                  )}
                </div>
                <div className="space-y-2">
                  {selectedDayEvents.appointments.map(a => (
                    <div key={a.id}>
                      {editingAppt && editingAppt !== 'new' && editingAppt.id === a.id ? (
                        <ApptForm form={apptForm} setForm={setApptForm} onSave={saveAppt} onCancel={() => setEditingAppt(null)} saving={saving} />
                      ) : (
                        <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                          <div>
                            <p className="text-sm font-medium">{a.lead_name}</p>
                            <p className="text-xs text-muted-foreground">{a.scheduled_date ? format(new Date(a.scheduled_date), 'h:mm a') : ''} · {a.duration_minutes || 30} min</p>
                            {a.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{a.notes}</p>}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <StatusBadge status={a.status} />
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEditAppt(a)}><Pencil className="w-3 h-3" /></Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => deleteAppt(a)}><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {editingAppt === 'new' && (
                    <ApptForm form={apptForm} setForm={setApptForm} onSave={saveAppt} onCancel={() => setEditingAppt(null)} saving={saving} />
                  )}
                  {selectedDayEvents.appointments.length === 0 && editingAppt === null && (
                    <p className="text-xs text-muted-foreground text-center py-2">No appointments — click Add to schedule one</p>
                  )}
                </div>
              </div>

              {/* Tasks */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-600 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> Tasks ({selectedDayEvents.tasks.length})
                  </h4>
                  {editingTask === null && (
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1" onClick={startNewTask}>
                      <Plus className="w-3 h-3" />Add
                    </Button>
                  )}
                </div>
                <div className="space-y-2">
                  {selectedDayEvents.tasks.map(t => (
                    <div key={t.id}>
                      {editingTask && editingTask !== 'new' && editingTask.id === t.id ? (
                        <TaskForm form={taskForm} setForm={setTaskForm} onSave={saveTask} onCancel={() => setEditingTask(null)} saving={saving} />
                      ) : (
                        <div className="flex items-center justify-between p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
                          <div>
                            <p className="text-sm font-medium">{t.lead_name || '—'}</p>
                            <p className="text-xs text-muted-foreground capitalize">{t.task_type?.replace(/_/g, ' ')} · {t.priority} priority</p>
                            {t.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{t.notes}</p>}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <StatusBadge status={t.priority} />
                            <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEditTask(t)}><Pencil className="w-3 h-3" /></Button>
                            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => deleteTask(t)}><Trash2 className="w-3 h-3" /></Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {editingTask === 'new' && (
                    <TaskForm form={taskForm} setForm={setTaskForm} onSave={saveTask} onCancel={() => setEditingTask(null)} saving={saving} />
                  )}
                  {selectedDayEvents.tasks.length === 0 && editingTask === null && (
                    <p className="text-xs text-muted-foreground text-center py-2">No tasks — click Add to create one</p>
                  )}
                </div>
              </div>

            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}