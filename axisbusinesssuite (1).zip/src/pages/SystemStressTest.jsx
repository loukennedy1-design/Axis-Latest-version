import React, { useState, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Activity, Zap, Database, Phone, Users, Settings, CheckCircle2, XCircle, AlertTriangle, Loader2, Trash2 } from 'lucide-react';

const SCENARIO_META = [
  { key: 'data_input', label: 'Data Input', icon: Database, desc: 'Bulk lead creation + concurrent writes' },
  { key: 'data_retrieval', label: 'Data Retrieval', icon: Activity, desc: 'Paginated reads, filtered queries, concurrent reads' },
  { key: 'function_calls', label: 'Function Calls', icon: Zap, desc: 'Sequential + concurrent backend function invocations' },
  { key: 'logins', label: 'Auth / Logins', icon: Users, desc: 'Session validation cycles + concurrent auth' },
  { key: 'call_volume', label: 'Call Volume', icon: Phone, desc: 'Outgoing + incoming call simulation + call log writes' },
  { key: 'mixed_workload', label: 'Mixed Workload', icon: Settings, desc: 'All systems firing simultaneously' },
  { key: 'cleanup', label: 'Cleanup', icon: Trash2, desc: 'Remove stress test data after run' },
];

const INTENSITY_LEVELS = [
  { key: 'light', label: 'Light', desc: '50 bulk · 10 logins · 20 calls' },
  { key: 'standard', label: 'Standard', desc: '200 bulk · 50 logins · 100 calls' },
  { key: 'extreme', label: 'Extreme', desc: '500 bulk · 100 logins · 300 calls' },
];

export default function SystemStressTest() {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [intensity, setIntensity] = useState('standard');
  const [selectedScenarios, setSelectedScenarios] = useState(['all']);
  const [progress, setProgress] = useState(0);

  const toggleScenario = (key) => {
    if (key === 'all') {
      setSelectedScenarios(['all']);
    } else {
      setSelectedScenarios(prev => {
        const without = prev.filter(s => s !== 'all');
        return without.includes(key) ? without.filter(s => s !== key) : [...without, key];
      });
    }
  };

  const runTest = useCallback(async () => {
    setRunning(true);
    setError(null);
    setResults(null);
    setProgress(0);

    // Animate progress bar during the test
    const progressInterval = setInterval(() => {
      setProgress(p => Math.min(p + Math.random() * 8, 92));
    }, 500);

    try {
      const response = await base44.functions.invoke('systemStressTest', {
        intensity,
        scenarios: selectedScenarios,
      });
      setResults(response.data);
      setProgress(100);
    } catch (e) {
      setError(e.response?.data?.error || e.message || 'Stress test failed');
    } finally {
      clearInterval(progressInterval);
      setRunning(false);
    }
  }, [intensity, selectedScenarios]);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-foreground flex items-center gap-2">
            <Activity className="w-7 h-7 text-primary" />
            System Stress Test
          </h1>
          <p className="text-muted-foreground mt-1">
            Simulate high-volume data input, logins, function calls, and calling traffic to test system resilience.
          </p>
        </div>
        {running && (
          <div className="flex items-center gap-2 text-primary">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm font-medium">Running stress test...</span>
          </div>
        )}
      </div>

      {/* Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Test Configuration</CardTitle>
          <CardDescription>Select intensity level and scenarios to simulate</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Intensity */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">Intensity Level</label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {INTENSITY_LEVELS.map(level => (
                <button
                  key={level.key}
                  onClick={() => setIntensity(level.key)}
                  className={`p-4 rounded-lg border-2 text-left transition-all ${
                    intensity === level.key
                      ? 'border-primary bg-primary/10'
                      : 'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="font-semibold text-foreground">{level.label}</div>
                  <div className="text-xs text-muted-foreground mt-1">{level.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Scenarios */}
          <div>
            <label className="text-sm font-medium text-muted-foreground mb-2 block">Scenarios</label>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              {SCENARIO_META.map(s => {
                const Icon = s.icon;
                const active = selectedScenarios.includes('all') || selectedScenarios.includes(s.key);
                return (
                  <button
                    key={s.key}
                    onClick={() => toggleScenario(s.key)}
                    className={`p-3 rounded-lg border-2 text-left transition-all ${
                      active ? 'border-primary bg-primary/10' : 'border-border opacity-60 hover:opacity-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-primary mb-1" />
                    <div className="text-sm font-medium text-foreground">{s.label}</div>
                    <div className="text-xs text-muted-foreground mt-1">{s.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button onClick={runTest} disabled={running} size="lg">
              {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {running ? 'Running...' : 'Run Stress Test'}
            </Button>
            {running && (
              <div className="flex-1 max-w-xs">
                <Progress value={progress} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Error */}
      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="w-4 h-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Results */}
      {results && (
        <div className="space-y-6">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <SummaryCard
              label="Total Operations"
              value={results.summary.total_operations}
              icon={Activity}
            />
            <SummaryCard
              label="Succeeded"
              value={results.summary.total_succeeded}
              icon={CheckCircle2}
              color="text-green-500"
            />
            <SummaryCard
              label="Failed"
              value={results.summary.total_failed}
              icon={XCircle}
              color={results.summary.total_failed > 0 ? 'text-red-500' : 'text-muted-foreground'}
            />
            <SummaryCard
              label="Duration"
              value={`${(results.summary.total_duration_ms / 1000).toFixed(1)}s`}
              icon={Zap}
            />
            <SummaryCard
              label="Ops / Sec"
              value={results.summary.ops_per_second}
              icon={Activity}
            />
            <SummaryCard
              label="Success Rate"
              value={`${results.summary.success_rate_pct}%`}
              icon={results.summary.success_rate_pct >= 95 ? CheckCircle2 : AlertTriangle}
              color={results.summary.success_rate_pct >= 95 ? 'text-green-500' : results.summary.success_rate_pct >= 80 ? 'text-yellow-500' : 'text-red-500'}
            />
          </div>

          {/* Recommendations */}
          {results.recommendations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-500" />
                  Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {results.recommendations.map((rec, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{rec}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Scenario Results */}
          <Card>
            <CardHeader>
              <CardTitle>Scenario Breakdown</CardTitle>
              <CardDescription>Detailed metrics for each stress test scenario</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {results.scenarios_run.map((name, i) => {
                const metric = results.metrics[name];
                if (!metric) return null;
                const meta = SCENARIO_META.find(s => s.key === name);
                const Icon = meta?.icon || Activity;
                return (
                  <div
                    key={i}
                    className="flex items-center justify-between p-3 rounded-lg border border-border bg-card/50"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-primary" />
                      <div>
                        <div className="font-medium text-sm text-foreground">
                          {name.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                        </div>
                        {metric.operations != null && (
                          <div className="text-xs text-muted-foreground">{metric.operations} operations</div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right text-sm">
                        <div className="text-muted-foreground">{metric.duration_ms}ms</div>
                        {metric.records_created && <div className="text-xs text-green-500">{metric.records_created} created</div>}
                        {metric.records_read && <div className="text-xs text-blue-500">{metric.records_read} read</div>}
                        {metric.succeeded != null && <div className="text-xs text-green-500">{metric.succeeded} ok</div>}
                        {metric.failed != null && metric.failed > 0 && <div className="text-xs text-red-500">{metric.failed} failed</div>}
                      </div>
                      <Badge variant={metric.status === 'success' ? 'default' : 'destructive'}>
                        {metric.status === 'success' ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                        {metric.status}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Errors */}
          {results.errors.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-red-500" />
                  Errors ({results.errors.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-64 overflow-y-auto">
                {results.errors.map((err, i) => (
                  <div key={i} className="p-2 rounded bg-destructive/10 border border-destructive/30">
                    <div className="text-xs font-medium text-destructive">{err.scenario}</div>
                    <div className="text-xs text-muted-foreground">{err.error}</div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Raw JSON */}
          <Card>
            <CardHeader>
              <CardTitle>Raw Results</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="text-xs text-muted-foreground overflow-x-auto bg-card p-4 rounded-lg border border-border">
                {JSON.stringify(results, null, 2)}
              </pre>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, value, icon: Icon, color = 'text-foreground' }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-1">
          <span className="text-xs text-muted-foreground uppercase tracking-wide">{label}</span>
          <Icon className={`w-4 h-4 ${color}`} />
        </div>
        <div className={`text-2xl font-bold ${color}`}>{value}</div>
      </CardContent>
    </Card>
  );
}