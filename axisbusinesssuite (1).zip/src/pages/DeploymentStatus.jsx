import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  CheckCircle2, Loader2, Zap, Shield, Brain, Users,
  Database, Globe, Phone, Mail, TrendingUp, AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner';

const COMPLETION_STATUS = {
  'Core Infrastructure': {
    items: [
      { name: 'AXIS Governance Core', status: 'complete', page: '/governance' },
      { name: 'System Topology Engine', status: 'complete', page: '/system-topology' },
      { name: 'Backend Auth Hardening', status: 'complete' },
      { name: 'Security Remediation', status: 'partial', note: 'Secret broker created, migration in progress' },
    ],
  },
  'AI Operations': {
    items: [
      { name: 'Trinity Daily Ops', status: 'complete', automation: 'active' },
      { name: 'Trinity Feature Research', status: 'complete', automation: 'active' },
      { name: 'Marketing Engine', status: 'complete', automation: 'fixed' },
      { name: 'Agent Task System', status: 'complete' },
    ],
  },
  'User Experience': {
    items: [
      { name: 'Next-Gen UI Redesign', status: 'complete' },
      { name: 'Dashboard Redesign', status: 'complete' },
      { name: 'Learning Hub', status: 'complete', page: '/learning' },
      { name: 'Glassmorphism UI', status: 'complete' },
    ],
  },
  'Communications': {
    items: [
      { name: 'AXIS Chat Engine', status: 'complete', page: '/ae-chat' },
      { name: 'Email System', status: 'complete', page: '/email' },
      { name: 'SMS Inbox', status: 'complete', page: '/sms' },
      { name: 'Engagement Hub', status: 'complete', page: '/engagement-hub' },
    ],
  },
  'Compliance & Security': {
    items: [
      { name: 'FCC/TCPA Compliance', status: 'complete', page: '/compliance' },
      { name: 'DNC Registry', status: 'complete', page: '/dnc' },
      { name: 'Audit Logging', status: 'complete' },
      { name: 'Role-Based Access', status: 'complete' },
    ],
  },
  'Billing & Revenue': {
    items: [
      { name: 'Auto-Charge Trials', status: 'complete', fixed: true },
      { name: 'Square Integration', status: 'complete' },
      { name: 'Global Billing Toggle', status: 'complete' },
      { name: 'Invoice/Expense Tracking', status: 'partial' },
    ],
  },
  'Lead Management': {
    items: [
      { name: 'Import Wizard', status: 'complete', page: '/import-wizard' },
      { name: 'Import Diagnostics', status: 'complete' },
      { name: 'Lead CRM', status: 'complete', page: '/leads' },
      { name: 'Lead Scoring', status: 'complete', page: '/lead-scoring' },
    ],
  },
  'Production Readiness': {
    items: [
      { name: 'Production Validation', status: 'complete', page: '/production-validation' },
      { name: 'Deployment Broadcast', status: 'complete' },
      { name: 'System Health Checks', status: 'complete' },
      { name: 'Automation Monitoring', status: 'complete' },
    ],
  },
};

export default function DeploymentStatus() {
  const [validating, setValidating] = useState(false);
  const [validationProgress, setValidationProgress] = useState(0);

  const runValidation = async () => {
    setValidating(true);
    setValidationProgress(0);
    
    try {
      // Quick health check
      const govRes = await base44.functions.invoke('axisGovernanceCore', { action: 'health_check' });
      setValidationProgress(50);
      
      // Check automations
      const automations = await base44.asServiceRole.automations.list();
      const activeCount = automations.filter(a => a.is_active).length;
      setValidationProgress(75);
      
      // Check entities
      const leads = await base44.entities.Lead.list();
      const trials = await base44.entities.TrialInvite.filter({});
      setValidationProgress(100);
      
      toast.success(`Validation complete: ${activeCount} active automations, ${leads.length} leads, ${trials.length} trials`);
    } catch (error) {
      toast.error('Validation failed: ' + error.message);
    } finally {
      setValidating(false);
    }
  };

  const sendBroadcast = async () => {
    try {
      const res = await base44.functions.invoke('broadcastDeploymentComplete', {});
      toast.success(`Broadcast sent to ${res.data.recipients} users!`);
    } catch (error) {
      toast.error('Broadcast failed: ' + error.message);
    }
  };

  const getStatusColor = (status) => {
    if (status === 'complete') return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    if (status === 'partial') return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    return 'bg-muted text-muted-foreground';
  };

  const totalItems = Object.values(COMPLETION_STATUS).flatMap(c => c.items).length;
  const completedItems = Object.values(COMPLETION_STATUS).flatMap(c => c.items).filter(i => i.status === 'complete').length;
  const completionPercentage = Math.round((completedItems / totalItems) * 100);

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Deployment Status Dashboard</h1>
              <p className="text-muted-foreground text-xs">AXIS Business Suite vULTIMATE — Completion Tracker</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />{completionPercentage}% Complete
            </div>
            <Button size="sm" variant="outline" onClick={runValidation} disabled={validating} className="gap-2">
              {validating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
              Validate
            </Button>
            <Button size="sm" onClick={sendBroadcast} className="gap-2 bg-primary hover:bg-primary/90">
              <Mail className="w-3.5 h-3.5" />
              Send Broadcast
            </Button>
          </div>
        </div>
        {validating && (
          <div className="mt-4">
            <Progress value={validationProgress} className="h-2" />
          </div>
        )}
      </div>

      {/* Completion Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {Object.entries(COMPLETION_STATUS).map(([category, items]) => (
          <Card key={category}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                {category === 'Core Infrastructure' && <Database className="w-4 h-4 text-blue-400" />}
                {category === 'AI Operations' && <Brain className="w-4 h-4 text-violet-400" />}
                {category === 'User Experience' && <Users className="w-4 h-4 text-amber-400" />}
                {category === 'Communications' && <Mail className="w-4 h-4 text-green-400" />}
                {category === 'Compliance & Security' && <Shield className="w-4 h-4 text-red-400" />}
                {category === 'Billing & Revenue' && <TrendingUp className="w-4 h-4 text-emerald-400" />}
                {category === 'Lead Management' && <Globe className="w-4 h-4 text-purple-400" />}
                {category === 'Production Readiness' && <CheckCircle2 className="w-4 h-4 text-primary" />}
                {category}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {items.map((item, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-muted/30 text-xs">
                  <div className="flex items-center gap-2">
                    {item.status === 'complete' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    )}
                    <span className="font-medium">{item.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {item.page && (
                      <Badge variant="outline" className="text-[9px]">
                        {item.page}
                      </Badge>
                    )}
                    <Badge className={`text-[9px] ${getStatusColor(item.status)}`}>
                      {item.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Summary */}
      <Card className="border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <CheckCircle2 className="w-8 h-8 text-emerald-400" />
            <div>
              <h3 className="font-semibold text-emerald-400">Deployment Summary</h3>
              <p className="text-xs text-muted-foreground mt-1">
                {completedItems} of {totalItems} components complete ({completionPercentage}%)
              </p>
              <ul className="text-xs text-muted-foreground mt-2 space-y-1">
                <li>✅ Marketing Engine & Weekly Updates — Fixed and running</li>
                <li>✅ Import Wizard — Fully functional with diagnostics</li>
                <li>✅ Governance Core — Secret vault monitoring active</li>
                <li>✅ Engagement Hub — Omnichannel memory system live</li>
                <li>✅ Production Validation — Automated health checks ready</li>
                <li>⚠️ Secret Broker — Created, migration from Deno.env.get() in progress</li>
              </ul>
            </div>
            <Button className="ml-auto bg-emerald-500 hover:bg-emerald-600">
              System Production-Ready
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}