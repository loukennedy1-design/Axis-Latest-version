import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts';
import { Package, AlertTriangle, Boxes, DollarSign, TrendingDown, ArrowLeft, Loader2, RefreshCw, Layers } from 'lucide-react';
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';

const currency = (n) => `$${(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
const CAT_COLORS = ['#F5C842', '#60A5FA', '#34D399', '#A78BFA', '#F87171', '#FB923C', '#38BDF8', '#A3E635'];
const MVMT_COLORS = { receipt: '#34D399', shipment: '#F87171', adjustment: '#F5C842', transfer: '#60A5FA', scrap: '#991B1B', return: '#A78BFA' };

export default function InventoryAnalytics() {
  const { data: items = [], isLoading: itL } = useQuery({ queryKey: ['inventory-items', 'analytics'], queryFn: () => base44.entities.InventoryItem.list('-created_date', 500) });
  const { data: movements = [], isLoading: mvL } = useQuery({ queryKey: ['stock-movements', 'analytics'], queryFn: () => base44.entities.StockMovement.list('-created_date', 500) });

  const loading = itL || mvL;
  const now = new Date();

  const totalValue = useMemo(() => items.reduce((s, i) => s + (i.quantity_on_hand || 0) * (i.unit_cost || 0), 0), [items]);
  const totalRetail = useMemo(() => items.reduce((s, i) => s + (i.quantity_on_hand || 0) * (i.unit_price || 0), 0), [items]);
  const skuCount = items.length;
  const lowStock = items.filter(i => (i.quantity_on_hand || 0) <= (i.reorder_point || 0) && (i.quantity_on_hand || 0) > 0);
  const outOfStock = items.filter(i => (i.quantity_on_hand || 0) <= 0);

  // Value by category
  const byCategory = useMemo(() => {
    const map = {};
    items.forEach(i => { const c = i.category || 'other'; map[c] = (map[c] || 0) + (i.quantity_on_hand || 0) * (i.unit_cost || 0); });
    return Object.entries(map).map(([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);
  }, [items]);

  // Top low-stock items
  const topLowStock = useMemo(() => {
    return items
      .filter(i => (i.quantity_on_hand || 0) <= (i.reorder_point || 0))
      .map(i => ({ name: i.item_name || i.sku, sku: i.sku, qty: i.quantity_on_hand || 0, reorder: i.reorder_point || 0, cost: i.unit_cost || 0 }))
      .sort((a, b) => a.qty - b.qty)
      .slice(0, 7);
  }, [items]);

  // Stock movement trend (6 mo) — receipts vs shipments
  const movementTrend = useMemo(() => Array.from({ length: 6 }, (_, i) => {
    const m = subMonths(now, 5 - i);
    const s = startOfMonth(m), e = endOfMonth(m);
    const inMonth = movements.filter(mv => {
      if (!mv.movement_date) return false;
      try { return isWithinInterval(new Date(mv.movement_date), { start: s, end: e }); } catch { return false; }
    });
    const receipts = inMonth.filter(mv => mv.movement_type === 'receipt').reduce((s2, mv) => s2 + Math.abs(mv.quantity || 0), 0);
    const shipments = inMonth.filter(mv => mv.movement_type === 'shipment').reduce((s2, mv) => s2 + Math.abs(mv.quantity || 0), 0);
    return { month: format(m, 'MMM'), receipts, shipments };
  }), [movements]);

  // Movement type distribution
  const mvmtDist = useMemo(() => {
    const map = {};
    movements.forEach(mv => { const t = mv.movement_type || 'receipt'; map[t] = (map[t] || 0) + Math.abs(mv.quantity || 0); });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [movements]);

  // Inventory turnover (last 6mo shipment value / avg inventory value)
  const turnover = useMemo(() => {
    const shippedValue = movements.filter(m => m.movement_type === 'shipment').reduce((s, m) => s + Math.abs(m.total_value || 0), 0);
    if (totalValue === 0) return 0;
    return (shippedValue / totalValue).toFixed(1);
  }, [movements, totalValue]);

  if (loading) return <div className="flex items-center justify-center h-[60vh]"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>;

  const kpis = [
    { label: 'Inventory Value (cost)', value: currency(totalValue), icon: DollarSign, color: 'text-emerald-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
    { label: 'Retail Value', value: currency(totalRetail), icon: Layers, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
    { label: 'Active SKUs', value: skuCount, icon: Boxes, color: 'text-purple-400', bg: 'from-purple-500/10 to-purple-600/5', border: 'border-purple-500/20' },
    { label: 'Low Stock', value: lowStock.length, icon: AlertTriangle, color: lowStock.length ? 'text-amber-400' : 'text-emerald-400', bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20' },
    { label: 'Out of Stock', value: outOfStock.length, icon: TrendingDown, color: outOfStock.length ? 'text-red-400' : 'text-emerald-400', bg: 'from-red-500/10 to-red-600/5', border: 'border-red-500/20' },
    { label: 'Turnover (6mo)', value: `${turnover}x`, icon: RefreshCw, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
  ];

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-500/8 via-card to-orange-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-44 h-44 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center"><Package className="w-5 h-5 text-amber-400" /></div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Inventory Analytics</h1>
              <p className="text-muted-foreground text-xs">Stock value · Turnover · Movement trends · Low-stock alerts · Category mix</p>
            </div>
          </div>
          <Link to="/inventory" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-3.5 h-3.5" /> Back to Inventory
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpis.map(k => (
          <div key={k.label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 shadow-lg ${k.bg} ${k.border}`}>
            <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">{k.label}</p>
            <p className={`text-2xl font-bold ${k.color}`}>{k.value}</p>
            <k.icon className={`absolute bottom-3 right-3 w-5 h-5 opacity-20 ${k.color}`} />
          </div>
        ))}
      </div>

      {/* Movement trend + category value */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><RefreshCw className="w-4 h-4 text-blue-400" /> Stock Movement (6 mo)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={movementTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="receipts" stroke="#34D399" strokeWidth={2.5} dot={{ r: 3 }} name="Receipts (in)" />
                <Line type="monotone" dataKey="shipments" stroke="#F87171" strokeWidth={2.5} dot={{ r: 3 }} name="Shipments (out)" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Inventory Value by Category</CardTitle></CardHeader>
          <CardContent>
            {byCategory.length === 0 ? (
              <div className="flex items-center justify-center h-[240px] text-sm text-muted-foreground">No inventory yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={byCategory} cx="50%" cy="50%" outerRadius={85} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                    {byCategory.map((_, i) => <Cell key={i} fill={CAT_COLORS[i % CAT_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => currency(v)} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Low stock + movement distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-amber-400" /> Low-Stock Items</CardTitle></CardHeader>
          <CardContent>
            {topLowStock.length === 0 ? (
              <div className="flex items-center justify-center h-[220px] text-sm text-muted-foreground">All stock levels healthy 🎉</div>
            ) : (
              <div className="space-y-2">
                {topLowStock.map((it, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{it.name}</p>
                      <p className="text-[10px] text-muted-foreground">{it.sku} · reorder at {it.reorder}</p>
                    </div>
                    <Badge variant={it.qty <= 0 ? 'destructive' : 'secondary'} className="text-[10px]">{it.qty} on hand</Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm">Movement Type Distribution</CardTitle></CardHeader>
          <CardContent>
            {mvmtDist.length === 0 ? (
              <div className="flex items-center justify-center h-[220px] text-sm text-muted-foreground">No movements logged yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={mvmtDist}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" allowDecimals={false} />
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="value" name="Units" radius={[4, 4, 0, 0]}>
                    {mvmtDist.map((m, i) => <Cell key={i} fill={MVMT_COLORS[m.name] || '#60A5FA'} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}