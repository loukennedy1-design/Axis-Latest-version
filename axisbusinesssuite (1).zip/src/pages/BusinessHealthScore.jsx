import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Gauge, Loader2, RefreshCw, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const DEPT_LABELS = {
  financial: 'Financial', operational: 'Operational', customer_satisfaction: 'Customer',
  marketing: 'Marketing', employee_engagement: 'Employee', compliance: 'Compliance',
  cybersecurity: 'Cybersecurity', automation_coverage: 'Automation', sales: 'Sales', vendor_reliability: 'Vendor'
};

export default function BusinessHealthScorePage() {
  const [score, setScore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [calculating, setCalculating] = useState(false);

  const fetchScore = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('businessHealthScore', { action: 'get_latest' });
      setScore(res.data?.score);
    } catch { setScore(null); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchScore(); }, []);

  const handleCalculate = async () => {
    setCalculating(true);
    try {
      const res = await base44.functions.invoke('businessHealthScore', { action: 'calculate' });
      setScore(res.data?.score);
    } finally { setCalculating(false); }
  };

  const overall = score?.overall ?? 0;
  const overallColor = overall >= 70 ? 'text-emerald-400' : overall >= 40 ? 'text-amber-400' : 'text-red-400';
  const TrendIcon = score?.trend === 'improving' ? TrendingUp : score?.trend === 'declining' ? TrendingDown : Minus;

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Gauge className="w-6 h-6 text-primary" />
            Business Health Score
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            A unified health index analyzing financial, operational, customer, marketing, employee, compliance, cybersecurity, automation, sales, and vendor reliability — with trend analysis and recommended improvements.
          </p>
        </div>
        <Button onClick={handleCalculate} disabled={calculating}>
          {calculating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {calculating ? 'Calculating...' : 'Calculate Score'}
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : score ? (
        <>
          {/* Overall score gauge */}
          <Card>
            <CardContent className="pt-8 pb-8">
              <div className="flex flex-col items-center">
                <div className="relative w-40 h-40">
                  <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="52" fill="none" stroke="hsl(var(--muted))" strokeWidth="10" />
                    <circle cx="60" cy="60" r="52" fill="none" stroke="currentColor" strokeWidth="10"
                      strokeDasharray={`${(overall / 100) * 327} 327`} strokeLinecap="round" className={overallColor} />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className={`text-5xl font-bold font-poppins ${overallColor}`}>{overall}</span>
                    <span className="text-xs text-muted-foreground uppercase">out of 100</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-4">
                  <TrendIcon className={`w-5 h-5 ${overallColor}`} />
                  <span className="text-sm capitalize text-muted-foreground">{score.trend}</span>
                  {score.generated_at && <span className="text-xs text-muted-foreground">· {new Date(score.generated_at).toLocaleDateString()}</span>}
                </div>
                {score.benchmark && <p className="text-sm text-muted-foreground text-center mt-3 max-w-md">{score.benchmark}</p>}
              </div>
            </CardContent>
          </Card>

          {/* Department scores */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {Object.entries(score.department_scores || {}).map(([key, val]) => (
              <DeptCard key={key} label={DEPT_LABELS[key] || key} value={val} />
            ))}
          </div>

          {/* Recommendations */}
          {score.recommendations?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Recommended Improvements</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {score.recommendations.map((r, i) => (
                    <div key={i} className="rounded-lg border border-border bg-card/30 p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs px-2 py-0.5 rounded bg-primary/20 text-primary">{r.area}</span>
                      </div>
                      <p className="text-sm font-medium">{r.action}</p>
                      {r.expected_impact && <p className="text-xs text-muted-foreground mt-1">{r.expected_impact}</p>}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <Card><CardContent className="py-12 text-center"><Gauge className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No health score yet. Click "Calculate Score" to assess your business across all domains.</p></CardContent></Card>
      )}
    </div>
  );
}

function DeptCard({ label, value }) {
  const color = value >= 70 ? 'text-emerald-400' : value >= 40 ? 'text-amber-400' : 'text-red-400';
  return (
    <Card><CardContent className="pt-4">
      <p className="text-xs text-muted-foreground uppercase tracking-wider truncate">{label}</p>
      <div className="flex items-center gap-2 mt-1">
        <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
          <div className={`h-full ${color.replace('text-', 'bg-')}`} style={{ width: `${value}%` }} />
        </div>
        <span className={`text-sm font-bold ${color}`}>{value}</span>
      </div>
    </CardContent></Card>
  );
}