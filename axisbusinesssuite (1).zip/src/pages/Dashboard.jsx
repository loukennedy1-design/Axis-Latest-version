import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Users, Phone, Calendar, ShieldCheck, TrendingUp, Activity, Target, Clock, Zap, PhoneOff, BarChart3, Layers, Megaphone, Shield, ListChecks, Bot, Sparkles, Building2, Settings, Brain } from 'lucide-react';
import StatCard from '@/components/dashboard/StatCard';
import GlassStatCard from '@/components/dashboard/GlassStatCard';
import AIStatusPanel from '@/components/dashboard/AIStatusPanel';
import DrillableKPICard from '@/components/dashboard/DrillableKPICard';
import DrilldownDrawer from '@/components/dashboard/DrilldownDrawer';
import StatusBadge from '@/components/shared/StatusBadge';
import AEDashboard from '@/components/dashboard/AEDashboard';
import TodaySnapshot from '@/components/dashboard/TodaySnapshot';
import TeamTracker from '@/components/dashboard/TeamTracker';
import LeadsAnalytics from '@/components/analytics/LeadsAnalytics';
import CallsAnalytics from '@/components/analytics/CallsAnalytics';
import TeamAnalytics from '@/components/analytics/TeamAnalytics';
import MarketingAnalytics from '@/components/analytics/MarketingAnalytics';
import OperationsAnalytics from '@/components/analytics/OperationsAnalytics';
import { format, subDays, startOfDay } from 'date-fns';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, Legend, LineChart, Line, RadialBarChart, RadialBar
} from 'recharts';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import IndustryConfigSummary from '@/components/industry/IndustryConfigSummary';
import ModuleDetailDrawer from '@/components/dashboard/ModuleDetailDrawer';
import OperationsProductionPanel from '@/components/dashboard/OperationsProductionPanel';
import GettingStartedChecklist from '@/components/trinity/GettingStartedChecklist';
import AppointmentWeeklyDashboard from '@/components/dashboard/AppointmentWeeklyDashboard';
import AgentPerformanceReport from '@/components/dashboard/AgentPerformanceReport';
import DriveAutoSync from '@/components/dashboard/DriveAutoSync';

const COLORS = ['hsl(217,91%,60%)', 'hsl(262,83%,58%)', 'hsl(162,63%,47%)', 'hsl(43,96%,56%)', 'hsl(0,84%,60%)', 'hsl(192,83%,48%)'];

const ANALYTICS_TABS = [
  { id: 'overview', label: 'Overview', icon: Layers },
  { id: 'leads', label: 'Leads', icon: Users },
  { id: 'calls', label: 'Calls', icon: Phone },
  { id: 'team', label: 'Team & HR', icon: Users },
  { id: 'marketing', label: 'Marketing', icon: Megaphone },
  { id: 'operations', label: 'Operations', icon: ListChecks },
];

export default function Dashboard() {
  const qc = useQueryClient();
  const { user, isAdmin } = useCurrentUser();
  const [liveCallCount, setLiveCallCount] = useState(0);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [timeRange, setTimeRange] = useState('7');
  const [analyticsTab, setAnalyticsTab] = useState('overview');
  const [industryConfig, setIndustryConfig] = useState(null);
  const [enabledModules, setEnabledModules] = useState([]);
  const [selectedModule, setSelectedModule] = useState(null);
  const [drilldown, setDrilldown] = useState(null); // { type: 'leads' | 'calls' | 'appointments' | 'compliance' | 'tasks' }

  // Fetch industry configuration
  const { data: settings = [] } = useQuery({
    queryKey: ['system-settings', user?.email],
    queryFn: () => base44.entities.SystemSettings.filter({ key: `industry_${user.email}` }),
    enabled: !!user?.email,
    initialData: [],
  });

  // Fetch enabled modules from GlobalAppSettings (global, not per-user)
  const { data: globalModuleSettings = [] } = useQuery({
    queryKey: ['global-module-config'],
    queryFn: () => base44.entities.GlobalAppSettings.filter({ key: 'module_config' }),
    initialData: [],
  });

  React.useEffect(() => {
    if (globalModuleSettings && globalModuleSettings.length > 0) {
      try {
        const parsed = JSON.parse(globalModuleSettings[0].value || '{}');
        const modules = parsed.enabled_modules;
        setEnabledModules(Array.isArray(modules) ? modules : []);
      } catch (e) {
        console.error('Failed to parse enabled modules', e);
      }
    }
  }, [globalModuleSettings]);

  React.useEffect(() => {
    if (settings && settings.length > 0) {
      try {
        const config = JSON.parse(settings[0].ai_generated_config || '{}');
        setIndustryConfig(config);
      } catch (e) {
        console.error('Failed to parse industry config', e);
      }
    }
  }, [settings]);

  const { data: leads = [] } = useQuery({ queryKey: ['leads'], queryFn: () => base44.entities.Lead.list() });
  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 500) });
  const { data: appointments = [] } = useQuery({ queryKey: ['appointments'], queryFn: () => base44.entities.Appointment.list('-created_date', 200) });
  const { data: tasks = [] } = useQuery({ queryKey: ['followup-tasks'], queryFn: () => base44.entities.FollowUpTask.list() });
  const { data: salesReps = [] } = useQuery({ queryKey: ['salesReps'], queryFn: () => base44.entities.SalesRep.list(), enabled: isAdmin });
  const { data: candidates = [] } = useQuery({ queryKey: ['candidates'], queryFn: () => base44.entities.Candidate.list(), enabled: isAdmin });
  const { data: employees = [] } = useQuery({ queryKey: ['employees'], queryFn: () => base44.entities.Employee.list(), enabled: isAdmin });
  const { data: socialPosts = [] } = useQuery({ queryKey: ['socialPosts'], queryFn: () => base44.entities.SocialPost.list(), enabled: isAdmin });
  const { data: socialCampaigns = [] } = useQuery({ queryKey: ['socialCampaigns'], queryFn: () => base44.entities.SocialCampaign.list(), enabled: isAdmin });
  const { data: emailMessages = [] } = useQuery({ queryKey: ['emailMessages'], queryFn: () => base44.entities.EmailMessage.list(), enabled: isAdmin });
  const { data: smsMessages = [] } = useQuery({ queryKey: ['smsMessages'], queryFn: () => base44.entities.SmsMessage.list(), enabled: isAdmin });
  const { data: complianceLogs = [] } = useQuery({ queryKey: ['complianceLogs'], queryFn: () => base44.entities.ComplianceLog.list(), enabled: isAdmin });
  const { data: dncEntries = [] } = useQuery({ queryKey: ['dncEntries'], queryFn: () => base44.entities.DNCEntry.list(), enabled: isAdmin });
  const { data: payrollRecords = [] } = useQuery({ queryKey: ['payrollRecords'], queryFn: () => base44.entities.PayrollRecord.list(), enabled: isAdmin });
  const { data: performanceReviews = [] } = useQuery({ queryKey: ['performanceReviews'], queryFn: () => base44.entities.PerformanceReview.list(), enabled: isAdmin });
  const { data: timeOffRequests = [] } = useQuery({ queryKey: ['timeOffRequests'], queryFn: () => base44.entities.TimeOffRequest.list(), enabled: isAdmin });

  // Real-time subscriptions
  useEffect(() => {
    const u1 = base44.entities.CallLog.subscribe((e) => {
      if (e.type === 'create') setLiveCallCount(c => c + 1);
      qc.invalidateQueries({ queryKey: ['calls'] });
      setLastRefresh(new Date());
    });
    const u2 = base44.entities.Appointment.subscribe(() => qc.invalidateQueries({ queryKey: ['appointments'] }));
    const u3 = base44.entities.Lead.subscribe(() => qc.invalidateQueries({ queryKey: ['leads'] }));
    const u4 = base44.entities.FollowUpTask.subscribe(() => qc.invalidateQueries({ queryKey: ['followup-tasks'] }));
    return () => { u1(); u2(); u3(); u4(); };
  }, [qc]);

  // AE sub-users get their own focused dashboard — after all hooks
  if (user && !isAdmin) {
    return <AEDashboard />;
  }

  const days = parseInt(timeRange);
  const cutoff = startOfDay(subDays(new Date(), days - 1));

  const rangedCalls = calls.filter(c => c.created_date && new Date(c.created_date) >= cutoff);
  const rangedAppts = appointments.filter(a => a.created_date && new Date(a.created_date) >= cutoff);

  // KPIs
  const totalLeads = leads.length;
  const appointmentsSet = appointments.filter(a => ['scheduled','confirmed'].includes(a.status)).length;
  const totalCalls = calls.length;
  const complianceRate = calls.length > 0 ? Math.round((calls.filter(c => c.fcc_compliant).length / calls.length) * 100) : 100;
  const conversionRate = totalCalls > 0 ? Math.round((calls.filter(c => c.outcome === 'appointment_set').length / totalCalls) * 100) : 0;
  const avgCallDuration = calls.filter(c => c.duration_seconds > 0).reduce((a, c, _, arr) => a + c.duration_seconds / arr.length, 0);
  const pendingTasks = tasks.filter(t => t.status === 'pending').length;
  const contactedToday = calls.filter(c => c.created_date?.startsWith(format(new Date(), 'yyyy-MM-dd'))).length;

  // Time series
  const timeSeries = Array.from({ length: days }, (_, i) => {
    const d = subDays(new Date(), days - 1 - i);
    const dateStr = format(d, 'yyyy-MM-dd');
    const label = days <= 7 ? format(d, 'EEE') : format(d, 'MMM d');
    return {
      name: label,
      calls: calls.filter(c => c.created_date?.startsWith(dateStr)).length,
      appointments: appointments.filter(a => a.created_date?.startsWith(dateStr)).length,
      answered: calls.filter(c => c.created_date?.startsWith(dateStr) && c.status === 'completed').length,
      converted: calls.filter(c => c.created_date?.startsWith(dateStr) && c.outcome === 'appointment_set').length,
    };
  });

  // Lead status breakdown
  const statusBreakdown = leads.reduce((acc, l) => { acc[l.status] = (acc[l.status] || 0) + 1; return acc; }, {});
  const pieData = Object.entries(statusBreakdown).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));

  // Outcome breakdown
  const outcomeData = [
    { name: 'Appt Set', value: rangedCalls.filter(c => c.outcome === 'appointment_set').length, fill: COLORS[2] },
    { name: 'Callback', value: rangedCalls.filter(c => c.outcome === 'callback_requested').length, fill: COLORS[0] },
    { name: 'No Answer', value: rangedCalls.filter(c => c.status === 'no_answer').length, fill: COLORS[3] },
    { name: 'Not Interested', value: rangedCalls.filter(c => c.outcome === 'not_interested').length, fill: COLORS[4] },
    { name: 'Voicemail', value: rangedCalls.filter(c => c.outcome === 'voicemail_left').length, fill: COLORS[1] },
  ];

  // Hourly heatmap (calls by hour of day)
  const hourlyData = Array.from({ length: 13 }, (_, i) => {
    const h = i + 8; // 8am-8pm
    return {
      hour: `${h > 12 ? h - 12 : h}${h >= 12 ? 'pm' : 'am'}`,
      calls: calls.filter(c => c.created_date && new Date(c.created_date).getHours() === h).length,
    };
  });

  // Top lead sources
  const sourceMap = leads.reduce((acc, l) => { const s = l.source || 'Unknown'; acc[s] = (acc[s] || 0) + 1; return acc; }, {});
  const sourceData = Object.entries(sourceMap).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([name, value]) => ({ name, value }));

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 sm:w-8 sm:h-8 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 sm:w-4 sm:h-4 text-primary" />
          </div>
          <div>
            <h1 className="text-xl sm:text-xl font-bold tracking-tight">Operations Center</h1>
            <p className="text-muted-foreground text-xs">Real-time AI business intelligence</p>
          </div>
        </div>
        {industryConfig && (
          <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30 text-xs">
            ✓ {settings[0]?.industry || 'Industry Configured'}
          </Badge>
        )}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-full sm:w-36 h-9 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="14">Last 14 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 whitespace-nowrap">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
            <span className="text-xs text-emerald-500 font-medium hidden sm:block">Live · {format(lastRefresh, 'h:mm a')}</span>
            <span className="text-xs text-emerald-500 font-medium sm:hidden">Live</span>
          </div>
        </div>
      </div>

      {/* Live call alert */}
      {liveCallCount > 0 && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3 p-3 sm:p-3 bg-primary/5 border border-primary/20 rounded-xl">
          <Activity className="w-5 h-5 text-primary animate-pulse shrink-0" />
          <p className="text-sm font-medium text-primary text-center sm:text-left">{liveCallCount} new call{liveCallCount > 1 ? 's' : ''} logged this session</p>
          <Badge className="bg-primary/10 text-primary border-primary/20 ml-auto">{liveCallCount} live</Badge>
        </div>
      )}

      {/* Getting Started Checklist — pinned at top for new users */}
      <GettingStartedChecklist />

      {/* Industry Configuration Summary */}
      {industryConfig && (
        <IndustryConfigSummary
          config={industryConfig}
          settings={settings}
          onReconfigure={() => window.location.href = '/industry-onboarding'}
        />
      )}

      {/* 2026 AI Features Quick Access */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 via-card to-cyan-500/5 cursor-pointer hover:border-primary/40 transition-colors group" onClick={() => window.location.href = '/ai-features'}>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center group-hover:bg-primary/30 transition-colors">
              <Brain className="w-4 h-4 text-primary" />
            </div>
            <div className="flex-1">
              2026 AI CRM Features
              <Badge className="ml-2 text-[10px] px-1.5 py-0 bg-primary/10 text-primary border-primary/20">New</Badge>
            </div>
            <p className="text-xs text-muted-foreground">Click to explore →</p>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <div className="text-center p-2 rounded-lg bg-blue-500/5 border border-blue-500/20">
              <Zap className="w-4 h-4 text-blue-500 mx-auto mb-1" />
              <p className="text-[10px] font-semibold">Signal Detection</p>
              <p className="text-[9px] text-muted-foreground">24h response</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-green-500/5 border border-green-500/20">
              <Shield className="w-4 h-4 text-green-500 mx-auto mb-1" />
              <p className="text-[10px] font-semibold">AI Governance</p>
              <p className="text-[9px] text-muted-foreground">EU AI Act</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-purple-500/5 border border-purple-500/20">
              <Brain className="w-4 h-4 text-purple-500 mx-auto mb-1" />
              <p className="text-[10px] font-semibold">Knowledge Graph</p>
              <p className="text-[9px] text-muted-foreground">5min ramp</p>
            </div>
            <div className="text-center p-2 rounded-lg bg-orange-500/5 border border-orange-500/20">
              <Layers className="w-4 h-4 text-orange-500 mx-auto mb-1" />
              <p className="text-[10px] font-semibold">Micro-Apps</p>
              <p className="text-[9px] text-muted-foreground">2.5min gen</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Modules — click any to see full detail */}
      {enabledModules.length > 0 && (
        <Card className="border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              Active Modules
              <Badge variant="outline" className="ml-auto text-xs">{enabledModules.length} enabled · click any for full details</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {enabledModules.map(moduleId => (
                <button
                  key={moduleId}
                  onClick={() => setSelectedModule(moduleId)}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium bg-primary/5 border border-primary/20 text-primary hover:bg-primary/15 transition-colors cursor-pointer"
                >
                  {moduleId.replace(/_/g, ' ')}
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Top row: KPIs + AI Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* KPI block — all cards are clickable drilldowns */}
        <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3">
          <DrillableKPICard title="Total Leads" value={totalLeads} icon={Users} color="blue" trend={12} subtext={`${leads.filter(l => l.consent_given).length} consented`} onClick={() => setDrilldown('leads')} />
          <DrillableKPICard title="Calls Made" value={totalCalls} icon={Phone} color="gold" trend={8} subtext={`${contactedToday} today`} onClick={() => setDrilldown('calls')} />
          <DrillableKPICard title="Appointments" value={appointmentsSet} icon={Calendar} color="green" trend={15} subtext={`${conversionRate}% conversion`} onClick={() => setDrilldown('appointments')} />
          <DrillableKPICard title="Pending Tasks" value={pendingTasks} icon={Target} color="purple" subtext="follow-ups due" onClick={() => setDrilldown('tasks')} />
          <DrillableKPICard title="FCC Compliance" value={`${complianceRate}%`} icon={ShieldCheck} color="green" onClick={() => setDrilldown('compliance')} />
          <DrillableKPICard title="Avg Call Duration" value={`${Math.floor(avgCallDuration / 60)}m ${Math.round(avgCallDuration % 60)}s`} icon={Clock} color="blue" onClick={() => setDrilldown('calls')} />
          <DrillableKPICard title="Answered Rate" value={`${totalCalls > 0 ? Math.round((calls.filter(c => c.status === 'completed').length / totalCalls) * 100) : 0}%`} icon={TrendingUp} color="gold" onClick={() => setDrilldown('calls')} />
          <DrillableKPICard title="DNC Blocks" value={calls.filter(c => c.status === 'blocked').length} icon={PhoneOff} color="red" onClick={() => setDrilldown('compliance')} />
        </div>

        {/* AI Status Panel */}
        <AIStatusPanel />
      </div>

      {/* Main charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('calls')}>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 sm:mb-4 gap-2">
            <h3 className="font-semibold text-sm whitespace-nowrap group-hover:text-primary transition-colors">Call Activity — Last {timeRange} Days</h3>
            <div className="flex items-center gap-2 sm:gap-3 text-xs text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-primary inline-block" />Total</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-emerald-500 inline-block" />Answered</span>
              <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-purple-500 inline-block" />Appointments</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={timeSeries}>
              <defs>
                <linearGradient id="gCalls" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(217,91%,60%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(217,91%,60%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gAppts" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(162,63%,47%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(162,63%,47%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
              <Area type="monotone" dataKey="calls" name="Total Calls" stroke="hsl(217,91%,60%)" fill="url(#gCalls)" strokeWidth={2} />
              <Area type="monotone" dataKey="answered" name="Answered" stroke="hsl(262,83%,58%)" fill="none" strokeWidth={2} strokeDasharray="4 2" />
              <Area type="monotone" dataKey="appointments" name="Appointments" stroke="hsl(162,63%,47%)" fill="url(#gAppts)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('leads')}>
          <h3 className="font-semibold text-sm mb-3 sm:mb-4 group-hover:text-primary transition-colors">Lead Status Breakdown</h3>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={4} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[180px] text-muted-foreground text-sm">No leads yet</div>
          )}
          <div className="flex flex-wrap gap-2 mt-2">
            {pieData.map((d, i) => (
              <div key={d.name} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="capitalize">{d.name} ({d.value})</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Second charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Outcomes */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('calls')}>
          <h3 className="font-semibold text-sm mb-3 sm:mb-4 group-hover:text-primary transition-colors">Call Outcomes ({timeRange}d)</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={outcomeData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="hsl(var(--border))" />
              <XAxis type="number" tick={{ fontSize: 10 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={80} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
              <Bar dataKey="value" name="Count" radius={[0, 4, 4, 0]}>
                {outcomeData.map((entry, i) => <Cell key={i} fill={entry.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Hourly pattern */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('calls')}>
          <h3 className="font-semibold text-sm mb-3 sm:mb-4 group-hover:text-primary transition-colors">Best Calling Hours</h3>
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={hourlyData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
              <XAxis dataKey="hour" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} />
              <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '11px' }} />
              <Bar dataKey="calls" name="Calls" fill="hsl(217,91%,60%)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Lead Sources */}
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('leads')}>
          <h3 className="font-semibold text-sm mb-3 sm:mb-4 group-hover:text-primary transition-colors">Lead Sources</h3>
          {sourceData.length > 0 ? (
            <div className="space-y-2 sm:space-y-2.5">
              {sourceData.map((s, i) => (
                <div key={s.name}>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs mb-1 gap-1">
                    <span className="font-medium break-all">{s.name}</span>
                    <span className="text-muted-foreground whitespace-nowrap">{s.value} ({Math.round((s.value / totalLeads) * 100)}%)</span>
                  </div>
                  <div className="h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{ width: `${Math.round((s.value / totalLeads) * 100)}%`, backgroundColor: COLORS[i % COLORS.length] }}
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">No leads yet</div>
          )}
        </div>
      </div>

      {/* Appointment Weekly Performance Dashboard — Close Rate Tracking */}
      <Card className="border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold flex items-center gap-2">
            <Target className="w-4 h-4 text-primary" />
            Appointment Performance & Close Rate Tracking
            <Badge className="bg-primary/10 text-primary border-primary/20 text-[10px] ml-auto">Weekly</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <AppointmentWeeklyDashboard appointments={appointments} targetRate={50} />
        </CardContent>
      </Card>

      {/* Agent Performance Report — pulled from the coaching analysis engine */}
      <AgentPerformanceReport />

      {/* Google Drive auto-sync for call recordings & session logs (per-user OAuth) */}
      <DriveAutoSync />

      {/* Operations & Production */}
      <OperationsProductionPanel />

      {/* Today's Snapshot */}
      <TodaySnapshot calls={calls} leads={leads} />

      {/* Full Team Tracker */}
      <TeamTracker />

      {/* ── Full Analytics Panel ── */}
      <div className="border border-border rounded-xl overflow-hidden">
        {/* Tab Header */}
        <div className="bg-muted/40 border-b border-border px-4 py-3">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-5 h-5 text-primary" />
            <h2 className="text-base font-bold">Full Analytics Suite</h2>
            <Badge className="bg-primary/10 text-primary border-primary/20 text-xs ml-auto">Live Data</Badge>
          </div>
          <div className="flex gap-1 overflow-x-auto pb-1">
            {ANALYTICS_TABS.map(tab => (
              <button
                key={tab.id}
                onClick={() => setAnalyticsTab(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  analyticsTab === tab.id
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }`}
              >
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-4 space-y-2">
          {analyticsTab === 'overview' && (
            <div className="space-y-6">
              <LeadsAnalytics leads={leads} calls={calls} />
              <CallsAnalytics calls={calls} />
            </div>
          )}
          {analyticsTab === 'leads' && <LeadsAnalytics leads={leads} calls={calls} />}
          {analyticsTab === 'calls' && <CallsAnalytics calls={calls} />}
          {analyticsTab === 'team' && (
            <TeamAnalytics
              salesReps={salesReps}
              calls={calls}
              appointments={appointments}
              leads={leads}
              candidates={candidates}
              employees={employees}
            />
          )}
          {analyticsTab === 'marketing' && (
            <MarketingAnalytics
              socialPosts={socialPosts}
              socialCampaigns={socialCampaigns}
              emailMessages={emailMessages}
              smsMessages={smsMessages}
            />
          )}
          {analyticsTab === 'operations' && (
            <OperationsAnalytics
              tasks={tasks}
              complianceLogs={complianceLogs}
              dncEntries={dncEntries}
              payrollRecords={payrollRecords}
              performanceReviews={performanceReviews}
              timeOffRequests={timeOffRequests}
            />
          )}
        </div>
      </div>

      <ModuleDetailDrawer
        moduleId={selectedModule}
        open={!!selectedModule}
        onClose={() => setSelectedModule(null)}
      />

      <DrilldownDrawer
        open={!!drilldown}
        onClose={() => setDrilldown(null)}
        type={drilldown}
        data={{ leads, calls, appointments, tasks }}
      />

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('calls')}>
          <h3 className="font-semibold text-sm mb-3 group-hover:text-primary transition-colors">Recent Calls</h3>
          <div className="space-y-2 sm:space-y-2.5">
            {calls.slice(0, 5).map(call => (
              <div key={call.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 sm:gap-2 py-2 border-b border-border last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{call.lead_name || call.phone_number}</p>
                  <p className="text-xs text-muted-foreground">{call.created_date && !isNaN(new Date(call.created_date)) ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</p>
                </div>
                <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
                  {call.duration_seconds > 0 && <span className="text-xs text-muted-foreground whitespace-nowrap">{Math.floor(call.duration_seconds/60)}m {call.duration_seconds%60}s</span>}
                  <StatusBadge status={call.outcome || call.status} />
                </div>
              </div>
            ))}
            {calls.length === 0 && <p className="text-sm text-muted-foreground">No calls yet</p>}
          </div>
        </div>

        <div className="bg-card border border-border rounded-xl p-3 sm:p-5 cursor-pointer hover:border-primary/30 transition-colors group" onClick={() => setDrilldown('appointments')}>
          <h3 className="font-semibold text-sm mb-3 group-hover:text-primary transition-colors">Upcoming Appointments</h3>
          <div className="space-y-2 sm:space-y-2.5">
            {appointments.filter(a => ['scheduled','confirmed'].includes(a.status)).slice(0, 5).map(apt => (
              <div key={apt.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 sm:gap-2 py-2 border-b border-border last:border-0">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{apt.lead_name || 'Unknown'}</p>
                  <p className="text-xs text-muted-foreground">{apt.scheduled_date && !isNaN(new Date(apt.scheduled_date)) ? format(new Date(apt.scheduled_date), 'MMM d, h:mm a') : ''}</p>
                </div>
                <StatusBadge status={apt.status} />
              </div>
            ))}
            {appointments.length === 0 && <p className="text-sm text-muted-foreground">No appointments yet</p>}
          </div>
        </div>
      </div>
    </div>
  );
}