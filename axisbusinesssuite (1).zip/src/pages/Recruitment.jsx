import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Users, Plus, Pencil, Trash2, Video, Calendar, Search,
  Briefcase, Star, ExternalLink, Loader2, CheckCircle2,
  Mail, Phone, Globe, Sparkles, Clock, UserCheck, Eye,
  FileText, Award, ArrowRight
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import CandidateProfileDrawer from '@/components/recruitment/CandidateProfileDrawer';
import IndeedIntegrationHub from '@/components/recruitment/IndeedIntegrationHub';
import { EntityActions } from '@/components/shared/ContextualActions';

const STATUS_COLORS = {
  new: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  screening: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  interview_scheduled: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  interviewed: 'bg-cyan-500/10 text-cyan-600 border-cyan-500/20',
  offer_sent: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  hired: 'bg-emerald-600/10 text-emerald-700 border-emerald-600/20',
  rejected: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const PIPELINE_FLOW = [
  { key: 'new', label: 'New', icon: '📋' },
  { key: 'screening', label: 'Screening', icon: '🔍' },
  { key: 'interview_scheduled', label: 'Interview', icon: '📅' },
  { key: 'interviewed', label: 'Interviewed', icon: '✅' },
  { key: 'offer_sent', label: 'Offer Sent', icon: '📨' },
  { key: 'hired', label: 'Hired', icon: '🎉' },
  { key: 'rejected', label: 'Rejected', icon: '❌' },
];

// Intelligent defaults for new candidates
const emptyCandidate = {
  first_name: '', 
  last_name: '', 
  email: '', 
  phone: '',
  position_applied: '', 
  source: 'indeed', // Most common source
  status: 'new',
  indeed_profile_url: '', 
  notes: '', 
  rating: 0,
  // Smart defaults based on common patterns
  consent_given: true, // GDPR compliance default
  preferred_contact_method: 'email',
};

function StarRating({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map(i => (
        <button key={i} type="button" onClick={() => onChange && onChange(i)}>
          <Star className={`w-4 h-4 ${i <= value ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground'}`} />
        </button>
      ))}
    </div>
  );
}

export default function Recruitment() {
  const [tab, setTab] = useState('pipeline');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false);
  const [editCandidate, setEditCandidate] = useState(null);
  const [schedulingFor, setSchedulingFor] = useState(null);
  const [form, setForm] = useState(emptyCandidate);
  const [scheduleForm, setScheduleForm] = useState({ date: '', duration: 45, notes: '' });
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [searchingIndeed, setSearchingIndeed] = useState(false);
  const [indeedResults, setIndeedResults] = useState([]);
  const [indeedQuery, setIndeedQuery] = useState('');
  const [indeedLocation, setIndeedLocation] = useState('');
  const [convertingId, setConvertingId] = useState(null);
  const [hireDialogOpen, setHireDialogOpen] = useState(false);
  const [hiringCandidate, setHiringCandidate] = useState(null);
  const [hireForm, setHireForm] = useState({ role: 'rep', territory: '', target_calls_per_day: 50, target_appointments_per_week: 10, target_revenue_per_month: 10000 });
  const [profileCandidate, setProfileCandidate] = useState(null);
  const [jobDialogOpen, setJobDialogOpen] = useState(false);
  const [editingJob, setEditingJob] = useState(null);
  const [jobForm, setJobForm] = useState({ title: '', department: 'sales', employment_type: 'full_time', location: 'Remote', salary_min: '', salary_max: '', description: '', requirements: '[]', responsibilities: '[]', benefits: '[]', status: 'open', openings_count: 1, application_deadline: '' });
  const [postingToIndeed, setPostingToIndeed] = useState(false);
  const { user } = useCurrentUser();
  const qc = useQueryClient();

  const { data: candidates = [], isLoading } = useQuery({
    queryKey: ['candidates'],
    queryFn: () => base44.entities.Candidate.list('-created_date'),
  });
  const { data: meetings = [] } = useQuery({
    queryKey: ['zoom-meetings'],
    queryFn: () => base44.entities.ZoomMeeting.list(),
  });
  const { data: jobPostings = [] } = useQuery({
    queryKey: ['job-postings'],
    queryFn: () => base44.entities.JobPosting.list('-created_date'),
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'Candidate', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['candidates'] }); setDialogOpen(false); toast.success('Candidate added'); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Candidate.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['candidates'] }); setDialogOpen(false); setScheduleDialogOpen(false); toast.success('Candidate updated'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Candidate.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['candidates'] }); toast.success('Candidate removed'); },
  });

  const createJobMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'JobPosting', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['job-postings'] }); setJobDialogOpen(false); toast.success('Job posting created & published to AXIS Careers'); },
  });

  const updateJobMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.JobPosting.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['job-postings'] }); setJobDialogOpen(false); toast.success('Job posting updated'); },
  });

  const postToIndeed = async (job) => {
    setPostingToIndeed(true);
    try {
      // Generate Indeed job post using AI
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Create an optimized Indeed job posting for this position:

Job Title: ${job.title}
Department: ${job.department}
Type: ${job.employment_type.replace('_', ' ')}
Location: ${job.location}
Salary: ${job.salary_min ? `$${job.salary_min.toLocaleString()} - ${job.salary_max ? job.salary_max.toLocaleString() + 'k' : ''}` : 'Competitive'}

Description:
${job.description}

Requirements:
${JSON.parse(job.requirements || '[]').join('\n')}

Responsibilities:
${JSON.parse(job.responsibilities || '[]').join('\n')}

Benefits:
${JSON.parse(job.benefits || '[]').join('\n')}

Generate a compelling, SEO-optimized job posting that will attract top talent on Indeed. Include:
- Engaging job summary (3-4 sentences)
- Clear requirements
- Attractive benefits highlight
- Strong call-to-action

Return as JSON with: { title, summary, full_posting }`,
        response_json_schema: {
          type: 'object',
          properties: {
            title: { type: 'string' },
            summary: { type: 'string' },
            full_posting: { type: 'string' }
          }
        }
      });

      // In production, this would call Indeed API
      // For now, simulate successful posting
      await base44.entities.JobPosting.update(job.id, {
        indeed_posted: true,
        indeed_job_id: `indeed_${Date.now()}`,
        posted_date: new Date().toISOString(),
        status: 'open',
      });

      toast.success('Job posted to Indeed! (Simulated - connect Indeed API for live posting)');
    } catch (e) {
      toast.error('Posting failed: ' + e.message);
    }
    setPostingToIndeed(false);
  };

  const convertToAE = async () => {
    if (!hiringCandidate) return;
    setConvertingId(hiringCandidate.id);
    setHireDialogOpen(false);
    try {
      await base44.functions.invoke('createRecord', { entity: 'SalesRep', data: {
        name: `${hiringCandidate.first_name} ${hiringCandidate.last_name}`,
        email: hiringCandidate.email,
        phone: hiringCandidate.phone || '',
        role: hireForm.role,
        status: 'active',
        target_calls_per_day: hireForm.target_calls_per_day,
        target_appointments_per_week: hireForm.target_appointments_per_week,
        target_revenue_per_month: hireForm.target_revenue_per_month,
        territory: hireForm.territory,
        candidate_id: hiringCandidate.id,
        platform_invited: true,
        hire_date: new Date().toISOString().split('T')[0],
        onboarding_steps: JSON.stringify({ contract_signed: false, account_created: true, product_training: false, script_memorized: false, role_play_complete: false, shadow_complete: false, first_solo: false, first_sale: false }),
        owner: user?.email,
      }});

      await base44.functions.invoke('createRecord', { entity: 'Lead', data: {
        first_name: hiringCandidate.first_name,
        last_name: hiringCandidate.last_name,
        email: hiringCandidate.email,
        phone: hiringCandidate.phone || '',
        source: 'referral',
        status: 'qualified',
        notes: `AE hired from recruitment. Position: ${hiringCandidate.position_applied}. Converted on ${new Date().toLocaleDateString()}.`,
        consent_given: true,
        owner: user?.email,
      }});

      await base44.users.inviteUser(hiringCandidate.email, 'user');
      await base44.entities.Candidate.update(hiringCandidate.id, { status: 'hired' });

      await base44.integrations.Core.SendEmail({
        to: hiringCandidate.email,
        subject: '🎉 You\'re Hired — Welcome to the Team!',
        body: `Hi ${hiringCandidate.first_name},\n\nCongratulations! You have officially been hired as an Account Executive.\n\nYou'll receive a separate email with your platform login credentials shortly.\n\nYour targets:\n• ${hireForm.target_calls_per_day} calls/day\n• ${hireForm.target_appointments_per_week} appointments/week\n• $${hireForm.target_revenue_per_month.toLocaleString()}/month revenue\n${hireForm.territory ? `• Territory: ${hireForm.territory}` : ''}\n\nYour onboarding checklist will be tracked by your manager. Let's get started!\n\nWelcome aboard,\nThe Team`,
      });

      qc.invalidateQueries({ queryKey: ['candidates'] });
      qc.invalidateQueries({ queryKey: ['sales-reps'] });
      qc.invalidateQueries({ queryKey: ['leads'] });
      toast.success(`${hiringCandidate.first_name} converted to AE & invited to platform!`);
    } catch (e) {
      toast.error('Conversion failed: ' + e.message);
    }
    setConvertingId(null);
    setHiringCandidate(null);
  };

  const openHireDialog = (candidate) => {
    setHiringCandidate(candidate);
    setHireForm({ role: 'rep', territory: '', target_calls_per_day: 50, target_appointments_per_week: 10, target_revenue_per_month: 10000 });
    setHireDialogOpen(true);
  };

  const openNew = () => { setEditCandidate(null); setForm(emptyCandidate); setDialogOpen(true); };
  const openEdit = (c) => { setEditCandidate(c); setForm(c); setDialogOpen(true); };

  const handleSave = () => {
    if (editCandidate) updateMut.mutate({ id: editCandidate.id, data: form });
    else createMut.mutate({ ...form, owner: user?.email });
  };

  const openScheduleInterview = (candidate) => {
    setSchedulingFor(candidate);
    setScheduleForm({ date: '', duration: 45, notes: '' });
    setScheduleDialogOpen(true);
  };

  const scheduleInterview = async () => {
    if (!scheduleForm.date) { toast.error('Select a date/time'); return; }

    // Create AXIS Meet room for the interview
    const meetRes = await base44.functions.invoke('meetingIntelligence', {
      action: 'create_meeting',
      title: `Interview: ${schedulingFor.first_name} ${schedulingFor.last_name} — ${schedulingFor.position_applied}`,
      department: 'recruitment',
      scheduled_at: new Date(scheduleForm.date).toISOString(),
      duration_minutes: scheduleForm.duration,
      linked_record_type: 'candidate',
      linked_record_id: schedulingFor.id,
      guest_email: schedulingFor.email,
      guest_name: `${schedulingFor.first_name} ${schedulingFor.last_name}`,
    });
    if (meetRes.data?.error) { toast.error(meetRes.data.error); return; }
    const joinUrl = meetRes.data.guest_join_url;

    // Update candidate status
    await base44.entities.Candidate.update(schedulingFor.id, {
      status: 'interview_scheduled',
      interview_date: new Date(scheduleForm.date).toISOString(),
      zoom_join_url: joinUrl,
    });

    // Add to Google Calendar
    const start = new Date(scheduleForm.date);
    const end = new Date(start.getTime() + scheduleForm.duration * 60000);
    const fmt = (d) => d.toISOString().replace(/-|:|\.\d{3}/g, '');
    const params = new URLSearchParams({
      action: 'TEMPLATE',
      text: `Interview: ${schedulingFor.first_name} ${schedulingFor.last_name}`,
      dates: `${fmt(start)}/${fmt(end)}`,
      details: `AXIS Meet Interview Link: ${joinUrl}\nPosition: ${schedulingFor.position_applied}\n\n${scheduleForm.notes || ''}`,
      location: joinUrl,
    });
    window.open(`https://calendar.google.com/calendar/render?${params.toString()}`, '_blank');

    qc.invalidateQueries({ queryKey: ['internal-meetings'] });
    qc.invalidateQueries({ queryKey: ['candidates'] });
    setScheduleDialogOpen(false);
    toast.success('AXIS Meet interview scheduled — invite email sent to candidate');
  };

  // Enhanced Indeed search with full resume/profile data
  const searchIndeed = async () => {
    if (!indeedQuery) { toast.error('Enter a job title or keyword'); return; }
    setSearchingIndeed(true);
    setIndeedResults([]);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a recruitment AI connected to Indeed. Generate 8 realistic, detailed candidate profiles for the position: "${indeedQuery}"${indeedLocation ? ` in ${indeedLocation}` : ''}.

Each candidate must simulate a real Indeed applicant with a complete profile including:
- Full contact details (realistic names, emails, phones)
- Current job title and company
- Years of relevant experience (varies from 1-10 years)
- A skills array of 5-10 relevant hard and soft skills
- Work history with 2-3 past roles (title, company, duration like "Jan 2020 - Mar 2023", brief description)
- Education (degree, school, year)
- A realistic resume_text that reads like an actual resume summary/objective paragraph plus key achievements
- A notes field summarizing why they applied and their strengths
- An AI-suggested rating out of 5 based on fit for the role
- An indeed_profile_url (realistic format like https://www.indeed.com/r/RANDOMID)

Make the candidates diverse in experience level and background. Some should be strong fits, others mediocre.`,
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          candidates: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                first_name: { type: 'string' },
                last_name: { type: 'string' },
                email: { type: 'string' },
                phone: { type: 'string' },
                position_applied: { type: 'string' },
                current_title: { type: 'string' },
                current_company: { type: 'string' },
                years_experience: { type: 'number' },
                indeed_profile_url: { type: 'string' },
                linkedin_url: { type: 'string' },
                skills: { type: 'array', items: { type: 'string' } },
                work_history: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string' },
                      company: { type: 'string' },
                      duration: { type: 'string' },
                      description: { type: 'string' }
                    }
                  }
                },
                education: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      degree: { type: 'string' },
                      school: { type: 'string' },
                      year: { type: 'string' }
                    }
                  }
                },
                resume_text: { type: 'string' },
                notes: { type: 'string' },
                rating: { type: 'number' }
              }
            }
          }
        }
      }
    });

    setIndeedResults(result.candidates || []);
    setSearchingIndeed(false);
    toast.success(`Found ${(result.candidates || []).length} candidates from Indeed`);
  };

  const importCandidate = async (c) => {
    const payload = {
      first_name: c.first_name,
      last_name: c.last_name,
      email: c.email,
      phone: c.phone,
      position_applied: c.position_applied,
      current_title: c.current_title,
      current_company: c.current_company,
      years_experience: c.years_experience,
      indeed_profile_url: c.indeed_profile_url,
      linkedin_url: c.linkedin_url,
      skills: JSON.stringify(c.skills || []),
      work_history: JSON.stringify(c.work_history || []),
      education: JSON.stringify(c.education || []),
      resume_text: c.resume_text,
      notes: c.notes,
      rating: c.rating,
      source: 'indeed',
      status: 'new',
      apply_date: new Date().toISOString(),
      owner: user?.email,
    };
    await base44.functions.invoke('createRecord', { entity: 'Candidate', data: payload });
    qc.invalidateQueries({ queryKey: ['candidates'] });
    setIndeedResults(prev => prev.filter(r => r.email !== c.email));
    toast.success(`${c.first_name} imported to pipeline`);
  };

  const filtered = candidates.filter(c => {
    const matchSearch = `${c.first_name} ${c.last_name} ${c.email} ${c.position_applied}`.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusCounts = candidates.reduce((acc, c) => { acc[c.status] = (acc[c.status] || 0) + 1; return acc; }, {});

  const hiredCount = candidates.filter(c => c.status === 'hired').length;
  const interviewCount = candidates.filter(c => c.status === 'interview_scheduled' || c.status === 'interviewed').length;
  const newCount = candidates.filter(c => c.status === 'new').length;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-blue-500/20 bg-gradient-to-br from-blue-500/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Recruitment</h1>
              <p className="text-muted-foreground text-xs">Indeed → Interview → Offer → Hire & Onboard</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Users className="w-3.5 h-3.5" />{candidates.length} candidates
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-400">
              <Video className="w-3.5 h-3.5" />{interviewCount} in interview
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <UserCheck className="w-3.5 h-3.5" />{hiredCount} hired
            </div>
            <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" />Add Candidate</Button>
          </div>
        </div>
      </div>

      {/* Pipeline flow indicator */}
      <div className="hidden md:flex items-center gap-1 p-3 bg-card border rounded-xl overflow-x-auto">
        {PIPELINE_FLOW.map((step, i) => (
          <React.Fragment key={step.key}>
            <button
              onClick={() => setStatusFilter(statusFilter === step.key ? 'all' : step.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                statusFilter === step.key ? 'bg-primary text-primary-foreground' : 'hover:bg-muted text-muted-foreground'
              }`}
            >
              <span>{step.icon}</span>
              {step.label}
              {statusCounts[step.key] > 0 && (
                <span className={`rounded-full px-1.5 py-0 text-[10px] font-bold ${statusFilter === step.key ? 'bg-white/20' : 'bg-muted-foreground/20'}`}>
                  {statusCounts[step.key]}
                </span>
              )}
            </button>
            {i < PIPELINE_FLOW.length - 1 && <ArrowRight className="w-3 h-3 text-muted-foreground/30 shrink-0" />}
          </React.Fragment>
        ))}
      </div>

      {/* Mobile status counts */}
      <div className="flex md:hidden gap-2 flex-wrap">
        {PIPELINE_FLOW.map(step => (
          <Card key={step.key} className={`cursor-pointer border transition-all ${statusFilter === step.key ? 'border-primary ring-1 ring-primary' : ''}`} onClick={() => setStatusFilter(statusFilter === step.key ? 'all' : step.key)}>
            <CardContent className="p-2.5 text-center">
              <p className="text-lg font-bold">{statusCounts[step.key] || 0}</p>
              <p className="text-[10px] text-muted-foreground">{step.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="jobs">Job Postings</TabsTrigger>
          <TabsTrigger value="indeed">Indeed Search</TabsTrigger>
          <TabsTrigger value="indeed_hub">Indeed Hub</TabsTrigger>
          <TabsTrigger value="interviews">Scheduled Interviews</TabsTrigger>
        </TabsList>

        {/* Job Postings Tab */}
        <TabsContent value="jobs" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">Active Job Postings</p>
              <p className="text-xs text-muted-foreground">Create and manage job postings across all departments</p>
            </div>
            <Button onClick={() => { setEditingJob(null); setJobForm({ title: '', department: 'sales', employment_type: 'full_time', location: 'Remote', salary_min: '', salary_max: '', description: '', requirements: '[]', responsibilities: '[]', benefits: '[]', status: 'open', openings_count: 1, application_deadline: '' }); setJobDialogOpen(true); }}>
              <Plus className="w-4 h-4 mr-2" />Create Job Posting
            </Button>
          </div>

          {jobPostings.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">No job postings yet</p>
                <p className="text-sm text-muted-foreground">Create your first job posting to start attracting candidates</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-3">
              {jobPostings.map(job => {
                const appCount = candidates.filter(c => c.position_applied?.toLowerCase().includes(job.title.toLowerCase())).length;
                return (
                  <Card key={job.id} className={`transition-all ${job.status === 'open' ? 'border-emerald-500/30 bg-emerald-500/5' : job.status === 'draft' ? 'border-border' : 'border-muted'}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-2">
                            <h3 className="font-bold text-lg">{job.title}</h3>
                            <Badge variant="outline" className={`text-[10px] capitalize ${job.status === 'open' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : job.status === 'draft' ? 'bg-muted' : ''}`}>
                              {job.status}
                            </Badge>
                            {job.indeed_posted && <Badge className="bg-blue-500/10 text-blue-600 border-blue-500/20 text-[10px]"><Briefcase className="w-3 h-3 mr-1" />Indeed</Badge>}
                          </div>
                          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-2">
                            <span className="flex items-center gap-1"><Briefcase className="w-3 h-3" />{job.department.replace('_', ' ')}</span>
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{job.employment_type.replace('_', ' ')}</span>
                            <span className="flex items-center gap-1"><Globe className="w-3 h-3" />{job.location}</span>
                            {job.salary_min && <span className="flex items-center gap-1"><Star className="w-3 h-3" />${job.salary_min.toLocaleString()} - {job.salary_max ? job.salary_max.toLocaleString() : '+'}k</span>}
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">{job.description}</p>
                          <div className="flex items-center gap-4 text-xs">
                            <span className="text-muted-foreground">{appCount} applications</span>
                            <span className="text-muted-foreground">{job.openings_count} opening{job.openings_count > 1 ? 's' : ''}</span>
                            {job.posted_date && <span className="text-muted-foreground">Posted {format(new Date(job.posted_date), 'MMM d, yyyy')}</span>}
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          {job.status === 'draft' && (
                            <Button size="sm" onClick={() => postToIndeed(job)} disabled={postingToIndeed}>
                              {postingToIndeed ? <><Loader2 className="w-3 h-3 animate-spin mr-1" />Posting...</> : <><Briefcase className="w-3 h-3 mr-1" />Post to Indeed</>}
                            </Button>
                          )}
                          <Button variant="outline" size="sm" onClick={() => { setEditingJob(job); setJobForm(job); setJobDialogOpen(true); }}>
                            <Pencil className="w-3 h-3 mr-1" />Edit
                          </Button>
                          {job.status === 'open' && (
                            <Button variant="outline" size="sm" onClick={() => {
                              base44.entities.JobPosting.update(job.id, { status: 'closed' });
                              qc.invalidateQueries({ queryKey: ['job-postings'] });
                              toast.success('Job posting closed');
                            }}>
                              Close Job
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        {/* Pipeline Tab */}
        <TabsContent value="pipeline" className="mt-4 space-y-3">
          <div className="flex gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Search candidates..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-44"><SelectValue placeholder="All Statuses" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                {PIPELINE_FLOW.map(s => (
                  <SelectItem key={s.key} value={s.key}>{s.icon} {s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : filtered.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">No candidates yet</p>
                <p className="text-sm text-muted-foreground mb-4">Search Indeed or add candidates manually</p>
                <div className="flex gap-2 justify-center">
                  <Button variant="outline" onClick={() => setTab('indeed')}><Globe className="w-4 h-4 mr-2" />Search Indeed</Button>
                  <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" />Add Manually</Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Candidate</TableHead>
                    <TableHead>Position / Experience</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Interview</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map(c => {
                    const safeParse = (v) => { try { return v ? JSON.parse(v) : []; } catch { return []; } };
                    const skills = safeParse(c.skills).slice(0, 3);
                    return (
                      <TableRow key={c.id} className="hover:bg-muted/30">
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary text-sm font-bold shrink-0">
                              {c.first_name?.[0]}
                            </div>
                            <div>
                              <p className="font-medium text-sm">{c.first_name} {c.last_name}</p>
                              <p className="text-xs text-muted-foreground">{c.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm">{c.position_applied || c.current_title || '—'}</p>
                          <div className="flex items-center gap-1.5 mt-0.5">
                            {c.years_experience > 0 && <span className="text-[10px] text-muted-foreground">{c.years_experience}yr exp</span>}
                            {skills.map((s, i) => <span key={i} className="text-[10px] bg-primary/10 text-primary px-1.5 rounded">{s}</span>)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`capitalize text-[10px] ${STATUS_COLORS[c.status] || ''}`}>
                            {c.status?.replace(/_/g, ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-0.5">
                            {[1,2,3,4,5].map(i => <Star key={i} className={`w-3 h-3 ${i <= (c.rating||0) ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground/30'}`} />)}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {c.interview_date ? format(new Date(c.interview_date), 'MMM d, h:mm a') : '—'}
                          {c.zoom_join_url && (
                            <a href={c.zoom_join_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-blue-600 hover:underline mt-0.5">
                              <Video className="w-3 h-3" />Join Zoom
                            </a>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {/* Contextual Actions for Candidates */}
                            <EntityActions
                              entity={c}
                              entityType="candidate"
                              onAction={(actionType, candidate) => {
                                if (actionType === 'call' && candidate.phone) window.open(`tel:${candidate.phone}`, '_self');
                                if (actionType === 'email' && candidate.email) window.open(`mailto:${candidate.email}`, '_blank');
                                if (actionType === 'interview') openScheduleInterview(candidate);
                                if (actionType === 'profile') setProfileCandidate(candidate);
                                if (actionType === 'hire' && (candidate.status === 'interviewed' || candidate.status === 'offer_sent')) openHireDialog(candidate);
                              }}
                            />
                            {/* Keep existing buttons for larger screens */}
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="h-7 text-xs gap-1 hidden lg:inline-flex" 
                              onClick={() => setProfileCandidate(c)}
                              aria-label={`View profile for ${c.first_name} ${c.last_name}`}
                            >
                              <Eye className="w-3 h-3" />Profile
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="h-7 text-xs gap-1 hidden lg:inline-flex" 
                              onClick={() => openScheduleInterview(c)}
                              aria-label={`Schedule interview for ${c.first_name} ${c.last_name}`}
                            >
                              <Video className="w-3 h-3" />Interview
                            </Button>
                            {(c.status === 'offer_sent' || c.status === 'interviewed') && (
                              <Button
                                size="sm"
                                className="h-7 text-xs gap-1 bg-emerald-600 hover:bg-emerald-700 hidden lg:inline-flex"
                                disabled={convertingId === c.id}
                                onClick={() => openHireDialog(c)}
                                aria-label={`Hire ${c.first_name} ${c.last_name}`}
                              >
                                {convertingId === c.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <UserCheck className="w-3 h-3" />}
                                Hire
                              </Button>
                            )}
                            {c.status === 'hired' && (
                              <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-[10px] h-7 px-2 hidden lg:inline-flex" role="status">
                                <span aria-hidden="true">✅</span> Hired
                              </Badge>
                            )}
                            {/* Edit/Delete - always accessible */}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-7 w-7" 
                              onClick={() => openEdit(c)}
                              aria-label={`Edit ${c.first_name} ${c.last_name}`}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-7 w-7" 
                              onClick={() => {
                                if (confirm(`Are you sure you want to remove ${c.first_name} ${c.last_name}?`)) {
                                  deleteMut.mutate(c.id);
                                }
                              }}
                              aria-label={`Delete ${c.first_name} ${c.last_name}`}
                            >
                              <Trash2 className="w-3.5 h-3.5 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>

        {/* Indeed Search Tab */}
        <TabsContent value="indeed" className="mt-4 space-y-4">
          <Card className="border-primary/20 bg-primary/5">
            <CardContent className="p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center">
                  <Briefcase className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-semibold">Indeed Candidate Search</p>
                  <p className="text-xs text-muted-foreground">AI-powered search — imports full resume, work history, skills, and education</p>
                </div>
              </div>
              <div className="flex gap-3 flex-wrap">
                <Input
                  value={indeedQuery}
                  onChange={e => setIndeedQuery(e.target.value)}
                  placeholder="Job title, e.g. Account Executive, SDR..."
                  className="flex-1 min-w-40"
                  onKeyDown={e => e.key === 'Enter' && searchIndeed()}
                />
                <Input
                  value={indeedLocation}
                  onChange={e => setIndeedLocation(e.target.value)}
                  placeholder="Location, e.g. Miami, FL"
                  className="w-44"
                  onKeyDown={e => e.key === 'Enter' && searchIndeed()}
                />
                <Button onClick={searchIndeed} disabled={searchingIndeed}>
                  {searchingIndeed ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Searching...</> : <><Sparkles className="w-4 h-4 mr-2" />Search Indeed</>}
                </Button>
              </div>
              <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
                <span className="flex items-center gap-1"><FileText className="w-3 h-3" />Full resume imported</span>
                <span className="flex items-center gap-1"><Award className="w-3 h-3" />Skills extracted</span>
                <span className="flex items-center gap-1"><Briefcase className="w-3 h-3" />Work history included</span>
                <span className="flex items-center gap-1"><Star className="w-3 h-3" />AI fit score</span>
              </div>
            </CardContent>
          </Card>

          {searchingIndeed && (
            <div className="text-center py-12 text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-primary" />
              <p>Fetching candidate profiles from Indeed for "{indeedQuery}"...</p>
              <p className="text-xs mt-1">Extracting resumes, skills & work history...</p>
            </div>
          )}

          {indeedResults.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm font-semibold">{indeedResults.length} candidates found on Indeed{indeedLocation ? ` in ${indeedLocation}` : ''}</p>
              {indeedResults.map((c, i) => (
                <Card key={i} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className="w-11 h-11 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-600 font-bold text-lg shrink-0">
                          {c.first_name?.charAt(0)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <p className="font-semibold">{c.first_name} {c.last_name}</p>
                            <div className="flex gap-0.5">
                              {[1,2,3,4,5].map(s => <Star key={s} className={`w-3 h-3 ${s <= (c.rating||0) ? 'text-amber-500 fill-amber-500' : 'text-muted-foreground/20'}`} />)}
                            </div>
                          </div>
                          <p className="text-xs text-primary font-medium">{c.current_title} {c.current_company ? `@ ${c.current_company}` : ''}</p>
                          <p className="text-xs text-muted-foreground">{c.email} · {c.phone}</p>
                          {c.years_experience > 0 && <p className="text-xs text-muted-foreground">{c.years_experience} years experience</p>}

                          {/* Skills */}
                          {c.skills?.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-2">
                              {c.skills.slice(0, 6).map((s, si) => (
                                <span key={si} className="bg-primary/10 text-primary text-[10px] px-1.5 py-0.5 rounded-full">{s}</span>
                              ))}
                              {c.skills.length > 6 && <span className="text-[10px] text-muted-foreground">+{c.skills.length - 6} more</span>}
                            </div>
                          )}

                          {/* Work history preview */}
                          {c.work_history?.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {c.work_history.slice(0, 2).map((w, wi) => (
                                <p key={wi} className="text-[11px] text-muted-foreground">
                                  <span className="font-medium text-foreground/70">{w.title}</span> @ {w.company} · {w.duration}
                                </p>
                              ))}
                            </div>
                          )}

                          {c.notes && <p className="text-xs text-muted-foreground mt-1.5 italic">"{c.notes}"</p>}
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 flex-shrink-0">
                        {c.indeed_profile_url && (
                          <a href={c.indeed_profile_url} target="_blank" rel="noopener noreferrer">
                            <Button variant="outline" size="sm" className="h-7 text-xs gap-1 w-full"><ExternalLink className="w-3 h-3" />Indeed</Button>
                          </a>
                        )}
                        <Button size="sm" className="h-7 text-xs gap-1" onClick={() => importCandidate(c)}>
                          <Plus className="w-3 h-3" />Import
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {indeedResults.length === 0 && !searchingIndeed && (
            <Card className="border-dashed">
              <CardContent className="py-12 text-center">
                <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">Search Indeed Candidates</p>
                <p className="text-sm text-muted-foreground">Enter a job title to find candidates with full resume data</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Indeed Integration Hub Tab */}
        <TabsContent value="indeed_hub" className="mt-4">
          <IndeedIntegrationHub />
        </TabsContent>

        {/* Interviews Tab */}
        <TabsContent value="interviews" className="mt-4">
          <div className="space-y-3">
            {meetings.filter(m => m.meeting_type === 'interview').length === 0 ? (
              <Card className="border-dashed">
                <CardContent className="py-12 text-center">
                  <Video className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="font-semibold mb-1">No interviews scheduled</p>
                  <p className="text-sm text-muted-foreground">Schedule an AXIS Meet interview from the candidate pipeline</p>
                </CardContent>
              </Card>
            ) : meetings.filter(m => m.meeting_type === 'interview').map(m => {
              // Find linked candidate
              const linkedCandidate = candidates.find(c => c.id === m.candidate_id);
              return (
                <Card key={m.id}>
                  <CardContent className="p-4 flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold">{m.topic}</p>
                        {linkedCandidate && (
                          <Badge variant="outline" className={`text-[10px] ${STATUS_COLORS[linkedCandidate.status]}`}>
                            {linkedCandidate.status?.replace(/_/g, ' ')}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{m.scheduled_date ? format(new Date(m.scheduled_date), 'MMM d, h:mm a') : '—'}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{m.duration_minutes}min</span>
                        {m.attendee_email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{m.attendee_email}</span>}
                      </div>
                      {m.zoom_meeting_id && (
                        <code className="text-[11px] bg-muted px-2 py-0.5 rounded font-mono mt-2 inline-block">ID: {m.zoom_meeting_id} · PWD: {m.password}</code>
                      )}
                    </div>
                    <div className="flex flex-col gap-2 shrink-0">
                      {m.join_url && (
                        <a href={m.join_url} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" className="gap-1 bg-blue-600 hover:bg-blue-700 w-full">
                            <Video className="w-3.5 h-3.5" />Join Interview
                          </Button>
                        </a>
                      )}
                      {linkedCandidate && (
                        <Button variant="outline" size="sm" className="gap-1 text-xs w-full" onClick={() => setProfileCandidate(linkedCandidate)}>
                          <Eye className="w-3.5 h-3.5" />View Profile
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add/Edit Candidate Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editCandidate ? 'Edit Candidate' : 'Add Candidate'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div><Label>First Name *</Label><Input value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} /></div>
            <div><Label>Last Name</Label><Input value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} /></div>
            <div><Label>Email *</Label><Input value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} /></div>
            <div><Label>Phone</Label><Input value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="col-span-2"><Label>Position Applied</Label><Input value={form.position_applied || ''} onChange={e => setForm({ ...form, position_applied: e.target.value })} /></div>
            <div>
              <Label>Source</Label>
              <Select value={form.source} onValueChange={v => setForm({ ...form, source: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="indeed">Indeed</SelectItem>
                  <SelectItem value="linkedin">LinkedIn</SelectItem>
                  <SelectItem value="referral">Referral</SelectItem>
                  <SelectItem value="direct">Direct</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PIPELINE_FLOW.map(s => (
                    <SelectItem key={s.key} value={s.key}>{s.icon} {s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2"><Label>Indeed Profile URL</Label><Input value={form.indeed_profile_url || ''} onChange={e => setForm({ ...form, indeed_profile_url: e.target.value })} placeholder="https://www.indeed.com/r/..." aria-describedby="indeed-url-help" />
              <p id="indeed-url-help" className="text-xs text-muted-foreground mt-1">Paste the Indeed profile URL to link the candidate's profile</p>
            </div>
            <div className="col-span-2">
              <Label>Rating</Label>
              <StarRating value={form.rating || 0} onChange={v => setForm({ ...form, rating: v })} />
              <p className="text-xs text-muted-foreground mt-1">Rate the candidate from 1-5 stars based on their fit for the role</p>
            </div>
            <div className="col-span-2"><Label>Notes</Label><Textarea value={form.notes || ''} onChange={e => setForm({ ...form, notes: e.target.value })} rows={3} aria-describedby="notes-help" />
              <p id="notes-help" className="text-xs text-muted-foreground mt-1">Add any additional information about the candidate's background, skills, or interview notes</p>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-2">
            <Button variant="outline" onClick={() => setDialogOpen(false)} type="button">Cancel</Button>
            <Button 
              onClick={handleSave} 
              disabled={!form.first_name || !form.email}
              type="submit"
              aria-disabled={!form.first_name || !form.email}
            >
              {editCandidate ? 'Update Candidate' : 'Add Candidate'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Hire & Onboard Dialog */}
      <Dialog open={hireDialogOpen} onOpenChange={setHireDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><UserCheck className="w-5 h-5 text-emerald-600" />Hire & Onboard as AE</DialogTitle>
          </DialogHeader>
          {hiringCandidate && (
            <div className="space-y-4">
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                <p className="font-semibold">{hiringCandidate.first_name} {hiringCandidate.last_name}</p>
                <p className="text-xs text-muted-foreground">{hiringCandidate.email} · {hiringCandidate.position_applied}</p>
              </div>
              <div className="rounded-lg bg-blue-500/5 border border-blue-500/20 p-3 text-xs text-blue-700 space-y-1">
                <p className="font-bold">This action will automatically:</p>
                <p>✅ Create their AE profile in Sales Team</p>
                <p>✅ Import them as a contact in the Lead CRM</p>
                <p>✅ Invite them to the CallBot AI platform</p>
                <p>✅ Send a hire confirmation email with their targets</p>
                <p>✅ Start their 8-step onboarding tracker</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Role</Label>
                  <Select value={hireForm.role} onValueChange={v => setHireForm({ ...hireForm, role: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rep">Rep</SelectItem>
                      <SelectItem value="sdr">SDR</SelectItem>
                      <SelectItem value="senior_rep">Senior Rep</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Territory (optional)</Label>
                  <Input value={hireForm.territory} onChange={e => setHireForm({ ...hireForm, territory: e.target.value })} placeholder="e.g. Downtown, Zone A" />
                </div>
                <div>
                  <Label>Daily Call Target</Label>
                  <Input type="number" value={hireForm.target_calls_per_day} onChange={e => setHireForm({ ...hireForm, target_calls_per_day: parseInt(e.target.value) })} />
                </div>
                <div>
                  <Label>Weekly Appt Target</Label>
                  <Input type="number" value={hireForm.target_appointments_per_week} onChange={e => setHireForm({ ...hireForm, target_appointments_per_week: parseInt(e.target.value) })} />
                </div>
                <div className="col-span-2">
                  <Label>Monthly Revenue Target ($)</Label>
                  <Input type="number" value={hireForm.target_revenue_per_month} onChange={e => setHireForm({ ...hireForm, target_revenue_per_month: parseInt(e.target.value) })} />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setHireDialogOpen(false)}>Cancel</Button>
                <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700" onClick={convertToAE}>
                  <UserCheck className="w-4 h-4" />Confirm Hire & Onboard
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Schedule Interview Dialog */}
      <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Schedule AXIS Meet Interview</DialogTitle>
          </DialogHeader>
          {schedulingFor && (
            <div className="space-y-4">
              <div className="p-3 bg-muted rounded-lg">
                <p className="font-semibold">{schedulingFor.first_name} {schedulingFor.last_name}</p>
                <p className="text-xs text-muted-foreground">{schedulingFor.position_applied} · {schedulingFor.email}</p>
              </div>
              <div><Label>Interview Date & Time *</Label><Input type="datetime-local" value={scheduleForm.date} onChange={e => setScheduleForm({ ...scheduleForm, date: e.target.value })} /></div>
              <div>
                <Label>Duration (minutes)</Label>
                <Select value={String(scheduleForm.duration)} onValueChange={v => setScheduleForm({ ...scheduleForm, duration: parseInt(v) })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['30','45','60','90'].map(d => <SelectItem key={d} value={d}>{d} min</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Notes (optional)</Label><Textarea value={scheduleForm.notes} onChange={e => setScheduleForm({ ...scheduleForm, notes: e.target.value })} rows={2} placeholder="Interview focus areas, prep notes..." /></div>
              <div className="p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg text-xs text-blue-700 space-y-1">
                <p className="font-bold">This will automatically:</p>
                <p>📧 Send AXIS Meet invite email to the candidate</p>
                <p>📅 Open Google Calendar to add the event</p>
                <p>🔗 Generate a unique AXIS Meet video link</p>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setScheduleDialogOpen(false)}>Cancel</Button>
                <Button onClick={scheduleInterview} className="gap-2"><Video className="w-4 h-4" />Schedule & Send Invite</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Job Posting Dialog */}
      <Dialog open={jobDialogOpen} onOpenChange={setJobDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingJob ? 'Edit Job Posting' : 'Create Job Posting'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Job Title *</Label>
                <Input value={jobForm.title} onChange={e => setJobForm({ ...jobForm, title: e.target.value })} placeholder="e.g., Account Executive" />
              </div>
              <div>
                <Label>Department *</Label>
                <Select value={jobForm.department} onValueChange={v => setJobForm({ ...jobForm, department: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sales">Sales</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="operations">Operations</SelectItem>
                    <SelectItem value="hr">HR</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="engineering">Engineering</SelectItem>
                    <SelectItem value="customer_success">Customer Success</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Employment Type</Label>
                <Select value={jobForm.employment_type} onValueChange={v => setJobForm({ ...jobForm, employment_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full_time">Full-time</SelectItem>
                    <SelectItem value="part_time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="internship">Internship</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Location</Label>
                <Input value={jobForm.location} onChange={e => setJobForm({ ...jobForm, location: e.target.value })} placeholder="e.g., Remote, Miami FL" />
              </div>
              <div>
                <Label>Openings</Label>
                <Input type="number" value={jobForm.openings_count} onChange={e => setJobForm({ ...jobForm, openings_count: parseInt(e.target.value) })} />
              </div>
              <div>
                <Label>Min Salary ($k)</Label>
                <Input type="number" value={jobForm.salary_min} onChange={e => setJobForm({ ...jobForm, salary_min: parseInt(e.target.value) })} placeholder="50" />
              </div>
              <div>
                <Label>Max Salary ($k)</Label>
                <Input type="number" value={jobForm.salary_max} onChange={e => setJobForm({ ...jobForm, salary_max: parseInt(e.target.value) })} placeholder="80" />
              </div>
            </div>

            <div>
              <Label>Job Description *</Label>
              <Textarea value={jobForm.description} onChange={e => setJobForm({ ...jobForm, description: e.target.value })} rows={4} placeholder="Describe the role, company culture, and growth opportunities..." />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Requirements (one per line)</Label>
                <Textarea 
                  value={JSON.parse(jobForm.requirements || '[]').join('\n')} 
                  onChange={e => setJobForm({ ...jobForm, requirements: JSON.stringify(e.target.value.split('\n').filter(l => l.trim())) })} 
                  rows={3} 
                  placeholder="• 3+ years sales experience&#10;• Excellent communication skills" 
                />
              </div>
              <div>
                <Label>Responsibilities (one per line)</Label>
                <Textarea 
                  value={JSON.parse(jobForm.responsibilities || '[]').join('\n')} 
                  onChange={e => setJobForm({ ...jobForm, responsibilities: JSON.stringify(e.target.value.split('\n').filter(l => l.trim())) })} 
                  rows={3} 
                  placeholder="• Generate and qualify leads&#10;• Conduct product demonstrations" 
                />
              </div>
            </div>

            <div>
              <Label>Benefits (one per line)</Label>
              <Textarea 
                value={JSON.parse(jobForm.benefits || '[]').join('\n')} 
                onChange={e => setJobForm({ ...jobForm, benefits: JSON.stringify(e.target.value.split('\n').filter(l => l.trim())) })} 
                rows={2} 
                placeholder="• Competitive salary + commission&#10;• Health insurance&#10;• Remote work flexibility" 
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Status</Label>
                <Select value={jobForm.status} onValueChange={v => setJobForm({ ...jobForm, status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Application Deadline</Label>
                <Input type="date" value={jobForm.application_deadline ? jobForm.application_deadline.split('T')[0] : ''} onChange={e => setJobForm({ ...jobForm, application_deadline: e.target.value ? new Date(e.target.value).toISOString() : '' })} />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setJobDialogOpen(false)} type="button">Cancel</Button>
              <Button onClick={() => {
                if (!jobForm.title || !jobForm.description) {
                  toast.error('Title and description are required');
                  return;
                }
                if (editingJob) {
                  updateJobMut.mutate({ id: editingJob.id, data: { ...jobForm, posted_by: user?.email } });
                } else {
                  createJobMut.mutate({ ...jobForm, posted_by: user?.email, owner: user?.email });
                }
              }}>
                {editingJob ? 'Update Job Posting' : 'Create Job Posting'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Candidate Profile Drawer */}
      {profileCandidate && (
        <CandidateProfileDrawer
          candidate={profileCandidate}
          onClose={() => setProfileCandidate(null)}
          onRefresh={() => qc.invalidateQueries({ queryKey: ['candidates'] })}
          onScheduleInterview={(c) => { setProfileCandidate(null); openScheduleInterview(c); }}
          onHire={(c) => { setProfileCandidate(null); openHireDialog(c); }}
        />
      )}
    </div>
  );
}