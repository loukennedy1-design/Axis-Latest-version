import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Phone, MessageSquare, Mail, CreditCard, Calendar, Video, 
  Users, Zap, Globe, Shield, BarChart3, Database, 
  Search, ExternalLink, ChevronDown, ChevronRight,
  Webhook, Code2, Key, Link2, Plug, Layers, CheckCircle2,
  ArrowRight, Lock, Share2, AlertCircle, Wifi, WifiOff, X,
  Info, Settings, Activity, Tag, Eye, EyeOff
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

// OAuth-supported connectors (one-click via Base44 connectors)
const OAUTH_APIS = {
  'Google Calendar': 'googlecalendar',
  'Gmail API': 'gmail',
  'Google Sheets': 'googlesheets',
  'Google Drive': 'googledrive',
  'Google Ads': 'googleads',
  'Google Analytics 4': 'google_analytics',
  'Google Meet': 'googlemeet',
  'Slack': 'slack',
  'HubSpot': 'hubspot',
  'Salesforce': 'salesforce',
  'LinkedIn Ads': 'linkedin',
  'Microsoft Teams': 'microsoft_teams',
  'Microsoft Outlook Calendar': 'outlook',
  'Notion': 'notion',
  'Airtable': 'airtable',
  'Dropbox': 'dropbox',
  'GitHub API': 'github',
  'BambooHR': 'bamboohr',
  'TikTok Ads': 'tiktok',
  'Discord': 'discord',
};

// SSO-capable integrations that use the silent-session-detect connect flow.
// Keyed by the exact api.name as it appears in API_CATEGORIES. Value is the
// integration_type handled by the oauthAuthorize / oauthCallback backend functions.
const SSO_INTEGRATIONS = {
  'Facebook / Meta Pages': 'facebook',
  'Instagram Business': 'instagram',
  'TikTok': 'tiktok',
  'LinkedIn': 'linkedin',
  'Twitter / X API': 'twitter',
  'WhatsApp Business API': 'whatsapp',
  'Zoom': 'zoom',
};

const API_CATEGORIES = [
  {
    id: 'telephony', label: 'Telephony & Phone', icon: Phone,
    color: 'text-blue-500', bg: 'bg-blue-500/10 border-blue-500/20',
    apis: [
      { name: 'Twilio', desc: 'Voice, SMS, WhatsApp, phone numbers & call routing', docs: 'https://www.twilio.com/docs', status: 'configured', fields: ['TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN', 'TWILIO_PHONE_NUMBER'] },
      { name: 'Vonage (Nexmo)', desc: 'Voice calls, SMS, number insight & verify API', docs: 'https://developer.vonage.com', status: 'available', fields: ['VONAGE_API_KEY', 'VONAGE_API_SECRET'] },
      { name: 'Bandwidth', desc: 'Carrier-grade voice, messaging & 911 services', docs: 'https://dev.bandwidth.com', status: 'available', fields: ['BANDWIDTH_ACCOUNT_ID', 'BANDWIDTH_API_TOKEN'] },
      { name: 'Plivo', desc: 'Voice & SMS APIs with global coverage', docs: 'https://www.plivo.com/docs', status: 'available', fields: ['PLIVO_AUTH_ID', 'PLIVO_AUTH_TOKEN'] },
      { name: 'Telnyx', desc: 'SIP trunking, voice, SMS & fax', docs: 'https://developers.telnyx.com', status: 'available', fields: ['TELNYX_API_KEY'] },
      { name: 'Aircall', desc: 'Cloud phone system with CRM integrations', docs: 'https://developer.aircall.io', status: 'available', fields: ['AIRCALL_API_ID', 'AIRCALL_API_TOKEN'] },
      { name: 'JustCall', desc: 'Cloud phone system for sales & support teams', docs: 'https://developers.justcall.io', status: 'available', fields: ['JUSTCALL_API_KEY', 'JUSTCALL_API_SECRET'] },
      { name: 'Five9', desc: 'Cloud contact center & predictive dialer API', docs: 'https://developer.five9.com', status: 'available', fields: ['FIVE9_USERNAME', 'FIVE9_PASSWORD'] },
      { name: 'Dialpad', desc: 'AI-powered calling and contact center platform', docs: 'https://developers.dialpad.com', status: 'available', fields: ['DIALPAD_API_KEY'] },
      { name: 'SignalWire', desc: 'AI-native communications platform', docs: 'https://developer.signalwire.com', status: 'available', fields: ['SIGNALWIRE_PROJECT_ID', 'SIGNALWIRE_TOKEN', 'SIGNALWIRE_SPACE_URL'] },
    ]
  },
  {
    id: 'sms_messaging', label: 'SMS & Messaging', icon: MessageSquare,
    color: 'text-green-500', bg: 'bg-green-500/10 border-green-500/20',
    apis: [
      { name: 'Twilio SMS', desc: 'Two-way SMS, MMS & WhatsApp messaging', docs: 'https://www.twilio.com/sms', status: 'configured', fields: ['TWILIO_ACCOUNT_SID', 'TWILIO_AUTH_TOKEN'] },
      { name: 'Slack', desc: 'Team messaging, bots & workflow notifications', docs: 'https://api.slack.com', status: 'available', fields: [] },
      { name: 'Discord', desc: 'Community messaging & bot automation', docs: 'https://discord.com/developers', status: 'available', fields: [] },
      { name: 'WhatsApp Business API', desc: 'Official WhatsApp messaging for businesses', docs: 'https://developers.facebook.com/docs/whatsapp', status: 'available', fields: ['WHATSAPP_ACCESS_TOKEN', 'WHATSAPP_PHONE_NUMBER_ID'] },
      { name: 'Telegram Bot API', desc: 'Build bots and send messages via Telegram', docs: 'https://core.telegram.org/bots/api', status: 'available', fields: ['TELEGRAM_BOT_TOKEN'] },
      { name: 'Sinch', desc: 'SMS, voice & email messaging APIs', docs: 'https://developers.sinch.com', status: 'available', fields: ['SINCH_APP_KEY', 'SINCH_APP_SECRET'] },
      { name: 'MessageBird', desc: 'Omnichannel messaging platform', docs: 'https://developers.messagebird.com', status: 'available', fields: ['MESSAGEBIRD_API_KEY'] },
      { name: 'ClickSend', desc: 'SMS, email, voice & post API', docs: 'https://developers.clicksend.com', status: 'available', fields: ['CLICKSEND_USERNAME', 'CLICKSEND_API_KEY'] },
    ]
  },
  {
    id: 'email', label: 'Email', icon: Mail,
    color: 'text-purple-500', bg: 'bg-purple-500/10 border-purple-500/20',
    apis: [
      { name: 'Gmail API', desc: 'Read, send & manage Gmail messages', docs: 'https://developers.google.com/gmail/api', status: 'available', fields: [] },
      { name: 'Microsoft Outlook Calendar', desc: 'Send & receive emails via Microsoft 365', docs: 'https://learn.microsoft.com/graph', status: 'available', fields: [] },
      { name: 'SendGrid', desc: 'Transactional & marketing email delivery', docs: 'https://docs.sendgrid.com', status: 'available', fields: ['SENDGRID_API_KEY'] },
      { name: 'Mailgun', desc: 'Email API for developers', docs: 'https://documentation.mailgun.com', status: 'available', fields: ['MAILGUN_API_KEY', 'MAILGUN_DOMAIN'] },
      { name: 'Postmark', desc: 'Fast transactional email delivery', docs: 'https://postmarkapp.com/developer', status: 'available', fields: ['POSTMARK_SERVER_TOKEN'] },
      { name: 'Resend', desc: 'Email API built for developers', docs: 'https://resend.com/docs', status: 'available', fields: ['RESEND_API_KEY'] },
      { name: 'Brevo (Sendinblue)', desc: 'Email, SMS & marketing automation', docs: 'https://developers.brevo.com', status: 'available', fields: ['BREVO_API_KEY'] },
      { name: 'Klaviyo', desc: 'Email & SMS marketing for e-commerce', docs: 'https://developers.klaviyo.com', status: 'available', fields: ['KLAVIYO_PRIVATE_API_KEY'] },
    ]
  },
  {
    id: 'crm_sales', label: 'CRM & Sales', icon: Users,
    color: 'text-orange-500', bg: 'bg-orange-500/10 border-orange-500/20',
    apis: [
      { name: 'Salesforce', desc: 'World\'s #1 CRM — contacts, leads, opportunities', docs: 'https://developer.salesforce.com', status: 'available', fields: [] },
      { name: 'HubSpot', desc: 'CRM, marketing, sales & service hub', docs: 'https://developers.hubspot.com', status: 'available', fields: [] },
      { name: 'Pipedrive', desc: 'Sales CRM & pipeline management', docs: 'https://developers.pipedrive.com', status: 'available', fields: ['PIPEDRIVE_API_TOKEN'] },
      { name: 'Zoho CRM', desc: 'CRM, sales pipeline & automation', docs: 'https://www.zoho.com/crm/developer', status: 'available', fields: ['ZOHO_CLIENT_ID', 'ZOHO_CLIENT_SECRET'] },
      { name: 'GoHighLevel', desc: 'All-in-one marketing & sales platform', docs: 'https://highlevel.stoplight.io', status: 'available', fields: ['GHL_API_KEY', 'GHL_LOCATION_ID'] },
      { name: 'ActiveCampaign', desc: 'CRM & email marketing automation', docs: 'https://developers.activecampaign.com', status: 'available', fields: ['ACTIVECAMPAIGN_API_URL', 'ACTIVECAMPAIGN_API_KEY'] },
      { name: 'Close CRM', desc: 'Inside sales CRM with built-in calling', docs: 'https://developer.close.com', status: 'available', fields: ['CLOSE_API_KEY'] },
      { name: 'Freshsales', desc: 'AI-powered CRM for sales teams', docs: 'https://developers.freshworks.com', status: 'available', fields: ['FRESHSALES_API_KEY', 'FRESHSALES_DOMAIN'] },
    ]
  },
  {
    id: 'payments', label: 'Payments & Billing', icon: CreditCard,
    color: 'text-emerald-500', bg: 'bg-emerald-500/10 border-emerald-500/20',
    apis: [
      { name: 'Square', desc: 'Payments, POS & subscriptions', docs: 'https://developer.squareup.com', status: 'configured', fields: ['SQUARE_API_KEY', 'SQUARE_LOCATION_ID'] },
      { name: 'Stripe', desc: 'Online payments, subscriptions & billing', docs: 'https://docs.stripe.com', status: 'available', fields: ['STRIPE_PUBLISHABLE_KEY', 'STRIPE_SECRET_KEY'] },
      { name: 'PayPal', desc: 'Payments, subscriptions & payouts', docs: 'https://developer.paypal.com', status: 'available', fields: ['PAYPAL_CLIENT_ID', 'PAYPAL_CLIENT_SECRET'] },
      { name: 'Chargebee', desc: 'Subscription billing & revenue management', docs: 'https://apidocs.chargebee.com', status: 'available', fields: ['CHARGEBEE_API_KEY', 'CHARGEBEE_SITE_NAME'] },
      { name: 'Recurly', desc: 'Subscription management platform', docs: 'https://recurly.com/developers', status: 'available', fields: ['RECURLY_API_KEY'] },
      { name: 'Authorize.Net', desc: 'Secure payment gateway for merchants', docs: 'https://developer.authorize.net', status: 'available', fields: ['AUTHNET_API_LOGIN_ID', 'AUTHNET_TRANSACTION_KEY'] },
    ]
  },
  {
    id: 'scheduling', label: 'Scheduling & Calendar', icon: Calendar,
    color: 'text-sky-500', bg: 'bg-sky-500/10 border-sky-500/20',
    apis: [
      { name: 'Calendly', desc: 'Appointment scheduling & availability', docs: 'https://developer.calendly.com', status: 'configured', fields: ['CALENDLY_API_KEY', 'CALENDLY_USER_URI'] },
      { name: 'Google Calendar', desc: 'Calendar events, availability & scheduling', docs: 'https://developers.google.com/calendar', status: 'configured', fields: [] },
      { name: 'Microsoft Outlook Calendar', desc: 'Calendar & meeting scheduling via Graph API', docs: 'https://learn.microsoft.com/graph/outlook-calendar', status: 'available', fields: [] },
      { name: 'Acuity Scheduling', desc: 'Online appointment booking & management', docs: 'https://developers.acuityscheduling.com', status: 'available', fields: ['ACUITY_USER_ID', 'ACUITY_API_KEY'] },
      { name: 'Cal.com', desc: 'Open-source scheduling infrastructure', docs: 'https://cal.com/docs/api-reference', status: 'available', fields: ['CALCOM_API_KEY'] },
    ]
  },
  {
    id: 'video', label: 'Video & Conferencing', icon: Video,
    color: 'text-violet-500', bg: 'bg-violet-500/10 border-violet-500/20',
    apis: [
      { name: 'Google Meet', desc: 'Video calls via Google Workspace', docs: 'https://developers.google.com/meet', status: 'available', fields: [] },
      { name: 'Microsoft Teams', desc: 'Team meetings & collaboration API', docs: 'https://learn.microsoft.com/graph/teams', status: 'available', fields: [] },
      { name: 'Zoom', desc: 'Video meetings, webinars & recordings', docs: 'https://marketplace.zoom.us/docs', status: 'available', fields: ['ZOOM_CLIENT_ID', 'ZOOM_CLIENT_SECRET', 'ZOOM_ACCOUNT_ID'] },
      { name: 'Whereby', desc: 'Embeddable video meetings', docs: 'https://docs.whereby.com', status: 'available', fields: ['WHEREBY_API_KEY'] },
      { name: 'Daily.co', desc: 'Video call infrastructure & recordings', docs: 'https://docs.daily.co', status: 'available', fields: ['DAILY_API_KEY'] },
    ]
  },
  {
    id: 'ai_ml', label: 'AI & Machine Learning', icon: Zap,
    color: 'text-yellow-500', bg: 'bg-yellow-500/10 border-yellow-500/20',
    apis: [
      { name: 'OpenAI', desc: 'GPT-4, DALL-E, Whisper & embeddings', docs: 'https://platform.openai.com/docs', status: 'available', fields: ['OPENAI_API_KEY'] },
      { name: 'Anthropic Claude', desc: 'Claude AI models for reasoning & generation', docs: 'https://docs.anthropic.com', status: 'available', fields: ['ANTHROPIC_API_KEY'] },
      { name: 'Google Gemini', desc: 'Multimodal AI models from Google', docs: 'https://ai.google.dev/docs', status: 'available', fields: ['GOOGLE_GEMINI_API_KEY'] },
      { name: 'ElevenLabs', desc: 'AI voice synthesis & cloning', docs: 'https://docs.elevenlabs.io', status: 'available', fields: ['ELEVENLABS_API_KEY'] },
      { name: 'Deepgram', desc: 'Real-time speech-to-text transcription', docs: 'https://developers.deepgram.com', status: 'available', fields: ['DEEPGRAM_API_KEY'] },
      { name: 'AssemblyAI', desc: 'Audio transcription, sentiment & summarization', docs: 'https://www.assemblyai.com/docs', status: 'available', fields: ['ASSEMBLYAI_API_KEY'] },
      { name: 'Hugging Face', desc: 'Open-source ML models & inference API', docs: 'https://huggingface.co/docs', status: 'available', fields: [] },
      { name: 'Cohere', desc: 'NLP embeddings, classification & generation', docs: 'https://docs.cohere.com', status: 'available', fields: ['COHERE_API_KEY'] },
    ]
  },
  {
    id: 'marketing', label: 'Marketing & Ads', icon: BarChart3,
    color: 'text-pink-500', bg: 'bg-pink-500/10 border-pink-500/20',
    apis: [
      { name: 'Google Ads', desc: 'Search, display & performance ads', docs: 'https://developers.google.com/google-ads', status: 'available', fields: [] },
      { name: 'Google Analytics 4', desc: 'Website & app analytics events', docs: 'https://developers.google.com/analytics', status: 'available', fields: [] },
      { name: 'LinkedIn Ads', desc: 'B2B lead gen forms & campaign API', docs: 'https://learn.microsoft.com/linkedin', status: 'available', fields: [] },
      { name: 'TikTok Ads', desc: 'TikTok marketing & lead generation API', docs: 'https://ads.tiktok.com/marketing_api', status: 'available', fields: [] },
      { name: 'Facebook / Meta Ads', desc: 'Lead forms, audiences & ad management', docs: 'https://developers.facebook.com/docs/marketing-apis', status: 'available', fields: ['META_ACCESS_TOKEN', 'META_AD_ACCOUNT_ID'] },
      { name: 'Mailchimp', desc: 'Email marketing & audience management', docs: 'https://mailchimp.com/developer', status: 'available', fields: ['MAILCHIMP_API_KEY'] },
      { name: 'Mixpanel', desc: 'Product analytics & event tracking', docs: 'https://developer.mixpanel.com', status: 'available', fields: ['MIXPANEL_PROJECT_TOKEN'] },
      { name: 'Segment', desc: 'Customer data platform & analytics', docs: 'https://segment.com/docs', status: 'available', fields: ['SEGMENT_WRITE_KEY'] },
    ]
  },
  {
    id: 'data_storage', label: 'Data & Storage', icon: Database,
    color: 'text-teal-500', bg: 'bg-teal-500/10 border-teal-500/20',
    apis: [
      { name: 'Airtable', desc: 'Database & spreadsheet hybrid API', docs: 'https://airtable.com/developers', status: 'available', fields: [] },
      { name: 'Notion', desc: 'Workspace database & pages API', docs: 'https://developers.notion.com', status: 'available', fields: [] },
      { name: 'Google Sheets', desc: 'Read & write spreadsheet data', docs: 'https://developers.google.com/sheets/api', status: 'available', fields: [] },
      { name: 'Supabase', desc: 'Open-source Firebase alternative', docs: 'https://supabase.com/docs', status: 'available', fields: ['SUPABASE_URL', 'SUPABASE_ANON_KEY'] },
      { name: 'AWS S3', desc: 'Object storage for files & media', docs: 'https://docs.aws.amazon.com/s3', status: 'available', fields: ['AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY', 'S3_BUCKET_NAME', 'AWS_REGION'] },
      { name: 'Cloudinary', desc: 'Image & video management in the cloud', docs: 'https://cloudinary.com/documentation', status: 'available', fields: ['CLOUDINARY_CLOUD_NAME', 'CLOUDINARY_API_KEY', 'CLOUDINARY_API_SECRET'] },
    ]
  },
  {
    id: 'automation', label: 'Automation & Webhooks', icon: Webhook,
    color: 'text-amber-500', bg: 'bg-amber-500/10 border-amber-500/20',
    apis: [
      { name: 'Zapier', desc: 'Workflow automation & app connections', docs: 'https://platform.zapier.com/docs', status: 'available', fields: ['ZAPIER_API_KEY'] },
      { name: 'Make (Integromat)', desc: 'Visual workflow automation platform', docs: 'https://www.make.com/en/api-documentation', status: 'available', fields: ['MAKE_API_TOKEN'] },
      { name: 'n8n', desc: 'Open-source workflow automation', docs: 'https://docs.n8n.io/api', status: 'available', fields: ['N8N_API_KEY', 'N8N_INSTANCE_URL'] },
      { name: 'Pipedream', desc: 'Serverless workflow & integration platform', docs: 'https://pipedream.com/docs/api', status: 'available', fields: ['PIPEDREAM_API_KEY'] },
    ]
  },
  {
    id: 'compliance_legal', label: 'Compliance & Legal', icon: Shield,
    color: 'text-red-500', bg: 'bg-red-500/10 border-red-500/20',
    apis: [
      { name: 'DocuSign', desc: 'Electronic signature & agreement cloud', docs: 'https://developers.docusign.com', status: 'available', fields: ['DOCUSIGN_INTEGRATION_KEY', 'DOCUSIGN_USER_ID', 'DOCUSIGN_ACCOUNT_ID'] },
      { name: 'PandaDoc', desc: 'Document automation & e-signatures', docs: 'https://developers.pandadoc.com', status: 'available', fields: ['PANDADOC_API_KEY'] },
      { name: 'HelloSign (Dropbox Sign)', desc: 'eSignature & document API', docs: 'https://developers.hellosign.com', status: 'available', fields: ['HELLOSIGN_API_KEY'] },
      { name: 'Numverify', desc: 'Phone number validation & carrier lookup', docs: 'https://numverify.com/documentation', status: 'available', fields: ['NUMVERIFY_API_KEY'] },
      { name: 'National DNC Registry', desc: 'FTC Do Not Call list verification', docs: 'https://www.donotcall.gov/business.html', status: 'available', fields: ['DNC_ORGANIZATION_ID', 'DNC_SAN_NUMBER'] },
    ]
  },
  {
    id: 'hr_recruiting', label: 'HR & Recruiting', icon: Layers,
    color: 'text-cyan-500', bg: 'bg-cyan-500/10 border-cyan-500/20',
    apis: [
      { name: 'BambooHR', desc: 'HR software & people data API', docs: 'https://documentation.bamboohr.com', status: 'available', fields: [] },
      { name: 'Greenhouse', desc: 'Applicant tracking system API', docs: 'https://developers.greenhouse.io', status: 'available', fields: ['GREENHOUSE_API_KEY'] },
      { name: 'Lever', desc: 'ATS & CRM for recruiting teams', docs: 'https://hire.lever.co/developer', status: 'available', fields: ['LEVER_API_KEY'] },
      { name: 'Gusto', desc: 'Payroll, benefits & HR management', docs: 'https://docs.gusto.com', status: 'available', fields: ['GUSTO_CLIENT_ID', 'GUSTO_CLIENT_SECRET'] },
      { name: 'ADP', desc: 'Payroll & workforce management', docs: 'https://developers.adp.com', status: 'available', fields: ['ADP_CLIENT_ID', 'ADP_CLIENT_SECRET'] },
      { name: 'Indeed Publisher API', desc: 'Job listings & candidate data access', docs: 'https://opensource.indeedeng.io/api-documentation', status: 'available', fields: ['INDEED_PUBLISHER_ID'] },
    ]
  },
  {
    id: 'social_media', label: 'Social Media', icon: Share2,
    color: 'text-fuchsia-500', bg: 'bg-fuchsia-500/10 border-fuchsia-500/20',
    apis: [
      { name: 'Instagram Business', desc: 'Post content, fetch insights & lead ads via Instagram Graph API', docs: 'https://developers.facebook.com/docs/instagram-api', status: 'available', fields: [] },
      { name: 'Facebook / Meta Pages', desc: 'Manage pages, posts, comments & lead form submissions', docs: 'https://developers.facebook.com/docs/pages', status: 'available', fields: ['META_ACCESS_TOKEN', 'META_PAGE_ID'] },
      { name: 'TikTok', desc: 'TikTok content publishing & analytics API', docs: 'https://developers.tiktok.com', status: 'available', fields: [] },
      { name: 'LinkedIn', desc: 'Share posts, company updates & retrieve follower analytics', docs: 'https://learn.microsoft.com/linkedin', status: 'available', fields: [] },
      { name: 'Twitter / X API', desc: 'Post tweets, search mentions & monitor brand keywords', docs: 'https://developer.twitter.com/en/docs', status: 'available', fields: ['TWITTER_API_KEY', 'TWITTER_API_SECRET', 'TWITTER_ACCESS_TOKEN', 'TWITTER_ACCESS_SECRET'] },
      { name: 'Pinterest', desc: 'Create pins, boards & access analytics', docs: 'https://developers.pinterest.com', status: 'available', fields: ['PINTEREST_ACCESS_TOKEN'] },
      { name: 'YouTube Data API', desc: 'Upload videos, manage playlists & retrieve analytics', docs: 'https://developers.google.com/youtube/v3', status: 'available', fields: ['YOUTUBE_API_KEY'] },
      { name: 'Snapchat Marketing API', desc: 'Ad campaigns & audience management on Snapchat', docs: 'https://marketingapi.snapchat.com/docs', status: 'available', fields: ['SNAPCHAT_CLIENT_ID', 'SNAPCHAT_CLIENT_SECRET'] },
      { name: 'Buffer', desc: 'Schedule & publish posts across all social channels', docs: 'https://buffer.com/developers/api', status: 'available', fields: ['BUFFER_ACCESS_TOKEN'] },
      { name: 'Hootsuite', desc: 'Social media management & scheduling platform', docs: 'https://platform.hootsuite.com/docs', status: 'available', fields: ['HOOTSUITE_CLIENT_ID', 'HOOTSUITE_CLIENT_SECRET'] },
    ]
  },
];

function ApiCard({ api, connections, onRefreshConnections }) {
  const [expanded, setExpanded] = useState(false);
  const [values, setValues] = useState({});
  const [connecting, setConnecting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [storedKeys, setStoredKeys] = useState([]);
  const [showValues, setShowValues] = useState({});
  const [checkingSession, setCheckingSession] = useState(false);
  const [twilioIdentity, setTwilioIdentity] = useState(null);
  const [verifying, setVerifying] = useState(false);
  const [confirmDisconnect, setConfirmDisconnect] = useState(false);

  const isOAuth = OAUTH_APIS[api.name];
  const ssoType = SSO_INTEGRATIONS[api.name];
  const isSSO = !!ssoType;
  const isTwilio = api.fields.includes('TWILIO_ACCOUNT_SID');
  const connection = isSSO ? (connections?.[ssoType] || null) : null;
  const isConnected = !!(connection?.is_active && (connection.identity_name || connection.identity_email));

  // Load which keys are already stored
  useEffect(() => {
    if (isOAuth || isSSO || api.fields.length === 0) return;
    let mounted = true;
    base44.functions.invoke('userCredentials', { action: 'list' })
      .then((res) => {
        if (!mounted) return;
        const stored = (res.data?.keys || []).filter(k => api.fields.includes(k));
        setStoredKeys(stored);
      })
      .catch(() => {});
    return () => { mounted = false; };
  }, [api.name, isOAuth, isSSO]);

  const allKeysStored = api.fields.length > 0 && api.fields.every(f => storedKeys.includes(f));
  const someKeysStored = storedKeys.length > 0;

  const handleOAuthConnect = async () => {
    setConnecting(true);
    try {
      const integrationType = OAUTH_APIS[api.name];
      
      // Use the oauthAuthorize backend function for all OAuth connections
      const res = await base44.functions.invoke('oauthAuthorize', { 
        integration_type: integrationType,
        service_name: api.name
      });
      
      if (res.data?.authorization_url) {
        const popup = window.open(res.data.authorization_url, '_blank', 'width=600,height=700');
        const timer = setInterval(() => {
          if (!popup || popup.closed) {
            clearInterval(timer);
            toast.success(`${api.name} connection completed`);
            setConnecting(false);
            // Refresh the page to show updated connection status
            setTimeout(() => window.location.reload(), 1000);
          }
        }, 1000);
      } else if (res.data?.error) {
        toast.error(res.data.error);
        setConnecting(false);
      } else {
        toast.error('Failed to get authorization URL');
        setConnecting(false);
      }
    } catch (err) {
      toast.error(`Connection failed: ${err.message}`);
      setConnecting(false);
    }
  };

  // Silent-session-detect connect flow: show a brief "Checking session..." micro-state,
  // then open the OAuth popup. If the user is already logged into the platform and has
  // previously authorized the app, the popup auto-completes without a login screen.
  const handleSSOConnect = async () => {
    setCheckingSession(true);
    // Brief micro-state (<2s) so the silent attempt feels invisible unless a popup opens
    await new Promise((r) => setTimeout(r, 1400));
    try {
      const res = await base44.functions.invoke('oauthAuthorize', {
        integration_type: ssoType,
        silent: true,
      });
      const data = res.data || {};
      if (data.setup_required) {
        toast.error(data.message || `${api.name} is not configured yet. Ask your admin to add OAuth credentials.`);
        setCheckingSession(false);
        return;
      }
      if (data.connected) {
        // Server-to-server (Zoom) connected instantly — no popup
        toast.success(`${api.name} connected successfully`);
        onRefreshConnections?.();
        setCheckingSession(false);
        return;
      }
      if (data.error) {
        toast.error(data.error);
        setCheckingSession(false);
        return;
      }
      if (!data.authorization_url) {
        toast.error('Failed to start connection');
        setCheckingSession(false);
        return;
      }
      // Open the OAuth popup — the callback redirects it to /api-center?oauth_done=1
      // which posts a message back to this window and self-closes.
      window.open(data.authorization_url, '_blank', 'width=600,height=700');
      // The page-level message listener calls onRefreshConnections() when the popup
      // reports completion. Clear the micro-state once we start the popup.
      setCheckingSession(false);
      setConnecting(true);
    } catch (err) {
      toast.error(`Connection failed: ${err.message}`);
      setCheckingSession(false);
    }
  };

  const handleDisconnect = async () => {
    setConfirmDisconnect(false);
    setConnecting(true);
    try {
      await base44.functions.invoke('disconnectOAuth', { provider: ssoType });
      toast.success(`${api.name} disconnected`);
      onRefreshConnections?.();
    } catch (err) {
      toast.error(`Disconnect failed: ${err.message}`);
    } finally {
      setConnecting(false);
    }
  };

  const handleTwilioVerify = async () => {
    setVerifying(true);
    try {
      const res = await base44.functions.invoke('getTwilioConfig', { action: 'verifyCredentials' });
      const data = res.data || {};
      if (data.valid) {
        setTwilioIdentity({ name: data.friendly_name, sid: data.sid });
        toast.success(`Twilio verified — ${data.friendly_name}`);
      } else {
        toast.error(data.message || 'Twilio credentials are invalid');
        setTwilioIdentity(null);
      }
    } catch (err) {
      toast.error(`Verification failed: ${err.message}`);
    } finally {
      setVerifying(false);
    }
  };

  const handleSaveKeys = async () => {
    const filled = api.fields.filter(f => values[f]?.trim());
    if (filled.length === 0) {
      toast.error('Please enter at least one credential');
      return;
    }
    setSaving(true);
    try {
      for (const field of filled) {
        await base44.functions.invoke('userCredentials', {
          action: 'store',
          key: field,
          value: values[field].trim(),
        });
      }
      toast.success(`${api.name} credentials saved securely`);
      setStoredKeys(prev => [...new Set([...prev, ...filled])]);
      setValues({});
      setShowValues({});
      setExpanded(false);
    } catch (err) {
      toast.error(`Failed to save: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteKey = async (field) => {
    setSaving(true);
    try {
      await base44.functions.invoke('userCredentials', { action: 'delete', key: field });
      toast.success(`${field} removed`);
      setStoredKeys(prev => prev.filter(k => k !== field));
    } catch (err) {
      toast.error(`Failed to delete: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={`bg-card border rounded-xl overflow-hidden transition-all hover:border-primary/30 ${api.status === 'configured' ? 'border-emerald-500/40' : 'border-border'}`}>
      <div className="flex items-start justify-between p-4 gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <p className="font-semibold text-sm">{api.name}</p>
            {api.status === 'configured' && !isSSO && (
              <Badge className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" />Active
              </Badge>
            )}
            {isSSO && isConnected && (
              <Badge className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" />Connected
              </Badge>
            )}
            {isSSO && !isConnected && (
              <Badge className="text-[10px] px-1.5 py-0 bg-fuchsia-500/10 text-fuchsia-400 border border-fuchsia-500/20">
                SSO
              </Badge>
            )}
            {isOAuth && api.status !== 'configured' && (
              <Badge className="text-[10px] px-1.5 py-0 bg-blue-500/10 text-blue-400 border border-blue-500/20">
                OAuth
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">{api.desc}</p>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <a href={api.docs} target="_blank" rel="noopener noreferrer">
            <Button variant="ghost" size="icon" className="h-7 w-7">
              <ExternalLink className="w-3.5 h-3.5" />
            </Button>
          </a>
          {!isOAuth && !isSSO && api.fields.length > 0 && (
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setExpanded(!expanded)}>
              {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </Button>
          )}
        </div>
      </div>

      {/* Action Row */}
      <div className="px-4 pb-4">
        {/* SSO-connected identity row (replaces Connect button) */}
        {isSSO && isConnected ? (
          confirmDisconnect ? (
            <div className="flex items-center justify-between gap-2 bg-red-500/5 border border-red-500/20 rounded-lg px-2.5 py-2">
              <span className="text-xs text-muted-foreground">Disconnect {api.name.split(' ')[0]}?</span>
              <div className="flex items-center gap-1.5">
                <Button size="sm" variant="destructive" className="h-7 text-xs px-2.5" onClick={handleDisconnect} disabled={connecting}>
                  {connecting ? <span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full" /> : <X className="w-3 h-3" />}
                  Yes, Disconnect
                </Button>
                <Button size="sm" variant="ghost" className="h-7 text-xs px-2.5" onClick={() => setConfirmDisconnect(false)} disabled={connecting}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg px-2.5 py-2">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-6 h-6 rounded-full bg-emerald-500/15 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-emerald-500 truncate">
                    Connected as {connection.identity_name || 'Authenticated Account'}
                  </p>
                  {connection.identity_email && (
                    <p className="text-[10px] text-muted-foreground truncate">{connection.identity_email}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setConfirmDisconnect(true)}
                disabled={connecting}
                className="text-[11px] text-red-400/80 hover:text-red-400 transition-colors shrink-0 disabled:opacity-50"
                title={`Disconnect ${api.name}`}
              >
                {connecting ? 'Disconnecting…' : 'Disconnect'}
              </button>
            </div>
          )
        ) : isSSO ? (
          checkingSession ? (
            <div className="flex items-center justify-center gap-2 h-8 text-xs text-muted-foreground">
              <span className="animate-spin w-3 h-3 border-2 border-primary border-t-transparent rounded-full" />
              Checking session…
            </div>
          ) : (
            <Button
              size="sm"
              className="w-full h-8 text-xs gap-2"
              onClick={handleSSOConnect}
              disabled={connecting}
            >
              {connecting ? (
                <span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <Link2 className="w-3.5 h-3.5" />
              )}
              Connect with {api.name.split(' ')[0]}
              <ArrowRight className="w-3 h-3 ml-auto" />
            </Button>
          )
        ) : !isOAuth && api.fields.length > 0 && (someKeysStored || api.status === 'configured') ? (
          <div className="flex items-center gap-2 flex-wrap">
            <Badge className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30">
              <CheckCircle2 className="w-2.5 h-2.5 mr-1" />{storedKeys.length}/{api.fields.length} Keys Set
            </Badge>
            {twilioIdentity && (
              <Badge className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-500 border border-emerald-500/30">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" />{twilioIdentity.name}
              </Badge>
            )}
            <Button variant="outline" size="sm" className="h-7 text-xs gap-1.5" onClick={() => setExpanded(!expanded)}>
              <Key className="w-3.5 h-3.5" />{someKeysStored ? 'Manage Keys' : 'Edit Keys'}
              {expanded ? <ChevronDown className="w-3 h-3 ml-auto" /> : <ChevronRight className="w-3 h-3 ml-auto" />}
            </Button>
            {isTwilio && (
              <Button
                variant="outline"
                size="sm"
                className="h-7 text-xs gap-1.5 border-emerald-500/30 text-emerald-500 hover:bg-emerald-500/10"
                onClick={handleTwilioVerify}
                disabled={verifying || !someKeysStored}
              >
                {verifying ? (
                  <span className="animate-spin w-3 h-3 border-2 border-emerald-500 border-t-transparent rounded-full" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5" />
                )}
                {verifying ? 'Verifying…' : 'Verify Credentials'}
              </Button>
            )}
          </div>
        ) : api.status === 'configured' ? (
          <div className="flex items-center gap-2 text-xs text-emerald-500">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Connected & Active</span>
          </div>
        ) : isOAuth ? (
          <Button
            size="sm"
            className="w-full h-8 text-xs gap-2"
            onClick={handleOAuthConnect}
            disabled={connecting}
          >
            {connecting ? (
              <span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full" />
            ) : (
              <Link2 className="w-3.5 h-3.5" />
            )}
            Connect with {api.name.split(' ')[0]}
            <ArrowRight className="w-3 h-3 ml-auto" />
          </Button>
        ) : api.fields.length > 0 ? (
          <Button
            size="sm"
            variant="outline"
            className="w-full h-8 text-xs gap-2"
            onClick={() => setExpanded(!expanded)}
          >
            <Key className="w-3.5 h-3.5" />
            Add API Keys
            {expanded ? <ChevronDown className="w-3 h-3 ml-auto" /> : <ChevronRight className="w-3 h-3 ml-auto" />}
          </Button>
        ) : null}
      </div>

      {/* Expandable Key Entry */}
      {expanded && !isOAuth && !isSSO && api.fields.length > 0 && (
        <div className="border-t border-border px-4 pb-4 pt-3 bg-muted/20">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2 flex items-center gap-1.5">
            <Lock className="w-3 h-3" />API Credentials
          </p>
          <div className="space-y-2">
            {api.fields.map(field => {
              const isStored = storedKeys.includes(field);
              return (
                <div key={field}>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[10px] text-muted-foreground font-mono">{field}</label>
                    {isStored && (
                      <div className="flex items-center gap-1.5">
                        <Badge className="text-[9px] px-1 py-0 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                          <CheckCircle2 className="w-2 h-2 mr-0.5" />Stored
                        </Badge>
                        <button
                          onClick={() => handleDeleteKey(field)}
                          disabled={saving}
                          className="text-muted-foreground hover:text-red-500 transition-colors"
                          title="Remove key"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                  <div className="relative">
                    <Input
                      type={showValues[field] ? 'text' : 'password'}
                      placeholder={isStored ? '•••••••• (enter new to update)' : `Enter ${field}...`}
                      className="h-7 text-xs font-mono pr-7"
                      value={values[field] || ''}
                      onChange={e => setValues(v => ({ ...v, [field]: e.target.value }))}
                    />
                    {isStored && (
                      <button
                        type="button"
                        onClick={() => setShowValues(s => ({ ...s, [field]: !s[field] }))}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                        title={showValues[field] ? 'Hide' : 'Show'}
                      >
                        {showValues[field] ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex gap-2 mt-3">
            <Button size="sm" className="h-7 text-xs flex-1 gap-1.5" onClick={handleSaveKeys} disabled={saving}>
              {saving ? (
                <span className="animate-spin w-3 h-3 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <CheckCircle2 className="w-3.5 h-3.5" />
              )}
              {someKeysStored ? 'Update Credentials' : 'Save & Configure'}
            </Button>
            <a href={api.docs} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="h-7 text-xs gap-1">
                <Code2 className="w-3 h-3" />Docs
              </Button>
            </a>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2">
            🔒 Credentials are stored securely and encrypted. Enter new values to update existing keys.
          </p>
        </div>
      )}
    </div>
  );
}

// Build the full connection list from all API_CATEGORIES
function buildConnectionList() {
  const list = [];
  API_CATEGORIES.forEach(cat => {
    cat.apis.forEach(api => {
      list.push({
        name: api.name,
        category: cat.label,
        categoryId: cat.id,
        color: cat.color,
        bg: cat.bg,
        connected: api.status === 'configured',
        isOAuth: !!OAUTH_APIS[api.name],
        authType: OAUTH_APIS[api.name] ? 'OAuth' : api.fields.length > 0 ? 'API Key' : 'OAuth',
        fields: api.fields,
        docs: api.docs,
        desc: api.desc,
        icon: cat.icon,
      });
    });
  });
  return list;
}

function ConnectionDetailModal({ item, onClose }) {
  if (!item) return null;
  const Icon = item.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl z-10">
        {/* Header */}
        <div className={`flex items-start justify-between p-5 border-b border-border`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${item.bg}`}>
              <Icon className={`w-5 h-5 ${item.color}`} />
            </div>
            <div>
              <h3 className="font-bold text-sm">{item.name}</h3>
              <p className="text-[10px] text-muted-foreground">{item.category}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {item.connected ? (
              <Badge className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <CheckCircle2 className="w-2.5 h-2.5 mr-1" /> Active
              </Badge>
            ) : (
              <Badge className="text-[10px] px-2 py-0.5 bg-muted text-muted-foreground border border-border">
                <WifiOff className="w-2.5 h-2.5 mr-1" /> Not Connected
              </Badge>
            )}
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* Description */}
          <div className="flex gap-2 items-start">
            <Info className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
            <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
          </div>

          {/* Connection Details */}
          <div className="bg-muted/30 border border-border rounded-xl p-4 space-y-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
              <Activity className="w-3 h-3" /> Connection Details
            </p>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <p className="text-muted-foreground mb-0.5">Auth Type</p>
                <div className="flex items-center gap-1">
                  {item.isOAuth ? (
                    <Badge className="text-[10px] px-1.5 py-0 bg-blue-500/10 text-blue-400 border border-blue-500/20">OAuth 2.0</Badge>
                  ) : (
                    <Badge className="text-[10px] px-1.5 py-0 bg-amber-500/10 text-amber-400 border border-amber-500/20">API Key</Badge>
                  )}
                </div>
              </div>
              <div>
                <p className="text-muted-foreground mb-0.5">Status</p>
                <p className={`font-semibold ${item.connected ? 'text-emerald-400' : 'text-muted-foreground'}`}>
                  {item.connected ? '● Live & Active' : '○ Not Connected'}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground mb-0.5">Category</p>
                <p className={`font-medium ${item.color}`}>{item.category}</p>
              </div>
              <div>
                <p className="text-muted-foreground mb-0.5">Integration</p>
                <p className="font-medium">{item.isOAuth ? 'One-Click' : 'Manual Setup'}</p>
              </div>
            </div>
          </div>

          {/* Required Credentials */}
          {item.fields.length > 0 && (
            <div className="bg-muted/20 border border-border rounded-xl p-4 space-y-2">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold flex items-center gap-1.5">
                <Key className="w-3 h-3" /> Required Secrets
              </p>
              <div className="flex flex-wrap gap-1.5">
                {item.fields.map(field => (
                  <code key={field} className="text-[10px] bg-muted px-2 py-1 rounded-md text-amber-400 font-mono border border-border">
                    {field}
                  </code>
                ))}
              </div>
              <p className="text-[10px] text-muted-foreground">
                Add these as Secrets in Dashboard → Settings → Secrets
              </p>
            </div>
          )}

          {/* Setup Instructions */}
          {item.connected && (
            <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4">
              <p className="text-xs text-emerald-400 font-semibold mb-1 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Connection Active
              </p>
              <p className="text-xs text-muted-foreground">
                This integration is live and accessible from your backend functions via <code className="bg-muted px-1 rounded text-emerald-400">Deno.env.get("...")</code>
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex gap-2 px-5 pb-5">
          <a href={item.docs} target="_blank" rel="noopener noreferrer" className="flex-1">
            <Button variant="outline" size="sm" className="w-full h-8 text-xs gap-2">
              <ExternalLink className="w-3.5 h-3.5" /> View Documentation
            </Button>
          </a>
          {!item.connected && (
            <Button size="sm" className="flex-1 h-8 text-xs gap-2" onClick={onClose}>
              <Settings className="w-3.5 h-3.5" />
              {item.isOAuth ? 'Connect via OAuth' : 'Add API Keys'}
              <ArrowRight className="w-3 h-3 ml-auto" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function ConnectionDashboard() {
  const [selectedItem, setSelectedItem] = useState(null);
  const [filterConnected, setFilterConnected] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const allConnections = buildConnectionList();
  const connected = allConnections.filter(c => c.connected);
  const disconnected = allConnections.filter(c => !c.connected);

  const filtered = allConnections.filter(c => {
    const matchesFilter = filterConnected === 'all' || (filterConnected === 'active' ? c.connected : !c.connected);
    const matchesSearch = !searchTerm || c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const filteredConnected = filtered.filter(c => c.connected);
  const filteredDisconnected = filtered.filter(c => !c.connected);

  return (
    <>
      {selectedItem && <ConnectionDetailModal item={selectedItem} onClose={() => setSelectedItem(null)} />}

      <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Wifi className="w-4 h-4 text-primary" />
            <h2 className="font-bold text-sm">Connection Dashboard</h2>
            <Badge className="text-[10px] px-1.5 py-0 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              {connected.length} Live
            </Badge>
            <Badge className="text-[10px] px-1.5 py-0 bg-muted text-muted-foreground border border-border">
              {disconnected.length} Available
            </Badge>
            <Badge className="text-[10px] px-1.5 py-0 bg-primary/10 text-primary border border-primary/20">
              {allConnections.length} Total
            </Badge>
          </div>
          <p className="text-[10px] text-muted-foreground hidden sm:block">Click any integration to view details</p>
        </div>

        {/* Filter + Search */}
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[160px]">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-muted-foreground" />
            <Input
              className="h-7 pl-7 text-xs"
              placeholder="Search connections..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-1">
            {[['all', 'All'], ['active', 'Active'], ['inactive', 'Not Connected']].map(([val, label]) => (
              <Button
                key={val}
                size="sm"
                variant={filterConnected === val ? 'default' : 'outline'}
                className="h-7 text-xs px-2.5"
                onClick={() => setFilterConnected(val)}
              >
                {label}
              </Button>
            ))}
          </div>
        </div>

        {/* Connected */}
        {filteredConnected.length > 0 && (
          <div>
            <p className="text-[10px] uppercase tracking-wider text-emerald-500 font-semibold mb-2">● Active Connections ({filteredConnected.length})</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
              {filteredConnected.map(item => (
                <button
                  key={item.name}
                  onClick={() => setSelectedItem(item)}
                  className="flex items-center gap-2 bg-emerald-500/5 border border-emerald-500/20 rounded-lg px-2.5 py-2 hover:bg-emerald-500/10 hover:border-emerald-500/40 transition-all cursor-pointer text-left group"
                >
                  <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold truncate group-hover:text-emerald-400 transition-colors">{item.name}</p>
                    <p className="text-[10px] text-muted-foreground truncate">{item.category}</p>
                  </div>
                  <ChevronRight className="w-2.5 h-2.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Not Connected */}
        {filteredDisconnected.length > 0 && (
          <div>
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-2">○ Not Connected ({filteredDisconnected.length})</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2">
              {filteredDisconnected.map(item => (
                <button
                  key={item.name}
                  onClick={() => setSelectedItem(item)}
                  className="flex items-center gap-2 bg-muted/20 border border-border rounded-lg px-2.5 py-2 hover:bg-muted/40 hover:border-primary/30 transition-all cursor-pointer text-left group"
                >
                  <WifiOff className="w-3 h-3 text-muted-foreground shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate text-muted-foreground group-hover:text-foreground transition-colors">{item.name}</p>
                    <p className="text-[10px] text-muted-foreground/60 truncate">{item.category}</p>
                  </div>
                  <ChevronRight className="w-2.5 h-2.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {filtered.length === 0 && (
          <div className="text-center py-8 text-muted-foreground text-sm">
            <WifiOff className="w-6 h-6 mx-auto mb-2 opacity-40" />
            No connections match your search
          </div>
        )}
      </div>
    </>
  );
}

export default function ApiCenter() {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [connections, setConnections] = useState({});

  // Fetch the user's connected OAuth/SSO integrations and index by provider.
  const refreshConnections = useCallback(async () => {
    try {
      const res = await base44.functions.invoke('getOAuthConnections', {});
      const map = {};
      (res.data?.connections || []).forEach((c) => { map[c.provider] = c; });
      setConnections(map);
    } catch (_) { /* ignore — cards fall back to unconnected state */ }
  }, []);

  useEffect(() => {
    refreshConnections();
    // When an OAuth popup completes, it redirects to /api-center?oauth_done=1 and
    // posts a message back to this (opener) window — refresh connection state on receipt.
    const handler = (e) => {
      if (e.data?.type === 'oauth_connected') {
        refreshConnections();
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [refreshConnections]);

  // If this page is loaded inside an OAuth popup (redirected here by the callback),
  // notify the opener window and self-close.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('oauth_done') === '1' && window.opener) {
      window.opener.postMessage(
        { type: 'oauth_connected', provider: params.get('provider') || '' },
        window.location.origin
      );
      window.close();
    }
  }, []);

  const filteredCategories = API_CATEGORIES.map(cat => ({
    ...cat,
    apis: cat.apis.filter(api =>
      api.name.toLowerCase().includes(search.toLowerCase()) ||
      api.desc.toLowerCase().includes(search.toLowerCase())
    )
  })).filter(cat =>
    (activeCategory === 'all' || cat.id === activeCategory) && cat.apis.length > 0
  );

  const totalApis = API_CATEGORIES.reduce((sum, cat) => sum + cat.apis.length, 0);
  const configuredApis = API_CATEGORIES.flatMap(c => c.apis).filter(a => a.status === 'configured').length;
  const oauthCount = Object.keys(OAUTH_APIS).length;

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-cyan-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Plug className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">API Integration Center</h1>
              <p className="text-muted-foreground text-xs">One-click OAuth or API key connections for every tool</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Layers className="w-3.5 h-3.5" />{totalApis} APIs
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Link2 className="w-3.5 h-3.5" />{oauthCount} One-Click OAuth
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />{configuredApis} Active
            </div>
          </div>
        </div>
      </div>

      {/* Connection Dashboard */}
      <ConnectionDashboard />

      {/* How it works */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 flex gap-3 items-start">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center shrink-0">
            <Link2 className="w-4 h-4 text-blue-400" />
          </div>
          <div>
            <p className="text-sm font-semibold">OAuth Integrations</p>
            <p className="text-xs text-muted-foreground mt-0.5">Click "Connect" to authorize with your personal account. Secure one-click setup.</p>
          </div>
        </div>
        <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 flex gap-3 items-start">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0">
            <Key className="w-4 h-4 text-amber-400" />
          </div>
          <div>
            <p className="text-sm font-semibold">API Key Integrations</p>
            <p className="text-xs text-muted-foreground mt-0.5">Add your API credentials as Secrets in Dashboard → Settings → Secrets.</p>
          </div>
        </div>
        <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-4 flex gap-3 items-start">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-semibold">Active Connections</p>
            <p className="text-xs text-muted-foreground mt-0.5">Green badges mean the integration is live and ready to use.</p>
          </div>
        </div>
      </div>

      {/* Google OAuth Setup Info */}
      <Card className="border-blue-500/30 bg-gradient-to-br from-blue-500/5 to-indigo-500/5">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Globe className="w-4 h-4 text-blue-500" />
            Google OAuth Setup (All Google Services)
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-xs">
          <p className="text-muted-foreground">
            To enable OAuth for Google services (Calendar, Drive, Gmail, Sheets, etc.), you need to set up OAuth credentials in your Google Cloud Console:
          </p>
          <ol className="space-y-2 text-muted-foreground list-decimal list-inside">
            <li>Go to <a href="https://console.cloud.google.com" target="_blank" className="text-blue-400 hover:underline">Google Cloud Console</a></li>
            <li>Create a new project or select existing</li>
            <li>Enable APIs you need (Calendar, Drive, Gmail, Sheets, etc.)</li>
            <li>Go to "Credentials" → "Create Credentials" → "OAuth client ID"</li>
            <li>Choose "Web application" as application type</li>
            <li>Add authorized redirect URIs: <code className="bg-muted px-1 rounded">{window.location.origin}/oauth/callback</code></li>
            <li>Copy Client ID and Client Secret</li>
            <li>Add as Secrets: <code className="bg-muted px-1 rounded">GOOGLE_OAUTH_CLIENT_ID</code> and <code className="bg-muted px-1 rounded">GOOGLE_OAUTH_CLIENT_SECRET</code></li>
          </ol>
          <p className="text-muted-foreground mt-3">
            Once configured, users can connect their personal Google accounts with one click from this page.
          </p>
        </CardContent>
      </Card>

      {/* Search + Filter */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            className="pl-9 h-9"
            placeholder="Search APIs (Twilio, Stripe, Zoom...)"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <Button
            variant={activeCategory === 'all' ? 'default' : 'outline'}
            size="sm" className="h-8 text-xs shrink-0"
            onClick={() => setActiveCategory('all')}
          >All</Button>
          {API_CATEGORIES.map(cat => (
            <Button
              key={cat.id}
              variant={activeCategory === cat.id ? 'default' : 'outline'}
              size="sm" className="h-8 text-xs shrink-0 gap-1"
              onClick={() => setActiveCategory(activeCategory === cat.id ? 'all' : cat.id)}
            >
              <cat.icon className="w-3 h-3" />
              <span className="hidden sm:inline">{cat.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* API Categories */}
      {filteredCategories.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Search className="w-8 h-8 mx-auto mb-3 opacity-40" />
          <p>No APIs found for "{search}"</p>
        </div>
      ) : (
        filteredCategories.map(cat => (
          <div key={cat.id}>
            <div className={`flex items-center gap-2 mb-3 p-3 rounded-xl border ${cat.bg}`}>
              <cat.icon className={`w-5 h-5 ${cat.color}`} />
              <h2 className="font-bold text-sm">{cat.label}</h2>
              <Badge variant="outline" className="ml-auto text-[10px]">{cat.apis.length} integrations</Badge>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
              {cat.apis.map(api => (
                <ApiCard
                  key={api.name}
                  api={api}
                  connections={connections}
                  onRefreshConnections={refreshConnections}
                />
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
}