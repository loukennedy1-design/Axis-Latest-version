import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Cpu, Loader2, RefreshCw, AlertTriangle, CheckCircle2, Zap } from 'lucide-react';

export default function OmniCoreOptimization() {
  const [report, setReport] = useState(null);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);

  const fetchScan = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('omnicoreOptimizationEngine', { action: 'health_scan' });
      setReport(res.data?.optimization_report);
      setIssues(res.data?.issues || []);
    } catch { setReport(null); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchScan(); }, []);

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Cpu className="w-6 h-6 text-primary" />
            OmniCore AI X — Platform Optimization
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            An autonomous optimization engine that self-monitors platform health, detects degraded performance, identifies unused modules and inefficient workflows, and performs non-destructive optimizations with weekly reports.
          </p>
        </div>
        <Button onClick={fetchScan} disabled={scanning} variant="outline">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />} Run Health Scan
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-primary" /></div>
      ) : report ? (
        <>
          {/* Platform health summary */}
          <Card className="border-primary/40">
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Cpu className="w-4 h-4 text-primary" /> Platform Health</CardTitle></CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed">{report.platform_health}</p>
              <div className="mt-3 rounded-lg border-l-2 border-primary bg-primary/5 p-3">
                <p className="text-sm"><span className="text-primary font-medium">Executive Summary:</span> {report.summary}</p>
              </div>
            </CardContent>
          </Card>

          {/* Detected issues */}
          <div>
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3">Detected Issues ({issues.length})</h2>
            {issues.length ? (
              <div className="space-y-2">
                {issues.map((iss, i) => {
                  const sevColor = iss.severity === 'high' ? 'border-red-500/40 bg-red-500/10' : iss.severity === 'medium' ? 'border-amber-500/40 bg-amber-500/10' : 'border-border bg-card/30';
                  return (
                    <div key={i} className={`rounded-lg border p-3 ${sevColor}`}>
                      <div className="flex items-center gap-2 mb-1">
                        <AlertTriangle className={`w-4 h-4 ${iss.severity === 'high' ? 'text-red-400' : iss.severity === 'medium' ? 'text-amber-400' : 'text-muted-foreground'}`} />
                        <span className="text-xs uppercase text-muted-foreground">{iss.severity}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-muted">{iss.area}</span>
                      </div>
                      <p className="text-sm font-medium">{iss.issue}</p>
                      <p className="text-xs text-muted-foreground mt-1">→ {iss.recommendation}</p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <Card><CardContent className="py-8 text-center"><CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" /><p className="text-sm text-muted-foreground">No issues detected — platform is healthy.</p></CardContent></Card>
            )}
          </div>

          {/* Optimization opportunities */}
          {report.optimization_opportunities?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base flex items-center gap-2"><Zap className="w-4 h-4 text-primary" /> Optimization Opportunities</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {report.optimization_opportunities.map((opp, i) => (
                    <div key={i} className="rounded-lg border border-border bg-card/30 p-3">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs px-2 py-0.5 rounded bg-primary/20 text-primary">{opp.area}</span>
                        {opp.safe_to_auto_apply && <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> safe to auto-apply</span>}
                      </div>
                      <p className="text-sm font-medium mt-1">{opp.action}</p>
                      {opp.expected_benefit && <p className="text-xs text-muted-foreground mt-1">{opp.expected_benefit}</p>}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Performance concerns */}
          {report.performance_concerns?.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Performance Concerns</CardTitle></CardHeader>
              <CardContent>
                <ul className="space-y-1">{report.performance_concerns.map((c, i) => <li key={i} className="text-sm text-muted-foreground flex gap-2"><span className="text-primary/40">•</span>{c}</li>)}</ul>
              </CardContent>
            </Card>
          )}
        </>
      ) : (
        <Card><CardContent className="py-12 text-center"><Cpu className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No scan run yet. Click "Run Health Scan" to assess platform health.</p></CardContent></Card>
      )}
    </div>
  );
}