import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { FlaskConical, Loader2, Play, History, TrendingUp, AlertTriangle, CheckCircle2 } from 'lucide-react';

const EXAMPLES = [
  'Hire 5 employees',
  'Increase marketing budget 20%',
  'Raise pricing by 10%',
  'Open another location',
  'Expand product line',
  'Reduce payroll by 15%',
  'Launch a new campaign'
];

export default function DecisionSimulator() {
  const [scenario, setScenario] = useState('');
  const [result, setResult] = useState(null);
  const [simulating, setSimulating] = useState(false);
  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  const fetchHistory = async () => {
    setLoadingHistory(true);
    try {
      const res = await base44.functions.invoke('decisionSimulator', { action: 'get_history' });
      setHistory(res.data?.simulations || []);
    } catch { setHistory([]); }
    finally { setLoadingHistory(false); }
  };

  useEffect(() => { fetchHistory(); }, []);

  const handleSimulate = async (s) => {
    const sc = s || scenario;
    if (!sc.trim()) return;
    setSimulating(true);
    setResult(null);
    try {
      const res = await base44.functions.invoke('decisionSimulator', { action: 'simulate', scenario: sc });
      setResult(res.data);
      await fetchHistory();
    } catch (e) {
      setResult({ error: e.message });
    } finally {
      setSimulating(false);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
          <FlaskConical className="w-6 h-6 text-primary" />
          Decision Simulator
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          Ask "What happens if..." and Trinity predicts the impact across revenue, cash flow, profit, ROI, operations, hiring, inventory, and risk — with confidence scoring and recommendations.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Play className="w-4 h-4 text-primary" /> Run a Simulation</CardTitle>
          <CardDescription>Describe a business decision you're considering</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={scenario}
              onChange={(e) => setScenario(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSimulate()}
              placeholder="What happens if I hire 5 new sales reps?"
              className="flex-1"
            />
            <Button onClick={() => handleSimulate()} disabled={simulating || !scenario.trim()}>
              {simulating ? <Loader2 className="w-4 h-4 animate-spin" /> : <FlaskConical className="w-4 h-4" />}
              Simulate
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            {EXAMPLES.map(ex => (
              <button key={ex} onClick={() => { setScenario(ex); handleSimulate(ex); }} disabled={simulating}
                className="text-xs px-2.5 py-1 rounded-full border border-border bg-card/50 hover:bg-accent hover:text-accent-foreground transition-colors">
                {ex}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {result?.error && <p className="text-sm text-destructive">{result.error}</p>}

      {result?.prediction && (
        <div className="space-y-4">
          {/* Core predictions */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <PredCard label="Revenue" value={`$${(result.prediction.revenue || 0).toLocaleString()}`} />
            <PredCard label="Cash Flow" value={`$${(result.prediction.cash_flow || 0).toLocaleString()}`} />
            <PredCard label="Profit" value={`$${(result.prediction.profit || 0).toLocaleString()}`} />
            <PredCard label="ROI" value={`${result.prediction.roi || 0}%`} />
          </div>

          {/* Risk + Confidence */}
          <div className="grid md:grid-cols-2 gap-4">
            <ScoreCard label="Risk Score" value={result.prediction.risk_score || 0} icon={AlertTriangle} invert />
            <ScoreCard label="Confidence" value={result.prediction.confidence_score || 0} icon={CheckCircle2} />
          </div>

          {/* Operational impact */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4 text-primary" /> Operational Impact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm leading-relaxed">{result.prediction.operational_impact}</p>
              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-border">
                <div>
                  <p className="text-xs text-muted-foreground">Hiring Needs</p>
                  <p className="text-lg font-bold">{result.prediction.hiring_needs || 0} new hires</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Inventory Requirements</p>
                  <p className="text-sm">{result.prediction.inventory_requirements || 'No change'}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Recommended Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2">
                {(result.prediction.recommendations || []).map((r, i) => (
                  <li key={i} className="flex gap-3 text-sm">
                    <span className="flex-shrink-0 w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center font-bold">{i + 1}</span>
                    <span className="leading-relaxed">{r}</span>
                  </li>
                ))}
              </ol>
              {result.prediction.assumptions?.length > 0 && (
                <div className="mt-4 pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-2">Key Assumptions</p>
                  <ul className="space-y-1">
                    {result.prediction.assumptions.map((a, i) => (
                      <li key={i} className="text-xs text-muted-foreground flex gap-2"><span className="text-primary/40">•</span>{a}</li>
                    ))}
                  </ul>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* History */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><History className="w-4 h-4 text-primary" /> Simulation History</CardTitle>
        </CardHeader>
        <CardContent>
          {loadingHistory ? (
            <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
          ) : history.length ? (
            <div className="space-y-2">
              {history.map(h => {
                let pred = {}; let recs = [];
                try { pred = JSON.parse(h.prediction_data || '{}'); } catch { /* ignore */ }
                try { recs = JSON.parse(h.recommendations || '[]'); } catch { /* ignore */ }
                return (
                  <div key={h.id} className="rounded-lg border border-border bg-card/30 px-3 py-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium truncate flex-1">{h.scenario}</p>
                      <span className="text-xs text-muted-foreground">{new Date(h.created_date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex gap-4 mt-1 text-xs text-muted-foreground">
                      <span>ROI: {pred.roi ?? '—'}%</span>
                      <span>Risk: {pred.risk_score ?? '—'}/100</span>
                      <span>Confidence: {pred.confidence_score ?? '—'}%</span>
                      <span>{recs.length} recommendations</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-3">No simulations yet.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PredCard({ label, value }) {
  return (
    <Card>
      <CardContent className="pt-5">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-xl font-bold font-poppins mt-1">{value}</p>
      </CardContent>
    </Card>
  );
}

function ScoreCard({ label, value, icon: Icon, invert }) {
  const pct = Math.min(100, Math.max(0, value || 0));
  const color = invert
    ? pct < 30 ? 'text-emerald-400' : pct < 70 ? 'text-amber-400' : 'text-red-400'
    : pct < 30 ? 'text-red-400' : pct < 70 ? 'text-amber-400' : 'text-emerald-400';
  return (
    <Card>
      <CardContent className="pt-5">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm text-muted-foreground flex items-center gap-1.5"><Icon className={`w-4 h-4 ${color}`} /> {label}</p>
          <span className={`text-2xl font-bold font-poppins ${color}`}>{pct}/100</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className={`h-full ${color.replace('text-', 'bg-')}`} style={{ width: `${pct}%` }} />
        </div>
      </CardContent>
    </Card>
  );
}