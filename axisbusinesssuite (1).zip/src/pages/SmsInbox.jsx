import React, { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { MessageSquare, Send, Plus, Search, CheckCircle2, XCircle, Clock, Loader2, Settings } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';

export default function SmsInbox() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [composeOpen, setComposeOpen] = useState(false);
  const [selectedThread, setSelectedThread] = useState(null);
  const [replyBody, setReplyBody] = useState('');
  const [composeTo, setComposeTo] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const [sendingNew, setSendingNew] = useState(false);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['sms-messages'],
    queryFn: () => base44.entities.SmsMessage.list('-created_date', 200),
    refetchInterval: 15000,
  });

  const { data: settings = [] } = useQuery({
    queryKey: ['system-settings-sms'],
    queryFn: () => base44.entities.SystemSettings.filter({ owner: user?.email }),
    enabled: !!user,
  });

  const twilioConfigured = settings[0]?.twilio_account_sid && settings[0]?.twilio_auth_token && settings[0]?.twilio_phone_number;

  // Group messages into threads by phone number
  const threads = useMemo(() => {
    const map = {};
    messages.forEach(m => {
      const phone = m.phone_number;
      if (!map[phone]) map[phone] = { phone, lead_name: m.lead_name, messages: [] };
      if (m.lead_name && !map[phone].lead_name) map[phone].lead_name = m.lead_name;
      map[phone].messages.push(m);
    });
    return Object.values(map).sort((a, b) => {
      const aLast = a.messages[0]?.created_date || '';
      const bLast = b.messages[0]?.created_date || '';
      return bLast.localeCompare(aLast);
    });
  }, [messages]);

  const filteredThreads = threads.filter(t =>
    t.phone.includes(search) || (t.lead_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const threadMessages = selectedThread
    ? messages.filter(m => m.phone_number === selectedThread.phone).sort((a, b) => a.created_date.localeCompare(b.created_date))
    : [];

  const sendSms = async (to, body, leadName = '') => {
    const res = await base44.functions.invoke('sendSms', { to, body, lead_name: leadName });
    return res.data;
  };

  const handleReply = async () => {
    if (!replyBody.trim()) return;
    setSendingReply(true);
    const result = await sendSms(selectedThread.phone, replyBody, selectedThread.lead_name);
    if (result?.success) {
      toast.success('SMS sent');
      setReplyBody('');
      qc.invalidateQueries({ queryKey: ['sms-messages'] });
    } else {
      toast.error(result?.error || 'Failed to send SMS');
    }
    setSendingReply(false);
  };

  const handleCompose = async () => {
    if (!composeTo.trim() || !composeBody.trim()) return;
    setSendingNew(true);
    const result = await sendSms(composeTo, composeBody);
    if (result?.success) {
      toast.success('SMS sent');
      setComposeOpen(false);
      setComposeTo('');
      setComposeBody('');
      qc.invalidateQueries({ queryKey: ['sms-messages'] });
    } else {
      toast.error(result?.error || 'Failed to send SMS');
    }
    setSendingNew(false);
  };

  const statusIcon = (status) => {
    if (status === 'sent' || status === 'delivered') return <CheckCircle2 className="w-3 h-3 text-emerald-500" />;
    if (status === 'failed') return <XCircle className="w-3 h-3 text-red-500" />;
    return <Clock className="w-3 h-3 text-muted-foreground" />;
  };

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] rounded-xl border border-border overflow-hidden bg-card">
      {/* Slim hero bar */}
      <div className="relative shrink-0 border-b border-primary/20 bg-gradient-to-r from-primary/8 via-card to-green-500/5 px-4 py-2.5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-green-500/20 flex items-center justify-center">
            <MessageSquare className="w-4 h-4 text-green-400" />
          </div>
          <div>
            <span className="font-bold text-sm">SMS Inbox</span>
            <span className="text-muted-foreground text-xs ml-2">{threads.length} conversations</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {!twilioConfigured && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
              <Settings className="w-3 h-3" />Twilio not configured
            </div>
          )}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-xs font-semibold text-green-400">
            <MessageSquare className="w-3 h-3" />{messages.length} messages
          </div>
        </div>
      </div>
      <div className="flex flex-1 overflow-hidden gap-0">
      {/* Thread list */}
      <div className="w-72 flex-shrink-0 border-r border-border flex flex-col">
        <div className="p-3 border-b border-border flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-8 h-8 text-sm" />
          </div>
          <Button size="sm" className="h-8 px-2" onClick={() => setComposeOpen(true)} title="New SMS">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {!twilioConfigured && (
          <div className="m-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-700">
            <Link to="/admin/settings" className="text-amber-600 underline font-medium">Configure Twilio in Settings →</Link>
          </div>
        )}

        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
          ) : filteredThreads.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30" />
              No messages yet
            </div>
          ) : filteredThreads.map(t => {
            const last = t.messages[0];
            return (
              <button
                key={t.phone}
                onClick={() => setSelectedThread(t)}
                className={`w-full text-left px-3 py-2.5 border-b border-border hover:bg-muted/40 transition-colors ${selectedThread?.phone === t.phone ? 'bg-primary/10' : ''}`}
              >
                <div className="flex items-center justify-between mb-0.5">
                  <span className="font-medium text-sm truncate">{t.lead_name || t.phone}</span>
                  <span className="text-[10px] text-muted-foreground flex-shrink-0 ml-1">
                    {last?.created_date ? format(new Date(last.created_date), 'MMM d') : ''}
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-xs text-muted-foreground truncate flex-1">{last?.body}</span>
                  {last && statusIcon(last.status)}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Message thread */}
      {selectedThread ? (
        <div className="flex-1 flex flex-col">
          <div className="px-4 py-3 border-b border-border flex items-center gap-3">
            <div>
              <p className="font-semibold">{selectedThread.lead_name || selectedThread.phone}</p>
              <p className="text-xs text-muted-foreground">{selectedThread.phone}</p>
            </div>
            <Badge variant="outline" className="ml-auto text-xs">{threadMessages.length} messages</Badge>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {threadMessages.map(m => (
              <div key={m.id} className={`flex ${m.direction === 'sent' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[70%] rounded-2xl px-3 py-2 ${m.direction === 'sent' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  <p className="text-sm leading-relaxed">{m.body}</p>
                  <div className={`flex items-center gap-1 mt-1 ${m.direction === 'sent' ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-[10px] opacity-60">{m.created_date ? format(new Date(m.created_date), 'MMM d, h:mm a') : ''}</span>
                    {m.direction === 'sent' && statusIcon(m.status)}
                  </div>
                  {m.status === 'failed' && m.error_message && (
                    <p className="text-[10px] text-red-300 mt-1">{m.error_message}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 border-t border-border flex gap-2">
            <Textarea
              placeholder="Type a message..."
              value={replyBody}
              onChange={e => setReplyBody(e.target.value)}
              className="flex-1 min-h-[60px] max-h-[120px] resize-none text-sm"
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleReply(); } }}
            />
            <Button onClick={handleReply} disabled={sendingReply || !replyBody.trim()} className="self-end">
              {sendingReply ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          <div className="text-center">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="font-medium">Select a conversation</p>
            <p className="text-sm mt-1">or click + to start a new one</p>
          </div>
        </div>
      )}

      </div>

      {/* Compose dialog */}
      <Dialog open={composeOpen} onOpenChange={setComposeOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><MessageSquare className="w-4 h-4" />New SMS</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>To (phone number)</Label>
              <Input placeholder="+15550001234" value={composeTo} onChange={e => setComposeTo(e.target.value)} />
              <p className="text-xs text-muted-foreground mt-1">Use E.164 format, e.g. +15551234567</p>
            </div>
            <div>
              <Label>Message</Label>
              <Textarea placeholder="Type your message..." value={composeBody} onChange={e => setComposeBody(e.target.value)} rows={4} />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setComposeOpen(false)}>Cancel</Button>
              <Button onClick={handleCompose} disabled={sendingNew || !composeTo.trim() || !composeBody.trim()}>
                {sendingNew ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Sending...</> : <><Send className="w-4 h-4 mr-2" />Send SMS</>}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}