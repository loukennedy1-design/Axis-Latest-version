import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Loader2, RefreshCw, AlertTriangle, Star, TrendingUp } from 'lucide-react';

const SENTIMENT_COLORS = { positive: 'text-emerald-400', neutral: 'text-muted-foreground', negative: 'text-red-400', unknown: 'text-muted-foreground' };

export default function CustomerIntelligence() {
  const [profiles, setProfiles] = useState([]);
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('customerIntelligenceEngine', { action: 'get_overview' });
      setProfiles(res.data?.profiles || []);
      setOverview(res.data?.overview);
    } catch { setProfiles([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleAnalyze = async () => {
    setAnalyzing(true);
    try {
      await base44.functions.invoke('customerIntelligenceEngine', { action: 'analyze_all' });
      await fetchAll();
    } finally { setAnalyzing(false); }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Users className="w-6 h-6 text-primary" />
            Customer Intelligence Engine
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Dynamic customer profiles tracking behavior, sentiment, CLV, risk, referral potential, and purchase probability — with AI predictions for churn, upsell, and cross-sell.
          </p>
        </div>
        <Button onClick={handleAnalyze} disabled={analyzing}>
          {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {analyzing ? 'Analyzing...' : 'Analyze Customers'}
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Profiles" value={overview?.total_profiles ?? '—'} />
        <StatCard label="At Risk" value={overview?.at_risk ?? 0} color="text-red-400" icon={AlertTriangle} />
        <StatCard label="High Value" value={overview?.high_value ?? 0} color="text-emerald-400" icon={TrendingUp} />
        <StatCard label="Referral Ready" value={overview?.referral_ready ?? 0} color="text-amber-400" icon={Star} />
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : profiles.length ? (
        <div className="grid md:grid-cols-2 gap-4">
          {profiles.map(p => {
            let preds = {};
            try { preds = JSON.parse(p.predictions || '{}'); } catch { /* ignore */ }
            return (
              <Card key={p.id}>
                <CardContent className="pt-5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold">{p.customer_name}</h3>
                      {p.customer_email && <p className="text-xs text-muted-foreground">{p.customer_email}</p>}
                    </div>
                    <span className={`text-xs ${SENTIMENT_COLORS[p.sentiment]}`}>{p.sentiment}</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3 mt-3">
                    <Score label="Risk" value={p.risk_score || 0} invert />
                    <Score label="Referral" value={p.referral_potential || 0} />
                    <Score label="Purchase" value={p.purchase_probability || 0} />
                  </div>
                  <div className="mt-3 text-xs space-y-1">
                    <p className="text-muted-foreground">CLV: <span className="font-medium text-foreground">${(p.lifetime_value || 0).toLocaleString()}</span></p>
                    {preds.churn && <p className="text-muted-foreground">Churn prediction: <span className="text-foreground">{preds.churn}</span></p>}
                    {preds.upsell && <p className="text-muted-foreground">Upsell: <span className="text-foreground">{preds.upsell}</span></p>}
                    {preds.next_purchase && <p className="text-muted-foreground">Next purchase: <span className="text-foreground">{preds.next_purchase}</span></p>}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card><CardContent className="py-12 text-center"><Users className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No customer profiles yet. Click "Analyze Customers" to build intelligence profiles.</p></CardContent></Card>
      )}
    </div>
  );
}

function StatCard({ label, value, color, icon: Icon }) {
  return (
    <Card><CardContent className="pt-5">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        {Icon && <Icon className="w-4 h-4 text-primary/60" />}
      </div>
      <p className={`text-2xl font-bold font-poppins mt-1 ${color || ''}`}>{value ?? '—'}</p>
    </CardContent></Card>
  );
}

function Score({ label, value, invert }) {
  const pct = Math.min(100, value || 0);
  const color = invert
    ? pct < 30 ? 'text-emerald-400' : pct < 70 ? 'text-amber-400' : 'text-red-400'
    : pct < 30 ? 'text-red-400' : pct < 70 ? 'text-amber-400' : 'text-emerald-400';
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <div className="flex items-center gap-1.5 mt-0.5">
        <div className="h-1.5 flex-1 rounded-full bg-muted overflow-hidden">
          <div className={`h-full ${color.replace('text-', 'bg-')}`} style={{ width: `${pct}%` }} />
        </div>
        <span className={`text-xs font-bold ${color}`}>{pct}</span>
      </div>
    </div>
  );
}