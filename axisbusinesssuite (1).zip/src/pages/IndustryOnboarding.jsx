import React, { useState } from 'react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { base44 } from '@/api/base44Client';
import { useMutation } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight, Loader2, Rocket, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import { STEPS } from '@/components/onboarding/StepProgress';
import StepProgress from '@/components/onboarding/StepProgress';
import StepWelcome from '@/components/onboarding/StepWelcome';
import StepBusinessProfile from '@/components/onboarding/StepBusinessProfile';
import StepIndustry from '@/components/onboarding/StepIndustry';
import StepCallBot from '@/components/onboarding/StepCallBot';
import StepIntegrations from '@/components/onboarding/StepIntegrations';
import StepNotifications from '@/components/onboarding/StepNotifications';
import StepTeamMembers from '@/components/onboarding/StepTeamMembers';
import StepLeadImport from '@/components/onboarding/StepLeadImport';
import StepReview from '@/components/onboarding/StepReview';
import StepLaunch from '@/components/onboarding/StepLaunch';
import TrinityChatAssistant from '@/components/trinity/TrinityChatAssistant';

const INITIAL = () => ({
  company_name: '', website: '', company_size: '1-10',
  industry: '', primary_use_case: '',
  bot_agent_name: '', bot_voice: 'professional', bot_personality_style: 'consultative',
  bot_talking_speed: 'normal', bot_script: '', calling_start_hour: '', calling_end_hour: '', calling_timezone: 'America/New_York',
  twilio_account_sid: '', twilio_auth_token: '', twilio_phone_number: '',
  zoom_account_id: '', zoom_client_id: '', zoom_client_secret: '', google_calendar_connected: false,
  email_notifications: true, sms_notifications: false, notification_email: '',
  alert_new_appointment: true, alert_call_completed: true, alert_lead_status_change: true, alert_payment_received: true,
});
const SKIPPABLE_STEPS = [4, 6, 7];

export default function IndustryOnboarding() {
  const { user } = useCurrentUser();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState(INITIAL);
  const [invites, setInvites] = useState([]);
  const [leadsImported, setLeadsImported] = useState(0);
  const [launched, setLaunched] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const isFinalReview = step === 8;

  const updateField = (key, value) => {
    setForm(prev => ({ ...prev, [key]: value }));
  };

  const isStepValid = () => {
    if (step === 1) return form.company_name?.trim();
    if (step === 2) return form.industry;
    return true;
  };

  const handleEditJump = (idx) => setStep(idx);

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const now = new Date();
      const scheduleRules = form.calling_start_hour && form.calling_end_hour
        ? JSON.stringify({ start: form.calling_start_hour, end: form.calling_end_hour, timezone: form.calling_timezone || 'America/New_York' })
        : '';
      const botPayload = {
        bot_agent_name: form.bot_agent_name || undefined,
        bot_voice: form.bot_voice,
        bot_personality_style: form.bot_personality_style,
        bot_talking_speed: form.bot_talking_speed,
        bot_script: form.bot_script || undefined,
        schedule_rules: scheduleRules || undefined,
      };
      // Only include fields the user actually entered for integrations
      const integPayload = {};
      if (form.twilio_account_sid) integPayload.twilio_account_sid = form.twilio_account_sid;
      if (form.twilio_auth_token) integPayload.twilio_auth_token = form.twilio_auth_token;
      if (form.twilio_phone_number) integPayload.twilio_phone_number = form.twilio_phone_number;
      if (form.zoom_account_id) integPayload.zoom_account_id = form.zoom_account_id;
      if (form.zoom_client_id) integPayload.zoom_client_id = form.zoom_client_id;
      if (form.zoom_client_secret) integPayload.zoom_client_secret = form.zoom_client_secret;
      const notifyPayload = {
        email_notifications: form.email_notifications,
        sms_notifications: form.sms_notifications,
        email_address: form.notification_email || user?.email || '',
      };

      const promises = [
        base44.functions.invoke('saveUserSettings', {
          action: 'save',
          data: { ...botPayload, ...integPayload, ...notifyPayload },
        }),
        base44.functions.invoke('configureIndustryAdapter', {
          company_name: form.company_name, website: form.website, company_size: form.company_size,
          industry: form.industry, primary_use_case: form.primary_use_case,
          automation_level: 'full', team_size: '1',
        }),
      ];

      // Invite team members
      for (const invite of invites) {
        promises.push(
          base44.functions.invoke('createRecord', {
            entity: 'SalesRep', data: {
              email: invite.email,
              status: 'invited',
              invited_by: user?.email || '',
              role: invite.role || 'Sales Rep',
              owner: user?.email || '',
            },
          }).catch(() => null)
        );
      }

      await Promise.all(promises);
      await base44.auth.updateMe({ onboarding_completed: true });
      setLaunched(true);
      setStep(9);
    } catch (err) {
      toast.error('Launch failed: ' + (err.message || 'Unknown error'));
      setSubmitting(false);
    }
  };

  const iconForStep = (s) => {
    const map = {
      0: Rocket, 1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: Sparkles, 9: null,
    };
    return map[s];
  };
  const StepIcon = iconForStep(step);

  return (
    <div className="min-h-screen bg-background p-4 sm:p-6">
      <div className="max-w-4xl mx-auto flex gap-6">
        {/* Sidebar roadmap */}
        <div className="hidden lg:block w-56 shrink-0 pt-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Launch Roadmap</p>
          <StepProgress currentStep={step} onStepClick={handleEditJump} />
          {step < 9 && (
            <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1">
              <Rocket className="w-3 h-3 text-primary" /> ~10 min to launch
            </p>
          )}
        </div>

        {/* Main card */}
        <div className="flex-1 space-y-4">
          {/* Mobile progress */}
          <div className="lg:hidden space-y-1">
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>Step {step + 1} of {STEPS.length}</span>
              {step < 9 && <span className="flex items-center gap-1 text-primary"><Rocket className="w-3 h-3" /> ~10 min</span>}
            </div>
            <Progress value={((step + 1) / STEPS.length) * 100} className="h-1.5" />
          </div>

          <Card className="border-border/70 shadow-lg">
            <CardContent className="pt-6 pb-4">
              {launched || step === 9 ? (
                <StepLaunch />
              ) : (
                <>
                  {/* Step title */}
                  <div className="flex items-center justify-between mb-1">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                      {StepIcon && <StepIcon className="w-5 h-5 text-primary" />}
                      {STEPS[step]}
                    </h2>
                    {/* Skip link for skippable steps */}
                    {SKIPPABLE_STEPS.includes(step) && !isFinalReview && (
                      <button
                        type="button"
                        onClick={() => setStep(s => Math.min(s + 1, 8))}
                        className="text-xs text-muted-foreground hover:text-primary underline underline-offset-2 transition-colors"
                      >
                        Skip for now
                      </button>
                    )}
                  </div>

                  {/* Step content */}
                  <div className="pt-3 min-h-[340px]">
                    {step === 0 && <StepWelcome onNext={() => setStep(1)} />}
                    {step === 1 && <StepBusinessProfile form={form} updateField={updateField} />}
                    {step === 2 && <StepIndustry form={form} updateField={updateField} />}
                    {step === 3 && <StepCallBot form={form} updateField={updateField} />}
                    {step === 4 && <StepIntegrations form={form} updateField={updateField} user={user} />}
                    {step === 5 && <StepNotifications form={form} updateField={updateField} user={user} />}
                    {step === 6 && <StepTeamMembers invites={invites} setInvites={setInvites} />}
                    {step === 7 && <StepLeadImport leadsImported={leadsImported} setLeadsImported={setLeadsImported} />}
                    {step === 8 && <StepReview form={form} invites={invites} leadsImported={leadsImported} onEdit={handleEditJump} />}
                  </div>

                  {/* Navigation */}
                  <div className="flex items-center justify-between pt-6 border-t border-border mt-6">
                    <Button
                      variant="outline"
                      onClick={() => setStep(s => Math.max(s - 1, 0))}
                      disabled={step === 0}
                      className="gap-2"
                    >
                      <ArrowLeft className="w-4 h-4" /> Back
                    </Button>
                    {isFinalReview ? (
                      <Button onClick={handleSubmit} disabled={submitting} className="gap-2 bg-primary hover:bg-primary/90">
                        {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Launching...</> : <><Sparkles className="w-4 h-4" /> Launch My Platform</>}
                      </Button>
                    ) : (
                      <Button
                        onClick={() => setStep(s => Math.min(s + 1, 8))}
                        disabled={!isStepValid()}
                        className="gap-2"
                      >
                        Continue <ArrowRight className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  {/* Submitting overlay */}
                  {submitting && (
                    <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/20">
                      <div className="flex items-center gap-3">
                        <Loader2 className="w-4 h-4 text-primary animate-spin" />
                        <p className="text-xs text-muted-foreground">Committing your configuration in parallel — this takes just a moment...</p>
                      </div>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      <TrinityChatAssistant user={user} onboardingMode={true} />
    </div>
  );
}