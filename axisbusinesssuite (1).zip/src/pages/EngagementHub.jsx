import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  MessageSquare, Phone, Mail, Video, Users, Search,
  Clock, TrendingUp, CheckCircle2, AlertCircle
} from 'lucide-react';

const CHANNEL_ICONS = {
  voice: Phone,
  sms: MessageSquare,
  email: Mail,
  chat: MessageSquare,
  slack: MessageSquare,
  teams: Video,
  telegram: MessageSquare,
  whatsapp: MessageSquare,
  instagram: MessageSquare,
  linkedin: MessageSquare,
  facebook: MessageSquare,
  crm: Users,
};

const CHANNEL_COLORS = {
  voice: 'bg-blue-500/10 text-blue-400',
  sms: 'bg-green-500/10 text-green-400',
  email: 'bg-purple-500/10 text-purple-400',
  chat: 'bg-amber-500/10 text-amber-400',
  default: 'bg-muted text-muted-foreground',
};

export default function EngagementHub() {
  const [search, setSearch] = useState('');
  const [selectedContact, setSelectedContact] = useState(null);

  const { data: engagements = [], refetch } = useQuery({
    queryKey: ['engagements'],
    queryFn: () => base44.entities.EngagementObject.list('-last_interaction_at', 100),
  });

  const filteredEngagements = engagements.filter(e =>
    e.contact_name?.toLowerCase().includes(search.toLowerCase()) ||
    e.contact_email?.toLowerCase().includes(search.toLowerCase()) ||
    e.contact_phone?.includes(search)
  );

  const parseTimeline = (timelineStr) => {
    try {
      return JSON.parse(timelineStr || '[]');
    } catch {
      return [];
    }
  };

  const parseMemory = (memoryStr) => {
    try {
      return JSON.parse(memoryStr || '{}');
    } catch {
      return {};
    }
  };

  const selectedData = selectedContact ? engagements.find(e => e.id === selectedContact) : null;
  const timeline = selectedData ? parseTimeline(selectedData.timeline) : [];
  const memory = selectedData ? parseMemory(selectedData.persistent_memory) : {};

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Agentic Engagement Hub</h1>
              <p className="text-muted-foreground text-xs">Unified omnichannel communication memory · AI continuity</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Users className="w-3.5 h-3.5" />{engagements.length} Active Engagements
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Contact List */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <Search className="w-4 h-4 text-muted-foreground" />
              Search Contacts
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              placeholder="Search by name, email, or phone..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="text-sm"
            />
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {filteredEngagements.map((engagement) => {
                const ChannelIcon = CHANNEL_ICONS[engagement.last_channel] || CHANNEL_ICONS.crm;
                const color = CHANNEL_COLORS[engagement.last_channel] || CHANNEL_COLORS.default;
                
                return (
                  <button
                    key={engagement.id}
                    onClick={() => setSelectedContact(engagement.id)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${
                      selectedContact === engagement.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/30'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-semibold">{engagement.contact_name}</p>
                      <ChannelIcon className={`w-3.5 h-3.5 ${color.split(' ')[1]}`} />
                    </div>
                    <p className="text-xs text-muted-foreground truncate">
                      {engagement.contact_email || engagement.contact_phone}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className={`text-[9px] ${color}`}>
                        {engagement.last_channel}
                      </Badge>
                      <Badge variant="outline" className="text-[9px]">
                        {engagement.engagement_score || 0} score
                      </Badge>
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Engagement Details */}
        <Card className="lg:col-span-2">
          {selectedData ? (
            <>
              <CardHeader>
                <CardTitle className="text-sm">{selectedData.contact_name}</CardTitle>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  {selectedData.contact_email && <span>{selectedData.contact_email}</span>}
                  {selectedData.contact_phone && <span>· {selectedData.contact_phone}</span>}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Quick Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="p-3 rounded-xl bg-muted/30">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                      <Clock className="w-3 h-3" />
                      Last Contact
                    </div>
                    <p className="text-sm font-semibold">
                      {selectedData.last_interaction_at
                        ? new Date(selectedData.last_interaction_at).toLocaleDateString()
                        : 'Never'}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-muted/30">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                      <TrendingUp className="w-3 h-3" />
                      Engagement Score
                    </div>
                    <p className="text-sm font-semibold">{selectedData.engagement_score || 0}/100</p>
                  </div>
                  <div className="p-3 rounded-xl bg-muted/30">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground mb-1">
                      <MessageSquare className="w-3 h-3" />
                      Interactions
                    </div>
                    <p className="text-sm font-semibold">{timeline.length}</p>
                  </div>
                </div>

                {/* Timeline */}
                <div>
                  <h3 className="text-xs font-semibold mb-2">Communication Timeline</h3>
                  <div className="space-y-2 max-h-[400px] overflow-y-auto">
                    {timeline.length === 0 ? (
                      <p className="text-xs text-muted-foreground text-center py-4">No interactions yet</p>
                    ) : (
                      timeline.map((entry, i) => {
                        const ChannelIcon = CHANNEL_ICONS[entry.channel] || CHANNEL_ICONS.crm;
                        const color = CHANNEL_COLORS[entry.channel] || CHANNEL_COLORS.default;
                        
                        return (
                          <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-muted/30">
                            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
                              <ChannelIcon className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <p className="text-xs font-semibold capitalize">{entry.channel}</p>
                                <p className="text-[10px] text-muted-foreground">
                                  {new Date(entry.timestamp).toLocaleString()}
                                </p>
                              </div>
                              {entry.body && (
                                <p className="text-xs text-muted-foreground">{entry.body}</p>
                              )}
                              {entry.summary && (
                                <p className="text-xs text-muted-foreground">{entry.summary}</p>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Persistent Memory */}
                {Object.keys(memory).length > 0 && (
                  <div>
                    <h3 className="text-xs font-semibold mb-2 flex items-center gap-2">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      AI Memory
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(memory).map(([key, value]) => (
                        <div key={key} className="p-2 rounded-lg bg-muted/30 text-xs">
                          <p className="text-muted-foreground capitalize">{key}</p>
                          <p className="font-semibold">{String(value)}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </>
          ) : (
            <div className="flex items-center justify-center h-[400px]">
              <div className="text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <h3 className="font-semibold text-muted-foreground">Select a contact to view engagement details</h3>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}