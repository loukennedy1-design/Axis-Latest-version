import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

// Renders the Twilio domain-verification string at the public verification URL.
// The string is fetched at runtime from the same-origin twilioVerification
// backend function (which reads it from the secret vault), so the verification
// token never lives in the frontend source code.
export default function TwilioVerification() {
  const [token, setToken] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let done = false;
    base44.functions.invoke('twilioVerification')
      .then(res => {
        if (done) return;
        if (res?.data?.token) setToken(res.data.token);
        else setError(true);
      })
      .catch(() => { if (!done) setError(true); });
    return () => { done = true; };
  }, []);

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#0a0a0a' }}>
      <pre style={{ color: '#fff', fontFamily: 'monospace', fontSize: '1rem' }}>
        {token || (error ? 'Verification unavailable' : 'Loading…')}
      </pre>
    </div>
  );
}