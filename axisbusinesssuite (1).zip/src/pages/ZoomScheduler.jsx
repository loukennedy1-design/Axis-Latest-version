import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Video, Plus, ExternalLink, Calendar, Clock, Copy, Trash2,
  Pencil, Users, Phone, CheckCircle2, Loader2, Link2, CalendarDays, RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { format, isPast } from 'date-fns';

const MEETING_TYPE_COLORS = {
  sales_call: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  interview: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  team_meeting: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  demo: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
};

const emptyMeeting = {
  topic: '', meeting_type: 'sales_call', scheduled_date: '',
  duration_minutes: 30, attendee_name: '', attendee_email: '',
  notes: '', zoom_meeting_id: '', join_url: '', password: '',
};

export default function ZoomScheduler() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editMeeting, setEditMeeting] = useState(null);
  const [form, setForm] = useState(emptyMeeting);
  const [tab, setTab] = useState('upcoming');
  const [generating, setGenerating] = useState(false);
  const { user } = useCurrentUser();
  const qc = useQueryClient();

  const { data: meetings = [], isLoading } = useQuery({
    queryKey: ['zoom-meetings'],
    queryFn: () => base44.entities.ZoomMeeting.list('-scheduled_date'),
  });
  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list(),
  });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'ZoomMeeting', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['zoom-meetings'] }); setDialogOpen(false); toast.success('Meeting scheduled'); },
  });
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ZoomMeeting.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['zoom-meetings'] }); setDialogOpen(false); toast.success('Meeting updated'); },
  });
  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.ZoomMeeting.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['zoom-meetings'] }); toast.success('Meeting deleted'); },
  });

  const openNew = (type = 'sales_call') => {
    setEditMeeting(null);
    setForm({ ...emptyMeeting, meeting_type: type });
    setDialogOpen(true);
  };
  const openEdit = (m) => { setEditMeeting(m); setForm(m); setDialogOpen(true); };

  const generateZoomLink = async () => {
    if (!form.topic?.trim()) { toast.error('Enter a meeting topic first'); return; }
    if (!form.scheduled_date) { toast.error('Select a date & time first'); return; }
    setGenerating(true);
    try {
      const res = await base44.functions.invoke('zoomOAuth', {
        action: 'create_meeting',
        payload: {
          topic: form.topic,
          start_time: new Date(form.scheduled_date).toISOString(),
          duration_minutes: form.duration_minutes || 30,
          agenda: form.notes || '',
          attendee_email: form.attendee_email || '',
        },
      });
      if (res.data?.error) throw new Error(res.data.error);
      setForm(f => ({
        ...f,
        zoom_meeting_id: res.data.zoom_meeting_id,
        join_url: res.data.join_url,
        start_url: res.data.start_url,
        password: res.data.password,
      }));
      toast.success('Real Zoom meeting created via OAuth');
    } catch (e) {
      toast.error(e.message || 'Failed to create Zoom meeting');
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = () => {
    if (editMeeting) updateMut.mutate({ id: editMeeting.id, data: form });
    else createMut.mutate({ ...form, owner: user?.email });
  };

  const copyLink = (url) => {
    navigator.clipboard.writeText(url);
    toast.success('Link copied to clipboard');
  };

  const addToGoogleCalendar = (meeting) => {
    if (!meeting.join_url) { toast.error('Generate a Zoom link first'); return; }
    const start = new Date(meeting.scheduled_date);
    const end = new Date(start.getTime() + meeting.duration_minutes * 60000);
    const fmt = (d) => d.toISOString().replace(/-|:|\.\d{3}/g, '');
    const params = new URLSearchParams({
      action: 'TEMPLATE',
      text: meeting.topic,
      dates: `${fmt(start)}/${fmt(end)}`,
      details: `Join Zoom Meeting: ${meeting.join_url}\nMeeting ID: ${meeting.zoom_meeting_id}\nPassword: ${meeting.password}\n\n${meeting.notes || ''}`,
      location: meeting.join_url,
    });
    window.open(`https://calendar.google.com/calendar/render?${params.toString()}`, '_blank');
  };

  const now = new Date();
  const upcoming = meetings.filter(m => m.scheduled_date && !isPast(new Date(m.scheduled_date)) && m.status !== 'cancelled');
  const past = meetings.filter(m => m.scheduled_date && (isPast(new Date(m.scheduled_date)) || m.status === 'completed'));

  const displayMeetings = tab === 'upcoming' ? upcoming : tab === 'past' ? past : meetings;

  const salesMeetings = meetings.filter(m => m.meeting_type === 'sales_call').length;
  const interviewMeetings = meetings.filter(m => m.meeting_type === 'interview').length;
  const demoMeetings = meetings.filter(m => m.meeting_type === 'demo').length;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-blue-500/20 bg-gradient-to-br from-blue-500/8 via-card to-primary/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Video className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Zoom & Calendar Scheduler</h1>
              <p className="text-muted-foreground text-xs">Schedule meetings, interviews & demos with Zoom + Google Calendar</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Calendar className="w-3.5 h-3.5" />{upcoming.length} upcoming
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Phone className="w-3.5 h-3.5" />{salesMeetings} sales
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-400">
              <Users className="w-3.5 h-3.5" />{interviewMeetings} interviews
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => openNew('interview')} className="gap-1.5"><Users className="w-3.5 h-3.5" />Interview</Button>
              <Button variant="outline" size="sm" onClick={() => openNew('demo')} className="gap-1.5"><Video className="w-3.5 h-3.5" />Demo</Button>
              <Button size="sm" onClick={() => openNew('sales_call')} className="gap-1.5"><Plus className="w-4 h-4" />Schedule</Button>
            </div>
          </div>
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="upcoming">Upcoming ({upcoming.length})</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
          <TabsTrigger value="all">All Meetings</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : displayMeetings.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <Video className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">No meetings scheduled</p>
                <p className="text-sm text-muted-foreground mb-4">Schedule a Zoom meeting to get started</p>
                <Button onClick={() => openNew()}><Plus className="w-4 h-4 mr-2" />Schedule Meeting</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {displayMeetings.map(meeting => (
                <Card key={meeting.id} className={`transition-shadow hover:shadow-md ${meeting.status === 'completed' ? 'opacity-70' : ''}`}>
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1 min-w-0">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${MEETING_TYPE_COLORS[meeting.meeting_type] || 'bg-muted'}`}>
                          <Video className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <p className="font-semibold">{meeting.topic}</p>
                            <Badge variant="outline" className={`capitalize text-[10px] ${MEETING_TYPE_COLORS[meeting.meeting_type]}`}>
                              {meeting.meeting_type?.replace(/_/g, ' ')}
                            </Badge>
                            <Badge variant="outline" className={`text-[10px] ${meeting.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' : meeting.status === 'cancelled' ? 'bg-red-500/10 text-red-600' : 'bg-blue-500/10 text-blue-600'}`}>
                              {meeting.status}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground flex-wrap">
                            {meeting.scheduled_date && (
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {format(new Date(meeting.scheduled_date), 'MMM d, yyyy h:mm a')}
                              </span>
                            )}
                            <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{meeting.duration_minutes}min</span>
                            {meeting.attendee_name && <span className="flex items-center gap-1"><Users className="w-3 h-3" />{meeting.attendee_name}</span>}
                          </div>
                          {meeting.zoom_meeting_id && (
                            <div className="flex items-center gap-2 mt-2 flex-wrap">
                              <code className="text-[11px] bg-muted px-2 py-0.5 rounded font-mono">ID: {meeting.zoom_meeting_id}</code>
                              {meeting.password && <code className="text-[11px] bg-muted px-2 py-0.5 rounded font-mono">PWD: {meeting.password}</code>}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1 flex-shrink-0 flex-wrap">
                        {meeting.join_url && (
                          <>
                            <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => copyLink(meeting.join_url)}>
                              <Copy className="w-3 h-3" />Copy Link
                            </Button>
                            <a href={meeting.join_url} target="_blank" rel="noopener noreferrer">
                              <Button size="sm" className="h-7 text-xs gap-1 bg-blue-600 hover:bg-blue-700">
                                <Video className="w-3 h-3" />Join
                              </Button>
                            </a>
                            <Button variant="outline" size="sm" className="h-7 text-xs gap-1" onClick={() => addToGoogleCalendar(meeting)}>
                              <CalendarDays className="w-3 h-3" />Google Cal
                            </Button>
                          </>
                        )}
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(meeting)}><Pencil className="w-3.5 h-3.5" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => deleteMut.mutate(meeting.id)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Schedule Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editMeeting ? 'Edit Meeting' : 'Schedule Zoom Meeting'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label>Meeting Topic *</Label><Input value={form.topic} onChange={e => setForm({ ...form, topic: e.target.value })} placeholder="e.g. Sales Demo with Acme Corp" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Type</Label>
                <Select value={form.meeting_type} onValueChange={v => setForm({ ...form, meeting_type: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sales_call">Sales Call</SelectItem>
                    <SelectItem value="interview">Interview</SelectItem>
                    <SelectItem value="team_meeting">Team Meeting</SelectItem>
                    <SelectItem value="demo">Demo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Duration (min)</Label>
                <Select value={String(form.duration_minutes)} onValueChange={v => setForm({ ...form, duration_minutes: parseInt(v) })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['15','30','45','60','90'].map(d => <SelectItem key={d} value={d}>{d} min</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div><Label>Date & Time *</Label><Input type="datetime-local" value={form.scheduled_date ? format(new Date(form.scheduled_date), "yyyy-MM-dd'T'HH:mm") : ''} onChange={e => { if (e.target.value) setForm({ ...form, scheduled_date: new Date(e.target.value).toISOString() }); }} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Attendee Name</Label><Input value={form.attendee_name || ''} onChange={e => setForm({ ...form, attendee_name: e.target.value })} /></div>
              <div><Label>Attendee Email</Label><Input value={form.attendee_email || ''} onChange={e => setForm({ ...form, attendee_email: e.target.value })} /></div>
            </div>

            {/* Zoom Link Section */}
            <div className="p-4 bg-blue-500/5 border border-blue-500/20 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-blue-700 flex items-center gap-2"><Video className="w-4 h-4" />Zoom Meeting Link</p>
                <Button variant="outline" size="sm" onClick={generateZoomLink} disabled={generating} className="h-7 text-xs">
                  {generating ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                  {form.zoom_meeting_id ? 'Regenerate' : 'Generate Link'}
                </Button>
              </div>
              {form.zoom_meeting_id ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <code className="text-xs bg-muted px-2 py-1 rounded flex-1 truncate font-mono">{form.join_url}</code>
                    <Button variant="ghost" size="icon" className="h-7 w-7 flex-shrink-0" onClick={() => copyLink(form.join_url)}><Copy className="w-3.5 h-3.5" /></Button>
                  </div>
                  <div className="flex gap-3 text-xs text-muted-foreground">
                    <span>ID: <code className="font-mono">{form.zoom_meeting_id}</code></span>
                    <span>PWD: <code className="font-mono">{form.password}</code></span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Click "Generate Link" to create a Zoom meeting URL</p>
              )}
              <div>
                <Label className="text-xs">Or paste existing Zoom Join URL</Label>
                <Input value={form.join_url || ''} onChange={e => setForm({ ...form, join_url: e.target.value })} placeholder="https://zoom.us/j/..." className="h-8 text-xs" />
              </div>
            </div>

            <div><Label>Notes</Label><Textarea value={form.notes || ''} onChange={e => setForm({ ...form, notes: e.target.value })} rows={2} /></div>

            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={!form.topic || !form.scheduled_date}>{editMeeting ? 'Update' : 'Schedule Meeting'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}