import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Switch } from '@/components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import {
  Plus, Trash2, Pencil, Zap, Users, ArrowRight, Loader2, Sparkles,
  Route, UserCog, Phone, Target, CheckCircle2, AlertCircle
} from 'lucide-react';
import { toast } from 'sonner';
import RepFormDialog from '@/components/sales/RepFormDialog';
import AppointmentWeeklyDashboard from '@/components/dashboard/AppointmentWeeklyDashboard';

const LEAD_STATUSES = ['new', 'contacted', 'qualified', 'appointment_set', 'not_interested'];
const emptyRule = { name: '', condition_field: 'source', condition_operator: 'equals', condition_value: '', action_type: 'assign_user', action_value: '', priority: 1, is_active: true };

const STATUS_STYLES = {
  active: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  inactive: 'bg-muted text-muted-foreground border-border',
  on_leave: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  probation: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  terminated: 'bg-red-500/10 text-red-600 border-red-500/20',
};
const ROLE_COLORS = {
  manager: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  senior_rep: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  rep: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  sdr: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
};

const emptyRep = {
  name: '', email: '', phone: '', role: 'rep', status: 'active', hire_date: '', territory: '',
  target_calls_per_day: 50, target_appointments_per_week: 10, target_revenue_per_month: 10000,
  pay_type: 'salary_plus_commission', base_salary: 0, hourly_rate: 0,
  commission_rate: 0.2, commission_type: 'revenue_share', commission_per_deal: 0,
  draw_amount: 0, bonus_target: 0, ote: 0, quota_monthly: 0, benefits: '[]', notes: '', zoom_user_id: '', tracking_code: '',
};

const generateTrackingCode = (name) => {
  const base = name ? name.replace(/\s+/g, '').toUpperCase().slice(0, 4) : 'REP';
  return `${base}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
};

export default function SalesCommandCenter() {
  const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
  const [editRule, setEditRule] = useState(null);
  const [ruleForm, setRuleForm] = useState(emptyRule);
  const [runningRouting, setRunningRouting] = useState(false);
  const [repDialogOpen, setRepDialogOpen] = useState(false);
  const [editRep, setEditRep] = useState(null);
  const [repForm, setRepForm] = useState(emptyRep);
  const { user, dataOwnerEmail } = useCurrentUser();
  const qc = useQueryClient();
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const { data: reps = [], isLoading: repsLoading } = useQuery({ queryKey: ['sales-reps'], queryFn: () => base44.entities.SalesRep.list('-created_date') });
  const { data: leads = [] } = useQuery({ queryKey: ['leads'], queryFn: () => base44.entities.Lead.list() });
  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 300) });
  const { data: appointments = [] } = useQuery({ queryKey: ['appointments'], queryFn: () => base44.entities.Appointment.list() });

  const { data: routingData = [] } = useQuery({
    queryKey: ['routing-settings'],
    queryFn: () => base44.entities.SystemSettings.filter({ key: 'routing_rules' }),
  });
  const routingRecord = routingData[0] || null;
  const parsedRules = (() => { try { return JSON.parse(routingRecord?.bot_script || '[]'); } catch { return []; } })();

  const saveRules = async (newRules) => {
    const payload = { key: 'routing_rules', bot_script: JSON.stringify(newRules) };
    if (routingRecord) {
      await base44.entities.SystemSettings.update(routingRecord.id, payload);
    } else {
      await base44.functions.invoke('createRecord', { entity: 'SystemSettings', data: payload });
    }
    qc.invalidateQueries({ queryKey: ['routing-settings'] });
  };

  const createRepMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'SalesRep', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data?.record;
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-reps'] }); setRepDialogOpen(false); toast.success('Rep added'); },
  });
  const updateRepMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SalesRep.update(id, data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-reps'] }); setRepDialogOpen(false); toast.success('Rep updated'); },
  });
  const deleteRepMut = useMutation({
    mutationFn: (id) => base44.entities.SalesRep.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-reps'] }); toast.success('Rep removed'); },
  });

  const handleRepSave = () => {
    const trackingCode = repForm.tracking_code || generateTrackingCode(repForm.name);
    if (editRep) updateRepMut.mutate({ id: editRep.id, data: { ...repForm, tracking_code: trackingCode } });
    else createRepMut.mutate({ ...repForm, tracking_code: trackingCode, owner: dataOwnerEmail || user?.email });
  };

  const updateRepStatus = async (rep, newStatus) => {
    await base44.entities.SalesRep.update(rep.id, { status: newStatus });
    qc.invalidateQueries({ queryKey: ['sales-reps'] });
    toast.success(`${rep.name} → ${newStatus.replace(/_/g, ' ')}`);
  };

  const assignLead = async (leadId, repEmail) => {
    await base44.entities.Lead.update(leadId, { assigned_to: repEmail });
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success('Lead assigned');
  };

  const openNewRule = () => { setEditRule(null); setRuleForm({ ...emptyRule, priority: parsedRules.length + 1 }); setRuleDialogOpen(true); };
  const openEditRule = (rule) => { setEditRule(rule); setRuleForm(rule); setRuleDialogOpen(true); };
  const handleRuleSave = async () => {
    const updated = editRule
      ? parsedRules.map(r => r.id === editRule.id ? { ...ruleForm, id: editRule.id } : r)
      : [...parsedRules, { ...ruleForm, id: Date.now().toString() }];
    await saveRules(updated);
    setRuleDialogOpen(false);
    toast.success(editRule ? 'Rule updated' : 'Rule created');
  };
  const deleteRule = async (id) => { await saveRules(parsedRules.filter(r => r.id !== id)); toast.success('Rule deleted'); };
  const toggleRule = async (rule) => {
    await saveRules(parsedRules.map(r => r.id === rule.id ? { ...r, is_active: !r.is_active } : r));
    qc.invalidateQueries({ queryKey: ['routing-settings'] });
  };

  const runRouting = async () => {
    const activeRules = parsedRules.filter(r => r.is_active).sort((a, b) => (a.priority || 0) - (b.priority || 0));
    if (!activeRules.length) { toast.error('No active routing rules'); return; }
    setRunningRouting(true);
    let routed = 0;
    for (const lead of leads) {
      for (const rule of activeRules) {
        const fieldVal = (lead[rule.condition_field] || '').toString().toLowerCase();
        const condVal = (rule.condition_value || '').toLowerCase();
        const match = rule.condition_operator === 'equals' ? fieldVal === condVal : rule.condition_operator === 'contains' ? fieldVal.includes(condVal) : fieldVal.startsWith(condVal);
        if (match) {
          if (rule.action_type === 'assign_user') await base44.entities.Lead.update(lead.id, { assigned_to: rule.action_value });
          else if (rule.action_type === 'set_status') await base44.entities.Lead.update(lead.id, { status: rule.action_value });
          routed++;
          break;
        }
      }
    }
    qc.invalidateQueries({ queryKey: ['leads'] });
    setRunningRouting(false);
    toast.success(`Routing complete — ${routed} leads updated`);
  };

  const unassigned = leads.filter(l => !l.assigned_to).length;
  const activeReps = reps.filter(r => r.status === 'active');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <UserCog className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Sales Command Center</h1>
              <p className="text-muted-foreground text-xs">Rep status, lead assignment & routing — all on one screen</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5" />{activeReps.length} active reps
            </div>
            {unassigned > 0 && (
              <div className="px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />{unassigned} unassigned leads
              </div>
            )}
            <Button size="sm" onClick={() => { setEditRep(null); setRepForm(emptyRep); setRepDialogOpen(true); }} className="gap-1.5">
              <Plus className="w-4 h-4" />Add Rep
            </Button>
          </div>
        </div>
      </div>

      {/* ── Appointment Performance: set vs completed weekly + team close rates ── */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-7 h-7 rounded-lg bg-emerald-500/15 flex items-center justify-center">
            <Target className="w-4 h-4 text-emerald-500" />
          </div>
          <div>
            <h2 className="text-sm font-bold tracking-tight">Appointment Performance</h2>
            <p className="text-[11px] text-muted-foreground">Set vs completed each week — track your team's close rates</p>
          </div>
        </div>
        <AppointmentWeeklyDashboard appointments={appointments} targetRate={50} />
      </div>

      {/* ── SECTION 1: Reps + Lead Assignment side by side ── */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">

        {/* LEFT: Rep Status Panel */}
        <Card>
          <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
            <CardTitle className="text-sm flex items-center gap-2"><Users className="w-4 h-4" />Rep Status</CardTitle>
            <span className="text-xs text-muted-foreground">Update status inline</span>
          </CardHeader>
          <CardContent className="p-0">
            {repsLoading ? (
              <div className="flex items-center justify-center py-10"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
            ) : reps.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm">No reps yet — click "Add Rep" to get started</div>
            ) : (
              <div className="divide-y divide-border">
                {reps.map(rep => {
                  const repLeads = leads.filter(l => l.assigned_to === rep.email).length;
                  const repCalls = calls.filter(c => c.called_by === rep.name || c.owner === rep.email).length;
                  const repAppts = appointments.filter(a => a.assigned_to === rep.email).length;
                  const leadPct = leads.length > 0 ? Math.round((repLeads / leads.length) * 100) : 0;
                  return (
                    <div key={rep.id} className="p-3 hover:bg-muted/20 transition-colors">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs flex-shrink-0">{rep.name?.charAt(0) || '?'}</div>
                          <div className="min-w-0">
                            <p className="font-semibold text-sm truncate">{rep.name}</p>
                            <p className="text-[10px] text-muted-foreground truncate">{rep.email}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <Badge variant="outline" className={`text-[10px] capitalize hidden sm:flex ${ROLE_COLORS[rep.role] || ''}`}>{rep.role?.replace(/_/g, ' ')}</Badge>
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => { setEditRep(rep); setRepForm({ ...emptyRep, ...rep }); setRepDialogOpen(true); }}><Pencil className="w-3 h-3" /></Button>
                          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => deleteRepMut.mutate(rep.id)}><Trash2 className="w-3 h-3 text-destructive" /></Button>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-3">
                        <Select value={rep.status} onValueChange={(v) => updateRepStatus(rep, v)}>
                          <SelectTrigger className="h-7 text-xs w-32 flex-shrink-0"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="active">Active</SelectItem>
                            <SelectItem value="inactive">Inactive</SelectItem>
                            <SelectItem value="on_leave">On Leave</SelectItem>
                            <SelectItem value="probation">Probation</SelectItem>
                            <SelectItem value="terminated">Terminated</SelectItem>
                          </SelectContent>
                        </Select>
                        <div className="flex gap-3 text-xs text-muted-foreground flex-1">
                          <span className="flex items-center gap-1"><Target className="w-3 h-3 text-primary" /><strong className="text-foreground">{repLeads}</strong></span>
                          <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-blue-400" /><strong className="text-foreground">{repCalls}</strong></span>
                        </div>
                      </div>
                      {repLeads > 0 && (
                        <div className="mt-2">
                          <Progress value={leadPct} className="h-1" />
                          <p className="text-[10px] text-muted-foreground mt-0.5">{leadPct}% of total leads</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* RIGHT: Lead Assignment Panel */}
        <div className="space-y-4">
          {/* Unassigned */}
          <Card>
            <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-amber-500" />Unassigned Leads
                {unassigned > 0 && <span className="ml-1 text-[10px] bg-amber-500 text-white rounded-full px-1.5 font-bold">{unassigned}</span>}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {unassigned === 0 ? (
                <div className="text-center py-6 text-emerald-500 text-sm font-medium">
                  <CheckCircle2 className="w-4 h-4 inline mr-1" />All leads assigned
                </div>
              ) : (
                <div className="divide-y divide-border max-h-72 overflow-y-auto">
                  {leads.filter(l => !l.assigned_to).slice(0, 50).map(lead => (
                    <div key={lead.id} className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-muted/20">
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{lead.first_name} {lead.last_name}</p>
                        <p className="text-[10px] text-muted-foreground">{lead.source || lead.status}</p>
                      </div>
                      <Select onValueChange={(v) => assignLead(lead.id, v)}>
                        <SelectTrigger className="h-7 text-xs w-36 flex-shrink-0"><SelectValue placeholder="Assign..." /></SelectTrigger>
                        <SelectContent>
                          {activeReps.map(rep => <SelectItem key={rep.id} value={rep.email}>{rep.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Reassign assigned leads */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2"><ArrowRight className="w-4 h-4" />Reassign Leads</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="divide-y divide-border max-h-64 overflow-y-auto">
                {leads.filter(l => l.assigned_to).length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground text-sm">No assigned leads yet</div>
                ) : (
                  leads.filter(l => l.assigned_to).slice(0, 50).map(lead => {
                    const currentRep = reps.find(r => r.email === lead.assigned_to);
                    return (
                      <div key={lead.id} className="px-4 py-2.5 flex items-center justify-between gap-3 hover:bg-muted/20">
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm truncate">{lead.first_name} {lead.last_name}</p>
                          <Badge variant="outline" className="text-[10px] mt-0.5">{currentRep?.name || lead.assigned_to}</Badge>
                        </div>
                        <Select value={lead.assigned_to} onValueChange={(v) => assignLead(lead.id, v)}>
                          <SelectTrigger className="h-7 text-xs w-36 flex-shrink-0"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {activeReps.map(rep => <SelectItem key={rep.id} value={rep.email}>{rep.name}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    );
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* ── SECTION 2: Auto Routing Rules ── */}
      <Card>
        <CardHeader className="pb-3 flex-row items-center justify-between space-y-0">
          <CardTitle className="text-sm flex items-center gap-2"><Route className="w-4 h-4" />Auto Routing Rules <span className="text-xs font-normal text-muted-foreground ml-1">— first match wins</span></CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={runRouting} disabled={runningRouting} className="gap-1.5 h-7 text-xs">
              {runningRouting ? <><Loader2 className="w-3 h-3 animate-spin" />Running...</> : <><Zap className="w-3 h-3" />Run Now</>}
            </Button>
            <Button size="sm" onClick={openNewRule} className="gap-1 h-7 text-xs"><Plus className="w-3 h-3" />Add Rule</Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {parsedRules.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">No routing rules yet — click "Add Rule" to automate lead assignment</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-10">Pri.</TableHead>
                  <TableHead>Rule</TableHead>
                  <TableHead>Condition → Action</TableHead>
                  <TableHead className="w-16">Active</TableHead>
                  <TableHead className="w-16">Edit</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...parsedRules].sort((a, b) => (a.priority || 0) - (b.priority || 0)).map(rule => (
                  <TableRow key={rule.id} className={!rule.is_active ? 'opacity-40' : ''}>
                    <TableCell className="font-bold text-muted-foreground text-sm">{rule.priority}</TableCell>
                    <TableCell className="font-medium text-sm">{rule.name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 text-xs flex-wrap">
                        <Badge variant="outline" className="capitalize text-[10px]">{rule.condition_field?.replace(/_/g, ' ')}</Badge>
                        <span className="text-muted-foreground">{rule.condition_operator}</span>
                        <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20 text-[10px]">{rule.condition_value}</Badge>
                        <ArrowRight className="w-3 h-3 text-muted-foreground" />
                        <Badge className="bg-emerald-500/10 text-emerald-700 border-emerald-500/20 capitalize text-[10px]">{rule.action_type?.replace(/_/g, ' ')}</Badge>
                        <span className="font-medium text-[10px]">{rule.action_value}</span>
                      </div>
                    </TableCell>
                    <TableCell><Switch checked={rule.is_active} onCheckedChange={() => toggleRule(rule)} /></TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => openEditRule(rule)}><Pencil className="w-3 h-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => deleteRule(rule.id)}><Trash2 className="w-3 h-3 text-destructive" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Routing Rule Dialog */}
      <Dialog open={ruleDialogOpen} onOpenChange={setRuleDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editRule ? 'Edit Routing Rule' : 'New Routing Rule'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label>Rule Name</Label>
                <Input value={ruleForm.name} onChange={e => setRuleForm({ ...ruleForm, name: e.target.value })} placeholder="e.g. Route website leads to John" />
              </div>
              <div>
                <Label>Priority (lower = first)</Label>
                <Input type="number" min={1} value={ruleForm.priority} onChange={e => setRuleForm({ ...ruleForm, priority: parseInt(e.target.value) || 1 })} />
              </div>
              <div className="flex items-center gap-2 pt-6">
                <Switch checked={ruleForm.is_active} onCheckedChange={v => setRuleForm({ ...ruleForm, is_active: v })} />
                <Label>Active</Label>
              </div>
            </div>
            <div className="p-4 rounded-xl bg-muted/30 border border-border space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Condition (IF)</p>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label className="text-xs">Field</Label>
                  <Select value={ruleForm.condition_field} onValueChange={v => setRuleForm({ ...ruleForm, condition_field: v })}>
                    <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="source">Source</SelectItem>
                      <SelectItem value="status">Status</SelectItem>
                      <SelectItem value="company">Company</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Operator</Label>
                  <Select value={ruleForm.condition_operator} onValueChange={v => setRuleForm({ ...ruleForm, condition_operator: v })}>
                    <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equals">equals</SelectItem>
                      <SelectItem value="contains">contains</SelectItem>
                      <SelectItem value="starts_with">starts with</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Value</Label>
                  <Input value={ruleForm.condition_value} onChange={e => setRuleForm({ ...ruleForm, condition_value: e.target.value })} className="h-8 text-xs" placeholder="e.g. Website" />
                </div>
              </div>
            </div>
            <div className="p-4 rounded-xl bg-emerald-500/5 border border-emerald-500/20 space-y-3">
              <p className="text-xs font-semibold uppercase tracking-wider text-emerald-700">Action (THEN)</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Action</Label>
                  <Select value={ruleForm.action_type} onValueChange={v => setRuleForm({ ...ruleForm, action_type: v, action_value: '' })}>
                    <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="assign_user">Assign to User</SelectItem>
                      <SelectItem value="set_status">Set Status</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Value</Label>
                  {ruleForm.action_type === 'assign_user' ? (
                    <Select value={ruleForm.action_value} onValueChange={v => setRuleForm({ ...ruleForm, action_value: v })}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select rep" /></SelectTrigger>
                      <SelectContent>
                        {reps.map(rep => <SelectItem key={rep.id} value={rep.email}>{rep.name} ({rep.role})</SelectItem>)}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Select value={ruleForm.action_value} onValueChange={v => setRuleForm({ ...ruleForm, action_value: v })}>
                      <SelectTrigger className="h-8 text-xs"><SelectValue placeholder="Select status" /></SelectTrigger>
                      <SelectContent>
                        {LEAD_STATUSES.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, ' ')}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setRuleDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleRuleSave} disabled={!ruleForm.name || !ruleForm.condition_value || !ruleForm.action_value}>
                {editRule ? 'Update' : 'Create'} Rule
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <RepFormDialog
        open={repDialogOpen}
        onOpenChange={setRepDialogOpen}
        form={repForm}
        setForm={setRepForm}
        editRep={editRep}
        onSave={handleRepSave}
        saving={createRepMut.isPending || updateRepMut.isPending}
        appUrl={appUrl}
      />
    </div>
  );
}