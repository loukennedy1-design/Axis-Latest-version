import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Calendar, Brain, Zap, Clock, Users, MessageSquare,
  Video, Phone, Globe, Loader2, CheckCircle2, ArrowRight,
  RefreshCw, Plus, Slack, Send, Bot
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

const SCHEDULING_MODES = [
  { id: 'natural_language', label: 'Natural Language', icon: Brain, desc: 'Type what you need — AI handles everything', color: 'text-primary bg-primary/10 border-primary/20' },
  { id: 'round_robin', label: 'Round Robin', icon: Users, desc: 'Auto-assign across your team fairly', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
  { id: 'sms_scheduling', label: 'SMS Scheduling', icon: MessageSquare, desc: 'Schedule via text message conversation', color: 'text-green-400 bg-green-500/10 border-green-500/20' },
  { id: 'slack_scheduling', label: 'Slack Scheduling', icon: Slack, desc: 'Schedule directly from Slack channels', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
  { id: 'zoom_scheduling', label: 'Zoom Scheduling', icon: Video, desc: 'Auto-create Zoom links and invites', color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20' },
  { id: 'teams_scheduling', label: 'Teams Scheduling', icon: Video, desc: 'Schedule Microsoft Teams meetings', color: 'text-violet-400 bg-violet-500/10 border-violet-500/20' },
  { id: 'calendar_negotiation', label: 'AI Negotiation', icon: Bot, desc: 'AI negotiates best time with all parties', color: 'text-pink-400 bg-pink-500/10 border-pink-500/20' },
  { id: 'auto_reschedule', label: 'Auto-Reschedule', icon: RefreshCw, desc: 'Automatic rescheduling on cancellation', color: 'text-orange-400 bg-orange-500/10 border-orange-500/20' },
];

const RECENT_ACTIONS = [
  { type: 'scheduled', contact: 'Michael Torres', channel: 'zoom', time: '2h ago', outcome: 'Demo — Thu 2pm EST' },
  { type: 'rescheduled', contact: 'Sarah Chen', channel: 'sms', time: '4h ago', outcome: 'Moved to Fri 10am EST' },
  { type: 'negotiated', contact: 'James Wilson', channel: 'ai', time: '6h ago', outcome: 'Found mutual slot: Mon 3pm' },
  { type: 'round_robin', contact: '5 new leads', channel: 'crm', time: '1d ago', outcome: 'Distributed to team evenly' },
];

function NaturalLanguageScheduler() {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleSchedule = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are AXIS Autonomous Scheduling Agent. Parse this scheduling request and return a structured scheduling plan:

Request: "${prompt}"

Return JSON with:
{
  "intent": "schedule|reschedule|cancel|check",
  "contact_name": "string or null",
  "meeting_type": "demo|discovery|follow_up|interview|general",
  "channel": "zoom|phone|teams|in_person",
  "suggested_times": ["ISO datetime string", ...],
  "duration_minutes": number,
  "ai_message": "Friendly confirmation message to send",
  "action_items": ["Step 1", "Step 2", ...]
}`,
        response_json_schema: {
          type: "object",
          properties: {
            intent: { type: "string" },
            contact_name: { type: "string" },
            meeting_type: { type: "string" },
            channel: { type: "string" },
            suggested_times: { type: "array", items: { type: "string" } },
            duration_minutes: { type: "number" },
            ai_message: { type: "string" },
            action_items: { type: "array", items: { type: "string" } },
          }
        }
      });
      setResult(res);
      toast.success('Scheduling plan generated!');
    } catch (e) {
      toast.error('Failed: ' + e.message);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="text-xs font-medium mb-2 block">Describe what you need to schedule</label>
        <Textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder={`Examples:\n• "Schedule a 30-min Zoom demo with John Smith next Tuesday afternoon"\n• "Reschedule all appointments for next Monday — I'm out of office"\n• "Set up round-robin calls with 10 new leads this week"\n• "Book interviews for the Sales Manager role, Zoom, 45 min each"`}
          className="min-h-[120px] text-sm resize-none"
        />
      </div>
      <Button onClick={handleSchedule} disabled={loading || !prompt.trim()} className="gap-2">
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Brain className="w-4 h-4" />}
        Generate Scheduling Plan
      </Button>

      {result && (
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 space-y-3">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <p className="text-sm font-semibold text-emerald-400">Scheduling Plan Ready</p>
            <Badge className="ml-auto text-[9px] bg-primary/10 text-primary border-primary/20">{result.intent}</Badge>
          </div>
          <p className="text-sm text-muted-foreground">{result.ai_message}</p>
          {result.suggested_times?.length > 0 && (
            <div>
              <p className="text-xs font-medium mb-1.5">Suggested Times:</p>
              <div className="flex flex-wrap gap-2">
                {result.suggested_times.map((t, i) => (
                  <div key={i} className="px-2.5 py-1 rounded-lg bg-card border border-border text-xs flex items-center gap-1.5">
                    <Clock className="w-3 h-3 text-primary" />
                    {t}
                  </div>
                ))}
              </div>
            </div>
          )}
          {result.action_items?.length > 0 && (
            <div>
              <p className="text-xs font-medium mb-1.5">Action Items:</p>
              <div className="space-y-1">
                {result.action_items.map((item, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs">
                    <ArrowRight className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                    {item}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function AutonomousScheduler() {
  const [activeMode, setActiveMode] = useState('natural_language');

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-purple-500/20 bg-gradient-to-br from-purple-500/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-10 -right-10 w-56 h-56 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-purple-500/20 flex items-center justify-center">
              <Calendar className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight">AXIS Autonomous Scheduling</h1>
              <p className="text-muted-foreground text-xs">Natural language scheduling · AI calendar negotiation · Cross-channel coordination</p>
            </div>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-400">
            <div className="w-1.5 h-1.5 rounded-full bg-purple-500 animate-pulse" />Agent Active
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Modes Available', value: '8', icon: Zap, color: 'text-purple-400' },
          { label: 'Channels', value: '6+', icon: Globe, color: 'text-blue-400' },
          { label: 'Auto-Reschedule', value: 'Active', icon: RefreshCw, color: 'text-emerald-400' },
          { label: 'AI Negotiation', value: 'On', icon: Brain, color: 'text-amber-400' },
        ].map(s => (
          <div key={s.label} className="p-4 rounded-xl border border-border bg-card">
            <div className="flex items-center gap-2 mb-1">
              <s.icon className={`w-3.5 h-3.5 ${s.color}`} />
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{s.label}</p>
            </div>
            <p className={`text-2xl font-black ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Scheduling modes */}
        <div className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">Scheduling Modes</p>
          {SCHEDULING_MODES.map(mode => (
            <button
              key={mode.id}
              onClick={() => setActiveMode(mode.id)}
              className={`w-full text-left p-3 rounded-xl border transition-all ${activeMode === mode.id ? `${mode.color} border-current/30` : 'border-border bg-card hover:bg-muted/30'}`}
            >
              <div className="flex items-center gap-2.5">
                <mode.icon className={`w-4 h-4 shrink-0 ${activeMode === mode.id ? '' : 'text-muted-foreground'}`} />
                <div>
                  <p className={`text-xs font-semibold ${activeMode === mode.id ? '' : 'text-foreground'}`}>{mode.label}</p>
                  <p className="text-[10px] text-muted-foreground">{mode.desc}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Main panel */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2">
                {(() => { const m = SCHEDULING_MODES.find(m => m.id === activeMode); return m ? <m.icon className="w-4 h-4" /> : null; })()}
                {SCHEDULING_MODES.find(m => m.id === activeMode)?.label}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {activeMode === 'natural_language' ? (
                <NaturalLanguageScheduler />
              ) : (
                <div className="text-center py-10">
                  <div className="w-12 h-12 rounded-xl bg-muted/30 flex items-center justify-center mx-auto mb-3">
                    {(() => { const m = SCHEDULING_MODES.find(m => m.id === activeMode); return m ? <m.icon className="w-6 h-6 text-muted-foreground" /> : null; })()}
                  </div>
                  <p className="text-sm font-semibold mb-1">{SCHEDULING_MODES.find(m => m.id === activeMode)?.label}</p>
                  <p className="text-xs text-muted-foreground mb-4">{SCHEDULING_MODES.find(m => m.id === activeMode)?.desc}</p>
                  <p className="text-xs text-muted-foreground">Configure this mode in your integration settings</p>
                  <Button size="sm" variant="outline" className="mt-3 text-xs">Configure Integration</Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recent scheduling activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-xs text-muted-foreground uppercase tracking-wider flex items-center gap-2">
                <Clock className="w-3 h-3" />Recent Scheduling Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {RECENT_ACTIONS.map((a, i) => (
                <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-muted/20 border border-border">
                  <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-3 h-3 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate">{a.contact}</p>
                    <p className="text-[10px] text-muted-foreground">{a.outcome}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <Badge className="text-[9px] bg-muted/40 text-muted-foreground mb-0.5">{a.channel}</Badge>
                    <p className="text-[10px] text-muted-foreground">{a.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}