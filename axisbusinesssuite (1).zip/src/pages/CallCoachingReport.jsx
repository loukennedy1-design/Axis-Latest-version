import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, Trophy, TrendingUp, ClipboardList, FileText, Award, Users, Sparkles } from 'lucide-react';
import AgentCoachingCard from '@/components/coaching/AgentCoachingCard';

function parseJson(str, fallback) {
  if (str == null) return fallback;
  if (Array.isArray(str) || typeof str === 'object') return str;
  try { return JSON.parse(str); } catch { return fallback; }
}
function dedupe(arr) {
  const seen = new Set(); const out = [];
  for (const x of arr) { const k = String(x || '').trim(); if (k && !seen.has(k)) { seen.add(k); out.push(k); } }
  return out;
}
function avg(nums) { const n = nums.filter((x) => x > 0); if (!n.length) return 0; return Math.round(n.reduce((a, b) => a + b, 0) / n.length); }

function buildAgent(key, calls, sessions) {
  const scores = [
    ...calls.filter((c) => c.coaching_analyzed && c.coaching_score > 0).map((c) => c.coaching_score),
    ...sessions.map((s) => s.overall_score || 0),
  ];
  const avgScore = avg(scores);
  const appt = calls.filter((c) => c.outcome === 'appointment_set').length;
  const apptRate = calls.length ? Math.round((appt / calls.length) * 100) : 0;

  const breakdown = {
    opening: avg(sessions.map((s) => s.opening_score || 0)),
    objection_handling: avg(sessions.map((s) => s.objection_handling_score || 0)),
    closing: avg(sessions.map((s) => s.closing_score || 0)),
    compliance: avg(sessions.map((s) => s.compliance_score || 0)),
  };

  const qm = calls.filter((c) => c.quality_metrics).map((c) => parseJson(c.quality_metrics, {}));
  const qualityMetrics = qm.length
    ? {
        empathy: avg(qm.map((m) => m.empathy || 0)),
        clarity: avg(qm.map((m) => m.clarity || 0)),
        objection_handling: avg(qm.map((m) => m.objection_handling || 0)),
        closing_attempt: avg(qm.map((m) => m.closing_attempt || 0)),
        rapport_building: avg(qm.map((m) => m.rapport_building || 0)),
        active_listening: avg(qm.map((m) => m.active_listening || 0)),
      }
    : null;

  const flagCount = {};
  for (const c of calls) { for (const f of parseJson(c.coaching_flags, [])) { flagCount[f] = (flagCount[f] || 0) + 1; } }
  const flags = Object.entries(flagCount).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([flag, count]) => ({ flag, count }));

  const strengths = dedupe(sessions.flatMap((s) => parseJson(s.strengths, []))).slice(0, 5);
  const improvements = dedupe(sessions.flatMap((s) => parseJson(s.improvements, []))).slice(0, 5);
  const scriptSuggestions = dedupe(sessions.flatMap((s) => parseJson(s.script_suggestions, []))).slice(0, 5);
  const recommendations = dedupe(calls.flatMap((c) => parseJson(c.coaching_recommendations, []))).slice(0, 6);

  const sorted = calls.filter((c) => c.coaching_analyzed && c.coaching_score > 0)
    .sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
  let trend = 'stable';
  if (sorted.length >= 4) {
    const mid = Math.floor(sorted.length / 2);
    const older = avg(sorted.slice(0, mid).map((c) => c.coaching_score));
    const newer = avg(sorted.slice(mid).map((c) => c.coaching_score));
    if (newer - older > 3) trend = 'improving';
    else if (older - newer > 3) trend = 'declining';
  }

  const recentCalls = [...calls].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 5)
    .map((c) => ({ lead: c.lead_name || c.phone_number, outcome: c.outcome, score: c.coaching_score || 0, date: c.created_date }));

  return { key, name: key, callsCount: calls.length, analyzedCount: calls.filter((c) => c.coaching_analyzed).length, avgScore, apptRate, trend, breakdown, qualityMetrics, flags, strengths, improvements, scriptSuggestions, recommendations, recentCalls };
}

function buildReports(calls, sessions) {
  const byAgent = {};
  for (const c of calls) {
    const k = (c.called_by && c.called_by.trim()) || 'AI Bot';
    (byAgent[k] = byAgent[k] || []).push(c);
  }
  const sessByAgent = {};
  for (const s of sessions) {
    const k = (s.agent_name && s.agent_name.trim()) || 'AI Bot';
    (sessByAgent[k] = sessByAgent[k] || []).push(s);
  }
  const keys = new Set([...Object.keys(byAgent), ...Object.keys(sessByAgent)]);
  return [...keys].map((k) => buildAgent(k, byAgent[k] || [], sessByAgent[k] || []))
    .sort((a, b) => b.avgScore - a.avgScore);
}

function ActiveScriptSection({ script }) {
  const [expanded, setExpanded] = useState(false);
  if (!script) {
    return (
      <Card><CardContent className="p-4 text-sm text-muted-foreground italic">
        No active script version found. Generate an evolved script from call analysis to populate this playbook.
      </CardContent></Card>
    );
  }
  const winning = parseJson(script.winning_phrases, []);
  const objections = parseJson(script.objection_patterns, []);
  const learnings = parseJson(script.key_learnings, []);
  const text = script.script || '';
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary" /> Current Playbook — Script v{script.version || '—'}
          {script.is_active && <Badge className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20 text-[10px]">Active</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Calls Analyzed</p>
            <p className="text-lg font-bold">{script.calls_analyzed || 0}</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Appointment Rate</p>
            <p className="text-lg font-bold text-emerald-500">{script.appointment_rate || 0}%</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Answer Rate</p>
            <p className="text-lg font-bold">{script.answer_rate || 0}%</p>
          </div>
          <div className="bg-muted/30 rounded-lg p-2.5">
            <p className="text-[10px] uppercase text-muted-foreground">Winning Phrases</p>
            <p className="text-lg font-bold text-primary">{winning.length}</p>
          </div>
        </div>

        {text && (
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Script</p>
            <p className={`text-xs leading-relaxed whitespace-pre-wrap ${expanded ? '' : 'line-clamp-6'}`}>{text}</p>
            {text.length > 400 && (
              <Button variant="ghost" size="sm" className="h-6 mt-1 text-xs" onClick={() => setExpanded((e) => !e)}>
                {expanded ? 'Show less' : 'Show full script'}
              </Button>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {winning.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider mb-1.5">Winning Phrases</p>
              <ul className="space-y-1">{winning.slice(0, 6).map((w, i) => <li key={i} className="text-xs text-muted-foreground">• {w}</li>)}</ul>
            </div>
          )}
          {objections.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider mb-1.5">Common Objections</p>
              <ul className="space-y-1">{objections.slice(0, 6).map((w, i) => <li key={i} className="text-xs text-muted-foreground">• {w}</li>)}</ul>
            </div>
          )}
          {learnings.length > 0 && (
            <div className="md:col-span-2">
              <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1.5">Key Learnings</p>
              <ul className="space-y-1">{learnings.slice(0, 6).map((w, i) => <li key={i} className="text-xs text-muted-foreground">• {w}</li>)}</ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

export default function CallCoachingReport() {
  const { data: calls = [], isLoading: callsLoading } = useQuery({
    queryKey: ['coaching-report-calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });
  const { data: sessions = [] } = useQuery({
    queryKey: ['coaching-report-sessions'],
    queryFn: () => base44.entities.CoachingSession.list('-created_date'),
  });
  const { data: scripts = [] } = useQuery({
    queryKey: ['coaching-report-scripts'],
    queryFn: () => base44.entities.ScriptEvolution.list('-created_date'),
  });

  const reports = useMemo(() => buildReports(calls, sessions), [calls, sessions]);
  const activeScript = useMemo(() => scripts.find((s) => s.is_active) || scripts[0] || null, [scripts]);

  const overallAvg = reports.length ? Math.round(reports.reduce((a, r) => a + r.avgScore, 0) / reports.length) : 0;
  const totalAnalyzed = calls.filter((c) => c.coaching_analyzed).length;
  const topPerformer = reports.find((r) => r.avgScore > 0);

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-amber-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <ClipboardList className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Call Coaching Report</h1>
              <p className="text-muted-foreground text-xs">Per-agent scripts, performance scores & conversation feedback</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Users className="w-3.5 h-3.5" />{reports.length} agents
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />avg {overallAvg}/100
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
              <Sparkles className="w-3.5 h-3.5" />{totalAnalyzed} analyzed
            </div>
            {topPerformer && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
                <Trophy className="w-3.5 h-3.5" />top {topPerformer.name.split(' ')[0]}
              </div>
            )}
          </div>
        </div>
      </div>

      {callsLoading ? (
        <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 text-primary animate-spin" /></div>
      ) : reports.length === 0 ? (
        <Card><CardContent className="p-8 text-center">
          <Award className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm font-semibold">No coaching data yet</p>
          <p className="text-xs text-muted-foreground mt-1">Analyze calls in the Coaching Hub to populate this report.</p>
        </CardContent></Card>
      ) : (
        <>
          {/* Current Playbook */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FileText className="w-4 h-4" />Current Playbook
            </h2>
            <ActiveScriptSection script={activeScript} />
          </div>

          {/* Per-agent reports */}
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Users className="w-4 h-4" />Agent Performance
            </h2>
            <div className="space-y-3">
              {reports.map((r, i) => (
                <AgentCoachingCard key={r.key} agent={r} defaultOpen={i === 0} />
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}