import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { ShieldX } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Phone, Calendar, DollarSign, Link2, Copy, Trophy,
  TrendingUp, Users, CheckCircle2, AlertCircle, Loader2, Sparkles, LayoutDashboard, FileText, Target, GraduationCap
} from 'lucide-react';
import RepAITools from '@/components/rep/RepAITools';
import RepLeadGenerator from '@/components/rep/RepLeadGenerator';
import RepSalesTraining from '@/components/rep/RepSalesTraining';
import RepCommandCenter from '@/components/rep/RepCommandCenter';
import RepLeadsPanel from '@/components/rep/RepLeadsPanel';
import RepTasksPanel from '@/components/rep/RepTasksPanel';
import RepAppointmentsPanel from '@/components/rep/RepAppointmentsPanel';
import RepCalendarSync from '@/components/rep/RepCalendarSync';
import RepLeadDrawer from '@/components/rep/RepLeadDrawer';
import RepDocumentsPanel from '@/components/rep/RepDocumentsPanel';
import RepCommissionPanel from '@/components/rep/RepCommissionPanel';
import ForcedPasswordReset from '@/components/rep/ForcedPasswordReset';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function RepPortal() {
  const { user, dataOwnerEmail } = useCurrentUser();
  const [searchParams, setSearchParams] = useSearchParams();
  const tab = searchParams.get('tab') || 'command';
  const setTab = (newTab) => setSearchParams({ tab: newTab });
  const [drawerLead, setDrawerLead] = useState(null);
  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const { data: reps = [], isLoading: loadingRep } = useQuery({
    queryKey: ['my-rep', user?.email],
    queryFn: () => base44.entities.SalesRep.filter({ email: user?.email }),
    enabled: !!user?.email,
  });
  const rep = reps[0] || null;

  const { data: leads = [] } = useQuery({
    queryKey: ['rep-leads', user?.email],
    queryFn: () => base44.entities.Lead.filter({ assigned_to: user?.email }),
    enabled: !!user?.email,
  });

  const { data: referrals = [] } = useQuery({
    queryKey: ['my-referrals', rep?.id],
    queryFn: () => base44.entities.RepReferral.filter({ rep_id: rep?.id }),
    enabled: !!rep?.id,
  });

  const { data: commissions = [] } = useQuery({
    queryKey: ['my-commissions', rep?.id],
    queryFn: () => base44.entities.RepCommission.filter({ rep_id: rep?.id }),
    enabled: !!rep?.id,
  });

  const referralLink = rep?.tracking_code ? `${appUrl}/pricing?ref=${rep.tracking_code}` : null;
  const copyLink = () => {
    if (!referralLink) return;
    navigator.clipboard.writeText(referralLink);
    toast.success('Referral link copied!');
  };

  const subscriberEmail = dataOwnerEmail || rep?.owner || user?.email;

  const [accessCheck, setAccessCheck] = useState({ loading: true, authorized: false, reason: null, message: null });

  useEffect(() => {
    if (!user?.email) return;
    let mounted = true;
    base44.functions.invoke('verifyRepPortalAccess', {})
      .then((res) => {
        if (!mounted) return;
        if (res.data?.authorized) {
          setAccessCheck({ loading: false, authorized: true, mustResetPassword: !!res.data?.must_reset_password });
        } else {
          setAccessCheck({ loading: false, authorized: false, reason: res.data?.reason, message: res.data?.message });
        }
      })
      .catch(() => {
        if (mounted) setAccessCheck({ loading: false, authorized: false, reason: 'error', message: 'Unable to verify portal access.' });
      });
    return () => { mounted = false; };
  }, [user?.email]);

  const openDrawer = (lead) => {
    // If we have the full lead in our list, use it; otherwise construct a minimal object
    const fullLead = leads.find(l => l.id === lead.id) || lead;
    setDrawerLead(fullLead);
  };

  if (loadingRep || accessCheck.loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!accessCheck.authorized) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="max-w-md w-full border-dashed">
          <CardContent className="py-12 text-center">
            <ShieldX className="w-10 h-10 text-red-500 mx-auto mb-3" />
            <p className="font-semibold mb-1">Access Denied</p>
            <p className="text-sm text-muted-foreground">
              {accessCheck.message || 'Your email is not assigned to any subscriber account. Contact your administrator to get set up.'}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Forced password reset gate — blocks all portal access until the rep sets a new password
  if (accessCheck.mustResetPassword) {
    return <ForcedPasswordReset onComplete={() => setAccessCheck({ loading: false, authorized: true, mustResetPassword: false })} />;
  }

  if (!rep) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card className="max-w-md w-full border-dashed">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
            <p className="font-semibold mb-1">No Rep Profile Found</p>
            <p className="text-sm text-muted-foreground">
              Your account ({user?.email}) hasn't been linked to a Sales Rep profile yet.
              Contact your admin to get set up.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-amber-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center text-primary font-bold text-lg">
              {rep.name?.charAt(0) || '?'}
            </div>
            <div>
              <h1 className="text-xl font-bold">Welcome back, {rep.name?.split(' ')[0]}!</h1>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <Badge variant="outline" className="capitalize text-xs">{rep.role?.replace(/_/g, ' ')}</Badge>
                {rep.territory && <Badge variant="outline" className="text-xs">{rep.territory}</Badge>}
                <Badge variant="outline" className={`text-xs ${rep.status === 'active' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : ''}`}>
                  {rep.status}
                </Badge>
              </div>
            </div>
          </div>
          {referralLink && (
            <div className="flex items-center gap-2 bg-background/60 border border-border rounded-lg px-3 py-2">
              <Link2 className="w-4 h-4 text-primary shrink-0" />
              <span className="text-xs text-muted-foreground truncate max-w-[220px]">{referralLink}</span>
              <Button size="sm" variant="ghost" className="h-7 px-2" onClick={copyLink}>
                <Copy className="w-3.5 h-3.5" />
              </Button>
            </div>
          )}
        </div>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="command" className="gap-1.5"><LayoutDashboard className="w-3.5 h-3.5" />Command Center</TabsTrigger>
          <TabsTrigger value="leads" className="gap-1.5"><Users className="w-3.5 h-3.5" />Leads ({leads.length})</TabsTrigger>
          <TabsTrigger value="lead_gen" className="gap-1.5"><Target className="w-3.5 h-3.5" />Lead Gen</TabsTrigger>
          <TabsTrigger value="tasks" className="gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5" />Tasks
          </TabsTrigger>
          <TabsTrigger value="appointments" className="gap-1.5"><Calendar className="w-3.5 h-3.5" />Appointments</TabsTrigger>
          <TabsTrigger value="referrals" className="gap-1.5"><Link2 className="w-3.5 h-3.5" />Referrals</TabsTrigger>
          <TabsTrigger value="documents" className="gap-1.5"><FileText className="w-3.5 h-3.5" />Documents</TabsTrigger>
          <TabsTrigger value="training" className="gap-1.5"><GraduationCap className="w-3.5 h-3.5" />Training</TabsTrigger>
          <TabsTrigger value="ai_tools" className="gap-1.5"><Sparkles className="w-3.5 h-3.5" />AI Tools</TabsTrigger>
        </TabsList>

        {/* COMMAND CENTER */}
        <TabsContent value="command" className="mt-4">
          <RepCommandCenter
            rep={rep}
            leads={leads}
            userEmail={user?.email}
            subscriberEmail={subscriberEmail}
            onGoToTasks={() => setTab('tasks')}
            onLeadClick={openDrawer}
          />
        </TabsContent>

        {/* LEADS */}
        <TabsContent value="leads" className="mt-4">
          <RepLeadsPanel
            leads={leads}
            rep={rep}
            userEmail={user?.email}
            subscriberEmail={subscriberEmail}
            onLeadClick={openDrawer}
          />
        </TabsContent>

        {/* LEAD GENERATOR */}
        <TabsContent value="lead_gen" className="mt-4">
          <RepLeadGenerator
            rep={rep}
            userEmail={user?.email}
            subscriberEmail={subscriberEmail}
            onLeadClick={openDrawer}
          />
        </TabsContent>

        {/* TASKS */}
        <TabsContent value="tasks" className="mt-4">
          <RepTasksPanel
            userEmail={user?.email}
            onLeadClick={openDrawer}
          />
        </TabsContent>

        {/* APPOINTMENTS */}
        <TabsContent value="appointments" className="mt-4 space-y-4">
          <RepCalendarSync />
          <RepAppointmentsPanel
            userEmail={user?.email}
            onLeadClick={openDrawer}
          />
        </TabsContent>

        {/* REFERRALS & COMMISSIONS */}
        <TabsContent value="referrals" className="mt-4 space-y-4">
          {referralLink && (
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="py-4 flex items-center gap-4 flex-wrap">
                <Link2 className="w-5 h-5 text-primary shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">Your Referral Link</p>
                  <p className="text-xs text-muted-foreground truncate">{referralLink}</p>
                </div>
                <Button onClick={copyLink} className="gap-2 shrink-0"><Copy className="w-4 h-4" />Copy Link</Button>
              </CardContent>
            </Card>
          )}

          <RepCommissionPanel commissions={commissions} />

          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="w-4 h-4" />All Referral Activity</CardTitle></CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Subscriber</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Commission</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {referrals.length === 0 && (
                    <TableRow><TableCell colSpan={6} className="text-center py-10 text-muted-foreground">No referrals tracked yet. Share your link to get started!</TableCell></TableRow>
                  )}
                  {referrals.map(r => (
                    <TableRow key={r.id}>
                      <TableCell className="text-sm">{r.subscriber_email}</TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px]">{r.plan_key}</Badge></TableCell>
                      <TableCell>${r.plan_amount || 0}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{r.signup_timestamp ? format(new Date(r.signup_timestamp), 'MMM d, yyyy') : '—'}</TableCell>
                      <TableCell className="font-semibold text-emerald-600">${r.commission_amount || 0}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`text-[10px] capitalize ${r.commission_status === 'approved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : r.commission_status === 'flagged' ? 'bg-red-500/10 text-red-600 border-red-500/20' : ''}`}>
                          {r.commission_status || 'pending'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* DOCUMENTS */}
        <TabsContent value="documents" className="mt-4">
          <RepDocumentsPanel rep={rep} />
        </TabsContent>

        {/* SALES TRAINING */}
        <TabsContent value="training" className="mt-4">
          <RepSalesTraining rep={rep} />
        </TabsContent>

        {/* AI SALES TOOLS */}
        <TabsContent value="ai_tools" className="mt-4">
          <RepAITools leads={leads} rep={rep} />
        </TabsContent>
      </Tabs>

      {/* Lead Detail Drawer */}
      <RepLeadDrawer
        lead={drawerLead}
        isOpen={!!drawerLead}
        onClose={() => setDrawerLead(null)}
      />
    </div>
  );
}