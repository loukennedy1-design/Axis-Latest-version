import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TrendingUp, Users, DollarSign, Brain, Zap, Target, 
  BarChart3, MessageSquare, FileText, CheckCircle2, 
  Loader2, Sparkles, ArrowUpRight, ArrowDownRight,
  Play, RefreshCcw, Plus, Search, Filter
} from 'lucide-react';
import { toast } from 'sonner';

export default function RevenueOperations() {
  const qc = useQueryClient();
  const [selectedLead, setSelectedLead] = useState(null);
  const [selectedOpp, setSelectedOpp] = useState(null);
  const [scoringId, setScoringId] = useState(null);
  const [forecastingId, setForecastingId] = useState(null);
  const [generatingDoc, setGeneratingDoc] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [docType, setDocType] = useState('proposal');
  const [customData, setCustomData] = useState('');

  // Fetch data
  const { data: leads = [] } = useQuery({ 
    queryKey: ['leads'], 
    queryFn: () => base44.entities.Lead.list('-created_date', 50) 
  });
  
  const { data: opportunities = [] } = useQuery({ 
    queryKey: ['opportunities'], 
    queryFn: () => base44.entities.Opportunity ? base44.entities.Opportunity.list('-created_date') : [] 
  });
  
  const { data: accountAgents = [] } = useQuery({ 
    queryKey: ['account-agents'], 
    queryFn: () => base44.entities.AccountAgent ? base44.entities.AccountAgent.list() : [] 
  });

  const { data: proposals = [] } = useQuery({ 
    queryKey: ['proposals'], 
    queryFn: () => base44.entities.Proposal ? base44.entities.Proposal.list() : [] 
  });

  // Subscriber & Trial Data
  const { data: trials = [] } = useQuery({ 
    queryKey: ['trials'], 
    queryFn: () => base44.entities.TrialInvite ? base44.entities.TrialInvite.list('-trial_start') : [] 
  });

  // AI Scoring Mutation
  const scoreLead = useMutation({
    mutationFn: async (lead_id) => {
      setScoringId(lead_id);
      const res = await base44.functions.invoke('aiRevenueEngine', { lead_id, action: 'score_lead' });
      setScoringId(null);
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['leads'] });
      toast.success(`Lead scored: ${data.score}/100 (${data.tier.toUpperCase()})`);
    },
    onError: (err) => {
      setScoringId(null);
      toast.error('Failed to score lead: ' + err.message);
    }
  });

  // AI Forecasting Mutation
  const forecastOpp = useMutation({
    mutationFn: async (opportunity_id) => {
      setForecastingId(opportunity_id);
      const res = await base44.functions.invoke('aiRevenueEngine', { opportunity_id, action: 'forecast_opportunity' });
      setForecastingId(null);
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['opportunities'] });
      toast.success(`Forecast updated: ${data.forecast.probability}% probability`);
    },
    onError: (err) => {
      setForecastingId(null);
      toast.error('Failed to forecast: ' + err.message);
    }
  });

  // Document Generation Mutation
  const generateDoc = useMutation({
    mutationFn: async ({ opportunity_id, document_type, custom_data }) => {
      setGeneratingDoc(document_type);
      const res = await base44.functions.invoke('aiDocumentGeneration', { 
        opportunity_id, 
        document_type,
        custom_data 
      });
      setGeneratingDoc(null);
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['proposals', 'opportunities'] });
      setDialogOpen(false);
      toast.success(`${docType.toUpperCase()} generated successfully`);
    },
    onError: (err) => {
      setGeneratingDoc(null);
      toast.error('Failed to generate: ' + err.message);
    }
  });

  // KPI Calculations
  const totalPipeline = opportunities.reduce((sum, o) => sum + (o.amount || 0), 0);
  const weightedPipeline = opportunities.reduce((sum, o) => sum + (o.amount || 0) * ((o.ai_forecast_score || o.probability || 0) / 100), 0);
  const avgDealSize = opportunities.length > 0 ? totalPipeline / opportunities.length : 0;
  const winRate = opportunities.filter(o => o.stage === 'closed_won').length / (opportunities.filter(o => ['closed_won', 'closed_lost'].includes(o.stage)).length || 1) * 100;

  // Subscriber Metrics
  const activeTrials = trials.filter(t => t.status === 'active');
  const convertedTrials = trials.filter(t => t.status === 'converted');
  const expiredTrials = trials.filter(t => t.status === 'expired');
  const pendingTrials = trials.filter(t => t.status === 'pending');
  const totalMRR = activeTrials.reduce((sum, t) => sum + (t.billing_amount || 0), 0);
  const trialsExpiringSoon = activeTrials.filter(t => {
    const endDate = t.trial_end ? new Date(t.trial_end) : null;
    return endDate && endDate <= new Date(new Date().getTime() + 3 * 24 * 60 * 60 * 1000) && endDate > new Date();
  });

  const openDocDialog = (opp, type) => {
    setSelectedOpp(opp);
    setDocType(type);
    setCustomData('');
    setDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Brain className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">AI Revenue Operations</h1>
            <p className="text-muted-foreground">AI-driven sales intelligence and automation</p>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Pipeline</p>
                <p className="text-2xl font-bold">${totalPipeline.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground mt-1">Weighted: ${Math.round(weightedPipeline).toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Opportunities</p>
                <p className="text-2xl font-bold">{opportunities.length}</p>
                <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1">
                  <ArrowUpRight className="w-3 h-3" />
                  {opportunities.filter(o => o.stage === 'closed_won').length} won
                </p>
              </div>
              <Target className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Deal Size</p>
                <p className="text-2xl font-bold">${Math.round(avgDealSize).toLocaleString()}</p>
                <p className="text-xs text-muted-foreground mt-1">Win rate: {Math.round(winRate)}%</p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Account Agents</p>
                <p className="text-2xl font-bold">{accountAgents.length}</p>
                <p className="text-xs text-emerald-600 mt-1">
                  {accountAgents.filter(a => a.engagement_level === 'high').length} highly engaged
                </p>
              </div>
              <Users className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Trials</p>
                <p className="text-2xl font-bold">{activeTrials.length}</p>
                <p className="text-xs text-amber-600 mt-1 flex items-center gap-1">
                  <ArrowUpRight className="w-3 h-3" />
                  {trialsExpiringSoon.length} expiring in 3 days
                </p>
              </div>
              <Users className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Monthly Revenue</p>
                <p className="text-2xl font-bold">${Math.round(totalMRR).toLocaleString()}</p>
                <p className="text-xs text-emerald-600 mt-1">
                  {convertedTrials.length} converted subscribers
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Lead Scoring */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5 text-primary" />
              AI Lead Prioritization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {leads.slice(0, 8).map(lead => (
                <div key={lead.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{lead.first_name} {lead.last_name}</p>
                    <p className="text-xs text-muted-foreground">{lead.company || 'No company'}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {lead.status}
                    </Badge>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => scoreLead.mutate(lead.id)}
                      disabled={scoringId === lead.id}
                    >
                      {scoringId === lead.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-primary" />
                      )}
                    </Button>
                  </div>
                </div>
              ))}
              {leads.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">No leads found</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* AI Opportunity Forecasting */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-primary" />
              AI Conversion Forecasting
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {opportunities.slice(0, 8).map(opp => (
                <div key={opp.id} className="p-3 rounded-lg border bg-card">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{opp.name}</p>
                      <p className="text-xs text-muted-foreground">{opp.account_name}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">${opp.amount?.toLocaleString() || '0'}</p>
                      <p className="text-xs text-muted-foreground">
                        AI Score: {opp.ai_forecast_score || opp.probability || 0}%
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {opp.stage.replace('_', ' ')}
                    </Badge>
                    <Badge 
                      className={`text-xs ${
                        (opp.ai_forecast_score || opp.probability || 0) >= 70 
                          ? 'bg-emerald-500/10 text-emerald-600' 
                          : (opp.ai_forecast_score || opp.probability || 0) >= 40
                          ? 'bg-amber-500/10 text-amber-600'
                          : 'bg-red-500/10 text-red-600'
                      }`}
                    >
                      {opp.forecast_category || 'pipeline'}
                    </Badge>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => forecastOpp.mutate(opp.id)}
                      disabled={forecastingId === opp.id}
                    >
                      {forecastingId === opp.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <RefreshCcw className="w-4 h-4" />
                      )}
                    </Button>
                    <Dialog open={dialogOpen && selectedOpp?.id === opp.id} onOpenChange={setDialogOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm" variant="outline" onClick={() => openDocDialog(opp, 'proposal')}>
                          <FileText className="w-4 h-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Generate {docType}</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="flex gap-2">
                            <Button 
                              variant={docType === 'proposal' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => setDocType('proposal')}
                            >
                              Proposal
                            </Button>
                            <Button 
                              variant={docType === 'quote' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => setDocType('quote')}
                            >
                              Quote
                            </Button>
                            <Button 
                              variant={docType === 'contract' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => setDocType('contract')}
                            >
                              Contract
                            </Button>
                          </div>
                          <Textarea
                            placeholder="Add custom requirements or notes (optional)..."
                            value={customData}
                            onChange={(e) => setCustomData(e.target.value)}
                            className="h-24"
                          />
                          <Button
                            className="w-full"
                            onClick={() => generateDoc.mutate({
                              opportunity_id: opp.id,
                              document_type: docType,
                              custom_data: customData
                            })}
                            disabled={generatingDoc === docType}
                          >
                            {generatingDoc === docType ? (
                              <>
                                <Loader2 className="w-4 h-4 animate-spin mr-2" />
                                Generating...
                              </>
                            ) : (
                              <>
                                <Zap className="w-4 h-4 mr-2" />
                                Generate with AI
                              </>
                            )}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              ))}
              {opportunities.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">No opportunities found</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Subscriber Data */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            Subscriber & Trial Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="active" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="active">Active ({activeTrials.length})</TabsTrigger>
              <TabsTrigger value="expiring">Expiring Soon ({trialsExpiringSoon.length})</TabsTrigger>
              <TabsTrigger value="converted">Converted ({convertedTrials.length})</TabsTrigger>
              <TabsTrigger value="all">All Trials ({trials.length})</TabsTrigger>
            </TabsList>

            <TabsContent value="active" className="mt-4">
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {activeTrials.map(trial => (
                  <div key={trial.id} className="p-3 rounded-lg border bg-card">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{trial.name || trial.email}</p>
                        <p className="text-xs text-muted-foreground">{trial.email}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Trial ends: {trial.trial_end ? new Date(trial.trial_end).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-emerald-500/10 text-emerald-600">Active</Badge>
                        <p className="text-xs font-semibold mt-2">${trial.billing_amount || 0}/{trial.billing_cycle === 'yearly' ? 'yr' : 'mo'}</p>
                        <p className="text-xs text-muted-foreground capitalize">{trial.plan_key || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {activeTrials.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No active trials</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="expiring" className="mt-4">
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {trialsExpiringSoon.map(trial => (
                  <div key={trial.id} className="p-3 rounded-lg border bg-card border-amber-500/50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{trial.name || trial.email}</p>
                        <p className="text-xs text-muted-foreground">{trial.email}</p>
                        <p className="text-xs text-amber-600 font-medium mt-1">
                          ⚠️ Expires: {trial.trial_end ? new Date(trial.trial_end).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-amber-500/10 text-amber-600">Expiring Soon</Badge>
                        <p className="text-xs font-semibold mt-2">${trial.billing_amount || 0}/{trial.billing_cycle === 'yearly' ? 'yr' : 'mo'}</p>
                        <p className="text-xs text-muted-foreground capitalize">{trial.plan_key || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {trialsExpiringSoon.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No trials expiring in the next 3 days</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="converted" className="mt-4">
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {convertedTrials.map(trial => (
                  <div key={trial.id} className="p-3 rounded-lg border bg-card">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{trial.name || trial.email}</p>
                        <p className="text-xs text-muted-foreground">{trial.email}</p>
                        <p className="text-xs text-emerald-600 mt-1">
                          ✓ Converted on {trial.trial_start ? new Date(trial.trial_start).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className="bg-emerald-500/10 text-emerald-600">Converted</Badge>
                        <p className="text-xs font-semibold mt-2">${trial.billing_amount || 0}/{trial.billing_cycle === 'yearly' ? 'yr' : 'mo'}</p>
                        <p className="text-xs text-muted-foreground capitalize">{trial.plan_key || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {convertedTrials.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No converted subscribers</p>
                )}
              </div>
            </TabsContent>

            <TabsContent value="all" className="mt-4">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {trials.map(trial => (
                  <div key={trial.id} className="p-3 rounded-lg border bg-card">
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{trial.name || trial.email}</p>
                        <p className="text-xs text-muted-foreground">{trial.email}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {trial.trial_start ? new Date(trial.trial_start).toLocaleDateString() : 'N/A'} - 
                          {trial.trial_end ? new Date(trial.trial_end).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge 
                          className={
                            trial.status === 'active' ? 'bg-emerald-500/10 text-emerald-600' :
                            trial.status === 'converted' ? 'bg-blue-500/10 text-blue-600' :
                            trial.status === 'expired' ? 'bg-red-500/10 text-red-600' :
                            'bg-gray-500/10 text-gray-600'
                          }
                        >
                          {trial.status}
                        </Badge>
                        <p className="text-xs font-semibold mt-2">${trial.billing_amount || 0}/{trial.billing_cycle === 'yearly' ? 'yr' : 'mo'}</p>
                        <p className="text-xs text-muted-foreground capitalize">{trial.plan_key || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {trials.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">No trial records found</p>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Account Agents */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5 text-primary" />
            AI Account Agents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-3">Account</th>
                  <th className="text-left py-2 px-3">Lifecycle Stage</th>
                  <th className="text-left py-2 px-3">Engagement</th>
                  <th className="text-left py-2 px-3">Conversion Prob.</th>
                  <th className="text-left py-2 px-3">Next Action</th>
                </tr>
              </thead>
              <tbody>
                {accountAgents.slice(0, 10).map(agent => (
                  <tr key={agent.id} className="border-b last:border-0">
                    <td className="py-3 px-3 font-medium">{agent.account_name}</td>
                    <td className="py-3 px-3">
                      <Badge variant="outline" className="text-xs">
                        {agent.lifecycle_stage}
                      </Badge>
                    </td>
                    <td className="py-3 px-3">
                      <Badge 
                        className={`text-xs ${
                          agent.engagement_level === 'high' ? 'bg-emerald-500/10 text-emerald-600' :
                          agent.engagement_level === 'medium' ? 'bg-amber-500/10 text-amber-600' :
                          'bg-red-500/10 text-red-600'
                        }`}
                      >
                        {agent.engagement_level}
                      </Badge>
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${agent.conversion_probability || 0}%` }}
                          />
                        </div>
                        <span className="text-xs">{agent.conversion_probability || 0}%</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-muted-foreground">
                      {agent.recommended_action || 'No recommendation'}
                    </td>
                  </tr>
                ))}
                {accountAgents.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-muted-foreground">
                      No account agents configured
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}