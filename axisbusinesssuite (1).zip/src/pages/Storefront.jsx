import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Store, ShoppingCart, Calendar, Award, Search, Package, Check, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

export default function Storefront() {
  const { slug } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [cart, setCart] = useState([]);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [loyaltyOpen, setLoyaltyOpen] = useState(false);

  useEffect(() => {
    base44.functions.invoke('publicStorefront', { slug })
      .then(res => { setData(res.data); setLoading(false); })
      .catch(err => { setError(err.response?.data?.error || 'Store not found'); setLoading(false); });
  }, [slug]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Loading storefront...</div></div>;
  if (error || !data) return <div className="min-h-screen flex flex-col items-center justify-center gap-3"><Store className="w-12 h-12 text-muted-foreground" /><p className="text-xl font-semibold">Store Not Found</p><p className="text-muted-foreground">The storefront "{slug}" doesn't exist.</p><a href="/" className="text-primary hover:underline">Go Home</a></div>;

  const addToCart = (item) => {
    setCart(prev => {
      const existing = prev.find(c => c.item_id === item.id);
      if (existing) return prev.map(c => c.item_id === item.id ? { ...c, quantity: c.quantity + 1 } : c);
      return [...prev, { item_id: item.id, sku: item.sku, name: item.item_name, quantity: 1, unit_price: item.store_price || 0 }];
    });
    toast.success(`${item.item_name} added to cart`);
  };

  const cartTotal = cart.reduce((s, c) => s + c.unit_price * c.quantity, 0);

  const handleCheckout = async (customerInfo) => {
    try {
      const res = await base44.functions.invoke('storefrontOrder', { slug, ...customerInfo, line_items: cart });
      toast.success(`Order placed! Order #${res.data.order_number}`);
      setCart([]);
      setCheckoutOpen(false);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Checkout failed');
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur z-10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Store className="w-6 h-6 text-primary" />
            <span className="text-lg font-bold">{data.company_name}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setLoyaltyOpen(true)}><Award className="w-4 h-4 mr-1" />Rewards</Button>
            <Button variant="ghost" size="sm" onClick={() => setBookingOpen(true)}><Calendar className="w-4 h-4 mr-1" />Book</Button>
            {cart.length > 0 && (
              <Button size="sm" onClick={() => setCheckoutOpen(true)}><ShoppingCart className="w-4 h-4 mr-1" />{cart.length} · ${cartTotal.toFixed(2)}</Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="bg-gradient-to-br from-primary/10 via-card to-primary/5 py-12 text-center">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl font-bold mb-2">{data.company_name}</h1>
          <p className="text-muted-foreground">Quality products and services for you</p>
        </div>
      </div>

      {/* Products */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold mb-4">Products</h2>
        {data.products.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground"><Package className="w-10 h-10 mx-auto mb-2 opacity-40" />No products available yet</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {data.products.map(p => (
              <Card key={p.id} className="overflow-hidden flex flex-col">
                <div className="aspect-square bg-muted overflow-hidden">
                  {p.store_image_url ? <img src={p.store_image_url} alt={p.item_name} className="w-full h-full object-cover" /> : <Package className="w-10 h-10 text-muted-foreground m-auto mt-[45%]" />}
                </div>
                <CardContent className="p-3 flex-1 flex flex-col">
                  <p className="font-semibold text-sm line-clamp-2">{p.item_name}</p>
                  {p.store_description && <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{p.store_description}</p>}
                  <div className="mt-auto pt-2">
                    <p className="font-bold text-lg">${(p.store_price || 0).toFixed(2)}</p>
                    {p.quantity_on_hand <= 0 ? <Badge variant="outline" className="text-red-500">Out of Stock</Badge> : <Button size="sm" className="w-full mt-1" onClick={() => addToCart(p)} disabled={p.quantity_on_hand <= 0}><ShoppingCart className="w-3.5 h-3.5 mr-1" />Add</Button>}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Bundles */}
        {data.bundles.length > 0 && (
          <>
            <h2 className="text-2xl font-bold mt-8 mb-4">Bundles & Deals</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data.bundles.map(b => (
                <Card key={b.id} className="p-5">
                  {b.store_image_url && <img src={b.store_image_url} alt={b.bundle_name} className="w-full h-32 object-cover rounded-lg mb-3" />}
                  <h3 className="font-semibold">{b.bundle_name}</h3>
                  {b.description && <p className="text-xs text-muted-foreground mt-1">{b.description}</p>}
                  <div className="flex items-center justify-between mt-3">
                    <span className="font-bold text-lg">${(b.bundle_price || 0).toFixed(2)}</span>
                    <Button size="sm" onClick={() => addToCart({ id: b.id, sku: b.bundle_sku, item_name: b.bundle_name, store_price: b.bundle_price })}><ShoppingCart className="w-3.5 h-3.5 mr-1" />Add</Button>
                  </div>
                </Card>
              ))}
            </div>
          </>
        )}
      </main>

      <CheckoutDialog open={checkoutOpen} onClose={() => setCheckoutOpen(false)} cart={cart} total={cartTotal} onCheckout={handleCheckout} />
      <BookingDialog open={bookingOpen} onClose={() => setBookingOpen(false)} slug={slug} availability={data.availability} />
      <LoyaltyDialog open={loyaltyOpen} onClose={() => setLoyaltyOpen(false)} slug={slug} />
    </div>
  );
}

function CheckoutDialog({ open, onClose, cart, total, onCheckout }) {
  const [form, setForm] = useState({ customer_name: '', customer_email: '', customer_phone: '' });
  const [submitting, setSubmitting] = useState(false);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Checkout</DialogTitle></DialogHeader>
        <div className="space-y-3">
          {cart.map((c, i) => <div key={i} className="flex justify-between text-sm"><span>{c.name} × {c.quantity}</span><span>${(c.unit_price * c.quantity).toFixed(2)}</span></div>)}
          <div className="border-t pt-2 flex justify-between font-bold"><span>Total</span><span>${total.toFixed(2)}</span></div>
          <Input placeholder="Full Name" value={form.customer_name} onChange={e => setForm({ ...form, customer_name: e.target.value })} />
          <Input type="email" placeholder="Email" value={form.customer_email} onChange={e => setForm({ ...form, customer_email: e.target.value })} />
          <Input placeholder="Phone" value={form.customer_phone} onChange={e => setForm({ ...form, customer_phone: e.target.value })} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button disabled={submitting || !form.customer_name || !form.customer_email} onClick={async () => { setSubmitting(true); await onCheckout(form); setSubmitting(false); }}><Check className="w-4 h-4 mr-1" />Place Order</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function BookingDialog({ open, onClose, slug, availability }) {
  const [form, setForm] = useState({ name: '', email: '', phone: '', slot: '' });
  const [submitting, setSubmitting] = useState(false);
  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const enabledDays = availability?.days?.filter(d => d.enabled) || [];

  const generateSlots = () => {
    if (!form.day) return [];
    const dayCfg = enabledDays.find(d => d.day === form.day);
    if (!dayCfg || !dayCfg.start || !dayCfg.end) return [];
    const slots = [];
    let [h, m] = dayCfg.start.split(':').map(Number);
    const [endH, endM] = dayCfg.end.split(':').map(Number);
    const dur = availability.duration_minutes || 30;
    while (h < endH || (h === endH && m < endM)) {
      slots.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
      m += dur;
      while (m >= 60) { m -= 60; h++; }
    }
    return slots;
  };

  const handleBook = async () => {
    if (!form.name || !form.email || !form.date || !form.slot) { toast.error('Please fill all fields'); return; }
    setSubmitting(true);
    try {
      const slot = new Date(form.date + 'T' + form.slot);
      await base44.functions.invoke('publicBooking', { slug, customer_name: form.name, customer_email: form.email, customer_phone: form.phone, preferred_slot: slot.toISOString() });
      toast.success('Appointment booked! Check your email for confirmation.');
      onClose();
      setForm({ name: '', email: '', phone: '', slot: '' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Booking failed');
    }
    setSubmitting(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Book an Appointment</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Input placeholder="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <Input type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          <Input placeholder="Phone" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
          {enabledDays.length > 0 ? (
            <>
              <select className="w-full border rounded-md p-2 text-sm bg-transparent" value={form.day || ''} onChange={e => setForm({ ...form, day: e.target.value })}>
                <option value="">Select a day...</option>
                {enabledDays.map(d => <option key={d.day} value={d.day}>{d.day.charAt(0).toUpperCase() + d.day.slice(1)} ({d.start}–{d.end})</option>)}
              </select>
              <Input type="date" value={form.date || ''} onChange={e => setForm({ ...form, date: e.target.value })} />
              {form.day && form.date && generateSlots().length > 0 && (
                <div className="grid grid-cols-3 gap-2">
                  {generateSlots().map(s => <Button key={s} variant={form.slot === s ? 'default' : 'outline'} size="sm" onClick={() => setForm({ ...form, slot: s })}>{s}</Button>)}
                </div>
              )}
            </>
          ) : <p className="text-sm text-muted-foreground">No availability configured. Please call to book.</p>}
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Cancel</Button><Button disabled={submitting} onClick={handleBook}><Calendar className="w-4 h-4 mr-1" />Confirm Booking</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function LoyaltyDialog({ open, onClose, slug }) {
  const [email, setEmail] = useState('');
  const [result, setResult] = useState(null);

  const lookup = async () => {
    try {
      const res = await base44.functions.invoke('publicStorefront', { slug });
      // Use customer portal to look up by token — but for public lookup we need a different approach
      // For now, just show a placeholder
      setResult({ message: 'Loyalty lookup available after placing an order. Your portal link will be emailed to you.' });
    } catch (e) { toast.error('Lookup failed'); }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle><Award className="w-5 h-5 inline mr-2" />Loyalty & Rewards</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <p className="text-sm text-muted-foreground">Earn points on every purchase! 1 point = $1 spent. Reach Silver (500 pts) or Gold (2000 pts) for exclusive perks.</p>
          <div className="flex gap-2">
            <div className="flex-1 grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-lg bg-amber-700/10 border border-amber-700/20"><Star className="w-4 h-4 mx-auto text-amber-600" /><p className="text-xs font-semibold mt-1">Bronze</p><p className="text-[10px] text-muted-foreground">0+ pts</p></div>
              <div className="p-2 rounded-lg bg-slate-400/10 border border-slate-400/20"><Star className="w-4 h-4 mx-auto text-slate-400" /><p className="text-xs font-semibold mt-1">Silver</p><p className="text-[10px] text-muted-foreground">500+ pts</p></div>
              <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20"><Star className="w-4 h-4 mx-auto text-amber-500" /><p className="text-xs font-semibold mt-1">Gold</p><p className="text-[10px] text-muted-foreground">2000+ pts</p></div>
            </div>
          </div>
          {result && <p className="text-xs text-muted-foreground p-3 rounded-lg bg-muted/30">{result.message}</p>}
        </div>
        <DialogFooter><Button variant="outline" onClick={onClose}>Close</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}