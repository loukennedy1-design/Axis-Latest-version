import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Mail, ArrowRight, Clock, CreditCard } from 'lucide-react';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';

export default function CheckoutConfirmation() {
  const params = new URLSearchParams(window.location.search);
  const plan = params.get('plan') || 'Axis Business Suite';
  const total = params.get('total') || '';
  const processor = params.get('processor') || 'converge';
  const email = params.get('email');

  // Converge (Elavon) appends the transaction response to the receipt link.
  // ssl_result = 0  → approved; anything else → declined/error.
  const convergeResult = params.get('ssl_result');
  const convergeMessage = params.get('ssl_result_message');
  const convergeTxnId = params.get('ssl_txn_id');
  const convergeApproval = params.get('ssl_approval_code');
  const convergeToken = params.get('ssl_token');

  const isConverge = processor === 'converge';
  // Converge "approved" is ssl_result === '0'. Absent ssl_result means the user
  // landed here without a Converge response (treat as pending).
  const convergeSuccess = isConverge && convergeResult === '0';
  const convergeDeclined = isConverge && convergeResult !== null && convergeResult !== '0';

  const [activating, setActivating] = useState(false);

  // Activate the trial on the backend once Converge confirms the card. The
  // backend re-verifies the transaction with Converge before unlocking the
  // account, so the URL params alone can't grant access.
  useEffect(() => {
    if (!isConverge || !email || convergeResult === null) return;
    setActivating(true);
    base44.functions.invoke('activateTrialFromCheckout', {
      email,
      ssl_result: convergeResult,
      ssl_txn_id: convergeTxnId || '',
      ssl_token: convergeToken || '',
    })
      .catch((err) => console.warn('activateTrialFromCheckout failed:', err.message))
      .finally(() => setActivating(false));
  }, [isConverge, email, convergeResult, convergeTxnId, convergeToken]);

  // Auto-redirect to app after 5 seconds (only on a successful/pending outcome)
  useEffect(() => {
    if (convergeDeclined) return;
    const timer = setTimeout(() => {
      window.location.href = '/app';
    }, 5000);
    return () => clearTimeout(timer);
  }, [convergeDeclined]);

  const processorLabel = 'Converge (Elavon)';

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-lg space-y-6">
        {/* Success / Decline Header */}
        <div className="text-center space-y-2">
          <div className="flex justify-center">
            {convergeDeclined ? (
              <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center">
                <XCircle className="w-9 h-9 text-red-500" />
              </div>
            ) : (
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <CheckCircle2 className="w-9 h-9 text-emerald-500" />
              </div>
            )}
          </div>
          <h1 className="text-2xl font-bold">
            {convergeDeclined ? 'Payment Could Not Be Completed' : "You're Almost In!"}
          </h1>
          <p className="text-muted-foreground text-sm">
            {convergeDeclined
              ? 'Your card was declined by Converge. No charge was made — please try a different card.'
              : isConverge
                ? 'Your card was verified securely through Converge. Check your email to activate your account.'
                : `Complete your checkout on ${processorLabel}, then check your email to activate your account.`}
          </p>
        </div>

        {/* Converge transaction result detail */}
        {isConverge && convergeResult !== null && (
          <Card className={convergeSuccess ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-red-500/30 bg-red-500/5'}>
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-primary" />
                <CardTitle className="text-base">Converge Transaction</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Status</span>
                <Badge variant="outline" className={convergeSuccess ? 'text-emerald-600 border-emerald-500/30 bg-emerald-500/10' : 'text-red-600 border-red-500/30 bg-red-500/10'}>
                  {convergeMessage || (convergeSuccess ? 'APPROVED' : 'DECLINED')}
                </Badge>
              </div>
              {convergeTxnId && (
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Transaction ID</span>
                  <span className="font-mono text-xs">{convergeTxnId}</span>
                </div>
              )}
              {convergeApproval && (
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Approval Code</span>
                  <span className="font-mono text-xs">{convergeApproval}</span>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Order Summary */}
        {(plan || total) && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-medium">{plan}</span>
                <Badge variant="outline" className={convergeDeclined ? 'text-red-600 border-red-500/30 bg-red-500/10' : 'text-amber-600 border-amber-500/30 bg-amber-500/10'}>
                  {convergeDeclined ? 'Payment Failed' : 'Pending Activation'}
                </Badge>
              </div>
              {total && (
                <div className="flex items-center justify-between pt-2 border-t font-bold">
                  <span>Total</span>
                  <span className="text-primary">${total}</span>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Next Steps — only when not declined */}
        {!convergeDeclined && (
          <Card className="border-blue-500/30 bg-blue-500/5">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-500" />
                <CardTitle className="text-base text-blue-700 dark:text-blue-400">Next Steps</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">1</div>
                  <div>
                    <p className="text-sm font-semibold">{isConverge ? 'Card verified securely' : `Complete your ${processorLabel} checkout`}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {isConverge
                        ? 'Your card was verified through Converge (Elavon). $0 was charged today — billing starts after your 7-day trial.'
                        : `If you were redirected here before completing payment, go back and finish the checkout on the ${processorLabel} page.`}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">2</div>
                  <div>
                    <p className="text-sm font-semibold">Check your email inbox</p>
                    <p className="text-xs text-muted-foreground mt-0.5">You'll receive an invitation email to set your password and activate your Axis Business Suite account.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">3</div>
                  <div>
                    <p className="text-sm font-semibold">Log in and get started</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Once you set your password, you'll have full access to your dashboard.</p>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2 text-xs text-blue-700 dark:text-blue-400 pt-2 border-t border-blue-500/20">
                <Mail className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                <span>Don't see the email? Check your spam folder or contact <strong>support@axisbusiness.com</strong></span>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex gap-3">
          {convergeDeclined ? (
            <>
              <Button asChild className="flex-1" variant="outline">
                <a href="/">← Back to Home</a>
              </Button>
              <Button asChild className="flex-1">
                <Link to="/pricing">Try Again <ArrowRight className="w-4 h-4 ml-1" /></Link>
              </Button>
            </>
          ) : (
            <>
              <Button asChild className="flex-1" variant="outline">
                <a href="/">← Back to Home</a>
              </Button>
              <Button asChild className="flex-1">
                <Link to="/app">Go to Dashboard <ArrowRight className="w-4 h-4 ml-1" /></Link>
              </Button>
              <p className="text-center text-xs text-muted-foreground mt-2">
                Redirecting to dashboard in 5 seconds...
              </p>
            </>
          )}
        </div>
        <p className="text-center text-xs text-muted-foreground">
          Need help? <a href="mailto:support@axisbusiness.com" className="underline hover:text-foreground">support@axisbusiness.com</a>
        </p>
      </div>
    </div>
  );
}