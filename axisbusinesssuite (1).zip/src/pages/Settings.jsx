import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { 
  Settings as SettingsIcon, Palette, LayoutDashboard, Bell,
  Moon, Sun, Monitor, Building2, Save, RotateCcw,
  ChevronRight, Sparkles, ExternalLink, CreditCard, Plug, Info, Mail
} from 'lucide-react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import EmailAccountManager from '@/components/email/EmailAccountManager';
import SidebarCustomizer from '@/components/settings/SidebarCustomizer';
import ConvergePaymentSettings from '@/components/settings/ConvergePaymentSettings';
import ConnectionsTab from '@/components/settings/ConnectionsTab';
import IntegrationWizard from '@/components/connections/IntegrationWizard';
import ProviderHealthDashboard from '@/components/settings/ProviderHealthDashboard';
import { Phone as PhoneIcon } from 'lucide-react';
import { INDUSTRIES } from '@/lib/industries';

// Small (ℹ) tooltip showing the technical field name for power users
function TechTooltip({ technical }) {
  return (
    <span className="group relative inline-flex align-middle ml-1">
      <Info className="w-3 h-3 text-muted-foreground cursor-help" />
      <span className="absolute left-4 top-0 hidden group-hover:block z-10 bg-popover border border-border rounded-md px-2 py-1 text-[10px] whitespace-nowrap shadow-lg">
        {technical}
      </span>
    </span>
  );
}

// Industries are imported from @/lib/industries (shared registry).

const TIMEZONES = [
  { value: 'America/New_York', label: 'Eastern Time (ET)' },
  { value: 'America/Chicago', label: 'Central Time (CT)' },
  { value: 'America/Denver', label: 'Mountain Time (MT)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
  { value: 'America/Anchorage', label: 'Alaska Time (AKT)' },
  { value: 'Pacific/Honolulu', label: 'Hawaii Time (HT)' },
  { value: 'Europe/London', label: 'London (GMT)' },
  { value: 'Europe/Paris', label: 'Paris (CET)' },
  { value: 'Asia/Tokyo', label: 'Tokyo (JST)' },
  { value: 'Asia/Shanghai', label: 'Shanghai (CST)' },
  { value: 'Australia/Sydney', label: 'Sydney (AEST)' },
];

export default function Settings() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState('business');
  const [wizardOpen, setWizardOpen] = useState(false);
  
  // Local state for general settings form (now includes industry — "Your Business" tab)
  const [generalForm, setGeneralForm] = useState(null);

  // Local state for UI preferences
  const [uiSettings, setUiSettings] = useState({
    theme: 'system',
    sidebarCollapsed: false,
    compactMode: false,
    showAnimations: true,
    notificationsEnabled: true,
    emailNotifications: true,
    dashboardLayout: 'grid',
    itemsPerPage: 25,
  });
  const [uiInitialized, setUiInitialized] = useState(false);

  // Fetch system settings via backend function (bypasses RLS issues)
  const { data: systemSettings, isLoading } = useQuery({
    queryKey: ['system-settings', user?.email],
    queryFn: async () => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'get' });
      return res.data?.settings || null;
    },
    enabled: !!user?.email,
  });

  // Initialize all forms when settings load — always sync from server data
  useEffect(() => {
    if (systemSettings) {
      setGeneralForm({
        company_name: systemSettings.company_name || '',
        default_timezone: systemSettings.default_timezone || 'America/New_York',
        industry: systemSettings.industry || '',
      });
      if (!uiInitialized) {
        setUiSettings({
          theme: systemSettings.ui_theme || 'system',
          sidebarCollapsed: systemSettings.ui_sidebar_collapsed || false,
          compactMode: systemSettings.ui_compact_mode || false,
          showAnimations: systemSettings.ui_show_animations !== false,
          notificationsEnabled: systemSettings.ui_notifications_enabled !== false,
          emailNotifications: systemSettings.email_notifications !== false,
          dashboardLayout: systemSettings.ui_dashboard_layout || 'grid',
          itemsPerPage: systemSettings.ui_items_per_page || 25,
        });
        setUiInitialized(true);
      }
    } else if (systemSettings === null) {
      setGeneralForm({ company_name: '', default_timezone: 'America/New_York', industry: '' });
    }
  }, [systemSettings]);

  // Update system settings via backend function
  const updateSettingsMutation = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'save', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success('Settings saved successfully');
    },
    onError: (error) => {
      toast.error('Failed to save settings: ' + error.message);
    },
  });

  // One unified payload covering General + Interface + Notifications so any
  // save button persists the full current state — no need to re-save each tab.
  const buildAllPayload = (ui = uiSettings) => ({
    company_name: generalForm?.company_name || '',
    default_timezone: generalForm?.default_timezone || 'America/New_York',
    industry: generalForm?.industry || systemSettings?.industry || '',
    ui_theme: ui.theme,
    ui_sidebar_collapsed: ui.sidebarCollapsed,
    ui_compact_mode: ui.compactMode,
    ui_show_animations: ui.showAnimations,
    ui_notifications_enabled: ui.notificationsEnabled,
    email_notifications: ui.emailNotifications,
    ui_dashboard_layout: ui.dashboardLayout,
    ui_items_per_page: ui.itemsPerPage,
  });

  const handleSaveAll = () => {
    updateSettingsMutation.mutate(buildAllPayload());
    window.dispatchEvent(new CustomEvent('axis-theme-change', { detail: uiSettings }));
  };

  const handleReconfigureIndustry = () => {
    window.location.href = '/industry-onboarding';
  };

  const handleResetUI = () => {
    const defaults = {
      theme: 'system',
      sidebarCollapsed: false,
      compactMode: false,
      showAnimations: true,
      notificationsEnabled: true,
      emailNotifications: true,
      dashboardLayout: 'grid',
      itemsPerPage: 25,
    };
    setUiSettings(defaults);
    updateSettingsMutation.mutate({
      ui_theme: defaults.theme,
      ui_sidebar_collapsed: defaults.sidebarCollapsed,
      ui_compact_mode: defaults.compactMode,
      ui_show_animations: defaults.showAnimations,
      ui_notifications_enabled: defaults.notificationsEnabled,
      email_notifications: defaults.emailNotifications,
      ui_dashboard_layout: defaults.dashboardLayout,
      ui_items_per_page: defaults.itemsPerPage,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your account, UI preferences, and system configuration</p>
        </div>
        <Button onClick={handleSaveAll} disabled={updateSettingsMutation.isPending} className="gap-2">
          <Save className="w-4 h-4" />
          {updateSettingsMutation.isPending ? 'Saving...' : 'Save All Settings'}
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 sm:grid-cols-8 lg:w-auto lg:inline-grid">
          <TabsTrigger value="business" className="gap-2">
            <Building2 className="w-4 h-4" />
            <span className="hidden sm:inline">Your Business</span>
          </TabsTrigger>
          <TabsTrigger value="email" className="gap-2">
            <Mail className="w-4 h-4" />
            <span className="hidden sm:inline">Email</span>
          </TabsTrigger>
          <TabsTrigger value="modules" className="gap-2">
            <LayoutDashboard className="w-4 h-4" />
            <span className="hidden sm:inline">Sidebar</span>
          </TabsTrigger>
          <TabsTrigger value="ui" className="gap-2">
            <Palette className="w-4 h-4" />
            <span className="hidden sm:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="calling" className="gap-2">
            <PhoneIcon className="w-4 h-4" />
            <span className="hidden sm:inline">Calling</span>
          </TabsTrigger>
          <TabsTrigger value="connections" className="gap-2">
            <Plug className="w-4 h-4" />
            <span className="hidden sm:inline">Connections</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2">
            <Bell className="w-4 h-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          {(user?.role === 'admin' || user?.role === 'super_admin') && (
            <TabsTrigger value="payments" className="gap-2">
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Subscription Billing</span>
            </TabsTrigger>
          )}
        </TabsList>

        {/* Sidebar Module Customizer */}
        <TabsContent value="modules" className="space-y-4">
          <p className="text-sm text-muted-foreground">Choose which modules appear in your sidebar — show only what you use, or enable everything.</p>
          <SidebarCustomizer user={user} />
        </TabsContent>

        {/* Your Business — merged General + Industry */}
        <TabsContent value="business" className="space-y-4">
          <p className="text-sm text-muted-foreground">Tell AXIS about your business so it can personalize your scripts, modules, and dashboard.</p>
          <Card>
            <CardHeader>
              <CardTitle>Your Business</CardTitle>
              <CardDescription>Company name, industry, and timezone — all in one place</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="company-name">
                  Company Name<TechTooltip technical="company_name" />
                </Label>
                <Input
                  id="company-name"
                  value={generalForm?.company_name || ''}
                  onChange={(e) => setGeneralForm(f => ({ ...f, company_name: e.target.value }))}
                  placeholder="Your company name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="industry">
                  Industry<TechTooltip technical="industry" />
                </Label>
                <Select
                  value={generalForm?.industry || ''}
                  onValueChange={(value) => setGeneralForm(f => ({ ...f, industry: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select your industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {INDUSTRIES.map((ind) => (
                      <SelectItem key={ind.value} value={ind.value}>
                        {ind.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="timezone">
                  Default Timezone<TechTooltip technical="default_timezone" />
                </Label>
                <Select
                  value={generalForm?.default_timezone || 'America/New_York'}
                  onValueChange={(value) => setGeneralForm(f => ({ ...f, default_timezone: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map((tz) => (
                      <SelectItem key={tz.value} value={tz.value}>
                        {tz.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-2">
                <Button onClick={handleSaveAll} disabled={updateSettingsMutation.isPending} className="gap-2">
                  <Save className="w-4 h-4" />
                  {updateSettingsMutation.isPending ? 'Saving...' : 'Save'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Enabled Modules summary */}
          <Card>
            <CardHeader>
              <CardTitle>Active Modules</CardTitle>
              <CardDescription>Modules currently enabled in your sidebar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {systemSettings?.enabled_modules ? (
                  <div className="flex flex-wrap gap-2">
                    {(() => {
                      try {
                        const modules = JSON.parse(systemSettings.enabled_modules);
                        const display = modules === '__ALL__' ? ['All modules enabled'] : modules;
                        return display.map((mod, idx) => (
                          <div key={idx} className="px-2 py-1 rounded-md bg-primary/10 text-primary text-xs font-medium">
                            {mod.replace(/_/g, ' ')}
                          </div>
                        ));
                      } catch {
                        return <p className="text-sm text-muted-foreground">No modules configured</p>;
                      }
                    })()}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">Default modules active</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Reconfigure Setup</CardTitle>
              <CardDescription>Run the Trinity guided setup again to adjust your configuration</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={handleReconfigureIndustry} className="gap-2">
                <Sparkles className="w-4 h-4" />
                Reconfigure with Trinity
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Email Accounts — per-user multi-account IMAP/SMTP manager */}
        <TabsContent value="email" className="space-y-4">
          <p className="text-sm text-muted-foreground">Configure your personal email accounts (IMAP/POP3/SMTP). Each account is private to you and encrypted.</p>
          <EmailAccountManager />
        </TabsContent>

        {/* Calling — universal calling provider setup + health dashboard */}
        <TabsContent value="calling" className="space-y-4">
          <p className="text-sm text-muted-foreground">Connect your AI calling provider — Bland.ai, Vapi.ai, SignalWire, Twilio, or Browser AI Voice. Be making real autonomous calls in under 10 minutes.</p>
          <ProviderHealthDashboard />
        </TabsContent>

        {/* Connections — unified hub for all integrations */}
        <TabsContent value="connections" className="space-y-4">
          <ConnectionsTab onLaunchWizard={() => setWizardOpen(true)} />
        </TabsContent>

        {/* Appearance Settings (renamed from Interface) */}
        <TabsContent value="ui" className="space-y-4">
          <p className="text-sm text-muted-foreground">Customize how AXIS looks and feels — theme, layout density, and motion.</p>
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Theme, layout, and display preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Theme */}
              <div className="space-y-3">
                <Label>Theme</Label>
                <div className="grid grid-cols-3 gap-2">
                  <Button
                    variant={uiSettings.theme === 'light' ? 'default' : 'outline'}
                    onClick={() => setUiSettings({ ...uiSettings, theme: 'light' })}
                    className="gap-2"
                  >
                    <Sun className="w-4 h-4" />
                    Light
                  </Button>
                  <Button
                    variant={uiSettings.theme === 'dark' ? 'default' : 'outline'}
                    onClick={() => setUiSettings({ ...uiSettings, theme: 'dark' })}
                    className="gap-2"
                  >
                    <Moon className="w-4 h-4" />
                    Dark
                  </Button>
                  <Button
                    variant={uiSettings.theme === 'system' ? 'default' : 'outline'}
                    onClick={() => setUiSettings({ ...uiSettings, theme: 'system' })}
                    className="gap-2"
                  >
                    <Monitor className="w-4 h-4" />
                    System
                  </Button>
                </div>
              </div>

              {/* Dashboard Layout */}
              <div className="space-y-3">
                <Label>Dashboard Layout</Label>
                <Select
                  value={uiSettings.dashboardLayout}
                  onValueChange={(value) => setUiSettings({ ...uiSettings, dashboardLayout: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grid">Grid View</SelectItem>
                    <SelectItem value="list">List View</SelectItem>
                    <SelectItem value="compact">Compact</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Items Per Page */}
              <div className="space-y-3">
                <Label>Items Per Page</Label>
                <Select
                  value={uiSettings.itemsPerPage.toString()}
                  onValueChange={(value) => setUiSettings({ ...uiSettings, itemsPerPage: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10 items</SelectItem>
                    <SelectItem value="25">25 items</SelectItem>
                    <SelectItem value="50">50 items</SelectItem>
                    <SelectItem value="100">100 items</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Toggles */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Sidebar Collapsed by Default</Label>
                    <p className="text-xs text-muted-foreground">Start with sidebar minimized</p>
                  </div>
                  <Switch
                    checked={uiSettings.sidebarCollapsed}
                    onCheckedChange={(value) => setUiSettings({ ...uiSettings, sidebarCollapsed: value })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Compact Mode</Label>
                    <p className="text-xs text-muted-foreground">Reduce spacing and padding</p>
                  </div>
                  <Switch
                    checked={uiSettings.compactMode}
                    onCheckedChange={(value) => setUiSettings({ ...uiSettings, compactMode: value })}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Animations</Label>
                    <p className="text-xs text-muted-foreground">Show motion effects and transitions</p>
                  </div>
                  <Switch
                    checked={uiSettings.showAnimations}
                    onCheckedChange={(value) => setUiSettings({ ...uiSettings, showAnimations: value })}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-4">
                <Button onClick={handleSaveAll} disabled={updateSettingsMutation.isPending} className="gap-2">
                  <Save className="w-4 h-4" />
                  Save All Settings
                </Button>
                <Button variant="outline" onClick={handleResetUI} className="gap-2">
                  <RotateCcw className="w-4 h-4" />
                  Reset Defaults
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="space-y-4">
          <p className="text-sm text-muted-foreground">Control how and when AXIS sends you updates and alerts.</p>
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
              <CardDescription>Manage how you receive updates and alerts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Enable Notifications</Label>
                  <p className="text-xs text-muted-foreground">Show in-app notifications</p>
                </div>
                <Switch
                  checked={uiSettings.notificationsEnabled}
                  onCheckedChange={(value) => setUiSettings({ ...uiSettings, notificationsEnabled: value })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-xs text-muted-foreground">Receive updates via email</p>
                </div>
                <Switch
                  checked={uiSettings.emailNotifications}
                  onCheckedChange={(value) => setUiSettings({ ...uiSettings, emailNotifications: value })}
                />
              </div>

              <div className="pt-4">
                <Button onClick={handleSaveAll} disabled={updateSettingsMutation.isPending} className="gap-2">
                  <Save className="w-4 h-4" />
                  Save All Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments / Credit Card Processor — ADMIN ONLY (AXIS platform credentials, not subscriber-facing) */}
        {(user?.role === 'admin' || user?.role === 'super_admin') && (
          <TabsContent value="payments" className="space-y-4">
            <ConvergePaymentSettings systemSettings={systemSettings} />
          </TabsContent>
        )}


      </Tabs>

      <IntegrationWizard open={wizardOpen} onClose={() => setWizardOpen(false)} onComplete={() => setWizardOpen(false)} />
    </div>
  );
}