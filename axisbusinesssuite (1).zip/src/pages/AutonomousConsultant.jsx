import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2, RefreshCw, CheckCircle2, XCircle, TrendingUp, Lightbulb } from 'lucide-react';

const DOMAIN_COLORS = {
  sales: 'text-blue-400', marketing: 'text-pink-400', finance: 'text-emerald-400',
  operations: 'text-amber-400', support: 'text-cyan-400', hr: 'text-indigo-400',
  inventory: 'text-orange-400', compliance: 'text-rose-400', security: 'text-red-400',
  automation: 'text-purple-400'
};

const EFFORT_COLORS = { low: 'text-emerald-400', medium: 'text-amber-400', high: 'text-red-400' };

export default function AutonomousConsultant() {
  const [recs, setRecs] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [auditing, setAuditing] = useState(false);

  const fetchRecs = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('autonomousConsultant', { action: 'get_recommendations' });
      setRecs(res.data?.recommendations || []);
      setSummary(res.data?.summary);
    } catch { setRecs([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchRecs(); }, []);

  const handleAudit = async () => {
    setAuditing(true);
    try {
      await base44.functions.invoke('autonomousConsultant', { action: 'audit' });
      await fetchRecs();
    } finally { setAuditing(false); }
  };

  const updateStatus = async (id, status) => {
    await base44.functions.invoke('autonomousConsultant', { action: 'update_status', recommendation_id: id, status });
    await fetchRecs();
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Lightbulb className="w-6 h-6 text-primary" />
            Autonomous Consultant
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Trinity continuously audits every business domain — sales, marketing, finance, operations, HR, compliance — surfacing prioritized recommendations with estimated impact, effort, confidence, and ROI.
          </p>
        </div>
        <Button onClick={handleAudit} disabled={auditing}>
          {auditing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {auditing ? 'Auditing...' : 'Run Audit'}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Recommendations" value={summary?.total ?? recs.length} />
        <StatCard label="Pending" value={summary?.by_status?.pending ?? recs.filter(r => r.status === 'pending').length} />
        <StatCard label="Implemented" value={summary?.by_status?.implemented ?? recs.filter(r => r.status === 'implemented').length} />
        <StatCard label="Domains Covered" value={Object.keys(summary?.by_domain || {}).length} />
      </div>

      {/* Recommendations */}
      <div className="space-y-3">
        {loading ? (
          <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : recs.length ? (
          recs.map(r => (
            <Card key={r.id}>
              <CardContent className="pt-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs font-medium ${DOMAIN_COLORS[r.domain] || 'text-foreground'}`}>{r.domain}</span>
                      <span className="text-xs text-muted-foreground">·</span>
                      <span className="text-xs text-muted-foreground capitalize">{r.category?.replace(/_/g, ' ')}</span>
                      {r.status !== 'pending' && <span className="text-xs px-1.5 py-0.5 rounded bg-muted capitalize">{r.status}</span>}
                    </div>
                    <h3 className="font-semibold text-base">{r.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{r.description}</p>
                    <div className="flex flex-wrap gap-4 mt-3 text-xs">
                      <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3 text-primary" /> {r.estimated_impact}</span>
                      <span className="flex items-center gap-1">Effort: <span className={EFFORT_COLORS[r.implementation_effort]}>{r.implementation_effort}</span></span>
                      <span>Confidence: {r.confidence_score}%</span>
                      {r.expected_roi && <span className="text-primary">ROI: {r.expected_roi}</span>}
                    </div>
                  </div>
                  {r.status === 'pending' && (
                    <div className="flex flex-col gap-2 flex-shrink-0">
                      <Button size="sm" variant="default" onClick={() => updateStatus(r.id, 'implemented')}><CheckCircle2 className="w-3.5 h-3.5" /> Implement</Button>
                      <Button size="sm" variant="outline" onClick={() => updateStatus(r.id, 'dismissed')}><XCircle className="w-3.5 h-3.5" /> Dismiss</Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <Sparkles className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
              <p className="text-muted-foreground">No recommendations yet. Click "Run Audit" for Trinity to analyze your business across all domains.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <Card>
      <CardContent className="pt-5">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold font-poppins mt-1">{value ?? '—'}</p>
      </CardContent>
    </Card>
  );
}