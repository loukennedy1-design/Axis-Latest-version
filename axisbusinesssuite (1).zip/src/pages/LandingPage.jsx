import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { PLANS } from '@/lib/pricing';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Check, Bot, Users, Phone, ShieldCheck, ListTodo, BarChart3,
  Target, GitBranch, GraduationCap, Calendar, Video, Briefcase,
  MapPin, ArrowRight, Zap, DollarSign,
  MessageSquare, FileText, HeartHandshake, Megaphone, ChevronDown,
  Mail, Receipt, Brain, Globe, Radio, Route, BookOpen, Plug
} from 'lucide-react';
import UserReviewsSection from '@/components/landing/UserReviewsSection';
import SEOHead from '@/components/landing/SEOHead';
import BookDemoModal from '@/components/landing/BookDemoModal';
import SocialProofStats from '@/components/landing/SocialProofStats';
import IndustryUseCases from '@/components/landing/IndustryUseCases';



const FEATURE_GROUPS = [
  {
    category: '🤖 AI Automation',
    features: [
      { icon: Bot, label: 'AI Call Bot', color: 'text-primary', bg: 'bg-primary/10', desc: 'Autonomous outbound dialer conducting human-like conversations, handling objections, and booking appointments 24/7 without human intervention. Powered by Twilio (preferred) or other supported providers.' },
      { icon: Brain, label: 'AI Lead Scoring', color: 'text-purple-600', bg: 'bg-purple-500/10', desc: 'ML algorithms analyze engagement, demographic fit, and behavioral intent to automatically tier leads by conversion probability.' },
      { icon: GitBranch, label: 'Nurture Workflows', color: 'text-emerald-600', bg: 'bg-emerald-500/10', desc: 'Multi-channel automation sequences following up via AI calls, personalized emails, and tasks until leads convert or opt-out.' },
      { icon: Route, label: 'Lead Routing', color: 'text-blue-600', bg: 'bg-blue-500/10', desc: 'Intelligent rule-based and AI-powered lead assignment routing prospects to the best available rep based on skill, territory, and capacity.' },
    ],
  },
  {
    category: '👥 CRM & Sales',
    features: [
      { icon: Users, label: 'Lead CRM', color: 'text-blue-600', bg: 'bg-blue-500/10', desc: 'Complete pipeline management with bulk import, duplicate detection, lead scoring, and real-time status tracking across your entire sales funnel.' },
      { icon: ListTodo, label: 'Follow-Up Tasks', color: 'text-violet-600', bg: 'bg-violet-500/10', desc: 'Automated follow-up task generation from call outcomes — ensures every lead gets a timely callback, zero slipping through the cracks.' },
      { icon: BarChart3, label: 'Sales Team Management', color: 'text-teal-600', bg: 'bg-teal-500/10', desc: 'Rep leaderboards, quota tracking, territory management, and daily performance snapshots with manager override capabilities.' },
      { icon: GraduationCap, label: 'Coaching Hub', color: 'text-amber-600', bg: 'bg-amber-500/10', desc: 'AI analyzes every call transcript, grades performance, identifies objection patterns, and evolves your winning scripts automatically.' },
    ],
  },
  {
    category: '📣 Marketing',
    features: [
      { icon: Megaphone, label: 'Social Media AI', color: 'text-pink-600', bg: 'bg-pink-500/10', desc: 'AI generates platform-optimized posts, manages paid campaigns, schedules content calendars across Facebook, Instagram, LinkedIn, and TikTok.' },
      { icon: Video, label: 'Video Marketing AI', color: 'text-red-500', bg: 'bg-red-500/10', desc: 'AI-powered video content creation, scripting, and distribution workflows for YouTube, TikTok, and Instagram Reels.' },
      { icon: Radio, label: 'OmniChannel Hub', color: 'text-indigo-600', bg: 'bg-indigo-500/10', desc: 'Unified customer engagement across all channels — email, SMS, social, chat, and calls — with a single interaction timeline per contact.' },
      { icon: MapPin, label: 'AI Lead Generator', color: 'text-orange-600', bg: 'bg-orange-500/10', desc: 'B2B prospect discovery using AI web search and Google Maps — finds thousands of qualified leads by industry, location, and niche.' },
    ],
  },
  {
    category: '💬 Communications',
    features: [
      { icon: Mail, label: 'Email Client', color: 'text-blue-500', bg: 'bg-blue-500/10', desc: 'Full built-in email client with AI drafting, threading, template library, CRM lead linking, and open/click tracking.' },
      { icon: MessageSquare, label: 'SMS Inbox', color: 'text-green-600', bg: 'bg-green-500/10', desc: 'Two-way SMS messaging via Twilio with contact linking, conversation threading, automated opt-out compliance, and bulk messaging.' },
      { icon: Video, label: 'Zoom Scheduler', color: 'text-blue-400', bg: 'bg-blue-400/10', desc: 'Automated Zoom meeting creation with join links, calendar invites, recording links, and direct integration with the recruitment pipeline.' },
      { icon: Calendar, label: 'Calendly Integration', color: 'text-cyan-600', bg: 'bg-cyan-500/10', desc: 'AI books appointments directly during live calls via Calendly — prospects confirm in real-time, zero back-and-forth emails.' },
    ],
  },
  {
    category: '🏢 People Ops',
    features: [
      { icon: HeartHandshake, label: 'HR Suite', color: 'text-rose-600', bg: 'bg-rose-500/10', desc: 'Complete HRIS with employee records, time-off requests, payroll tracking, performance review cycles, and digital document management.' },
      { icon: Briefcase, label: 'Recruitment ATS', color: 'text-violet-600', bg: 'bg-violet-500/10', desc: 'Full applicant tracking system sourcing candidates from Indeed, AI scoring resumes, scheduling Zoom interviews, managing pipelines.' },
      { icon: Globe, label: 'Global Workforce', color: 'text-teal-600', bg: 'bg-teal-500/10', desc: 'Manage distributed teams across time zones with shift scheduling, contractor management, multi-territory reporting, and workforce analytics.' },
      { icon: BookOpen, label: 'Academy + Learning Hub', color: 'text-amber-600', bg: 'bg-amber-500/10', desc: 'AI-generated training content, custom sales scripts, onboarding programs, and video courses tailored to your industry and workflows.' },
    ],
  },
  {
    category: '🛡️ Compliance & Finance',
    features: [
      { icon: ShieldCheck, label: 'Compliance Suite', color: 'text-red-600', bg: 'bg-red-500/10', desc: 'TCPA/FCC compliance with national DNC registry integration, consent verification, call recording disclosures, and automated audit trails.' },
      { icon: Receipt, label: 'Financial Ops', color: 'text-emerald-600', bg: 'bg-emerald-500/10', desc: 'Invoice management, expense tracking, contractor payroll, P&L reporting, and receipt storage in one unified financial operations center.' },
      { icon: FileText, label: 'Document Intelligence', color: 'text-slate-500', bg: 'bg-slate-500/10', desc: 'AI-powered document processing, contract analysis, proposal generation, e-signatures, and secure document storage and retrieval.' },
      { icon: Plug, label: 'API Center', color: 'text-indigo-500', bg: 'bg-indigo-500/10', desc: 'Full REST API access, webhook management, and integration hub connecting your existing tech stack to the Axis platform.' },
    ],
  },
];



const FAQS = [
  { q: 'Do I need a credit card to start the free trial?', a: 'Yes — we collect your card securely at signup via Square, but you won\'t be charged for 7 days. Cancel before the trial ends and you\'ll never pay a cent.' },
  { q: 'Can I cancel anytime?', a: 'Yes — cancel anytime with no penalty or long-term contracts. Your data is always yours to export.' },
  { q: 'What\'s the difference between monthly and yearly billing?', a: 'Yearly billing saves you 15% compared to paying month-to-month. You pay once upfront and save significantly over the year.' },
  { q: 'Can I upgrade or downgrade my plan?', a: 'Absolutely. You can switch plans at any time. Upgrades take effect immediately, downgrades apply at your next billing cycle.' },
  { q: 'Does the AI call bot require any special phone hardware?', a: 'No. The AI call bot runs 100% in the cloud via your internet browser. No hardware, headsets, or VoIP setup needed. We recommend Twilio as the preferred calling provider for the best reliability and call quality, though other providers are supported.' },
  { q: 'Is there onboarding support?', a: 'Yes! All plans come with access to the Learning Hub with step-by-step guides for every feature, plus email support.' },
  { q: 'Should I hire a professional to set up the system?', a: 'While most of the platform is designed for self-service setup, we recommend hiring a professional (or using our White Glove onboarding service) for certain aspects — particularly telecom configuration (Twilio, phone number provisioning, caller ID verification), payment gateway setup, CRM data migration, and custom workflow automation. These areas involve compliance, security, and third-party account requirements where expert guidance saves time and prevents costly mistakes.' },
];

export default function LandingPage() {
  const [openFaq, setOpenFaq] = useState(null);
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [demoOpen, setDemoOpen] = useState(false);
  const { isAuthenticated } = useAuth();
  
  const handleLoginClick = () => {
    base44.auth.redirectToLogin('/app');
  };

  const handleTrialClick = () => {
    // Always go to pricing/checkout page where users can select plans and enter card info
    window.location.href = '/pricing';
  };

  const handleBookDemo = () => {
    window.location.href = '/admin?tab=support';
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* NAV */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="https://media.base44.com/images/public/69ef71210cace64a00bec165/db6b11da8_ChatGPTImageMay8202612_44_40PM.png" alt="AXIS" className="h-8" />
            <span className="font-bold text-lg">Axis Business Suite</span>
          </div>
          <div className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">Features</a>
            <a href="#pricing" className="hover:text-foreground transition-colors">Pricing</a>
            <a href="#reviews" className="hover:text-foreground transition-colors">Reviews</a>
            <a href="#faq" className="hover:text-foreground transition-colors">FAQ</a>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <a href="/app"><Button size="sm" variant="outline">Go to Dashboard →</Button></a>
            ) : (
              <>
                <Button size="sm" variant="outline" onClick={handleLoginClick}>Log In</Button>
                <Button size="sm" variant="secondary" className="bg-primary/10 text-primary hover:bg-primary/20 border border-primary/30" onClick={handleBookDemo}>Book a Demo</Button>
              </>
            )}
            <a href="/pricing"><Button size="sm">Start Free Trial</Button></a>
          </div>
        </div>
      </nav>

      {/* HERO */}
      <section className="pt-32 pb-20 px-4 text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <Badge className="bg-primary/10 text-primary border-primary/30 px-4 py-1.5 text-sm">
            🚀 AXIS Business Suite Omega OS v1 — Now Live
          </Badge>
          <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-tight">
          <span className="text-primary">AI Business Software</span> &<br />
          <span className="text-primary">AI Sales Automation CRM</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
          8 Autonomous Digital Employees handling sales, marketing, hiring, HR, finance, and customer success. Complete CRM, AI call bot, lead generation, compliance engine, and social media automation — <strong>all in one unified platform from $29/mo.</strong> First 7 days free.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <a href="/pricing"><Button size="lg" className="gap-2 text-base px-8">
              Start 7-Day Free Trial <ArrowRight className="w-4 h-4" />
            </Button></a>
            <Button size="lg" variant="outline" className="gap-2 text-base border-primary/40 text-primary hover:bg-primary/10" onClick={handleBookDemo}>
              <Calendar className="w-4 h-4" /> Book a Demo
            </Button>
            <a href="mailto:sales@axisbusiness.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
              <Mail className="w-4 h-4" /> Contact Us
            </a>
          </div>
          <div className="flex items-center justify-center gap-6 text-sm text-muted-foreground flex-wrap pt-2">
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-500" />No contracts</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-500" />Cancel anytime</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-500" />TRUE 7-day free trial</span>
            <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-emerald-500" />$0 today · First charge after trial</span>
          </div>
        </div>
      </section>

      <SocialProofStats />

      {/* VS BANNER */}
      <section className="px-4 pb-16">
        <div className="max-w-5xl mx-auto rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 text-white p-8">
          <p className="text-center text-sm font-semibold text-slate-400 uppercase tracking-widest mb-6">What other businesses pay for the same features</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
            {[
              { tool: 'CRM (HubSpot)', price: '$90/mo' },
              { tool: 'Dialer (JustCall)', price: '$60/mo' },
              { tool: 'Scheduling (Calendly)', price: '$16/mo' },
              { tool: 'Lead Gen (Apollo)', price: '$99/mo' },
              { tool: 'Nurture (ActiveCampaign)', price: '$49/mo' },
              { tool: 'Call Coaching (Gong)', price: '$100+/mo' },
              { tool: 'HR Software (BambooHR)', price: '$99/mo' },
              { tool: 'Social (Buffer/Hootsuite)', price: '$49/mo' },
            ].map(item => (
              <div key={item.tool} className="bg-white/5 rounded-xl p-3 text-center">
                <p className="text-xs text-slate-400">{item.tool}</p>
                <p className="font-bold text-red-400 mt-1">{item.price}</p>
              </div>
            ))}
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold text-red-400 line-through">~$562–$1,200+/mo total</p>
            <p className="text-3xl font-extrabold text-emerald-400 mt-1">vs. Axis Business Suite from $29/mo ✓</p>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section id="features" className="px-4 py-16 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="mb-3">Complete Feature Set</Badge>
            <h2 className="text-3xl md:text-4xl font-black mb-3">Everything Your Business Needs — In One Platform</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">From AI dialers and CRM to HR, compliance, social media, and finance — Axis replaces every tool in your stack. 40+ modules. One subscription.</p>
          </div>
          <div className="space-y-10">
            {FEATURE_GROUPS.map(group => (
              <div key={group.category}>
                <h3 className="text-lg font-bold mb-4 text-foreground/80">{group.category}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {group.features.map(({ icon: Icon, label, color, bg, desc }) => (
                    <Card key={label} className="hover:shadow-lg transition-shadow">
                      <CardContent className="p-5">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${bg} mb-3`}>
                          <Icon className={`w-5 h-5 ${color}`} />
                        </div>
                        <h4 className="font-bold text-sm mb-1">{label}</h4>
                        <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <IndustryUseCases />

      {/* PRICING */}
      <section id="pricing" className="px-4 py-20">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-10">
            <Badge className="mb-3">Transparent Pricing</Badge>
            <h2 className="text-3xl md:text-4xl font-black mb-3">Affordable for Every Business Size</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">From solo reps to full agencies — pick the plan that fits, upgrade anytime.</p>
          </div>

          {/* Billing toggle */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center gap-3 bg-muted rounded-xl p-1">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-5 py-2 rounded-lg font-medium text-sm transition-all ${billingCycle === 'monthly' ? 'bg-background shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >Monthly</button>
              <button
                onClick={() => setBillingCycle('yearly')}
                className={`px-5 py-2 rounded-lg font-medium text-sm transition-all relative ${billingCycle === 'yearly' ? 'bg-background shadow text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                Yearly
                <span className="ml-2 text-[10px] bg-emerald-500 text-white rounded-full px-1.5 py-0.5 font-bold">SAVE 15%</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {PLANS.map(plan => {
              const price = billingCycle === 'yearly' ? Math.round(plan.price * 12 * 0.85 * 100) / 100 : plan.price;
              const monthlyEq = billingCycle === 'yearly' ? Math.round(plan.price * 0.85 * 100) / 100 : null;
              return (
                <div key={plan.key} className={`relative rounded-2xl border-2 p-6 flex flex-col ${plan.borderColor} ${plan.bg} ${plan.highlight ? 'shadow-xl shadow-purple-500/20 scale-[1.03]' : ''}`}>
                  {plan.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full whitespace-nowrap">⭐ MOST POPULAR</div>
                  )}
                  <Badge className={`${plan.badgeColor} w-fit mb-3 border-0`}>{plan.badge}</Badge>
                  <p className="text-2xl font-extrabold">{plan.label}</p>
                  <div className="mt-2">
                    <span className="text-5xl font-black">${price}</span>
                    <span className="text-muted-foreground text-base font-normal">/{billingCycle === 'yearly' ? 'yr' : 'mo'}</span>
                  </div>
                  {monthlyEq && <p className="text-xs text-emerald-600 font-semibold mt-1">${monthlyEq}/mo · save 15%</p>}
                  <p className="text-xs text-muted-foreground mt-2 mb-4">{plan.desc}</p>
                  <div className="space-y-1.5 flex-1 mb-5">
                    {plan.includes.map(f => (
                      <div key={f} className="flex items-start gap-2 text-xs">
                        <Check className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />{f}
                      </div>
                    ))}
                  </div>
                  <a href="/pricing"><Button size="lg" className="w-full">
                    Start 7-Day Free Trial <ArrowRight className="w-4 h-4 ml-1" />
                  </Button></a>
                  <p className="text-center text-xs text-muted-foreground mt-2">Card required · Not charged for 7 days · Cancel anytime</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CUSTOMER REVIEWS */}
      <UserReviewsSection />

      {/* PROFESSIONAL SETUP RECOMMENDATION */}
      <section className="px-4 py-16 bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <Card className="border-primary/30">
            <CardContent className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                  <Briefcase className="w-6 h-6 text-primary" />
                </div>
                <div className="space-y-4">
                  <div>
                    <Badge className="mb-2 bg-primary/10 text-primary border-primary/30">Recommended</Badge>
                    <h2 className="text-2xl md:text-3xl font-black mb-2">Consider Professional Setup for Key Areas</h2>
                    <p className="text-muted-foreground text-sm">Most of AXIS is built for self-service, but certain aspects of system setup involve compliance, security, or third-party complexity where we strongly recommend hiring a professional or using our <strong>White Glove onboarding</strong> service:</p>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { icon: Phone, label: 'Telecom & Calling', note: 'Twilio account setup, number provisioning, caller ID verification, A2P 10DLC registration' },
                      { icon: Receipt, label: 'Payment Gateway', note: 'Converge/Square merchant setup, PCI compliance, payment routing' },
                      { icon: Users, label: 'CRM Data Migration', note: 'Importing existing lead databases, field mapping, deduplication' },
                      { icon: GitBranch, label: 'Custom Workflows', note: 'Complex automation rules, nurture sequences, API integrations' },
                      { icon: ShieldCheck, label: 'Compliance Configuration', note: 'TCPA consent flows, DNC registry setup, call recording disclosures' },
                      { icon: Plug, label: 'Third-Party Integrations', note: 'Calendar sync, email providers, social media accounts' },
                    ].map(({ icon: Icon, label, note }) => (
                      <div key={label} className="flex items-start gap-3 p-3 rounded-lg bg-background/50 border border-border">
                        <Icon className="w-5 h-5 text-primary shrink-0 mt-0.5" />
                        <div>
                          <p className="font-semibold text-sm">{label}</p>
                          <p className="text-xs text-muted-foreground leading-relaxed">{note}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center gap-3 pt-2 flex-wrap">
                    <a href="/pricing"><Button size="sm" className="gap-2">
                      <Briefcase className="w-4 h-4" /> Get White Glove Setup
                    </Button></a>
                    <a href="mailto:sales@axisbusiness.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                      <Mail className="w-4 h-4" /> Ask about professional setup
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="px-4 py-16">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <Badge className="mb-3">FAQ</Badge>
            <h2 className="text-3xl md:text-4xl font-black">Frequently Asked Questions</h2>
          </div>
          <div className="space-y-3">
            {FAQS.map((faq, i) => (
              <div key={i} className="border border-border rounded-xl overflow-hidden">
                <button
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-muted/30 transition-colors"
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                >
                  <span className="font-semibold text-sm pr-4">{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="px-4 py-20 bg-gradient-to-br from-primary/10 to-background">
        <div className="max-w-2xl mx-auto text-center space-y-6">
          <h2 className="text-3xl md:text-4xl font-black">Ready to Transform Your Sales?</h2>
          <p className="text-muted-foreground text-lg">Join hundreds of businesses already using Axis Business Suite to close more deals, faster — at a price any team can afford.</p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <a href="/pricing"><Button size="lg" className="gap-2 px-10 text-base">
              Start Your 7-Day Free Trial <ArrowRight className="w-4 h-4" />
            </Button></a>
            <Button size="lg" variant="outline" className="gap-2 border-primary/40 text-primary hover:bg-primary/10" onClick={handleBookDemo}>
              <Calendar className="w-4 h-4" /> Book a Demo
            </Button>
            <a href="mailto:sales@axisbusiness.com" className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
              <Mail className="w-4 h-4" /> sales@axisbusiness.com
            </a>
          </div>
          <p className="text-xs text-muted-foreground">7-day free trial · Credit card required at signup · You won't be charged for 7 days · Cancel anytime</p>
        </div>
      </section>



      <SEOHead />
      <BookDemoModal calendlyUrl="" open={demoOpen} onOpenChange={setDemoOpen} />

      {/* FOOTER */}
      <footer className="border-t border-border px-4 py-8">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-primary flex items-center justify-center"><Zap className="w-3 h-3 text-primary-foreground" /></div>
            <span className="font-semibold text-foreground">Axis Business Suite</span>
          </div>
          <div className="flex flex-wrap gap-4 justify-center">
            <a href="#features" className="hover:text-foreground transition-colors">Features</a>
            <a href="#pricing" className="hover:text-foreground transition-colors">Pricing</a>
            <a href="/pricing" className="hover:text-foreground transition-colors">Sign Up</a>
            <a href="/terms" className="hover:text-foreground transition-colors">Terms</a>
            <a href="/privacy" className="hover:text-foreground transition-colors">Privacy</a>
            <a href="mailto:support@axisbusiness.com" className="hover:text-foreground transition-colors">Support</a>
          </div>
          <p>© {new Date().getFullYear()} Axis Business Suite. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}