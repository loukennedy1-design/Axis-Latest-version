import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Key, Settings2, UserCheck, Activity, DollarSign, Mail } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import ConsoleUsersPanel from '@/components/admin/ConsoleUsersPanel';
import SystemEmailConfig from '@/components/admin/SystemEmailConfig';
import ConsoleApiKeysPanel from '@/components/admin/ConsoleApiKeysPanel';
import ConsoleSystemPanel from '@/components/admin/ConsoleSystemPanel';
import LeadAssignmentPanel from '@/components/admin/LeadAssignmentPanel';
import RepActivityOverview from '@/components/admin/RepActivityOverview';
import ResidualApprovalDashboard from '@/components/admin/ResidualApprovalDashboard';

export default function AdminConsole() {
  const [activeTab, setActiveTab] = useState('users');
  const { user } = useAuth();
  const isSuperAdmin = user?.role === 'super_admin';

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-purple-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Settings2 className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Admin Console</h1>
            <p className="text-muted-foreground text-xs">Users, API keys, and system settings — all in one place</p>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="flex flex-wrap h-auto gap-1">
          <TabsTrigger value="users" className="gap-1.5"><Users className="w-3.5 h-3.5" />Users & Access</TabsTrigger>
          <TabsTrigger value="leads" className="gap-1.5"><UserCheck className="w-3.5 h-3.5" />Lead Assignment</TabsTrigger>
          <TabsTrigger value="rep_activity" className="gap-1.5"><Activity className="w-3.5 h-3.5" />Rep Activity</TabsTrigger>
          <TabsTrigger value="residuals" className="gap-1.5"><DollarSign className="w-3.5 h-3.5" />Residual Approval</TabsTrigger>
          <TabsTrigger value="apikeys" className="gap-1.5"><Key className="w-3.5 h-3.5" />API Keys</TabsTrigger>
          <TabsTrigger value="system" className="gap-1.5"><Settings2 className="w-3.5 h-3.5" />System Config</TabsTrigger>
          {isSuperAdmin && (
            <TabsTrigger value="system_email" className="gap-1.5"><Mail className="w-3.5 h-3.5" />System Email</TabsTrigger>
          )}
        </TabsList>
        <TabsContent value="users"><ConsoleUsersPanel /></TabsContent>
        <TabsContent value="leads"><LeadAssignmentPanel /></TabsContent>
        <TabsContent value="rep_activity"><RepActivityOverview /></TabsContent>
        <TabsContent value="residuals"><ResidualApprovalDashboard /></TabsContent>
        <TabsContent value="apikeys"><ConsoleApiKeysPanel /></TabsContent>
        <TabsContent value="system"><ConsoleSystemPanel /></TabsContent>
        {isSuperAdmin && (
          <TabsContent value="system_email"><SystemEmailConfig /></TabsContent>
        )}
      </Tabs>
    </div>
  );
}