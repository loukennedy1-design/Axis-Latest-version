import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Facebook, Download, Plus, CheckCircle2, Clock, AlertCircle, Loader2, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

export default function FacebookLeads() {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const { user } = useCurrentUser();
  const qc = useQueryClient();

  const { data: generatedLeads = [] } = useQuery({
    queryKey: ['generatedLeads'],
    queryFn: () => base44.entities.GeneratedLead.list('-created_date', 100),
  });

  const facebookLeads = generatedLeads.filter(l => l.source === 'facebook_ads');

  const syncMutation = useMutation({
    mutationFn: async () => {
      setIsImporting(true);
      try {
        const response = await base44.functions.invoke('syncFacebookLeads', {
          userId: user?.email,
        });
        return response.data;
      } finally {
        setIsImporting(false);
      }
    },
    onSuccess: (data) => {
      toast.success(`✅ Synced ${data.count} leads from Facebook`);
      qc.invalidateQueries({ queryKey: ['generatedLeads'] });
    },
    onError: (err) => {
      toast.error(`Failed to sync: ${err.message}`);
    },
  });

  const importMutation = useMutation({
    mutationFn: async (leadIds) => {
      const leads = facebookLeads.filter(l => leadIds.includes(l.id));
      const leadsToCreate = leads.map(l => ({
        first_name: l.business_name?.split(' ')[0] || 'Lead',
        last_name: l.business_name?.split(' ').slice(1).join(' ') || '',
        phone: l.phone || '',
        email: l.email || '',
        company: l.business_name || '',
        source: 'Facebook Ads',
        timezone: 'America/New_York',
        notes: `Facebook Lead - Category: ${l.category}`,
        status: 'new',
        consent_given: false,
        call_attempts: 0,
        owner: user?.email,
      }));

      const response = await base44.functions.invoke('bulkImportLeads', {
        leads: leadsToCreate,
      });
      return response.data;
    },
    onSuccess: (data) => {
      toast.success(`✅ ${data.imported} leads imported to CRM`);
      qc.invalidateQueries({ queryKey: ['leads', 'generatedLeads'] });
    },
    onError: (err) => {
      toast.error(`Import failed: ${err.message}`);
    },
  });

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      const url = await base44.connectors.connectAppUser('facebook_connector');
      window.open(url, '_blank');
      const popup = window.open(url);
      const timer = setInterval(() => {
        if (!popup || popup.closed) {
          clearInterval(timer);
          setIsConnecting(false);
          syncMutation.mutate();
        }
      }, 500);
    } catch (error) {
      toast.error('Connection failed: Make sure Facebook connector is registered');
      setIsConnecting(false);
    }
  };

  const newLeads = facebookLeads.filter(l => l.status === 'new').length;
  const importedLeads = facebookLeads.filter(l => l.status === 'imported').length;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-blue-500/20 bg-gradient-to-br from-blue-500/8 via-card to-primary/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Facebook className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Facebook Lead Ads</h1>
              <p className="text-muted-foreground text-xs">Sync leads from Facebook Lead Ads campaigns directly to your CRM</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Facebook className="w-3.5 h-3.5" />{facebookLeads.length} total
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Plus className="w-3.5 h-3.5" />{newLeads} new
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />{importedLeads} imported
            </div>
            <Button variant="outline" size="sm" onClick={() => syncMutation.mutate()} disabled={syncMutation.isPending} className="gap-1.5">
              <RefreshCw className={`w-3.5 h-3.5 ${syncMutation.isPending ? 'animate-spin' : ''}`} />Sync Now
            </Button>
            <Button size="sm" onClick={handleConnect} disabled={isConnecting} className="gap-1.5">
              <Facebook className="w-3.5 h-3.5" />{isConnecting ? 'Connecting...' : 'Connect'}
            </Button>
          </div>
        </div>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="text-base">Facebook Leads</CardTitle>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Bulk Import
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Import Selected Leads to CRM</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  This will import selected Facebook leads into your CRM as new contacts.
                </p>
                <Button 
                  className="w-full" 
                  onClick={() => {
                    const newLeadIds = facebookLeads.filter(l => l.status === 'new').map(l => l.id);
                    importMutation.mutate(newLeadIds);
                  }}
                  disabled={facebookLeads.filter(l => l.status === 'new').length === 0 || importMutation.isPending}
                >
                  {importMutation.isPending ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Importing...</>
                  ) : (
                    <><Download className="w-4 h-4 mr-2" />Import {facebookLeads.filter(l => l.status === 'new').length} Leads</>
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          {facebookLeads.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <Facebook className="w-8 h-8 mb-2 opacity-50" />
              <p className="text-sm">No Facebook leads yet. Connect your account to get started.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Business Name</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {facebookLeads.map(lead => (
                    <TableRow key={lead.id}>
                      <TableCell className="font-medium">{lead.business_name}</TableCell>
                      <TableCell>{lead.phone || '—'}</TableCell>
                      <TableCell className="text-sm">{lead.email || '—'}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="text-xs">{lead.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={lead.status === 'imported' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-blue-500/10 text-blue-600'}>
                          {lead.status === 'imported' ? 'Imported' : 'New'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {lead.status === 'new' && (
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => importMutation.mutate([lead.id])}
                            disabled={importMutation.isPending}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        )}
                        {lead.status === 'imported' && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-blue-500/30 bg-blue-500/5">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-blue-600" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm">
          <div className="flex gap-3">
            <div className="text-blue-600 font-bold">1</div>
            <div>
              <p className="font-semibold">Connect Facebook</p>
              <p className="text-muted-foreground">Authorize your Facebook ad account to sync leads in real-time</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="text-blue-600 font-bold">2</div>
            <div>
              <p className="font-semibold">Leads Auto-Sync</p>
              <p className="text-muted-foreground">New Facebook leads appear here automatically when submitted</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="text-blue-600 font-bold">3</div>
            <div>
              <p className="font-semibold">Import to CRM</p>
              <p className="text-muted-foreground">Review and import leads into your CRM with one click</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}