import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Check, Phone, ShoppingCart, Bot, Users, Shield, Clock, TrendingUp, ArrowRight, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { PLANS } from '@/lib/pricing';
import CardVaultForm from '@/components/checkout/CardVaultForm';

const CHARGEBACK_CLAUSE = `By completing this purchase, I acknowledge that all sales are final. I expressly waive my right to initiate any chargeback or payment reversal with my card issuer for charges made by Axis Business Suite once services/access have been granted. I agree to contact support@axisbusiness.com to resolve any billing concerns before initiating any bank dispute. This agreement is electronically accepted and legally binding (Terms v1.0).`;

const CORE_FEATURES = [
  { icon: Bot, label: 'AI Call Bot (auto-dialer)' },
  { icon: Users, label: 'Lead CRM & Management' },
  { icon: Phone, label: 'Call Logs & Transcripts' },
  { icon: Shield, label: 'DNC Registry & Compliance' },
  { icon: Clock, label: 'Follow-Up Task Manager' },
  { icon: TrendingUp, label: 'Live Analytics Dashboard' },
];

export default function PricingCheckout() {
  const [billingCycle, setBillingCycle] = useState('monthly');
  const [checkoutLoading, setCheckoutLoading] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [showGuestForm, setShowGuestForm] = useState(false);
  const [chargebackConsent, setChargebackConsent] = useState(false);
  const [vaultData, setVaultData] = useState(null);

  // Read rep referral code from URL
  const refCode = new URLSearchParams(window.location.search).get('ref') || null;

  useEffect(() => {
    base44.auth.isAuthenticated().then(authed => {
      if (authed) {
        base44.auth.me().then(u => setCurrentUser(u)).catch(() => {});
      }
    });
  }, []);

  const handleSelectPlan = (plan) => {
    if (currentUser) {
      if (!chargebackConsent) {
        toast.error('Please agree to the billing terms before proceeding.');
        document.getElementById('chargeback-consent')?.scrollIntoView({ behavior: 'smooth' });
        return;
      }
      handleCheckout(plan, currentUser.email, currentUser.full_name);
    } else {
      // Guest — show name/email form (consent checked inside modal)
      setSelectedPlan(plan);
      setChargebackConsent(false);
      setShowGuestForm(true);
    }
  };

  const handleGuestSubmit = (e) => {
    e.preventDefault();
    if (!guestName.trim() || !guestEmail.trim()) return;
    handleCheckout(selectedPlan, guestEmail.trim(), guestName.trim());
    setShowGuestForm(false);
  };

  const handleCheckout = async (plan, email, fullName) => {
    setCheckoutLoading(plan.key);
    try {
      // Record chargeback consent before payment
      base44.functions.invoke('chargebackProtection', {
        action: 'record_consent',
        customer_email: email,
        customer_name: fullName,
        plan_key: plan.key,
        amount: billingCycle === 'yearly' ? Math.round(plan.price * 12 * 0.85 * 100) / 100 : plan.price,
        consent_agreed: true,
        ip_address: '',
        user_agent: navigator.userAgent,
        checkout_page_url: window.location.href,
      }).catch(() => {}); // fire-and-forget, don't block checkout

      const price = billingCycle === 'yearly'
        ? Math.round(plan.price * 12 * 0.85 * 100) / 100
        : plan.price;
      const response = await base44.functions.invoke('convergeCheckout', {
        email,
        fullName,
        planKey: plan.key,
        isYearly: billingCycle === 'yearly',
        ref: refCode,
      });
      const data = response.data || {};
      if (data.vaultFallback) {
        // Converge not live yet — show the card vault form
        setVaultData({
          email,
          fullName,
          planLabel: data.planLabel || plan.label,
          amount: data.amount || price,
          isYearly: billingCycle === 'yearly',
        });
        toast.info('Payment processing is being configured. Please enter your card to save it — you will be charged automatically once processing is live.');
      } else if (data.processor === 'converge' && data.paymentHtml) {
        // Render Converge's hosted card form — card data goes directly to Converge.
        document.open();
        document.write(data.paymentHtml);
        document.close();
      } else if (data.redirect) {
        if (data.message) toast.info(data.message, { duration: 3500 });
        setTimeout(() => { window.location.href = data.redirect; }, 400);
      } else {
        toast.error(data.error || 'Failed to create checkout. Please try again.');
      }
    } catch (err) {
      toast.error(err.message || 'Checkout failed. Please try again.');
    } finally {
      setCheckoutLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="border-b border-border px-4 h-14 flex items-center justify-between sticky top-0 bg-background/90 backdrop-blur z-50">
        <a href="/" className="flex items-center gap-2 text-sm font-semibold hover:text-primary transition-colors">
          <img src="https://media.base44.com/images/public/69ef71210cace64a00bec165/db6b11da8_ChatGPTImageMay8202612_44_40PM.png" alt="AXIS" className="h-7" />
          <span className="hidden sm:block">Axis Business Suite</span>
        </a>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <a href="/" className="hover:text-foreground transition-colors hidden sm:block">← Back to Home</a>
          {currentUser && <a href="/app" className="hover:text-foreground transition-colors font-medium">Go to Dashboard →</a>}
          <a href="mailto:support@axisbusiness.com" className="hover:text-foreground transition-colors">Support</a>
        </div>
      </nav>
    <div className="space-y-10 max-w-5xl mx-auto pb-20 px-4 pt-6">
      {/* Header */}
      <div className="text-center pt-4 space-y-3">
        <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/30 text-sm px-4 py-1">
          ✅ TRUE 7-DAY FREE TRIAL — $0 Today, Card Saved for Billing After Trial
        </Badge>
        <h1 className="text-4xl font-extrabold tracking-tight">Simple, Affordable Pricing</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          The average sales team pays <span className="line-through text-red-500 font-semibold">$800–$1,200/mo</span> across 5–7 separate tools.
          Axis Business Suite replaces them all — starting at <span className="text-primary font-bold">$29/mo</span>.
        </p>
        <div className="inline-flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-5 py-3 text-sm text-emerald-700 dark:text-emerald-400 max-w-xl mx-auto">
          <Check className="w-4 h-4 shrink-0" />
          <span><strong>TRUE FREE TRIAL:</strong> Pick your plan → Enter card securely → $0 charge today → Full access for 7 days → Automatic billing starts on day 8 → Cancel anytime before trial ends to avoid charges</span>
        </div>
      </div>

      {/* VS Banner */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 text-white p-6">
        <p className="text-center text-sm font-semibold text-slate-400 uppercase tracking-widest mb-4">What other teams pay for the same features</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          {[
            { tool: 'CRM (HubSpot)', price: '$90/mo' },
            { tool: 'Dialer (JustCall)', price: '$60/mo' },
            { tool: 'Scheduling (Calendly)', price: '$16/mo' },
            { tool: 'Lead Gen (Apollo)', price: '$99/mo' },
            { tool: 'Email Nurture (ActiveCampaign)', price: '$49/mo' },
            { tool: 'Call Coach (Gong)', price: '$100+/mo' },
            { tool: 'Compliance (manual)', price: '$50+/mo' },
            { tool: 'Analytics (BI tool)', price: '$40/mo' },
          ].map(item => (
            <div key={item.tool} className="bg-white/5 rounded-xl p-3">
              <p className="text-xs text-slate-400">{item.tool}</p>
              <p className="font-bold text-red-400 mt-1">{item.price}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-5">
          <p className="text-2xl font-bold text-red-400 line-through">~$562–$1,200+/mo total</p>
          <p className="text-3xl font-extrabold text-emerald-400 mt-1">vs. Axis Business Suite from $29/mo ✓</p>
        </div>
      </div>

      {/* Core Features */}
      <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Phone className="w-5 h-5 text-emerald-600" />
          <span className="font-bold text-emerald-800 dark:text-emerald-400">Every plan includes the full core call flow — no nickle & diming:</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {CORE_FEATURES.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2 text-sm text-emerald-700 dark:text-emerald-400">
              <Icon className="w-4 h-4 shrink-0" />{label}
            </div>
          ))}
        </div>
      </div>

      {/* Chargeback Consent Clause */}
      <div id="chargeback-consent" className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-3">
        <div className="flex items-center gap-2 text-amber-600">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span className="font-bold text-sm">Billing Agreement — Required Before Checkout</span>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{CHARGEBACK_CLAUSE}</p>
        <label className="flex items-start gap-3 cursor-pointer group">
          <input
            type="checkbox"
            checked={chargebackConsent}
            onChange={e => setChargebackConsent(e.target.checked)}
            className="mt-0.5 w-4 h-4 accent-primary cursor-pointer"
          />
          <span className="text-sm font-medium group-hover:text-foreground transition-colors">
            I have read and agree to the billing terms above, including the no-chargeback clause.
          </span>
        </label>
      </div>

      {/* Billing Cycle Toggle */}
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-xl">1. Pick Your Plan</h2>
        <div className="flex items-center gap-3 bg-muted rounded-lg p-1">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-4 py-2 rounded-md font-medium text-sm transition-all ${
              billingCycle === 'monthly'
                ? 'bg-background text-foreground shadow'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Monthly
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-4 py-2 rounded-md font-medium text-sm transition-all relative ${
              billingCycle === 'yearly'
                ? 'bg-background text-foreground shadow'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Yearly
            {billingCycle === 'yearly' && (
              <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                Save 15%
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-4">
        {PLANS.map(plan => {
          const displayPrice = billingCycle === 'yearly' ? Math.round(plan.price * 12 * 0.85 * 100) / 100 : plan.price;
          const monthlyEquiv = billingCycle === 'yearly' ? Math.round(plan.price * 0.85 * 100) / 100 : null;
          const isLoading = checkoutLoading === plan.key;
          return (
            <div
              key={plan.key}
              className={`relative rounded-2xl border-2 p-6 flex flex-col ${plan.borderColor} ${plan.bg} ${plan.highlight ? 'shadow-xl shadow-purple-500/20 scale-[1.02]' : ''}`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-full whitespace-nowrap">
                  ⭐ MOST POPULAR
                </div>
              )}
              <Badge className={`${plan.badgeColor} w-fit mb-3`}>{plan.badge}</Badge>
              <p className="font-extrabold text-2xl">{plan.label}</p>
              <div className="mt-2 mb-1">
                <span className="text-5xl font-black">${displayPrice}</span>
                <span className="text-base font-normal text-muted-foreground">/{billingCycle === 'yearly' ? 'yr' : 'mo'}</span>
              </div>
              {billingCycle === 'yearly' && (
                <p className="text-xs text-emerald-600 font-semibold mb-1">${monthlyEquiv}/mo — save 15%</p>
              )}
              <p className="text-xs text-muted-foreground mb-4">{plan.desc}</p>

              <div className="space-y-1.5 text-sm mb-4">
                <div className="flex items-center gap-2 font-medium"><Check className="w-4 h-4 text-emerald-500 shrink-0" />{plan.max_leads === 999999 ? 'Unlimited' : plan.max_leads.toLocaleString()} leads</div>
                <div className="flex items-center gap-2 font-medium"><Check className="w-4 h-4 text-emerald-500 shrink-0" />{plan.max_calls === 999999 ? 'Unlimited' : plan.max_calls.toLocaleString()} calls/mo</div>
                <div className="flex items-center gap-2 font-medium"><Check className="w-4 h-4 text-emerald-500 shrink-0" />Up to {plan.max_users === 25 ? '25' : plan.max_users} user{plan.max_users !== 1 ? 's' : ''}</div>
              </div>

              <div className="border-t border-border/50 pt-4 mb-5 space-y-1.5 flex-1">
                {plan.includes.map(f => (
                  <div key={f} className="flex items-center gap-2 text-xs">
                    <Check className="w-3.5 h-3.5 text-primary shrink-0" />{f}
                  </div>
                ))}
              </div>

              <Button
                size="lg"
                className="w-full gap-2 mt-auto"
                onClick={() => handleSelectPlan(plan)}
                disabled={!!checkoutLoading}
              >
                {isLoading ? (
                  <><span className="animate-spin">⏳</span> Setting up checkout...</>
                ) : (
                  <><ShoppingCart className="w-4 h-4" /> Start Free Trial — Enter Card</>
                )}
              </Button>
              <p className="text-center text-xs text-emerald-600 font-medium mt-2">✅ $0 Today · 7-Day Free Trial · Cancel Before Day 8 to Avoid Charges</p>
            </div>
          );
        })}
      </div>
    </div>
    {/* Footer */}
    <footer className="border-t border-border px-4 py-6 text-center text-xs text-muted-foreground">
      <div className="flex flex-wrap justify-center gap-4">
        <a href="/terms" className="hover:text-foreground transition-colors">Terms of Service</a>
        <a href="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</a>
        <a href="mailto:support@axisbusiness.com" className="hover:text-foreground transition-colors">Contact Support</a>
      </div>
      <p className="mt-2">© {new Date().getFullYear()} Axis Business Suite. Secured by Converge (Elavon).</p>
    </footer>
    {/* Card Vault Fallback Modal */}
    <Dialog open={!!vaultData} onOpenChange={(open) => { if (!open) setVaultData(null); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            Save Your Card for Billing
          </DialogTitle>
          <DialogDescription>
            Our payment processor (Converge/Elavon) is being configured. Enter your card now — it will be encrypted
            and charged automatically once processing is live. You will not be charged today.
          </DialogDescription>
        </DialogHeader>
        {vaultData && (
          <CardVaultForm
            email={vaultData.email}
            fullName={vaultData.fullName}
            planLabel={vaultData.planLabel}
            amount={vaultData.amount}
            isYearly={vaultData.isYearly}
          />
        )}
      </DialogContent>
    </Dialog>
    {/* Guest info modal */}
    <Dialog open={showGuestForm} onOpenChange={setShowGuestForm}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>One quick step before checkout</DialogTitle>
          <DialogDescription>Enter your name and email to start your 7-day free trial.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleGuestSubmit} className="space-y-4 mt-2">
          <div>
            <label className="block text-sm font-medium mb-1">Full Name</label>
            <input
              type="text"
              required
              value={guestName}
              onChange={e => setGuestName(e.target.value)}
              placeholder="Jane Smith"
              className="w-full border border-input rounded-md px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Email Address</label>
            <input
              type="email"
              required
              value={guestEmail}
              onChange={e => setGuestEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full border border-input rounded-md px-3 py-2 bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          {/* Chargeback consent in guest modal */}
          <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 space-y-2">
            <p className="text-xs text-muted-foreground leading-relaxed">{CHARGEBACK_CLAUSE}</p>
            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                required
                checked={chargebackConsent}
                onChange={e => setChargebackConsent(e.target.checked)}
                className="mt-0.5 w-4 h-4 accent-primary cursor-pointer"
              />
              <span className="text-xs font-medium">I agree to the billing terms & no-chargeback clause above.</span>
            </label>
          </div>
          <Button type="submit" className="w-full gap-2" disabled={!!checkoutLoading || !chargebackConsent}>
            {checkoutLoading ? 'Setting up checkout...' : <><ShoppingCart className="w-4 h-4" /> Continue to Secure Checkout <ArrowRight className="w-4 h-4" /></>}
          </Button>
          <p className="text-center text-xs text-emerald-600 font-medium">✅ $0 Today · Trial Ends {new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · Cancel Anytime</p>
        </form>
      </DialogContent>
    </Dialog>
    </div>
  );
}