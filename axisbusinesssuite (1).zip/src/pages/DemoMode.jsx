import React, { useState, useEffect } from 'react';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Activity, Lock, RefreshCcw } from 'lucide-react';
import { format } from 'date-fns';
import LiveActivityFeed from '@/components/demo/LiveActivityFeed';
import DemoCRMModule from '@/components/demo/DemoCRMModule';
import DemoCallBotModule from '@/components/demo/DemoCallBotModule';
import DemoHRModule from '@/components/demo/DemoHRModule';
import DemoFinanceModule from '@/components/demo/DemoFinanceModule';
import DemoComplianceModule from '@/components/demo/DemoComplianceModule';
import DemoAIAgentsModule from '@/components/demo/DemoAIAgentsModule';
import DemoAxisMeetModule from '@/components/demo/DemoAxisMeetModule';

const BASELINE_METRICS = {
  crm: { totalLeads: 679, pipelineValue: 284500, callsToday: 142, conversionRate: 18.4 },
  callBot: { callsToday: 143, answerRate: 68.4, appointmentsSet: 28, avgDuration: '3m 24s' },
  hr: { openRoles: 12, activeCandidates: 47, interviewsScheduled: 8, offersExtended: 5 },
  finance: { mrr: 18420, arr: 221040, invoicesSent: 47, outstandingBalance: 12340 },
  compliance: { complianceScore: 99.8, dncEntries: 234, tcpaAudits: 47, securityAlerts: 0 },
  aiAgents: { tasksRunToday: 847, workflowsActive: 23, automationSavings: 12400, agentTasks: 156 },
  axisMeet: { meetingsHeld: 34, avgDuration: '42m', upcomingMeetings: 8, totalAttendees: 156 },
};

export default function DemoMode() {
  const { user, isAdmin } = useCurrentUser();
  const [timeRange, setTimeRange] = useState('30');
  const [resetKey, setResetKey] = useState(0);
  const [lastReset, setLastReset] = useState(null);

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Card className="max-w-sm w-full">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <Lock className="w-10 h-10 mx-auto text-muted-foreground" />
            <p className="font-semibold">Admin Only</p>
            <p className="text-sm text-muted-foreground">Presentation Mode is only available to system administrators.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleReset = () => {
    setResetKey(prev => prev + 1);
    setLastReset(new Date());
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-500/8 via-card to-primary/5 p-6">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <Activity className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Presentation Mode — Live System Demo</h1>
              <p className="text-muted-foreground text-sm">Real-time simulated analytics showcasing the full AXIS Business Suite platform</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="outline" className="text-xs bg-amber-500/10 text-amber-400 border-amber-500/20">
              <Activity className="w-3 h-3 animate-pulse mr-1" />
              Simulated Data
            </Badge>
            <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1" />
              Live Demo · {format(new Date(), 'h:mm a')}
            </Badge>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="14">Last 14 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={handleReset} className="gap-1.5">
              <RefreshCcw className="w-3.5 h-3.5" />
              Reset Demo
            </Button>
          </div>
        </div>
        {lastReset && (
          <p className="text-xs text-muted-foreground mt-2">
            Last reset: {lastReset.toLocaleTimeString()}
          </p>
        )}
      </div>

      {/* Live Activity Feed - Sticky Top */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-1">
          <LiveActivityFeed key={resetKey} />
        </div>

        <div className="lg:col-span-3 space-y-6">
          {/* CRM Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoCRMModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* Call Bot Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoCallBotModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* HR & Recruitment Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoHRModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* Finance & Revenue Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoFinanceModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* AXIS Meet Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoAxisMeetModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* Compliance & Security Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoComplianceModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>

          {/* AI Agents & Automation Module */}
          <section className="space-y-4 p-4 rounded-xl border border-border bg-card/50">
            <DemoAIAgentsModule key={resetKey} baseline={BASELINE_METRICS} />
          </section>
        </div>
      </div>
    </div>
  );
}