import React, { useState, useRef, useMemo } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Upload, FileSpreadsheet, Check, AlertCircle, Loader2, X,
  Download, ChevronRight, ChevronLeft, Users, Shield, CheckCircle2, ArrowRight, FileText
} from 'lucide-react';
import { toast } from 'sonner';
import ImportDiagnostics from '@/components/import/ImportDiagnostics';

// ─── CSV Parser ───────────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];
  const parseRow = (line) => {
    const result = []; let cur = ''; let inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { if (inQ && line[i+1] === '"') { cur += '"'; i++; } else inQ = !inQ; }
      else if (ch === ',' && !inQ) { result.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    result.push(cur.trim());
    return result;
  };
  const headers = parseRow(lines[0]).map(h => h.toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9_]/g,''));
  return lines.slice(1).map(line => {
    const vals = parseRow(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = (vals[i] || '').trim(); });
    return obj;
  });
}

const SCHEMA_FIELDS = [
  { key: 'first_name', label: 'First Name', required: true },
  { key: 'last_name', label: 'Last Name', required: false },
  { key: 'phone', label: 'Phone', required: true },
  { key: 'email', label: 'Email', required: false },
  { key: 'company', label: 'Company', required: false },
  { key: 'source', label: 'Source', required: false },
  { key: 'timezone', label: 'Timezone', required: false },
  { key: 'notes', label: 'Notes', required: false },
];

const AUTO_MAP = {
  first_name: ['first_name','firstname','first','fname','name','fullname','full_name'],
  last_name: ['last_name','lastname','last','lname','surname'],
  phone: ['phone','phone_number','phonenumber','mobile','cell','telephone','tel','mob'],
  email: ['email','email_address','emailaddress','e_mail','mail'],
  company: ['company','company_name','business','organization','org','account'],
  source: ['source','lead_source','leadsource','origin','channel'],
  timezone: ['timezone','time_zone','tz'],
  notes: ['notes','note','comments','comment','description','remarks'],
};

function autoDetectMapping(csvHeaders) {
  const mapping = {};
  SCHEMA_FIELDS.forEach(({ key }) => {
    const match = csvHeaders.find(h => AUTO_MAP[key]?.includes(h.toLowerCase().replace(/\s+/g,'_').replace(/[^a-z0-9_]/g,'')));
    mapping[key] = match || '';
  });
  return mapping;
}

const STEPS = ['Upload', 'Map Columns', 'Review', 'Options', 'Import'];
const BATCH_SIZE = 100;

export default function ImportWizard() {
  const [step, setStep] = useState(0);
  const [file, setFile] = useState(null);
  const [rawRows, setRawRows] = useState([]);
  const [csvHeaders, setCsvHeaders] = useState([]);
  const [mapping, setMapping] = useState({});
  const [options, setOptions] = useState({ consent_given: false, default_source: 'CSV Import', default_timezone: 'America/New_York', skip_duplicates: true });
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState(null);
  const inputRef = useRef();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const handleFileSelect = (e) => {
    const f = e.target.files?.[0] || e;
    if (!f) return;
    setFile(f);
    const reader = new FileReader();
    reader.onload = (evt) => {
      const parsed = parseCSV(evt.target.result);
      if (!parsed.length) { toast.error('No data found in CSV'); return; }
      setRawRows(parsed);
      const headers = Object.keys(parsed[0]);
      setCsvHeaders(headers);
      setMapping(autoDetectMapping(headers));
      setStep(1);
    };
    reader.readAsText(f);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files?.[0];
    if (f) handleFileSelect({ target: { files: [f] } });
  };

  const mappedRows = useMemo(() => rawRows.map(row => {
    const out = {};
    SCHEMA_FIELDS.forEach(({ key }) => {
      out[key] = mapping[key] ? (row[mapping[key]] || '').trim() : '';
    });
    return out;
  }), [rawRows, mapping]);

  const validRows = useMemo(() => mappedRows.filter(r => r.first_name && r.phone), [mappedRows]);

  const handleImport = async () => {
  setImporting(true);
  setProgress(0);
  let rows = validRows;
  if (options.skip_duplicates) {
    const seen = new Set();
    rows = rows.filter(r => { if (seen.has(r.phone)) return false; seen.add(r.phone); return true; });
  }
  const leads = rows.map(r => ({
    first_name: r.first_name,
    last_name: r.last_name || '',
    phone: r.phone,
    email: (r.email || '').toLowerCase().trim(),
    company: r.company || '',
    source: r.source || options.default_source,
    timezone: r.timezone || options.default_timezone,
    notes: r.notes || '',
    status: 'new',
    consent_given: options.consent_given,
    call_attempts: 0,
  }));

    const batches = [];
    for (let i = 0; i < leads.length; i += BATCH_SIZE) batches.push(leads.slice(i, i + BATCH_SIZE));

    let imported = 0;
    let failed = 0;
    for (let i = 0; i < batches.length; i++) {
      const res = await base44.functions.invoke('bulkImportLeads', {
        leads: batches[i],
        consent_given: options.consent_given,
      });
      imported += res.data?.imported || 0;
      failed += res.data?.failed || 0;
      setProgress(Math.round(((i + 1) / batches.length) * 100));
    }

    const skipped = rawRows.length - validRows.length + (validRows.length - rows.length);
    setResults({ imported, skipped, failed, total: rawRows.length });
    setImporting(false);
    setStep(4);
    qc.invalidateQueries({ queryKey: ['leads'] });
    toast.success(`✅ ${imported} leads imported`);
  };

  const reset = () => {
    setStep(0); setFile(null); setRawRows([]); setCsvHeaders([]); setMapping({});
    setResults(null); setProgress(0);
    if (inputRef.current) inputRef.current.value = '';
  };

  const downloadTemplate = () => {
    const csv = 'first_name,last_name,phone,email,company,source,timezone,notes\nJohn,Doe,+15551234567,john@example.com,Acme Corp,Web,America/New_York,"Interest in product"\nJane,Smith,+15559876543,jane@example.com,Beta LLC,Referral,America/Chicago,""';
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'leads_template.csv'; a.click();
  };

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      {/* Diagnostics */}
      <ImportDiagnostics />

      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Upload className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Lead Import Wizard</h1>
              <p className="text-muted-foreground text-xs">Step-by-step guided import with auto column mapping</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <FileSpreadsheet className="w-3.5 h-3.5" />{rawRows.length > 0 ? `${rawRows.length} rows loaded` : 'No file yet'}
            </div>
            {validRows.length > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
                <CheckCircle2 className="w-3.5 h-3.5" />{validRows.length} valid
              </div>
            )}
            <Button variant="outline" size="sm" onClick={downloadTemplate} className="gap-1.5"><Download className="w-3.5 h-3.5" />Template</Button>
          </div>
        </div>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-0">
        {STEPS.map((s, i) => (
          <React.Fragment key={s}>
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${i === step ? 'bg-primary text-primary-foreground' : i < step ? 'text-emerald-600' : 'text-muted-foreground'}`}>
              {i < step ? <CheckCircle2 className="w-4 h-4" /> : <span className="w-5 h-5 rounded-full border-2 flex items-center justify-center text-xs">{i + 1}</span>}
              {s}
            </div>
            {i < STEPS.length - 1 && <ArrowRight className="w-4 h-4 text-muted-foreground mx-1" />}
          </React.Fragment>
        ))}
      </div>

      {/* Step 0: Upload */}
      {step === 0 && (
        <Card>
          <CardContent className="p-8">
            <label
              className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-2xl p-16 hover:border-primary/50 hover:bg-primary/5 cursor-pointer transition-all"
              onDrop={handleDrop} onDragOver={e => e.preventDefault()}
            >
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                <Upload className="w-8 h-8 text-primary" />
              </div>
              <p className="text-lg font-semibold mb-1">Drop your CSV here</p>
              <p className="text-sm text-muted-foreground mb-4">or click to browse files</p>
              <Badge variant="outline" className="text-xs">CSV, TXT supported • up to 10,000 rows</Badge>
              <input ref={inputRef} type="file" accept=".csv,.txt" className="hidden" onChange={handleFileSelect} />
            </label>
            <div className="mt-6 grid grid-cols-3 gap-4 text-center">
              {[
                { icon: FileSpreadsheet, label: 'Auto Column Detection', desc: 'We detect your column names automatically' },
                { icon: Users, label: 'Any Format', desc: 'Flexible column name aliases supported' },
                { icon: Shield, label: 'FCC Ready', desc: 'Consent flags set on import' },
              ].map(({ icon: Icon, label, desc }) => (
                <div key={label} className="p-4 rounded-xl border border-border bg-muted/20">
                  <Icon className="w-6 h-6 text-primary mx-auto mb-2" />
                  <p className="text-xs font-semibold">{label}</p>
                  <p className="text-xs text-muted-foreground mt-1">{desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 1: Map Columns */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Map Your CSV Columns</CardTitle>
            <p className="text-xs text-muted-foreground">We auto-detected the mappings — review and adjust if needed</p>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              {SCHEMA_FIELDS.map(({ key, label, required }) => (
                <div key={key}>
                  <Label className="text-xs mb-1">{label}{required && ' *'}</Label>
                  <Select value={mapping[key] || '__none__'} onValueChange={v => setMapping(m => ({ ...m, [key]: v === '__none__' ? '' : v }))}>
                    <SelectTrigger className={`h-8 text-xs ${required && !mapping[key] ? 'border-amber-400' : ''}`}>
                      <SelectValue placeholder="— skip —" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">— skip —</SelectItem>
                      {csvHeaders.map(h => <SelectItem key={h} value={h}>{h}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>

            {/* Preview */}
            <div className="mt-4 overflow-x-auto rounded-xl border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    {SCHEMA_FIELDS.filter(f => mapping[f.key]).map(f => (
                      <TableHead key={f.key} className="text-xs">{f.label}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                   {mappedRows.slice(0, 5).map((row, i) => (
                    <TableRow key={i} className={!row.first_name || !row.phone ? 'opacity-40 bg-red-500/5' : ''}>
                      {SCHEMA_FIELDS.filter(f => mapping[f.key]).map(f => (
                        <TableCell key={f.key} className="text-xs py-1.5">{row[f.key] || <span className="text-muted-foreground italic">—</span>}</TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">{validRows.length} valid rows</Badge>
              {rawRows.length - validRows.length > 0 && <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">{rawRows.length - validRows.length} will skip (missing name/phone)</Badge>}
            </div>
            <div className="flex justify-between pt-2">
              <Button variant="outline" onClick={() => setStep(0)}><ChevronLeft className="w-4 h-4 mr-1" />Back</Button>
              <Button onClick={() => setStep(2)} disabled={!mapping.first_name || !mapping.phone}>
                Continue <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Review */}
      {step === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Review Data ({validRows.length} leads)</CardTitle>
            <p className="text-xs text-muted-foreground">Showing first 10 valid rows that will be imported</p>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto rounded-xl border border-border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="text-xs">Name</TableHead>
                    <TableHead className="text-xs">Phone</TableHead>
                    <TableHead className="text-xs">Email</TableHead>
                    <TableHead className="text-xs">Company</TableHead>
                    <TableHead className="text-xs">Source</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {validRows.slice(0, 10).map((row, i) => (
                    <TableRow key={i}>
                      <TableCell className="text-xs py-2 font-medium">{row.first_name} {row.last_name}</TableCell>
                      <TableCell className="text-xs font-mono">{row.phone}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{row.email || '—'}</TableCell>
                      <TableCell className="text-xs">{row.company || '—'}</TableCell>
                      <TableCell className="text-xs">{row.source || '—'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {validRows.length > 10 && <p className="text-xs text-muted-foreground mt-2">…and {validRows.length - 10} more</p>}
            <div className="flex justify-between pt-4">
              <Button variant="outline" onClick={() => setStep(1)}><ChevronLeft className="w-4 h-4 mr-1" />Back</Button>
              <Button onClick={() => setStep(3)}>Set Options <ChevronRight className="w-4 h-4 ml-1" /></Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 3: Options */}
      {step === 3 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Import Options</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                <div>
                  <Label className="mb-0 font-medium">Mark as TCPA Consented</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Only enable if you have documented consent for these leads</p>
                </div>
                <Switch checked={options.consent_given} onCheckedChange={v => setOptions(o => ({ ...o, consent_given: v }))} />
              </div>
              <div className="flex items-center justify-between p-4 rounded-xl border border-border">
                <div>
                  <Label className="mb-0 font-medium">Skip Duplicate Phones</Label>
                  <p className="text-xs text-muted-foreground mt-0.5">Deduplicate by phone number before importing</p>
                </div>
                <Switch checked={options.skip_duplicates} onCheckedChange={v => setOptions(o => ({ ...o, skip_duplicates: v }))} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">Default Source (if not in CSV)</Label>
                <Select value={options.default_source} onValueChange={v => setOptions(o => ({ ...o, default_source: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['CSV Import','Web Form','Referral','Cold Outreach','Purchased List','Event','Other'].map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Default Timezone (if not in CSV)</Label>
                <Select value={options.default_timezone} onValueChange={v => setOptions(o => ({ ...o, default_timezone: v }))}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {['America/New_York','America/Chicago','America/Denver','America/Los_Angeles','America/Phoenix','Pacific/Honolulu'].map(tz => (
                      <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800">FCC / TCPA Reminder</p>
                <p className="text-xs text-amber-700 mt-0.5">Only enable consent if you have written proof. The call bot will not dial unconsented leads by default.</p>
              </div>
            </div>

            <div className="flex justify-between pt-2">
              <Button variant="outline" onClick={() => setStep(2)}><ChevronLeft className="w-4 h-4 mr-1" />Back</Button>
              <Button onClick={handleImport} disabled={importing || validRows.length === 0}>
                {importing
                  ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Importing {progress}%...</>
                  : <><FileSpreadsheet className="w-4 h-4 mr-2" />Import {validRows.length} Leads</>}
              </Button>
            </div>

            {importing && (
              <div className="space-y-1 pt-2">
                <div className="flex justify-between text-xs text-muted-foreground"><span>Importing in batches...</span><span>{progress}%</span></div>
                <Progress value={progress} className="h-2" />
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Step 4: Done */}
      {step === 4 && results && (
        <div className="space-y-4">
          <Card className="border-emerald-500/30 bg-emerald-500/5">
            <CardContent className="p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-emerald-600" />
              </div>
              <h2 className="text-xl font-bold text-emerald-700 mb-2">Import Complete!</h2>
              <div className="flex items-center justify-center gap-6 text-sm mt-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-emerald-600">{results.imported}</p>
                  <p className="text-muted-foreground text-xs">Leads Imported</p>
                </div>
                {results.skipped > 0 && (
                  <div className="text-center">
                    <p className="text-2xl font-bold text-amber-600">{results.skipped}</p>
                    <p className="text-muted-foreground text-xs">Rows Skipped</p>
                  </div>
                )}
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">{results.total}</p>
                  <p className="text-muted-foreground text-xs">Total Rows</p>
                </div>
              </div>
              {!options.consent_given && (
                <p className="text-xs text-amber-700 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 mt-6">
                  Leads were imported without consent — visit the Leads page to grant consent before the bot can call them.
                </p>
              )}
              <div className="flex items-center justify-center gap-3 mt-6">
                <Button variant="outline" onClick={reset}>Import Another File</Button>
                <Button onClick={() => navigate('/leads')}>View Leads <ArrowRight className="w-4 h-4 ml-1" /></Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}