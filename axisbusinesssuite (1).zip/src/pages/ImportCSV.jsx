import React, { useState, useRef } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Upload, FileSpreadsheet, Check, AlertCircle, Loader2, X, Download } from 'lucide-react';
import { toast } from 'sonner';

// ─── CSV Parser ───────────────────────────────────────────────────────────────
function parseCSV(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim());
  if (lines.length < 2) return [];

  const parseRow = (line) => {
    const result = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
        else inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(cur.trim()); cur = '';
      } else {
        cur += ch;
      }
    }
    result.push(cur.trim());
    return result;
  };

  const headers = parseRow(lines[0]).map(h =>
    h.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')
  );
  return lines.slice(1).map(line => {
    const vals = parseRow(line);
    const obj = {};
    headers.forEach((h, i) => { obj[h] = (vals[i] || '').trim(); });
    return obj;
  });
}

// ─── Column Mapper ────────────────────────────────────────────────────────────
function mapRow(row) {
  const g = (keys) => {
    for (const k of keys) {
      const v = row[k] || row[k.replace(/_/g, '')] || row[k.replace(/_/g, ' ')] || '';
      if (v) return v;
    }
    return '';
  };
  return {
    first_name: g(['first_name', 'firstname', 'first', 'fname', 'name']),
    last_name:  g(['last_name', 'lastname', 'last', 'lname', 'surname']),
    phone:      g(['phone', 'phone_number', 'phonenumber', 'mobile', 'cell', 'telephone', 'tel']),
    email:      g(['email', 'email_address', 'emailaddress', 'e_mail']),
    company:    g(['company', 'company_name', 'business', 'organization', 'org']),
    source:     g(['source', 'lead_source', 'leadsource', 'origin']),
    timezone:   g(['timezone', 'time_zone', 'tz']),
    notes:      g(['notes', 'note', 'comments', 'comment', 'description']),
  };
}

const BATCH_SIZE = 25;

export default function ImportCSV() {
  const [file, setFile]           = useState(null);
  const [rawRows, setRawRows]     = useState([]);
  const [preview, setPreview]     = useState([]);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress]   = useState(0);
  const [results, setResults]     = useState(null);
  const [statusMsg, setStatusMsg] = useState('');
  const inputRef = useRef();
  const qc = useQueryClient();

  // ── File handling ──────────────────────────────────────────────────────────
  const handleFileSelect = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f); setResults(null); setProgress(0); setStatusMsg('');
    const reader = new FileReader();
    reader.onload = (evt) => {
      const parsed = parseCSV(evt.target.result);
      setRawRows(parsed);
      setPreview(parsed.slice(0, 8).map(mapRow));
    };
    reader.readAsText(f);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const f = e.dataTransfer.files?.[0];
    if (f) handleFileSelect({ target: { files: [f] } });
  };

  // ── Core import via backend function ───────────────────────────────────────
  const handleImport = async () => {
    if (!rawRows.length) return;

    const mapped = rawRows.map(mapRow).filter(r => r.first_name && r.phone);
    const skipped = rawRows.length - mapped.length;

    if (mapped.length === 0) {
      toast.error('No valid leads found. Ensure CSV has first_name and phone columns.');
      return;
    }

    setImporting(true);
    setProgress(0);
    setStatusMsg('Starting import...');

    let totalImported = 0;
    let totalFailed = 0;
    const totalBatches = Math.ceil(mapped.length / BATCH_SIZE);

    for (let i = 0; i < mapped.length; i += BATCH_SIZE) {
      const batch = mapped.slice(i, i + BATCH_SIZE);
      const batchNum = Math.floor(i / BATCH_SIZE) + 1;

      setStatusMsg(`Importing batch ${batchNum} of ${totalBatches}...`);

      try {
        const response = await base44.functions.invoke('bulkImportLeads', { leads: batch });
        totalImported += response.data.imported || 0;
        totalFailed += response.data.failed || 0;
      } catch (err) {
        console.error('Batch error:', err);
        totalFailed += batch.length;
      }

      setProgress(Math.round(((i + batch.length) / mapped.length) * 100));
      // Give React a paint cycle
      await new Promise(r => setTimeout(r, 20));
    }

    setResults({ imported: totalImported, failed: totalFailed, skipped, total: rawRows.length });
    setStatusMsg('');
    await qc.invalidateQueries({ queryKey: ['leads'] });

    if (totalImported > 0) {
      toast.success(`✅ ${totalImported} leads imported successfully!`);
    } else {
      toast.error('No leads were saved. Check the logs for details.');
    }
    setImporting(false);
  };

  // ── Reset ──────────────────────────────────────────────────────────────────
  const reset = () => {
    setFile(null); setRawRows([]); setPreview([]);
    setResults(null); setProgress(0); setStatusMsg('');
    if (inputRef.current) inputRef.current.value = '';
  };

  // ── Template download ──────────────────────────────────────────────────────
  const downloadTemplate = () => {
    const csv = [
      'first_name,last_name,phone,email,company,source,timezone,notes',
      'John,Doe,+15551234567,john@example.com,Acme Corp,Web,America/New_York,""',
      'Jane,Smith,+15559876543,jane@example.com,Beta LLC,Referral,America/Chicago,""',
    ].join('\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    const a = document.createElement('a');
    a.href = url; a.download = 'leads_template.csv'; a.click();
  };

  const validCount   = rawRows.map(mapRow).filter(r => r.first_name && r.phone).length;
  const invalidCount = rawRows.length - validCount;

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Import Leads from CSV</h1>
              <p className="text-muted-foreground text-xs">Bulk import leads — sends batches of {BATCH_SIZE} through a secure backend function</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {rawRows.length > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
                <Check className="w-3.5 h-3.5" />{validCount} valid leads
              </div>
            )}
            <Button variant="outline" size="sm" onClick={downloadTemplate} className="gap-1.5">
              <Download className="w-3.5 h-3.5" />Download Template
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── Main upload area ── */}
        <div className="lg:col-span-2 space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base">Upload File</CardTitle>
              {file && (
                <Button variant="ghost" size="icon" onClick={reset}>
                  <X className="w-4 h-4" />
                </Button>
              )}
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Drop zone */}
              <div
                className="flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl p-10 hover:border-primary/50 hover:bg-primary/5 cursor-pointer transition-all"
                onDrop={handleDrop}
                onDragOver={e => e.preventDefault()}
                onClick={() => !importing && inputRef.current?.click()}
              >
                <Upload className="w-10 h-10 text-muted-foreground mb-3" />
                {file ? (
                  <div className="text-center">
                    <p className="text-sm font-semibold text-primary">{file.name}</p>
                    <p className="text-xs text-muted-foreground mt-1">{rawRows.length} rows detected</p>
                  </div>
                ) : (
                  <>
                    <span className="text-sm font-medium">Click to upload or drag &amp; drop CSV</span>
                    <span className="text-xs text-muted-foreground mt-1">
                      CSV format • Any column naming • Up to 10,000+ rows
                    </span>
                  </>
                )}
                <input
                  ref={inputRef}
                  type="file"
                  accept=".csv,.txt"
                  className="hidden"
                  onChange={handleFileSelect}
                />
              </div>

              {/* Stats + progress + import button */}
              {rawRows.length > 0 && !results && (
                <>
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className="bg-primary/10 text-primary border-primary/20">
                      {rawRows.length} rows detected
                    </Badge>
                    <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                      {validCount} valid
                    </Badge>
                    {invalidCount > 0 && (
                      <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">
                        {invalidCount} skipped (missing name/phone)
                      </Badge>
                    )}
                  </div>

                  {importing && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{statusMsg || 'Importing…'}</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}

                  <Button
                    className="w-full"
                    onClick={handleImport}
                    disabled={importing || validCount === 0}
                  >
                    {importing ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Importing… {progress}%</>
                    ) : (
                      <><FileSpreadsheet className="w-4 h-4 mr-2" />Import {validCount} Leads</>
                    )}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>

          {/* Column mapping preview */}
          {preview.length > 0 && !results && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">
                  Column Mapping Preview (first {preview.length} rows)
                </CardTitle>
              </CardHeader>
              <CardContent className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      {['first_name','last_name','phone','email','company','source'].map(h => (
                        <TableHead key={h} className="text-xs capitalize">{h.replace(/_/g, ' ')}</TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.map((row, i) => (
                      <TableRow key={i} className={!row.first_name || !row.phone ? 'opacity-40' : ''}>
                        {['first_name','last_name','phone','email','company','source'].map(k => (
                          <TableCell key={k} className="text-xs py-2">
                            {row[k] || <span className="text-muted-foreground italic">—</span>}
                          </TableCell>
                        ))}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {/* Results */}
          {results && (
            <Card className="border-emerald-500/30 bg-emerald-500/5">
              <CardContent className="p-5">
                <div className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold text-emerald-700">Import Complete</p>
                    <div className="flex gap-4 mt-2 text-sm flex-wrap">
                      <span className="text-emerald-600 font-medium">✓ {results.imported} imported</span>
                      {results.failed > 0 && (
                        <span className="text-red-600">✗ {results.failed} failed</span>
                      )}
                      {results.skipped > 0 && (
                        <span className="text-amber-600">
                          ⚠ {results.skipped} skipped (missing name/phone)
                        </span>
                      )}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={reset}>Import More</Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* ── Column guide ── */}
        <div>
          <Card>
            <CardHeader><CardTitle className="text-base">Supported Column Names</CardTitle></CardHeader>
            <CardContent className="text-sm space-y-3">
              <p className="text-muted-foreground text-xs">
                Auto-detected (case-insensitive, spaces or underscores):
              </p>
              <div className="space-y-2">
                {[
                  { field: 'First Name *', aliases: 'first_name, firstname, fname, name' },
                  { field: 'Phone *',      aliases: 'phone, mobile, cell, telephone, tel' },
                  { field: 'Last Name',    aliases: 'last_name, lastname, lname' },
                  { field: 'Email',        aliases: 'email, email_address' },
                  { field: 'Company',      aliases: 'company, business, org' },
                  { field: 'Source',       aliases: 'source, lead_source' },
                  { field: 'Timezone',     aliases: 'timezone, tz' },
                  { field: 'Notes',        aliases: 'notes, comments' },
                ].map(({ field, aliases }) => (
                  <div key={field} className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0" />
                      <span className="font-medium text-xs">{field}</span>
                    </div>
                    <p className="text-xs text-muted-foreground pl-3 font-mono">{aliases}</p>
                  </div>
                ))}
              </div>
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-amber-700">
                    Imported leads require consent verification before the bot will call them.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}