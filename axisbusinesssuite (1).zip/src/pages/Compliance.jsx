import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShieldCheck, Shield, AlertTriangle, CheckCircle2, FileText, Clock, Mic, Key, Archive, Bot, Phone, Lock, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const eventIcons = {
  consent_recorded: CheckCircle2,
  dnc_added: Shield,
  dnc_removed: AlertTriangle,
  time_violation_blocked: Clock,
  caller_id_check: FileText,
  tcpa_disclosure: FileText,
  opt_out_processed: Shield,
};

const eventColors = {
  consent_recorded: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  dnc_added: 'bg-red-500/10 text-red-600 border-red-500/20',
  dnc_removed: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  time_violation_blocked: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
  caller_id_check: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  tcpa_disclosure: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  opt_out_processed: 'bg-red-500/10 text-red-600 border-red-500/20',
};

const MANDATORY_DISCLOSURE = `"Hello, this is Trinity, an AI assistant calling on behalf of [Company Name]. This call may be recorded for quality and compliance purposes. If you did not consent to receive this call or wish to be removed from our list, please say 'stop' at any time."`;

const CONSENT_TYPES = [
  { type: 'Oral Consent', desc: 'Real-time spoken consent captured and transcribed during call', icon: Mic, color: 'text-blue-400' },
  { type: 'Written Consent', desc: 'Signed form or digital agreement prior to calling', icon: FileText, color: 'text-purple-400' },
  { type: 'Cryptographic Timestamp', desc: 'SHA-256 hash of consent record + timestamp logged immutably', icon: Key, color: 'text-amber-400' },
  { type: 'DNC Sync', desc: 'Automatic cross-check against FTC/state DNC registries pre-call', icon: Shield, color: 'text-red-400' },
  { type: 'Call Archival', desc: '7-year encrypted call recording retention for regulatory audit', icon: Archive, color: 'text-emerald-400' },
  { type: 'AI Disclosure', desc: 'Mandatory Trinity AI disclosure at call start, every call', icon: Bot, color: 'text-violet-400' },
];

export default function Compliance() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [logConsentLoading, setLogConsentLoading] = useState(false);

  const { data: logs = [], isLoading } = useQuery({ queryKey: ['compliance'], queryFn: () => base44.entities.ComplianceLog.list('-created_date') });
  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list() });
  const { data: dnc = [] } = useQuery({ queryKey: ['dnc'], queryFn: () => base44.entities.DNCEntry.list() });

  const compliantCalls = calls.filter(c => c.fcc_compliant).length;
  const complianceRate = calls.length > 0 ? Math.round((compliantCalls / calls.length) * 100) : 100;
  const violationsBlocked = logs.filter(l => l.event_type === 'time_violation_blocked').length;

  const logConsentEvent = async (eventType) => {
    setLogConsentLoading(true);
    try {
      const ts = new Date().toISOString();
      // Simulate cryptographic hash of consent event
      const encoder = new TextEncoder();
      const data = encoder.encode(`${eventType}:${user?.email}:${ts}`);
      const hashBuffer = await crypto.subtle.digest('SHA-256', data);
      const hashArray = Array.from(new Uint8Array(hashBuffer));
      const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

      await base44.functions.invoke('createRecord', {
        entity: 'ComplianceLog',
        data: {
          event_type: eventType,
          description: `${eventType.replace(/_/g, ' ')} — cryptographic timestamp: ${hashHex.slice(0, 16)}...`,
          phone_number: 'Manual entry',
          fcc_compliant: true,
          owner: user?.email,
        }
      });
      qc.invalidateQueries({ queryKey: ['compliance'] });
      toast.success('Compliance event logged with cryptographic timestamp');
    } catch (e) {
      toast.error('Failed to log event: ' + e.message);
    }
    setLogConsentLoading(false);
  };

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Global Compliance Center</h1>
              <p className="text-muted-foreground text-xs">FCC/TCPA · CASL · GDPR/PECR · DNCR — worldwide calling law compliance</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />{complianceRate}% compliant
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold text-red-400">
              <Shield className="w-3.5 h-3.5" />{dnc.length} DNC entries
            </div>
            {violationsBlocked > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
                <AlertTriangle className="w-3.5 h-3.5" />{violationsBlocked} violations blocked
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: 'Compliance Rate', value: `${complianceRate}%`, icon: ShieldCheck, val: 'text-emerald-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
          { label: 'Compliant Calls', value: compliantCalls, icon: CheckCircle2, val: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
          { label: 'DNC Entries', value: dnc.length, icon: Shield, val: 'text-red-400', bg: 'from-red-500/10 to-red-600/5', border: 'border-red-500/20' },
          { label: 'Violations Blocked', value: violationsBlocked, icon: AlertTriangle, val: 'text-amber-400', bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20' },
        ].map(({ label, value, icon: Icon, val, bg, border }) => (
          <div key={label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 ${bg} ${border}`}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-background/40 mb-2">
              <Icon className={`w-3.5 h-3.5 ${val}`} />
            </div>
            <p className={`text-xl font-bold leading-none ${val}`}>{value}</p>
            <p className="text-[10px] text-muted-foreground mt-1">{label}</p>
          </div>
        ))}
      </div>

      {/* Mandatory AI Disclosure Banner */}
      <div className="rounded-xl border border-violet-500/30 bg-violet-500/8 p-4">
        <div className="flex items-start gap-3">
          <Bot className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-bold text-violet-400 mb-1">Mandatory AI Opening Disclosure — Trinity</p>
            <p className="text-xs font-mono text-muted-foreground leading-relaxed bg-background/40 rounded-lg p-3 border border-border">{MANDATORY_DISCLOSURE}</p>
            <p className="text-[10px] text-muted-foreground mt-2">FCC Rule (effective Feb 2024): All AI-generated or AI-assisted calls must disclose the artificial nature of the call at the start. Non-compliance = up to $23,000/violation.</p>
          </div>
        </div>
      </div>

      {/* Consent & Security Engine */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {CONSENT_TYPES.map(ct => (
          <div key={ct.type} className="p-4 rounded-xl border border-border bg-card flex items-start gap-3">
            <ct.icon className={`w-4 h-4 shrink-0 mt-0.5 ${ct.color}`} />
            <div>
              <p className="text-xs font-semibold">{ct.type}</p>
              <p className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">{ct.desc}</p>
            </div>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 ml-auto mt-0.5" />
          </div>
        ))}
      </div>

      {/* Quick log buttons */}
      <div className="flex flex-wrap gap-2 items-center">
        <p className="text-xs font-semibold text-muted-foreground">Quick Log:</p>
        {['consent_recorded', 'tcpa_disclosure', 'dnc_added', 'opt_out_processed'].map(et => (
          <Button key={et} size="sm" variant="outline" className="text-xs h-7 gap-1" disabled={logConsentLoading} onClick={() => logConsentEvent(et)}>
            {logConsentLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Lock className="w-3 h-3" />}
            {et.replace(/_/g, ' ')}
          </Button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader><CardTitle className="text-base">Compliance Audit Trail</CardTitle></CardHeader>
            <CardContent>
              <div className="bg-card border border-border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead>Event</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {isLoading ? (
                      <TableRow><TableCell colSpan={4} className="text-center py-8">Loading...</TableCell></TableRow>
                    ) : logs.length === 0 ? (
                      <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No compliance events logged</TableCell></TableRow>
                    ) : logs.map(log => {
                      const Icon = eventIcons[log.event_type] || Shield;
                      return (
                        <TableRow key={log.id}>
                          <TableCell>
                            <Badge variant="outline" className={eventColors[log.event_type]}>
                              <Icon className="w-3 h-3 mr-1" />
                              {log.event_type?.replace(/_/g, ' ')}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm max-w-xs truncate">{log.description}</TableCell>
                          <TableCell className="font-mono text-sm">{log.phone_number || '—'}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">{log.created_date ? format(new Date(log.created_date), 'MMM d, h:mm a') : ''}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader><CardTitle className="text-base">Global Calling Law Checklist</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {[
              {
                region: '🇺🇸 USA — FCC / TCPA',
                color: 'bg-blue-500/10 border-blue-500/20',
                items: [
                  { label: 'Prior express written consent', desc: 'Required before any AI/autodialed calls (TCPA)' },
                  { label: 'Calling hours: 8AM–9PM local time', desc: 'Calls outside these hours are prohibited' },
                  { label: 'National DNC registry checked', desc: 'Must scrub against FTC DNC list before calling' },
                  { label: 'AI/bot disclosure at call start', desc: 'FCC requires disclosure that caller is artificial/automated' },
                  { label: 'Caller ID displayed', desc: 'Valid caller ID must be transmitted on all calls' },
                  { label: 'Opt-out honored within 30 days', desc: 'Internal DNC maintained for 5+ years' },
                ]
              },
              {
                region: '🇨🇦 Canada — CASL / CRTC',
                color: 'bg-red-500/10 border-red-500/20',
                items: [
                  { label: 'Express or implied consent obtained', desc: 'CASL requires consent before commercial electronic messages' },
                  { label: 'Calling hours: 9AM–9PM local (weekdays), 10AM–6PM (weekends)', desc: 'CRTC Unsolicited Telecommunications Rules' },
                  { label: 'National DNCL checked', desc: "Canada's Do Not Call List must be scrubbed" },
                  { label: 'Unsubscribe mechanism within 10 days', desc: 'Opt-out requests must be honored promptly' },
                ]
              },
              {
                region: '🇬🇧 UK — ICO / PECR / Ofcom',
                color: 'bg-purple-500/10 border-purple-500/20',
                items: [
                  { label: 'Explicit consent under GDPR/UK GDPR', desc: 'Required for marketing calls; legitimate interest insufficient for cold calls' },
                  { label: 'TPS/CTPS registry checked', desc: 'Telephone Preference Service — scrub before calling' },
                  { label: 'Calling hours: 8AM–9PM (Mon–Sat)', desc: 'No calls on Sundays or bank holidays recommended' },
                  { label: 'Transparent data processing notice', desc: 'GDPR privacy notice must be provided to contacts' },
                ]
              },
              {
                region: '🇪🇺 EU — GDPR / ePrivacy Directive',
                color: 'bg-amber-500/10 border-amber-500/20',
                items: [
                  { label: 'Lawful basis established (explicit consent)', desc: 'GDPR Art. 6 — consent is the preferred basis for marketing calls' },
                  { label: 'Data minimization — collect only what\'s needed', desc: 'Do not retain contact data longer than necessary' },
                  { label: 'Right to erasure honored', desc: 'Delete contact data on request within 30 days' },
                  { label: 'Cross-border transfers compliant (SCCs/adequacy)', desc: 'Required for data sent outside EEA' },
                ]
              },
              {
                region: '🇦🇺 Australia — DNCR / Spam Act',
                color: 'bg-green-500/10 border-green-500/20',
                items: [
                  { label: 'Do Not Call Register (DNCR) checked', desc: 'Administered by ACMA — scrub all numbers before calling' },
                  { label: 'Calling hours: 9AM–8PM weekdays, 9AM–5PM Sat', desc: 'No calls on Sundays or public holidays' },
                  { label: 'Consent under Spam Act for electronic messages', desc: 'Required before sending commercial e-communications' },
                  { label: 'Organisation identification on all calls', desc: 'Caller must identify company name and contact details' },
                ]
              },
            ].map((region) => (
              <div key={region.region} className={`rounded-lg border p-3 ${region.color}`}>
                <p className="text-xs font-bold mb-2">{region.region}</p>
                <div className="space-y-1.5">
                  {region.items.map((item, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-xs font-medium leading-snug">{item.label}</p>
                        <p className="text-[10px] text-muted-foreground">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}