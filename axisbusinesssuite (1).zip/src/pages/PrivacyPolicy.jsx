import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Shield } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-8 h-8 text-primary" />
          <h1 className="text-3xl font-bold">Privacy Policy</h1>
        </div>

        <Card>
          <CardContent className="p-8 space-y-6 text-sm leading-relaxed">
            <section>
              <h2 className="text-lg font-bold mb-3">1. Introduction</h2>
              <p>
                Axis Business Suite ("we," "us," "our") is committed to protecting your privacy. This Privacy Policy 
                explains how we collect, use, disclose, and safeguard your information when you use our platform and 
                services. Please read this policy carefully.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">2. Information We Collect</h2>
              
              <h3 className="font-semibold mb-2">2.1 Personal Information</h3>
              <p className="mb-2">We collect personal information that you provide directly to us, including:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Name, email address, and phone number</li>
                <li>Company name and business information</li>
                <li>Payment information (processed securely by third-party payment processors)</li>
                <li>Account credentials and preferences</li>
                <li>Communications with our support team</li>
              </ul>

              <h3 className="font-semibold mb-2 mt-4">2.2 Business Data</h3>
              <p className="mb-2">We collect data you upload or create in the platform:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Lead and contact information</li>
                <li>Call logs and recordings</li>
                <li>CRM data and sales information</li>
                <li>HR and employee records</li>
                <li>Marketing campaign data</li>
              </ul>

              <h3 className="font-semibold mb-2 mt-4">2.3 Usage Information</h3>
              <p className="mb-2">We automatically collect information about how you use the platform:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Device information (browser type, operating system)</li>
                <li>IP address and location data</li>
                <li>Access times and pages viewed</li>
                <li>Features used and interaction patterns</li>
                <li>Log data and analytics</li>
              </ul>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">3. How We Use Your Information</h2>
              <p className="mb-2">We use the information we collect to:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Provide, maintain, and improve our services</li>
                <li>Process transactions and send related information</li>
                <li>Send administrative information (updates, security alerts)</li>
                <li>Provide customer support and respond to inquiries</li>
                <li>Monitor usage trends and optimize user experience</li>
                <li>Detect and prevent fraud, abuse, or security incidents</li>
                <li>Comply with legal obligations and enforce our terms</li>
                <li>Send marketing communications (with your consent, where required)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">4. Information Sharing and Disclosure</h2>
              <p className="mb-2">We do not sell, trade, or rent your personal information. We may share information in these circumstances:</p>
              
              <h3 className="font-semibold mb-2 mt-3">4.1 Service Providers</h3>
              <p>
                We work with third-party vendors who perform services on our behalf (payment processing, hosting, 
                analytics, customer support). These providers have access only to information needed to perform 
                their functions and are bound by confidentiality obligations.
              </p>

              <h3 className="font-semibold mb-2 mt-3">4.2 Legal Requirements</h3>
              <p>
                We may disclose information if required by law, regulation, legal process, or governmental request, 
                or to protect our rights, prevent fraud, or ensure safety.
              </p>

              <h3 className="font-semibold mb-2 mt-3">4.3 Business Transfers</h3>
              <p>
                In connection with a merger, acquisition, or sale of assets, user information may be transferred as 
                a business asset. You will be notified via email and/or prominent notice on our website.
              </p>

              <h3 className="font-semibold mb-2 mt-3">4.4 With Your Consent</h3>
              <p>
                We may share information with third parties when you explicitly consent to such sharing.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">5. Data Security</h2>
              <p>
                We implement appropriate technical and organizational measures to protect your information against 
                unauthorized access, alteration, disclosure, or destruction. These include encryption, secure 
                servers, access controls, and regular security assessments. However, no method of transmission 
                over the internet is 100% secure, and we cannot guarantee absolute security.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">6. Data Retention</h2>
              <p>
                We retain your information for as long as necessary to provide our services, comply with legal 
                obligations, resolve disputes, and enforce our agreements. When you cancel your account, we will 
                retain your data only as required by law or legitimate business purposes.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">7. Your Rights and Choices</h2>
              <p className="mb-2">Depending on your location, you may have the right to:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Access your personal information</li>
                <li>Correct inaccurate data</li>
                <li>Request deletion of your data</li>
                <li>Opt-out of marketing communications</li>
                <li>Restrict or object to certain processing</li>
                <li>Data portability (receive your data in a structured format)</li>
                <li>Withdraw consent (where processing is based on consent)</li>
              </ul>
              <p className="mt-2">
                To exercise these rights, contact us at{' '}
                <a href="mailto:privacy@axisbusiness.com" className="underline text-primary">privacy@axisbusiness.com</a>
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">8. Cookies and Tracking</h2>
              <p>
                We use cookies and similar tracking technologies to collect usage information, remember your 
                preferences, and improve your experience. You can control cookie settings through your browser, 
                but disabling cookies may limit your ability to use certain features.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">9. Third-Party Links</h2>
              <p>
                Our platform may contain links to third-party websites or services. This Privacy Policy does not 
                apply to those sites. We encourage you to review the privacy policies of any third-party sites you visit.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">10. International Data Transfers</h2>
              <p>
                Your information may be transferred to and processed in countries other than your own. We ensure 
                appropriate safeguards are in place, such as standard contractual clauses, to protect your data 
                in accordance with applicable laws.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">11. Children's Privacy</h2>
              <p>
                Our services are not directed to individuals under 18, and we do not knowingly collect personal 
                information from children. If we become aware that we have collected data from a child, we will 
                take steps to delete it.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">12. Changes to This Policy</h2>
              <p>
                We may update this Privacy Policy periodically. We will notify you of material changes via email 
                or prominent notice on our platform. The "Last Updated" date at the bottom indicates when the 
                policy was last revised.
              </p>
            </section>

            <section>
              <h2 className="text-lg font-bold mb-3">13. Contact Us</h2>
              <p>
                For questions or concerns about this Privacy Policy or our data practices, please contact us at:
              </p>
              <ul className="list-none pl-0 space-y-1 mt-2">
                <li>Email: <a href="mailto:privacy@axisbusiness.com" className="underline text-primary">privacy@axisbusiness.com</a></li>
                <li>Address: Axis Business Suite, Attn: Privacy Officer</li>
              </ul>
            </section>

            <div className="pt-6 border-t text-xs text-muted-foreground">
              <p>Last Updated: May 28, 2026</p>
              <p>Effective Date: Immediately upon posting</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}