import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Sparkles, Loader2, Trophy, TrendingUp, Target, Mic,
  ChevronDown, ChevronUp, CheckCircle2, AlertCircle, Lightbulb, Star
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import StatusBadge from '@/components/shared/StatusBadge';
import { useCurrentUser } from '@/hooks/useCurrentUser';

function ScoreMeter({ label, value, color }) {
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-center">
        <span className="text-xs text-muted-foreground">{label}</span>
        <span className="text-sm font-bold" style={{ color }}>{value}</span>
      </div>
      <Progress value={value} className="h-2" />
    </div>
  );
}

function GradeCircle({ score }) {
  const grade = score >= 90 ? 'A' : score >= 80 ? 'B' : score >= 70 ? 'C' : score >= 60 ? 'D' : 'F';
  const color = score >= 80 ? '#22c55e' : score >= 60 ? '#f59e0b' : '#ef4444';
  return (
    <div className="relative w-16 h-16 flex-shrink-0">
      <svg viewBox="0 0 36 36" className="w-16 h-16 -rotate-90">
        <circle cx="18" cy="18" r="15.9" fill="none" stroke="hsl(220,13%,91%)" strokeWidth="3" />
        <circle cx="18" cy="18" r="15.9" fill="none" stroke={color} strokeWidth="3"
          strokeDasharray={`${score} 100`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-lg font-bold leading-none">{grade}</span>
        <span className="text-[9px] text-muted-foreground">{score}</span>
      </div>
    </div>
  );
}

export default function CoachingHub() {
  const [analyzing, setAnalyzing] = useState(null);
  const [expanded, setExpanded] = useState(null);
  const [outcomeFilter, setOutcomeFilter] = useState('all');
  const qc = useQueryClient();
  const { user } = useCurrentUser();

  const { data: calls = [], isLoading } = useQuery({
    queryKey: ['calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 100),
  });
  const { data: sessions = [] } = useQuery({
    queryKey: ['coaching-sessions'],
    queryFn: () => base44.entities.CoachingSession.list('-created_date'),
  });

  const createMutFn = async (data) => {
    await base44.functions.invoke('createRecord', { entity: 'CoachingSession', data });
    qc.invalidateQueries({ queryKey: ['coaching-sessions'] });
  };
  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CoachingSession.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['coaching-sessions'] }),
  });

  const sessionMap = sessions.reduce((acc, s) => { acc[s.call_log_id] = s; return acc; }, {});

  const analyzeCall = async (call) => {
    if (!call.transcript && !call.ai_summary) {
      toast.error('This call has no transcript. Generate a transcript first in Call Logs.');
      return;
    }
    setAnalyzing(call.id);

    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert sales call coach. Analyze this AI sales call and provide detailed coaching feedback.

Call Details:
- Lead: ${call.lead_name}
- Duration: ${call.duration_seconds || 0} seconds
- Status: ${call.status}
- Outcome: ${call.outcome || 'unknown'}
- FCC Compliant: ${call.fcc_compliant ? 'Yes' : 'No'}
- Transcript: ${call.transcript || 'Not available'}
- AI Summary: ${call.ai_summary || 'Not available'}

Score each dimension 0-100:
1. Opening (first impression, disclosure, rapport)
2. Objection Handling (responses to pushback)
3. Closing (appointment setting, next steps)
4. Compliance (FCC/TCPA adherence)
5. Overall score

Provide 2-3 specific strengths, 2-3 improvement areas, and 2 script suggestions.`,
      response_json_schema: {
        type: "object",
        properties: {
          overall_score: { type: "number" },
          opening_score: { type: "number" },
          objection_handling_score: { type: "number" },
          closing_score: { type: "number" },
          compliance_score: { type: "number" },
          strengths: { type: "array", items: { type: "string" } },
          improvements: { type: "array", items: { type: "string" } },
          script_suggestions: { type: "array", items: { type: "string" } },
          summary: { type: "string" }
        }
      }
    });

    const sessionData = {
      call_log_id: call.id,
      agent_name: call.called_by || 'AI Bot',
      overall_score: result.overall_score,
      opening_score: result.opening_score,
      objection_handling_score: result.objection_handling_score,
      closing_score: result.closing_score,
      compliance_score: result.compliance_score,
      strengths: JSON.stringify(result.strengths || []),
      improvements: JSON.stringify(result.improvements || []),
      script_suggestions: JSON.stringify(result.script_suggestions || []),
      summary: result.summary,
    };

    const existing = sessionMap[call.id];
    if (existing) updateMut.mutate({ id: existing.id, data: sessionData });
    else createMutFn({ ...sessionData, owner: user?.email });

    setAnalyzing(null);
    setExpanded(call.id);
    toast.success(`Call analyzed: ${result.overall_score}/100`);
  };

  const completedCalls = calls.filter(c => c.status === 'completed');
  const filtered = completedCalls.filter(c => outcomeFilter === 'all' || c.outcome === outcomeFilter);

  const avgScore = sessions.length > 0
    ? Math.round(sessions.reduce((a, s) => a + (s.overall_score || 0), 0) / sessions.length)
    : 0;
  const topScore = sessions.length > 0 ? Math.max(...sessions.map(s => s.overall_score || 0)) : 0;
  const analyzedCount = sessions.length;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-500/8 via-card to-primary/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Call Coaching Hub</h1>
              <p className="text-muted-foreground text-xs">AI-powered call analysis and agent performance coaching</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Mic className="w-3.5 h-3.5" />{analyzedCount} analyzed
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />avg {avgScore}/100
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
              <Trophy className="w-3.5 h-3.5" />top {topScore}/100
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-3 flex-wrap">
        <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Filter by outcome" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Outcomes</SelectItem>
            <SelectItem value="appointment_set">Appointment Set</SelectItem>
            <SelectItem value="callback_requested">Callback Requested</SelectItem>
            <SelectItem value="not_interested">Not Interested</SelectItem>
            <SelectItem value="voicemail_left">Voicemail Left</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        <p className="text-sm text-muted-foreground self-center">{filtered.length} calls · {analyzedCount} analyzed</p>
      </div>

      {/* Calls Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Call</TableHead>
              <TableHead>Outcome</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Coach Score</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">No completed calls found</TableCell></TableRow>
            ) : filtered.map(call => {
              const session = sessionMap[call.id];
              const isExpanded = expanded === call.id;
              return (
                <React.Fragment key={call.id}>
                  <TableRow className="hover:bg-muted/30 cursor-pointer" onClick={() => setExpanded(isExpanded ? null : call.id)}>
                    <TableCell>
                      <div>
                        <p className="font-medium text-sm">{call.lead_name || call.phone_number}</p>
                        <p className="text-xs text-muted-foreground font-mono">{call.phone_number}</p>
                      </div>
                    </TableCell>
                    <TableCell><StatusBadge status={call.outcome || call.status} /></TableCell>
                    <TableCell className="text-sm">
                      {call.duration_seconds > 0 ? `${Math.floor(call.duration_seconds / 60)}m ${call.duration_seconds % 60}s` : '—'}
                    </TableCell>
                    <TableCell>
                      {session ? (
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-16 bg-muted rounded-full overflow-hidden">
                            <div className="h-full rounded-full" style={{
                              width: `${session.overall_score}%`,
                              backgroundColor: session.overall_score >= 80 ? '#22c55e' : session.overall_score >= 60 ? '#f59e0b' : '#ef4444'
                            }} />
                          </div>
                          <span className="text-sm font-semibold">{session.overall_score}</span>
                        </div>
                      ) : <span className="text-xs text-muted-foreground">Not analyzed</span>}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {call.created_date ? format(new Date(call.created_date), 'MMM d, h:mm a') : '—'}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" disabled={analyzing === call.id}
                          onClick={(e) => { e.stopPropagation(); analyzeCall(call); }}>
                          {analyzing === call.id
                            ? <Loader2 className="w-3 h-3 animate-spin" />
                            : <><Sparkles className="w-3 h-3 text-primary" />{session ? 'Re-analyze' : 'Analyze'}</>}
                        </Button>
                        {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                      </div>
                    </TableCell>
                  </TableRow>

                  {isExpanded && session && (
                    <TableRow className="bg-muted/10">
                      <TableCell colSpan={6} className="py-5 px-6">
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                          {/* Score meter */}
                          <div className="flex items-start gap-4">
                            <GradeCircle score={session.overall_score} />
                            <div className="flex-1 space-y-2">
                              <ScoreMeter label="Opening" value={session.opening_score} color="#3b82f6" />
                              <ScoreMeter label="Objection Handling" value={session.objection_handling_score} color="#8b5cf6" />
                              <ScoreMeter label="Closing" value={session.closing_score} color="#22c55e" />
                              <ScoreMeter label="Compliance" value={session.compliance_score} color="#f59e0b" />
                            </div>
                          </div>

                          {/* Strengths / Improvements */}
                          <div className="space-y-3">
                            <div>
                              <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wider mb-2 flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5" />Strengths
                              </p>
                              <ul className="space-y-1.5">
                                {JSON.parse(session.strengths || '[]').map((s, i) => (
                                  <li key={i} className="text-xs flex items-start gap-2">
                                    <Star className="w-3 h-3 text-amber-500 flex-shrink-0 mt-0.5" />
                                    {s}
                                  </li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <p className="text-xs font-semibold text-red-500 uppercase tracking-wider mb-2 flex items-center gap-1">
                                <AlertCircle className="w-3.5 h-3.5" />Needs Improvement
                              </p>
                              <ul className="space-y-1.5">
                                {JSON.parse(session.improvements || '[]').map((s, i) => (
                                  <li key={i} className="text-xs flex items-start gap-2">
                                    <Target className="w-3 h-3 text-red-400 flex-shrink-0 mt-0.5" />
                                    {s}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                          {/* Script suggestions */}
                          <div>
                            <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-2 flex items-center gap-1">
                              <Lightbulb className="w-3.5 h-3.5" />Script Suggestions
                            </p>
                            <div className="space-y-2">
                              {JSON.parse(session.script_suggestions || '[]').map((s, i) => (
                                <div key={i} className="p-2.5 bg-primary/5 border border-primary/20 rounded-lg text-xs leading-relaxed">
                                  "{s}"
                                </div>
                              ))}
                            </div>
                            {session.summary && (
                              <p className="text-xs text-muted-foreground mt-3 leading-relaxed border-t border-border pt-3">{session.summary}</p>
                            )}
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  )}
                </React.Fragment>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}