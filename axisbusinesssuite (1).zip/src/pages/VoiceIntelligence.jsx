import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import LiveCommandTab from '@/components/voice/LiveCommandTab';
import AnalyticsDashboardTab from '@/components/voice/AnalyticsDashboardTab';
import SystemAuditTab from '@/components/voice/SystemAuditTab';
import BiometricManagementTab from '@/components/voice/BiometricManagementTab';
import ComplianceAuditTab from '@/components/voice/ComplianceAuditTab';
import { Radio, BarChart3, ShieldCheck, Fingerprint, ScrollText } from 'lucide-react';

export default function VoiceIntelligence() {
  const [activeTab, setActiveTab] = useState('live');

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-primary/10 via-transparent to-amber-500/5 border-b border-border">
        <div className="px-6 py-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
              <Radio className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">AI Voice Intelligence Platform</h1>
              <p className="text-sm text-muted-foreground">Native browser-based voice recognition, biometrics, and conversation intelligence</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-6 py-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-4 h-auto">
            <TabsTrigger value="live" className="flex items-center gap-1.5 py-2">
              <Radio className="w-4 h-4" />
              <span className="hidden sm:inline">Live Command</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-1.5 py-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="audit" className="flex items-center gap-1.5 py-2">
              <ShieldCheck className="w-4 h-4" />
              <span className="hidden sm:inline">System Audit</span>
            </TabsTrigger>
            <TabsTrigger value="biometrics" className="flex items-center gap-1.5 py-2">
              <Fingerprint className="w-4 h-4" />
              <span className="hidden sm:inline">Biometrics</span>
            </TabsTrigger>
            <TabsTrigger value="compliance" className="flex items-center gap-1.5 py-2">
              <ScrollText className="w-4 h-4" />
              <span className="hidden sm:inline">Compliance</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="live"><LiveCommandTab /></TabsContent>
          <TabsContent value="analytics"><AnalyticsDashboardTab /></TabsContent>
          <TabsContent value="audit"><SystemAuditTab /></TabsContent>
          <TabsContent value="biometrics"><BiometricManagementTab /></TabsContent>
          <TabsContent value="compliance"><ComplianceAuditTab /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}