import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  MessageSquare, Mail, Phone, MessageCircle, Globe, Users,
  Zap, Brain, ArrowRight, CheckCircle2, Clock, TrendingUp,
  Bell, Activity, Inbox, Send, Radio
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';

const CHANNELS = [
  { id: 'voice', label: 'Voice / AI Call Bot', icon: Phone, color: 'emerald', status: 'active', path: '/call-bot', desc: 'AI-powered outbound calling with real-time transcription' },
  { id: 'sms', label: 'SMS Inbox', icon: MessageSquare, color: 'blue', status: 'active', path: '/sms', desc: 'Two-way text messaging with leads and customers' },
  { id: 'email', label: 'Email Client', icon: Mail, color: 'amber', status: 'active', path: '/email', desc: 'Full email threading and lead communication' },
  { id: 'chat', label: 'AE Team Chat', icon: MessageCircle, color: 'purple', status: 'active', path: '/ae-chat', desc: 'Internal team messaging and collaboration' },
  { id: 'social', label: 'Social Media AI', icon: Globe, color: 'pink', status: 'active', path: '/social-media', desc: 'Automated content across Facebook, Instagram, LinkedIn' },
  { id: 'calendly', label: 'Scheduling', icon: Clock, color: 'orange', status: 'active', path: '/zoom-scheduler', desc: 'Automated appointment booking via Calendly & Zoom' },
];

const colorMap = {
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20' },
  pink: { bg: 'bg-pink-500/10', text: 'text-pink-400', border: 'border-pink-500/20' },
  orange: { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/20' },
};

const SEQUENCE_TEMPLATES = [
  { name: 'Cold Lead Follow-Up', steps: ['Call Day 1', 'SMS Day 2', 'Email Day 3', 'Call Day 5', 'Email Day 7'], desc: 'Standard multi-touch sequence for new cold leads' },
  { name: 'Appointment No-Show', steps: ['SMS Immediate', 'Call +30 min', 'Email +2 hrs', 'Reschedule SMS +1 day'], desc: 'Recovery sequence for leads who missed their appointment' },
  { name: 'Hot Lead Fast Track', steps: ['Call Immediate', 'SMS +10 min', 'Calendar Link Email'], desc: 'Urgent sequence for high-scored inbound leads' },
  { name: 'Re-engagement 30-Day', steps: ['Email Day 1', 'Call Day 3', 'SMS Day 7', 'Final Email Day 14'], desc: 'Win back leads who went cold over 30 days' },
];

export default function OmniChannel() {
  const [selectedTemplate, setSelectedTemplate] = useState(null);

  const { data: leads = [] } = useQuery({ queryKey: ['om-leads'], queryFn: () => base44.entities.Lead.list('-created_date', 100) });
  const { data: calls = [] } = useQuery({ queryKey: ['om-calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 100) });
  const { data: smsMessages = [] } = useQuery({ queryKey: ['om-sms'], queryFn: () => base44.entities.SmsMessage.list('-created_date', 100) });
  const { data: emails = [] } = useQuery({ queryKey: ['om-emails'], queryFn: () => base44.entities.EmailMessage.list('-created_date', 100) });

  const totalTouchpoints = calls.length + smsMessages.length + emails.length;
  const last7Days = (arr) => arr.filter(i => i.created_date && new Date(i.created_date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000));

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-blue-500/20 bg-gradient-to-br from-blue-500/8 via-card to-purple-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center">
              <Radio className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">OmniChannel Engagement Hub</h1>
              <p className="text-muted-foreground text-xs">Unified voice · SMS · email · chat · social — all channels in one place</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Zap className="w-3.5 h-3.5" />{totalTouchpoints.toLocaleString()} Total Touchpoints
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />All Channels Active
            </div>
          </div>
        </div>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Calls (7d)', value: last7Days(calls).length, icon: Phone, color: 'text-emerald-400' },
          { label: 'SMS Sent (7d)', value: last7Days(smsMessages).filter(s => s.direction === 'sent').length, icon: MessageSquare, color: 'text-blue-400' },
          { label: 'Emails (7d)', value: last7Days(emails).length, icon: Mail, color: 'text-amber-400' },
          { label: 'Active Leads', value: leads.filter(l => ['new', 'contacted', 'qualified'].includes(l.status)).length, icon: Users, color: 'text-purple-400' },
        ].map((kpi) => (
          <div key={kpi.label} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{kpi.label}</p>
              <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
            </div>
            <p className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Channel Cards */}
      <div>
        <h2 className="text-sm font-bold mb-3 flex items-center gap-2"><Inbox className="w-4 h-4 text-muted-foreground" />Active Communication Channels</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {CHANNELS.map((ch) => {
            const c = colorMap[ch.color] || colorMap.blue;
            return (
              <Link key={ch.id} to={ch.path}>
                <div className={`rounded-xl border ${c.border} bg-card p-4 hover:bg-muted/20 transition-all group cursor-pointer h-full`}>
                  <div className="flex items-start justify-between mb-3">
                    <div className={`w-9 h-9 rounded-xl ${c.bg} flex items-center justify-center`}>
                      <ch.icon className={`w-4.5 h-4.5 ${c.text}`} />
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span className="text-[10px] text-emerald-400 font-semibold">Active</span>
                    </div>
                  </div>
                  <p className="font-semibold text-sm">{ch.label}</p>
                  <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">{ch.desc}</p>
                  <div className={`mt-3 flex items-center gap-1 text-xs font-medium ${c.text} opacity-0 group-hover:opacity-100 transition-opacity`}>
                    Open <ArrowRight className="w-3 h-3" />
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Sequence Templates */}
      <div>
        <h2 className="text-sm font-bold mb-3 flex items-center gap-2"><Brain className="w-4 h-4 text-muted-foreground" />Multi-Channel Sequence Playbooks</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {SEQUENCE_TEMPLATES.map((tmpl) => (
            <div
              key={tmpl.name}
              onClick={() => setSelectedTemplate(selectedTemplate === tmpl.name ? null : tmpl.name)}
              className={`rounded-xl border p-4 cursor-pointer transition-all ${selectedTemplate === tmpl.name ? 'border-primary/40 bg-primary/5' : 'border-border bg-card hover:border-primary/20'}`}
            >
              <div className="flex items-start justify-between mb-2">
                <p className="font-semibold text-sm">{tmpl.name}</p>
                <Badge variant="outline" className="text-[9px]">{tmpl.steps.length} steps</Badge>
              </div>
              <p className="text-[11px] text-muted-foreground mb-3">{tmpl.desc}</p>
              <div className="flex flex-wrap gap-1.5">
                {tmpl.steps.map((step, i) => (
                  <div key={i} className="flex items-center gap-1">
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground font-medium">{step}</span>
                    {i < tmpl.steps.length - 1 && <ArrowRight className="w-2.5 h-2.5 text-muted-foreground/40" />}
                  </div>
                ))}
              </div>
              {selectedTemplate === tmpl.name && (
                <div className="mt-3 pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground mb-2">Configure this playbook in Nurture Workflows:</p>
                  <Link to="/nurture">
                    <Button size="sm" className="w-full gap-2 text-xs">
                      <Send className="w-3.5 h-3.5" />Open Nurture Workflows
                    </Button>
                  </Link>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Activity Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Activity className="w-4 h-4 text-muted-foreground" />Recent Communication Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {[
              ...calls.slice(0, 5).map(c => ({ type: 'call', icon: Phone, label: `Call to ${c.lead_name || c.phone_number}`, sub: c.status, color: 'text-emerald-400', time: c.created_date })),
              ...smsMessages.slice(0, 5).map(s => ({ type: 'sms', icon: MessageSquare, label: `SMS ${s.direction} · ${s.phone_number}`, sub: s.status, color: 'text-blue-400', time: s.created_date })),
              ...emails.slice(0, 5).map(e => ({ type: 'email', icon: Mail, label: `Email: ${e.subject}`, sub: e.to_address, color: 'text-amber-400', time: e.created_date })),
            ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 15).map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-2.5 bg-muted/30 rounded-lg">
                <div className={`w-7 h-7 rounded-lg bg-background flex items-center justify-center shrink-0`}>
                  <item.icon className={`w-3.5 h-3.5 ${item.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{item.label}</p>
                  <p className="text-[10px] text-muted-foreground truncate capitalize">{item.sub}</p>
                </div>
                {item.time && <p className="text-[10px] text-muted-foreground shrink-0">{format(new Date(item.time), 'MMM d h:mm a')}</p>}
              </div>
            ))}
            {totalTouchpoints === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">No communication activity yet</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}