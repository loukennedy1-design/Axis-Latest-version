import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import StatusBadge from '@/components/shared/StatusBadge';
import { Phone, Shield, Clock, Bot, Loader2, ListTodo, Sparkles, ChevronDown, ChevronUp, Mic, TrendingUp, TrendingDown, Minus, BarChart2, Headphones, AlertTriangle, Mail, MessageSquare, Calendar } from 'lucide-react';
import TranscriptPanel from '@/components/calls/TranscriptPanel';
import ClickToCall from '@/components/shared/ClickToCall';
import CallRecordingPlayer from '@/components/calls/CallRecordingPlayer';
import { EntityActions } from '@/components/shared/ContextualActions';
import { EntityActions as ContextualActions } from '@/components/shared/ContextualActions';
import { format, addDays } from 'date-fns';
import { toast } from 'sonner';
import PullToRefresh from '@/components/shared/PullToRefresh';

const SENTIMENT_CONFIG = {
  positive: { icon: TrendingUp, label: 'Positive', className: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' },
  neutral: { icon: Minus, label: 'Neutral', className: 'bg-slate-500/10 text-slate-500 border-slate-500/20' },
  negative: { icon: TrendingDown, label: 'Negative', className: 'bg-red-500/10 text-red-600 border-red-500/20' },
};

export default function CallLogs() {
  const [selected, setSelected] = useState(null);
  const [showPlayer, setShowPlayer] = useState(null);
  const [outcomeFilter, setOutcomeFilter] = useState('all');
  // Intelligent default - most common outcome for filtering
  const [showOnlyCompliant, setShowOnlyCompliant] = useState(false);
  const [generatingFor, setGeneratingFor] = useState(null);
  const [bulkAnalyzing, setBulkAnalyzing] = useState(false);
  const [analysisCache, setAnalysisCache] = useState({});
  const [clearingData, setClearingData] = useState(false);
  const qc = useQueryClient();

  const { data: calls = [], isLoading, refetch } = useQuery({
    queryKey: ['calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date'),
  });

  const filtered = calls.filter(c => outcomeFilter === 'all' || c.outcome === outcomeFilter);

  // Generate AI summary + follow-up tasks for a call
  const generateSummaryAndTasks = async (call) => {
    setGeneratingFor(call.id);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a sales CRM assistant. Analyze this AI sales call and produce a structured summary and follow-up action plan.

Lead: ${call.lead_name}
Phone: ${call.phone_number}
Call Status: ${call.status}
Outcome: ${call.outcome}
Duration: ${call.duration_seconds}s
Transcript: ${call.transcript || 'Not available'}
AI Summary: ${call.ai_summary || 'Not available'}

Return a structured analysis.`,
        response_json_schema: {
          type: "object",
          properties: {
            enhanced_summary: { type: "string", description: "2-3 sentence professional summary of the call" },
            sentiment: { type: "string", enum: ["positive", "neutral", "negative"] },
            key_points: { type: "array", items: { type: "string" }, description: "3-5 key bullet points from the call" },
            follow_up_tasks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  task_type: { type: "string", enum: ["call_back", "send_email", "send_sms", "schedule_appointment", "review_lead", "other"] },
                  priority: { type: "string", enum: ["high", "medium", "low"] },
                  notes: { type: "string" },
                  days_until_due: { type: "number" }
                }
              }
            }
          }
        }
      });

      // Update call log with enhanced summary
      await base44.entities.CallLog.update(call.id, { ai_summary: result.enhanced_summary });

      // Create follow-up tasks
      if (result.follow_up_tasks?.length > 0) {
        await Promise.all(result.follow_up_tasks.map(task =>
          base44.functions.invoke('createRecord', {
            entity: 'FollowUpTask',
            data: {
              lead_id: call.lead_id,
              lead_name: call.lead_name,
              lead_phone: call.phone_number,
              task_type: task.task_type,
              priority: task.priority,
              notes: task.notes,
              due_date: addDays(new Date(), task.days_until_due || 1).toISOString(),
              ai_generated: true,
              call_log_id: call.id,
              status: 'pending',
            }
          })
        ));
      }

      qc.invalidateQueries({ queryKey: ['calls'] });
      qc.invalidateQueries({ queryKey: ['followup-tasks'] });

      toast.success(`✅ Summary generated · ${result.follow_up_tasks?.length || 0} tasks created`);

      // Cache the analysis result
      setAnalysisCache(prev => ({ ...prev, [call.id]: result }));

      // Update selected if open — use functional updater to avoid stale closure
      setSelected(prev => prev?.id === call.id ? { ...prev, ai_summary: result.enhanced_summary, _analysis: result } : prev);

      return result;
    } finally {
      setGeneratingFor(null);
    }
  };

  const bulkAnalyzeAll = async () => {
    const unanalyzed = calls.filter(c => !c.ai_summary && c.status === 'completed');
    if (!unanalyzed.length) { toast.info('All completed calls already have summaries'); return; }
    setBulkAnalyzing(true);
    let count = 0;
    for (const call of unanalyzed.slice(0, 10)) {
      await generateSummaryAndTasks(call);
      count++;
    }
    setBulkAnalyzing(false);
    toast.success(`Analyzed ${count} calls`);
  };

  const completedCalls = calls.filter(c => c.status === 'completed').length;
  const appointmentsCalls = calls.filter(c => c.outcome === 'appointment_set').length;
  const analyzedCalls = calls.filter(c => c.ai_summary).length;
  const coachingRequired = calls.filter(c => c.requires_coaching).length;
  const avgDuration = calls.length > 0 ? Math.round(calls.reduce((s, c) => s + (c.duration_seconds || 0), 0) / calls.length) : 0;

  // Clear all call data
  const handleClearData = async () => {
    if (!confirm('Are you sure you want to delete ALL call logs? This cannot be undone.')) return;
    setClearingData(true);
    try {
      const result = await base44.functions.invoke('clearCallData', {});
      toast.success(result.message || 'All call data cleared');
      qc.invalidateQueries({ queryKey: ['calls'] });
    } catch (error) {
      toast.error('Failed to clear data: ' + error.message);
    } finally {
      setClearingData(false);
    }
  };

  // Auto-refresh every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      qc.invalidateQueries({ queryKey: ['calls'] });
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <PullToRefresh onRefresh={refetch}>
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-slate-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Phone className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Call Logs</h1>
              <p className="text-muted-foreground text-xs">{calls.length} total · AI-analyzed call records</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <Phone className="w-3.5 h-3.5" />{completedCalls} completed
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <Clock className="w-3.5 h-3.5" />{appointmentsCalls} appts set
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <Bot className="w-3.5 h-3.5" />{analyzedCalls} analyzed
            </div>
            {coachingRequired > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold text-red-400">
                <AlertTriangle className="w-3.5 h-3.5" />{coachingRequired} need coaching
              </div>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-1.5" 
              onClick={handleClearData} 
              disabled={clearingData}
              aria-label="Clear all call data"
            >
              {clearingData ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Clearing...</> : <><AlertTriangle className="w-3.5 h-3.5" />Clear Data</>}
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-1.5" 
              onClick={bulkAnalyzeAll} 
              disabled={bulkAnalyzing}
              aria-label="Analyze all calls with AI"
            >
              {bulkAnalyzing ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Analyzing...</> : <><BarChart2 className="w-3.5 h-3.5" />Analyze All</>}
            </Button>
            <Select value={outcomeFilter} onValueChange={setOutcomeFilter}>
              <SelectTrigger className="w-40 h-9" aria-label="Filter by call outcome">
                <SelectValue placeholder="Filter outcome" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Outcomes</SelectItem>
                {['appointment_set','callback_requested','not_interested','wrong_number','dnc_requested','voicemail_left','other'].map(o => (
                  <SelectItem key={o} value={o}>{o.replace(/_/g, ' ')}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Lead</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Outcome</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Compliant</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="w-28">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No call logs</TableCell></TableRow>
            ) : filtered.map(call => (
              <TableRow key={call.id} className="hover:bg-muted/30 transition-colors">
                <TableCell className="font-medium cursor-pointer" onClick={() => setSelected(call)}>{call.lead_name || '—'}</TableCell>
                <TableCell><ClickToCall phone={call.phone_number} /></TableCell>
                <TableCell><StatusBadge status={call.status} /></TableCell>
                <TableCell><StatusBadge status={call.outcome} /></TableCell>
                <TableCell className="text-sm">{call.duration_seconds ? `${Math.floor(call.duration_seconds / 60)}:${String(call.duration_seconds % 60).padStart(2, '0')}` : '—'}</TableCell>
                <TableCell>
                  {call.fcc_compliant
                    ? <Badge className="bg-emerald-500/10 text-emerald-600 border-emerald-500/20"><Shield className="w-3 h-3 mr-1" />Yes</Badge>
                    : <Badge className="bg-red-500/10 text-red-600 border-red-500/20">No</Badge>}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">{call.created_date && !isNaN(new Date(call.created_date)) ? format(new Date(call.created_date), 'MMM d, h:mm a') : ''}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    {/* Contextual Actions Group - Enhanced UX */}
                    <EntityActions
                      entity={call}
                      entityType="call"
                      onAction={(actionType, entity) => {
                        if (actionType === 'call') window.open(`tel:${entity.phone_number}`, '_self');
                        if (actionType === 'summary') setSelected(entity);
                        if (actionType === 'schedule') { /* Implement scheduling */ }
                      }}
                    />
                    {/* Keep existing buttons for backward compatibility */}
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs gap-1 px-2 hidden lg:inline-flex"
                      onClick={() => setSelected(call)}
                      aria-label={`View summary for ${call.lead_name}`}
                    >
                      <Bot className="w-3 h-3" />Summary
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs gap-1 px-2 hidden lg:inline-flex"
                      onClick={() => setShowPlayer(call)}
                      disabled={!call.recording_url && !call.transcript}
                      aria-label={call.recording_url ? 'Play recording' : 'Review call'}
                    >
                      <Headphones className="w-3 h-3" />
                      {call.recording_url ? 'Play' : 'Review'}
                    </Button>
                    <Button
                      variant="ghost" size="icon" className="h-7 w-7 lg:hidden"
                      disabled={generatingFor === call.id}
                      onClick={() => generateSummaryAndTasks(call)}
                      title="Generate AI summary & tasks"
                      aria-label="Generate AI summary"
                    >
                      {generatingFor === call.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-primary" />}
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Call Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between pr-6">
              <DialogTitle>Call Summary — {selected?.lead_name}</DialogTitle>
              {selected && (
                <Button size="sm" variant="outline" className="gap-1.5" disabled={generatingFor === selected.id}
                  onClick={() => generateSummaryAndTasks(selected)}>
                  {generatingFor === selected.id
                    ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Generating...</>
                    : <><Sparkles className="w-3.5 h-3.5 text-primary" />Re-analyze</>}
                </Button>
              )}
            </div>
          </DialogHeader>
          {selected && (() => {
            const analysis = selected._analysis || analysisCache[selected.id];
            const sentimentCfg = analysis?.sentiment ? SENTIMENT_CONFIG[analysis.sentiment] : null;
            const SentimentIcon = sentimentCfg?.icon;
            return (
            <div className="space-y-5">
              {/* Meta */}
              <div className="grid grid-cols-2 gap-3 p-4 bg-muted/30 rounded-xl">
                <div><p className="text-xs text-muted-foreground">Lead</p><p className="font-medium text-sm">{selected.lead_name}</p></div>
                <div><p className="text-xs text-muted-foreground">Phone</p><ClickToCall phone={selected.phone_number} /></div>
                <div><p className="text-xs text-muted-foreground">Status</p><StatusBadge status={selected.status} /></div>
                <div><p className="text-xs text-muted-foreground">Outcome</p><StatusBadge status={selected.outcome} /></div>
                <div><p className="text-xs text-muted-foreground">Duration</p><p className="text-sm">{selected.duration_seconds ? `${Math.floor(selected.duration_seconds / 60)}m ${selected.duration_seconds % 60}s` : '—'}</p></div>
                <div><p className="text-xs text-muted-foreground">Date</p><p className="text-sm">{selected.created_date && !isNaN(new Date(selected.created_date)) ? format(new Date(selected.created_date), 'MMM d, yyyy h:mm a') : '—'}</p></div>
                {sentimentCfg && (
                  <div className="col-span-2">
                    <p className="text-xs text-muted-foreground mb-1">Call Sentiment</p>
                    <Badge variant="outline" className={`gap-1 ${sentimentCfg.className}`}>
                      <SentimentIcon className="w-3 h-3" />{sentimentCfg.label}
                    </Badge>
                  </div>
                )}
              </div>

              {/* AI Summary */}
              {selected.ai_summary ? (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Bot className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">AI Summary</p>
                  </div>
                  <p className="text-sm bg-primary/5 border border-primary/10 p-4 rounded-xl leading-relaxed">{selected.ai_summary}</p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6 gap-3 border-2 border-dashed border-border rounded-xl">
                  <Sparkles className="w-8 h-8 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">No summary yet</p>
                  <Button size="sm" onClick={() => generateSummaryAndTasks(selected)} disabled={generatingFor === selected.id}>
                    {generatingFor === selected.id ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Analyzing...</> : <><Sparkles className="w-3.5 h-3.5 mr-1.5" />Generate Summary & Tasks</>}
                  </Button>
                </div>
              )}

              {/* Key Points */}
              {analysis?.key_points?.length > 0 && (
                <div>
                  <p className="text-sm font-semibold mb-2">Key Points</p>
                  <ul className="space-y-1.5">
                    {analysis.key_points.map((pt, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                        {pt}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Follow-up Tasks Generated */}
              {analysis?.follow_up_tasks?.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <ListTodo className="w-4 h-4 text-primary" />
                    <p className="text-sm font-semibold">Follow-Up Tasks Created</p>
                    <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">{analysis.follow_up_tasks.length}</Badge>
                  </div>
                  <div className="space-y-1.5">
                    {analysis.follow_up_tasks.map((t, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 bg-muted/30 rounded-lg text-sm">
                        <Badge variant="outline" className="capitalize text-xs">{t.task_type.replace(/_/g, ' ')}</Badge>
                        <Badge variant="outline" className={`text-xs ${t.priority === 'high' ? 'bg-red-500/10 text-red-600 border-red-500/20' : t.priority === 'medium' ? 'bg-amber-500/10 text-amber-600 border-amber-500/20' : 'bg-blue-500/10 text-blue-600 border-blue-500/20'}`}>{t.priority}</Badge>
                        <span className="text-muted-foreground flex-1 truncate">{t.notes}</span>
                        <span className="text-xs text-muted-foreground">Due in {t.days_until_due}d</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Transcript */}
              {/* Transcription Panel */}
              <TranscriptPanel
                call={selected}
                onUpdate={(updated) => setSelected(updated)}
              />

              {/* Compliance Footer */}
              <div className="flex gap-4 text-xs text-muted-foreground pt-2 border-t border-border">
                <span className="flex items-center gap-1"><Shield className="w-3 h-3" />FCC: {selected.fcc_compliant ? 'Compliant' : 'Non-compliant'}</span>
                <span className="flex items-center gap-1"><Phone className="w-3 h-3" />Caller ID: {selected.caller_id_displayed ? 'Shown' : 'Hidden'}</span>
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />Consent: {selected.consent_verified ? 'Verified' : 'Unverified'}</span>
              </div>
            </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Recording Player & Coaching Dialog */}
      <Dialog open={!!showPlayer} onOpenChange={() => setShowPlayer(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Headphones className="w-5 h-5 text-primary" />
              Call Recording & Coaching
            </DialogTitle>
          </DialogHeader>
          {showPlayer && (
            <CallRecordingPlayer
              call={showPlayer}
              onClose={() => setShowPlayer(null)}
              onAnalyze={async (callId) => {
                const result = await base44.functions.invoke('analyzeCallCoaching', { call_id: callId });
                if (result.data.success) {
                  qc.invalidateQueries({ queryKey: ['calls'] });
                  setShowPlayer({ ...showPlayer, ...result.data.analysis });
                }
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
    </PullToRefresh>
  );
}