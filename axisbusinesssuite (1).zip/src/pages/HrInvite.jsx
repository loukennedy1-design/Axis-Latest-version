import React, { useState, useMemo, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { ShieldCheck, Lock, AlertCircle, Loader2, CheckCircle2, Eye, EyeOff } from 'lucide-react';

function getPasswordStrength(pwd) {
  let score = 0;
  if (pwd.length >= 8) score++;
  if (pwd.length >= 12) score++;
  if (/[A-Z]/.test(pwd)) score++;
  if (/[a-z]/.test(pwd)) score++;
  if (/[0-9]/.test(pwd)) score++;
  if (/[^A-Za-z0-9]/.test(pwd)) score++;
  return Math.min(score, 4); // 0-4
}

const STRENGTH_LABELS = ['Too short', 'Weak', 'Fair', 'Good', 'Strong'];
const STRENGTH_COLORS = ['bg-muted', 'bg-red-500', 'bg-amber-500', 'bg-blue-500', 'bg-emerald-500'];

export default function HrInvite() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') || '';

  const [status, setStatus] = useState('validating'); // validating | valid | error | activating | success
  const [errorMsg, setErrorMsg] = useState('');
  const [employee, setEmployee] = useState(null);

  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPwd, setShowPwd] = useState(false);
  const [formError, setFormError] = useState('');

  // Validate token on load
  useEffect(() => {
    if (!token) {
      setStatus('error');
      setErrorMsg('No invite token was provided. Please use the link your admin sent you.');
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await base44.functions.invoke('hrPortalInvite', { action: 'validate_token', token });
        if (cancelled) return;
        if (res.data?.valid) {
          setEmployee(res.data.employee);
          setFullName(`${res.data.employee.first_name || ''} ${res.data.employee.last_name || ''}`.trim());
          setStatus('valid');
        } else {
          setStatus('error');
          setErrorMsg(res.data?.error || 'This invite link is no longer valid.');
        }
      } catch (e) {
        if (!cancelled) {
          setStatus('error');
          setErrorMsg('Could not validate invite link. Please try again or contact your admin.');
        }
      }
    })();
    return () => { cancelled = true; };
  }, [token]);

  const strength = useMemo(() => getPasswordStrength(password), [password]);

  const handleActivate = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!fullName.trim()) { setFormError('Please enter your full name.'); return; }
    if (password.length < 8) { setFormError('Password must be at least 8 characters.'); return; }
    if (strength < 2) { setFormError('Please choose a stronger password.'); return; }
    if (password !== confirm) { setFormError('Passwords do not match.'); return; }

    setStatus('activating');
    try {
      const res = await base44.functions.invoke('hrPortalInvite', {
        action: 'activate',
        token,
        full_name: fullName.trim(),
        password,
      });
      if (res.data?.success) {
        setStatus('success');
      } else {
        setStatus('valid');
        setFormError(res.data?.error || 'Activation failed. Please try again.');
      }
    } catch (err) {
      setStatus('valid');
      setFormError(err?.response?.data?.error || err?.message || 'Activation failed. Please try again.');
    }
  };

  // ── AXIS Logo ──
  const Logo = () => (
    <div className="flex items-center gap-2.5 mb-8">
      <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
        <span className="text-primary-foreground font-extrabold text-lg tracking-tight">A</span>
      </div>
      <div>
        <p className="font-poppins font-bold text-lg tracking-tight leading-none">AXIS</p>
        <p className="text-[10px] text-muted-foreground tracking-widest uppercase">Business Suite</p>
      </div>
    </div>
  );

  // ── Validating state ──
  if (status === 'validating') {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <Logo />
        <Loader2 className="w-8 h-8 animate-spin text-primary mb-4" />
        <p className="text-sm text-muted-foreground">Verifying your invite link…</p>
      </div>
    );
  }

  // ── Error / expired state ──
  if (status === 'error') {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <Logo />
        <Card className="max-w-md w-full p-8 text-center border-border bg-card">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-5">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="font-poppins font-bold text-xl mb-2">Invite Link Invalid</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">{errorMsg}</p>
          <div className="rounded-lg bg-muted/50 border border-border p-4 text-left">
            <p className="text-xs text-muted-foreground mb-1">Need a new link?</p>
            <p className="text-sm font-medium">Contact your account administrator to generate a fresh invite link.</p>
          </div>
        </Card>
      </div>
    );
  }

  // ── Success state ──
  if (status === 'success') {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4">
        <Logo />
        <Card className="max-w-md w-full p-8 text-center border-border bg-card">
          <div className="w-16 h-16 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-5">
            <CheckCircle2 className="w-8 h-8 text-emerald-500" />
          </div>
          <h1 className="font-poppins font-bold text-xl mb-2">Account Activated!</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
            Welcome to AXIS, {employee?.first_name || 'team member'}! Your account is ready.
            We've sent a separate email with a link to <span className="text-foreground font-medium">set your password</span> and complete your login setup.
          </p>
          <div className="space-y-3">
            <Button className="w-full" size="lg" onClick={() => navigate('/rep-login')}>
              Go to Login
            </Button>
            <p className="text-xs text-muted-foreground">
              Didn't get the email? Check your spam folder, or contact your admin.
            </p>
          </div>
        </Card>
      </div>
    );
  }

  // ── Valid token — activation form ──
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-8">
      <Logo />

      <Card className="max-w-md w-full p-8 border-border bg-card shadow-xl">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
            <ShieldCheck className="w-7 h-7 text-primary" />
          </div>
          <h1 className="font-poppins font-bold text-xl mb-1">Activate Your Account</h1>
          <p className="text-sm text-muted-foreground">
            You've been invited as{' '}
            <span className="text-primary font-semibold">{employee?.role_label || 'Team Member'}</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1">{employee?.email}</p>
        </div>

        <form onSubmit={handleActivate} className="space-y-4">
          {/* Full Name */}
          <div className="space-y-1.5">
            <Label htmlFor="full_name" className="text-xs font-medium">Full Name</Label>
            <Input
              id="full_name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Your full name"
              autoComplete="name"
              className="h-10"
            />
          </div>

          {/* Password */}
          <div className="space-y-1.5">
            <Label htmlFor="password" className="text-xs font-medium">Password</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPwd ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Create a secure password"
                autoComplete="new-password"
                className="h-10 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPwd(s => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                tabIndex={-1}
              >
                {showPwd ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {/* Strength indicator */}
            {password.length > 0 && (
              <div className="flex items-center gap-2 mt-1.5">
                <div className="flex-1 flex gap-1">
                  {[0, 1, 2, 3].map(i => (
                    <div
                      key={i}
                      className={`h-1.5 flex-1 rounded-full transition-colors ${i < strength ? STRENGTH_COLORS[strength] : 'bg-muted'}`}
                    />
                  ))}
                </div>
                <span className="text-[10px] text-muted-foreground w-14 text-right">{STRENGTH_LABELS[strength]}</span>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <div className="space-y-1.5">
            <Label htmlFor="confirm" className="text-xs font-medium">Confirm Password</Label>
            <div className="relative">
              <Input
                id="confirm"
                type={showPwd ? 'text' : 'password'}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                placeholder="Re-enter your password"
                autoComplete="new-password"
                className={`h-10 pr-10 ${confirm && confirm !== password ? 'border-destructive' : ''}`}
              />
              {confirm && confirm === password && (
                <CheckCircle2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-500" />
              )}
            </div>
            {confirm && confirm !== password && (
              <p className="text-[11px] text-destructive">Passwords do not match</p>
            )}
          </div>

          {/* Form error */}
          {formError && (
            <div className="flex items-start gap-2 rounded-lg bg-destructive/10 border border-destructive/20 p-3">
              <AlertCircle className="w-4 h-4 text-destructive shrink-0 mt-0.5" />
              <p className="text-xs text-destructive">{formError}</p>
            </div>
          )}

          {/* Submit */}
          <Button
            type="submit"
            size="lg"
            className="w-full"
            disabled={status === 'activating'}
          >
            {status === 'activating' ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Activating…</>
            ) : (
              <><Lock className="w-4 h-4" /> Activate My Account</>
            )}
          </Button>
        </form>

        <p className="text-[11px] text-muted-foreground text-center mt-5">
          By activating your account, you agree to keep your login credentials secure and confidential.
        </p>
      </Card>
    </div>
  );
}