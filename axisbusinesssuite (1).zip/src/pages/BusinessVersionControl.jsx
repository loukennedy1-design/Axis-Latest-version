import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { GitBranch, Loader2, History, RotateCcw, GitCompare, Plus } from 'lucide-react';

const TYPE_COLORS = {
  automation: 'text-purple-400', ai_prompt: 'text-pink-400', workflow: 'text-blue-400',
  landing_page: 'text-amber-400', pipeline: 'text-cyan-400', pricing: 'text-emerald-400',
  document: 'text-muted-foreground', form: 'text-indigo-400', crm_field: 'text-orange-400', business_rule: 'text-rose-400'
};

export default function BusinessVersionControl() {
  const [resources, setResources] = useState([]);
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [history, setHistory] = useState(null);
  const [historyName, setHistoryName] = useState('');
  const [compareResult, setCompareResult] = useState(null);
  const [newVer, setNewVer] = useState({ resource_type: 'document', resource_name: '', change_description: '', snapshot_data: '' });

  const fetchAll = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('businessVersionControl', { action: 'get_overview' });
      setResources(res.data?.resources || []);
      setOverview(res.data?.overview);
    } catch { setResources([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleCreate = async () => {
    if (!newVer.resource_name.trim()) return;
    await base44.functions.invoke('businessVersionControl', {
      action: 'create_version', ...newVer,
      snapshot_data: newVer.snapshot_data ? JSON.parse(newVer.snapshot_data) : {}
    });
    setNewVer({ resource_type: 'document', resource_name: '', change_description: '', snapshot_data: '' });
    setShowCreate(false);
    await fetchAll();
  };

  const handleHistory = async (type, name) => {
    setHistoryName(name);
    const res = await base44.functions.invoke('businessVersionControl', { action: 'get_history', resource_type: type, resource_name: name });
    setHistory(res.data?.history || []);
  };

  const handleCompare = async (versionId) => {
    const res = await base44.functions.invoke('businessVersionControl', { action: 'compare', version_id: versionId });
    setCompareResult(res.data);
  };

  const handleRestore = async (versionId) => {
    await base44.functions.invoke('businessVersionControl', { action: 'restore', version_id: versionId });
    await fetchAll();
    if (historyName) await handleHistory(historyName.split(':')[0], historyName.split(':')[1]);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <GitBranch className="w-6 h-6 text-primary" />
            Business Version Control
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Track historical versions of automations, AI prompts, workflows, landing pages, pipelines, pricing, and business rules. Rollback, compare, and view full audit timelines.
          </p>
        </div>
        <Button onClick={() => setShowCreate(true)}><Plus className="w-4 h-4" /> Snapshot Version</Button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <StatCard label="Tracked Resources" value={overview?.tracked_resources ?? '—'} />
        <StatCard label="Total Versions" value={overview?.total_versions ?? '—'} />
        <StatCard label="Resource Types" value={Object.keys(overview?.by_type || {}).length} />
      </div>

      {showCreate && (
        <Card>
          <CardHeader><CardTitle className="text-base">Create Version Snapshot</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <select className="bg-card border border-border rounded-md px-2 py-2 text-sm" value={newVer.resource_type} onChange={e => setNewVer({...newVer, resource_type: e.target.value})}>
                <option value="automation">Automation</option><option value="ai_prompt">AI Prompt</option><option value="workflow">Workflow</option>
                <option value="landing_page">Landing Page</option><option value="pipeline">Pipeline</option><option value="pricing">Pricing</option>
                <option value="document">Document</option><option value="form">Form</option><option value="business_rule">Business Rule</option>
              </select>
              <Input placeholder="Resource name..." value={newVer.resource_name} onChange={e => setNewVer({...newVer, resource_name: e.target.value})} />
            </div>
            <Input placeholder="Change description..." value={newVer.change_description} onChange={e => setNewVer({...newVer, change_description: e.target.value})} />
            <textarea placeholder='Snapshot data (JSON)... e.g. {"prompt":"You are Trinity..."}' value={newVer.snapshot_data} onChange={e => setNewVer({...newVer, snapshot_data: e.target.value})} rows={3} className="w-full bg-card border border-border rounded-md px-3 py-2 text-sm font-mono" />
            <div className="flex gap-2">
              <Button onClick={handleCreate} disabled={!newVer.resource_name.trim()}>Create</Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Resources */}
      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : resources.length ? (
        <div className="space-y-2">
          {resources.map((r, i) => (
            <Card key={i}>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`text-xs font-medium ${TYPE_COLORS[r.type]}`}>{r.type.replace(/_/g, ' ')}</span>
                      <span className="text-xs text-muted-foreground">· v{r.current}</span>
                    </div>
                    <h3 className="font-semibold text-sm mt-0.5">{r.name}</h3>
                    <p className="text-xs text-muted-foreground">{r.versions} version{r.versions !== 1 ? 's' : ''}</p>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => handleHistory(r.type, r.name)}><History className="w-3.5 h-3.5" /> History</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card><CardContent className="py-12 text-center"><GitBranch className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No versioned resources yet. Create a snapshot to start tracking changes.</p></CardContent></Card>
      )}

      {/* History drawer */}
      {history && (
        <div className="fixed inset-0 bg-black/60 z-50 flex justify-end" onClick={() => { setHistory(null); setCompareResult(null); }}>
          <div className="w-full max-w-lg bg-card border-l border-border h-full overflow-y-auto p-6 space-y-4" onClick={e => e.stopPropagation()}>
            <h2 className="text-lg font-bold flex items-center gap-2"><History className="w-5 h-5 text-primary" /> Version History</h2>
            <p className="text-sm text-muted-foreground">{historyName}</p>
            {history.length ? (
              <div className="space-y-2">
                {history.map(v => (
                  <div key={v.id} className="rounded-lg border border-border bg-card/30 p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm">v{v.version_number}</span>
                        {v.is_current && <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400">current</span>}
                      </div>
                      <span className="text-xs text-muted-foreground">{new Date(v.created_date).toLocaleString()}</span>
                    </div>
                    {v.change_description && <p className="text-xs text-muted-foreground mt-1">{v.change_description}</p>}
                    <div className="flex gap-1 mt-2">
                      <Button size="sm" variant="ghost" onClick={() => handleCompare(v.id)}><GitCompare className="w-3.5 h-3.5" /> Compare</Button>
                      {!v.is_current && <Button size="sm" variant="ghost" onClick={() => handleRestore(v.id)}><RotateCcw className="w-3.5 h-3.5" /> Restore</Button>}
                    </div>
                  </div>
                ))}
              </div>
            ) : <p className="text-sm text-muted-foreground">No versions found.</p>}

            {compareResult && (
              <div className="rounded-lg border border-primary/40 bg-primary/5 p-3">
                <p className="text-xs text-muted-foreground uppercase mb-1">Comparison (v{compareResult.current?.version})</p>
                <p className="text-sm">{compareResult.diff}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value }) {
  return (
    <Card><CardContent className="pt-5">
      <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold font-poppins mt-1">{value ?? '—'}</p>
    </CardContent></Card>
  );
}