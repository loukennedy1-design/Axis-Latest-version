import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Zap, Shield, Brain, Layers, 
  TrendingUp, Clock, CheckCircle2, Target
} from 'lucide-react';
import SignalExecutionPanel from '@/components/ai/SignalExecutionPanel';
import GovernanceTrustPanel from '@/components/ai/GovernanceTrustPanel';
import DealKnowledgeGraph from '@/components/ai/DealKnowledgeGraph';
import IndustryMicroAppsPanel from '@/components/ai/IndustryMicroAppsPanel';

export default function AIFeatures() {
  const [activeTab, setActiveTab] = useState('signals');

  const features = [
    {
      id: 'signals',
      label: 'Signal-to-Execution',
      icon: Zap,
      color: 'text-blue-500',
      bg: 'bg-blue-500/10',
      description: 'Detect high-intent signals and trigger autonomous actions within 24 hours',
      roi: 'Ultimate "blue ocean" feature - hits leads while hot',
    },
    {
      id: 'governance',
      label: 'AI Governance',
      icon: Shield,
      color: 'text-green-500',
      bg: 'bg-green-500/10',
      description: 'EU AI Act compliant transparency - shows WHY AI made decisions',
      roi: 'Mandatory for enterprise sales in EU markets',
    },
    {
      id: 'knowledge',
      label: 'Deal Knowledge Graph',
      icon: Brain,
      color: 'text-purple-500',
      bg: 'bg-purple-500/10',
      description: 'Unified cross-platform context - eliminates 6-week ramp time',
      roi: 'New hires get full context in 5 minutes vs 6 weeks',
    },
    {
      id: 'micro-apps',
      label: 'Industry Micro-Apps',
      icon: Layers,
      color: 'text-orange-500',
      bg: 'bg-orange-500/10',
      description: 'No-code custom workflows with 90%+ adoption rates',
      roi: 'Generate industry-specific apps in 2.5 minutes',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-cyan-500/5 p-6">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">2026 AI CRM Features</h1>
              <p className="text-muted-foreground">Next-generation autonomous sales operations</p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <button
                  key={feature.id}
                  onClick={() => setActiveTab(feature.id)}
                  className={`p-3 rounded-xl border transition-all text-left ${
                    activeTab === feature.id
                      ? `${feature.bg} border-current/30 shadow-lg`
                      : 'bg-muted/20 border-border hover:bg-muted/40'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${feature.color} mb-2`} />
                  <p className="text-sm font-semibold mb-0.5">{feature.label}</p>
                  <p className="text-[10px] text-muted-foreground line-clamp-2">{feature.description}</p>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* ROI Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Card className="bg-blue-500/5 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Target className="w-5 h-5 text-blue-500 mt-0.5" />
              <div>
                <p className="text-sm font-semibold mb-1">Market Differentiation</p>
                <p className="text-xs text-muted-foreground">
                  Only CRM with autonomous signal detection + EU AI Act compliance + cross-platform knowledge graph
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-green-500/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <TrendingUp className="w-5 h-5 text-green-500 mt-0.5" />
              <div>
                <p className="text-sm font-semibold mb-1">Revenue Impact</p>
                <p className="text-xs text-muted-foreground">
                  24-hour response time → 3x conversion rates | 5-minute ramp → 90% faster onboarding
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-purple-500/5 border-purple-500/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <Clock className="w-5 h-5 text-purple-500 mt-0.5" />
              <div>
                <p className="text-sm font-semibold mb-1">Time Savings</p>
                <p className="text-xs text-muted-foreground">
                  6 weeks → 5 minutes ramp time | 2.5 minutes to generate custom workflows
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-emerald-500/5 border-emerald-500/20">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-500 mt-0.5" />
              <div>
                <p className="text-sm font-semibold mb-1">Compliance Ready</p>
                <p className="text-xs text-muted-foreground">
                  EU AI Act, GDPR Article 30, TCPA, DNC registry - all automated and auditable
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Feature Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="signals" className="text-xs">Signal-to-Execution</TabsTrigger>
          <TabsTrigger value="governance" className="text-xs">AI Governance</TabsTrigger>
          <TabsTrigger value="knowledge" className="text-xs">Knowledge Graph</TabsTrigger>
          <TabsTrigger value="micro-apps" className="text-xs">Micro-Apps</TabsTrigger>
        </TabsList>
        <TabsContent value="signals" className="mt-4">
          <SignalExecutionPanel />
        </TabsContent>
        <TabsContent value="governance" className="mt-4">
          <GovernanceTrustPanel />
        </TabsContent>
        <TabsContent value="knowledge" className="mt-4">
          <DealKnowledgeGraph />
        </TabsContent>
        <TabsContent value="micro-apps" className="mt-4">
          <IndustryMicroAppsPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}