import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Check, Shield, FileText } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { PLANS } from '@/lib/pricing';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import CardVaultForm from '@/components/checkout/CardVaultForm';

export default function TrialSignup() {
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [selectedPlan, setSelectedPlan] = useState('growth');
  const [selectedOption, setSelectedOption] = useState('trial'); // 'trial' or 'yearly'
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [vaultData, setVaultData] = useState(null);

  const plan = PLANS.find(p => p.key === selectedPlan) || PLANS[1];
  const isProfessionalOrAbove = plan.key === 'growth' || plan.key === 'business' || plan.key === 'enterprise';
  const yearlyPrice = Math.round(plan.price * 12 * 0.85 * 100) / 100; // 15% yearly discount
  const inviteDiscount = selectedOption === 'trial' && inviteCode ? Math.round(plan.price * 0.25 * 100) / 100 : 0;
  const newAccountDiscount = isProfessionalOrAbove ? 10 : 0;
  const totalFirstMonthDiscount = inviteDiscount + newAccountDiscount;
  const firstMonthPrice = selectedOption === 'trial' ? Math.max(0, plan.price - totalFirstMonthDiscount) : 0;

  const handleSignup = async (e) => {
    e.preventDefault();
    if (!email || !fullName) {
      toast.error('Please fill in all fields');
      return;
    }
    if (!agreedToTerms) {
      toast.error('You must agree to the Terms and Conditions to continue');
      return;
    }

    setLoading(true);
    try {
      const response = await base44.functions.invoke('convergeCheckout', {
        email,
        fullName,
        planKey: selectedPlan,
        isYearly: selectedOption === 'yearly',
        ref: inviteCode || null,
      });

      const data = response.data || {};
      if (data.vaultFallback) {
        // Converge not live — show the in-page card vault form so the subscriber
        // can save their card now. Redirecting to /pricing would re-trigger the
        // duplicate-subscription guard and skip card entry entirely.
        setVaultData({
          email: data.email || email,
          fullName: data.fullName || fullName,
          planLabel: data.planLabel || (plan?.label || selectedPlan),
          amount: data.amount ?? (selectedOption === 'yearly' ? yearlyPrice : plan?.price),
          isYearly: data.isYearly ?? selectedOption === 'yearly',
          vaultToken: data.vaultToken || '',
        });
        setLoading(false);
      } else if (data.processor === 'converge' && data.paymentHtml) {
        document.open();
        document.write(data.paymentHtml);
        document.close();
      } else if (data.redirect) {
        window.location.href = data.redirect;
      } else {
        toast.error(data.error || 'Failed to create checkout session');
        setLoading(false);
      }
    } catch (error) {
      toast.error(error.message || 'An error occurred');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      {/* Nav */}
      <nav className="border-b border-border px-4 h-14 flex items-center justify-between bg-background/90 backdrop-blur sticky top-0 z-50">
        <a href="/" className="flex items-center gap-2 text-sm font-semibold hover:text-primary transition-colors">
          <img src="https://media.base44.com/images/public/69ef71210cace64a00bec165/db6b11da8_ChatGPTImageMay8202612_44_40PM.png" alt="AXIS" className="h-7" />
          <span>Axis Business Suite</span>
        </a>
        <a href="/" className="text-sm text-muted-foreground hover:text-foreground transition-colors">← Back to Home</a>
      </nav>
      <div className="max-w-6xl mx-auto p-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-2xl md:text-4xl font-bold tracking-tight mb-2">Get Started with Axis Business Suite</h1>
          <p className="text-sm md:text-lg text-muted-foreground">7-day free trial — card saved securely, not charged for 7 days. Save 15% with yearly billing.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6 md:gap-8">
          {/* Plan Selection */}
          <div className="lg:col-span-2 space-y-4">
            <h2 className="text-xl font-bold">Choose Your Plan</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4">
              {PLANS.map(p => (
                <button
                  key={p.key}
                  onClick={() => setSelectedPlan(p.key)}
                  className={`text-left rounded-xl border-2 p-4 transition-all relative ${
                    selectedPlan === p.key
                      ? `${p.borderColor} ring-2 ring-primary/20 ${p.bg}`
                      : `border-border hover:border-primary/40`
                  }`}
                >
                  {p.highlight && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                      MOST POPULAR
                    </div>
                  )}
                  <Badge className={p.badgeColor}>{p.badge}</Badge>
                  <p className="font-bold text-lg mt-2">{p.label}</p>
                  <p className="text-2xl font-black text-primary mt-1">${p.price}<span className="text-sm font-normal text-muted-foreground">/mo</span></p>
                  <div className="space-y-1.5 mt-4 text-sm">
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" />{p.max_calls === 999999 ? 'Unlimited' : p.max_calls.toLocaleString()} calls/mo</div>
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" />{p.max_leads === 999999 ? 'Unlimited' : p.max_leads.toLocaleString()} leads</div>
                    <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" />Up to {p.max_users} user{p.max_users !== 1 ? 's' : ''}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Signup Form */}
          <div>
            <Card className="sticky top-6">
              <CardHeader>
                <CardTitle>Get Started Now</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleSignup} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Full Name</label>
                    <Input
                      placeholder="Your full name"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      disabled={loading}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Email Address</label>
                    <Input
                      type="email"
                      placeholder="you@company.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={loading}
                    />
                  </div>

                  {/* Option Selector */}
                  <div className="space-y-3 border-t pt-4">
                    <label className="block text-sm font-semibold">Choose Your Plan:</label>

                    <button
                      type="button"
                      onClick={() => setSelectedOption('trial')}
                      className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                        selectedOption === 'trial'
                          ? 'border-emerald-500 bg-emerald-500/5'
                          : 'border-border hover:border-emerald-500/50'
                      }`}
                    >
                      <p className="font-semibold text-sm">7-Day Trial + First Month Offer</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {isProfessionalOrAbove 
                          ? `✓ 7 days free + $100 off first month${inviteCode ? ' + 25% invite bonus' : ''}`
                          : 'Have an invite code? Get 25% off first month'}
                      </p>
                      <p className="text-lg font-bold text-emerald-600 mt-2">
                        {totalFirstMonthDiscount > 0 ? (
                          <span>
                            <span className="line-through text-muted-foreground text-sm">${plan?.price}</span> ${firstMonthPrice.toFixed(2)}/mo
                          </span>
                        ) : `$${plan?.price}/mo`}
                      </p>
                    </button>

                    {selectedOption === 'trial' && (
                      <div>
                        <label className="block text-xs font-medium mb-1 text-muted-foreground">Have an invite code? (optional)</label>
                        <Input
                          placeholder="Enter invite code for 25% off"
                          value={inviteCode}
                          onChange={(e) => setInviteCode(e.target.value)}
                          disabled={loading}
                        />
                      </div>
                    )}

                    <button
                      type="button"
                      onClick={() => setSelectedOption('yearly')}
                      className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                        selectedOption === 'yearly'
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <p className="font-semibold text-sm">Pay Yearly Upfront</p>
                      <p className="text-xs text-muted-foreground mt-1">Best value — pay once for 12 months</p>
                      <p className="text-lg font-bold text-primary mt-2">${yearlyPrice.toFixed(2)}/year</p>
                    </button>
                  </div>

                  {/* Payment Info Note */}
                  <div className="rounded-lg bg-blue-500/10 border border-blue-500/30 p-3 flex items-start gap-2">
                    <Shield className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <p className="text-xs text-blue-700">
                      {selectedOption === 'trial'
                        ? 'Card required. You won\'t be charged for 7 days.'
                        : 'Payment is due today for the full year.'}
                    </p>
                  </div>

                  <Button type="submit" disabled={loading} size="lg" className="w-full">
                    {loading ? 'Processing...' : selectedOption === 'trial' ? 'Start Free Trial' : 'Pay Yearly'}
                  </Button>

                  {/* Terms and Conditions Checkbox */}
                  <div className="flex items-start gap-2 p-3 rounded-lg border border-border bg-muted/30">
                    <input
                      type="checkbox"
                      id="terms"
                      checked={agreedToTerms}
                      onChange={(e) => setAgreedToTerms(e.target.checked)}
                      className="mt-0.5 w-4 h-4 rounded border-gray-300 text-primary focus:ring-primary"
                      disabled={loading}
                    />
                    <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed">
                      I agree to the{' '}
                      <a href="/terms" target="_blank" rel="noopener noreferrer" className="underline text-primary hover:text-primary/80">
                        Terms of Service
                      </a>{' '}
                      and{' '}
                      <a href="/privacy" target="_blank" rel="noopener noreferrer" className="underline text-primary hover:text-primary/80">
                        Privacy Policy
                      </a>
                      . I understand that I will be charged after the trial period unless I cancel.
                    </label>
                  </div>

                  <div className="text-xs text-center text-muted-foreground space-y-1">
                    {selectedOption === 'trial' ? (
                      <>
                        <p>✓ 7 days free, then ${plan?.price}/mo</p>
                        <p>✓ Cancel anytime</p>
                      </>
                    ) : (
                      <>
                        <p>✓ Full year access</p>
                        <p>✓ Best value pricing</p>
                      </>
                    )}
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-muted-foreground space-y-2">
          <p>Questions? Contact us at <a href="mailto:support@axisbusiness.com" className="underline hover:text-foreground">support@axisbusiness.com</a></p>
          <div className="flex justify-center gap-4 text-xs">
            <a href="/terms" className="underline hover:text-foreground">Terms of Service</a>
            <a href="/privacy" className="underline hover:text-foreground">Privacy Policy</a>
          </div>
        </div>
      </div>

      {/* Card Vault Fallback Modal (Converge not yet configured) */}
      <Dialog open={!!vaultData} onOpenChange={(open) => { if (!open) setVaultData(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Save Your Card for Billing
            </DialogTitle>
            <DialogDescription>
              Our payment processor (Converge/Elavon) is being configured. Enter your card now — it will be encrypted
              and charged automatically once processing is live. You will not be charged today.
            </DialogDescription>
          </DialogHeader>
          {vaultData && (
            <CardVaultForm
              email={vaultData.email}
              fullName={vaultData.fullName}
              planLabel={vaultData.planLabel}
              amount={vaultData.amount}
              isYearly={vaultData.isYearly}
              vaultToken={vaultData.vaultToken}
              onSuccess={() => {
                setVaultData(null);
                toast.success('Card saved! Check your email to set your password and log in.', { duration: 6000 });
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}