import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Workflow, Package, FileText, Truck, CheckCircle2, 
  Loader2, Zap, AlertCircle, Clock, TrendingUp,
  DollarSign, Users, Bell, BarChart3, RefreshCcw, Play
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function WorkflowOrchestration() {
  const qc = useQueryClient();
  const [selectedWorkflow, setSelectedWorkflow] = useState(null);
  const [runningWorkflow, setRunningWorkflow] = useState(null);

  // Fetch data
  const { data: workflows = [] } = useQuery({ 
    queryKey: ['workflows'], 
    queryFn: () => base44.entities.Workflow.list('-created_date', 50) 
  });
  
  const { data: orders = [] } = useQuery({ 
    queryKey: ['orders'], 
    queryFn: () => base44.entities.Order ? base44.entities.Order.list('-created_date', 50) : [] 
  });
  
  const { data: productionTickets = [] } = useQuery({ 
    queryKey: ['production-tickets'], 
    queryFn: () => base44.entities.ProductionTicket ? base44.entities.ProductionTicket.list() : [] 
  });
  
  const { data: fulfillmentTasks = [] } = useQuery({ 
    queryKey: ['fulfillment-tasks'], 
    queryFn: () => base44.entities.FulfillmentTask ? base44.entities.FulfillmentTask.list() : [] 
  });

  const { data: closedOpportunities = [] } = useQuery({ 
    queryKey: ['closed-opportunities'], 
    queryFn: () => base44.entities.Opportunity ? base44.entities.Opportunity.filter({ stage: 'closed_won' }) : [] 
  });

  // Run workflow mutation
  const runWorkflow = useMutation({
    mutationFn: async (contract_id) => {
      setRunningWorkflow(contract_id);
      const res = await base44.functions.invoke('salesToOperationsWorkflow', { contract_id });
      setRunningWorkflow(null);
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['workflows', 'orders'] });
      toast.success(`Workflow completed! Order: ${data.order_id}, Invoice: ${data.invoice_id}`);
    },
    onError: (err) => {
      setRunningWorkflow(null);
      toast.error('Workflow failed: ' + err.message);
    }
  });

  // KPIs
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, o) => sum + (o.total || 0), 0);
  const activeWorkflows = workflows.filter(w => w.status === 'running').length;
  const completedWorkflows = workflows.filter(w => w.status === 'completed').length;
  const productionInProgress = productionTickets.filter(t => t.status === 'in_progress').length;
  const pendingFulfillment = fulfillmentTasks.filter(t => t.status === 'pending').length;

  const getWorkflowIcon = (type) => {
    switch(type) {
      case 'sales_to_operations': return Zap;
      case 'order_fulfillment': return Truck;
      case 'customer_onboarding': return Users;
      case 'renewal_retention': return RefreshCcw;
      default: return Workflow;
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30';
      case 'running': return 'bg-blue-500/10 text-blue-600 border-blue-500/30';
      case 'failed': return 'bg-red-500/10 text-red-600 border-red-500/30';
      case 'paused': return 'bg-amber-500/10 text-amber-600 border-amber-500/30';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Workflow className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Sales-to-Operations Workflow Engine</h1>
            <p className="text-muted-foreground">Automated order orchestration from close to delivery</p>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold">{totalOrders}</p>
              </div>
              <Package className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Workflows</p>
                <p className="text-2xl font-bold">{activeWorkflows}</p>
              </div>
              <Zap className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold">{completedWorkflows}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Production</p>
                <p className="text-2xl font-bold">{productionInProgress}</p>
              </div>
              <Package className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Pending Fulfillment</p>
                <p className="text-2xl font-bold">{pendingFulfillment}</p>
              </div>
              <Truck className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="workflows" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted p-1 w-full">
          <TabsTrigger value="workflows" className="flex items-center gap-2">
            <Workflow className="w-4 h-4" />
            <span>Active Workflows</span>
          </TabsTrigger>
          <TabsTrigger value="orders" className="flex items-center gap-2">
            <Package className="w-4 h-4" />
            <span>Orders</span>
          </TabsTrigger>
          <TabsTrigger value="production" className="flex items-center gap-2">
            <FileText className="w-4 h-4" />
            <span>Production</span>
          </TabsTrigger>
          <TabsTrigger value="fulfillment" className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            <span>Fulfillment</span>
          </TabsTrigger>
          <TabsTrigger value="trigger" className="flex items-center gap-2">
            <Play className="w-4 h-4" />
            <span>Trigger Workflow</span>
          </TabsTrigger>
        </TabsList>

        {/* Workflows Tab */}
        <TabsContent value="workflows" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Workflow className="w-5 h-5" />
                Workflow Execution History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {workflows.slice(0, 10).map(wf => {
                  const WorkflowIcon = getWorkflowIcon(wf.workflow_type);
                  return (
                    <div key={wf.id} className="p-4 rounded-lg border bg-card">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
                            <WorkflowIcon className="w-4 h-4 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{wf.name}</p>
                            <p className="text-xs text-muted-foreground">
                              Triggered by: {wf.trigger_entity} • {format(new Date(wf.created_date), 'MMM d, yyyy HH:mm')}
                            </p>
                          </div>
                        </div>
                        <Badge className={getStatusColor(wf.status)}>
                          {wf.status}
                        </Badge>
                      </div>
                      
                      {wf.progress_percent > 0 && (
                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span>Progress</span>
                            <span>{wf.progress_percent}%</span>
                          </div>
                          <Progress value={wf.progress_percent} className="h-2" />
                        </div>
                      )}

                      {wf.steps && (
                        <div className="mt-3 text-xs text-muted-foreground">
                          Step {wf.current_step || 0} of {wf.total_steps || 0}: {
                            JSON.parse(wf.steps)[wf.current_step - 1]?.name || 'N/A'
                          }
                        </div>
                      )}
                    </div>
                  );
                })}
                {workflows.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">No workflows executed yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Orders Tab */}
        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="w-5 h-5" />
                Order Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3">Order #</th>
                      <th className="text-left py-2 px-3">Customer</th>
                      <th className="text-left py-2 px-3">Amount</th>
                      <th className="text-left py-2 px-3">Status</th>
                      <th className="text-left py-2 px-3">Production</th>
                      <th className="text-left py-2 px-3">Fulfillment</th>
                      <th className="text-left py-2 px-3">Onboarding</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orders.slice(0, 10).map(order => (
                      <tr key={order.id} className="border-b last:border-0">
                        <td className="py-3 px-3 font-medium">{order.order_number}</td>
                        <td className="py-3 px-3">{order.account_name}</td>
                        <td className="py-3 px-3">${order.total?.toLocaleString() || '0'}</td>
                        <td className="py-3 px-3">
                          <Badge 
                            className={`text-xs ${
                              order.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' :
                              order.status === 'shipped' ? 'bg-blue-500/10 text-blue-600' :
                              order.status === 'in_production' ? 'bg-amber-500/10 text-amber-600' :
                              'bg-muted text-muted-foreground'
                            }`}
                          >
                            {order.status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="py-3 px-3">
                          <Badge variant="outline" className="text-xs">
                            {order.production_status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="py-3 px-3">
                          <Badge variant="outline" className="text-xs">
                            {order.fulfillment_status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="py-3 px-3">
                          <Badge 
                            className={`text-xs ${
                              order.onboarding_status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' :
                              order.onboarding_status === 'in_progress' ? 'bg-blue-500/10 text-blue-600' :
                              'bg-muted text-muted-foreground'
                            }`}
                          >
                            {order.onboarding_status.replace('_', ' ')}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                    {orders.length === 0 && (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-muted-foreground">
                          No orders yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Production Tab */}
        <TabsContent value="production" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Production Tickets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {productionTickets.slice(0, 10).map(ticket => (
                  <div key={ticket.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">{ticket.ticket_number}</p>
                        <p className="text-xs text-muted-foreground">{ticket.account_name}</p>
                      </div>
                      <Badge 
                        className={`text-xs ${
                          ticket.status === 'completed' ? 'bg-emerald-500/10 text-emerald-600' :
                          ticket.status === 'in_progress' ? 'bg-blue-500/10 text-blue-600' :
                          ticket.status === 'quality_check' ? 'bg-amber-500/10 text-amber-600' :
                          'bg-muted text-muted-foreground'
                        }`}
                      >
                        {ticket.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs text-muted-foreground">
                      <div>
                        <span className="font-medium">Product:</span> {ticket.product_name}
                      </div>
                      <div>
                        <span className="font-medium">Qty:</span> {ticket.quantity}
                      </div>
                      <div>
                        <span className="font-medium">Due:</span> {ticket.due_date ? format(new Date(ticket.due_date), 'MMM d') : 'N/A'}
                      </div>
                    </div>
                  </div>
                ))}
                {productionTickets.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">No production tickets</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fulfillment Tab */}
        <TabsContent value="fulfillment" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                Fulfillment Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {fulfillmentTasks.slice(0, 10).map(task => (
                  <div key={task.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium">{task.task_number}</p>
                        <p className="text-xs text-muted-foreground">{task.account_name}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge 
                          className={`text-xs ${
                            task.task_type === 'shipping' ? 'bg-blue-500/10 text-blue-600' :
                            task.task_type === 'delivery' ? 'bg-emerald-500/10 text-emerald-600' :
                            'bg-muted text-muted-foreground'
                          }`}
                        >
                          {task.task_type}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {task.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                      <div>
                        <span className="font-medium">Due:</span> {task.due_date ? format(new Date(task.due_date), 'MMM d') : 'N/A'}
                      </div>
                      {task.tracking_number && (
                        <div>
                          <span className="font-medium">Tracking:</span> {task.tracking_number}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {fulfillmentTasks.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">No fulfillment tasks</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Trigger Workflow Tab */}
        <TabsContent value="trigger" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="w-5 h-5" />
                Trigger Sales-to-Operations Workflow
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-muted/50 rounded-lg border">
                  <p className="font-medium mb-2">What happens when a deal closes:</p>
                  <ol className="space-y-1 text-sm text-muted-foreground list-decimal list-inside">
                    <li>Generate invoice automatically</li>
                    <li>Create order record</li>
                    <li>Generate production tickets</li>
                    <li>Create fulfillment tasks</li>
                    <li>Update accounting records</li>
                    <li>Update CRM (opportunity → closed won)</li>
                    <li>Trigger customer onboarding</li>
                    <li>Notify all departments (Sales, Production, Fulfillment, CS, Finance)</li>
                    <li>Update live dashboards</li>
                  </ol>
                </div>

                <div className="space-y-3">
                  <p className="font-medium">Select a closed opportunity to trigger workflow:</p>
                  {closedOpportunities.slice(0, 10).map(opp => (
                    <div key={opp.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                      <div className="flex-1">
                        <p className="font-medium">{opp.name}</p>
                        <p className="text-xs text-muted-foreground">{opp.account_name} • ${opp.amount?.toLocaleString() || '0'}</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => runWorkflow.mutate(opp.contract_id || opp.id)}
                        disabled={runningWorkflow === opp.contract_id || runningWorkflow === opp.id || !opp.contract_id}
                      >
                        {runningWorkflow === opp.contract_id || runningWorkflow === opp.id ? (
                          <>
                            <Loader2 className="w-4 h-4 animate-spin mr-2" />
                            Running...
                          </>
                        ) : (
                          <>
                            <Zap className="w-4 h-4 mr-2" />
                            Trigger Workflow
                          </>
                        )}
                      </Button>
                    </div>
                  ))}
                  {closedOpportunities.length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No closed opportunities found. Close a deal first to trigger the workflow.
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}