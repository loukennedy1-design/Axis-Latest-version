import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  Brain, TrendingUp, AlertTriangle, CheckCircle, Clock, 
  BarChart3, Activity, DollarSign, Users, Package, AlertCircle,
  Zap, Shield, FileText, Loader2, Play, Eye, Target,
  ArrowUpRight, ArrowDownRight, Minus, Search
} from 'lucide-react';
import { toast } from 'sonner';

export default function UniversalOperationalAI() {
  const qc = useQueryClient();
  const [selectedInsight, setSelectedInsight] = useState(null);
  const [selectedDepartment, setSelectedDepartment] = useState('all');
  const [forecastMonths, setForecastMonths] = useState(3);
  const [generatingInsights, setGeneratingInsights] = useState(false);

  // Fetch insights
  const { data: insights = [], refetch: refetchInsights } = useQuery({ 
    queryKey: ['operational-insights'], 
    queryFn: () => base44.entities.OperationalInsight ? base44.entities.OperationalInsight.list('-created_date', 50) : [],
    refetchInterval: 10000
  });

  const { data: automations = [] } = useQuery({ 
    queryKey: ['ai-automations'], 
    queryFn: () => base44.entities.AIAutomationLog ? base44.entities.AIAutomationLog.list('-executed_at', 50) : [] 
  });

  // Generate insights
  const generateInsights = useMutation({
    mutationFn: async (params) => {
      setGeneratingInsights(true);
      const res = await base44.functions.invoke('universalOperationalAI', {
        action: 'generate_insights',
        ...params
      });
      setGeneratingInsights(false);
      return res.data;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['operational-insights'] });
      toast.success('Insights generated successfully');
    },
    onError: (err) => {
      setGeneratingInsights(false);
      toast.error('Failed: ' + err.message);
    }
  });

  // Revenue forecast
  const forecastRevenue = useMutation({
    mutationFn: async (months) => {
      const res = await base44.functions.invoke('universalOperationalAI', {
        action: 'forecast_revenue',
        months
      });
      return res.data;
    }
  });

  // Detect bottlenecks
  const detectBottlenecks = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke('universalOperationalAI', {
        action: 'detect_bottlenecks'
      });
      return res.data;
    },
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['operational-insights'] });
      toast.success(`Detected ${data.bottlenecks_detected} bottlenecks`);
    }
  });

  // Get operational overview
  const getOverview = useMutation({
    mutationFn: async () => {
      const res = await base44.functions.invoke('universalOperationalAI', {
        action: 'get_operational_overview'
      });
      return res.data;
    }
  });

  const handleGenerateInsights = () => {
    generateInsights.mutate({
      department: selectedDepartment !== 'all' ? selectedDepartment : undefined,
      insight_types: ['bottleneck_detection', 'revenue_forecast', 'churn_prediction', 'optimization_recommendation'],
      days: 30
    });
  };

  const handleExecuteAction = async (insight) => {
    const action = JSON.parse(insight.recommended_actions || '[]')[0];
    if (action) {
      const res = await base44.functions.invoke('universalOperationalAI', {
        action: 'execute_automation',
        insight_id: insight.id,
        action_to_execute: action
      });
      
      if (res.data.success) {
        toast.success('Automation executed successfully');
        qc.invalidateQueries({ queryKey: ['operational-insights'] });
      } else if (res.data.blocked) {
        toast.warning(`Blocked: ${res.data.reason}`);
      } else {
        toast.error('Execution failed');
      }
    }
  };

  const getSeverityColor = (severity) => {
    switch(severity) {
      case 'critical': return 'bg-red-500/10 text-red-600 border-red-500/30';
      case 'high': return 'bg-orange-500/10 text-orange-600 border-orange-500/30';
      case 'medium': return 'bg-amber-500/10 text-amber-600 border-amber-500/30';
      case 'low': return 'bg-blue-500/10 text-blue-600 border-blue-500/30';
      default: return 'bg-muted';
    }
  };

  const getInsightIcon = (type) => {
    switch(type) {
      case 'bottleneck_detection': return <Activity className="w-4 h-4" />;
      case 'revenue_forecast': return <DollarSign className="w-4 h-4" />;
      case 'staffing_forecast': return <Users className="w-4 h-4" />;
      case 'production_forecast': return <Package className="w-4 h-4" />;
      case 'churn_prediction': return <AlertTriangle className="w-4 h-4" />;
      case 'profitability_monitoring': return <TrendingUp className="w-4 h-4" />;
      case 'operational_risk': return <Shield className="w-4 h-4" />;
      case 'optimization_recommendation': return <Zap className="w-4 h-4" />;
      case 'workflow_monitoring': return <Clock className="w-4 h-4" />;
      case 'delay_prediction': return <AlertCircle className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  // Calculate metrics
  const criticalInsights = insights.filter(i => i.severity === 'critical').length;
  const highInsights = insights.filter(i => i.severity === 'high').length;
  const automatedActions = automations.filter(a => a.execution_status === 'executed').length;
  const blockedActions = automations.filter(a => a.execution_status === 'blocked').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Brain className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Universal Operational AI</h1>
            <p className="text-muted-foreground">Predictive intelligence & safe automation across all departments</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => detectBottlenecks.mutate()}>
            <Activity className="w-4 h-4 mr-2" />
            Detect Bottlenecks
          </Button>
          <Button 
            size="sm" 
            onClick={handleGenerateInsights}
            disabled={generatingInsights}
          >
            {generatingInsights ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Zap className="w-4 h-4 mr-2" />}
            Generate Insights
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Critical Insights</p>
                <p className="text-2xl font-bold text-red-600">{criticalInsights}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">High Priority</p>
                <p className="text-2xl font-bold text-orange-600">{highInsights}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Insights</p>
                <p className="text-2xl font-bold">{insights.length}</p>
              </div>
              <Brain className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Automations Executed</p>
                <p className="text-2xl font-bold text-emerald-600">{automatedActions}</p>
              </div>
              <Zap className="w-8 h-8 text-emerald-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Blocked (Governance)</p>
                <p className="text-2xl font-bold text-amber-600">{blockedActions}</p>
              </div>
              <Shield className="w-8 h-8 text-amber-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Confidence</p>
                <p className="text-2xl font-bold text-primary">
                  {insights.length > 0 ? Math.round(insights.reduce((sum, i) => sum + (i.confidence_score || 0), 0) / insights.length) : 0}%
                </p>
              </div>
              <Target className="w-8 h-8 text-primary opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="insights" className="space-y-4">
        <TabsList className="flex flex-wrap h-auto gap-1 bg-muted p-1 w-full">
          <TabsTrigger value="insights" className="flex items-center gap-2">
            <Brain className="w-4 h-4" />
            <span>AI Insights</span>
          </TabsTrigger>
          <TabsTrigger value="revenue" className="flex items-center gap-2">
            <DollarSign className="w-4 h-4" />
            <span>Revenue Forecast</span>
          </TabsTrigger>
          <TabsTrigger value="bottlenecks" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            <span>Bottlenecks</span>
          </TabsTrigger>
          <TabsTrigger value="automations" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            <span>Automations</span>
          </TabsTrigger>
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            <span>Overview</span>
          </TabsTrigger>
        </TabsList>

        {/* AI Insights Tab */}
        <TabsContent value="insights" className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <select
              className="p-2 rounded-md border bg-background text-sm"
              value={selectedDepartment}
              onChange={(e) => setSelectedDepartment(e.target.value)}
            >
              <option value="all">All Departments</option>
              <option value="crm">CRM</option>
              <option value="accounting">Accounting</option>
              <option value="production">Production</option>
              <option value="fulfillment">Fulfillment</option>
              <option value="operations">Operations</option>
            </select>
          </div>

          <div className="space-y-3">
            {insights.slice(0, 20).map(insight => (
              <Card 
                key={insight.id}
                className={`cursor-pointer transition-all ${
                  selectedInsight?.id === insight.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedInsight(insight)}
              >
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                        {getInsightIcon(insight.insight_type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-semibold">{insight.title}</p>
                          <Badge className={getSeverityColor(insight.severity)}>
                            {insight.severity}
                          </Badge>
                          {insight.automated_action_taken && (
                            <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Automated
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {insight.insight_type.replace(/_/g, ' ')} • {insight.department} • Confidence: {insight.confidence_score}%
                        </p>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(insight.created_date).toLocaleDateString()}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-3">{insight.description}</p>

                  {insight.recommended_actions && (
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">Actions:</span>
                      <div className="flex gap-1 flex-wrap">
                        {JSON.parse(insight.recommended_actions || '[]').slice(0, 3).map((action, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {action.substring(0, 50)}{action.length > 50 ? '...' : ''}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {selectedInsight?.id === insight.id && insight.recommended_actions?.length > 0 && !insight.automated_action_taken && (
                    <div className="mt-3 flex gap-2">
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleExecuteAction(insight);
                        }}
                        disabled={insight.requires_approval && insight.approval_status !== 'approved'}
                      >
                        <Play className="w-3 h-3 mr-1" />
                        Execute First Action
                      </Button>
                      {insight.requires_approval && (
                        <Badge variant="outline" className="text-xs">
                          Requires Approval
                        </Badge>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
            {insights.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">
                No insights yet. Click "Generate Insights" to analyze operations.
              </p>
            )}
          </div>
        </TabsContent>

        {/* Revenue Forecast Tab */}
        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Revenue Forecasting
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <label className="text-sm font-medium">Forecast Period:</label>
                  <select
                    className="p-2 rounded-md border bg-background text-sm"
                    value={forecastMonths}
                    onChange={(e) => setForecastMonths(parseInt(e.target.value))}
                  >
                    <option value={1}>1 Month</option>
                    <option value={3}>3 Months</option>
                    <option value={6}>6 Months</option>
                    <option value={12}>12 Months</option>
                  </select>
                  <Button
                    size="sm"
                    onClick={() => forecastRevenue.mutate(forecastMonths)}
                    disabled={forecastRevenue.isPending}
                  >
                    {forecastRevenue.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <TrendingUp className="w-4 h-4 mr-2" />}
                    Generate Forecast
                  </Button>
                </div>

                {forecastRevenue.data && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                        <p className="text-sm text-emerald-600 font-semibold">Conservative</p>
                        <p className="text-2xl font-bold text-emerald-600">
                          ${forecastRevenue.data.forecast.total_conservative?.toLocaleString()}
                        </p>
                      </div>
                      <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20">
                        <p className="text-sm text-blue-600 font-semibold">Likely</p>
                        <p className="text-2xl font-bold text-blue-600">
                          ${forecastRevenue.data.forecast.total_likely?.toLocaleString()}
                        </p>
                      </div>
                      <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20">
                        <p className="text-sm text-purple-600 font-semibold">Optimistic</p>
                        <p className="text-2xl font-bold text-purple-600">
                          ${forecastRevenue.data.forecast.total_optimistic?.toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="p-4 rounded-lg bg-muted">
                      <p className="text-sm font-semibold mb-2">Key Assumptions:</p>
                      <ul className="text-sm list-disc list-inside space-y-1">
                        {forecastRevenue.data.forecast.key_assumptions?.map((assumption, i) => (
                          <li key={i}>{assumption}</li>
                        ))}
                      </ul>
                    </div>

                    {forecastRevenue.data.forecast.risks?.length > 0 && (
                      <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                        <p className="text-sm font-semibold text-amber-800 mb-2">Risks:</p>
                        <ul className="text-sm list-disc list-inside space-y-1 text-amber-700">
                          {forecastRevenue.data.forecast.risks.map((risk, i) => (
                            <li key={i}>{risk}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bottlenecks Tab */}
        <TabsContent value="bottlenecks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Bottleneck Detection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => detectBottlenecks.mutate()}
                disabled={detectBottlenecks.isPending}
                className="mb-4"
              >
                {detectBottlenecks.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Activity className="w-4 h-4 mr-2" />}
                Run Bottleneck Analysis
              </Button>

              {detectBottlenecks.data && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/20">
                      <p className="text-sm text-red-600 font-semibold">Bottlenecks Detected</p>
                      <p className="text-2xl font-bold text-red-600">{detectBottlenecks.data.bottlenecks.bottlenecks?.length || 0}</p>
                    </div>
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <p className="text-sm text-emerald-600 font-semibold">Quick Wins</p>
                      <p className="text-2xl font-bold text-emerald-600">{detectBottlenecks.data.quick_wins?.length || 0}</p>
                    </div>
                  </div>

                  {detectBottlenecks.data.bottlenecks?.bottlenecks?.map((bottleneck, i) => (
                    <div key={i} className="p-4 rounded-lg border bg-card">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getSeverityColor(bottleneck.severity)}>
                          {bottleneck.severity}
                        </Badge>
                        <p className="font-semibold">{bottleneck.area}</p>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{bottleneck.root_cause}</p>
                      <p className="text-sm font-medium">Impact: {bottleneck.impact?.description}</p>
                    </div>
                  ))}

                  {detectBottlenecks.data.quick_wins?.length > 0 && (
                    <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                      <p className="text-sm font-semibold text-emerald-800 mb-2">Quick Wins (Immediate Impact):</p>
                      <ul className="text-sm list-disc list-inside space-y-1 text-emerald-700">
                        {detectBottlenecks.data.quick_wins.map((win, i) => (
                          <li key={i}>{win}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Automations Tab */}
        <TabsContent value="automations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                AI Automation Log
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {automations.slice(0, 20).map(auto => (
                  <div key={auto.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Badge variant={auto.execution_status === 'executed' ? 'default' : auto.execution_status === 'blocked' ? 'secondary' : 'destructive'}>
                          {auto.execution_status}
                        </Badge>
                        <p className="font-medium">{auto.action_taken}</p>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(auto.executed_at).toLocaleString()}
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs">
                      <div className="flex items-center gap-1">
                        <Shield className="w-3 h-3" />
                        Risk: {auto.risk_level}
                      </div>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" />
                        Compliance: {auto.compliance_verified ? 'Verified' : 'Not Checked'}
                      </div>
                      {auto.approval_required && (
                        <div className="flex items-center gap-1">
                          <AlertCircle className="w-3 h-3" />
                          Approval: {auto.approval_obtained ? 'Obtained' : 'Required'}
                        </div>
                      )}
                    </div>

                    {auto.error_message && (
                      <p className="text-xs text-red-600 mt-2">{auto.error_message}</p>
                    )}
                  </div>
                ))}
                {automations.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-8">
                    No automations executed yet.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Operational Intelligence Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Insights by Type */}
                <div>
                  <h3 className="text-sm font-semibold mb-3">Insights by Type</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {Object.entries(insights.reduce((acc, i) => {
                      acc[i.insight_type] = (acc[i.insight_type] || 0) + 1;
                      return acc;
                    }, {})).map(([type, count]) => (
                      <div key={type} className="p-3 rounded-lg border bg-card">
                        <p className="text-xs font-medium truncate">{type.replace(/_/g, ' ')}</p>
                        <p className="text-lg font-bold">{count}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Governance Stats */}
                <div className="p-4 rounded-lg bg-muted">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Governance & Compliance
                  </h3>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-emerald-600">{automations.filter(a => a.compliance_verified).length}</p>
                      <p className="text-xs text-muted-foreground">Compliance Verified</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-amber-600">{blockedActions}</p>
                      <p className="text-xs text-muted-foreground">Blocked by Governance</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-primary">{automations.length}</p>
                      <p className="text-xs text-muted-foreground">Total Automations</p>
                    </div>
                  </div>
                </div>

                {/* Department Coverage */}
                <div>
                  <h3 className="text-sm font-semibold mb-3">Coverage by Department</h3>
                  <div className="space-y-2">
                    {[...new Set(insights.map(i => i.department))].map(dept => {
                      const deptInsights = insights.filter(i => i.department === dept);
                      const critical = deptInsights.filter(i => i.severity === 'critical').length;
                      
                      return (
                        <div key={dept} className="flex items-center gap-3">
                          <div className="w-24 text-xs capitalize">{dept}</div>
                          <Progress 
                            value={(deptInsights.length / insights.length) * 100} 
                            className="flex-1 h-2"
                          />
                          <div className="w-12 text-xs text-right">{deptInsights.length}</div>
                          {critical > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              {critical} critical
                            </Badge>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}