import React, { useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Users, Video, Copy, PhoneOff, Link2, Settings } from 'lucide-react';
import { toast } from 'sonner';
import WebRtcMeet from '@/components/meet/WebRtcMeet';
import HostControlPanel from '@/components/meet/HostControlPanel';

export default function MeetRoom() {
  const { meetingId } = useParams();
  const navigate = useNavigate();
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [transcriptParts, setTranscriptParts] = useState([]);
  const [ending, setEnding] = useState(false);
  const [controlsOpen, setControlsOpen] = useState(false);
  const transcriptRef = useRef([]);

  const { data: meeting, isLoading } = useQuery({
    queryKey: ['internal-meeting', meetingId],
    queryFn: () => base44.entities.InternalMeeting.filter({ meeting_id: meetingId }),
    enabled: !!meetingId,
    select: (records) => records?.[0] || null,
    refetchInterval: 5000,
  });

  const handleEndMeeting = async () => {
    if (!meeting) return;
    setEnding(true);
    const transcript = transcriptRef.current.join('\n');
    try {
      const res = await base44.functions.invoke('meetingIntelligence', {
        action: 'end_meeting',
        meeting_id: meetingId,
        transcript,
      });
      if (res.data?.error) throw new Error(res.data.error);
      toast.success('Meeting ended — AI summary generated');
      qc.invalidateQueries({ queryKey: ['internal-meetings'] });
      navigate('/axis-meet');
    } catch (e) {
      toast.error(e.message || 'Failed to end meeting');
    } finally {
      setEnding(false);
    }
  };

  const copyGuestLink = () => {
    if (meeting?.guest_join_url) {
      navigator.clipboard.writeText(meeting.guest_join_url);
      toast.success('Guest link copied');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!meeting) {
    return (
      <div className="flex items-center justify-center h-screen bg-background flex-col gap-3">
        <Video className="w-10 h-10 text-muted-foreground" />
        <p className="font-medium">Meeting not found</p>
        <Button variant="outline" onClick={() => navigate('/axis-meet')}>Back to AXIS Meet</Button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] gap-3">
      {/* Meeting header bar */}
      <div className="flex items-center justify-between gap-3 flex-wrap px-1">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <Video className="w-5 h-5 text-primary" />
          </div>
          <div className="min-w-0">
            <p className="font-medium truncate">{meeting.title}</p>
            <p className="text-xs text-muted-foreground capitalize">{meeting.department} · Room: {meeting.room_name}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5 h-8" onClick={() => setControlsOpen(true)}>
            <Settings className="w-3.5 h-3.5" />Controls
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-8" onClick={copyGuestLink}>
            <Link2 className="w-3.5 h-3.5" />Copy Guest Link
          </Button>
          <Button variant="destructive" size="sm" className="gap-1.5 h-8" onClick={handleEndMeeting} disabled={ending}>
            {ending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <PhoneOff className="w-3.5 h-3.5" />}
            End Meeting
          </Button>
        </div>
      </div>

      {/* Jitsi video container */}
      <div className="flex-1 min-h-0 rounded-2xl overflow-hidden border border-border bg-black">
        <WebRtcMeet
          roomName={meeting.room_name}
          meetingId={meetingId}
          displayName={user?.full_name || user?.email || 'AXIS Host'}
          isHost={true}
          onMeetingEnded={handleEndMeeting}
        />
      </div>

      {/* Info note about transcript */}
      <div className="text-[11px] text-muted-foreground px-1 flex items-center gap-1.5">
        <Users className="w-3 h-3" />
        Share the guest link with external participants. They'll enter their name/email and wait in the lobby until you admit them.
      </div>

      <HostControlPanel
        open={controlsOpen}
        onOpenChange={setControlsOpen}
        meetingId={meetingId}
        roomName={meeting.room_name}
        onEndMeeting={handleEndMeeting}
      />
    </div>
  );
}