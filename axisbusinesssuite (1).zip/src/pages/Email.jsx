import React, { useState, useMemo, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Pencil, Search, Inbox, Send, RefreshCw, Trash2, Mail, Settings as SettingsIcon, Star, FileText, ExternalLink } from 'lucide-react';
import ComposeModal from '@/components/email/ComposeModal';
import EmailList from '@/components/email/EmailList';
import ThreadView from '@/components/email/ThreadView';
import InlineReply from '@/components/email/InlineReply';
import EmailAccountsSummary from '@/components/email/EmailAccountsSummary';
import TemplateManager from '@/components/email/TemplateManager';
import { useEmailAccounts } from '@/hooks/useEmailAccounts';
import { useSystemEmail } from '@/hooks/useSystemEmail';
import { toast } from 'sonner';
import PullToRefresh from '@/components/shared/PullToRefresh';

const FOLDERS = [
  { id: 'inbox', label: 'Inbox', icon: Inbox },
  { id: 'sent', label: 'Sent', icon: Send },
  { id: 'all', label: 'All Mail', icon: Mail },
];

export default function Email() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [folder, setFolder] = useState('inbox');
  const [search, setSearch] = useState('');
  const [selectedThread, setSelectedThread] = useState(null);
  const [composeOpen, setComposeOpen] = useState(false);
  const [replyPrefill, setReplyPrefill] = useState({});
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [templatesOpen, setTemplatesOpen] = useState(false);
  const { accounts, defaultAccount } = useEmailAccounts();
  const { systemEmail, systemEmailConfigured } = useSystemEmail();

  // Point "Open Webmail" at the correct provider inbox based on the connected
  // account, instead of a hardcoded domain URL that doesn't resolve.
  const webmailUrl = useMemo(() => {
    const p = defaultAccount?.provider;
    if (p === 'gmail_oauth') return 'https://mail.google.com/mail/u/0/#inbox';
    if (p === 'outlook_oauth') return 'https://outlook.office.com/mail/';
    return 'https://axisbusinesssuite.com/webmail';
  }, [defaultAccount?.provider]);

  const handleOpenWebmail = () => {
    const w = window.open(webmailUrl, '_blank', 'noopener,noreferrer');
    if (!w) toast('Pop-up blocked — open this URL: ' + webmailUrl, { duration: 8000 });
  };

  // Handle OAuth callback status (?oauth=success or ?oauth=error)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const oauthStatus = params.get('oauth');
    if (oauthStatus === 'success') {
      toast.success('Gmail connected successfully!', { duration: 5000 });
      window.history.replaceState({}, '', '/email');
    } else if (oauthStatus === 'error') {
      toast.error('Gmail connection failed: ' + (params.get('message') || 'Unknown error'), {
        duration: 8000,
        action: {
          label: 'Try Again',
          onClick: () => base44.functions.invoke('gmailOAuthAuth', { redirect: '/email' })
            .then((res) => { if (res.data?.authorization_url) window.location.href = res.data.authorization_url; })
            .catch(() => toast.error('Failed to start OAuth')),
        },
      });
      window.history.replaceState({}, '', '/email');
    }
  }, []);

  const [syncing, setSyncing] = useState(false);

  // Pull new mail from connected providers (Gmail/Outlook OAuth) into the local
  // inbox. Called on mount and from the Refresh button so users actually receive
  // new emails on demand — not just the 15s cache poll.
  const syncInboxes = async () => {
    if (accounts.length === 0 || syncing) return 0;
    setSyncing(true);
    let newCount = 0;
    try {
      if (accounts.some(a => a.provider === 'gmail_oauth')) {
        const res = await base44.functions.invoke('gmailSync', { max_results: 30 }).catch(() => null);
        newCount += res?.data?.synced || 0;
      }
      if (accounts.some(a => a.provider === 'outlook_oauth')) {
        const res = await base44.functions.invoke('outlookSync', { max_results: 30 }).catch(() => null);
        newCount += res?.data?.synced || 0;
      }
      if (newCount > 0) qc.invalidateQueries({ queryKey: ['emails'] });
      return newCount;
    } finally {
      setSyncing(false);
    }
  };

  // Auto-sync once on load when accounts are present.
  useEffect(() => {
    if (accounts.length > 0) syncInboxes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [accounts.length]);

  const handleRefresh = async () => {
    const n = await syncInboxes();
    await refetchEmails();
    if (n && n > 0) toast.success(`${n} new message${n === 1 ? '' : 's'} synced`);
    else toast.success('Inbox up to date');
  };

  const { data: emails = [], isLoading, refetch: refetchEmails } = useQuery({
    queryKey: ['emails'],
    queryFn: () => base44.entities.EmailMessage.list('-created_date', 500),
    refetchInterval: 15000,
    refetchIntervalInBackground: false,
  });

  // Group into threads
  const threads = useMemo(() => {
    // Pre-compute thread IDs that contain at least one received message
    const threadsWithReceived = new Set(
      emails.filter(e => e.direction === 'received').map(e => e.thread_id || e.id)
    );

    let filtered = emails;

    if (folder === 'inbox') {
      filtered = emails.filter(e => {
        const tid = e.thread_id || e.id;
        return e.direction === 'received' || threadsWithReceived.has(tid);
      });
    } else if (folder === 'sent') {
      filtered = emails.filter(e => e.direction === 'sent');
    }

    if (search) {
      const s = search.toLowerCase();
      filtered = filtered.filter(e =>
        e.subject?.toLowerCase().includes(s) ||
        e.to_address?.toLowerCase().includes(s) ||
        e.from_address?.toLowerCase().includes(s) ||
        e.body?.toLowerCase().includes(s)
      );
    }

    // Group by thread_id
    const map = new Map();
    filtered.forEach(msg => {
      const tid = msg.thread_id || msg.id;
      if (!map.has(tid)) map.set(tid, { thread_id: tid, messages: [] });
      map.get(tid).messages.push(msg);
    });

    // Sort threads by latest message
    return Array.from(map.values()).sort((a, b) => {
      const aLatest = Math.max(...a.messages.map(m => new Date(m.created_date || 0)));
      const bLatest = Math.max(...b.messages.map(m => new Date(m.created_date || 0)));
      return bLatest - aLatest;
    });
  }, [emails, folder, search]);

  const unreadCount = useMemo(() =>
    emails.filter(e => e.direction === 'received' && e.status === 'unread').length,
    [emails]
  );

  // Keep selectedThread in sync with latest emails data
  const selectedThreadLive = useMemo(() => {
    if (!selectedThread) return null;
    return threads.find(t => t.thread_id === selectedThread.thread_id) || selectedThread;
  }, [threads, selectedThread]);

  const handleSelectThread = async (thread) => {
    setSelectedThread(thread);
    // Mark unread messages as read
    const unread = thread.messages.filter(m => m.status === 'unread');
    await Promise.all(unread.map(m => base44.entities.EmailMessage.update(m.id, { status: 'read' })));
    if (unread.length > 0) qc.invalidateQueries({ queryKey: ['emails'] });
  };

  const handleReply = () => {
    if (!selectedThreadLive) return;
    const msgs = selectedThreadLive.messages;
    const latest = msgs[msgs.length - 1];
    const replyTo = latest.direction === 'sent' ? latest.to_address : latest.from_address;
    setReplyPrefill({
      to: replyTo,
      subject: latest.subject?.startsWith('Re:') ? latest.subject : `Re: ${latest.subject}`,
      thread_id: selectedThreadLive.thread_id,
    });
    setComposeOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedThreadLive) return;
    await Promise.all(selectedThreadLive.messages.map(m => base44.entities.EmailMessage.delete(m.id)));
    qc.invalidateQueries({ queryKey: ['emails'] });
    setSelectedThread(null);
    toast.success('Thread deleted');
  };

  const handleCompose = () => {
    setReplyPrefill({});
    setComposeOpen(true);
  };

  return (
    <PullToRefresh onRefresh={refetchEmails}>
    <div className="flex flex-col h-[calc(100vh-3.5rem)] sm:h-[calc(100vh-4rem)] -mx-3 sm:-mx-4 md:-mx-6 overflow-hidden">
      {/* Slim hero bar */}
      <div className="relative shrink-0 border-b border-primary/20 bg-gradient-to-r from-primary/8 via-card to-blue-500/5 px-5 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-primary/20 flex items-center justify-center">
            <Mail className="w-4 h-4 text-primary" />
          </div>
          <div>
            <span className="font-bold text-sm">Email</span>
            <span className="text-muted-foreground text-xs ml-2">{emails.length} messages</span>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {unreadCount > 0 && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary shrink-0">
              <Inbox className="w-3 h-3" />{unreadCount} unread
            </div>
          )}
          <Button size="sm" className="gap-1.5 h-7 text-xs" onClick={handleCompose}>
            <Send className="w-3.5 h-3.5" /> Compose
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={handleRefresh} disabled={syncing}>
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} /> {syncing ? 'Syncing…' : 'Sync'}
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={handleOpenWebmail}>
            <ExternalLink className="w-3.5 h-3.5" /> Open Webmail
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => setTemplatesOpen(true)}>
            <FileText className="w-3.5 h-3.5" /> Templates
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-7 text-xs" onClick={() => setSettingsOpen(true)}>
            <SettingsIcon className="w-3.5 h-3.5" /> Provider Settings
          </Button>
        </div>
      </div>
      <div className="flex flex-1 overflow-hidden">
      {/* Sidebar */}
      <div className="hidden sm:flex w-52 shrink-0 border-r bg-card flex-col">
        <div className="p-3 border-b">
          <Button className="w-full gap-2" onClick={handleCompose}>
            <Pencil className="w-4 h-4" />Compose
          </Button>
        </div>
        <nav className="p-2 space-y-0.5">
          {FOLDERS.map(f => (
            <button
              key={f.id}
              onClick={() => { setFolder(f.id); setSelectedThread(null); }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                folder === f.id ? 'bg-primary/10 text-primary' : 'text-muted-foreground hover:bg-muted'
              }`}
            >
              <f.icon className="w-4 h-4" />
              {f.label}
              {f.id === 'inbox' && unreadCount > 0 && (
                <Badge className="ml-auto bg-primary text-primary-foreground text-[10px] px-1.5 py-0">{unreadCount}</Badge>
              )}
            </button>
          ))}
        </nav>
        {accounts.length > 0 && (
          <div className="px-3 py-2 border-t">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">Accounts</p>
            <div className="space-y-0.5">
              {accounts.map(acc => (
                <button
                  key={acc.id}
                  onClick={handleRefresh}
                  disabled={syncing}
                  title="Sync this inbox now"
                  className="w-full flex items-center gap-2 px-2 py-1 rounded-md text-xs hover:bg-muted transition-colors disabled:opacity-50"
                >
                  <Mail className="w-3 h-3 text-muted-foreground shrink-0" />
                  <span className="break-all flex-1 leading-tight text-left">{acc.email_address}</span>
                  {acc.is_default && <Star className="w-3 h-3 text-primary fill-primary shrink-0" />}
                </button>
              ))}
            </div>
          </div>
        )}
        {accounts.length === 0 && systemEmailConfigured && systemEmail?.email_address && (
          <div className="px-3 py-2 border-t">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-1.5">System Email</p>
            <div className="flex items-center gap-2 px-2 py-1 rounded-md text-xs">
              <Mail className="w-3 h-3 text-primary shrink-0" />
              <span className="break-all flex-1 leading-tight text-primary">{systemEmail.email_address}</span>
              <Star className="w-3 h-3 text-primary fill-primary shrink-0" />
            </div>
            <p className="text-[10px] text-muted-foreground mt-1 px-2">
              Sending via system email
            </p>
          </div>
        )}
        <div className="mt-auto p-3 border-t">
          <button
            onClick={handleRefresh}
            disabled={syncing}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-muted-foreground hover:bg-muted transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing…' : 'Refresh Inbox'}
          </button>
        </div>
      </div>

      {/* Email list */}
      <div className={`w-full sm:w-80 shrink-0 border-r flex-col bg-background ${selectedThreadLive ? 'hidden sm:flex' : 'flex'}`}>
        <div className="p-3 border-b">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              placeholder="Search emails..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8 h-8 text-xs"
            />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">Loading...</div>
          ) : (
            <EmailList
              threads={threads}
              selectedThreadId={selectedThread?.thread_id}
              onSelect={handleSelectThread}
              folder={folder}
            />
          )}
        </div>
      </div>

      {/* Thread view */}
      <div className={`flex-1 flex-col bg-background ${selectedThreadLive ? 'flex' : 'hidden sm:flex'}`}>
        {selectedThreadLive ? (
          <>
            <div className="flex items-center justify-end px-4 py-2 border-b gap-2">
              <Button variant="outline" size="sm" className="gap-1.5 text-xs" onClick={handleReply}>
                Reply
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={handleDelete}>
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex-1 overflow-hidden flex flex-col">
              <ThreadView
                messages={selectedThreadLive.messages}
                onBack={() => setSelectedThread(null)}
                onReply={handleReply}
              />
              <InlineReply
                threadId={selectedThreadLive.thread_id}
                to={
                  selectedThreadLive.messages[selectedThreadLive.messages.length - 1]?.direction === 'sent'
                    ? selectedThreadLive.messages[selectedThreadLive.messages.length - 1]?.to_address
                    : selectedThreadLive.messages[selectedThreadLive.messages.length - 1]?.from_address
                }
                subject={selectedThreadLive.messages[0]?.subject}
                latestMessage={selectedThreadLive.messages[selectedThreadLive.messages.length - 1]}
                onSent={() => qc.invalidateQueries({ queryKey: ['emails'] })}
              />
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-3">
            <Mail className="w-12 h-12 opacity-20" />
            <p className="text-sm">Select an email to read</p>
            <Button variant="outline" size="sm" onClick={handleCompose}>Compose New Email</Button>
          </div>
        )}
      </div>

      </div>

      <ComposeModal
        open={composeOpen}
        onClose={() => setComposeOpen(false)}
        onSent={() => qc.invalidateQueries({ queryKey: ['emails'] })}
        prefill={replyPrefill}
        user={user}
        accounts={accounts}
        defaultAccountId={defaultAccount?.id}
        systemEmail={systemEmail}
        systemEmailConfigured={systemEmailConfigured}
      />

      {/* Email Provider Settings Dialog */}
      {settingsOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSettingsOpen(false)} />
          <div className="relative z-10 w-full max-w-2xl my-8">
            <EmailAccountsSummary />
            <div className="flex justify-center mt-3">
              <Button variant="outline" size="sm" onClick={() => setSettingsOpen(false)}>Close</Button>
            </div>
          </div>
        </div>
      )}

      {/* Template Manager Dialog */}
      {templatesOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 overflow-y-auto">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setTemplatesOpen(false)} />
          <div className="relative z-10 w-full max-w-2xl my-8 bg-card border border-border rounded-xl p-5">
            <TemplateManager onClose={() => setTemplatesOpen(false)} />
            <div className="flex justify-center mt-3">
              <Button variant="outline" size="sm" onClick={() => setTemplatesOpen(false)}>Close</Button>
            </div>
          </div>
        </div>
      )}
    </div>
    </PullToRefresh>
  );
}