import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  User, Plug, Bell, Save, Zap, Palette,
  Loader2, CheckCircle2, Phone, Mail, Star
} from 'lucide-react';
import { toast } from 'sonner';
import IntegrationCard from '@/components/settings/IntegrationCard';
import OAuthIntegrationCard from '@/components/settings/OAuthIntegrationCard';
import ModuleConfiguration from '@/components/settings/ModuleConfiguration';
import { PersonalizationSettings } from '@/components/shared/PersonalizationSettings';
import DangerZoneCard from '@/components/settings/DangerZoneCard';

const TIMEZONES = [
  'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
  'America/Phoenix', 'America/Anchorage', 'Pacific/Honolulu',
  'Europe/London', 'Europe/Paris', 'Europe/Berlin', 'Asia/Tokyo',
  'Asia/Singapore', 'Australia/Sydney',
];

const INTEGRATIONS = [
  {
    id: 'calendly',
    name: 'Calendly',
    emoji: '📅',
    bg: 'bg-blue-500/10',
    desc: 'Auto-book appointments directly from your leads',
    keyField: 'calendly_api_key',
    whatItDoes: 'When a lead is ready to book, the system checks your Calendly calendar and schedules the meeting automatically.',
    benefit: 'No more back-and-forth scheduling — leads pick a time and it\'s done.',
    steps: [
      { text: 'Go to Calendly and sign in (or create a free account)', link: 'https://calendly.com', linkLabel: 'Open Calendly →' },
      { text: 'Click your profile photo (top right) → Integrations → API & Webhooks' },
      { text: 'Click "Create new token", give it any name (e.g. "Axis"), then copy the token' },
      { text: 'Also copy your Event URL from your Calendly profile page (looks like calendly.com/yourname/30min)' },
      { text: 'Paste both below and click Save' },
    ],
    fields: [
      { field: 'calendly_api_key', label: 'Calendly API Token', hint: 'The long code you copied from Calendly → Integrations', placeholder: 'eyJhbGciOiJIUzI1NiJ9...', secret: true },
      { field: 'calendly_event_url', label: 'Your Calendly Event Link', hint: 'Your booking page URL (e.g. calendly.com/yourname/30min)', placeholder: 'https://calendly.com/yourname/30min', secret: false },
    ],
  },
  {
    id: 'twilio',
    name: 'Twilio (Calls & SMS)',
    emoji: '📞',
    bg: 'bg-rose-500/10',
    desc: 'Make automated calls AND send text messages to leads',
    keyField: 'twilio_account_sid',
    whatItDoes: 'Enables both VoIP calling and SMS messaging. The system can place automated outbound calls directly from the AI Assistant and send/receive SMS for follow-ups, confirmations, and reminders.',
    benefit: 'Full voice and text automation — no manual dialing needed. Calls and texts use the same Twilio account.',
    steps: [
      { text: 'Go to Twilio and create a free account', link: 'https://www.twilio.com/try-twilio', linkLabel: 'Sign up for Twilio →' },
      { text: 'Once logged in, you\'ll see your Account SID and Auth Token right on the dashboard — copy both' },
      { text: 'Click "Get a trial phone number" (it\'s free) and copy that number too' },
      { text: 'Paste all three below and click Save — this single account enables both calling and SMS' },
    ],
    fields: [
      { field: 'twilio_account_sid', label: 'Account SID', hint: 'Found on your Twilio dashboard homepage (starts with AC...)', placeholder: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', secret: false },
      { field: 'twilio_auth_token', label: 'Auth Token', hint: 'Found right next to your Account SID on the dashboard', placeholder: 'Your auth token', secret: true },
      { field: 'twilio_phone_number', label: 'Your Twilio Phone Number', hint: 'The phone number Twilio gave you (include country code, e.g. +1) — used for BOTH calls and SMS', placeholder: '+15550001234', secret: false },
    ],
  },
  {
    id: 'googlecalendar',
    name: 'Google Calendar',
    emoji: '🗓️',
    bg: 'bg-emerald-500/10',
    desc: 'Sync your Google Calendar with appointments',
    oauthProvider: true,
    provider: 'google_calendar',
    scopes: ['https://www.googleapis.com/auth/calendar.events'],
    whatItDoes: 'Keeps your Google Calendar in sync so appointments show up automatically.',
    benefit: 'See all your booked meetings in Google Calendar alongside your personal events.',
  },
  {
    id: 'zoom',
    name: 'Zoom',
    emoji: '🎥',
    bg: 'bg-cyan-500/10',
    desc: 'Auto-generate Zoom links for meetings',
    oauthProvider: true,
    provider: 'zoom',
    scopes: [],
    whatItDoes: 'When an appointment is set, the system can automatically create a Zoom meeting link and send it to the lead.',
    benefit: 'Leads get a Zoom link the moment they book — no manual work needed.',
  },
];

const CALL_SERVICES = [
  { value: 'ai_simulation', label: '🤖 AI Simulation', desc: 'Fully automated AI calls (no real dialing)' },
  { value: 'phone_link', label: '📱 Phone Link', desc: 'Opens your phone dialer — you make the call' },
  { value: 'zoom', label: '🎥 Zoom', desc: 'Opens a Zoom meeting for each lead' },
  { value: 'whatsapp', label: '💬 WhatsApp', desc: 'Opens WhatsApp Web chat for each lead' },
  { value: 'twilio', label: '📞 Twilio', desc: 'Use Twilio API for real outbound calls' },
  { value: 'custom_api', label: '🔌 Custom API', desc: 'Connect your own calling service via API' },
];

const DEFAULT_SETTINGS = {
  company_name: '',
  caller_id_number: '',
  default_timezone: 'America/New_York',
  enable_call_recording: true,
  enable_voicemail: true,
  default_call_service: 'twilio',
  custom_api_endpoint: '',
  custom_api_key: '',
  custom_api_name: '',
  calendly_event_url: '',
  calendly_api_key: '',
  twilio_account_sid: '',
  twilio_auth_token: '',
  twilio_phone_number: '',
  zoom_client_id: '',
  zoom_client_secret: '',
  zoom_account_id: '',
  email_notifications: true,
  sms_notifications: false,
  bot_agent_name: '',
};

export default function UserSettings() {
  const { user } = useCurrentUser();
  const qc = useQueryClient();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [recordId, setRecordId] = useState(null);
  const [saved, setSaved] = useState(false);
  const [enabledModules, setEnabledModules] = useState([]);

  // Fetch existing settings via backend function (avoids RLS issues)
  const { data: oauthConnections = [] } = useQuery({
    queryKey: ['oauth-connections', user?.email],
    queryFn: async () => {
      const res = await base44.functions.invoke('getOAuthConnections', {});
      return res.data?.connections || [];
    },
    enabled: !!user?.email,
  });

  const { data: records = [], isLoading } = useQuery({
    queryKey: ['user-settings', user?.email],
    queryFn: async () => {
      const res = await base44.functions.invoke('saveUserSettings', { action: 'get', key: `global_${user.email}` });
      return res.data?.settings ? [res.data.settings] : [];
    },
    enabled: !!user?.email,
  });

  useEffect(() => {
    if (records.length > 0) {
      const r = records[0];
      setRecordId(r.id);
      setSettings(prev => ({
        ...prev,
        company_name: r.company_name || '',
        caller_id_number: r.caller_id_number || '',
        default_timezone: r.default_timezone || 'America/New_York',
        enable_call_recording: r.enable_call_recording ?? true,
        enable_voicemail: r.enable_voicemail ?? true,
        calendly_event_url: r.calendly_event_url || '',
        calendly_api_key: r.calendly_api_key || '',
        twilio_account_sid: r.twilio_account_sid || '',
        twilio_auth_token: r.twilio_auth_token || '',
        twilio_phone_number: r.twilio_phone_number || '',
        zoom_client_id: r.zoom_client_id || '',
        zoom_client_secret: r.zoom_client_secret || '',
        zoom_account_id: r.zoom_account_id || '',
        default_call_service: r.default_call_service || 'twilio',
        custom_api_endpoint: r.custom_api_endpoint || '',
        custom_api_key: r.custom_api_key || '',
        custom_api_name: r.custom_api_name || '',
        bot_agent_name: r.bot_agent_name || '',
        email_notifications: r.email_notifications ?? true,
        sms_notifications: r.sms_notifications ?? false,
      }));
      // Parse enabled modules
      if (r.enabled_modules) {
        try {
          const parsed = JSON.parse(r.enabled_modules);
          setEnabledModules(Array.isArray(parsed) ? parsed : []);
        } catch (e) {
          console.error('Failed to parse enabled_modules', e);
        }
      }
    }
  }, [records]);

  const saveMut = useMutation({
    mutationFn: async () => {
      if (!user?.email) throw new Error('User not loaded');
      const payload = { ...settings, enabled_modules: JSON.stringify(enabledModules) };
      const res = await base44.functions.invoke('saveUserSettings', {
        action: 'save',
        key: `global_${user.email}`,
        data: payload,
      });
      return res.data;
    },
    onSuccess: (result) => {
      if (!recordId && result?.id) setRecordId(result.id);
      qc.invalidateQueries({ queryKey: ['user-settings'] });
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
      toast.success('Settings saved!');
    },
    onError: (err) => toast.error(`Failed to save: ${err?.message}`),
  });

  const toggleModule = (moduleId) => {
    setEnabledModules(prev => {
      if (prev.includes(moduleId)) {
        return prev.filter(m => m !== moduleId);
      } else {
        return [...prev, moduleId];
      }
    });
  };

  const enableAllModules = () => {
    setEnabledModules(['all']);
  };

  const resetToDefaults = () => {
    setEnabledModules(['dashboard', 'crm_leads', 'crm_appointments', 'crm_tasks', 'account_subscription', 'account_settings', 'account_api']);
  };

  const set = (key, val) => setSettings(s => ({ ...s, [key]: val }));

  const handleIntegrationSave = (newValues) => {
    const merged = { ...settings, ...newValues };
    setSettings(merged);
    if (!user?.email) return;
    base44.functions.invoke('saveUserSettings', {
      action: 'save',
      key: `global_${user.email}`,
      data: merged,
    }).then((res) => {
      if (!recordId && res.data?.id) setRecordId(res.data.id);
      qc.invalidateQueries({ queryKey: ['user-settings'] });
      qc.invalidateQueries({ queryKey: ['system-settings'] });
      toast.success('Integration saved!');
    }).catch(err => toast.error(`Failed: ${err?.message}`));
  };

  if (isLoading) return (
    <div className="flex items-center justify-center h-40">
      <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
    </div>
  );

  const connectedCount = INTEGRATIONS.filter(i => i.keyField && settings[i.keyField]).length;
  const totalIntegrations = INTEGRATIONS.filter(i => i.keyField).length;

  return (
    <div className="max-w-3xl space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">My Account Settings</h1>
              <p className="text-muted-foreground text-xs">Configure your workspace, integrations, and preferences</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <Plug className="w-3.5 h-3.5" />{connectedCount}/{totalIntegrations} integrations
            </div>
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending} size="sm" className="gap-1.5">
              {saveMut.isPending ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Saving...</>
                : saved ? <><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />Saved!</>
                : <><Save className="w-3.5 h-3.5" />Save Settings</>}
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="profile">
        <TabsList className="grid grid-cols-6 w-full">
          <TabsTrigger value="profile"><User className="w-3.5 h-3.5 mr-1.5" />Profile</TabsTrigger>
          <TabsTrigger value="calling"><Phone className="w-3.5 h-3.5 mr-1.5" />Calling</TabsTrigger>
          <TabsTrigger value="integrations"><Plug className="w-3.5 h-3.5 mr-1.5" />Integrations</TabsTrigger>
          <TabsTrigger value="notifications"><Bell className="w-3.5 h-3.5 mr-1.5" />Notifications</TabsTrigger>
          <TabsTrigger value="modules"><Zap className="w-3.5 h-3.5 mr-1.5" />Modules</TabsTrigger>
          <TabsTrigger value="personalization"><Palette className="w-3.5 h-3.5 mr-1.5" />Personalize</TabsTrigger>
        </TabsList>

        {/* Profile */}
        <TabsContent value="profile">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><User className="w-4 h-4" />Profile & Company</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Full Name</Label>
                  <Input value={user?.full_name || ''} disabled className="mt-1 opacity-60" />
                  <p className="text-xs text-muted-foreground mt-1">Managed by your account</p>
                </div>
                <div>
                  <Label>Email</Label>
                  <Input value={user?.email || ''} disabled className="mt-1 opacity-60" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Company Name</Label>
                  <Input className="mt-1" value={settings.company_name} onChange={e => set('company_name', e.target.value)} placeholder="Your Company LLC" />
                </div>
                <div>
                  <Label>Bot / Agent Display Name</Label>
                  <Input className="mt-1" value={settings.bot_agent_name} onChange={e => set('bot_agent_name', e.target.value)} placeholder="Alex from Acme Inc." />
                  <p className="text-xs text-muted-foreground mt-1">Name the AI uses when calling leads</p>
                </div>
              </div>
              <div>
                <Label>Default Timezone</Label>
                <Select value={settings.default_timezone} onValueChange={v => set('default_timezone', v)}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TIMEZONES.map(tz => <SelectItem key={tz} value={tz}>{tz.replace(/_/g, ' ')}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Danger Zone */}
          <DangerZoneCard user={user} />
        </TabsContent>

        {/* Calling */}
        <TabsContent value="calling">
          <div className="space-y-4">
          {/* Default Calling Service */}
          <Card className="border-primary/30">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2"><Star className="w-4 h-4 text-primary" />Default Calling Service</CardTitle>
              <p className="text-xs text-muted-foreground mt-1">The AI Assistant will automatically use this service when dialing. You can still change it per-session on the AI Assistant page.</p>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CALL_SERVICES.map(svc => (
                  <button
                    key={svc.value}
                    onClick={() => set('default_call_service', svc.value)}
                    className={`flex items-start gap-3 p-3 rounded-xl border text-left transition-all ${
                      settings.default_call_service === svc.value
                        ? 'border-primary bg-primary/10 shadow-sm'
                        : 'border-border hover:border-primary/40 hover:bg-muted/40'
                    }`}
                  >
                    <div className="flex-1">
                      <p className={`text-sm font-semibold ${settings.default_call_service === svc.value ? 'text-primary' : ''}`}>{svc.label}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{svc.desc}</p>
                    </div>
                    {settings.default_call_service === svc.value && (
                      <CheckCircle2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                    )}
                  </button>
                ))}
              </div>

              {/* Custom API fields */}
              {settings.default_call_service === 'custom_api' && (
                <div className="mt-3 space-y-3 p-4 bg-muted/30 rounded-xl border border-dashed">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Custom Calling API Configuration</p>
                  <div>
                    <Label>Service Name</Label>
                    <Input className="mt-1" value={settings.custom_api_name} onChange={e => set('custom_api_name', e.target.value)} placeholder="e.g. RingCentral, Vonage, Bandwidth..." />
                  </div>
                  <div>
                    <Label>API Endpoint URL</Label>
                    <Input className="mt-1" value={settings.custom_api_endpoint} onChange={e => set('custom_api_endpoint', e.target.value)} placeholder="https://api.yourservice.com/calls" />
                  </div>
                  <div>
                    <Label>API Key / Auth Token</Label>
                    <Input className="mt-1" type="password" value={settings.custom_api_key} onChange={e => set('custom_api_key', e.target.value)} placeholder="Your API key..." />
                  </div>
                  <div className="text-xs text-muted-foreground bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
                    ⚠️ Custom API calls are initiated by the dialer using your endpoint. Make sure your API accepts POST requests with <code>phone_number</code>, <code>lead_name</code>, and <code>script</code> in the request body.
                  </div>
                </div>
              )}

              {/* Twilio status hint */}
              {settings.default_call_service === 'twilio' && (
                <div className={`text-xs rounded-lg p-3 ${settings.twilio_account_sid ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-700' : 'bg-amber-500/10 border border-amber-500/20 text-amber-700'}`}>
                  {settings.twilio_account_sid
                    ? '✅ Twilio is connected. The AI Assistant will use your Twilio number for outbound calls. Your account also enables SMS messaging.'
                    : '⚠️ Twilio is not connected yet. Go to the Integrations tab to set up your Twilio credentials for both calls and SMS.'}
                </div>
              )}

              <div className="flex justify-end">
                <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending} size="sm">
                  {saveMut.isPending ? <><Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />Saving...</> : <><Save className="w-3.5 h-3.5 mr-1.5" />Save Default</>}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Phone className="w-4 h-4" />Calling Preferences</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Caller ID / Outbound Number</Label>
                <Input className="mt-1" value={settings.caller_id_number} onChange={e => set('caller_id_number', e.target.value)} placeholder="+15550001234" />
                <p className="text-xs text-muted-foreground mt-1">Your verified outbound number displayed to leads</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div>
                    <Label className="mb-0">Enable Call Recording</Label>
                    <p className="text-xs text-muted-foreground">Records all outbound calls for quality review</p>
                  </div>
                  <Switch checked={settings.enable_call_recording} onCheckedChange={v => set('enable_call_recording', v)} />
                </div>
                <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                  <div>
                    <Label className="mb-0">Enable Voicemail Drop</Label>
                    <p className="text-xs text-muted-foreground">Automatically leaves voicemail on no-answer</p>
                  </div>
                  <Switch checked={settings.enable_voicemail} onCheckedChange={v => set('enable_voicemail', v)} />
                </div>
              </div>
            </CardContent>
          </Card>
          </div>
        </TabsContent>

        {/* Integrations */}
        <TabsContent value="integrations">
          <div className="space-y-4">
            {/* Progress bar */}
            <div className="p-4 bg-card border border-border rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold">Setup Progress</p>
                <span className="text-sm font-bold text-primary">
                  {INTEGRATIONS.filter(i => i.keyField && settings[i.keyField]).length} / {INTEGRATIONS.filter(i => i.keyField).length} connected
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500"
                  style={{ width: `${(INTEGRATIONS.filter(i => i.keyField && settings[i.keyField]).length / INTEGRATIONS.filter(i => i.keyField).length) * 100}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-2">Each integration unlocks more automation. Click "Set Up" on any card to get step-by-step instructions.</p>
            </div>

            {INTEGRATIONS.map(integration => {
              if (integration.oauthProvider) {
                return (
                  <OAuthIntegrationCard
                    key={integration.id}
                    integration={integration}
                    connection={oauthConnections.find(c => c.provider === integration.provider)}
                    settings={settings}
                  />
                );
              }
              return (
                <IntegrationCard
                  key={integration.id}
                  integration={integration}
                  settings={settings}
                  onSave={handleIntegrationSave}
                  isSaving={saveMut.isPending}
                />
              );
            })}
          </div>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Bell className="w-4 h-4" />Notification Preferences</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <Label className="mb-0">Email Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive updates on leads, appointments & tasks</p>
                  </div>
                </div>
                <Switch checked={settings.email_notifications} onCheckedChange={v => set('email_notifications', v)} />
              </div>
              <div className="flex items-center justify-between p-3 border border-border rounded-lg">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <div>
                    <Label className="mb-0">SMS Notifications</Label>
                    <p className="text-xs text-muted-foreground">Get SMS alerts for new appointments (requires Twilio)</p>
                  </div>
                </div>
                <Switch checked={settings.sms_notifications} onCheckedChange={v => set('sms_notifications', v)} />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Module Configuration */}
        <TabsContent value="modules">
          <ModuleConfiguration
            enabledModules={enabledModules}
            onToggle={toggleModule}
            onEnableAll={enableAllModules}
            onResetDefaults={resetToDefaults}
            onSave={() => saveMut.mutate()}
            isSaving={saveMut.isPending}
          />
        </TabsContent>

        {/* Personalization */}
        <TabsContent value="personalization">
          <PersonalizationSettings />
        </TabsContent>
      </Tabs>

      {/* Bottom save */}
      <div className="flex justify-end">
        <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending} size="lg">
          {saveMut.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
            : saved ? <><CheckCircle2 className="w-4 h-4 mr-2 text-emerald-400" />Saved!</>
            : <><Save className="w-4 h-4 mr-2" />Save Settings</>}
        </Button>
      </div>
    </div>
  );
}