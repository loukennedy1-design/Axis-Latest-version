import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2, RefreshCw, CheckCircle2, Eye, Zap } from 'lucide-react';

const TYPE_LABELS = {
  workflow: 'Workflow', ai_prompt: 'AI Prompt', redundant_task: 'Redundant Task', staffing: 'Staffing',
  pricing: 'Pricing', marketing_campaign: 'Marketing', unused_feature: 'Unused Feature',
  ui_improvement: 'UI', new_integration: 'Integration'
};
const RISK_COLORS = { low: 'text-emerald-400', medium: 'text-amber-400', high: 'text-red-400' };

export default function ContinuousEvolution() {
  const [opts, setOpts] = useState([]);
  const [overview, setOverview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('continuousEvolutionEngine', { action: 'get_overview' });
      setOpts(res.data?.optimizations || []);
      setOverview(res.data?.overview);
    } catch { setOpts([]); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAll(); }, []);

  const handleRun = async () => {
    setRunning(true);
    try {
      await base44.functions.invoke('continuousEvolutionEngine', { action: 'run_cycle' });
      await fetchAll();
    } finally { setRunning(false); }
  };

  const updateStatus = async (id, status) => {
    await base44.functions.invoke('continuousEvolutionEngine', { action: 'update_status', optimization_id: id, new_status: status });
    await fetchAll();
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-primary" />
            Continuous Business Evolution
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Trinity's nightly AI optimization cycle — analyzes workflows, improves automations, optimizes prompts, detects redundant tasks, and recommends improvements across staffing, pricing, marketing, and integrations. Low-risk optimizations auto-apply.
          </p>
        </div>
        <Button onClick={handleRun} disabled={running}>
          {running ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {running ? 'Running...' : 'Run Cycle'}
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Optimizations" value={overview?.total ?? '—'} />
        <StatCard label="Auto-Applied" value={overview?.auto_applied ?? 0} color="text-emerald-400" icon={Zap} />
        <StatCard label="Needs Review" value={overview?.needs_review ?? 0} color="text-amber-400" icon={Eye} />
        <StatCard label="Optimization Types" value={Object.keys(overview?.by_type || {}).length} />
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : opts.length ? (
        <div className="space-y-3">
          {opts.map(o => (
            <Card key={o.id}>
              <CardContent className="pt-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs px-2 py-0.5 rounded bg-primary/20 text-primary">{TYPE_LABELS[o.optimization_type] || o.optimization_type}</span>
                      <span className={`text-xs ${RISK_COLORS[o.risk]}`}>{o.risk} risk</span>
                      <span className="text-xs text-muted-foreground">· {o.confidence}% confidence</span>
                      {o.status === 'auto_applied' && <span className="text-xs px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 flex items-center gap-1"><Zap className="w-3 h-3" /> auto-applied</span>}
                      {o.status === 'needs_review' && <span className="text-xs px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400">needs review</span>}
                      {o.status === 'applied' && <span className="text-xs px-1.5 py-0.5 rounded bg-muted">applied</span>}
                    </div>
                    <h3 className="font-semibold">{o.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{o.description}</p>
                    <div className="flex flex-wrap gap-4 mt-3 text-xs text-muted-foreground">
                      {o.business_impact && <span>Impact: {o.business_impact}</span>}
                      {o.expected_roi && <span className="text-primary">ROI: {o.expected_roi}</span>}
                      {o.time_savings && <span>Saves: {o.time_savings}</span>}
                      {o.implementation_difficulty && <span>Difficulty: {o.implementation_difficulty}</span>}
                    </div>
                  </div>
                  {o.status === 'needs_review' && (
                    <Button size="sm" variant="outline" onClick={() => updateStatus(o.id, 'applied')}><CheckCircle2 className="w-3.5 h-3.5" /> Apply</Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card><CardContent className="py-12 text-center"><Sparkles className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" /><p className="text-muted-foreground">No optimizations yet. Click "Run Cycle" for Trinity to analyze and optimize your business overnight.</p></CardContent></Card>
      )}
    </div>
  );
}

function StatCard({ label, value, color, icon: Icon }) {
  return (
    <Card><CardContent className="pt-5">
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        {Icon && <Icon className="w-4 h-4 text-primary/60" />}
      </div>
      <p className={`text-2xl font-bold font-poppins mt-1 ${color || ''}`}>{value ?? '—'}</p>
    </CardContent></Card>
  );
}