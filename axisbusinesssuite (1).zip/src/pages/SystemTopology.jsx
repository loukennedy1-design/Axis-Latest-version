import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Settings, 
  Shield, 
  Mail, 
  Phone, 
  CreditCard, 
  Globe,
  RefreshCw,
  Zap,
  Users,
  TrendingUp,
  LayoutDashboard
} from "lucide-react";
import { useCurrentUser } from "@/hooks/useCurrentUser";

const ConnectionStatus = ({ status, label, description, onFix }) => {
  const statusConfig = {
    configured: {
      icon: CheckCircle2,
      color: "text-green-500",
      bg: "bg-green-500/10",
      border: "border-green-500/20",
      label: "Connected"
    },
    missing: {
      icon: XCircle,
      color: "text-red-500",
      bg: "bg-red-500/10",
      border: "border-red-500/20",
      label: "Not Configured"
    },
    warning: {
      icon: AlertCircle,
      color: "text-yellow-500",
      bg: "bg-yellow-500/10",
      border: "border-yellow-500/20",
      label: "Warning"
    }
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className={`flex items-start justify-between p-4 rounded-lg border ${config.border} ${config.bg}`}>
      <div className="flex items-start gap-3">
        <Icon className={`w-5 h-5 mt-0.5 ${config.color}`} />
        <div>
          <h4 className="font-medium text-sm">{label}</h4>
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Badge variant={status === "configured" ? "default" : status === "missing" ? "destructive" : "secondary"}>
          {config.label}
        </Badge>
        {onFix && (
          <Button size="sm" variant="outline" onClick={onFix}>
            Fix
          </Button>
        )}
      </div>
    </div>
  );
};

const SystemHealthCard = ({ title, score, items, icon: Icon }) => {
  const scoreColor = score >= 90 ? "text-green-500" : score >= 70 ? "text-yellow-500" : "text-red-500";
  const configuredCount = items.filter(i => i.status === "configured").length;
  const progress = (configuredCount / items.length) * 100;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Icon className="w-5 h-5 text-muted-foreground" />
            <CardTitle className="text-base">{title}</CardTitle>
          </div>
          <div className={`text-2xl font-bold ${scoreColor}`}>{score}%</div>
        </div>
        <CardDescription className="text-xs">
          {configuredCount}/{items.length} connections configured
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <Progress value={progress} className="h-2" />
        <div className="space-y-2">
          {items.map((item, idx) => (
            <ConnectionStatus
              key={idx}
              status={item.status}
              label={item.label}
              description={item.description}
              onFix={item.onFix}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default function SystemTopology() {
  const { user, isLoading: isLoadingUser } = useCurrentUser();
  const [healthData, setHealthData] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);

  const fetchHealth = async () => {
    try {
      const response = await base44.functions.invoke("axisGovernanceCore", { action: "health_check" });
      return response.data;
    } catch (error) {
      console.error("Failed to fetch health data:", error);
      return null;
    }
  };

  const { data, refetch, isFetched } = useQuery({
    queryKey: ["system-health"],
    queryFn: fetchHealth,
    enabled: !isLoadingUser && (user?.role === "admin" || user?.role === "super_admin"),
  });

  React.useEffect(() => {
    if (isFetched) {
      setHealthData(data || null);
      setIsLoading(false);
    }
  }, [data, isFetched]);

  if (isLoadingUser || isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user || (user.role !== "admin" && user.role !== "super_admin")) {
    return (
      <div className="flex items-center justify-center h-full">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertCircle className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Admin Access Required</h3>
              <p className="text-muted-foreground">
                System topology is only accessible to administrators.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const secrets = healthData?.secrets || {};
  
  // Payment Processing
  const paymentItems = [
    {
      status: secrets.SQUARE_API_KEY?.configured ? "configured" : "missing",
      label: "Square API Key",
      description: "Required for payment processing and billing"
    },
    {
      status: secrets.SQUARE_LOCATION_ID?.configured ? "configured" : "missing",
      label: "Square Location ID",
      description: "Your business location for transactions"
    },
    {
      status: secrets.SQUARE_WEBHOOK_SIGNATURE ? "configured" : "missing",
      label: "Square Webhook Secret",
      description: "Secure webhook signature verification"
    }
  ];

  // Communications
  const commsItems = [
    {
      status: secrets.TWILIO_ACCOUNT_SID?.configured ? "configured" : "missing",
      label: "Twilio Account SID",
      description: "Required for SMS and voice calls"
    },
    {
      status: secrets.TWILIO_AUTH_TOKEN?.configured ? "configured" : "missing",
      label: "Twilio Auth Token",
      description: "Twilio API authentication"
    },
    {
      status: secrets.TWILIO_PHONE_NUMBER?.configured ? "configured" : "missing",
      label: "Twilio Phone Number",
      description: "Sender ID for SMS messages"
    },
    {
      status: "configured", // Slack is authorized
      label: "Slack Integration",
      description: "Slack bot for team notifications"
    }
  ];

  // Admin & Notifications
  const adminItems = [
    {
      status: secrets.SUPER_ADMIN_EMAILS?.configured ? "configured" : "missing",
      label: "Super Admin Emails",
      description: "Recipients for critical system alerts"
    },
    {
      status: secrets.BILLING_EMAIL?.configured ? "configured" : "missing",
      label: "Billing Email",
      description: "Customer service and billing communications"
    }
  ];

  // System Configuration
  const systemItems = [
    {
      status: secrets.APP_URL?.configured ? "configured" : "missing",
      label: "App URL",
      description: "Application base URL for links and redirects"
    },
    {
      status: secrets.MOVEMENT_ACCESS_CODE?.configured ? "configured" : "missing",
      label: "Movement Access Code",
      description: "Authentication for Movement membership"
    },
    {
      status: secrets.google_oauth_client_secret ? "configured" : "missing",
      label: "Google OAuth",
      description: "Google Calendar and Drive integration"
    }
  ];

  // Calculate scores
  const calcScore = (items) => Math.round((items.filter(i => i.status === "configured").length / items.length) * 100);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">System Topology</h1>
          <p className="text-muted-foreground">
            Monitor all integrations, connections, and system health in real-time
          </p>
        </div>
        <Button onClick={() => refetch()} variant="outline" className="gap-2">
          <RefreshCw className="w-4 h-4" />
          Refresh
        </Button>
      </div>

      {/* Overall Health Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Overall System Health
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 rounded-lg bg-slate-800/50">
              <div className="text-3xl font-bold text-green-500 mb-1">
                {healthData?.secrets_configured || 0}/{healthData?.secrets_total || 0}
              </div>
              <div className="text-xs text-muted-foreground">Secrets Configured</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-slate-800/50">
              <div className="text-3xl font-bold text-blue-500 mb-1">
                {healthData?.system_health?.active_trials || 0}
              </div>
              <div className="text-xs text-muted-foreground">Active Trials</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-slate-800/50">
              <div className="text-3xl font-bold text-purple-500 mb-1">
                {healthData?.system_health?.active_agent_tasks || 0}
              </div>
              <div className="text-xs text-muted-foreground">AI Agents Active</div>
            </div>
            <div className="text-center p-4 rounded-lg bg-slate-800/50">
              <div className="text-3xl font-bold text-yellow-500 mb-1">
                {healthData?.system_health?.expired_trials_needing_action || 0}
              </div>
              <div className="text-xs text-muted-foreground">Trials Needing Action</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Connection Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <SystemHealthCard
          title="Payment Processing"
          icon={CreditCard}
          score={calcScore(paymentItems)}
          items={paymentItems}
        />
        
        <SystemHealthCard
          title="Communications"
          icon={Phone}
          score={calcScore(commsItems)}
          items={commsItems}
        />

        <SystemHealthCard
          title="Admin & Notifications"
          icon={Mail}
          score={calcScore(adminItems)}
          items={adminItems}
        />

        <SystemHealthCard
          title="System Configuration"
          icon={Globe}
          score={calcScore(systemItems)}
          items={systemItems}
        />
      </div>

      {/* Governance Status */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <CardTitle>Governance & Security</CardTitle>
          </div>
          <CardDescription>Security enforcement and audit status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg border border-slate-700">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-4 h-4 text-green-500" />
                <span className="font-medium text-sm">Governance Status</span>
              </div>
              <div className="text-2xl font-bold text-green-500 capitalize">
                {healthData?.governance_status || "unknown"}
              </div>
            </div>
            <div className="p-4 rounded-lg border border-slate-700">
              <div className="flex items-center gap-2 mb-2">
                <Users className="w-4 h-4 text-blue-500" />
                <span className="font-medium text-sm">Total Leads</span>
              </div>
              <div className="text-2xl font-bold">
                {healthData?.system_health?.total_leads || 0}
              </div>
            </div>
            <div className="p-4 rounded-lg border border-slate-700">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-purple-500" />
                <span className="font-medium text-sm">Calls Today</span>
              </div>
              <div className="text-2xl font-bold">
                {healthData?.system_health?.calls_today || 0}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            <CardTitle>Quick Actions</CardTitle>
          </div>
          <CardDescription>Manage your system configuration</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={() => window.location.href = "/settings"}>
              <Settings className="w-4 h-4 mr-2" />
              Go to Settings
            </Button>
            <Button variant="outline" onClick={() => window.location.href = "/dashboards"}>
              <LayoutDashboard className="w-4 h-4 mr-2" />
              Go to Dashboard
            </Button>
            <Button variant="outline" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh Status
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}