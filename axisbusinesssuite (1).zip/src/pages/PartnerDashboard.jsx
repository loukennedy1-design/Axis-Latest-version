import React from 'react';
import PartnerEarningsDashboard from '@/components/wl/PartnerEarningsDashboard';

export default function PartnerDashboard() {
  return (
    <div className="space-y-6">
      <PartnerEarningsDashboard />
    </div>
  );
}