import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Network, RefreshCw, Search, Loader2, Share2, GitBranch } from 'lucide-react';

export default function BusinessKnowledgeGraph() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [building, setBuilding] = useState(false);
  const [query, setQuery] = useState('');
  const [queryResult, setQueryResult] = useState(null);
  const [searching, setSearching] = useState(false);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('businessKnowledgeGraph', { action: 'get_status' });
      setStatus(res.data?.overview);
    } catch (e) {
      setStatus(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchStatus(); }, []);

  const handleBuild = async () => {
    setBuilding(true);
    try {
      const res = await base44.functions.invoke('businessKnowledgeGraph', { action: 'build_graph' });
      await fetchStatus();
      return res;
    } finally {
      setBuilding(false);
    }
  };

  const handleQuery = async () => {
    if (!query.trim()) return;
    setSearching(true);
    setQueryResult(null);
    try {
      const res = await base44.functions.invoke('businessKnowledgeGraph', { action: 'query', query });
      setQueryResult(res.data);
    } catch (e) {
      setQueryResult({ error: e.message });
    } finally {
      setSearching(false);
    }
  };

  const typeColors = {
    customer: 'text-emerald-400', lead: 'text-blue-400', employee: 'text-amber-400',
    invoice: 'text-purple-400', call: 'text-cyan-400', opportunity: 'text-rose-400',
    appointment: 'text-indigo-400', campaign: 'text-pink-400', shipment: 'text-orange-400'
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-poppins flex items-center gap-2">
            <Network className="w-6 h-6 text-primary" />
            Business Knowledge Graph
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            A universal relationship engine mapping every business object with bidirectional relationships. Trinity traverses this graph natively to answer relational queries.
          </p>
        </div>
        <Button onClick={handleBuild} disabled={building} variant="default">
          {building ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          {building ? 'Building...' : 'Rebuild Graph'}
        </Button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Nodes" value={status?.total_nodes ?? '—'} loading={loading} />
        <StatCard label="Total Edges" value={status?.total_edges ?? '—'} loading={loading} />
        <StatCard label="Object Types" value={Object.keys(status?.nodes_by_type || {}).length} loading={loading} />
        <StatCard label="Last Synced" value={status?.last_synced ? new Date(status.last_synced).toLocaleDateString() : '—'} loading={loading} />
      </div>

      {/* Node type breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><Share2 className="w-4 h-4 text-primary" /> Nodes by Type</CardTitle>
          <CardDescription>Distribution of mapped business objects across modules</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-6"><Loader2 className="w-5 h-5 animate-spin text-muted-foreground" /></div>
          ) : status?.nodes_by_type && Object.keys(status.nodes_by_type).length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {Object.entries(status.nodes_by_type).map(([type, count]) => (
                <div key={type} className="flex items-center justify-between rounded-lg border border-border bg-card/50 px-3 py-2">
                  <span className={`text-sm capitalize font-medium ${typeColors[type] || 'text-foreground'}`}>{type}</span>
                  <span className="text-sm font-bold text-foreground">{count}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">No nodes yet. Click "Rebuild Graph" to normalize your modules.</p>
          )}
        </CardContent>
      </Card>

      {/* Query / Traverse */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2"><GitBranch className="w-4 h-4 text-primary" /> Natural Language Traversal</CardTitle>
          <CardDescription>Ask Trinity to traverse the graph relationally — e.g. "Show me every customer connected to campaigns that generated invoices"</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleQuery()}
              placeholder="Show every customer linked to our top sales rep..."
              className="flex-1"
            />
            <Button onClick={handleQuery} disabled={searching || !query.trim()}>
              {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              Traverse
            </Button>
          </div>

          {queryResult?.error && (
            <p className="text-sm text-destructive">{queryResult.error}</p>
          )}

          {queryResult?.answer && (
            <div className="space-y-4">
              <div className="rounded-lg border border-border bg-card/50 p-4">
                <p className="text-sm leading-relaxed">{queryResult.answer}</p>
              </div>
              {queryResult.relationship_path && (
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Path:</span>
                  <code className="text-primary font-mono text-xs bg-primary/10 px-2 py-1 rounded">{queryResult.relationship_path}</code>
                </div>
              )}
              {queryResult.key_nodes?.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {queryResult.key_nodes.map((n, i) => (
                    <span key={i} className="text-xs rounded-md bg-muted px-2 py-1 border border-border">
                      <span className={`font-medium ${typeColors[n.type] || 'text-foreground'}`}>{n.name}</span>
                      <span className="text-muted-foreground ml-1">· {n.type}</span>
                    </span>
                  ))}
                </div>
              )}
              {queryResult.insight && (
                <div className="rounded-lg border-l-2 border-primary bg-primary/5 p-3">
                  <p className="text-sm text-muted-foreground"><span className="text-primary font-medium">Insight:</span> {queryResult.insight}</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ label, value, loading }) {
  return (
    <Card>
      <CardContent className="pt-5">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        {loading ? (
          <div className="h-7 mt-1 w-12 bg-muted animate-pulse rounded" />
        ) : (
          <p className="text-2xl font-bold font-poppins mt-1">{value ?? '—'}</p>
        )}
      </CardContent>
    </Card>
  );
}