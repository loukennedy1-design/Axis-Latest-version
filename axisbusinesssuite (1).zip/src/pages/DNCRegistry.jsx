import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { PhoneOff, Plus, Trash2, Search, ShieldAlert } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export default function DNCRegistry() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ phone_number: '', reason: 'customer_request', notes: '' });
  const qc = useQueryClient();
  const { user } = useCurrentUser();

  const { data: entries = [], isLoading } = useQuery({ queryKey: ['dnc'], queryFn: () => base44.entities.DNCEntry.list('-created_date') });

  const createMut = useMutation({
    mutationFn: async (data) => {
      const res1 = await base44.functions.invoke('createRecord', { entity: 'DNCEntry', data: { ...data, added_date: new Date().toISOString(), owner: user?.email } });
      if (res1.data?.error) throw new Error(res1.data.error);
      const res2 = await base44.functions.invoke('createRecord', { entity: 'ComplianceLog', data: { event_type: 'dnc_added', description: `Phone ${data.phone_number} added to DNC: ${data.reason}`, phone_number: data.phone_number, action_by: user?.email, owner: user?.email } });
      if (res2.data?.error) throw new Error(res2.data.error);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dnc'] }); setDialogOpen(false); setForm({ phone_number: '', reason: 'customer_request', notes: '' }); toast.success('Added to DNC'); }
  });
  const deleteMut = useMutation({
    mutationFn: async (entry) => {
      await base44.entities.DNCEntry.delete(entry.id);
      await base44.functions.invoke('createRecord', { entity: 'ComplianceLog', data: { event_type: 'dnc_removed', description: `Phone ${entry.phone_number} removed from DNC`, phone_number: entry.phone_number, action_by: user?.email, owner: user?.email } });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dnc'] }); toast.success('Removed from DNC'); }
  });

  const filtered = entries.filter(e => e.phone_number?.includes(search));

  const reasonLabels = { customer_request: 'Customer Request', federal_dnc: 'Federal DNC', state_dnc: 'State DNC', internal_policy: 'Internal Policy' };
  const reasonColors = { customer_request: 'bg-blue-500/10 text-blue-600', federal_dnc: 'bg-red-500/10 text-red-600', state_dnc: 'bg-amber-500/10 text-amber-600', internal_policy: 'bg-slate-500/10 text-slate-500' };

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-red-500/20 bg-gradient-to-br from-red-500/8 via-card to-slate-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
              <PhoneOff className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Do Not Call Registry</h1>
              <p className="text-muted-foreground text-xs">{entries.length} numbers · FCC/TCPA compliant DNC list</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold text-red-400">
              <ShieldAlert className="w-3.5 h-3.5" />{entries.length} protected
            </div>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1.5"><Plus className="w-4 h-4" />Add Number</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Add to DNC Registry</DialogTitle></DialogHeader>
                <div className="space-y-4">
                  <div><Label>Phone Number *</Label><Input value={form.phone_number} onChange={e => setForm({...form, phone_number: e.target.value})} placeholder="+1 (555) 123-4567" /></div>
                  <div><Label>Reason</Label>
                    <Select value={form.reason} onValueChange={v => setForm({...form, reason: v})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="customer_request">Customer Request</SelectItem>
                        <SelectItem value="federal_dnc">Federal DNC</SelectItem>
                        <SelectItem value="state_dnc">State DNC</SelectItem>
                        <SelectItem value="internal_policy">Internal Policy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div><Label>Notes</Label><Input value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} /></div>
                  <Button className="w-full" onClick={() => createMut.mutate(form)} disabled={!form.phone_number}>Add to DNC</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-xl flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-red-500 mt-0.5 flex-shrink-0" />
        <div>
          <p className="font-semibold text-sm text-red-600">FCC DNC Compliance</p>
          <p className="text-xs text-muted-foreground mt-1">Numbers on this list are automatically excluded from all AI calling campaigns. Per FCC regulations, DNC requests must be honored within 30 days and maintained for at least 5 years.</p>
        </div>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search phone numbers..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Phone Number</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead>Date Added</TableHead>
              <TableHead>Notes</TableHead>
              <TableHead className="w-16">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">No DNC entries</TableCell></TableRow>
            ) : filtered.map(entry => (
              <TableRow key={entry.id}>
                <TableCell className="font-mono text-sm flex items-center gap-2"><PhoneOff className="w-3.5 h-3.5 text-red-500" />{entry.phone_number}</TableCell>
                <TableCell><Badge className={reasonColors[entry.reason]}>{reasonLabels[entry.reason]}</Badge></TableCell>
                <TableCell className="text-sm text-muted-foreground">{entry.created_date ? format(new Date(entry.created_date), 'MMM d, yyyy') : ''}</TableCell>
                <TableCell className="text-sm">{entry.notes}</TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => deleteMut.mutate(entry)}><Trash2 className="w-3.5 h-3.5 text-destructive" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}