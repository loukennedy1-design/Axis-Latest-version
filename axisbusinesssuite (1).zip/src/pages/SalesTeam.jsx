import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ShieldAlert, ShieldCheck, TrendingUp, Plus, Trophy, DollarSign, Loader2, BarChart3,
  Users, Phone, Calendar, Target, Star, Clock, FileText, AlertCircle, Mail
} from 'lucide-react';
import { toast } from 'sonner';
import RepCard from '@/components/sales/RepCard';
import RepFormDialog from '@/components/sales/RepFormDialog';
import TimeOffManager from '@/components/hr/TimeOffManager';
import PerformanceReviews from '@/components/hr/PerformanceReviews';
import PayrollTracker from '@/components/hr/PayrollTracker';
import HRDocuments from '@/components/hr/HRDocuments';

const ROLE_COLORS = {
  manager: 'bg-purple-500/10 text-purple-600 border-purple-500/20',
  senior_rep: 'bg-blue-500/10 text-blue-600 border-blue-500/20',
  rep: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20',
  sdr: 'bg-amber-500/10 text-amber-600 border-amber-500/20',
};

const emptyRep = {
  name: '', email: '', phone: '', role: 'rep', status: 'active',
  hire_date: '', territory: '',
  target_calls_per_day: 50, target_appointments_per_week: 10,
  target_revenue_per_month: 10000,
  pay_type: 'salary_plus_commission', base_salary: 0, hourly_rate: 0,
  commission_rate: 0.2, commission_type: 'revenue_share', commission_per_deal: 0,
  draw_amount: 0, bonus_target: 0, ote: 0, quota_monthly: 0,
  benefits: '[]', notes: '', zoom_user_id: '', tracking_code: '',
};

const generateTrackingCode = (name) => {
  const base = name ? name.replace(/\s+/g, '').toUpperCase().slice(0, 4) : 'REP';
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `${base}-${rand}`;
};

// Map SalesRep role to HR job title
const ROLE_TO_TITLE = {
  manager: 'Sales Manager',
  senior_rep: 'Account Executive (AE)',
  rep: 'Account Executive (AE)',
  sdr: 'Sales Development Rep (SDR)',
};

export default function SalesTeam() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editRep, setEditRep] = useState(null);
  const [form, setForm] = useState(emptyRep);
  const [tab, setTab] = useState('overview');
  const [invitingAll, setInvitingAll] = useState(false);
  const { user, dataOwnerEmail } = useCurrentUser();
  const subscriberEmail = user?.account_owner_email || user?.email;
  const qc = useQueryClient();

  // Subscribe to real-time updates across all entities
  React.useEffect(() => {
    const unsubscribeSalesRep = base44.entities.SalesRep.subscribe((event) => {
      if (['create', 'update', 'delete'].includes(event.type)) {
        qc.invalidateQueries({ queryKey: ['sales-reps', 'employees', 'users'] });
      }
    });
    const unsubscribeEmployee = base44.entities.Employee.subscribe((event) => {
      if (['create', 'update', 'delete'].includes(event.type)) {
        qc.invalidateQueries({ queryKey: ['employees', 'sales-reps', 'users'] });
      }
    });
    return () => {
      unsubscribeSalesRep();
      unsubscribeEmployee();
    };
  }, [qc]);

  // Sales reps
  const { data: allReps = [], isLoading } = useQuery({
    queryKey: ['sales-reps'],
    queryFn: () => base44.entities.SalesRep.list('-created_date'),
  });
  // Call-team tab: limit to reps within the subscriber's account (not other tenants).
  const reps = allReps.filter(r => !subscriberEmail || r.owner === subscriberEmail || r.owner === user?.email);

  // HR Employees (all) — we'll filter to sales dept for HR sub-tabs
  const { data: allEmployees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list('-hire_date'),
  });
  const salesEmployees = allEmployees.filter(e => e.department === 'sales');

  // Calls & appointments for performance tracking
  const { data: calls = [] } = useQuery({
    queryKey: ['calls'],
    queryFn: () => base44.entities.CallLog.list('-created_date', 500),
  });
  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => base44.entities.Appointment.list(),
  });

  // Commission data
  const { data: referrals = [] } = useQuery({
    queryKey: ['rep-referrals'],
    queryFn: () => base44.entities.RepReferral.list('-created_date', 200),
  });
  const { data: commissions = [] } = useQuery({
    queryKey: ['rep-commissions'],
    queryFn: () => base44.entities.RepCommission.list('-created_date', 100),
  });

  // HR sub-tab counts for badges
  const { data: timeOff = [] } = useQuery({
    queryKey: ['time-off'],
    queryFn: () => base44.entities.TimeOffRequest.list(),
  });
  const { data: hrDocs = [] } = useQuery({
    queryKey: ['hr-docs'],
    queryFn: () => base44.entities.HRDocument.list(),
  });
  const pendingTimeOff = timeOff.filter(t => t.status === 'pending' && salesEmployees.some(e => e.id === t.employee_id)).length;
  const pendingDocs = hrDocs.filter(d => d.status === 'pending_signature' && salesEmployees.some(e => e.id === d.employee_id)).length;

  // Mutations for SalesRep
  const createRepMut = useMutation({
    mutationFn: async (data) => {
      const res = await base44.functions.invoke('createRecord', { entity: 'SalesRep', data });
      if (res.data?.error) throw new Error(res.data.error);
      return res.data?.record;
    },
    onSuccess: async (rep) => {
      qc.invalidateQueries({ queryKey: ['sales-reps', 'employees', 'users'] });
      // Also create an Employee record so HR data works
      await syncRepToEmployee(rep, null);
      setDialogOpen(false);
      toast.success('Rep added — synced to all teams');
    },
  });
  const updateRepMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.SalesRep.update(id, data),
    onSuccess: async (rep, vars) => {
      qc.invalidateQueries({ queryKey: ['sales-reps', 'employees', 'users'] });
      // Find existing employee by email and sync
      const existing = allEmployees.find(e => e.email === vars.data.email);
      await syncRepToEmployee(vars.data, existing?.id || null);
      setDialogOpen(false);
      toast.success('Rep updated — synced to all teams');
    },
  });
  const deleteRepMut = useMutation({
    mutationFn: (id) => base44.entities.SalesRep.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['sales-reps', 'employees', 'users'] }); toast.success('Rep removed'); },
  });

  // Sync a SalesRep to the Employee entity so all HR features work
  const syncRepToEmployee = async (repData, existingEmployeeId) => {
    const [firstName, ...rest] = (repData.name || '').split(' ');
    const lastName = rest.join(' ') || '';
    const salaryType = repData.pay_type === 'hourly' ? 'hourly' : repData.pay_type === 'commission_only' ? 'commission' : 'salary';
    const salaryValue = repData.pay_type === 'hourly' ? repData.hourly_rate : repData.base_salary;

    const empData = {
      first_name: firstName,
      last_name: lastName,
      email: repData.email,
      phone: repData.phone || '',
      job_title: ROLE_TO_TITLE[repData.role] || 'Account Executive (AE)',
      department: 'sales',
      employment_type: 'full_time',
      status: repData.status === 'terminated' ? 'terminated' : repData.status === 'on_leave' ? 'on_leave' : repData.status === 'probation' ? 'probation' : 'active',
      hire_date: repData.hire_date || '',
      salary: salaryValue || 0,
      salary_type: salaryType,
      pay_frequency: 'biweekly',
      territory: repData.territory || '',
      pto_balance: 15,
      sick_balance: 10,
      notes: repData.notes || '',
      manager_email: '',
      address: '',
      emergency_contact_name: '',
      emergency_contact_phone: '',
      owner: subscriberEmail,
    };

    if (existingEmployeeId) {
      await base44.entities.Employee.update(existingEmployeeId, empData);
    } else {
      // Check if employee already exists by email
      const existing = allEmployees.find(e => e.email === repData.email);
      if (existing) {
        await base44.entities.Employee.update(existing.id, empData);
      } else {
        await base44.functions.invoke('createRecord', { entity: 'Employee', data: empData });
      }
    }
    qc.invalidateQueries({ queryKey: ['employees'] });
  };

  const appUrl = typeof window !== 'undefined' ? window.location.origin : '';

  const openNew = () => { setEditRep(null); setForm(emptyRep); setDialogOpen(true); };
  const openEdit = (rep) => { setEditRep(rep); setForm({ ...emptyRep, ...rep }); setDialogOpen(true); };
  const handleSave = () => {
    const trackingCode = form.tracking_code || generateTrackingCode(form.name);
    if (editRep) updateRepMut.mutate({ id: editRep.id, data: { ...form, tracking_code: trackingCode } });
    else createRepMut.mutate({ ...form, tracking_code: trackingCode, owner: subscriberEmail });
  };

  const copyTrackingLink = (code) => {
    navigator.clipboard.writeText(`${appUrl}/pricing?ref=${code}`);
    toast.success('Referral link copied!');
  };

  // One-click: ensure every rep on this account has a portal login (creates a
  // platform account + sends a password-setup email for any rep missing one).
  const handleInviteAll = async () => {
    setInvitingAll(true);
    try {
      const res = await base44.functions.invoke('verifyRepPortalAccess', { action: 'bulk_invite_reps' });
      const d = res.data || {};
      if (d.error) throw new Error(d.error);
      if (d.total === 0) {
        toast.info('No reps to invite yet.');
      } else if (d.invited > 0) {
        toast.success(`Portal invites sent to ${d.invited} rep${d.invited === 1 ? '' : 's'}. ${d.already} already had access.`);
      } else {
        toast.success(`All ${d.already} rep${d.already === 1 ? '' : 's'} already have portal access.`);
      }
      qc.invalidateQueries({ queryKey: ['sales-reps'] });
    } catch (e) {
      toast.error('Could not invite reps: ' + (e.message || 'unknown error'));
    } finally {
      setInvitingAll(false);
    }
  };

  // Aggregated KPIs
  const activeReps = reps.filter(r => r.status === 'active');
  const totalPayroll = reps.reduce((s, r) => {
    if (r.pay_type === 'salary' || r.pay_type === 'salary_plus_commission') return s + (r.base_salary || 0);
    return s;
  }, 0);
  const totalOTE = reps.reduce((s, r) => s + (r.ote || 0), 0);
  const totalEarned = commissions.reduce((s, c) => s + (c.net_commission || 0), 0);

  const glassKpis = [
    { label: 'Active Reps', value: activeReps.length, icon: Users, color: 'text-primary', bg: 'from-primary/10 to-primary/5', border: 'border-primary/20' },
    { label: 'Total Calls', value: calls.length.toLocaleString(), icon: Phone, color: 'text-blue-400', bg: 'from-blue-500/10 to-blue-600/5', border: 'border-blue-500/20' },
    { label: 'Appointments', value: appointments.length, icon: Calendar, color: 'text-emerald-400', bg: 'from-emerald-500/10 to-emerald-600/5', border: 'border-emerald-500/20' },
    { label: 'Monthly Payroll', value: `$${(totalPayroll / 1000).toFixed(0)}k`, icon: DollarSign, color: 'text-amber-400', bg: 'from-amber-500/10 to-amber-600/5', border: 'border-amber-500/20' },
    { label: 'Team OTE (Annual)', value: `$${(totalOTE / 1000).toFixed(0)}k`, icon: TrendingUp, color: 'text-purple-400', bg: 'from-purple-500/10 to-purple-600/5', border: 'border-purple-500/20' },
    { label: 'Commission Earned', value: `$${totalEarned.toLocaleString()}`, icon: Star, color: 'text-rose-400', bg: 'from-rose-500/10 to-rose-600/5', border: 'border-rose-500/20' },
  ];

  // Leaderboard
  const leaderboard = reps.map(rep => {
    const repCalls = calls.filter(c => c.called_by === rep.name || c.owner === rep.email).length;
    const repAppts = appointments.filter(a => a.assigned_to === rep.email).length;
    const repRefs = referrals.filter(r => r.rep_id === rep.id || r.tracking_code === rep.tracking_code).length;
    const earned = commissions.filter(c => c.rep_id === rep.id).reduce((s, c) => s + (c.net_commission || 0), 0);
    const score = repCalls * 1 + repAppts * 10 + repRefs * 15;
    const callPct = Math.min(100, Math.round((repCalls / ((rep.target_calls_per_day || 50) * 30)) * 100));
    const apptPct = Math.min(100, Math.round((repAppts / ((rep.target_appointments_per_week || 10) * 4)) * 100));
    return { ...rep, repCalls, repAppts, repRefs, earned, score, callPct, apptPct };
  }).sort((a, b) => b.score - a.score);

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-amber-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Sales Team</h1>
              <p className="text-muted-foreground text-xs">Performance, compensation, HR, payroll & referral attribution</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {pendingTimeOff > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs font-semibold text-amber-400">
                <AlertCircle className="w-3.5 h-3.5" />{pendingTimeOff} PTO pending
              </div>
            )}
            {pendingDocs > 0 && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-purple-500/10 border border-purple-500/20 text-xs font-semibold text-purple-400">
                <FileText className="w-3.5 h-3.5" />{pendingDocs} docs unsigned
              </div>
            )}
            <Button onClick={handleInviteAll} variant="outline" className="gap-1.5" disabled={invitingAll || reps.length === 0}>
              {invitingAll ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
              Invite All to Portal
            </Button>
            <Button onClick={openNew} className="gap-1.5"><Plus className="w-4 h-4" />Add Rep</Button>
          </div>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {glassKpis.map(({ label, value, icon: Icon, color, bg, border }) => (
          <div key={label} className={`relative overflow-hidden rounded-2xl border bg-gradient-to-br p-4 ${bg} ${border}`}>
            <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-background/40 mb-2">
              <Icon className={`w-3.5 h-3.5 ${color}`} />
            </div>
            <p className={`text-xl font-bold leading-none ${color}`}>{value}</p>
            <p className="text-[10px] text-muted-foreground mt-1">{label}</p>
          </div>
        ))}
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="overview" className="gap-1.5"><Users className="w-3.5 h-3.5" />Team Overview</TabsTrigger>
          <TabsTrigger value="leaderboard" className="gap-1.5"><Trophy className="w-3.5 h-3.5" />Leaderboard</TabsTrigger>
          <TabsTrigger value="targets" className="gap-1.5"><Target className="w-3.5 h-3.5" />Targets</TabsTrigger>
          <TabsTrigger value="compensation" className="gap-1.5"><DollarSign className="w-3.5 h-3.5" />Compensation</TabsTrigger>
          <TabsTrigger value="timeoff" className="gap-1.5 relative">
            <Clock className="w-3.5 h-3.5" />Time Off
            {pendingTimeOff > 0 && <span className="ml-1 text-[10px] bg-amber-500 text-white rounded-full px-1.5 font-bold">{pendingTimeOff}</span>}
          </TabsTrigger>
          <TabsTrigger value="performance" className="gap-1.5"><Star className="w-3.5 h-3.5" />Performance</TabsTrigger>
          <TabsTrigger value="payroll" className="gap-1.5"><DollarSign className="w-3.5 h-3.5" />Payroll</TabsTrigger>
          <TabsTrigger value="documents" className="gap-1.5 relative">
            <FileText className="w-3.5 h-3.5" />Documents
            {pendingDocs > 0 && <span className="ml-1 text-[10px] bg-amber-500 text-white rounded-full px-1.5 font-bold">{pendingDocs}</span>}
          </TabsTrigger>
          <TabsTrigger value="commissions" className="gap-1.5"><BarChart3 className="w-3.5 h-3.5" />Commissions</TabsTrigger>
        </TabsList>

        {/* OVERVIEW */}
        <TabsContent value="overview" className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
          ) : reps.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">No team members yet</p>
                <p className="text-sm text-muted-foreground mb-4">Add your sales reps — they'll automatically appear in HR as employees</p>
                <Button onClick={openNew}><Plus className="w-4 h-4 mr-2" />Add First Rep</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {reps.map(rep => (
                <RepCard
                  key={rep.id} rep={rep} calls={calls} appointments={appointments} referrals={referrals}
                  onEdit={openEdit} onDelete={(id) => deleteRepMut.mutate(id)} onCopyLink={copyTrackingLink}
                />
              ))}
            </div>
          )}
        </TabsContent>

        {/* LEADERBOARD */}
        <TabsContent value="leaderboard" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-500" />Team Leaderboard</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead className="w-10">#</TableHead>
                    <TableHead>Rep</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Calls</TableHead>
                    <TableHead>Appts</TableHead>
                    <TableHead>Referrals</TableHead>
                    <TableHead>Commission Earned</TableHead>
                    <TableHead>Call %</TableHead>
                    <TableHead>Appt %</TableHead>
                    <TableHead>Score</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {leaderboard.map((rep, i) => (
                    <TableRow key={rep.id} className={i === 0 ? 'bg-amber-500/5' : ''}>
                      <TableCell>
                        <span className={`text-sm font-bold ${i === 0 ? 'text-amber-500' : i === 1 ? 'text-slate-400' : i === 2 ? 'text-amber-700' : 'text-muted-foreground'}`}>
                          {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{rep.name}</TableCell>
                      <TableCell><Badge variant="outline" className={`capitalize text-[10px] ${ROLE_COLORS[rep.role] || ''}`}>{rep.role?.replace(/_/g, ' ')}</Badge></TableCell>
                      <TableCell>{rep.repCalls}</TableCell>
                      <TableCell>{rep.repAppts}</TableCell>
                      <TableCell><span className="text-primary font-semibold">{rep.repRefs}</span></TableCell>
                      <TableCell><span className="text-emerald-600 font-semibold">${rep.earned.toLocaleString()}</span></TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Progress value={rep.callPct} className="h-1.5 w-14" />
                          <span className="text-xs font-medium">{rep.callPct}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <Progress value={rep.apptPct} className="h-1.5 w-14" />
                          <span className="text-xs font-medium">{rep.apptPct}%</span>
                        </div>
                      </TableCell>
                      <TableCell><span className="font-bold text-primary">{rep.score.toLocaleString()}</span></TableCell>
                    </TableRow>
                  ))}
                  {leaderboard.length === 0 && (
                    <TableRow><TableCell colSpan={10} className="text-center py-8 text-muted-foreground">Add reps to see the leaderboard</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* TARGETS */}
        <TabsContent value="targets" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><Target className="w-4 h-4" />Individual Targets vs. Actuals</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-5">
                {reps.map(rep => {
                  const repCalls = calls.filter(c => c.called_by === rep.name || c.owner === rep.email).length;
                  const repAppts = appointments.filter(a => a.assigned_to === rep.email).length;
                  const repRefs = referrals.filter(r => r.rep_id === rep.id || r.tracking_code === rep.tracking_code).length;
                  const callPct = Math.min(100, Math.round((repCalls / ((rep.target_calls_per_day || 50) * 30)) * 100));
                  const apptPct = Math.min(100, Math.round((repAppts / ((rep.target_appointments_per_week || 10) * 4)) * 100));
                  return (
                    <div key={rep.id} className="p-4 border border-border rounded-xl">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">{rep.name.charAt(0)}</div>
                          <div>
                            <p className="font-semibold text-sm">{rep.name}</p>
                            <div className="flex gap-1.5">
                              <Badge variant="outline" className={`capitalize text-[10px] ${ROLE_COLORS[rep.role]}`}>{rep.role?.replace(/_/g, ' ')}</Badge>
                              {rep.territory && <Badge variant="outline" className="text-[10px]">{rep.territory}</Badge>}
                            </div>
                          </div>
                        </div>
                        <div className="text-right text-xs">
                          <p className="text-muted-foreground">Monthly Quota</p>
                          <p className="font-bold text-emerald-500">${(rep.quota_monthly || rep.target_revenue_per_month || 0).toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Calls ({repCalls} / {(rep.target_calls_per_day || 50) * 30})</span>
                            <span className={callPct >= 80 ? 'text-emerald-500 font-semibold' : callPct >= 50 ? 'text-amber-500 font-semibold' : 'text-red-400 font-semibold'}>{callPct}%</span>
                          </div>
                          <Progress value={callPct} className="h-2" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Appointments ({repAppts} / {(rep.target_appointments_per_week || 10) * 4})</span>
                            <span className={apptPct >= 80 ? 'text-emerald-500 font-semibold' : apptPct >= 50 ? 'text-amber-500 font-semibold' : 'text-red-400 font-semibold'}>{apptPct}%</span>
                          </div>
                          <Progress value={apptPct} className="h-2" />
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs">
                            <span>Referrals this month</span>
                            <span className="font-semibold text-primary">{repRefs}</span>
                          </div>
                          <Progress value={Math.min(100, repRefs * 10)} className="h-2" />
                        </div>
                      </div>
                    </div>
                  );
                })}
                {reps.length === 0 && <p className="text-center py-8 text-muted-foreground">No reps to display</p>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* COMPENSATION */}
        <TabsContent value="compensation" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><DollarSign className="w-4 h-4 text-emerald-500" />Team Compensation Overview</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Rep</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Pay Type</TableHead>
                    <TableHead>Base / Rate</TableHead>
                    <TableHead>Commission %</TableHead>
                    <TableHead>Draw</TableHead>
                    <TableHead>Bonus Target</TableHead>
                    <TableHead>OTE (Annual)</TableHead>
                    <TableHead>Benefits</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reps.length === 0 && (
                    <TableRow><TableCell colSpan={9} className="text-center py-8 text-muted-foreground">No reps added yet</TableCell></TableRow>
                  )}
                  {reps.map(r => {
                    let payDisplay = '—';
                    if (r.pay_type === 'hourly') payDisplay = `$${r.hourly_rate || 0}/hr`;
                    else if (r.base_salary) payDisplay = `$${(r.base_salary || 0).toLocaleString()}/mo`;
                    else if (r.pay_type === 'commission_only') payDisplay = 'Commission Only';
                    const benefits = (() => { try { return JSON.parse(r.benefits || '[]'); } catch { return []; } })();
                    return (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{r.name}</TableCell>
                        <TableCell><Badge variant="outline" className={`capitalize text-[10px] ${ROLE_COLORS[r.role] || ''}`}>{r.role?.replace(/_/g, ' ')}</Badge></TableCell>
                        <TableCell className="text-xs capitalize">{r.pay_type?.replace(/_/g, ' ') || '—'}</TableCell>
                        <TableCell className="font-semibold text-emerald-600">{payDisplay}</TableCell>
                        <TableCell><span className="font-bold">{Math.round((r.commission_rate || 0.2) * 100)}%</span></TableCell>
                        <TableCell>{r.draw_amount ? `$${(r.draw_amount).toLocaleString()}` : '—'}</TableCell>
                        <TableCell>{r.bonus_target ? `$${(r.bonus_target).toLocaleString()}` : '—'}</TableCell>
                        <TableCell><span className="font-bold text-blue-400">{r.ote ? `$${(r.ote / 1000).toFixed(0)}k` : '—'}</span></TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {benefits.slice(0, 2).map(b => <Badge key={b} variant="outline" className="text-[9px]">{b}</Badge>)}
                            {benefits.length > 2 && <Badge variant="outline" className="text-[9px]">+{benefits.length - 2}</Badge>}
                            {benefits.length === 0 && <span className="text-muted-foreground text-xs">—</span>}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {reps.length > 0 && (
                <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
                  {[
                    { label: 'Total Monthly Payroll', value: `$${totalPayroll.toLocaleString()}`, color: 'text-emerald-500' },
                    { label: 'Team Annual OTE', value: `$${(totalOTE / 1000).toFixed(0)}k`, color: 'text-blue-400' },
                    { label: 'Commissions Earned', value: `$${totalEarned.toLocaleString()}`, color: 'text-primary' },
                    { label: 'Avg Commission Rate', value: `${reps.length ? Math.round((reps.reduce((s, r) => s + (r.commission_rate || 0.2), 0) / reps.length) * 100) : 0}%`, color: 'text-amber-400' },
                  ].map(({ label, value, color }) => (
                    <div key={label} className="p-3 rounded-lg bg-muted/40 border border-border text-center">
                      <p className="text-xs text-muted-foreground">{label}</p>
                      <p className={`font-bold ${color}`}>{value}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* HR TABS — uses same components as HR page, filtered to sales employees */}
        <TabsContent value="timeoff" className="mt-4">
          {salesEmployees.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-12 text-center text-muted-foreground">Add sales reps first — they'll appear here as employees once added.</CardContent></Card>
          ) : (
            <TimeOffManager employees={salesEmployees} />
          )}
        </TabsContent>

        <TabsContent value="performance" className="mt-4">
          {salesEmployees.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-12 text-center text-muted-foreground">Add sales reps first — they'll appear here as employees once added.</CardContent></Card>
          ) : (
            <PerformanceReviews employees={salesEmployees} />
          )}
        </TabsContent>

        <TabsContent value="payroll" className="mt-4">
          {salesEmployees.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-12 text-center text-muted-foreground">Add sales reps first — they'll appear here as employees once added.</CardContent></Card>
          ) : (
            <PayrollTracker employees={salesEmployees} />
          )}
        </TabsContent>

        <TabsContent value="documents" className="mt-4">
          {salesEmployees.length === 0 ? (
            <Card className="border-dashed"><CardContent className="py-12 text-center text-muted-foreground">Add sales reps first — they'll appear here as employees once added.</CardContent></Card>
          ) : (
            <HRDocuments employees={salesEmployees} />
          )}
        </TabsContent>

        {/* COMMISSIONS & FRAUD */}
        <TabsContent value="commissions" className="mt-4 space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><DollarSign className="w-4 h-4 text-emerald-500" />Commission Payouts — Current Period</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Rep</TableHead><TableHead>Period</TableHead><TableHead>Referrals</TableHead>
                    <TableHead>Flagged</TableHead><TableHead>Revenue Referred</TableHead>
                    <TableHead>Gross</TableHead><TableHead>Net Commission</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {commissions.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No commission records yet — auto-calculated when referral signups occur.</TableCell></TableRow>
                  )}
                  {commissions.map(c => (
                    <TableRow key={c.id} className={c.flagged_referrals > 0 ? 'bg-red-500/5' : ''}>
                      <TableCell className="font-medium">{c.rep_name}</TableCell>
                      <TableCell className="font-mono text-xs">{c.period}</TableCell>
                      <TableCell>{c.total_referrals}</TableCell>
                      <TableCell>
                        {c.flagged_referrals > 0
                          ? <span className="text-red-500 font-semibold flex items-center gap-1"><ShieldAlert className="w-3 h-3" />{c.flagged_referrals}</span>
                          : <span className="text-emerald-600 flex items-center gap-1"><ShieldCheck className="w-3 h-3" />0</span>}
                      </TableCell>
                      <TableCell>${(c.total_revenue_referred || 0).toLocaleString()}</TableCell>
                      <TableCell>${(c.gross_commission || 0).toLocaleString()}</TableCell>
                      <TableCell className="font-bold text-emerald-600">${(c.net_commission || 0).toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          c.status === 'approved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px]' :
                          c.status === 'paid' ? 'bg-blue-500/10 text-blue-600 border-blue-500/20 text-[10px]' :
                          c.status === 'pending_review' ? 'bg-red-500/10 text-red-600 border-red-500/20 text-[10px]' : 'text-[10px]'
                        }>{c.status?.replace(/_/g, ' ')}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><ShieldAlert className="w-4 h-4 text-red-500" />Fraud-Flagged Referrals</CardTitle></CardHeader>
            <CardContent>
              {referrals.filter(r => r.fraud_flagged).length === 0 ? (
                <p className="text-center py-6 text-muted-foreground flex items-center justify-center gap-2"><ShieldCheck className="w-4 h-4 text-emerald-500" />No fraud flags detected</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow className="bg-muted/50">
                      <TableHead>Rep</TableHead><TableHead>Subscriber</TableHead><TableHead>Plan</TableHead>
                      <TableHead>IP</TableHead><TableHead>Fraud Reasons</TableHead><TableHead>Commission</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {referrals.filter(r => r.fraud_flagged).map(r => (
                      <TableRow key={r.id} className="bg-red-500/5">
                        <TableCell className="font-medium">{r.rep_name}</TableCell>
                        <TableCell className="text-xs">{r.subscriber_email}</TableCell>
                        <TableCell><Badge variant="outline" className="text-[10px]">{r.plan_key}</Badge></TableCell>
                        <TableCell className="font-mono text-xs">{r.signup_ip}</TableCell>
                        <TableCell className="text-xs text-red-500 max-w-xs">
                          {(() => { try { return JSON.parse(r.fraud_reasons || '[]').join('; '); } catch { return r.fraud_reasons; } })()}
                        </TableCell>
                        <TableCell><span className="text-red-500 font-semibold">Withheld</span></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base flex items-center gap-2"><BarChart3 className="w-4 h-4" />All Referral Activity</CardTitle></CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Rep</TableHead><TableHead>Subscriber</TableHead><TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead><TableHead>IP</TableHead><TableHead>Date</TableHead>
                    <TableHead>Commission</TableHead><TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {referrals.length === 0 && (
                    <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No referrals tracked yet</TableCell></TableRow>
                  )}
                  {referrals.map(r => (
                    <TableRow key={r.id} className={r.fraud_flagged ? 'bg-red-500/5' : ''}>
                      <TableCell className="font-medium">{r.rep_name}</TableCell>
                      <TableCell className="text-xs">{r.subscriber_email}</TableCell>
                      <TableCell><Badge variant="outline" className="text-[10px]">{r.plan_key}</Badge></TableCell>
                      <TableCell>${r.plan_amount || 0}</TableCell>
                      <TableCell className="font-mono text-xs">{r.signup_ip}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{r.signup_timestamp ? new Date(r.signup_timestamp).toLocaleDateString() : '—'}</TableCell>
                      <TableCell className={r.fraud_flagged ? 'text-red-500 font-semibold' : 'text-emerald-600 font-semibold'}>${r.commission_amount || 0}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={
                          r.commission_status === 'flagged' ? 'bg-red-500/10 text-red-600 border-red-500/20 text-[10px]' :
                          r.commission_status === 'approved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 text-[10px]' : 'text-[10px]'
                        }>{r.commission_status}</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <RepFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        form={form}
        setForm={setForm}
        editRep={editRep}
        onSave={handleSave}
        saving={createRepMut.isPending || updateRepMut.isPending}
        appUrl={appUrl}
      />
    </div>
  );
}