import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, ClipboardList, Layers, ArrowLeftRight, QrCode, Warehouse, ShoppingCart, Factory, Truck, Upload, Store } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import InventoryItemsPanel from '@/components/inventory/InventoryItemsPanel';
import BulkInventoryUpload from '@/components/inventory/BulkInventoryUpload';
import CountSessionPanel from '@/components/inventory/CountSessionPanel';
import ProductBundlePanel from '@/components/inventory/ProductBundlePanel';
import StockMovementPanel from '@/components/inventory/StockMovementPanel';
import QRCodePanel from '@/components/inventory/QRCodePanel';
import PurchaseOrderPanel from '@/components/inventory/PurchaseOrderPanel';
import ProductionPipelinePanel from '@/components/inventory/ProductionPipelinePanel';
import InventoryKPIBar from '@/components/inventory/InventoryKPIBar';
import ManualSalePanel from '@/components/inventory/ManualSalePanel';
import LogisticsCenter from '@/pages/Logistics';

export default function Inventory() {
  const [tab, setTab] = useState('items');

  const { data: items = [] } = useQuery({
    queryKey: ['inventory-items'],
    queryFn: () => base44.entities.InventoryItem.list('-created_date', 200)
  });
  const { data: purchaseOrders = [] } = useQuery({
    queryKey: ['purchase-orders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date', 200)
  });
  const { data: productionTickets = [] } = useQuery({
    queryKey: ['production-tickets-pipeline'],
    queryFn: () => base44.entities.ProductionTicket.list('-created_date', 100)
  });

  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-emerald-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Warehouse className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">Inventory & Storefront</h1>
            <p className="text-muted-foreground text-xs">Stock items, production pipeline, purchase orders, bundles, movements & QR storefront</p>
          </div>
        </div>
      </div>

      <InventoryKPIBar
        items={items}
        purchaseOrders={purchaseOrders}
        productionTickets={productionTickets}
        onLowStockClick={() => setTab('items')}
        onOpenPOsClick={() => setTab('po')}
      />

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap h-auto gap-1">
          <TabsTrigger value="items" className="gap-1.5"><Package className="w-3.5 h-3.5" />Stock Items</TabsTrigger>
          <TabsTrigger value="pos" className="gap-1.5"><Store className="w-3.5 h-3.5" />Point of Sale</TabsTrigger>
          <TabsTrigger value="bulk-upload" className="gap-1.5"><Upload className="w-3.5 h-3.5" />Bulk Upload</TabsTrigger>
          <TabsTrigger value="pipeline" className="gap-1.5"><Factory className="w-3.5 h-3.5" />Production Pipeline</TabsTrigger>
          <TabsTrigger value="po" className="gap-1.5"><ShoppingCart className="w-3.5 h-3.5" />Purchase Orders</TabsTrigger>
          <TabsTrigger value="counts" className="gap-1.5"><ClipboardList className="w-3.5 h-3.5" />Count Sessions</TabsTrigger>
          <TabsTrigger value="bundles" className="gap-1.5"><Layers className="w-3.5 h-3.5" />Bundles</TabsTrigger>
          <TabsTrigger value="movements" className="gap-1.5"><ArrowLeftRight className="w-3.5 h-3.5" />Movements</TabsTrigger>
          <TabsTrigger value="qr" className="gap-1.5"><QrCode className="w-3.5 h-3.5" />QR & Storefront</TabsTrigger>
          <TabsTrigger value="logistics" className="gap-1.5"><Truck className="w-3.5 h-3.5" />Logistics Center</TabsTrigger>
        </TabsList>
        <TabsContent value="items" className="mt-4"><InventoryItemsPanel /></TabsContent>
        <TabsContent value="pos" className="mt-4"><ManualSalePanel /></TabsContent>
        <TabsContent value="bulk-upload" className="mt-4"><BulkInventoryUpload /></TabsContent>
        <TabsContent value="pipeline" className="mt-4"><ProductionPipelinePanel /></TabsContent>
        <TabsContent value="po" className="mt-4"><PurchaseOrderPanel /></TabsContent>
        <TabsContent value="counts" className="mt-4"><CountSessionPanel /></TabsContent>
        <TabsContent value="bundles" className="mt-4"><ProductBundlePanel /></TabsContent>
        <TabsContent value="movements" className="mt-4"><StockMovementPanel /></TabsContent>
        <TabsContent value="qr" className="mt-4"><QRCodePanel /></TabsContent>
        <TabsContent value="logistics" className="mt-4"><LogisticsCenter /></TabsContent>
      </Tabs>
    </div>
  );
}