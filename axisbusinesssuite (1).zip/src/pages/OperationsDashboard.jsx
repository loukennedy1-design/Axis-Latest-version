import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Boxes, ArrowLeft, Factory, Truck, Brain, Loader2 } from 'lucide-react';
import { format, subMonths, startOfMonth, endOfMonth, isWithinInterval } from 'date-fns';
import {
  BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from 'recharts';
import OpsKpiBar from '@/components/operations/OpsKpiBar';
import OpsReorderPanel from '@/components/operations/OpsReorderPanel';

const STAGE_COLORS = ['#60A5FA', '#A78BFA', '#34D399', '#F5C842', '#FB923C', '#F87171', '#38BDF8'];
const STATUS_COLORS = ['#60A5FA', '#A78BFA', '#34D399', '#F5C842', '#FB923C', '#F87171', '#64748B'];
const CAT_COLORS = ['#F5C842', '#60A5FA', '#34D399', '#A78BFA', '#F87171', '#FB923C', '#38BDF8'];

const STAGE_LABELS = {
  po_procurement: 'PO Procurement', materials_received: 'Materials', build_assembly: 'Build',
  qc: 'QC', packaging: 'Packaging', fulfillment: 'Fulfillment', delivered: 'Delivered'
};

export default function OperationsDashboard() {
  const { data: items = [], isLoading: itemsLoading } = useQuery({
    queryKey: ['inventory-items'],
    queryFn: () => base44.entities.InventoryItem.list('-created_date', 500)
  });
  const { data: purchaseOrders = [], isLoading: poLoading } = useQuery({
    queryKey: ['purchase-orders'],
    queryFn: () => base44.entities.PurchaseOrder.list('-created_date', 500)
  });
  const { data: productionTickets = [], isLoading: prodLoading } = useQuery({
    queryKey: ['production-tickets-pipeline'],
    queryFn: () => base44.entities.ProductionTicket.list('-created_date', 300)
  });
  const { data: shipments = [], isLoading: shipLoading } = useQuery({
    queryKey: ['shipments'],
    queryFn: () => base44.entities.Shipment.list('-created_date', 500)
  });
  const { data: orders = [], isLoading: ordLoading } = useQuery({
    queryKey: ['orders-ops'],
    queryFn: () => base44.entities.Order.list('-created_date', 300)
  });

  const loading = itemsLoading || poLoading || prodLoading || shipLoading || ordLoading;

  // Production pipeline by stage
  const pipelineByStage = useMemo(() => {
    const map = {};
    Object.keys(STAGE_LABELS).forEach(k => { map[k] = 0; });
    productionTickets.forEach(t => {
      const stage = t.current_stage || 'po_procurement';
      if (map[stage] !== undefined) map[stage] += (t.quantity || 1);
    });
    return Object.entries(STAGE_LABELS).map(([k, label]) => ({ stage: label, units: map[k] || 0 }));
  }, [productionTickets]);

  // Shipment status distribution
  const shipmentStatusDist = useMemo(() => {
    const map = {};
    shipments.forEach(s => { const st = s.status || 'pending'; map[st] = (map[st] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));
  }, [shipments]);

  // 6-month shipping volume
  const shipVolume = useMemo(() => {
    const now = new Date();
    return Array.from({ length: 6 }, (_, i) => {
      const m = subMonths(now, 5 - i);
      const s = startOfMonth(m), e = endOfMonth(m);
      const inR = (d) => { if (!d) return false; try { return isWithinInterval(new Date(d), { start: s, end: e }); } catch { return false; } };
      const created = shipments.filter(sh => inR(sh.ship_date || sh.created_date)).length;
      const delivered = shipments.filter(sh => sh.status === 'delivered' && inR(sh.actual_delivery)).length;
      return { month: format(m, 'MMM'), created, delivered };
    });
  }, [shipments]);

  // Inventory value by category
  const invByCategory = useMemo(() => {
    const map = {};
    items.forEach(i => {
      const c = i.category || 'other';
      map[c] = (map[c] || 0) + (i.quantity_on_hand || 0) * (i.unit_cost || 0);
    });
    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 7);
  }, [items]);

  // Production status breakdown
  const prodStatus = useMemo(() => {
    const map = {};
    productionTickets.forEach(t => { const st = t.status || 'backlog'; map[st] = (map[st] || 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value }));
  }, [productionTickets]);

  // AI insight — computed heuristics
  const insight = useMemo(() => {
    const notes = [];
    const lowStock = items.filter(i => (i.quantity_on_hand || 0) <= (i.reorder_threshold || 0) && i.status !== 'discontinued');
    if (lowStock.length > 0) notes.push({ icon: '⚠️', text: `${lowStock.length} item(s) at or below reorder threshold — run Auto-Reorder to draft POs and avoid stockouts.` });
    const stalled = productionTickets.filter(t => t.status === 'waiting_materials' || t.status === 'on_hold');
    if (stalled.length > 0) notes.push({ icon: '🏭', text: `${stalled.length} production ticket(s) stalled on materials or on hold — review supplier ETAs to unblock the pipeline.` });
    const inTransit = shipments.filter(s => s.status === 'in_transit' || s.status === 'out_for_delivery');
    if (inTransit.length > 0) notes.push({ icon: '🚚', text: `${inTransit.length} shipment(s) currently in transit — monitor for on-time delivery.` });
    const backlog = orders.filter(o => o.status !== 'delivered' && o.status !== 'completed' && o.status !== 'cancelled');
    if (backlog.length > 0) notes.push({ icon: '📦', text: `${backlog.length} order(s) in fulfillment backlog — prioritize ready_to_ship items to reduce backlog.` });
    const openPOs = purchaseOrders.filter(po => po.status === 'draft' || po.status === 'sent');
    if (openPOs.length > 0) notes.push({ icon: '🛒', text: `${openPOs.length} purchase order(s) awaiting supplier receipt — follow up to keep production moving.` });
    if (notes.length === 0) notes.push({ icon: '✅', text: 'Operations are flowing smoothly — no critical bottlenecks detected.' });
    return notes;
  }, [items, productionTickets, shipments, orders, purchaseOrders]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[60vh]">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-card to-blue-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center"><Boxes className="w-5 h-5 text-primary" /></div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Operations Command Dashboard</h1>
              <p className="text-muted-foreground text-xs">Unified analytics across inventory, production, logistics & fulfillment — with auto-reorder automation</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Link to="/inventory"><Button variant="outline" size="sm" className="gap-1.5"><Factory className="w-3.5 h-3.5" />Inventory</Button></Link>
            <Link to="/logistics"><Button variant="outline" size="sm" className="gap-1.5"><Truck className="w-3.5 h-3.5" />Logistics</Button></Link>
          </div>
        </div>
      </div>

      <OpsKpiBar items={items} purchaseOrders={purchaseOrders} productionTickets={productionTickets} shipments={shipments} orders={orders} />

      <OpsReorderPanel items={items} purchaseOrders={purchaseOrders} />

      {/* Production Pipeline by Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Factory className="w-4 h-4 text-purple-400" /> Production Pipeline by Stage</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={pipelineByStage}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis dataKey="stage" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" angle={-20} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="units" radius={[4, 4, 0, 0]}>
                  {pipelineByStage.map((_, i) => <Cell key={i} fill={STAGE_COLORS[i % STAGE_COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Truck className="w-4 h-4 text-blue-400" /> Shipment Status Distribution</CardTitle></CardHeader>
          <CardContent>
            {shipmentStatusDist.length === 0 ? (
              <div className="flex items-center justify-center h-[260px] text-sm text-muted-foreground">No shipments yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={shipmentStatusDist} cx="50%" cy="50%" outerRadius={90} dataKey="value" nameKey="name" label={({ name, value }) => `${name}: ${value}`} labelLine={false} fontSize={10}>
                    {shipmentStatusDist.map((_, i) => <Cell key={i} fill={STATUS_COLORS[i % STATUS_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Shipping Volume Trend */}
      <Card>
        <CardHeader><CardTitle className="text-sm">6-Month Shipping Volume</CardTitle></CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={shipVolume}>
              <defs>
                <linearGradient id="createdGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#60A5FA" stopOpacity={0.3} /><stop offset="95%" stopColor="#60A5FA" stopOpacity={0} /></linearGradient>
                <linearGradient id="delivGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#34D399" stopOpacity={0.3} /><stop offset="95%" stopColor="#34D399" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Area type="monotone" dataKey="created" stroke="#60A5FA" fill="url(#createdGrad)" name="Shipped" />
              <Area type="monotone" dataKey="delivered" stroke="#34D399" fill="url(#delivGrad)" name="Delivered" />
            </AreaChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Inventory Value by Category + AI Insight */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-sm">Inventory Value by Category</CardTitle></CardHeader>
          <CardContent>
            {invByCategory.length === 0 ? (
              <div className="flex items-center justify-center h-[240px] text-sm text-muted-foreground">No inventory value tracked yet</div>
            ) : (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={invByCategory} cx="50%" cy="50%" outerRadius={85} dataKey="value" nameKey="name" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={10}>
                    {invByCategory.map((_, i) => <Cell key={i} fill={CAT_COLORS[i % CAT_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => `$${(v || 0).toLocaleString()}`} contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Brain className="w-4 h-4 text-primary" /> Operations AI Insight</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {insight.map((n, i) => (
              <div key={i} className="flex items-start gap-2.5 rounded-xl border border-border bg-muted/30 p-3">
                <span className="text-lg leading-none">{n.icon}</span>
                <p className="text-sm text-foreground/90 leading-relaxed">{n.text}</p>
              </div>
            ))}
            <div className="pt-2">
              <p className="text-[11px] text-muted-foreground mb-1.5 font-semibold uppercase tracking-wider">Production Status Mix</p>
              <div className="flex flex-wrap gap-1.5">
                {prodStatus.map((p, i) => (
                  <Badge key={p.name} variant="secondary" className="text-[10px] capitalize" style={{ color: STATUS_COLORS[i % STATUS_COLORS.length] }}>
                    {p.name}: {p.value}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}