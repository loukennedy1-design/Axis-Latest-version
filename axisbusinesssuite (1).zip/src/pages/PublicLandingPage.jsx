import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Store, ArrowLeft } from 'lucide-react';
import BlockRenderer from '@/components/pagebuilder/BlockRenderer';
import { toast } from 'sonner';

export default function PublicLandingPage() {
  const { slug, pageName } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    base44.functions.invoke('publicLandingPage', { slug, page_name: pageName })
      .then(res => { setData(res.data); setLoading(false); })
      .catch(err => { setError(err.response?.data?.error || 'Page not found'); setLoading(false); });
  }, [slug, pageName]);

  const handleLeadSubmit = async (formData) => {
    try {
      await base44.functions.invoke('publicStorefront', { slug, create_lead: true, ...formData });
      toast.success('Thank you! We\'ll be in touch.');
    } catch (e) { toast.success('Thank you for your interest!'); }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-pulse text-muted-foreground">Loading...</div></div>;
  if (error || !data) return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-3">
      <Store className="w-12 h-12 text-muted-foreground" />
      <p className="text-xl font-semibold">Page Not Found</p>
      <p className="text-muted-foreground text-sm">This page doesn't exist or hasn't been published yet.</p>
      <a href={`/${slug}`} className="text-primary hover:underline flex items-center gap-1"><ArrowLeft className="w-4 h-4" />Back to Storefront</a>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {data.company_name && (
        <header className="border-b border-border sticky top-0 bg-background/95 backdrop-blur z-10">
          <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Store className="w-5 h-5 text-primary" />
              <span className="font-bold">{data.company_name}</span>
            </div>
            <a href={`/${slug}`} className="text-sm text-muted-foreground hover:text-primary">Storefront</a>
          </div>
        </header>
      )}
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {data.blocks.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">This page has no content yet.</div>
        ) : (
          data.blocks.map((block, idx) => <BlockRenderer key={idx} block={block} onLeadSubmit={handleLeadSubmit} />)
        )}
      </div>
    </div>
  );
}