import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import SocialDashboard from '@/components/social/SocialDashboard';
import ContentStudio from '@/components/social/ContentStudio';
import PostCalendar from '@/components/social/PostCalendar';
import AdManager from '@/components/social/AdManager';
import CampaignManager from '@/components/social/CampaignManager';
import { Megaphone, Sparkles, Eye, MousePointerClick, Users, Link2, CheckCircle, AlertCircle, Loader2, Search, Calendar, Target, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

const TABS = [
  { id: 'studio', label: 'AI Studio', icon: Sparkles },
  { id: 'calendar', label: 'Calendar', icon: Calendar },
  { id: 'ads', label: 'Ad Manager', icon: Megaphone },
  { id: 'campaigns', label: 'Campaigns', icon: Target },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
];

export default function SocialMedia() {
  const { data: posts = [] } = useQuery({ queryKey: ['socialPosts'], queryFn: () => base44.entities.SocialPost.list() });
  const { data: campaigns = [] } = useQuery({ queryKey: ['socialCampaigns'], queryFn: () => base44.entities.SocialCampaign.list() });

  const [activeTab, setActiveTab] = useState('studio');
  const [connectedPlatforms, setConnectedPlatforms] = useState({});
  const [connecting, setConnecting] = useState(null);
  const [globalSearch, setGlobalSearch] = useState('');

  useEffect(() => {
    checkAllConnections();
  }, []);

  const checkAllConnections = async () => {
    const platforms = ['facebook', 'instagram', 'linkedin'];
    const status = {};
    for (const platform of platforms) {
      try {
        await base44.asServiceRole.connectors.getConnection(platform);
        status[platform] = true;
      } catch {
        status[platform] = false;
      }
    }
    setConnectedPlatforms(status);
  };

  const handleConnect = async (platform) => {
    setConnecting(platform);
    try {
      const url = await base44.connectors.connectAppUser(platform);
      window.open(url, '_blank', 'width=600,height=700');
      const pollInterval = setInterval(async () => {
        try {
          await base44.asServiceRole.connectors.getConnection(platform);
          clearInterval(pollInterval);
          setConnectedPlatforms(prev => ({ ...prev, [platform]: true }));
          toast.success(`${platform.charAt(0).toUpperCase() + platform.slice(1)} connected!`);
        } catch {
          // Keep polling
        }
      }, 2000);
      setTimeout(() => clearInterval(pollInterval), 120000);
    } catch (err) {
      toast.error(`Failed to connect ${platform}`);
    }
    setConnecting(null);
  };

  const published = posts.filter(p => p.status === 'published').length;
  const scheduled = posts.filter(p => p.status === 'scheduled').length;
  const activeCampaigns = campaigns.filter(c => c.status === 'active').length;
  const totalReach = posts.reduce((s, p) => s + (p.performance_reach || 0), 0);
  const connectedCount = Object.values(connectedPlatforms).filter(Boolean).length;

  const kpis = [
    { label: 'Published', value: published, icon: Sparkles, color: 'text-pink-400' },
    { label: 'Scheduled', value: scheduled, icon: Eye, color: 'text-purple-400' },
    { label: 'Campaigns', value: activeCampaigns, icon: MousePointerClick, color: 'text-blue-400' },
    { label: 'Reach', value: totalReach >= 1000 ? `${(totalReach/1000).toFixed(1)}k` : totalReach, icon: Users, color: 'text-emerald-400' },
    { label: 'Platforms', value: connectedCount, icon: Link2, color: 'text-cyan-400' },
  ];

  return (
    <div className="space-y-5">
      {/* Hero header */}
      <div className="relative overflow-hidden rounded-2xl border border-pink-500/20 bg-gradient-to-br from-pink-500/8 via-card to-purple-500/5 p-5">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500/30 to-purple-600/30 border border-pink-500/20 flex items-center justify-center">
              <Megaphone className="w-5 h-5 text-pink-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Social Media AI</h1>
              <p className="text-muted-foreground text-xs">AI-powered content creation, scheduling & ad management</p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {/* Platform Connection Pills */}
            <div className="flex items-center gap-2">
              {['facebook', 'instagram', 'linkedin'].map(platform => (
                <div key={platform} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border bg-background/50">
                  {connectedPlatforms[platform] ? (
                    <>
                      <CheckCircle className="w-3 h-3 text-emerald-400" />
                      <span className="text-[10px] font-medium capitalize text-emerald-400">{platform}</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-3 h-3 text-amber-400" />
                      <span className="text-[10px] font-medium capitalize text-amber-400">{platform}</span>
                    </>
                  )}
                  {!connectedPlatforms[platform] && (
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-5 w-5 p-0 hover:bg-primary/10"
                      onClick={() => handleConnect(platform)}
                      disabled={connecting === platform}
                    >
                      {connecting === platform ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : <Link2 className="w-2.5 h-2.5" />}
                    </Button>
                  )}
                </div>
              ))}
            </div>
            {/* KPI pills */}
            <div className="flex items-center gap-2 flex-wrap">
              {kpis.map(({ label, value, icon: Icon, color }) => (
                <div key={label} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg border bg-background/50">
                  <Icon className={cn('w-3.5 h-3.5', color)} />
                  <span className={cn('text-sm font-bold', color)}>{value}</span>
                  <span className="text-[10px] text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
            {/* Global search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={globalSearch}
                onChange={(e) => {
                  setGlobalSearch(e.target.value);
                  if (e.target.value && activeTab !== 'calendar' && activeTab !== 'analytics') setActiveTab('calendar');
                }}
                placeholder="Search posts..."
                className="pl-9 pr-4 py-2 rounded-lg border border-border bg-card text-sm focus:outline-none focus:border-pink-500/50 w-56"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-1 border-b border-border overflow-x-auto">
        {TABS.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all whitespace-nowrap',
              activeTab === tab.id
                ? 'border-pink-500 text-pink-400'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            )}
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="pb-10">
        {activeTab === 'studio' && <ContentStudio />}
        {activeTab === 'calendar' && <PostCalendar />}
        {activeTab === 'ads' && <AdManager />}
        {activeTab === 'campaigns' && <CampaignManager />}
        {activeTab === 'analytics' && <SocialDashboard />}
      </div>
    </div>
  );
}