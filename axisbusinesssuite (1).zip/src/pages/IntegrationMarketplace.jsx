import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Plug, Search, CheckCircle, Loader2, Settings, RefreshCw, 
  TrendingUp, Clock, AlertCircle, Link, Database, Zap,
  BarChart3, Globe, Shield, ArrowRight,
  Users, Mail, MessageSquare, DollarSign, Code, ShoppingCart, Briefcase
} from 'lucide-react';
import { toast } from 'sonner';
import QuickBooksCard from '@/components/quickbooks/QuickBooksCard';

const CATEGORY_ICONS = {
  crm: Database,
  erp: BarChart3,
  hr: Users,
  email: Mail,
  sms: MessageSquare,
  finance: DollarSign,
  devops: Code,
  social: Globe,
  ecommerce: ShoppingCart,
  recruiting: Briefcase,
};

export default function IntegrationMarketplace() {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [configDialogOpen, setConfigDialogOpen] = useState(false);
  const [selectedConnector, setSelectedConnector] = useState(null);
  const qc = useQueryClient();

  const { data: connectors = [], isLoading } = useQuery({
    queryKey: ['integration-connectors'],
    queryFn: async () => {
      const result = await base44.functions.invoke('universalIntegrationHub', { action: 'list_connectors' });
      return result.data.connectors || [];
    },
  });

  const { data: syncLogs = [] } = useQuery({
    queryKey: ['integration-sync-logs'],
    queryFn: () => base44.entities.IntegrationSyncLog.list('-created_date', 20),
  });

  const filteredConnectors = connectors.filter(c => {
    const matchSearch = c.connector_name.toLowerCase().includes(search.toLowerCase()) ||
                       c.description?.toLowerCase().includes(search.toLowerCase());
    const matchCategory = selectedCategory === 'all' || c.category === selectedCategory;
    return matchSearch && matchCategory;
  });

  const handleQuickConnect = async (integrationType, connectorName) => {
    try {
      // Redirect to OAuth authorization page
      // The backend function will handle the OAuth flow
      const result = await base44.functions.invoke('oauthAuthorize', {
        integration_type: integrationType,
      });
      
      if (result.data.auth_url) {
        window.location.href = result.data.auth_url;
        toast.success(`Redirecting to ${connectorName} login...`);
      } else {
        toast.error('Failed to start authorization');
      }
    } catch (err) {
      toast.error(`Connection failed: ${err.message}`);
    }
  };

  const handleConnect = async (connector) => {
    await handleQuickConnect(connector.integration_type, connector.connector_name);
  };

  const handleSync = async (connector) => {
    try {
      const result = await base44.functions.invoke('universalIntegrationHub', {
        action: 'start_sync',
        connector_id: connector.id,
      });
      
      if (result.data.success) {
        toast.success(`Synced ${result.data.records_synced} records from ${connector.connector_name}`);
        qc.invalidateQueries(['integration-sync-logs']);
      } else {
        toast.error(`Sync failed: ${result.data.error}`);
      }
    } catch (err) {
      toast.error(`Sync error: ${err.message}`);
    }
  };

  const categories = ['all', 'crm', 'erp', 'hr', 'email', 'sms', 'finance', 'devops', 'social', 'ecommerce', 'recruiting'];

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-card to-accent/5 p-6">
        <div className="absolute -top-8 -right-8 w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/30 to-accent/30 border border-primary/20 flex items-center justify-center">
              <Plug className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Integration Marketplace</h1>
              <p className="text-muted-foreground text-sm">Connect your favorite tools with AI-powered automation</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs">
                <CheckCircle className="w-3 h-3 mr-1 text-emerald-500" />
                {connectors.filter(c => c.is_connected).length} Connected
              </Badge>
              <Badge variant="outline" className="text-xs">
                <Globe className="w-3 h-3 mr-1" />
                {connectors.length} Available
              </Badge>
            </div>
            <Button 
              size="sm"
              onClick={() => window.location.href = '/quick-integrations'}
              className="gap-2"
            >
              <Zap className="w-4 h-4" />
              Quick Connect
            </Button>
          </div>
        </div>
      </div>

      {/* QuickBooks Featured */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Featured Integration</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          <QuickBooksCard />
        </div>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <RefreshCw className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{syncLogs.filter(l => l.sync_status === 'completed').length}</p>
                <p className="text-xs text-muted-foreground">Successful Syncs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center">
                <Database className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{syncLogs.reduce((sum, l) => sum + (l.records_synced || 0), 0)}</p>
                <p className="text-xs text-muted-foreground">Records Synced</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                <Zap className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{Math.round(syncLogs.reduce((sum, l) => sum + (l.execution_time_ms || 0), 0) / (syncLogs.length || 1))}ms</p>
                <p className="text-xs text-muted-foreground">Avg Sync Time</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{syncLogs.length > 0 ? Math.round((syncLogs.filter(l => l.sync_status === 'completed').length / syncLogs.length) * 100) : 100}%</p>
                <p className="text-xs text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <div className="flex items-center justify-between">
          <TabsList className="overflow-x-auto">
            {categories.map(cat => (
              <TabsTrigger key={cat} value={cat} className="capitalize">
                {cat === 'all' ? 'All' : cat}
              </TabsTrigger>
            ))}
          </TabsList>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search integrations..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 w-64"
            />
          </div>
        </div>

        <TabsContent value={selectedCategory} className="mt-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            </div>
          ) : filteredConnectors.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-16 text-center">
                <Plug className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-semibold mb-1">No integrations found</p>
                <p className="text-sm text-muted-foreground">Try adjusting your search or category filter</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {filteredConnectors.map(connector => {
                const CategoryIcon = CATEGORY_ICONS[connector.category] || Plug;
                const lastSync = syncLogs.find(l => l.connector_id === connector.id);
                
                return (
                  <Card key={connector.id} className={`hover:shadow-lg transition-shadow border-2 ${connector.is_connected ? 'border-emerald-500/30' : ''}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${connector.is_connected ? 'bg-emerald-500/10' : 'bg-muted'}`}>
                            <CategoryIcon className={`w-5 h-5 ${connector.is_connected ? 'text-emerald-600' : 'text-muted-foreground'}`} />
                          </div>
                          <div>
                            <CardTitle className="text-base">{connector.connector_name}</CardTitle>
                            <CardDescription className="text-xs">{connector.category}</CardDescription>
                          </div>
                        </div>
                        {connector.is_connected ? (
                          <CheckCircle className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Badge variant="outline" className="text-xs">Not Connected</Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <p className="text-sm text-muted-foreground line-clamp-2">{connector.description}</p>
                      
                      {lastSync && (
                        <div className="text-xs space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Last Sync</span>
                            <span className={lastSync.sync_status === 'completed' ? 'text-emerald-600' : 'text-amber-600'}>
                              {lastSync.sync_status}
                            </span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-muted-foreground">Records</span>
                            <span className="font-medium">{lastSync.records_synced || 0}</span>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2">
                        {connector.is_connected ? (
                          <>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="flex-1 text-xs"
                              onClick={() => handleSync(connector)}
                            >
                              <RefreshCw className="w-3 h-3 mr-1" />
                              Sync Now
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => { setSelectedConnector(connector); setConfigDialogOpen(true); }}
                            >
                              <Settings className="w-3 h-3" />
                            </Button>
                          </>
                        ) : (
                          <Button 
                            size="sm" 
                            className="flex-1"
                            onClick={() => handleConnect(connector)}
                          >
                            <Link className="w-3 h-3 mr-1" />
                            Connect
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}