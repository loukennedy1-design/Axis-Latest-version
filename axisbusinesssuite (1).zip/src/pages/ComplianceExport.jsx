import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, FileText, ShieldCheck, AlertTriangle, Loader2, Filter } from 'lucide-react';
import { format, subDays, startOfDay } from 'date-fns';
import { toast } from 'sonner';

const EVENT_TYPES = ['consent_recorded', 'dnc_added', 'dnc_removed', 'time_violation_blocked', 'caller_id_check', 'tcpa_disclosure', 'opt_out_processed'];

function escapeCSV(val) {
  if (val === null || val === undefined) return '';
  const s = String(val);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function generateCSV(rows, headers) {
  const headerRow = headers.map(escapeCSV).join(',');
  const dataRows = rows.map(r => headers.map(h => escapeCSV(r[h])).join(','));
  return [headerRow, ...dataRows].join('\n');
}

function downloadFile(content, filename, type = 'text/csv') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export default function ComplianceExport() {
  const [dateRange, setDateRange] = useState('30');
  const [selectedTypes, setSelectedTypes] = useState(new Set(EVENT_TYPES));
  const [exportFormat, setExportFormat] = useState('csv');
  const [exporting, setExporting] = useState(null);
  const [previewLimit, setPreviewLimit] = useState(20);

  const { data: logs = [], isLoading } = useQuery({ queryKey: ['compliance'], queryFn: () => base44.entities.ComplianceLog.list('-created_date', 1000) });
  const { data: calls = [] } = useQuery({ queryKey: ['calls'], queryFn: () => base44.entities.CallLog.list('-created_date', 1000) });
  const { data: dnc = [] } = useQuery({ queryKey: ['dnc'], queryFn: () => base44.entities.DNCEntry.list() });
  const { data: leads = [] } = useQuery({ queryKey: ['leads'], queryFn: () => base44.entities.Lead.list() });

  const cutoff = startOfDay(subDays(new Date(), parseInt(dateRange)));

  const filteredLogs = logs.filter(l => {
    const inRange = !l.created_date || new Date(l.created_date) >= cutoff;
    const typeMatch = selectedTypes.has(l.event_type);
    return inRange && typeMatch;
  });

  const filteredCalls = calls.filter(c => !c.created_date || new Date(c.created_date) >= cutoff);
  const consentedLeads = leads.filter(l => l.consent_given);
  const compliantCalls = filteredCalls.filter(c => c.fcc_compliant);
  const violations = filteredLogs.filter(l => l.event_type === 'time_violation_blocked').length;

  const toggleType = (t) => {
    const s = new Set(selectedTypes);
    s.has(t) ? s.delete(t) : s.add(t);
    setSelectedTypes(s);
  };

  const exportAuditLog = async () => {
    setExporting('audit');
    const headers = ['event_type', 'description', 'phone_number', 'lead_id', 'action_by', 'created_date'];
    const rows = filteredLogs.map(l => ({
      event_type: l.event_type,
      description: l.description,
      phone_number: l.phone_number || '',
      lead_id: l.lead_id || '',
      action_by: l.action_by || '',
      created_date: l.created_date ? format(new Date(l.created_date), 'yyyy-MM-dd HH:mm:ss') : '',
    }));
    const csv = generateCSV(rows, headers);
    downloadFile(csv, `compliance_audit_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    setExporting(null);
    toast.success('Audit log exported');
  };

  const exportCallLog = async () => {
    setExporting('calls');
    const headers = ['lead_name', 'phone_number', 'direction', 'status', 'outcome', 'duration_seconds', 'fcc_compliant', 'consent_verified', 'caller_id_displayed', 'called_by', 'created_date'];
    const rows = filteredCalls.map(c => ({
      lead_name: c.lead_name || '',
      phone_number: c.phone_number,
      direction: c.direction,
      status: c.status,
      outcome: c.outcome || '',
      duration_seconds: c.duration_seconds || 0,
      fcc_compliant: c.fcc_compliant ? 'Yes' : 'No',
      consent_verified: c.consent_verified ? 'Yes' : 'No',
      caller_id_displayed: c.caller_id_displayed ? 'Yes' : 'No',
      called_by: c.called_by || '',
      created_date: c.created_date ? format(new Date(c.created_date), 'yyyy-MM-dd HH:mm:ss') : '',
    }));
    const csv = generateCSV(rows, headers);
    downloadFile(csv, `call_compliance_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    setExporting(null);
    toast.success('Call compliance log exported');
  };

  const exportDNCList = async () => {
    setExporting('dnc');
    const headers = ['phone_number', 'reason', 'added_date', 'added_by', 'notes'];
    const rows = dnc.map(d => ({
      phone_number: d.phone_number,
      reason: d.reason,
      added_date: d.added_date ? format(new Date(d.added_date), 'yyyy-MM-dd') : '',
      added_by: d.added_by || '',
      notes: d.notes || '',
    }));
    const csv = generateCSV(rows, headers);
    downloadFile(csv, `dnc_registry_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    setExporting(null);
    toast.success('DNC list exported');
  };

  const exportConsentedLeads = async () => {
    setExporting('consent');
    const headers = ['first_name', 'last_name', 'phone', 'email', 'company', 'consent_given', 'consent_date', 'status'];
    const rows = consentedLeads.map(l => ({
      first_name: l.first_name,
      last_name: l.last_name || '',
      phone: l.phone,
      email: l.email || '',
      company: l.company || '',
      consent_given: l.consent_given ? 'Yes' : 'No',
      consent_date: l.consent_date ? format(new Date(l.consent_date), 'yyyy-MM-dd HH:mm:ss') : '',
      status: l.status,
    }));
    const csv = generateCSV(rows, headers);
    downloadFile(csv, `consented_leads_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    setExporting(null);
    toast.success('Consent records exported');
  };

  const exportFullReport = async () => {
    setExporting('full');
    // Multi-section text report
    const now = format(new Date(), 'yyyy-MM-dd HH:mm');
    let report = `COMPLIANCE AUDIT REPORT\nGenerated: ${now}\nDate Range: Last ${dateRange} days\n`;
    report += `${'='.repeat(60)}\n\n`;
    report += `SUMMARY\n${'-'.repeat(40)}\n`;
    report += `Total Calls: ${filteredCalls.length}\n`;
    report += `Compliant Calls: ${compliantCalls.length} (${filteredCalls.length > 0 ? Math.round(compliantCalls.length / filteredCalls.length * 100) : 100}%)\n`;
    report += `DNC Entries: ${dnc.length}\n`;
    report += `Consented Leads: ${consentedLeads.length}\n`;
    report += `Violations Blocked: ${violations}\n`;
    report += `Audit Events: ${filteredLogs.length}\n\n`;
    report += `AUDIT TRAIL\n${'-'.repeat(40)}\n`;
    filteredLogs.slice(0, 200).forEach(l => {
      report += `[${l.created_date ? format(new Date(l.created_date), 'yyyy-MM-dd HH:mm') : 'N/A'}] ${l.event_type?.toUpperCase()} — ${l.description} (${l.phone_number || 'no phone'})\n`;
    });
    downloadFile(report, `full_compliance_report_${format(new Date(), 'yyyy-MM-dd')}.txt`, 'text/plain');
    setExporting(null);
    toast.success('Full compliance report exported');
  };

  const complianceRate = filteredCalls.length > 0 ? Math.round(compliantCalls.length / filteredCalls.length * 100) : 100;

  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl border border-emerald-500/20 bg-gradient-to-br from-emerald-500/8 via-card to-primary/5 p-5">
        <div className="absolute -top-8 -right-8 w-40 h-40 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Compliance Audit Export</h1>
              <p className="text-muted-foreground text-xs">Export FCC/TCPA compliance data for audit purposes</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs font-semibold text-emerald-400">
              <ShieldCheck className="w-3.5 h-3.5" />{complianceRate}% compliant
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary">
              <FileText className="w-3.5 h-3.5" />{filteredLogs.length} events
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-red-500/10 border border-red-500/20 text-xs font-semibold text-red-400">
              <AlertTriangle className="w-3.5 h-3.5" />{dnc.length} DNC
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-semibold text-blue-400">
              <ShieldCheck className="w-3.5 h-3.5" />{consentedLeads.length} consented
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Filters */}
        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Filter className="w-4 h-4" />Export Filters</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last 12 months</SelectItem>
                    <SelectItem value="3650">All time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="mb-2 block">Event Types</Label>
                <div className="space-y-2">
                  {EVENT_TYPES.map(t => (
                    <div key={t} className="flex items-center gap-2">
                      <Checkbox checked={selectedTypes.has(t)} onCheckedChange={() => toggleType(t)} />
                      <span className="text-xs capitalize">{t.replace(/_/g, ' ')}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Export buttons */}
          <Card>
            <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Download className="w-4 h-4" />Export Options</CardTitle></CardHeader>
            <CardContent className="space-y-2">
              <Button className="w-full justify-start gap-2" variant="outline" onClick={exportAuditLog} disabled={!!exporting}>
                {exporting === 'audit' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4 text-primary" />}
                Audit Log (CSV)
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline" onClick={exportCallLog} disabled={!!exporting}>
                {exporting === 'calls' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4 text-blue-500" />}
                Call Compliance Log (CSV)
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline" onClick={exportDNCList} disabled={!!exporting}>
                {exporting === 'dnc' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4 text-red-500" />}
                DNC Registry (CSV)
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline" onClick={exportConsentedLeads} disabled={!!exporting}>
                {exporting === 'consent' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4 text-emerald-500" />}
                Consent Records (CSV)
              </Button>
              <Button className="w-full justify-start gap-2" onClick={exportFullReport} disabled={!!exporting}>
                {exporting === 'full' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                Full Audit Report (TXT)
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Preview */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-sm">Audit Log Preview ({filteredLogs.length} events)</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <TableHead>Event Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Phone</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></TableCell></TableRow>
                  ) : filteredLogs.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No compliance events in this date range</TableCell></TableRow>
                  ) : filteredLogs.slice(0, previewLimit).map(log => (
                    <TableRow key={log.id}>
                      <TableCell>
                        <Badge variant="outline" className="capitalize text-[10px]">{log.event_type?.replace(/_/g, ' ')}</Badge>
                      </TableCell>
                      <TableCell className="text-xs max-w-[200px] truncate">{log.description}</TableCell>
                      <TableCell className="font-mono text-xs">{log.phone_number || '—'}</TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        {log.created_date ? format(new Date(log.created_date), 'MMM d, h:mm a') : '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {filteredLogs.length > previewLimit && (
                <div className="p-3 text-center">
                  <Button variant="ghost" size="sm" onClick={() => setPreviewLimit(l => l + 20)}>
                    Show more ({filteredLogs.length - previewLimit} remaining)
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}