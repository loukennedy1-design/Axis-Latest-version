# Kennedy Core System — Changelog

## [System Scan — 2026-04-30]

### Fixed
- **sendFollowUpEmail function**: Replaced inefficient `Lead.list()` + in-memory filter with `asServiceRole.entities.Lead.filter({ id: leadId })` for proper RLS handling and performance
- **sendFollowUpEmail function**: Updated `EmailMessage` and `FollowUpTask` creates to use `asServiceRole` to ensure automation calls work correctly when user context is unavailable

### Security & Performance
- Improved backend function to use service-role operations for cross-user lead queries and automated writes
- Prevents RLS bypass and supports scheduler/automation contexts where user auth may not be present